# SEWAK SATHI SANSTHA v1.3-E
# NATIONAL IDENTITY, COMMUNICATION, REPUTATION & MASS ADOPTION ARCHITECTURE

| | |
|---|---|
| **Instrument** | v1.3-E — fifth and final major v1.3 instrument, following v1.3-A (Institutional Survival & Legitimacy), v1.3-B (Costed Mohalla Unit Economics), v1.3-C (Human System, Participation & Mass Adoption) and v1.3-D (Leadership, Succession & Performance) |
| **Question answered** | **HOW DOES A PROVEN LOCAL INSTITUTION BECOME NATIONALLY MEANINGFUL WITHOUT BECOMING A NATIONAL BRAND THAT OUTRUNS IT?** — how Sewak Sathi may be recognised, understood, trusted, spoken about and joined across India, by people who will mostly never become members, without manufacturing identity, emotion, patriotism or scale |
| **Source hierarchy** | **(1)** `…v1_2.pdf` 179 pp. incl. Appendix A preservation of v1.1 — **PRIMARY**; **(2)** `…v1_3_A…md` — **PRIMARY AMENDMENT**; **(3)** `…v1_3_B…md` — **PRIMARY AMENDMENT**; **(4)** `…v1_3_C…md` — **PRIMARY AMENDMENT**; **(5)** `…v1_3_D…md` — **PRIMARY AMENDMENT**; **(6)** `Sewak_Sathi_Strategic_Stress_Test.md` — **ADVERSARIAL DIAGNOSIS**; **(7)** the v1.3-E brief — **SCOPE** |
| **Relationship to prior instruments** | v1.2 = control system. v1.3-A = can it be trusted. v1.3-B = can it survive economically. v1.3-C = does anyone want to be in it. v1.3-D = can it produce and replace the people who run it. **v1.3-E = may it be spoken about, and at what scale, and on what evidence.** Each is additive; none rewrites another |
| **Scope** | National identity and its five confusions; the every-citizen relationship test; participation at national scale; emotional architecture; the national story; political, religious, caste and regional neutrality in expression; local-plus-national identity; brand, visual identity and the red-colour question; language architecture; accessibility; first contact, first five minutes, first real win; the participation funnel; trust, reputation and public transparency; crisis communication; social media; partnerships; government, business, education and media interfaces; the claim ladder and under-claiming; growth and reputation flywheels; replication; one India / many Indias; national culture and shared practice; stories and beneficiary dignity; anti-cult, anti-MLM and anti-coercion in communication; national capacity, bottlenecks and the four growth shocks; reputation shock; communication governance; digital and platform dependency; contribution portability; national recognition and hero language; specialist and knowledge networks; expansion gates; identity and adoption maturity; one integrated evidence system; decision register, amendment pack, contradiction audit, burden/economic/human/leadership/institutional audits, failure register, red team, the shared pilot, fifteen new measurements, the pre-/pilot-/post-pilot matrix and the final architecture |
| **Explicitly out of scope** | Any change to the four-pillar mission **[S: Ch.3]**, the hierarchy of levels **[S: Ch.4]**, the core doctrine **[S: Ch.2]**, the financial waterfall priority order **[S: Ch.18]**, the protection DO-NOT list **[S-A: A-08]**, the Political Neutrality Code **[S-A: A-01 N1…N9]**, the Equal Treatment & Non-Alignment Principle **[S-A: A-05]**, the Protection Visibility Protocol **[S-A: A-06 V1…V8]**, the nine-level participation spectrum **[S-C: H-02]**, the six recognition instruments **[S-C: H-08]**, or the launch roadmap **[S: Ch.30]**. **No performance weight, rupee value, growth target, conversion rate or membership number is invented. No successor is named. No slogan is adopted as doctrine** |
| **Document status** | **NATIONAL-IDENTITY DESIGN — PROPOSED.** Nothing here is policy, brand, copy, claim or promise until approved. Every proposition about what Indian people would feel, think or do is a **hypothesis to be tested**, not a finding |
| **Prepared** | 5 October 2026 |

---

## HOW TO READ THIS INSTRUMENT

### Classification tags

| Tag | Class | Meaning |
|---|---|---|
| **[S]** | **SOURCE-DERIVED** | Stated in v1.2 or the preserved v1.1 source; cited by chapter, article, appendix or database field |
| **[S-ST]** | Source-derived from the **Strategic Stress Test** | Cited by section, failure-mode ID (F-01…F-36), modification (M1…M23) or reconsideration item (R1…R5) |
| **[S-A]** | Source-derived from **v1.3-A** | Cited by amendment ID (A-01…A-23), decision ID (N1…N19, I1…I9, V1…V8) or section |
| **[S-B]** | Source-derived from **v1.3-B** | Cited by amendment ID (B-01…B-27), measurement (B-P-01…B-P-14) or section |
| **[S-C]** | Source-derived from **v1.3-C** | Cited by amendment ID (H-01…H-28), measurement (HM-1…HM-15), right (SR-1…SR-7) or section |
| **[S-D]** | Source-derived from **v1.3-D** | Cited by amendment ID (L-01…L-40), rule (D-1…D-135), measurement (LM-1…LM-15) or Part |
| **[A]** | **ANALYSIS** | Reasoning applied to source facts. Not evidence |
| **[I]** | **INFERENCE** | Probable consequence derived from analysis and ordinary organisational and social behaviour |
| **[P]** | **PROPOSAL** | Recommended here. **Not architecture, not brand, not copy.** Requires approval before it binds anyone or is published anywhere |
| **[V]** | **REQUIRES VALIDATION** | Legal, tax, regulatory, privacy, safeguarding, cultural, linguistic, communications, accessibility or reputation-risk advice required before adoption |
| **[X]** | **EXTERNAL FACT** | Published source outside the supplied architecture; identified where used |
| **[X-inherited]** | External fact **already cited inside the stress test or v1.3-A/B/C/D** | Recorded for honesty; **not re-asserted here as independent evidence** |
| **[C]** | **CALCULATED** | Derived arithmetically from stated variables; carries no new factual content |
| **[M]** | **MODEL ASSUMPTION** | A value or coefficient that must be **measured**, never asserted |
| **[U]** | **UNRESOLVED — DO NOT INVENT** | The source hierarchy has not decided this, and this document refuses to decide it silently |

### Six rules that govern every page

**RULE 1 — No invented evidence.** No membership target, no growth rate, no conversion percentage, no follower count, no reach estimate, no rupee value, no marketing budget, no survey result and no claim about what Indians think or feel is asserted anywhere in this document. Where a number would normally appear, a variable, a band or the phrase `UNKNOWN — MEASURE IN PILOT` appears instead. **[A]** This is not caution. An identity architecture built on invented numbers becomes an organisation that must keep inventing numbers.

**RULE 2 — Preserve the unresolved.** Every UNRESOLVED / NOT FINAL / PROPOSED / REQUIRES FINAL APPROVAL / REQUIRES PROFESSIONAL VALIDATION item in v1.2 and v1.3-A…D that touches identity, brand, communication, language, reputation or public claims is carried forward into **Part 62** and **Annexure B** unchanged. **This document closes nothing the source hierarchy left open.** In particular:

| Carried item | Source status | Where it reappears here |
|---|---|---|
| **Public name "Sewak Sathi Sanstha"** | `PROPOSED` — "use as public operating name while preserving Krytos parent context; validate name availability and registration" **[S: Ch.33; S-A: §22 N-carried]** | Part 12, Part 62 — **used as the working public name throughout, never as a settled one** |
| **Brand ownership and licensing terms** | `UNRESOLVED` — **N12** **[S-A: §22]**; "teams hold no documented right to the name"; settle **before multi-city expansion** | Part 12, Part 52, Part 62 — **not resolved** |
| **IP ownership of architecture, SOPs, curricula, software, data models and brand assets** | `UNRESOLVED` — **N13** **[S-A: §22]**; settle **before national expansion** | Part 12, Part 53, Part 62 — **not resolved** |
| **CEO vs National Council authority** | `UNRESOLVED` **[S: Ch.33; Ch.4]** | Part 52, Part 62 — **not resolved** |
| **Legal entity structure under Krytos** | `UNRESOLVED` **[S: Ch.33]** | Part 22, Part 26, Part 62 — determines what may lawfully be said about status |
| **Non-police ID card design** | `PROPOSED` — "Branding: Non-police ID card design — Communications + Legal" **[S: App. A blocker list]**; QR concept `PROPOSED` **[S: Ch.33]** | Part 13, Part 21, Part 62 |
| **Whether composition monitoring is undertaken at all** | `UNRESOLVED — deliberately` **[S-A: N5 ⟨new⟩]** | Part 9, Part 62 — **not resolved** |
| **Data retention** | `UNRESOLVED` **[S: Ch.33; S-A: A-17 P2]** | Part 22, Part 54 |
| **Whether the leaderboard should be public at all** | open reconsideration **[S-ST: R5]** | Part 24 — **left open** |
| **National Council charter (N19)** | `PROPOSED — REQUIRES FINAL APPROVAL` **[S-A: A-23]** | Part 52 |
| **Worker classification; leader multiplier; founder compensation** | `UNRESOLVED` / `NOT FINAL` **[S: Ch.33; S-D: LDR-U02, U09, U16]** | Part 27, Part 66 — **no figure asserted** |

**RULE 3 — No silent architectural change.** Where this document proposes a modification it states the original principle, the problem discovered, the proposed change, the reason, the benefit, **the new risk created**, and the burden — in the twenty-field E-series format of **Part 63**. Nothing is amended by implication, and no prior FINAL / LOCKED / APPROVED / PROHIBITED decision is altered.

**RULE 4 — Do not repeat A/B/C/D; extend them.** v1.3-C already built the human journey, the four doors, the first-ten-seconds and first-five-minutes standards, the language three-layer model, layered identity, recognition taxonomy and fifteen human measurements. v1.3-D already built eligibility, readiness, succession, gates and fifteen leadership measurements. **v1.3-E does not restate them.** It states what changes when the object is a *nation* rather than a *neighbourhood*, and it supplies only what is genuinely additional — including exactly fifteen new measurements that duplicate nothing.

**RULE 5 — Architecture completeness is not empirical proof, and a document cannot prove national adoption.** The distinction `ARCHITECTURALLY SPECIFIED` versus `EMPIRICALLY VALIDATED` governs every claim. **The v1.3-D finding remains visible throughout and is never softened: the leadership architecture is not yet empirically proven.** A national identity may not be built on a leadership system that has not selected one leader.

**RULE 6 — Do not build a national brand before building a trustworthy local reality.** This is the brief's absolute final rule. It is enforced structurally: **Part 31**'s claim ladder ties every public statement to a demonstrated stage; **Part 58**'s gates tie expansion to capacity; **Part 21** ties reputation to reality; and **Rule E-1** makes the prohibition operable rather than hortatory. Where a choice existed between making the identity more compelling and making the claim more defensible, the claim was made defensible.

### Naming conventions

| Prefix | Meaning |
|---|---|
| **E-1 … E-225** | Operating rules issued inline across Parts 1–76. **Unpadded — `Rule E-7` is a rule; `E-07` is an amendment. Where a rule number reaches three digits (E-101 and above) no ambiguity with the two-digit amendment series is possible** |
| **E-01 … E-46** | v1.3-E amendments, twenty fields each (Part 63, Annexure J). **Hyphenated and zero-padded — distinct from v1.3-A's election-period rules `E1…E14`, which are unhyphenated and are cited as [S-A: A-03 E1…E14]** |
| **N-E-01 … N-E-nn** | National Identity Decision Register (Part 62, Annexure B) |
| **E-C-01 … E-C-20** | Contradiction audit items (Part 64) — numbering mandated by the brief |
| **CI-1 … CI-15** | The fifteen **new** national-identity and communication measurements (Part 73, Annexure I) — additional to **[S-C: HM-1…HM-15]** and **[S-D: LM-1…LM-15]**, duplicating neither |
| **CL-0 … CL-8** | The national claim ladder (Part 31) |
| **GATE E0 … GATE E7** | National expansion identity gates (Part 58) — **distinct from v1.3-D's `Gate E` (eligibility) and `Gate R` (readiness), which are cited as [S-D]** |
| **NI-0 … NI-6** | National identity maturity levels (Part 59) |
| **MA-0 … MA-6** | Mass-adoption maturity levels (Part 60) |
| **SIM-01 … SIM-20** | National failure simulations (Part 48) — numbering mandated by the brief |
| **NRT-01 … NRT-nn** | National red-team attacks (Part 71) |
| **MAF-01 … MAF-nn** | Mass-adoption failure-mode register (Part 70, Annexure D) |
| **NEF-1 … NEF-10** | National emotional failure modes (Part 5, Part 67) |
| **LV-E-1 … LV-E-nn** | Professional validation register for this instrument (Annexure C) |
| **MC-1 … MC-n** | Misclassification classes, extending **[S-ST: §18.2]** (Part 16, Part 49) |
| **LA-1 … LA-5** | The five language registers (Part 14) — extending, not replacing, **[S-C: §30.2 L1/L2/L3]** |
| **BR-1 … BR-n** | Brand-usage rules (Part 12, Annexure F) |
| **TS-1 … TS-n** | Public trust signals (Part 20) |
| **CC-1 … CC-8** | Crisis communication classes (Part 23) |
| **A-nn / B-nn / H-nn / L-nn** | Amendments of v1.3-A / B / C / D — **cited, never renumbered** |
| **F-01 … F-36, M1 … M23, R1 … R5** | Stress-test failure modes, modifications and reconsideration items — **cited, never renumbered** |
| **N1 … N9** | v1.3-A Political Neutrality Code prohibitions — **cited, never renumbered** |
| **V1 … V8** | v1.3-A Protection Visibility Protocol — **cited, never renumbered** |
| **HM-1 … HM-15 / LM-1 … LM-15 / B-P-01 … B-P-14** | Prior measurement sets — **cited, never duplicated or renumbered** |

### The five distinctions the brief requires, stated once and enforced everywhere

**[A]** The brief's central warning is that five pairs of concepts will be confused. This document separates them in **Part 1** and every subsequent Part is built on the separation.

| Confusion | What it would mean | Where enforced |
|---|---|---|
| **NATIONAL RECOGNITION ≠ NATIONAL MEMBERSHIP** | Being known is not being joined | Part 3, Part 4, Part 19 |
| **NATIONAL MEMBERSHIP ≠ NATIONAL TRUST** | A membership count is not a trust measurement | Part 20, Part 31, Part 61 |
| **NATIONAL TRUST ≠ NATIONAL LEGITIMACY** | Being believed is not being entitled to act | Part 26, Part 58, Part 69 |
| **NATIONAL BRAND ≠ NATIONAL IMPACT** | A logo is not a service | Part 12, Part 21, Part 31 |
| **EMOTIONAL CONNECTION ≠ EMOTIONAL MANIPULATION** | Creating conditions is not engineering dependence | Part 5, Part 41, Part 67 |

### The absolute rule applied to this pack

> **Do not design an identity India should admire. Design an institution whose real behaviour can be verified by anyone who bothers to look — and then describe it plainly.**

**[A]** This is the operative constraint on every proposal below. A national identity that depends on people *not looking closely* is a liability that grows with every person who hears of it. **[S-ST: §11.3]** already established the principle: "every public claim must be traceable to a record a member could inspect." v1.3-E makes that the governing rule of the entire instrument, and tests every mechanism against the question: *what happens when a hostile journalist, a sceptical official, a disappointed beneficiary and an ambitious local leader all examine this at the same time?*

---

# EXECUTIVE SUMMARY

## ES.1 The finding in one paragraph

**[A]** The source architecture is **unusually well defended against saying the wrong thing** and **almost entirely unequipped to say the right thing in a way anyone outside can verify.** v1.2 already fixes: a communication-type rule table covering internal, public/social, emergency, press and misinformation **[S: Ch.24]**; "only verified facts; distinguish completed work from plans; protect privacy"; "authorised spokespersons only; national/relevant approval for sensitive matters"; "correct calmly with verifiable facts and correction logs"; a **National Communications** department that "owns public narrative, brand standards, crisis communication, misinformation correction and media approvals" **[S: Ch.5]**; **Editor** and **Social Media Manager** role specifications with explicit "cannot" boundaries including "cannot publish unverified claims, expose beneficiaries without consent, comment on legal/safety incidents without approval, use intimidation" **[S: App. A §8.x]**; a **Communication** training category covering "verified information, public statements and misinformation correction" **[S: Ch.12]**; an information colour system with the rule that "colour is used as an information system, not decoration… no mandatory rule is communicated by icon alone" **[S: Ch.1]**; a partnership rule that "no team should imply that a partner endorses the entire organisation unless the written agreement says so" **[S: Ch.5 §4.4]**; and — decisively — a **launch blocker**: "Communication / branding: ID card, public statement rules, misinformation correction → approved card mock-up and comms policy → **Blocker**" **[S: Ch.31]**. v1.3-A then added the Political Neutrality Code **N1…N9**, the Equal Treatment & Non-Alignment Principle, the Protection Visibility Protocol **V1…V8**, dual custody of "domain, payment gateway, communication channels, social accounts", public-representation rules, and two UNRESOLVED ownership questions. v1.3-C added the three-layer language architecture, layered identity, the first-ten-seconds and first-five-minutes standards, the recognition taxonomy and fifteen human measurements.

**[A]** What does not exist is **the connection between what the organisation can prove and what it may say.** The architecture generates evidence at a rate no Indian civic body matches — verification, outcome checks, receipts, reconciliation, decision records, correction logs, refusal logs, incident records **[S: Ch.15, Ch.18, Ch.19, Ch.25; S-A: A-15; S-ST: §14.2]** — and then keeps essentially all of it internal. **[S-ST: §14.1]** states the diagnosis exactly: the architecture "is strong on *being* trustworthy and almost entirely silent on *being seen to be* trustworthy. Trust that cannot be observed does not compound." **v1.3-E exists to build that missing bridge — and to refuse, at every point, to build the bridge out of anything the organisation cannot show.**

## ES.2 The central diagnosis

**[A]** Six structural faults, each traced to source.

| # | Fault | Evidence | Why it matters |
|---|---|---|---|
| **1** | **The evidence is real and the visibility is absent.** Every honesty mechanism is internal | **[S-ST: §14.1]**: "Not published. All honesty machinery is internal. A stranger cannot see any of it." No public-facing complaint channel, no ombuds, no published outcomes | An unobservable virtue does not compound into trust, and an organisation that cannot be seen to be honest is indistinguishable from one that is not |
| **2** | **The description is eleven concepts long and the public will pick one — usually the worst.** "A Krytos-owned, founder-led, nationally scalable, locally distributed organisation with four functions…" | **[S-ST: §18.1]**: "No human being holds eleven concepts… The public will collapse it into **one** category, chosen by whatever they encounter first and whatever they fear most." Eleven misclassifications mapped, four rated **Severe** | Misclassification is not a messaging problem; it is a **safety, legal and legitimacy** problem — vigilante, political, religious and surveillance readings each carry real-world consequence |
| **3** | **The first available action is the wrong one.** The architecture's entry point is "application — begins verification; not entitlement to join" | **[S: Ch.12]**; **[S-ST: §20.3]**: "That is an integrity-first design and a conversion-fatal one." The 10-second test **fails 4 of 5** | Nobody can report a need or help once without first encountering a membership process, so the organisation is discovered as a gate rather than as a service |
| **4** | **Red is already spoken for.** In v1.2 red is not a brand colour — it is the information-system colour for "Safety / protection / risk: protection boundaries, incidents, prohibitions and risk register" | **[S: Ch.1 colour system]**; and **[S-A: A-01 N2, N4]** prohibit use of the organisation's "marks, **colours**, dress" for partisan purposes and prohibit adopting political "colours" | Any red-dominant public identity collides with the architecture's own semantics for *prohibition and danger*, sits adjacent to several political colour fields, and would have to be defended jurisdiction by jurisdiction. **This is a genuine defect, not a matter of taste** |
| **5** | **The brand's legal owner is unknown.** Brand ownership and licensing (**N12**) and IP ownership (**N13**) are both `UNRESOLVED`, and **[S: Ch.4]** places "Property, brand, strategy and ultimate founder-level control" in one pair of hands | **[S-A: §22 N12, N13, I6, V8]**: "Teams hold no documented right to the name"; "the institution's operating system could be withdrawn by a licensor"; must be settled **before multi-city / national expansion** | Every local team using the name is using it without a documented right. **A national identity cannot be built on an unowned mark** |
| **6** | **Nothing compels the one act that would make all of this credible.** Publishing failures, corrections and refusals is prescribed as strategy and required by no gate | **[S-ST: §14.2 Layer 3]** "Publish failures… the single most differentiating trust act available"; **[S: Ch.15]** requires failures in *internal* reports; **[S-A: A-01]** requires a refusal log but publication is **[P]**; **[S-C]**, **[S-D]** add no compulsion | **ES.5 below. This is the largest single weakness in the five-instrument set** |

**[I]** Together these produce a specific and unusual risk profile: **an organisation with more verifiable integrity than almost any comparable body, and less ability to demonstrate it than a well-run NGO with an annual report.** The gap is not honesty. It is **publication architecture** — and publication architecture is cheap before scale and unaffordable after it.

## ES.3 What this instrument builds

**[P]** Seventy-six parts, eleven annexures and **46 separately mergeable amendments (E-01…E-46)**. **The count is a consequence of the Part count, not a target.**

| ID | Title | Part |
|---|---|---|
| **E-01** | **The Five-Distinction Rule** — recognition, membership, trust, legitimacy, brand and impact defined separately, with an operable test for each | 1, 2 |
| **E-02** | **Every-Citizen Relationship Matrix** — 25 relationships, of which **membership is one** | 3 |
| **E-03** | **National Participation Without Membership** — nine unaffiliated pathways, none conferring hidden authority | 4 |
| **E-04** | **Emotional Conditions Architecture** — the eight-stage journey as *conditions to create*, never *messages to send*; ten prohibited emotions | 5 |
| **E-05** | **National Story and Claim Traceability** — every public claim traceable to a record a member could inspect | 6 |
| **E-06** | **Political Neutrality in Expression** — extends **[S-A: N1…N9]** from conduct to every public artefact, including favourable content | 7 |
| **E-07** | **Religious Neutrality in Expression** — respect without alignment; no ritual as an organisational requirement | 8 |
| **E-08** | **Caste Neutrality and the Composition-Monitoring Refusal** — carries **[S-A: N5]** forward unresolved | 9 |
| **E-09** | **Regional Plurality and the Localisation Contract** — eight immutable items, ten localisable items | 10 |
| **E-10** | **Layered Identity** — local primary, national derived; **the national layer supplies capability, not identity** | 11 |
| **E-11** | **Three-Tier Brand Architecture and the Parent-Subordination Rule** | 12 |
| **E-12** | **Visual Identity and the Red-Colour Resolution** — colour as information system preserved; brand palette separated from it | 13 |
| **E-13** | **Five Language Registers** — governance, operational, public, local-participation, emergency | 14 |
| **E-14** | **Accessibility Standard** — implemented, not claimed | 15 |
| **E-15** | **First Contact Standard** — the eight-question national test and the misclassification map | 16 |
| **E-16** | **First Five Minutes, national version** — value before vetting; a public local page | 17 |
| **E-17** | **First Real Win at national scale** — no joining, no payment, no public praise | 18 |
| **E-18** | **National Participation Funnel with no conversion targets** | 19 |
| **E-19** | **Trust Production System** — four layers made operational, with public trust signals TS-1…TS-n | 20 |
| **E-20** | **Reputation Architecture** — Reality → Evidence → Transparency → **Correction** → Trust → Reputation → Repeat participation | 21 |
| **E-21** | **Four-Audience Transparency Regime** — public, member, leader, auditor, sealed | 22 |
| **E-22** | **Crisis Communication Protocol** — eight classes, seven-step public error response | 23 |
| **E-23** | **Social Media Doctrine and the Vanity-Metric Prohibition** | 24 |
| **E-24** | **Partnership Architecture and brand-usage rules** — partnership is not endorsement | 25 |
| **E-25** | **Government Interface Communication Boundaries** — cooperate without becoming | 26 |
| **E-26** | **Business Interface and the public Service/Sales Firewall** | 27 |
| **E-27** | **Education Interface** — institutions are not recruitment pipelines | 28 |
| **E-28** | **Media Interface, local and national, with evidence thresholds** | 29, 30 |
| **E-29** | **Claim Ladder CL-0…CL-8 and Under-Claiming as Policy** | 31 |
| **E-30** | **Reputation and Growth Flywheels, in the only permitted order** | 32 |
| **E-31** | **Replication Classification** — must-copy exactly vs may-adapt | 33 |
| **E-32** | **Structural Variance Register** — one India / many Indias, without stereotypes | 34 |
| **E-33** | **National Culture and Shared Practices, burden-tested** | 35, 36 |
| **E-34** | **Story Architecture and Beneficiary Dignity Rules** — attribution grammar, consent, images, children, before/after | 37, 38 |
| **E-35** | **Anti-Cult, Anti-MLM and Anti-Coercion controls in communication** | 39, 40, 41 |
| **E-36** | **National Capacity and the Bottleneck Principle** — growth ≤ smallest critical capacity | 42 |
| **E-37** | **Four Growth-Shock Protocols** — viral, slow, zero, negative | 43–46 |
| **E-38** | **Reputation Shock and Attack Response** — criticism is not automatically an attack | 47 |
| **E-39** | **National Communication Governance** — who may publish, on what evidence, with what correction duty | 52 |
| **E-40** | **Digital Architecture and Platform-Dependency Controls** — no single vendor, no personal account as an official channel | 53 |
| **E-41** | **Contribution Portability at national scale** — recognisable across cities, never a social-credit score | 54 |
| **E-42** | **National Recognition and the Hero-Language Rule** — service identity over combat identity | 55 |
| **E-43** | **Specialist and Knowledge Networks in public** — without creating a visible elite | 56, 57 |
| **E-44** | **Identity Maturity NI-0…NI-6 and Adoption Maturity MA-0…MA-6**, evidence-defined | 59, 60 |
| **E-45** | **One Integrated Evidence System** and the three expansion outcomes **EXPAND / IMPROVE / PAUSE** | 61 |
| **E-46** | **Claim Discipline** — six claim classes and five public evidence labels | 31, 61 |

**Full twenty-field register at Part 63 and Annexure J.**

## ES.4 The verdict, stated in advance

> # **D — NATIONAL IDENTITY & MASS-ADOPTION SYSTEM NOT YET PROVEN**
> ### with a defined, testable path to **B — VIABLE WITH TESTING**

**[A]** Reasoning in full at **Part 76**. In summary: **A** is unavailable because the brief itself states that "a document cannot prove national adoption", and nothing here has been seen by a single member of the public. **C — requires major redesign** would be dishonest in the other direction: the source already contains a communications department, two specified communication roles with explicit prohibitions, a communication training category, a five-row communication rule table, a launch blocker requiring a comms policy, a Political Neutrality Code, a Protection Visibility Protocol, a language-equality principle and a layered-identity model — **which is more communication governance than most national institutions possess.** **B** is unavailable because eight requirements are unsatisfied:

| Requirement for B | Status today |
|---|---|
| A single approved category sentence that passes the 10-second test in every operating language | ❌ **fails 4 of 5** today **[S-ST: §20.1]**; a draft exists but is `[P — not adopted language]` |
| Brand ownership and licensing resolved (**N12**) and IP ownership resolved (**N13**) | ❌ both `UNRESOLVED` **[S-A: §22]** |
| A public local page and a public complaint channel exist | ❌ **[S-ST: §20.3]** "not in the current architecture"; **[S-ST: §14.1]** "no public-facing complaint channel" |
| A published "what we are not" statement and a misclassification response protocol | ❌ proposed **[S-ST: §18.3]**, unadopted |
| A comms policy and a non-police ID card design — **both source launch blockers** | ❌ `PROPOSED` **[S: Ch.31; App. A blocker list]** |
| One published year of accounts, one published correction, one logged political refusal | ❌ nothing published; nothing has occurred |
| National-communication burden costed against `σ_max` | ❌ **`UNKNOWN`**; no communication line exists in **[S-B]**'s cost model |
| Any of it observed on real people | ❌ nothing has been |

**[A] Eight requirements, zero satisfied.** The same arithmetic that returned **D** from v1.3-B, v1.3-C and v1.3-D returns **D** here, for a sharper reason: **this instrument describes how a reputation would be earned by an organisation that has not yet served anyone.**

## ES.5 The single biggest unresolved weakness — stated without softening

> **[A] The entire reputation architecture rests on one voluntary act — publishing what went wrong — and no instrument in v1.2 or v1.3-A/B/C/D/E compels it, detects its absence, or penalises its omission.**

**[A]** Everything else in this five-instrument set has a control. Money has the waterfall, segregation of duties and audit **[S: Ch.18, Ch.27]**. Safety has the DO-NOT list and stop-work authority **[S-A: A-08; S: Ch.16]**. Data has classification, minimisation and sealed categories **[S-A: A-17…A-20]**. Leadership has gates, independent assessment and appeals **[S-D]**. Participation has refusal rights and dignity rules **[S-C: H-17]**. AI has Article 12 **[S: Const. Art.12]**.

**Publication of failure has nothing.** **[S: Ch.15]** requires failures and partial outcomes in *internal* reports. **[S-ST: §14.2]** proposes extending that to public reporting and calls it "the single most differentiating trust act available to this organisation, and almost no Indian institution does it." **[S-ST: §14.3 item 9]** proposes "a published correction — evidence that the organisation has corrected itself publicly at least once," on the ground that "institutions that have never corrected anything are either dishonest or inactive." **Every one of those is `[P]`.** None is a gate. None is a blocker. None appears in **[S: Ch.31]**'s launch checklist, in **[S-B]**'s control budget, in **[S-C]**'s human measurements or in **[S-D]**'s gates.

**[I]** And the incentive runs the wrong way. The people who decide whether to publish a failure are the people whose reputation the failure damages. Under-claiming is prescribed as *strategy* — **[S-ST: §18.3 item 4]**, "under-claiming is a trust strategy; over-claiming is a liability" — but a strategy is what an organisation does when it is convenient. **There is no mechanism that makes radical plainness inconvenient to omit.** The predictable outcome is a well-designed transparency architecture that publishes accounts, outcomes and successes on schedule, and whose correction log stays empty for years — not because nothing went wrong, but because nothing compelled the entry.

**[A]** The minimum architectural correction is **E-20 plus Rule E-61**: a **published correction log with a mandatory entry condition** — any confirmed material error in a public claim, any adverse audit or safeguarding finding, any upheld complaint against the organisation, and any logged political or commercial refusal **must** appear in the public correction and refusal record within a stated window; **an empty log across a full reporting period is itself published as an anomaly and referred to Audit**, on the same logic **[S-A: A-16]** applies to the dissent test, where "a zero count is a warning sign, not a clean bill of health." **That is the only control in this document that operates on absence rather than on presence, and it is the one the whole reputation architecture needs.**

**[A]** Whether it will be honoured is `EMPIRICALLY UNVALIDATED`, and honestly may not be: **a rule that requires an organisation to publish its own failures is the rule most likely to be quietly reinterpreted as applying only to failures that were already public.**

## ES.6 What this instrument refuses to do

| Refusal | Reason |
|---|---|
| **Adopt any slogan, sentence, tagline or proposition as official language** | **[S-ST: §20.2]** is explicitly "draft for approval, not adopted language"; **[S-C: §3.4 PM-1…PM-8]** shows how the emotional proposition can fail. Every candidate sentence here is `[P]` and requires approval |
| **Claim "India's largest", "India's most trusted", "every Indian", "revolutionary", "unmatched", "national movement"** | No empirical support exists; **[S-ST: §19.2]** explicitly lists superiority claims as *not defensible* |
| **Resolve brand ownership (N12), IP ownership (N13), the public name, CEO-vs-Council, the entity structure or composition monitoring** | All `UNRESOLVED`; Rule 2 forbids closing them |
| **Invent a marketing budget, a communication salary, a media spend, an event cost, a travel assumption, a membership target, a growth rate or a conversion percentage** | **[S-B]** discipline; the brief's absolute rule |
| **Design a uniform, insignia, rank marking, worn badge, oath, salute or loyalty ceremony** | **[S-A: A-06 V1, V2, V3, V6]** prohibit them absolutely; **[S-C: H-13]** six ritual tests; **[S-D: §21.7]** rejected oaths and insignia |
| **Create a national trust score, a reputation index, or any single composite measure of public standing** | Brief §90; **[S-C: §23.2]** "a person is never scored"; **[S-D: Rule D-63]** bands not scores |
| **Treat followers, likes, views or shares as measures of organisational success** | **[S: Ch.25]** prohibits raw counts determining leadership; brief §45 |
| **Recommend celebrity endorsement, influencer partnership or patriotic appeals as legitimacy instruments** | Brief §47, §154; **[S-A: A-16 §15.4]** public-representation rules; tested and found adverse in Part 24, Part 39 |
| **Collect caste, religion or political identity data to demonstrate diversity** | **[S-A: A-18]** minimisation; **[S-A: N5]** composition monitoring is `UNRESOLVED — deliberately`; brief §14 |
| **Create a second pilot** | **[S-B: §40]**, **[S-C: §57]**, **[S-D: Rule D-130]** require one shared pilot. Part 72 adds observations to it |
| **Assume that India will care, that the name will become known, that patriotism will work, that social media will work, that members will grow, or that a successful pilot proves national adoption** | Brief §250. Each assumption is tested and, where it fails, the failure mechanism is shown |

## ES.7 How to use this document

| If you are… | Read |
|---|---|
| The founder deciding what to approve first | **ES.3, Part 16, Part 22, Part 31, Part 58, Part 63 (Stage 0–1 items), Part 76** |
| The person who will write the comms policy that **[S: Ch.31]** makes a launch blocker | **Part 16, Part 21, Part 22, Part 23, Part 31, Part 52** |
| The person who must design the ID card without making it look like police | **Part 13, Part 21 — read with [S-A: A-06 V1…V8]** |
| The person worried this becomes a propaganda machine | **Part 5, Part 31, Part 39, Part 67, ES.5** |
| The person worried about political or religious capture | **Part 7, Part 8, Part 9, Part 47, Part 64** |
| The person worried the brand will outrun the institution | **Part 21, Part 31, Part 58, Part 59, Rule E-1** |
| The person worried about language and exclusion | **Part 14, Part 15, Part 34, Part 51** |
| The person who must merge this into v1.2 | **Part 63 (merge targets), Annexure A, Annexure J** |
| The person auditing this document | **Part 48, Part 64, Part 70, Part 71, Part 76, Annexure K** |

---

# PART 1 — NATIONAL IDENTITY PROBLEM

## 1.1 The problem, stated as a problem

**[A]** The brief's primary question contains three constraints that pull against one another, and the whole instrument is an attempt to hold all three:

1. **Nationally recognisable and emotionally meaningful** — which requires repetition, simplicity, symbols and scale.
2. **Without requiring everyone to become a member** — which requires that recognition not convert into recruitment pressure, and that value exist outside membership.
3. **Without building a national brand before the local system has earned trust** — which requires that every public expression be *behind* the evidence, never ahead of it.

**[I]** Constraints 1 and 3 are in direct tension. Recognition is produced by repetition of a simple claim; trust is produced by accumulation of verified specifics. **A simple claim repeated nationally will outrun verified specifics accumulated locally, unless the claim is deliberately smaller than the evidence.** That is why **[S-ST: §18.3 item 4]** treats under-claiming as strategy rather than modesty, and why **Rule E-1** below makes it operable.

## 1.2 The five distinctions, defined separately

**[P] Amendment E-01 — The Five-Distinction Rule.** Each concept gets a definition, a producer, a measurement and an operable test. **The test is what makes the distinction architectural rather than rhetorical.**

| Concept | Definition | What produces it | What measures it | Operable test | What it is NOT |
|---|---|---|---|---|---|
| **NATIONAL RECOGNITION** | A person who has never met anyone from the organisation has heard the name and can place it in a category | Repeated truthful contact; visible local results; word of mouth | **CI-1** misclassification rate; **CI-2** ten-second comprehension | *Ask a stranger what it is. If the category they choose is one of the eleven misclassifications (Part 16), recognition has failed even though it succeeded* | Not membership. Not trust. Not approval |
| **NATIONAL MEMBERSHIP** | A count of people who have completed verification and hold a recorded role or standing **[S: Ch.12]** | Verification capacity, leadership capacity, economic capacity | Member growth **[S: Ch.24 annual]**; **[S-D: LM-14]** pipeline throughput | *Can the organisation serve, verify, lead and pay every person it admitted?* | Not trust. Not relevance. Not impact |
| **NATIONAL TRUST** | A person who has never been helped would rely on the organisation's word about something that matters to them | Kept small promises, visibly; published accounts; published corrections; consistent behaviour over time | Four trust layers (Part 20); **TS-1…TS-n** signals; **[S-C: HM-14]** promises kept | *Would a sceptical stranger believe a claim they cannot check?* — **and the honest answer at CL-0 is no, which is why the claim must be checkable instead** | Not legitimacy. Not reputation. Not absence of scrutiny |
| **NATIONAL LEGITIMACY** | Authorities, institutions and communities accept that the organisation may act in a given domain | Legal form, insurance, documented boundaries, demonstrated competence, referrals honoured, refusals logged | **[S-ST: §30.3]** fifteen pre-conditions; Part 58 gates; **[S-A: A-01]** refusal log | *Would a police station, a municipality, a school and a hospital each know exactly what this organisation may and may not do, and believe it?* | Not trust. Not popularity. Not scale |
| **NATIONAL BRAND** | The set of marks, names, colours, words and channels by which the organisation is identified | Design and governance; **owned by whoever N12/N13 determine — `UNRESOLVED`** | Brand-usage compliance (BR-1…BR-n); misclassification rate | *Does the mark tell the truth about the institution?* | Not impact. Not legitimacy. **A national logo can exist in one day; a national institution cannot** |
| **NATIONAL IMPACT** | Verified, followed-up outcomes in the lives of people served | Service delivery, verification, follow-up **[S: Ch.15 step 10]** | **[S-C: HM-8]** follow-up outcome known; outcome windows **[S-D: Part 8]** | *Did the problem get resolved, reduced, stay the same, worsen — and does the organisation know which?* | Not activity. Not reach. Not awareness |

**[P] Rule E-1 (The Claim Ceiling).** No public statement may assert a concept at a level above what the organisation can currently evidence. Concretely: **brand may never be described in terms that imply impact; impact may never be described in terms that imply legitimacy; legitimacy may never be described in terms that imply trust; trust may never be described in terms that imply membership; membership may never be described in terms that imply recognition.** Each claim is bounded by the one below it in the evidence order: **IMPACT → TRUST → LEGITIMACY → MEMBERSHIP → RECOGNITION → BRAND.** **[A]** The order matters because it is the order in which things can be *produced*. Brand is the cheapest and last-earned; impact is the hardest and first-required.

**[P] Rule E-2 (The Substitution Prohibition).** No instrument, target, dashboard, incentive or campaign may substitute recognition for membership, membership for trust, trust for legitimacy, or brand for impact. **Specifically: a follower count may never appear in any expansion, funding or legitimacy argument** (Part 24; **[S: Ch.25]**'s prohibition on raw counts determining leadership is extended to determining scale claims).

## 1.3 Why "national" is the wrong first word

**[A]** The brief's §156 asks whether "Make our Mohalla better" is a stronger entry point than "Join a national organisation". **[S-ST: §29 item 1]** already answers it: "India's problems and India's capacity are both hyper-local… the people who could fix them usually live within two kilometres." **[S-C: H-26]** makes it a rule: **local primary and national derived; the national layer supplies capability, not identity.**

**[P] Rule E-3 (National Is Derived, Never Primary).** The word "national" may describe **capability, standards, continuity and reach** — it may never describe **belonging, identity or community**. A person belongs to their mohalla team. They are *supported by* a national network. **Any communication that invites a person to belong to India-scale community is inviting them to belong to nothing.**

**[I]** This has a hard consequence for this document: **most of what follows is not about speaking to India. It is about ensuring that when India hears about a lane in Moradabad, what it hears is true, checkable, in a language it can read, and about the lane rather than about the organisation.**

## 1.4 The reputation-capacity alignment problem

**[A]** Brief §89: the organisation must never build a stronger reputation than its actual capability. The mechanism by which excess reputation destroys an institution:

```
REPUTATION EXCEEDS CAPACITY
   -> expectations rise          (people ask for more, and expect yes)
   -> demand rises                (inbound needs exceed verification and delivery capacity)
   -> decline rate rises          (more requests must be refused)
   -> refusals are experienced as betrayal, because the reputation promised otherwise
   -> trust falls below its pre-reputation level     (the fall is larger than the rise)
   -> the organisation is now worse off than if it had never been heard of
```

**[P] Rule E-4 (Reputation Lags Capacity).** Public expression of capability is permitted only at the **highest stage already demonstrated**, never at the stage being attempted. **The claim ladder (Part 31) is the instrument; CL-n claims require CL-n evidence.** **[A]** The cost of this rule is real and is stated: **it means the organisation will be less impressive than it could appear for several years.** That is the price of a fall that is survivable rather than fatal, and **[S-ST: §14.3]** makes the same argument — "each of these items is cheap before scale and unaffordable after it."

**[P] Rule E-5 (A Well-Delivered Decline Is A Trust Event).** Where capacity is exceeded, the refusal is delivered honestly, early, with an alternative where one exists, and is recorded. **[S-ST: §20.3]**: "a well-delivered decline is itself a trust event"; **[S-B: §20.3]** response times and refusal-with-alternative. **[A]** This is the only mechanism available that converts excess reputation from a liability into evidence of honesty — and it works only if the refusal is *experienced as competent*, which requires the person refusing to know what the alternative is.

## 1.5 What this Part concludes

**[A]** Three findings, carried into every subsequent Part:

1. **The identity problem is not "what should we say". It is "what can we show".** Every communication instrument in this document is therefore specified as a **publication of an existing record**, not as the creation of a message. Where no record exists, nothing may be said.
2. **The five confusions are not semantic errors; they are substitution risks with different failure speeds.** Brand outruns impact in days. Recognition outruns trust in weeks. Membership outruns capacity in months. Legitimacy outruns all of them in a single incident.
3. **National identity is a *by-product*, and by-products cannot be targeted.** **[P]** The target is repeatable local value; national identity is what accumulates when enough of it is visible and checkable. **Any plan that targets national identity directly will produce national identity claims, which is the opposite thing.**

---

# PART 2 — NATIONAL IDENTITY PHILOSOPHY

## 2.1 What the source already commits the organisation to

**[S: Ch.2 core doctrine, verbatim]** — "Help without discrimination. Protect without retaliation. Serve without expecting reward. Stand against injustice without becoming unjust. Use strength with discipline. Responsibility follows earned trust."

**[S: Ch.2 operating formula, verbatim]** — "Central mission + local autonomy + verified membership + AI-enabled business + transparent compensation + measurable performance + earned leadership."

**[S: Ch.2]** — service "is not restricted by caste, religion, gender, economic status, politics, personal identity or popularity, subject to lawful eligibility and safeguards."

**[S-A: A-05 clause 2]** — "The organisation is not affiliated with, an instrument of, or identified with any religion, caste, ethnicity, linguistic group, region or social group. It has no theological, caste, ethnic or regional position and expresses none."

**[S-C: §8.4]** — "no instrument may describe leadership as a higher form of service."

**[A]** Read together, these already determine most of the identity philosophy, and they determine it **negatively** — as constraints on what the organisation may claim to be. **[P]** v1.3-E does not add a positive identity. It makes the negative one publishable.

## 2.2 "Feel Indian without claiming ownership of India" — tested

**[A]** The brief asks that this proposition be tested, not adopted.

| Test | Result |
|---|---|
| Can the organisation use "India" descriptively? | **Yes** — "operating in N localities across N states" is a fact about geography, not a claim about the nation |
| Can it use "India" possessively or representatively? | **No.** "India's", "for India", "the nation's" implies a mandate nobody granted. **[S-A: A-05 clause 2]**: no regional position, expressed or implied |
| Can it use national symbols? | **No.** **[S-A: A-01 N4]** prohibits adopting political "symbols, slogans, flags, colours, insignia, gestures, songs, portraits or dress"; **the national flag and emblem are state symbols and their use is regulated [V] REQUIRES LEGAL VALIDATION** |
| Can it appeal to patriotism? | **Only as one motivation among many, never as the primary mechanism, and never institutionally.** **[S-ST: §6.2]** classifies motivations as compatible or corrosive; **[S-A: A-05 guard 2]**: a person may join because their faith or patriotism commands service — "accepted individually, never invoked institutionally" |
| Can it say "Indian values"? | **No.** There is no agreed referent, and any specification excludes someone. **[S-A: A-05 clause 3]** permits *cultural respect* — working within local calendar, food, dress norm and courtesy — "as matters of practical effectiveness and courtesy, not as endorsement of any belief system" |
| Can it be *of* India? | **Yes, and this is the whole answer.** It is of India by being **in** Indian neighbourhoods, in Indian languages, on Indian calendars, solving Indian-scale local problems, with Indian people, under Indian law. **Presence, not claim** |

**[P] Rule E-6 (Presence, Not Claim).** The organisation's Indianness is expressed by **where it is, whose language it speaks, what it does and whom it serves** — never by adjectives, symbols, anthems, flags or possessive nouns. **[A]** This rule costs nothing and removes an entire category of political and communal exposure.

## 2.3 "You can participate without becoming culturally identical to us" — tested

**[A]** The brief proposes this sentence. **[S-C: H-26]** and **[S-A: A-05 guard 1]** already support it: "**Not cultural erasure.** Local expression — language, food, timing, venue, forms of courtesy, local recognition rituals — is *required* for the organisation to belong anywhere… Neutrality governs *alignment and treatment*, not *culture*."

**[P] The proposition is sound but must be stated more precisely, because as written it implies the organisation *has* a culture that others need not adopt.** The accurate version:

> **[P]** *The organisation has no culture of its own to impose. It has a small set of immutable rules — doctrine, safety, financial priority order, verification, AI boundaries, privacy and dignity, non-alignment, evidence standards — and beyond those rules, the culture is yours and stays yours.*

**[A]** This is **[S-ST: §12.1]**'s localisation contract stated from the participant's side: **eight immutable items, ten localisable items** (Part 10, Part 33). **The participant is not being asked to tolerate a national culture; they are being told that the national layer is eight rules and a capability, and that everything else is already theirs.**

**[P] Rule E-7 (Additive Participation).** Participation is additive to every existing identity. The formulation is **"I am this, and I also contribute here"** — never **"I belong to this organisation, therefore I must think like it."** Concretely: no member is required to change their name, language, dress, diet, calendar, faith, political view, profession, family role or neighbourhood allegiance; and **no organisational artefact may imply that a member has changed any of them.**

## 2.4 The seven identity principles, tested and classified

**[P]** The brief §244–§249 proposes six principles and asks that each be tested and classified. **None is source-derived; all are `[P]` unless marked.**

| # | Principle as proposed | Test | Verdict | Classification |
|---|---|---|---|---|
| **IP-1** | "Scale capacity before claims" | Consistent with **[S-B: §26]** control budget, **[S-D: Rule D-43]** expansion gate, **[S-ST: §30.3]** | **ADOPT** — this is Rule E-4 restated | **[P]**, supported by **[S-B]**, **[S-D]** |
| **IP-2** | "The brand is a truthful compression of real behaviour, not a substitute for it" | Consistent with **[S-ST: §11.3]** "every public claim must be traceable to a record a member could inspect" | **ADOPT** — becomes Rule E-8 | **[P]**, supported by **[S-ST]** |
| **IP-3** | "National identity emerges from millions of locally meaningful contributions rather than one centrally imposed identity" | Consistent with **[S-C: H-26]** "the national layer supplies capability, not identity" and **[S-ST: §12.3]** "the connection must run through records and stories, not through hierarchy" | **ADOPT with a caveat** — see below | **[I]** for the mechanism; **[P]** for the adoption |
| **IP-4** | "People feel connected because they contributed together, not because they were told they belong" | Consistent with **[S-ST: §10.2]** — belonging is the second clause of the proposition and is produced by shared work | **ADOPT** | **[P]**, supported by **[S-ST]**, **[S-C: §19.1]** |
| **IP-5** | "Do not make India loyal to Sewak Sathi; make Sewak Sathi useful enough that people voluntarily keep returning" | Consistent with **[S-ST: §30.5]** "not by persuading them… the conclusion forms inside them without your help" and **[S-C: HM-9]** voluntary return as the primary measure | **ADOPT** — the strongest of the six | **[P]**, supported by **[S-ST]**, **[S-C]** |
| **IP-6** | "The strongest reputation comes from what people can independently verify, not from what the organisation says about itself" | Consistent with **[S-ST: §14.3 item 8]** "at least one independently verified impact claim — an external party confirming an outcome, not the organisation confirming its own" | **ADOPT** | **[P]**, supported by **[S-ST]** |

**[A] The caveat on IP-3, stated because the brief requires evaluation rather than assumption.** Emergent identity is *desirable* and *plausible*, but three conditions must hold and none is automatic:

| Condition | Why it is not automatic | Instrument |
|---|---|---|
| **Local contributions must be visible beyond the locality** | A lane fixed in Moradabad is emotionally real in Moradabad and invisible in Madurai | **[S-ST: §12.3 item 2]** two-way flow: local achievement published nationally; **E-10** locality attribution on published outcomes |
| **The common element must be recognisable across localities** | If every local expression differs, a reader in another state sees unrelated acts, not one organisation | The eight immutable items; **one category sentence, identical in meaning across languages** **[S-ST: §18.3 item 1]** |
| **The centre must not become the hero of the local story** | Publishing local achievement nationally is one step from claiming credit for it | **E-34** attribution grammar: the beneficiary is the subject of the outcome sentence; the local contributor is the subject of the action sentence; **the organisation is the subject of neither** |

**[P] Rule E-8 (Truthful Compression).** Every public artefact — sentence, page, poster, post, report, statement — must be a compression of records that exist and can be inspected. **A statement that cannot be traced to a record may not be published, however true it may be.** **[A]** This rule is stricter than truthfulness: it forbids *unverifiable truth*, because an unverifiable true claim is indistinguishable from a false one to the person hearing it, and the organisation's whole differentiation is verifiability **[S-ST: §19.2 claim 1]**.

## 2.5 What the identity philosophy prohibits

**[A]** Drawn from **[S-ST: §10.3]**'s seven prohibited emotions, extended to communication:

| Prohibited | In communication this looks like | Control |
|---|---|---|
| **Guilt** | "While you read this, someone nearby is going hungry" | **Rule E-9**; prescriptive *seva* phrasing prohibited **[S-C: §30.4 item 3]** |
| **Fear** | "Your neighbourhood is not safe"; urgency countdowns; threat imagery | **Rule E-9**; no fear marketing (brief §28) |
| **Shame** | Before/after imagery that displays poverty; "helpless" framing | **E-34** beneficiary dignity rules; **[S-C]** and **[S-A: A-19]** dignity rules |
| **Indebtedness** | "Thanks to our founder / our supporters / our leader" as a recurring frame | **[S-A: A-16 §15.4]**; **E-35** anti-cult controls |
| **Superiority** | "Unlike other NGOs…"; "more trusted than"; ranking against named bodies | **[S-ST: §19.2]**: superiority claims are *not defensible* and "manufacture enemies" |
| **Outrage** | Conflict framing, antagonist naming, mobilisation against a group | **E-06**; **[S-A: A-01 N1, N5, N9]** |
| **Dependency** | "Only we can…"; permanent-need framing; no exit described | **[S-ST: §10.3 item 7]** "a floor people stand on, not a wall they lean against"; **E-03** pathways with a stated end |

**[P] Rule E-9 (The Ten Prohibited Emotional Registers).** No organisational communication, ceremony, recognition, recruitment artefact, campaign, story or internal message may be designed to produce: **guilt, fear, shame, indebtedness, superiority, outrage, dependency, envy, urgency-without-basis, or admiration for a person rather than for work.** **[A]** The test is design intent, not incidental effect: a factual account of a flood may frighten a reader; a *designed* fright is prohibited.

## 2.6 The one-sentence philosophy

**[A]** Not a slogan — a design constraint. Everything in Parts 3–76 must be consistent with it:

> **[A]** **Sewak Sathi's national identity is the accumulated, published, locally-produced record of what it actually did — described plainly, in the language of the place it happened, at a scale no larger than the evidence supports.**

---

# PART 3 — EVERY-CITIZEN TEST

## 3.1 The test, correctly framed

**[A]** The brief is explicit: "do not interpret 'target every citizen' as every citizen must join." The question is:

> **Can every citizen find a legitimate relationship with Sewak Sathi if they want one?**

**[P] Rule E-10 (Relationship, Not Membership).** For each of the twenty-five citizen positions below, a **legitimate relationship** must exist that requires no membership, no verification, no fee and no data beyond what the purpose requires **[S-A: A-18]**. **Membership is one relationship among twenty-five, not the destination of the other twenty-four.**

**[A]** Two source constraints shape every row. **[S-C: H-02]**'s nine-level spectrum begins below membership: Observer and Community Participant are **levels, not failures to advance**. **[S-C: H-03]** prohibits recruitment at the moment of vulnerability — which means the beneficiary relationship in particular must have **no conversion pathway attached to it**.

## 3.2 The twenty-five relationships — positions 1 to 13

**[P]** Participation levels are cited from **[S-C: H-02]**: **L0 Observer · L1 Community Participant · L2 Contributor · L3 Volunteer · L4 Specialist · L5 Verified Member · L6 Coordinator · L7 Leader · L8 Builder.**

| # | Position | Why they might care | Legitimate value Sewak Sathi can provide | Participation level that fits | What they can contribute | Never pressured to | What could make them distrust it |
|---|---|---|---|---|---|---|---|
| **1** | **School student** | A cleaned park, a tuition class, a science help session in their lane | Safe, supervised, age-appropriate local activity; a record of participation | **L0–L1**, with guardian consent and the two-adult rule **[S-A: A-05/§16.3; S-C: H-27]** | Time, energy, honesty about what they saw | Join; give personal data; appear in any image; be counted in any target | Any adult alone with them; any form; any photo; being told they are "the future of the organisation" |
| **2** | **College student** | A verified record of real work near home they can show an employer | **Door 2 — PROOF**: dated, verified, externally checkable contribution record; portable credential **[S-C: H-09, H-10]** | **L2–L3**, optionally L4/L5 | Hours, skills, digital fluency, campus networks | Convert anyone; pay anything; adopt an ideology; treat it as an internship they were promised | Being told the record is "not that kind of record"; discovering the work was unpaid while the organisation charged a client |
| **3** | **Worker (wage / industrial / gig)** | Bounded contribution near home that does not collide with shifts; occasional paid work with a published formula | **Door 3 — LIVELIHOOD**, but only where **[S-B]** supports it: paid venture work at priority 1 with a published formula version **[S: Ch.19 step 13]** | **L1–L3**; L5 only if they choose | Practical skill, reliability, local knowledge | Attend anything on a workday; accept unpaid "volunteering" that displaces paid work; recruit | Earnings claims that do not match the month they got; a formula nobody can show them |
| **4** | **Professional** | Three hours of real pro-bono scope where the skill is actually used, remotely if possible | Advisory standing without command; a credential; scope, not meetings **[S-D: SP-4 "advises, never commands"; S-C: H-24 remote participation]** | **L4 Specialist** | Verification, review, design, legal/medical/financial judgement within their licence | Give professional advice as an organisational position; be named publicly; exceed their licence **[V]** | Being asked to sign something; their advice being quoted as the organisation's view |
| **5** | **Entrepreneur** | A venture inside rules they can read, with an approval tier and a customer pipeline | **Door 3 / Door 4 — BUILDING**: venture approval, templates, QA, closure rules **[S: Ch.17]** | **L4–L8** | Capital, market access, employment, supply chains | Buy a position; sponsor in exchange for influence; become a "partner" in name only | Discovering the service brand was used to sell; a sponsor's name on a service record |
| **6** | **Shopkeeper** | A trustworthy local partner; help in a crisis; visible goodwill that returns footfall | Local coordination; a documented, activity-scoped partnership **[S: Ch.29; S-A: partnership rule]** | **L1–L2**; partner, not member | Space, materials, local intelligence, small sponsorship | Endorse the organisation; display a mark that implies endorsement **[S-A: A-05 clause 5 separate branding]**; political adjacency near their shop | A photo of their shop used as "support" they never gave; being asked for money repeatedly |
| **7** | **Farmer** | Help with a real problem — water, school, animal health — on the agricultural calendar | Service on the seasonal calendar, not the financial week; voice-first and paper-first process **[S-ST: §12.2]** | **L0–L2** | Land knowledge, labour pooling, produce logistics **[V]** regulated markets | Join during a crisis; sign anything during a crisis; give land or produce records | A city process that cannot be used without a smartphone; a decline delivered late |
| **8** | **Homemaker** | A morning slot within walking distance, with other women, that ends when it says it ends | Time-bounded participation; family-inclusive rather than family-competing; recognition that is not a rank **[S-C: H-23]** | **L1–L3** | Organisation, care knowledge, local networks, consistency | Attend anything that conflicts with care responsibilities; be photographed with beneficiaries; recruit neighbours | Timing that ignores care work; a venue that is socially difficult to enter; being counted as "inactive" for pausing **[S-C: H-18]** |
| **9** | **Elder** | Purpose, company and **the use of accumulated judgement** | **Elder/Mentor standing**: teaches, verifies by witness, mediates, holds local memory, blesses new teams — **no command, no score** **[S-C: §6.10; S-D: Part 13]** | **L2–L4**, with standing available from L3 upward **[S-C: H-27]** | Witness, mediation, memory, local legitimacy | Use an app; hold a role with RBAC; be assessed; be ranked | Being told their experience is "not verified"; digital-only processes; being used as a photo prop |
| **10** | **Retired person** | Structured use of a lifetime of skill, on their own schedule | Specialist or mentor scope; **paused status without penalty** **[S-C: H-18]** | **L2–L4** | Teaching, review, governance patience, credibility | Full-time anything; travel; public speaking | Being asked to be a "face"; discovering the role is ceremonial |
| **11** | **Person with disability or accessibility needs** | Participation designed from the start, not adapted later | Accessible formats: voice, audio, large print, plain language, captioning, offline routes **[E-14; S-C: H-23, H-24]** | **Any level** — accessibility is not a level | Perspective that improves the design for everyone; skill; judgement | Disclose a condition; use a format that does not work for them; attend an inaccessible venue | An accessibility claim on a page that is not accessible; being asked to explain their needs repeatedly |
| **12** | **Remote participant** | Contribution from anywhere — translation, design, research, documentation, planning, technology, telephone follow-up | **Remote participation architecture** **[S-C: H-24]**; full L2→L8 progression without physical presence | **L2–L8** | Skills that are location-independent | Travel; attend locally; be told their contribution counts less | Never hearing what their work became on the ground (**[S-C: HM-7]** measured specifically for remote contributors) |
| **13** | **Skilled specialist** | Scope-limited, conflict-declared, credential-verified engagement where they advise and are not conscripted | SP-1…SP-6 progression with authority ceilings; a portable credential against a published standard **[S-D: Part 13, Part 16]** | **L4** | Verification, standards, assessment, teaching | Take line authority; be ranked against other specialists; certify without assessment | Being asked to command; credential inflation; discovering their certification was issued without assessment |

## 3.3 The twenty-five relationships — positions 14 to 25

| # | Position | Why they might care | Legitimate value | Level | What they can contribute | Never pressured to | What could make them distrust it |
|---|---|---|---|---|---|---|---|
| **14** | **Low-income participant** | Help that does not cost dignity; possibly paid work | Service without distinction **[S-A: A-05 clause 1]**; **need assessment uses urgency, vulnerability, resources, expected impact, safety risk and feasibility — never the person's record or membership** **[S: Ch.8 step 5; S-C: CR-1]** | **L0–L2** | Local knowledge, time when they have it, honesty | Join; donate; reciprocate; give testimony; appear in any image; be counted as a "beneficiary" in any public claim | Being asked to be grateful publicly; help that stops when they stop attending; a photo of them used to raise money |
| **15** | **High-income supporter** | Giving where the money is traceable and the outcome is reported | Published accounts with worker compensation shown separately **[S: Ch.18, Ch.19; S-ST: §14.2 Layer 3]**; outcome and follow-up reporting | **L1–L2**; donor relationship is **not** a participation level and confers nothing | Funds, networks, expertise, equipment | Influence any decision; be named as a patron; have their gift acknowledged in a service record; receive any preferential access | Discovering a donor's name changed an allocation; a fundraising pitch with an emotional appeal (Rule E-9); no published accounts |
| **16** | **Local business** | A documented partner; a customer pipeline; visible local goodwill | Activity-scoped partnership with written scope, brand-usage rules and termination rights **[S: Ch.29; S-A: partnership rule]** | **Partner**, not member | Services, premises, employment, sponsorship with disclosure | Endorse the whole organisation **[S: Ch.5 §4.4]**; buy leadership authority (brief §50); appear as a service provider in a service record | Their brand used to imply organisational endorsement; a competitor's advantage bought with money |
| **17** | **Customer** | Local work delivered by verified people, with quality checks and clear accounting | **Door 3**: AI-business delivery, QA, dispute route, published formula **[S: Ch.17]** | **Customer** — not a participant, not a member | Revenue that funds priority 1 | Join; donate; be recruited; be added to any list | Service quality differing from what was sold; being pitched membership at delivery; a service brand used to sell a venture **[S-ST: §17.2]** |
| **18** | **Volunteer (one-time)** | One hour, once, with no form, no documents, no account and no expectation of anything further | **A real task, a real result, a personal thank-you, and a record they can see if they want one** **[S-ST: §20.3 minute 4–5; S-C: H-06 paired first task]** | **L2 for one task** | An hour, a skill, presence | Return; join; give contact details beyond what the task needs; be photographed; be asked again | Being contacted repeatedly; discovering their hour was counted in a "volunteer total" used publicly |
| **19** | **Community beneficiary** | A problem that gets fixed, without humiliation | Service without distinction; **dignity as a floor** **[S-ST: §10.2]**; follow-up and outcome known **[S: Ch.15 step 10; S-C: HM-8]** | **L0** — and this is a complete relationship | Their account of the problem; consent or refusal for any record | **Anything.** **[S-C: H-22 beneficiary/recruitment separation; S-D: H-03]** — no recruitment at the moment of vulnerability, no conversion reward, no testimony extraction, no suffering used as marketing | Being photographed; being asked to be grateful; help conditional on attendance; their story told without them |
| **20** | **Mentor** | Passing on a skill and seeing it used | Elder/Mentor or SP-5 standing; teaching without command **[S-C: §6.10; S-D: SP-5]** | **L3–L5** | Time, judgement, standards, witness | Assess their own mentee's readiness **[S-D: Part 13 §13.6]**; be ranked; hold RBAC | Discovering their mentee was promoted on the strength of their word alone |
| **21** | **Creator / media participant** | Real local stories with real evidence, and a body that will correct itself on the record | Access to verified records, named local contributors (with consent), correction logs, and a documented media protocol (Part 29, Part 30) | **L1–L4**; or **media relationship**, not membership | Reach, craft, verification discipline, scrutiny | Become an advocate; suppress a critical finding; accept payment for favourable coverage (Part 29); disclose audience data | Being given access conditional on tone; discovering a story was staged; no correction when they got it wrong |
| **22** | **Technology contributor** | A platform where AI recommends and humans decide, and where the constraint is written down | Remote, scoped, credentialed contribution; the AI doctrine as a design constraint rather than a preference **[S: Ch.21; Const. Art.12]** | **L2–L4**, remote **[S-C: H-24]** | Code, security review, accessibility work, data design | Build anything that scores a person; deploy any model that decides; access data beyond scope **[S-A: A-17…A-20]** | Discovering their work was used to profile people; an AI feature shipped that Art.12 forbids |
| **23** | **Research / education contributor** | A rare dataset of verified local service outcomes, handled ethically | Aggregate, de-identified, consent-scoped data under a documented research protocol **[S-A: A-17…A-20]** **[V]** | **L4 Specialist** or **research relationship** | Method, evaluation, publication that tests the organisation rather than praising it | Individual-level data; identifiable beneficiary data; a favourable conclusion; exclusivity | Being refused the inconvenient data and given only the flattering data; a publication used in a funding pitch without the caveats |
| **24** | **Person who only wants to observe** | To know what it is, check whether a claim is true, and never be asked for anything | **A public record they can read without an account**: what was done, where, when, with what result, what it cost, and what went wrong (Part 22) | **L0 Observer — a complete and permanent position** | Scrutiny. **Which is the most valuable contribution on this list and the only one that costs the organisation nothing** | Register; subscribe; donate; attend; give any data; be tracked | A paywall, a login, a form, a newsletter prompt, a cookie banner before the information; discovering the public numbers do not match the local reality |
| **25** | **Person who actively dislikes the organisation** | To criticise it and be answered with facts rather than deleted | A published complaint route reaching outside the local unit; a correction log; **preserved legitimate criticism** (Part 52); non-retaliation **[S-D: Part 18]** | **L0** — and hostility is not a disqualification from any public information | The most useful audit the organisation will ever receive | Delete; block; dox; respond with a counter-allegation; classify criticism as an attack by default (Part 47) | Their criticism deleted; a personal reply from a leader; being named in an organisational statement |

## 3.4 Findings from the twenty-five

**[P]** Four findings, each with a consequence:

**Finding 1 — Twenty-one of the twenty-five relationships require no membership.** Only positions 3, 12, 13 and 20 plausibly lead to L5, and none requires it. **[A]** The architecture is therefore **already** consistent with "relevant to every kind of Indian who wants to participate" — but **only if L0 and L1 are published as complete positions rather than as pre-membership states.** **[S-C: §8.2]** already establishes this ("VERIFIED MEMBER (L5, no role): holds membership, takes tasks, is paid for venture work, votes nothing, manages nobody" — and the lower levels are levels, not failures). **Rule E-11: no organisational artefact may describe L0–L4 as "not yet" anything.**

**Finding 2 — Three relationships have no participation level at all and must not be given one: Customer, Donor/Supporter, Media/Research.** **[A]** Assigning them a level on the participation spectrum would imply progression, and progression implies conversion. **[P] Rule E-12:** commercial, funding, media and research relationships are **documented relationships governed by contract or protocol**, recorded separately from the participation spectrum, and **conferring no standing, no recognition and no progression.** **[S-ST: §17.2]**'s service/business firewall and **[S-C: MLM-1…MLM-7]** require exactly this separation.

**Finding 3 — Position 24 (the observer) and position 25 (the critic) are the two the architecture currently serves worst.** Neither has any provision in v1.2: there is no public record, no public page, no public complaint channel and no published correction log **[S-ST: §14.1, §20.3]**. **[A]** These are also the two positions that determine whether the other twenty-three believe anything. **They are the highest-priority gap in this instrument and are addressed in Part 22 and Part 52.**

**Finding 4 — Position 19 (the beneficiary) is the one relationship with an absolute prohibition attached.** **[S-C: H-22]** beneficiary/recruitment separation, **[S-C: H-03]** no recruitment at vulnerability, **[S-D: PF-9]** pilot failure condition. **[P] Rule E-13:** the beneficiary relationship has **no conversion pathway of any kind**, at any time, in any direction, by anyone. **A person who received help may later choose to contribute — through an entirely separate door, at a later time, initiated by them, with no reference to the help they received.** Any instrument that connects the two is prohibited, and any record that permits the connection to be inferred is a design defect.

## 3.5 The honest limit of the every-citizen test

**[A]** Stated because the brief forbids flattery:

1. **Not all twenty-five will engage.** **[S-C]**'s standing instruction prohibits invented adoption percentages; **no claim is made here about how many will.** The test is whether a legitimate relationship *exists*, not whether it is used.
2. **Several relationships require capacity the organisation does not have.** Positions 4, 13, 20, 22 and 23 require specialist engagement infrastructure; position 11 requires accessibility implementation; positions 24 and 25 require publication infrastructure. **All are `[P]` and none exists at CL-0.**
3. **Two relationships are structurally in tension with each other.** Position 15 (high-income supporter) wants recognition and position 14 (low-income participant) must never experience hierarchy. **[A]** The resolution is not balance but separation: **funding relationships are documented, disclosed in aggregate and confer nothing visible at the point of service.** A donor's name may appear in an accounts summary; it may never appear in a service record, a project page or a lane.
4. **Position 1 (school student) requires legal validation before any activity.** **[V]** Minor participation, guardian consent, the two-adult rule and safeguarding obligations are jurisdiction-specific and are governed by **[S-C: SA-1…SA-7]** and **[S-D: LV-17, LV-23]**. **This document proposes nothing in that domain.**

---

# PART 4 — PARTICIPATION AT NATIONAL SCALE

## 4.1 The spectrum, preserved and scaled

**[S-C: H-02]** — nine levels, preserved exactly: **Observer → Community Participant → Contributor → Volunteer → Specialist → Verified Member → Coordinator → Leader → Builder.** **[S-ST: §9.1]** proposed it; **[S-C]** adopted it; **v1.3-E does not alter it.**

**[A]** What changes at national scale is not the spectrum but **the proportion of the population that stays at each level, and the fact that staying is the design rather than the failure.**

**[P] Rule E-14 (Low-Level Participation Is A Complete Outcome).** National adoption is **not** measured by how many people reach L5. It is measured by whether people at L0–L2 receive real value and can act on it. **A national network in which 95% of everyone who has ever engaged sits permanently at L0–L2, receives verified help, contributes occasionally, and can check any claim, is a success by this rule** — provided the 5% who hold responsibility are sufficient to serve and govern them (**[S-D: Rule D-43]** expansion gate; Part 42).

**[A]** The converse is the failure the brief warns about: **a national membership drive that produces L5s faster than it produces verification, leadership and service capacity.** **[S-D: Part 42]** already prices this — `L_pos/K` positional scarcity, the trusted-people bottleneck, the `σ_max` control budget. **Membership growth beyond capacity is not growth; it is a queue.**

## 4.2 The four doors at national scale

**[S-C: §6]** — Door 1 PURPOSE, Door 2 PROOF, Door 3 LIVELIHOOD, Door 4 BUILDING. **[P]** Extended nationally, with the brief's six determinations per door.

| | **Door 1 — PURPOSE** | **Door 2 — PROOF** | **Door 3 — LIVELIHOOD** | **Door 4 — BUILDING** |
|---|---|---|---|---|
| **What is national** | The doctrine and the eight immutable items; the category sentence; the claim ladder | The credential standard; the contribution-record schema; the verification standard | The waterfall priority order; the venture approval framework; the published formula *version* | The standards library **[S-A: A-15 M2]**; the replication classification (Part 33); the expansion gates |
| **What is local** | Which problem matters here; the calendar; the language; the meeting form **[S-ST: §12.1]** | Which tasks generate evidence; who verifies; the local names for roles | What the local economy can buy **[S-ST: §12.1 item 8]**; the venture category | How the local unit is built; who leads it; what it partners with |
| **What is optional** | Everything beyond observing | Everything beyond one contribution | **Entirely** — no one is required to work | **Entirely** |
| **What requires verification** | Nothing | **Yes** — the record is only valuable if verified **[S: Ch.25 step 2; App. F]** | **Yes** — payment requires verified work **[S: Ch.18]** | **Yes** — Gate E and Gate R **[S-D: Part 3]** |
| **What requires revenue** | Nothing | Nothing | **Yes** — a customer, a venture and a margin | Nothing |
| **What can operate at ₹0** | All of it | All of it — the record is a by-product of work already being done | **Nothing.** **[S-B]**: there is no revenue line for service, governance or training | All of it |
| **What cannot operate at ₹0** | — | — | **Delivery, QA, payment, dispute handling, and the float** | — |

**[P] Rule E-15 (Door 3 Is Economically Conditional, Nationally and Locally).** Door 3 may not be advertised, implied, hinted at or made visible in any public artefact **except** where a specific, funded, approved venture exists in that specific locality with a specific customer pipeline. **[S-B: B-09]** requires the paid/voluntary boundary to be published; **[S-C: §46]** states the livelihood door separately and truthfully; **[S-ST: F-02]** is the "scheme" accusation that follows any earnings implication. **The national default is: Door 3 is closed until a local unit opens it, and the national communication says so.**

**[A]** This is the single most important rule in this Part, because Door 3 is the only door where an over-claim causes direct material harm. **A person who joins expecting income and receives none has not been disappointed; they have been defrauded of their time** — and in a low-income locality that is a real loss, and it is the mechanism by which a service organisation acquires an MLM reputation without ever paying a commission (Part 40).

## 4.3 National participation without membership — the nine pathways

**[P] Amendment E-03.** Each pathway is available to any person, requires no membership, no verification and no fee, and **confers no authority**.

| # | Pathway | Minimum required from the person | Minimum required from the organisation | Hidden-authority risk | Control |
|---|---|---|---|---|---|
| **NP-1** | **Report a local need** | What, where, optional contact — three fields **[S-ST: §20.3]** | Acknowledgement, reference number, stated response window, honest triage or decline | None | The report creates no obligation on the reporter and no authority in the organisation |
| **NP-2** | **Request help** | A stated need | Priority assessment on need criteria only — **never on the requester's record or membership** **[S: Ch.8 step 5; S-C: CR-1]** | None | **Rule E-13:** no conversion pathway |
| **NP-3** | **Provide expertise once** | A skill, a bounded time | A scoped task, a named recipient, a record if they want one | **Medium** — an expert advising can drift into deciding | **Rule E-16:** advice is recorded as advice; only a role-holder with recorded authority may decide **[S-D: SP-4; S: Ch.10]** |
| **NP-4** | **Volunteer once** | An hour | A real task alongside two existing members; a personal thank-you; an explicit "no obligation to do it again" **[S-C: H-06]** | None | The task is real work with a real outcome, not a demonstration |
| **NP-5** | **Donate or sponsor** | Funds, within lawful limits **[V]** | A receipt; aggregate disclosure; **no influence, no naming at point of service, no standing** | **High** — money seeking influence | **Rule E-12; E-17:** a donation confers nothing on any decision, allocation, recognition or appointment; disclosed in aggregate in published accounts |
| **NP-6** | **Support a specific project** | Time, materials or funds, scoped | A published project record with outcome and follow-up | Medium | Scope is written; the project record shows what the support produced, not who gave it |
| **NP-7** | **Buy a legitimate service** | Payment | Delivery to specification, QA, dispute route **[S: Ch.17]** | **High** — customer becomes patron | **Rule E-18:** a commercial relationship confers no standing in the service organisation; trading names are separate **[S-ST: §18.2]** |
| **NP-8** | **Learn** | Attention | Published material in their language, at an accessible level | None | No account, no tracking, no progression prompt |
| **NP-9** | **Observe and check** | Nothing | **A public, indexed, dated record of what was done, where, what it cost and what went wrong** | None — and this is the point | **Rule E-19:** the observation pathway may never be gated by registration, login, form or fee |

**[P] Rule E-16 (Advice Is Not Authority).** Any person may advise. Only a role-holder with recorded authority may decide, and the decision record names the decider, not the adviser **[S-A: A-15 M1]**. **[A]** This prevents the most common way an unaffiliated expert acquires shadow authority: by being listened to consistently and never being recorded.

**[P] Rule E-17 (Money Buys Nothing But A Receipt).** No donation, sponsorship, purchase or in-kind contribution confers: influence over any decision; priority in any allocation; recognition at the point of service; naming in any service or project record; standing in the participation spectrum; eligibility for any role; or access to any non-public information. **Aggregate disclosure in published accounts is the only return, and it is mandatory rather than optional.**

**[P] Rule E-18 (Commerce And Service Are Separately Named).** Venture trading names are distinct from the service identity, and **the service brand may never be used to endorse a commercial offering** **[S-ST: §18.2, §17.2]**. **[A]** The reverse is also prohibited: a commercial customer may not be presented as a service beneficiary, and a service outcome may not be presented as a commercial reference.

**[P] Rule E-19 (The Observation Pathway Is Ungated).** Anything published for public verification is available without registration, login, form, fee, app installation, consent prompt or tracking. **[A]** The reason is architectural rather than ideological: **a verification claim that requires an account to check is not a verification claim.** It is a marketing funnel with an evidence aesthetic.

## 4.4 What national scale does to participation

**[A]** Six structural changes, none of them a matter of volume:

| Change | Mechanism | Instrument |
|---|---|---|
| **Trust becomes indirect** | At mohalla scale, trust is person-to-person **[S-ST: §14.2 Layer 1]**. At national scale, most people will never meet a member | Layers 2–4: verifiable local presence, institutional transparency, structural trust. **Layer 1 remains the only layer that scales, and Layers 2–4 exist to protect it, never to replace it** |
| **The misclassification risk multiplies** | Eleven categories, four rated Severe **[S-ST: §18.2]**; each new locality brings a new first impression | One category sentence identical in meaning everywhere; a published "what we are not" list; segment-specific explanations |
| **Language becomes a hard gate** | **[S-C: §30.1]**: "a person who cannot read the invitation cannot accept it" — a *hard exclusion*, not a friction | Five language registers (Part 14); the localisation contract |
| **Free-riding and fraud become economical** | At 50 teams, an impostor is noticed. At 5,000, impersonation is a business | A public verification channel where anyone can confirm whether a person or group is genuinely associated, and in what role **[S-ST: §14.2 Layer 2]**; Part 53 |
| **Contribution becomes invisible to the contributor** | A person in one city cannot see what their hour produced in another | **[S-C: H-15]** attribution loop; **[S-C: HM-7]**; remote contributors measured specifically |
| **Governance becomes the binding constraint** | Every participant adds `H_gov`; every unit adds control burden | **[S-B: §25, §26]**; **[S-D: Rule D-43]**; Part 42 bottleneck principle |

**[P] Rule E-20 (National Scale Does Not Change The Unit).** Nothing in this Part alters what a mohalla team does, how it is formed, what it may decide or what it must record. **National scale changes what is *available to* the unit and what is *published about* the unit. It never changes the unit's obligations upward or its authority downward.** **[A]** This is the practical form of **[S-C: H-26]**'s "the national layer supplies capability, not identity" and is the guard against ML-1 level confusion **[S-D: Part 32]**.

---

# PART 5 — EMOTIONAL ARCHITECTURE

## 5.1 The rule that governs this Part

**[A]** The brief is unambiguous: "do not artificially manufacture these emotions. Design conditions that allow them to emerge naturally." **[P]** That distinction is made architectural by one rule.

**[P] Rule E-21 (Conditions, Not Messages).** Every stage of the emotional journey is specified as **a condition the organisation must create** and **a prohibited message the organisation must not send**. A stage is satisfied when the condition exists and is observable — **never when the message has been sent.** **[A]** Reason: a message can be sent at zero cost and produces a measurable short-run response and a catastrophic long-run one. **An organisation that discovers it can produce the feeling of impact by describing impact will stop producing impact, because the description is cheaper.** That is Goodhart's law applied to emotion, and the only defence is to forbid the message and require the condition.

## 5.2 The eight stages — conditions and prohibitions

**[P] Amendment E-04.**

| Stage | The feeling | **Condition that must exist** | Observable evidence of the condition | **Prohibited message** | Failure if the message substitutes |
|---|---|---|---|---|---|
| **1. I SEE** | Awareness that something nearby needs help | **A visible, dated local result** — a cleaned lane with a small dated board; a photograph wall of local work; a neighbour's remark **[S-ST: §20.3 minute 0–1]** | CI-11 verification-channel queries; HM-1 inbound contacts; unsolicited local questions | "India is broken"; "your neighbourhood is failing"; any problem-framing that precedes a result | Fear and guilt (Rule E-9); the organisation becomes a critic of the place it wants to serve |
| **2. I CAN HELP** | Belief that a legitimate route exists and that they are eligible for it | **Two ungated actions available at first contact: "report a need" and "help once"** — neither requiring joining **[S-ST: §20.3]**; NP-1…NP-9 | First-contact comprehension (CI-2); HM-4 first-participation completion | "Join us"; "become a member"; any form before any action | **The gate appears before the value.** Conversion-fatal **[S-ST: §20.3]** |
| **3. MY CONTRIBUTION MATTERS** | Belief that their specific act was useful | **A real task with a real outcome**, not a demonstration task; the person can say what they did (**[S-C: HM-6]**) | HM-5 contribution completion; HM-6 | "Every hour counts!"; aggregate gratitude; impact infographics | The person discovers the task was symbolic; **worse than no task** |
| **4. IT REACHED SOMEONE REAL** | Belief that the outcome is true | **The attribution loop closes**: the outcome is returned to the contributor, dated, specific, place-based, inside a stated window **[S-C: H-15; HM-7]** | HM-7 attribution received; HM-8 follow-up outcome known | A beneficiary photograph; a testimonial; a before/after collage | **Dignity violation** (E-34) and the substitution of imagery for evidence |
| **5. I WAS NOT ALONE** | Belief that others are doing this too | **A paired first task alongside two existing members** **[S-C: H-06]**; a published local record showing who else contributed; **names only with consent** | HM-3 belonging — can they name two people here? | A member count; a follower count; a map of India with dots | A number is not a companion. **Counts produce insignificance, not belonging** |
| **6. THIS IS MY COMMUNITY TOO** | Belonging without coercion | **Local ownership is real**: the neighbourhood decides what its problem is; the local language, calendar, meeting form and recognition ritual are local **[S-ST: §12.1 items 1–5, 9]**; **paused status carries no penalty [S-C: H-18]** | HM-3; HM-12 understanding that leaving is allowed; local problem-definition records | "Welcome to the family"; "you are one of us now"; any belonging assertion | **Belonging asserted is belonging demanded.** The moment it is said, it becomes conditional |
| **7. I WANT TO RETURN** | Voluntary repetition | **The first experience was worth repeating**: bounded time honoured, result visible, thanks personal, expectation explicitly absent **[S-ST: §20.3 minute 4–5]**; no follow-up pressure | **HM-9 — second contribution within the defined window, the primary measure [S-ST: §21.3]** | "Don't forget to come back"; reminder sequences; streak mechanics; guilt about absence | Manufactured return destroys voluntary return, and HM-9 stops measuring anything |
| **8. I CAN BUILD** | Belief that a longer contribution is possible and that it is optional | **Real scope exists**: a project, a specialist engagement, a training cohort, a venture, a leadership route — each with a stated ceiling and a stated exit **[S-C: H-11; S-D: SP-series, Part 10]** | HM-10 development taken up voluntarily; **[S-D: LM-14]** pipeline | "You're a natural leader"; "we see great things in you"; any destiny language | **Flattery is the recruitment mechanism of every cult and every pyramid** (Part 39, Part 40) |

## 5.3 The emotional hierarchy, and why nationalism is last

**[P]** The brief §207 proposes an order. **[A]** It is correct, and the reason it is correct is structural rather than sentimental:

```
DIGNITY  ->  CONTRIBUTION  ->  IMPACT  ->  BELONGING  ->
RESPONSIBILITY  ->  CAPABILITY  ->  HOPE  ->  NATIONAL CONNECTION
```

| Position | Why it sits there | What breaks if it is moved earlier |
|---|---|---|
| **DIGNITY first** | It is a **floor**, not an outcome. **[S-ST: §10.2]**: "Dignity as floor, not as slogan." Everything after it is conditional on it | If dignity is not first, every later stage can be produced by extraction — and **[S-C: HM-13]** makes dignity a **veto gate**, not a metric |
| **CONTRIBUTION second** | It is the only thing the person does. Belonging to a group that contributes feels different from belonging to a group | If belonging precedes contribution, the organisation becomes a club — and **[S-ST: §10.2]**: "companionship without contribution produces a club" |
| **IMPACT third** | Impact is what contribution produces, verified. It cannot precede the act | If impact is promised before contribution, it becomes a claim — and claims that fail produce betrayal |
| **BELONGING fourth** | Belonging emerges from having contributed together. It cannot be offered | If offered, it is conditional, and conditional belonging is compliance |
| **RESPONSIBILITY fifth** | Responsibility follows earned trust **[S: Ch.2 doctrine]** and is a *consequence* of belonging, not a price for it | If earlier, responsibility becomes an entry requirement — the gate-before-value failure again |
| **CAPABILITY sixth** | Capability is what responsibility develops | If earlier, the organisation promises development it cannot deliver (**[X]** training alone did not improve retention in one large volunteer sample, because training raises expectations the role must then meet **[V]**) |
| **HOPE seventh** | Hope is the reasonable expectation that the next contribution will also matter. It requires six prior stages to be reasonable | If earlier, hope is optimism, and optimism that is not earned becomes cynicism on schedule |
| **NATIONAL CONNECTION last** | **It is the only stage that cannot be produced locally, and the only one that must never be required.** **[S-C: H-26]**: the national layer supplies capability, not identity | **If first, the organisation is a nationalist movement with a service programme — which is the exact inversion of the architecture and the fastest route to the Severe misclassifications in [S-ST: §18.2]** |

**[P] Rule E-22 (National Connection Is Never Required And Never First).** No artefact, ceremony, onboarding step, story or recognition may require, assume, test or reward a feeling of national connection. **It may be reported when it occurs** — a person in Madurai reading about a lane in Moradabad and recognising the pattern — **and it may never be solicited.**

## 5.4 Does the core proposition work across India?

**[A]** **[S-ST: §10.2]** proposes: **"My help reached someone real — and I was not alone in it."** **[S-C: §3.4]** subjected it to eight failure modes **PM-1…PM-8**. **v1.3-E tests it across contexts.** It remains **`[P] — a hypothesis, not adopted language`** throughout.

| Context | Does it hold? | Why / why not | Adjustment |
|---|---|---|---|
| **Urban metro** | **Partially** | Anonymity means "I was not alone" is the *scarce* half and the valuable half; "reached someone real" is plausible but unverifiable in a city where nobody knows their neighbours | Belonging design carries it **[S-ST: §12.2]**; the attribution loop is decisive |
| **Small town** | **Yes, strongly** | Everyone knows everyone; verification is cheap and independence is expensive **[S-ST: §12.2]**; "reached someone real" is literally checkable by asking | **Risk:** recognition is "highly motivating and highly political" — apply **[S-ST: F-33]** and **[S-A: A-16 §15.4]** strictly |
| **Rural** | **Yes, with a language condition** | The proposition's clause structure is English **[S-C: §3.4 PM-8]**; direct translation may produce something flat or devotional | Fix the *meaning*, let each language supply its own words **[S-C: §30.4]** |
| **Youth (college)** | **Partially** | **[S-C: PM-6]**: the proposition promises nothing about skill, credential or livelihood — and for a job-seeker that is the actual reason | Door 2 must be stated **separately and truthfully**, not folded into the emotional line **[S-C: H-10]** |
| **Elders** | **Yes** | "Not alone" and "reached someone real" map directly onto witness, memory and local standing **[S-C: §6.10]** | No adjustment; the Elder/Mentor role *is* the proposition institutionalised |
| **Business participants** | **No — and it must not be used** | A customer is not making a contribution and does not want to feel accompanied; they want delivery, QA and clear accounting | **A separate, non-emotional proposition**: "local work delivered by verified people, with quality checks and clear accounting" **[S-ST: §20.2]** |
| **Beneficiaries** | **No — and it must never be used** | The proposition is written from the *contributor's* position. Directed at a beneficiary it becomes "you were reached", which is the saviour frame **[S-C: PM-1]** | **Rule E-13:** no emotional proposition is addressed to a beneficiary at all. What they receive is service, dignity and a follow-up |
| **Specialists / remote** | **Partially** | "Not alone" is hardest remotely; **[S-C: H-24]** notes remote contributors are the most productive and the most likely to leave silently | **HM-7 measured specifically for remote contributors**; a named local person tells them what their work became |
| **Low-income participants** | **Yes, conditionally** | "My help" presumes disposable capacity. For a person with none, the proposition excludes them from the *contributor* side | The *receiving* side must be equally dignified and equally un-propagandised: **"someone's help reached me, and it did not cost me anything I did not want to give"** |
| **High-income supporters** | **Yes, and it is the strongest fit** | Traceability is exactly what this group is denied elsewhere | Published accounts and outcome reporting; **no emotional appeal (Rule E-9)** |

**[P] Rule E-23 (One Proposition Does Not Serve Every Relationship).** The core emotional proposition is addressed to **contributors only**. Beneficiaries receive service and dignity. Customers receive specification and accounting. Donors receive accounts and outcomes. Officials receive documentation and boundaries. Media receive records and corrections. **[A]** An organisation that says the same emotional sentence to everyone is not being consistent; it is failing to notice that it is talking to six different kinds of person.

## 5.5 The ten national emotional failure modes

**[P] NEF-1…NEF-10** (brief §210), each with early warning, prevention, detection, response and residual risk.

| ID | Failure mode | Early warning | Prevention | Detection | Response | Residual risk |
|---|---|---|---|---|---|---|
| **NEF-1** | **Nationalism becomes exclusion** | "Real Indians…"; any us/them framing about communities or regions | Rule E-6 presence not claim; Rule E-22; **[S-A: A-01 N4, N5]** | Language audit of public artefacts; CI-3/CI-4 perceived-association measurements | Immediate withdrawal of the artefact; a published correction (E-20) | **Medium** — local speech is harder to audit than national speech |
| **NEF-2** | **Service becomes saviourism** | "We gave them…"; beneficiary imagery; gratitude framing | **E-34 attribution grammar**: the beneficiary is the subject of the outcome sentence; the contributor of the action sentence; **the organisation of neither** **[S-C: §17.4]** | Editor rejection log **[S: App. A §8.x]**; HM-13 dignity reported by beneficiaries separately | Content withdrawn; story re-told from the correct subject; training | **Medium** |
| **NEF-3** | **Belonging becomes conformity** | "One of us would…"; disagreement framed as disloyalty; dissent absent | Rule E-7 additive participation; **[S-A: A-16 test 3]** dissent route; **[S-D: T3 dissent test — a zero count is a warning]** | Annual dissent count; exit themes **[S-C: §21.4]** | Publish the dissent count; act on at least one dissent | **High** — conformity is comfortable and self-reinforcing |
| **NEF-4** | **Recognition becomes status addiction** | Ordinal recognition; "top volunteer"; leaderboards of individuals | **[S-C: H-08]** six instruments never collapsed; **[S-C: SR-2]** no ordinal numbering; **[S-D: Rule D-66]** recognition confers nothing | Any published individual ranking is a breach on its face | Withdraw; replace with absolute instruments | **Low** — the prohibition is explicit and cheap to check |
| **NEF-5** | **Growth becomes MLM** | Any reward for introducing a person; downline language; "build your team" | **Rule E-24** below; **[S-C: MLM-1…MLM-7; H-21]**; **[S-D: Rule D-118]** | Audit of every compensation and recognition formula for a participation term | Formula voided; published correction | **Low** — detectable from documents alone |
| **NEF-6** | **Leadership becomes personality cult** | Founder imagery; quotes as authority; one voice; personal dates observed | **[S-A: A-16 §15.4]**; **[S-D: CU-1…CU-10]**; **E-35** | Attribution test (T2); spokesperson distribution (CI-13); portrait audit | Withdraw; many spokespersons by domain and region | **Medium** — see **[S-D: ES.5]** |
| **NEF-7** | **Safety becomes militarisation** | Any garment, marking, formation, rank language or "hero" framing | **[S-A: A-06 V1…V8]** absolutely; **E-42** hero-language rule | Visual audit; incident review of any intervention (Part 47) | Immediate withdrawal; **VG-5**-class incident review **[S-D]** | **Low** — V1…V8 are explicit and enumerated |
| **NEF-8** | **Transparency becomes privacy violation** | Named beneficiaries in public reports; identifiable small cells; "full transparency" as a slogan | **[S-A: A-17…A-20]** classification; **small-cell suppression**; **[S-D: Rule D-108]** | Data-protection audit; any C3/C4 disclosure is a breach | Containment and notification per **[S-A: A-17 P5]** **[V]** | **Medium** — the pressure to be maximally transparent is real and grows with scrutiny |
| **NEF-9** | **National identity becomes political identity** | Any response to a political accusation that is itself political | **[S-A: A-01 N1…N9]**; Part 7; Part 47 attack protocol | Refusal log; language audit; CI-3 | **Evidence, never campaigning** — publish the log, the accounts, the refusals | **Medium** — the temptation to answer a political attack politically is strongest exactly when the attack is working |
| **NEF-10** | **Local autonomy becomes factionalism** | Local pages that contradict national records; local marks; local claims of superiority | **E-09** localisation contract: eight immutable items; **E-11** brand architecture; BR-n usage rules | Terminology consistency (CI-7); brand-usage audit | Version-control the local artefact under **[S-A: A-15 M2]**; correct publicly | **Medium** |

**[P] Rule E-24 (No Reward For Introduction, Ever).** No payment, recognition, credential, standing, priority, allocation or progression may be a function of the number of people a person has introduced, recruited, retained or converted. **[S-C: H-21]** anti-MLM compensation firewall; **[S-D: Rule D-118]**. **[A]** Extended here to **communication**: no campaign, referral programme, share incentive, "invite a friend" mechanic or ambassador scheme may exist in any form. **Referral must arise from "this was useful", never from "I get something if you join" (brief §151).**

## 5.6 What emotional architecture costs

**[A]** Almost nothing, and that is the finding. **Every condition in §5.2 is a by-product of work the organisation must already do**: a dated board at a finished site, a paired first task, a returned outcome, a published local record, an honoured time limit, a personal thank-you. **The prohibited messages are free to not send.**

**[P] Rule E-25 (Emotion Is Never A Budget Line).** No expenditure may be made for the purpose of producing an emotional response. **Money may be spent on service, verification, translation, accessibility, publication and correction — all of which produce emotion as a by-product if the work is real.** **[A]** The moment an organisation has an emotional-production budget, it has a propaganda budget, and **[S-B]**'s absence of any revenue line for governance or communication makes this rule economically necessary as well as ethically necessary.

---

# PART 6 — NATIONAL STORY

## 6.1 The ten questions, answered within the claim ceiling

**[P]** Each answer is bounded by **Rule E-1** and by **[S-ST: §19.2]**'s separation of defensible from non-defensible claims. **Every answer below is `[P] — draft for approval, not adopted language`, per [S-ST: §20.2]'s own status marker.**

| Question | Answer | Evidence class | Prohibited version |
|---|---|---|---|
| **Why does it exist?** | Because India's problems and India's capacity are both hyper-local, and no institution currently aggregates capable people at neighbourhood scale with records that let trust compound **[S-ST: §29 items 1, 4]** | **[A]** structural observation | "To transform India" |
| **What problem does it solve?** | Not willingness — India has abundant willingness. **Verifiable trust and continuity**: an institution that will help anyone, show its accounts, keep its records, and still be there in five years **[S-ST: §29 item 4]** | **[A]** | "Poverty" / "every local problem" — over-scope |
| **Why does it need to exist?** | Because existing bodies are trusted but opaque, or transparent but absent. **A verification and continuity layer over local goodwill** is the gap **[S-ST: §29 item 5]** | **[A]**; **complement, never replace [S-ST: §19.3]** | "Nothing else does this" — **[S-ST: §19.2]**: superiority claims are false and insulting |
| **What makes it different?** | **Four defensible claims only:** verified help that actually arrives with evidence; you can see where the money went; your contribution is recorded and portable; neighbourhood-scale with national capability **[S-ST: §19.2]** | **[S: Ch.8, Ch.15, Ch.18–19, App. F, Ch.22]** — the mechanisms exist | "Cheaper/faster than an agency"; "pays better than the market"; "more trusted than community bodies" — all three **explicitly not defensible** |
| **Why should anyone care?** | Because a lane that floods, a school that needs a Saturday teacher, an elderly neighbour who cannot reach a clinic and a shopkeeper who needs a website are all visible at two kilometres' range **[S-ST: §29 item 1]** | **[A]** | Any national-scale abstraction |
| **Why should anyone trust it?** | **It should not ask to be trusted. It should be checkable.** Published accounts, published outcomes, published corrections, published refusals, a public verification channel, a complaint route that reaches outside the local unit **[S-ST: §14.2, §14.3]** | **[S: Ch.18, Ch.19, Ch.27]** for the machinery; **publication is `[P]` and does not yet exist** | "Trust us"; "we are transparent" — **[S-ST: §18.3 item 6]**: never argue with a label, replace it with a fact |
| **Why should someone participate?** | One of four doors, and the honest answer differs by person (Part 3): purpose, proof, livelihood **where a funded venture exists**, or building **[S-C: §6]** | **[S-C]** | "Join and earn" unless a specific funded venture exists in that locality (Rule E-15) |
| **Why should someone return?** | Because the first experience was worth repeating: bounded time honoured, result visible, thanks personal, expectation explicitly absent **[S-ST: §20.3; S-C: HM-9]** | **[P]**, testable | Any retention mechanic — streaks, reminders, guilt (NEF-3, Rule E-9) |
| **Why should someone support it?** | Because the money is traceable to priority 1 — worker compensation — and the accounts are published with that line shown separately **[S: Ch.18, Ch.19; S-ST: §14.2 Layer 3]** | **[S]** for the waterfall; **publication is `[P]`** | Any emotional appeal; any urgency; any named beneficiary (Rule E-9, E-17) |
| **Why should someone build it?** | Because scope exists with a ceiling and an exit: a project, a specialist engagement, a training cohort, a venture, a leadership route **[S-C: H-11; S-D: SP-series]** | **[S-C]**, **[S-D]** | Destiny language; "you're a natural leader" (NEF-6) |

## 6.2 The claim-traceability rule

**[S-ST: §11.3, verbatim]** — "every public claim must be traceable to a record a member could inspect. This is Ch.15's anti-fake-impact discipline applied to national branding — and it is the only form of patriotic-adjacent pride that cannot become propaganda."

**[P] Rule E-26 (Claim Register).** Every public claim of national or multi-locality scope is entered in a **claim register** with: the exact wording; the record(s) that support it; the date and scope of those records; the claim class (Part 31 §31.2); the approver; and the review date at which the claim must be re-evidenced or withdrawn. **[A]** A claim that cannot be entered in the register cannot be published. **A claim whose evidence expires is withdrawn, not repeated.**

**[P] Rule E-27 (Facts, Not Adjectives).** National identity is built from **verifiable accumulation** — N neighbourhoods, N verified projects, N outcomes, N people trained, N rupees paid to workers, N incidents handled lawfully, N corrections published, N political approaches declined **[S-ST: §11.3]** — **published plainly, in local languages, without adjectives.** **[A]** The architecture already generates every one of these numbers. **The identity strategy is to publish them and let scale do the emotional work — and to publish nothing when the number is one.**

## 6.3 The story the organisation must be able to tell at CL-0

**[A]** At the concept stage there is no track record, so the only honest story is about **intent and method**. **[P]** Four sentences, each traceable:

| Sentence | Traceable to |
|---|---|
| "We are building neighbourhood teams that fix local problems, and we record everything so you can check us." | **[S: Ch.8, Ch.15, App. F]** — the mechanism is designed |
| "We have not done it yet. We are testing whether it works in one place first." | **[S-B: §40]**, **[S-C: §57]**, **[S-D: Part 41]** — one shared pilot, no technology |
| "We are not a political organisation, not a religious organisation, not a security agency, not a job portal and not a replacement for government." | **[S-ST: §18.3 item 2, §20.2]**; **[S-A: A-01, A-05, A-08]** — the boundaries are written |
| "When we get something wrong we will publish the correction." | **[P] — E-20. This is the sentence that costs the most and is worth the most, and at CL-0 it is a promise about the future, which must be labelled as such** |

**[A]** The fourth sentence is the only one that is not yet backed by a record, and it is therefore the only one that is a **commitment rather than a description**. **Rule E-28: a commitment about future behaviour may be published only if it is labelled a commitment, states the mechanism by which it will be honoured, and is reported against at the first available reporting date.**

## 6.4 What the national story is not

| Not | Because |
|---|---|
| A founder's story | **[S-A: A-16 §15.4]**: decisions announced in the organisation's name with the deciding role identified; individuals credited for work, not for the existence of the institution |
| A story about India | Rule E-6: presence, not claim |
| A story about scale | Rule E-4: the claim ceiling; at CL-0 the scale is one |
| A story about suffering | **E-34**: beneficiaries are never the proof; suffering is never the marketing |
| A story with a villain | Rule E-9: outrage is prohibited; **[S-ST: §19.3]** the posture is **complement and escalate**, never rival |
| A story that ends | The follow-up obligation **[S: Ch.15]** means every story has a "what happened next" — including "unchanged" and "worsened" |
| A story the centre tells | **E-34**: local problem → local people → local action → local outcome → national learning. **Headquarters is never the hero** (brief §112) |

---

# PART 7 — POLITICAL NEUTRALITY

## 7.1 What already binds

**[S-A: A-01 N1…N9]** — the Political Neutrality Code, adopted as a proposal and carried here unchanged:

| # | Prohibition **[S-A]** | Communication-specific consequence **[P]** |
|---|---|---|
| **N1** | No endorsement, support, opposition, praise or criticism of any party, candidate, coalition or partisan movement — by the organisation, any team, any role-holder in role, or any organisational channel. **Includes implicit endorsement: hosting, sharing a stage, photo adjacency used organisationally** | **Photo adjacency is a publication decision.** No organisational image may place the mark beside a political person, symbol or event |
| **N2** | No use of name, marks, **colours**, dress, documents, photographs, member lists, attendance records, distribution capacity, events, vehicles, premises, funds, payment channels or communication channels for any partisan purpose. "The strongest and most testable rule; audit can verify it from records alone" | **Every channel is in scope**: accounts, groups, pages, domains, mailing lists, noticeboards, vehicles, banners |
| **N3** | No organisational participation in political fundraising, campaigning, election work, poll activity, voter mobilisation, or crowd mobilisation capable of being read as political | **"Crowd mobilisation capable of being read as political"** constrains rallies, large gatherings and mass calls to action — including for service purposes, near elections |
| **N4** | No adoption of political symbols, slogans, flags, **colours**, insignia, gestures, songs, portraits or dress identifying the organisation with a party, ideology, caste, community or movement | **Directly binds Part 13** (visual identity) and **Part 12** (brand) — see the red-colour analysis |
| **N5** | No political content in organisational communications, training, dashboards, publications, ceremonies or recognition — **including content that is favourable** | Favourable political content is the most likely violation, because it does not feel like a violation |
| **N6** | No acceptance of money, materials, premises, media, transport, publicity or volunteers from a political actor where the offer carries partisan expectation. Refusals are logged | **Publicity and media offers are in scope** — a free full-page advertisement from a politically adjacent body is a prohibited acceptance |
| **N7** | No use of organisational data for any political purpose, by anyone, ever. **Breach is serious misconduct** | Binds Part 22, Part 53, Part 54 absolutely |
| **N8** | No screening of applicants, members, volunteers, beneficiaries, partners or customers by political belief, affiliation, voting intention or family political history. **Anti-loyalty-test guard** | Binds Part 3 (every-citizen test) and Part 19 (funnel): **no audience segmentation by political characteristic, ever, including for targeting a service message** |
| **N9** | No representation of the organisation, in any medium, as affiliated with, sponsored by, opposed to or in conversation with a political actor — **including by omission where omission would mislead**. Covers "why didn't you deny it?" situations | **Creates a positive duty to correct a false political association**, which is why silence is not always the right response (Part 47) |

**[S-A: A-02]** member political activity rules with tier restrictions; **[S-A: A-03 E1…E14]** election-period protocol including the emergency exception E9; **[S-A: A-04]** the civic/partisan boundary; **[S-A]** refusal workflow: approved refusal script in every operating language, written-reply template signed at National level, **approach register with a published annual count**, and a support duty where a member faces consequence for a logged refusal.

## 7.2 Extending neutrality from conduct to expression

**[P] Amendment E-06.** **[A]** N1…N9 govern *acts*. Public expression has four additional failure surfaces that acts do not:

| Surface | Mechanism | Control |
|---|---|---|
| **PN-1 Adjacency** | The organisation appears beside political content it did not choose — a shared stage, a retweet, a sponsor's logo, a hashtag, a venue, a guest | **Rule E-29:** no organisational artefact may include a third party's mark, name, image or content without a documented, activity-scoped written agreement **[S: Ch.5 §4.4]**; **photo adjacency used organisationally is prohibited by N1** |
| **PN-2 Timing** | A service distribution, announcement or campaign near an election is read as political regardless of intent | **[S-A: A-03 E1…E14]** election-period protocol, including the internal window and the emergency exception E9. **Rule E-30:** the election calendar governs the communication calendar, not the reverse |
| **PN-3 Vocabulary** | Ordinary words carry partisan load in specific states and periods — "vikas", "andolan", "rashtra", "sangathan", "suraksha", "mukti", colour names, numeric slogans | **Rule E-31:** a **per-jurisdiction terminology review** before any L1 or public-artefact publication, on the same basis **[S-A: A-06 V11]** applies to protection terminology and **[S-C: §30.2]** to L1 texts. **The register is per language and per state, and is versioned [S-A: A-15 M2]** |
| **PN-4 Silence** | Failing to deny a false association is itself a representation where omission misleads (**N9**) | **Rule E-32:** a false political association, once known to the organisation, must be corrected on the record within a stated window — **calmly, with facts, without counter-allegation** **[S: Ch.24 misinformation rule]** |

**[P] Rule E-33 (Neutrality Is Published, Not Declared).** **[S-A]**: "Publishing refusals is more credible than declaring neutrality." The published instruments are: the Political Neutrality Code itself; the annual approach-and-refusal count; the annual accounts; the correction log; and the "what we are not" list. **[A]** A declaration of neutrality is an adjective. **A refusal log is a record.**

## 7.3 Political attack — the communication response

**[P]** Full simulation at Part 47 and Part 48 SIM-04. The principle:

**Rule E-34 (Never Answer A Political Claim Politically).** The response to "Sewak Sathi is secretly aligned with X" is: the neutrality code; the refusal log with its annual count; the accounts showing no political money; the composition of authorised spokespersons; the published record of the specific allegation examined and what was found. **Not:** a counter-allegation, a supportive statement about any party, a mobilisation of members, a hashtag, or silence where silence misleads (**N9**, Rule E-32).

**[A]** The hardest case, stated honestly: **[I]** if the allegation is *true in pattern* — a local team that is compositionally skewed, or that has repeatedly hosted one party's representatives — the correct response is not communication at all. It is the composition and partnership review **[S-A: A-05 clause 4, 5]**, a published correction, and a structural change. **Rule E-35: where an allegation is substantially true, the response is repair, not messaging (brief §169: repair reality before repairing reputation).**

---

# PART 8 — RELIGIOUS NEUTRALITY

## 8.1 What already binds

**[S-A: A-05]** — the Equal Treatment & Non-Alignment Principle, eight clauses, carried unchanged. The communication-relevant ones:

| Clause **[S-A: A-05]** | Communication consequence **[P]** |
|---|---|
| **2. Institutional non-alignment** — not affiliated with, an instrument of, or identified with any religion, caste, ethnicity, linguistic group, region or social group; **no theological, caste, ethnic or regional position, and expresses none** | The organisation may never speak in a theological register, in either direction — including to deny a theological claim in theological terms |
| **3. Cultural respect without alignment** — works within local culture, language, calendar, food practice, dress norm and social custom **"as matters of practical effectiveness and courtesy, not as endorsement of any belief system"** | Scheduling around a festival is courtesy; describing the festival as *our* festival is alignment |
| **5. Faith-based partners are activity-scoped** — **separate branding**, no religious content in the joint activity, no religious condition on receipt of help, **no proselytisation in either direction**, a written scope; never with a faith body *as a faith body* on matters of belief; **never exclusive where alternatives exist** | Joint artefacts carry both marks separately and describe only the activity |
| **6. No religious or caste framing in organisational expression** — not in communications, training, ceremonies, recognition, recruitment or public statements, **including favourable framing** | Favourable religious framing is the most likely violation and does not feel like one |
| **7. Symbols, names and dress carry no communal identification** — interlocks with A-06 | Binds Part 12, Part 13, Part 22 absolutely |
| **8. Language is not identity-ranking** — every operating language is equal in status for member-facing purposes | Binds Part 14. **Note [S-A: A-05]: "language architecture is outside this pack's scope" — v1.3-E Part 14 fills a gap v1.3-A explicitly named and deferred** |

**[S-A: A-05 guards]** — four limits on the neutrality principle itself: **not cultural erasure** (local expression is *required* for the organisation to belong anywhere); **not a ban on faith-motivated people** (a person may join because their faith commands service — "accepted individually, never invoked institutionally"); and two further guards against erasure and against a loyalty test.

**[S]** — social-impact funds may not support "political or religious activity" **[S: Ch.20]**; service is not restricted by religion **[S: Ch.2]**.

## 8.2 Extending neutrality to expression

**[P] Amendment E-07.**

| Surface | Mechanism | Control |
|---|---|---|
| **RN-1 Calendar** | A service calendar that clusters around one community's festivals is read as affiliation, whatever the intent **[S-ST: §18.2]** | **Rule E-36:** the local service calendar is **deliberately multi-festival and multi-season**, and its distribution is reviewed for pattern, not for any single decision **[S-A: A-05 clause 4]** |
| **RN-2 Venue** | Working only ever near one place of worship | Same rule: pattern review, not act review. **[A]** "A team that is 90% one community, or that only ever works near one place of worship, will be classified as that community's organisation **even if every individual decision was neutral**" **[S-A: A-05 §4.1]** |
| **RN-3 Ritual** | Any prayer, invocation, blessing, auspicious timing, sacred object or religious formula in an organisational activity | **Rule E-37:** **no religious ritual may be an organisational requirement, component or expectation in any activity, ceremony, meeting, launch, recognition or distribution.** A participant may pray; the organisation may not organise it. **[S-C: H-13]** six ritual tests apply to any proposed secular ritual |
| **RN-4 Language** | Devotional or karmic framing — "blessed to serve", "our duty before God", prescriptive *seva* | **Rule E-38:** *seva* and its equivalents may be used **descriptively** and only in a language where the term is native; **never prescriptively** ("a true sewak would…"), which **[S-C: §30.4 item 3]** identifies as the guilt mechanism that burns out good people |
| **RN-5 Imagery** | Religious architecture, dress, symbols or figures in any organisational image | Prohibited by **clause 6 and 7**; Editor rejection authority **[S: App. A §8.x]** |
| **RN-6 Food** | A distribution that serves only one community's food practice, or that excludes on dietary grounds | **Rule E-39:** food service respects local dietary practice as a matter of **courtesy and uptake**, offers a vegetarian option wherever feasible, and **never conditions receipt on dietary conformity** |
| **RN-7 Death, grief and disaster** | The moments when religious framing is most natural and most expected | **Rule E-40:** at a death, disaster or funeral, the organisation's role is **practical and referral-based**; religious observance is left entirely to the family and their community, and no organisational artefact marks it |

## 8.3 Religious attack — the communication response

**[P]** Full simulation at Part 47 and Part 48 SIM-05.

**Rule E-41 (Never Enter A Theological Argument).** The response to "Sewak Sathi belongs to religion X" is: the non-alignment clause; the composition and pattern review; the service calendar showing multi-festival distribution; the partnership register showing activity-scoped, separately-branded, non-exclusive cooperation with bodies of several traditions and of none; the accounts; and the statement that **service is determined by verified need and by nothing else** **[S-A: A-05 clause 1; S: Ch.8 step 5]**. **Not:** a theological rebuttal, a count of members by faith, a statement about any faith's merits, or a counter-accusation.

**[A]** The prohibition on counting members by faith is decisive and is not a soft preference. **[S-A: A-18]** prohibits collecting individual belief and caste at all; **[S-A: N5 ⟨new⟩]** leaves composition monitoring `UNRESOLVED — deliberately`, precisely because the choice is between "exclusion patterns invisible" and "an identity database is created". **[P] Rule E-42: the organisation may not produce a religious composition figure even to rebut a religious accusation.** The rebuttal is **behavioural** — where service went, when, on what criteria — never **demographic**.

**[A]** This is a real cost and is recorded: **[I]** an organisation that cannot say "look at who we are" is limited to saying "look at what we did". **In a communal accusation, the second answer is slower and less emotionally satisfying, and it is the only one that does not require building the instrument that would eventually be used against the people it was meant to protect.**

---

# PART 9 — CASTE NEUTRALITY

## 9.1 The structural problem

**[A]** Caste differs from religion and politics in one operationally decisive way: **it is largely invisible in a record and largely determinative of a pattern.** An organisation can publish its service calendar and refute a religious accusation. It cannot publish a caste composition without first collecting caste — and **[S-A: A-18]** prohibits collecting individual caste at all, while **[S-A: A-05 clause 4]** permits only aggregate, restricted review for *exclusion patterns*.

**[S-A: A-05 §4.1, verbatim]** — "A team that is 90% one community, or that only ever works near one place of worship, will be classified as that community's organisation **even if every individual decision was neutral.**"

**[I]** Applied to caste, this is sharper and harder. **[A]** In a mohalla, caste is often spatially organised: which lane is which, which well or hand-pump was historically usable by whom, which temple a procession passes, which households enter which courtyards. **A service organisation that is neutral in its rules and geographically naive in its routing will reproduce the locality's caste map precisely, and will be read as having chosen it.**

## 9.2 What binds

| Instrument | Content | Source |
|---|---|---|
| **Non-discrimination in service** | Help is determined by verified need, urgency, vulnerability, resources, expected impact, safety risk and feasibility — **never** by caste, and never by membership or record | **[S: Ch.2, Ch.8 step 5]**; **[S-A: A-05 clause 1]**; **[S-C: CR-1]** |
| **Institutional non-alignment** | No caste position, expressed or implied; not identified with any caste | **[S-A: A-05 clause 2]** |
| **No individual caste data** | Individual caste and belief are **not collected at all** | **[S-A: A-18]** |
| **Composition monitoring — deliberately unresolved** | Whether to monitor aggregate composition at all is `UNRESOLVED — deliberately`: "exclusion patterns invisible **or** an identity database is created. Aggregate, optional, self-declared, restricted, purpose-limited — or not at all" | **[S-A: N5 ⟨new⟩]** — **carried forward unresolved; Part 62, Annexure B** |
| **No screening** | No screening of applicants, members, volunteers, beneficiaries, partners or customers by caste or by any belief or identity characteristic | **[S-A: A-01 N8]**; **[S-A: A-18]** |
| **Symbols, names and dress carry no communal identification** | Includes caste-associated marks, surnames in organisational naming, and caste-coded colours or motifs | **[S-A: A-05 clause 7; A-06]** |
| **Language is not identity-ranking** | No dialect or register treated as superior; role *functions* fixed, role *words* local | **[S-A: A-05 clause 8]**; **[S-ST: §12.1 localisable item 10]** |

## 9.3 Extending neutrality to expression and to routing

**[P] Amendment E-08.** Six surfaces, none of which appears in a rule book and all of which determine who is served:

| Surface | Mechanism | Control |
|---|---|---|
| **CN-1 Geographic routing** | Which lane is served first, which is served at all | **Rule E-43:** service routing is recorded by **location and need criteria only**, and the distribution is reviewed for pattern at City level in aggregate. **A pattern that mirrors a known settlement division is a governance finding, not a routing preference** |
| **CN-2 Meeting venue and timing** | A venue one group will not enter, or a time one group cannot attend, excludes without any rule excluding | **Rule E-44:** venue and timing are **localisable items** **[S-ST: §12.1 item 5]** and their selection is reviewed against who actually attends. **[S-ST: §12.1]**: "women's participation depends almost entirely on timing and venue" — the same mechanism operates for caste |
| **CN-3 Naming and surnames** | Organisational use of surnames, honorifics or place-names with caste referents; role titles that import a caste-coded occupation | **Rule E-45:** organisational artefacts refer to people by **given name and role**, never by surname-derived honorific; **role functions are fixed, role words are local — but a local word with a caste referent is refused and the terminology register records the refusal** (Part 14) |
| **CN-4 Food and shared space** | Commensality is the sharpest caste boundary in daily Indian life | **Rule E-46:** where the organisation serves food, it is served to all present without distinction, prepared to a published hygiene standard, and **no organisational activity may be structured so that one group is served by or apart from another** |
| **CN-5 Recognition and visibility** | Who is photographed, who is named, who is invited as a guest of honour, who speaks at an event | **[S-ST: §12.1 item 4]**: a local guest of honour attends **"as a guest, never as a patron"**; **[S-A: A-16 §15.4]**: ceremonies honour **contribution and the neighbourhood**, never a person's position. **Rule E-47:** recognition artefacts are reviewed for who appears, in aggregate |
| **CN-6 Leadership composition** | Who is selected, by whom, from which lanes | **[S-D: Part 35]** anti-favouritism; **[S-D: Rule D-79]** aggregate distribution of *functions* with small-cell suppression, no protected-characteristic inference, no individual profiling. **v1.3-E adds nothing to that mechanism and does not weaken it** |

**[P] Rule E-48 (No Caste Data To Prove Caste Neutrality).** The organisation may not collect, infer, purchase, estimate or publish caste data about members, beneficiaries, partners or leadership **for the purpose of demonstrating diversity or rebutting an accusation.** **[A]** The instrument that would prove neutrality is the instrument that would eventually be used to sort people, and **[S-A: N5]** leaves even *aggregate optional self-declared* monitoring deliberately unresolved. **v1.3-E does not resolve it.** Where an exclusion pattern must be examined, it is examined through **behavioural aggregates that already exist** — routing, venue, timing, attendance, recognition, function distribution — none of which requires an identity field.

## 9.4 Caste accusation — the communication response

**[P]** Full simulation at Part 47. **Rule E-49:** the response to "Sewak Sathi is a caste organisation" is behavioural and record-based: where service went; on what criteria; who was served and who was not, by location; who attended and at what venue and time; who was recognised; the non-alignment clause; the no-screening rule; and the statement that **no caste data is held, because collecting it is prohibited.** **Not:** a composition figure, a counter-accusation, a named individual's identity, or a denial that refuses to examine the pattern.

**[A]** The honest limit: **[I]** in a locality where caste determines residence, a genuinely neutral routing record will *still* look skewed, because the need is skewed. **The correct answer is not to re-route for appearance; it is to publish the need assessment criteria in advance** (**[S-ST: §14.2 Layer 3]**: "publish the rules before the results… when people know the rule in advance, an outcome they dislike is a disappointment; when they learn the rule afterwards, it is a conspiracy").

---

# PART 10 — REGIONAL IDENTITY

## 10.1 The localisation contract

**[S-ST: §12.1]**, carried forward as **E-09** and reproduced because it is the single most important table in this Part.

**IMMUTABLE — identical everywhere, word for word:**

| # | Item | Source |
|---|---|---|
| 1 | Core doctrine and the principle statements | **[S: Ch.2]** |
| 2 | The protection DO-NOTs and the intervention sequence | **[S: Ch.16; S-A: A-08]** |
| 3 | Financial priority order and segregation of duties | **[S: Ch.18]** |
| 4 | Membership verification gates for responsibility-bearing roles | **[S: Ch.12]** |
| 5 | AI doctrine: recommend only; prohibited decisions; human review and logs | **[S: Ch.21; Const. Art.12]** |
| 6 | Privacy, minimum-data and dignity-of-beneficiary rules | **[S: Ch.12, Ch.15, App. F; S-A: A-17…A-20]** |
| 7 | Political and religious non-alignment; non-discrimination in service | **[S: Ch.2; S-A: A-01, A-05]** |
| 8 | Evidence standards: what counts and what never counts | **[S: App. F]** |

**LOCALISABLE — must be local, and locally decided:**

| # | Item | Note |
|---|---|---|
| 1 | **Language and script** of every member-facing and public artefact | Part 14 |
| 2 | **Service mix** — which categories matter here | "a coastal village's priorities are not a metro colony's" |
| 3 | **Calendar** — festival-linked service, harvest, monsoon, exam seasons, local fairs | Rule E-36 multi-festival |
| 4 | **Recognition rituals** — how achievement is marked, what is honourable, who is invited | Guest, never patron **[S-ST: §12.1]**; **[S-C: H-13]** six tests |
| 5 | **Meeting form** — chai at a tea stall, a courtyard, a schoolroom, a hall, an evening after prayers; time of day | Timing and venue determine who can attend (CN-2) |
| 6 | **Partner set** — municipality, panchayat, school, PHC, hospital, NGO, faith-body *service* committees (activity-scoped, never doctrinal), CSR | Part 25 |
| 7 | **Dress and visual identity** — **no uniform**; local colour and motif within national mark rules | Part 13; **[S-A: A-06 V1…V8]** |
| 8 | **Venture categories** — what the local economy can actually buy | Rule E-15 |
| 9 | **Problem-definition authority** — the neighbourhood decides what its problem is; **the centre decides only how it may be verified** | The most important item on the list |
| 10 | **Names for roles** — the *function* is fixed, the *word* may be local | "'HR & Verification Manager' is a foreign phrase in most mohallas" **[S-ST: §12.1]** |

**[S-ST: §12.1 result]** — "**ONE CORE MISSION, MANY LOCAL EXPRESSIONS** — the immutable list is short enough to be memorised; the localisable list is long enough to feel like home."

**[P] Rule E-50 (Eight And Ten).** The eight immutable items are the entire national standard. **Anything not on the immutable list is local by default**, and a national instruction on a localisable item requires a recorded justification under the change-request route **[S-A: A-15 M3]**. **[A]** Inverting the default — national by default, local by exception — is how a federation becomes a head office.

## 10.2 Regional superiority — the four directions it runs

**[A]** The brief prohibits regional superiority. **[I]** It runs in four directions, and only the first is usually noticed:

| Direction | Mechanism | Control |
|---|---|---|
| **RS-1 Centre over periphery** | The first city's dialect, calendar, service mix and role vocabulary become the unmarked national default | Rule E-50; the terminology register is **per language and per state** (Rule E-31); locality attribution on every published outcome **[S-C: H-26 technology effect]** |
| **RS-2 Large state over small state** | Numbers determine voice; a state with 500 teams outvotes one with 5 | **Rule E-51:** no national decision is taken by unit count. Standards change through the versioned route with reasons recorded, not by aggregation **[S-A: A-15 M2/M3]** |
| **RS-3 Urban over rural** | Digital-first design, English-first documentation, quarterly cadences that ignore agricultural rhythm | Part 15 accessibility; Part 14 language; **[S-ST: §12.2]** rural row: "voice/IVR and paper-first processes; weekly payment cycles may not match agricultural income rhythms" |
| **RS-4 "Mainland" over Northeast, and Hindi-belt over non-Hindi-belt** | Hindi-first anything is read as imposition **[S-ST: §12.2 Northeast row]**; distinct legal and land regimes | **Rule E-52:** **state-level legal review is mandatory before any operation in a state with a distinct legal or land regime [V]**; Hindi-first national communication is prohibited by Rule E-53 |

**[P] Rule E-53 (No Language Is Senior).** **[S-C: §30.3]**, carried forward: "No internal document, ceremony or announcement is 'original' in one language with the others as translations of lesser standing. **The public voice of a locality is in that locality's language. National communication is multilingual or is not published.**" **[A]** The operational consequence is severe and is stated: **a national statement that cannot be published in every operating language is not published at all.** This will slow national communication. That is the intended effect.

## 10.3 Structural variance — not stereotypes

**[P]** The brief requires investigation of radically different environments "without using stereotypes; focus on structural differences." **[A]** **[S-ST: §12.2]** already provides a state-by-state table marked **[I — illustrative generalisations, each requiring local validation before use. These are hypotheses for field testing, not claims about any community.]** — and that marking is preserved here in full.

**[P] Rule E-54 (Structural Variables Only).** Local variation is planned against **structural variables**, which are observable and non-pejorative, never against **cultural characterisations**, which are neither:

| Structural variable | What it determines | Example consequence |
|---|---|---|
| **Population density and settlement pattern** | Verification cost; independence cost; whether cross-team review is feasible | "Dense kinship networks mean verification is easy and *independence* is hard" **[S-ST: §12.2]** |
| **Literacy and device access** | Whether a digital route is primary or fallback | Rural: "voice/IVR and paper-first processes"; **[X]** rural–urban and gender digital divides persist |
| **Existing civil-society density** | Whether to enter as partner or as complement | "Enter as a partner and a complement, never as a rival" **[S-ST: §12.2]**; **[S-ST: §19.3]** |
| **Income rhythm** | Payment and participation cadence | Agricultural income rhythms vs weekly cycles **[S-ST: F-06]** |
| **Seasonal migration** | Whether paused status is a necessity | Rajasthan: "the *paused* status is not a nicety but a necessity" **[S-C: H-18]** |
| **Political saturation** | Neutrality-test intensity | "The neutrality code will be tested here first and hardest" **[S-ST: §12.2]** |
| **Distinct legal or land regime** | Whether state-level legal review is mandatory | Northeast India **[V]** |
| **Time scarcity of the able population** | Which participation levels carry the unit | Metros: "Specialist and Contributor tiers carry the city" **[S-ST: §9]** |
| **Civic literacy and scrutiny expectation** | How much to publish, and how early | "Expect scrutiny and demand for transparency; publish more, earlier" **[S-ST: §12.2]** |
| **Local economy's purchasing capacity** | Which venture categories exist; whether Door 3 can open at all | Rule E-15 |

**[A]** The full register is at **Part 34 (One India / Many Indias)**, which applies these ten variables to eleven environment types. **No state, community, region or group is characterised anywhere in this instrument.**

---

# PART 11 — LOCAL + NATIONAL IDENTITY

## 11.1 The layering rule

**[S-C: H-26]**, carried forward unchanged as **E-10**. **Five rules:**

| # | Rule **[S-C: H-26]** | Consequence for identity **[P]** |
|---|---|---|
| **1** | **Local primary and national derived** | The unit of belonging is the mohalla team. The national network is what supports it |
| **2** | **Nothing local is replaced by a national standard** | Rule E-50: eight immutable items, everything else local by default |
| **3** | **The national layer supplies capability, not identity** | Rule E-3. A specialist arriving, a float, a trainer, a verifier, a warehouse, an escalation route — **these are the national layer's products, and they are the only ones** |
| **4** | **No layer claims superiority** | Rule E-51, Rule E-52; **[S-D: Rule D-35]** no track superiority applies equally to levels |
| **5** | **National symbolism is service symbolism or nothing** | Part 13; **[S-A: A-06 V8]** the mark may appear on documents, banners at authorised service activities, digital channels and task-scoped identification — **and nowhere else** |

**Plus the six-layer sentence test [S-C: H-26]:** person → family → locality → city → state → India. **A person should be able to complete the sentence at each layer without any layer demanding the extinction of the one below it.**

**Plus the two-way flow [S-C: H-26]:** local achievement published nationally; national capability deployed locally. **Identity is produced by observable events — a specialist arriving, a local result published — not by claims.**

## 11.2 The risk the source itself names

**[S-C: H-26 field 9, verbatim]** — "'National capability deployed locally' becomes **central control wearing a helpful costume** — Mitigation: **[S: App. A §16.2]** central-standards doctrine; **[S-B: §20.3]** response times and refusal-with-alternative."

**[P] Rule E-55 (Capability, Not Direction).** When the national layer deploys locally, it deploys **a resource the locality requested or a standard the locality is bound by** — never a preference, a priority, a personnel decision or a message. Concretely, the national layer may send: a specialist, a trainer, a verifier, a float, a template, a translation, an escalation route, a correction. **It may not send: an instruction about which problem matters (immutable item 9 reserves that to the neighbourhood), a campaign, a talking point, a target, or a ranking.**

**[A]** The test is simple and is proposed for the annual report: **for every national intervention in a locality, can the locality point to the request that produced it, or to the immutable standard that required it?** If neither, the intervention was direction, and direction is what Rule E-55 prohibits.

## 11.3 How local connects to national

**[S-ST: §12.3]**, carried forward — "the connection must run through **records and stories, not through hierarchy**":

| # | Instrument **[S-ST]** | v1.3-E specification **[P]** |
|---|---|---|
| **1** | **One service record, held locally, verifiable nationally.** "A person's contribution in Madurai is legible in Moradabad. This is the single strongest national-binding instrument available and it is already implied by your data architecture **[S: Ch.22]**" | **Part 54** — contribution portability: portable evidence, verification, privacy, transfer, fraud prevention. **Never a social-credit score** |
| **2** | **Local achievement published nationally, national capability deployed locally** | Rule E-55; **E-34** attribution grammar so the centre is never the hero; locality attribution on every published outcome **[S-C: H-26]** |
| **3** | **An annual national assembly of local representatives** — "not a rally, a working assembly: standards review, published corrections, and the 'three things the ground told us' report. **Ritual plus governance**" | **Rule E-56:** the assembly is a **governance body for one purpose** — reviewing standards and publishing corrections — and satisfies **[S-D: Rule D-40]**'s body-justification test by stating the decision it makes and what happens if it is abolished. **It is not a communication event and may not be reported as one** |
| **4** | **National symbols that are empty of rank** — "a mark, a colour, a phrase, a shared date of service. Nothing wearable that suggests authority, nothing ordinal that suggests status" | Part 13; Part 55; **[S-A: A-06 V1…V8]**; **[S-C: SR-2]** no ordinal numbering |

## 11.4 The sentence test, applied

**[P]** The six-layer test as a design instrument. **A communication artefact passes if a reader at each layer can locate themselves without being asked to leave the layer below.**

| Layer | The sentence a person should be able to say | What the organisation must NOT require them to add |
|---|---|---|
| **Person** | "I did something useful on Saturday." | — |
| **Family** | "My family knows what I did and is not troubled by it." | Any conflict between participation and household responsibility (**[S-C: H-23]** family-inclusive, not family-competing) |
| **Locality** | "This is my lane's team; we fixed the drain." | Any subordination of the locality to a city or national identity |
| **City** | "My lane's team is one of several; a city reviewer can help when we are stuck." | Any competition with other lanes for standing |
| **State** | "Standards and specialists come from a level I will probably never meet, and they are useful." | Any loyalty to the state layer |
| **India** | "The same thing happens in other places, in other languages, and I can check that it is true." | **Any feeling of national belonging whatsoever.** Rule E-22: national connection is never required and never first |

**[A]** The last row is the finding of this Part. **[P] The strongest available national identity is *epistemic*, not *affective*: "the same thing happens elsewhere and it is checkable."** An affective national identity requires symbols, ritual, shared emotional experience and a centre — all four of which are prohibited or constrained by **[S-A: A-01 N4]**, **[S-A: A-05]**, **[S-A: A-06 V1…V8]**, **[S-A: A-16 §15.4]** and **[S-C: §8.4]**. **An epistemic national identity requires only records, publication and translation — all three of which the architecture already generates and none of which requires anyone to feel anything.**

**[P] Rule E-57 (Epistemic Before Affective).** National identity is built on **checkability** before **belonging**. Where a choice exists between making a reader *feel* part of something national and letting a reader *verify* that the same thing happens elsewhere, verification is chosen. **[A]** This rule is the practical resolution of the brief's §206 question, and it resolves it against the romantic answer: **identity that emerges from millions of local acts is real, but it emerges as recognition of a pattern, not as a feeling of oneness — and the pattern must be published for anyone to recognise it.**

---

# PART 12 — BRAND ARCHITECTURE

## 12.1 The three tiers, and the parent-subordination question

**[S]** The master chain is fixed: **KRYTOS → SEWAK SATHI SANSTHA → NATIONAL → STATE → CITY → MOHALLA → VERIFIED MEMBERS** **[S: Ch.4]**. **[S: Ch.4 authority table]**: CEO → organisation ownership = "Property, brand, strategy and ultimate founder-level control. Subject to law, contracts and approved governance." **[S: Ch.33]**: "Public name: Sewak Sathi Sanstha — Proposed/public name — use as public operating name while preserving Krytos parent context; validate name availability and registration."

**[A]** The brief asks whether Krytos should be made more important than the service organisation in public-facing contexts, and instructs that it should not be "unless justified." **[A] The justification test is who the audience is and what they need to know:**

| Audience | What they need | Correct presentation |
|---|---|---|
| **A resident asking for help** | Who is at the door, what they may do, how to check them, how to complain | **Sewak Sathi Sanstha + locality.** Krytos is irrelevant to the transaction and its presence imports a corporate frame into a service encounter |
| **A person considering contributing** | What the work is, what the record shows, what is expected of them | **Sewak Sathi Sanstha + locality** |
| **A customer buying a service** | Who is contracting, who is liable, what the QA and dispute route are | **Sewak Sathi Sanstha**, with the venture trading name separate (Rule E-18) |
| **A donor or funder** | Legal entity, governance, accounts, restrictions | **The legal entity, accurately named, with the Krytos relationship stated** — **[S-ST: §14.2 Layer 4]**: "legal entity clarity and honest status disclosure" |
| **A regulator, authority or court** | The legal person, its structure, its officers | **The legal entity only.** Entity structure is `UNRESOLVED` (LDR-U08 / **[S: Ch.33]**) and must be described accurately as such **[V]** |
| **A journalist** | Who is accountable | **The legal entity and the authorised spokesperson's role**, with the ownership structure stated plainly |
| **A partner organisation** | Who signs, who is bound, what may be co-branded | **The legal entity**, with the written agreement governing mark usage **[S: Ch.5 §4.4]** |

**[P] Rule E-58 (Parent Subordination In Service Contexts).** In any public-facing service, participation, recognition, story or help-seeking context, the operating name **Sewak Sathi Sanstha** and the **locality** appear; **Krytos does not appear.** In any legal, financial, contractual, regulatory, funding or accountability context, **the legal entity is named accurately and the ownership relationship is stated without euphemism.** **[A]** This is not concealment — **[S: Ch.33]** requires the Krytos parent context to be *preserved*, and Rule E-58 preserves it exactly where it is material. **It is a refusal to import a corporate owner into a neighbour's lane, where it would answer no question the neighbour has and would raise one they should not have to ask.**

**[P] Rule E-59 (No Concealment On Request).** Any person asking who owns or controls the organisation receives an accurate answer in plain language, in their language, immediately, from any role-holder. **The subordination in Rule E-58 is a sequencing decision about salience, never a withholding of fact.** **[A]** An ownership structure that can only survive not being asked about is not a governance structure.

## 12.2 The three-tier identity model

**[P] Amendment E-11.**

| Tier | Name | What it identifies | Where it appears | Where it never appears |
|---|---|---|---|---|
| **T1 MASTER** | **Sewak Sathi Sanstha** | The service organisation and its standards | Documents, the public record, digital channels, banners at authorised service activities, task-scoped identification **[S-A: A-06 V8]** | **Worn garments; vehicles used for crowd-facing activity; any object suggesting rank or authority [S-A: A-06 V8]** |
| **T2 PARENT** | **Krytos** | Ownership and the wider organisation context | Legal, financial, contractual, regulatory, funding and accountability contexts; the "about" record | Any service, participation, recognition or help-seeking artefact (Rule E-58) |
| **T3 LOCAL** | **Sewak Sathi Sanstha + locality name** — the mohalla, ward, village or city | The actual team a person will meet | **All first contact**; local pages; local records; local stories; locality attribution on every published outcome | Never alone in a legal or financial context, where the entity must be named |
| **T4 VENTURE** | Separate trading names for commercial offerings | The business pillar | Commercial contexts only | **Never alongside the service identity in a service artefact (Rule E-18; [S-ST: §18.2])** |

**[A]** T3 is the tier that does the work. **[S-ST: §12.1 item 10]** — "the *function* is fixed, the *word* may be local… this matters enormously" — and **[S-ST: §12.3 item 1]** — "a person's contribution in Madurai is legible in Moradabad" — together mean the local name must be **predictable in form and free in content**: the pattern is fixed ("Sewak Sathi Sanstha — [locality]"), the locality word is local, and **the local name is registered in the terminology register (Part 14) so that two teams cannot claim the same locality.**

## 12.3 Brand-usage rules

**[P] BR-1…BR-12.** Each is testable from records alone, which is what **[S-A: A-01 N2]** demands ("audit can verify it from records alone").

| # | Rule | Source / reason |
|---|---|---|
| **BR-1** | The mark may appear on **documents, banners at authorised service activities, digital channels and task-scoped identification** — and nowhere else | **[S-A: A-06 V8]** verbatim |
| **BR-2** | The mark may **not** appear on worn garments, on vehicles used for crowd-facing activity, or on any object suggesting rank or authority | **[S-A: A-06 V8]** |
| **BR-3** | No third party may use the mark without a **written, activity-scoped agreement** covering scope, data, finance, safeguarding, brand use and termination | **[S: Ch.29; S: App. A partnership MOU fields]** |
| **BR-4** | No partnership artefact may imply that a partner endorses the entire organisation unless the written agreement says so | **[S: Ch.5 §4.4]** verbatim |
| **BR-5** | Joint activities with a faith-based body carry **separate branding** and no religious content | **[S-A: A-05 clause 5]** |
| **BR-6** | The mark may not be used for any partisan purpose, and **colours** are within scope | **[S-A: A-01 N2, N4]** |
| **BR-7** | The mark may not be used to endorse a commercial offering; venture trading names are separate | Rule E-18; **[S-ST: §18.2]** |
| **BR-8** | The mark may not be modified, recoloured, combined with another mark, or placed in adjacency with a political, religious, military, police or security image | **[S-A: A-01 N4; A-06 V2]**; Part 13 |
| **BR-9** | Local teams have **no independent right to the name** until N12 is resolved; use is by recorded permission under the interim rule | **[S-A: N12 UNRESOLVED]** — "teams hold no documented right to the name" |
| **BR-10** | Every official account, domain and channel is registered to the organisation under **dual custody**, never to an individual | **[S-A: A-14 §13.4]** — "domain, payment gateway, communication channels, social accounts" under dual custody |
| **BR-11** | Any use of the mark by a person or body not holding recorded permission is an **impersonation incident**, routed to the public verification channel and, where appropriate, to legal process **[V]** | **[S-ST: §14.2 Layer 2]** public verification channel defends the brand against impostors |
| **BR-12** | **Brand ownership, licensing terms, use conditions and post-exit restrictions are `UNRESOLVED` (N12) and IP ownership is `UNRESOLVED` (N13). No rule in BR-1…BR-11 resolves them.** | **[S-A: §22]**; Rule 2 |

## 12.4 The ownership gap, stated plainly

**[A]** This is the largest defect in the brand architecture and it is not v1.3-E's to fix.

**[S-A: §22 N12]** — Brand ownership and licensing terms: **`UNRESOLVED`**. Risk: "teams hold no documented right to the name; exit and dissolution become chaotic." Action: "determine owner, licence terms, use conditions, post-exit restrictions." Owner: Founder/CEO + Legal. Dependency: IP. **Timing: before multi-city expansion.**

**[S-A: §22 N13]** — IP ownership of architecture, SOPs, curricula, software and data models: **`UNRESOLVED`**. Risk: "the institution's operating system could be withdrawn by a licensor." **Timing: before national expansion.**

**[S-A: I6]** — "Brand and IP ownership and licensing (N12, N13): **must be settled before many parties rely on the brand.**"
**[S-A: V8]** — IP counsel required for "brand ownership and licensing; ownership of architecture, SOPs, curricula, software and data models."

**[P] Rule E-60 (No National Brand Before N12 And N13).** No national-scale use of the name, mark or identity — and specifically no multi-city expansion under a common mark, no national domain, no national account portfolio, no national campaign and no national partnership programme — may proceed while N12 and N13 remain unresolved. **[A]** Reason: **[S-A: I6]**'s condition is precise — the questions must be settled **before many parties rely on the brand.** Every team that adopts the mark, every partner that co-brands and every member who lists the affiliation on a CV is a party relying on it. **Building national recognition first and settling ownership afterwards means settling it under conditions where refusal has already become expensive.**

**[A]** What *may* proceed at CL-0 without resolving N12/N13: **one team, in one locality, using the name locally under recorded permission (BR-9), with no national channel, no national campaign and no national partnership.** That is exactly the pilot **[S-B: §40]**, and it is why the pilot is not blocked by the ownership gap.

---

# PART 13 — VISUAL IDENTITY

## 13.1 The decisive source fact

**[S: Ch.1 Visual Legend and Information Colour System, verbatim]** — "**Colour is used as an information system, not decoration. Critical rules always appear as icon/label plus written text; no mandatory rule is communicated by icon alone.**"

| Colour | Meaning **[S]** | Typical use **[S]** |
|---|---|---|
| **Blue** | Organisation / hierarchy | Krytos → Sewak Sathi Sanstha → National → State → City → Mohalla → Members |
| **Teal** | People / HR / verification | Member lifecycle, vacancy, eligibility, training and conduct |
| **Green** | Social service / community | Service delivery, community network, impact and local autonomy |
| **Orange** | Business | AI business network, ventures, customers, QA and revenue |
| **Emerald** | Finance | Waterfall, weekly payment, reserves, social-impact fund and controls |
| **Red** | **Safety / protection / risk** | **Protection boundaries, incidents, prohibitions and risk register** |
| **Purple** | AI / data / software | AI governance, data architecture, platform modules and dashboards |
| **Slate** | Governance / audit | Council, CEO/National Team authority, audit and accountability |
| **Amber** | Warning / unresolved | Professional validation, unresolved decisions and proposed rules |

**[A] This is the finding that governs the entire Part: v1.2 has no brand palette. It has a nine-colour semantic system for internal documents, and red is already spoken for.** Red means *safety, protection, risk, prohibition and the risk register*. Green means *social service and community*. Every one of the nine colours carries a fixed internal meaning.

## 13.2 The red identity test

**[A]** The brief requires that red not be assumed correct, and that its cultural, political, safety, emergency, accessibility, readability and emotional associations be stress-tested.

| Test | Finding | Verdict on red as the dominant public identity colour |
|---|---|---|
| **Internal semantics** | Red already means **protection boundaries, incidents, prohibitions and the risk register** inside every v1.2 document **[S: Ch.1]** | **FATAL.** A red-dominant public identity would mean that the organisation's own colour for "this is prohibited" is also its colour for "this is us". Every internal document would carry the brand colour on its danger markers, and every public artefact would carry the danger colour as its identity |
| **Political association** | **[S-A: A-01 N4]** prohibits adopting political "**colours**" that identify the organisation with a party, ideology, caste, community or movement. Red is a live political colour in multiple Indian contexts, historically and presently, across more than one ideological family | **FATAL without jurisdiction-by-jurisdiction review.** `[V]` per state, and **[S-C: H-26 field 11]** already requires "**[V]** for any symbol, date or colour with political association per state" |
| **Safety / emergency association** | Red is the near-universal colour of emergency, ambulance, fire, hazard and stop. The organisation contains a **protection pillar** and **[S-A: A-06]** exists precisely because protection activity is misread as security activity | **ADVERSE.** A red-identified organisation that also intervenes in incidents will be read as an emergency or enforcement body — the **Severe** misclassification at **[S-ST: §18.2]** row 3 |
| **Military / police association** | **[S-A: A-06 V1, V2, V3]** prohibit uniforms, uniform-like garments, khaki/olive/high-visibility combinations, epaulettes, rank markings, tactical cut, badges, shields, crests, lanyards and outward-displayed ID | **ADVERSE.** Red plus any garment or marking is the shortest visual distance to a paramilitary reading, which V1…V3 exist to prevent |
| **Accessibility** | Red–green discrimination is the most common form of colour-vision deficiency **[X]**. The v1.2 system pairs **red = safety/prohibition** with **green = social service** — the two semantics most likely to appear adjacent on a service-and-safety document | **A REAL DEFECT IN THE EXISTING SYSTEM, partially mitigated.** The mitigation is the source's own rule: "no mandatory rule is communicated by icon alone" **[S: Ch.1]**. **Rule E-61 below extends it beyond mandatory rules** |
| **Readability / reproduction** | A mohalla team will reproduce the mark by hand: painted on a board, printed on a single-colour photocopier, stitched onto a table cloth, drawn in a school register | **Red reproduces poorly in one-colour and hand-painted form**, and shifts toward brown and orange at low fidelity |
| **Emotional effect** | Arousal, urgency, alarm, appetite, anger. **[S-ST: §10.3]** prohibits fear and outrage as mobilising fuels; Rule E-9 prohibits urgency-without-basis | **ADVERSE.** Red produces the exact affect the communication architecture prohibits |
| **Cultural association** | Red is auspicious, marital, sacred and celebratory in several Indian traditions, and mourning-adjacent in others | **NEUTRAL-TO-ADVERSE.** It is not available as a neutral colour; any use is read culturally somewhere, which collides with **[S-A: A-05 clause 6]** — no religious framing in organisational expression, including favourable framing |

**[P] Verdict: RED MAY NOT BE THE DOMINANT PUBLIC IDENTITY COLOUR.** Seven of eight tests are adverse or fatal, and the first is dispositive on its own: **the organisation cannot use as its identity the colour it uses for its prohibitions.**

**[P] Rule E-61 (Colour Semantics Are Reserved).** The nine information colours of **[S: Ch.1]** are **reserved to the information system** and may not be adopted as identity colours, in any combination, at any tier. **Corollary:** any colour adopted as an identity colour must be **outside** the nine, so that no public artefact can be misread as an internal semantic marker. **[A]** This rule closes the red question, the green question, the blue question and the saffron/orange question simultaneously, and it costs nothing.

**[P] Rule E-62 (No Colour-Only Meaning).** Extended from the source's own rule for mandatory information to **all** organisational communication: no meaning, status, urgency, prohibition, category or outcome may be conveyed by colour alone in any artefact, public or internal. **Colour is always accompanied by a word, an icon with a text label, or both.**

**[A]** What is **not** decided here: **which colour, if any, becomes an identity colour.** That requires per-state political review `[V]`, accessibility testing, one-colour reproduction testing and approval of the mark itself — and **the mark cannot be settled while N12 (brand ownership) is unresolved (Rule E-60).** **The palette question is therefore `UNRESOLVED — AND CORRECTLY SO`: it is downstream of an ownership decision this document may not make.**

## 13.3 The symbol system

**[P]** Brief §21 requires every symbol to answer six questions. **Rule E-63: a symbol that cannot answer all six may not be used.**

| Question | Test | Fails if |
|---|---|---|
| **What does it mean?** | The meaning is stated in words, in every operating language, and is registered in the terminology register (Part 14) | The meaning requires explanation by someone present |
| **Who can use it?** | A named permission class, recorded — consistent with BR-1…BR-12 | Anyone may use it |
| **Does it imply authority?** | **It must not.** No symbol may suggest the wearer or holder may command, inspect, detain, enter, verify or decide | It implies any of these |
| **Can it be misused?** | Enumerate the misuse and state the control. Impersonation is answered by the public verification channel **[S-ST: §14.2 Layer 2]** and BR-11 | Misuse is unimaginable to the designer |
| **Can it create hierarchy?** | No ordinal, no rank, no tier, no senior/junior form, no decoration **[S-C: SR-2; S-D: Rule D-66]** | Any variant exists that denotes standing |
| **Can it be mistaken for government authority?** | Not resembling any state emblem, police marking, municipal insignia, military badge, court symbol or official seal. **Use of national symbols is regulated [V]** | Any resemblance whatsoever |

**[P] Rule E-64 (No Symbol Grants Authority By Appearance).** Authority comes only from a recorded role or delegation **[S: Ch.10, Ch.22; S-D: Rule D-41 no shadow authority]**. **A person displaying any organisational mark has, by that display, no authority of any kind** — and the mark must be designed so that it cannot suggest otherwise.

**[A]** The consequence for design is restrictive and is stated plainly: **the permissible symbol is one that denotes an activity, never a person, a rank, a power or a status.** **[S-ST: §12.3 item 4]** already fixes this: "national symbols that are empty of rank: a mark, a colour, a phrase, a shared date of service. Nothing wearable that suggests authority, nothing ordinal that suggests status."

## 13.4 Uniform, dress and identification

**[S-A: A-06 V1…V8]**, carried forward **unchanged and unweakened**:

| # | Rule **[S-A]** |
|---|---|
| **V1** | **No uniform.** No shirt, jacket, cap, armband, sash, belt, boot, vest or any garment issued or encouraged by the organisation that identifies members as a body in public |
| **V2** | **No uniform-like garments.** No khaki/olive/high-visibility-combination styling, no epaulettes, no rank-like markings, no tactical or paramilitary cut, nothing resembling police, military or private-security dress. "Adjacency is read as equivalence by observers and by cameras" |
| **V3** | **No insignia of authority.** No badges, shields, stars, stripes or crests worn on the body; no lanyards suggesting official status; **no ID displayed outward in public** |
| **V4** | **Identification is carried, not worn** — kept in a pocket or bag, shown only to a person who needs to verify a *role claim*, never displayed publicly, never worn, never used to gain compliance |
| **V5** | **Activity identification is task-scoped and removable** — for a specific authorised activity where visibility aids safety, a plain high-visibility vest or table banner bearing **only the organisation's name and the activity**, removed at the end of the task, conferring no authority, and **not worn while travelling to or from the activity** |
| **V6** | **No weapons, weapon-like objects or protective equipment suggesting force** — no lathi, baton, chain, pepper spray, knife, firearm, tactical torch, shield, helmet-with-visor or body armour in organisational capacity |
| **V7** | **PPE is task-specific and plainly functional** — gloves for cleaning, masks for sanitation, life jackets for water rescue, helmets for two-wheeler travel — and is **never styled, branded or worn as identity** |
| **V8** | **The organisational mark may appear on documents, banners at authorised service activities, digital channels and task-scoped identification (V5). It may not appear on worn garments, on vehicles used for crowd-facing activity, or on any object suggesting rank or authority** |

**[P] Rule E-65 (The Four Permitted Surfaces).** V8 is exhaustive. **Documents, authorised-activity banners, digital channels, task-scoped removable identification.** Every proposed visual artefact in this document is tested against that list, and **nothing wearable, nothing vehicle-mounted for crowd-facing use, and nothing suggesting rank is permitted at any tier, at any stage, for any reason.**

## 13.5 The ID card — a source launch blocker

**[S: App. A blocker list]** — "**Branding | Non-police ID card design | Proposed | Communications + Legal**" with the deliverable "**Approved card mock-up**". **[S: Ch.31]** — "Communication / branding: **ID card**, public statement rules, misinformation correction → approved card mock-up and comms policy → **Blocker**." **[S: Ch.33]** — "QR ID card" listed among carried `PROPOSED` items; **[S-A: A-17 §16.4 and A-20]** add use restrictions to the already-approved QR concept.

**[A]** So the source simultaneously (i) makes an ID card a launch blocker, (ii) requires its design to be "non-police", (iii) proposes a QR element, and (iv) prohibits outward display of ID in public (**V3**) and requires identification to be carried, not worn (**V4**). **These are compatible, but only under a narrow design.**

**[P] Amendment E-12 (ID Card Specification Constraints).** The card must satisfy all of the following, and any design that fails one is refused:

| Constraint | Requirement | Source |
|---|---|---|
| **Carried, never worn or displayed** | No lanyard, clip, chain, pocket-square display or outward-facing holder | **[S-A: V3, V4]** |
| **Shown only to verify a role claim** | Never shown to gain compliance, priority, access to a person, or deference | **[S-A: V4]** |
| **No insignia of authority** | No badge shape, shield, star, stripe, crest, seal or epaulette-like element | **[S-A: V3]** |
| **Not resembling any state, police, municipal, military or security document** | Format, colour and layout must be visibly unlike an official credential | **[S: App. A "non-police"]; E-63 question 6 [V]** |
| **No colour reserved by the information system as identity** | Rule E-61 | **[S: Ch.1]** |
| **Minimum personal data** | Only what the verification purpose requires; **no caste, religion, political affiliation, health, family or beneficiary-status field** | **[S-A: A-18]** four-branch necessity test |
| **QR restricted** | The QR resolves to a **role-and-validity confirmation only** — never to a personal record, never to a beneficiary record, and **never scannable by the public at large** | **[S-A: A-17 §16.4; A-20]** use restrictions |
| **Revocable and recoverable** | Card validity is tied to the role record; **channel and credential access revocable, backup admin appointed, two-person recovery** | **[S: App. A §8.x Social Media Manager succession]**; **[S-A: A-14 §13.4]** |
| **Returned or invalidated on role change, same day** | Consistent with **[S-D: TA-b, TA-c, Rule D-102]** | **[S-D: Part 29]** |
| **Dual custody of the blank stock and the issuing function** | The person issuing is not the person verifying | **[S: Ch.18]** segregation principle applied |

**[A]** The card's real function, correctly understood, is **anti-impersonation**, not identification. **[S-ST: §14.2 Layer 2]** requires "a public verification channel (phone/WhatsApp/website) where anyone can confirm whether a person or a group is genuinely associated, and in what role." **A card that can only be checked by the person holding it is worth nothing; a role that can be checked by anyone who asks is worth everything.** The card exists to give the checker something to type in.

## 13.6 Logo, typography and reproduction

**[P]** Constraints, not designs. **No logo, mark, wordmark or typeface is specified here** — the mark cannot be settled while N12 is unresolved (Rule E-60), and a visual design is not an architectural object.

| Constraint | Requirement | Reason |
|---|---|---|
| **Reproducible by hand** | A member must be able to draw or paint it on a board with one brush and one colour, and have it recognised | A mohalla team will do exactly this; **[S-ST: §12.1 item 7]** permits local colour and motif within national mark rules |
| **Reproducible in one colour** | No gradient, no duotone, no dependency on hue | Photocopy, stencil, embroidery, stamp, hand-painting |
| **Legible at the smallest size it will actually appear** | Including as a favicon, a WhatsApp display image and a corner of an A5 notice | Digital channels are a permitted surface (V8) |
| **Script-independent** | The mark must not depend on Latin script; it must work alongside Devanagari, Bengali, Tamil, Telugu and other scripts used in operating languages | Rule E-53 no language is senior; Part 14 |
| **Name-legible without the mark** | **The words "Sewak Sathi Sanstha" plus the locality must be sufficient identification on their own** | If recognition depends on a graphic, the graphic is the brand — which inverts Rule E-8 |
| **No figurative human form in a heroic, elevated, muscular, uniformed or weapon-adjacent posture** | — | **[S-A: A-06 V2, V6]**; NEF-7 militarisation; NEF-2 saviourism |
| **No national symbol, flag, emblem, map outline or anthem reference** | — | Rule E-6; **[S-A: A-01 N4]**; `[V]` on regulated symbol use |
| **No religious symbol, motif, architecture or sacred object** | — | **[S-A: A-05 clauses 6, 7]** |
| **No animal or figure with a partisan, caste or regional referent in any operating state** | — | **[S-A: A-01 N4]**; `[V]` per state |
| **Testable for adjacency** | The mark must be tested beside a police badge, a party flag, a religious symbol and a corporate logo, and must not read as belonging to any of those families | E-63; **[S-A: A-06 V2]** "adjacency is read as equivalence" |

## 13.7 Signage, banners and physical presence

**[P]** Permitted under V5 and V8, bounded:

| Artefact | Permitted | Conditions |
|---|---|---|
| **Task-scoped activity banner or table banner** | **Yes** | Bears **only** the organisation's name and the activity; removed at the end of the task; confers no authority; not moved to another site as a standing installation **[S-A: V5]** |
| **Plain high-visibility vest for a specific authorised safety-relevant activity** | **Yes** | Task-scoped, removable, name and activity only, **not worn travelling to or from the activity**, never styled or branded as identity **[S-A: V5, V7]** |
| **Dated result board at a completed site** | **Yes, and recommended** | "A cleaned lane with a small dated board" is the **first stage of the emotional architecture** (Part 5 §5.2 stage 1). Bears the locality name, the date, what was done, and how to check or complain |
| **Permanent installation, plaque, monument, gate or painted wall** | **No, by default** | Creates a territorial claim, invites political and communal reading, and cannot be removed when the unit closes. **Any exception requires a recorded justification and a removal plan** |
| **Vehicle marking on a crowd-facing vehicle** | **No** | **[S-A: V8]** explicit |
| **Office or team premises signage** | **Yes** | Documents surface; name and locality only |
| **Worn garment of any kind** | **No** | **[S-A: V1, V2, V8]** |

**[A]** The dated result board is the most valuable visual artefact in this entire instrument and the cheapest. **It is simultaneously: the first-contact discovery mechanism (Part 16), the trust signal (Part 20 TS-series), the emotional condition for stage 1 (Part 5), the locality attribution that makes national identity epistemic rather than affective (Rule E-57), and the record a journalist can photograph and check (Part 30).** Nothing else in the visual architecture does five jobs at the price of a piece of painted ply.

---

# PART 14 — LANGUAGE ARCHITECTURE

## 14.1 What already exists, and the gap this Part fills

**[S-C: §30.2 / H-25]** — the three-layer model, carried forward unchanged:

| Layer | Content | Rule **[S-C]** |
|---|---|---|
| **L1 — Constitutional and legal** | Constitution, DO-NOT list, protection doctrine, privacy notice, compensation formula, consent text, exit rights, grievance route | "One authoritative text per language; every version legally reviewed; **no publication without review.**" **[S-A: H10]** already requires this for legally significant documents |
| **L2 — Operational** | SOPs, task descriptions, training material, forms, dashboards | Local language first; terminology register maintained per language |
| **L3 — Cultural and expressive** | Stories, invitations, recognition wording, event language, local naming | "**Fully local.** The organisation sets meaning, never phrasing" |

**[S-A: A-05 clause 8]** — "**Language is not identity-ranking.** Every operating language is equal in status for member-facing purposes… **language architecture is outside this pack's scope** but the principle is recorded here because linguistic exclusion is a form of the discrimination Article 2 forbids."

**[A]** v1.3-A named the gap and deferred it. v1.3-C built the three layers for the *human system*. **[P] v1.3-E supplies what neither did: the five registers, the mandatory-translation rule, the machine-translation control, and the cost rule.**

## 14.2 The five language registers

**[P] Amendment E-13 — LA-1 … LA-5.** Each register maps onto L1/L2/L3 and states where translation is **mandatory**.

| Register | Purpose | Maps to | Authoritative text | Translation mandatory? | Failure if wrong |
|---|---|---|---|---|---|
| **LA-1 GOVERNANCE & LEGAL** | Anything that creates, limits or removes a right, duty, payment, consent or liability: constitution, DO-NOT list, protection doctrine, privacy notice, compensation formula, consent text, exit rights, grievance and appeal routes, partnership agreements, brand-usage permission | **L1** | **One authoritative text per language; every version legally reviewed** **[S-C: §30.2]** | **YES — in every operating language, before publication, with legal review [V]** | A person consents to, is bound by, or is denied something they could not read. **This is the register where a translation error is a legal and safeguarding event, not a communication error** |
| **LA-2 OPERATIONAL** | SOPs, task descriptions, forms, training material, dashboards, role briefs, playbooks | **L2** | Local language first; terminology register per language | **By need** — translate what a role-holder in that language must use **[S-C: §30.5]** | A role-holder cannot perform a duty; a safety instruction is misunderstood |
| **LA-3 PUBLIC COMMUNICATION** | The category sentence, the "what we are not" list, published records and accounts, project outcomes, corrections, refusal log summaries, the public complaint route, media statements | **L1 for anything with legal effect; otherwise L3 in form, L1 in accuracy** | **Meaning fixed nationally; wording local** | **YES for the category sentence, the "what we are not" list, the complaint route and every correction. Otherwise by locality** | A person cannot check a claim, cannot complain, or is told something in a language they cannot read — **and the organisation has published a claim it cannot be held to** |
| **LA-4 LOCAL PARTICIPATION** | Invitations, stories, recognition wording, event language, local naming, meeting form, first-contact conversation | **L3** | **Fully local. The organisation sets meaning, never phrasing** **[S-C: §30.2]** | **No — and translating it is an error.** A nationally translated invitation is a foreign invitation | The organisation sounds like a head office; the message is grammatically correct and socially wrong |
| **LA-5 EMERGENCY** | Incident notification, safety instruction, evacuation or avoidance guidance, a service suspension, a data-breach notice to affected people, an urgent correction | **L1 in effect** | **Fast, factual, no speculation; sensitive statements require safety/legal/communications approval [S: Ch.24]** | **YES — immediately, in every language of the affected locality, and in an accessible format (Part 15) including voice** | **People are harmed because they could not read the warning.** This is the register with the shortest tolerance for delay and the highest cost of error |

**[P] Rule E-66 (The Mandatory-Translation Set).** Four things must exist in **every operating language of every locality where the organisation operates**, before it operates there: **(i)** the LA-1 rights and duties set; **(ii)** the category sentence and the "what we are not" list; **(iii)** the public complaint route and how to use it; **(iv)** the LA-5 emergency procedure. **[A]** Everything else may follow by need. **These four may not, because each is a precondition of the others being meaningful: a person who cannot read their rights cannot complain; a person who cannot read the complaint route cannot correct the organisation; a person who cannot read the warning cannot be safe.**

**[P] Rule E-67 (No National Publication Without Every Operating Language).** **[S-C: §30.3 rule 2]**: "National communication is multilingual or is not published." Operationalised: **a national statement is published simultaneously in every operating language, or it is not published at all.** Sequential publication — English today, others next week — establishes a senior language by procedure even where policy forbids it by rule.

## 14.3 The terminology register

**[P]** Extends **[S-C: §30.3 rule 3]** ("terminology is registered, not improvised") and **[S-A: A-06 V11]** (protection terminology review).

| Property | Requirement |
|---|---|
| **Scope** | Every term with an architectural meaning: member, verified, volunteer, contributor, specialist, coordinator, leader, beneficiary, partner, donor, customer, emergency, incident, protection, verification, credential, record, complaint, correction, refusal |
| **One meaning per term per language** | **[S-C: §30.1 item 3]**: "if 'member', 'verified', 'volunteer' and 'specialist' mean different things in different languages, §6's security boundary becomes unenforceable" |
| **Per state, not per language** | Rule E-31: a term's political load varies by state even within one language |
| **Versioned** | **[S-A: A-15 M2]**; changes through the change-request route **[M3]** with reasons recorded |
| **Reviewed before any L1/LA-1/LA-3/LA-5 publication** | **[S-C: §30.2]** "no publication without review" |
| **Records refusals as well as choices** | A local word rejected for a caste, partisan or communal referent (Rule E-45) is recorded with the reason, so the next team does not re-propose it |
| **Fixes meaning, never the word** | **[S-C: §30.4]**: *seva* and its equivalents — "fix the meaning, not the word… let each language supply its own word" |

**[A]** The register is the least glamorous instrument in this document and one of the two or three most load-bearing. **[I]** Terminology drift is the mechanism by which a national organisation discovers, three years in, that "volunteer" means an unpaid helper in one state and a probationary member in another — at which point the security boundary between L1 and L5 that the whole participation architecture depends on is unenforceable, and no single decision caused it.

## 14.4 Machine translation — the control chain

**[P]** Brief §25 requires: **AI translation → human review where necessary → publication**, and prohibits AI from silently changing policy meaning.

```
DRAFT (meaning fixed, wording local)
   |
   v
MACHINE TRANSLATION (drafting aid only)
   |
   v
REGISTER CHECK  -- every term against the terminology register (LA-1..LA-5)
   |
   v
HUMAN REVIEW    -- MANDATORY for LA-1, LA-3(legal), LA-5.
   |               Reviewer is a native speaker of the target language,
   |               is NOT the author, and is recorded by name and role.
   |               For LA-1: LEGAL REVIEW [V] in addition.
   v
MEANING DIFF    -- reviewer confirms: does this text create, limit or remove
   |               the same right, duty, payment, consent or liability as the
   |               authoritative text?  A "close enough" is a FAIL.
   v
APPROVAL + VERSION RECORD  -- [S-A: A-15 M2]
   |
   v
PUBLICATION (simultaneous across operating languages -- Rule E-67)
```

**[P] Rule E-68 (Machine Translation Never Publishes).** No machine-translated text may be published without recorded human review, and **for LA-1, LA-3-with-legal-effect and LA-5 the review is mandatory, named, and separate from the author.** **[S: Const. Art.12]** applies directly: AI may recommend; humans decide; AI "cannot autonomously make consequential… legal, safeguarding, safety… decisions" — and a translated consent text or safety instruction is exactly such a decision.

**[P] Rule E-69 (The Four Translation Error Classes).** Review is structured against the four classes the brief identifies, because they require different reviewers:

| Class | Example | Reviewer | Consequence if missed |
|---|---|---|---|
| **Meaning error** | A duty becomes a suggestion; "may" becomes "must"; a condition disappears | Native-speaker reviewer separate from the author | The person is bound by, or deprived of, something the text does not say |
| **Cultural error** | A register that is deferential in one language and servile in another; an idiom that imports a religious or caste referent | Local reviewer; terminology register | NEF-1, NEF-2; **[S-A: A-05 clause 6]** violation |
| **Legal error** | A consent, waiver, grievance right or disclosure obligation altered in translation | **Legal review [V]** | Unenforceable or unlawful text; **[S-A: H10]** breach |
| **Safety error** | A dosage, a load limit, a hazard word, an evacuation instruction, an age threshold, a "do not" | Safety function plus native-speaker reviewer | **Physical harm.** The lowest-tolerance class |

## 14.5 What language costs, and the economising rule

**[S-C: §30.5, verbatim]** — "the cost is real… **[S-B: HC-19]** already records translation as a hidden cost, and **[S-A: A-06/A-07]** require per-language review of protection and public-statement wording. **The economising rule: translate L1 fully and once; translate L2 by need; leave L3 to the locality, which does it for free and better.**"

**[P]** Extended to the five registers:

| Register | Cost rule |
|---|---|
| **LA-1** | **Translate fully, once, with legal review.** Expensive, non-deferrable, non-repeatable — the text changes rarely |
| **LA-2** | **Translate by need.** Only what a role-holder in that language must actually use |
| **LA-3** | **Translate the four mandatory items fully (Rule E-66); leave stories and invitations local** |
| **LA-4** | **Do not translate.** The locality produces it, for free, and better |
| **LA-5** | **Pre-position.** Emergency texts are translated **before** the emergency, per locality, because there is no time to translate during one |

**[A]** LA-5's pre-positioning rule is the one that will be skipped under budget pressure and the one that cannot be recovered afterwards. **[I]** An emergency instruction translated during an emergency is translated by whoever is available, under time pressure, without review — which is the exact set of conditions Rule E-68 exists to prevent. **Pre-positioned emergency text in every operating language is therefore a launch condition, not a scaling condition**, and is recorded as such in Part 74.

**[P] Rule E-70 (Language Is Not A Scaling Feature).** The mandatory set (Rule E-66) is required **before** a locality is served, not after. **[A]** Reason: **[S-C: §30.1 item 1]** — "a person who cannot read the invitation cannot accept it. Language is FR-11… and it is a *hard* exclusion rather than a friction." **A hard exclusion cannot be deferred to a later release.**

---

# PART 15 — ACCESSIBILITY

## 15.1 The rule that makes accessibility real

**[P] Amendment E-14. Rule E-71 (Accessibility Is Implemented Or Not Claimed).** No organisational artefact, page, document, statement, report or campaign may state or imply that the organisation is accessible **unless the specific capability is implemented and testable.** The brief's instruction — "do not make accessibility a marketing claim unless implemented" — is enforced as a claim-ladder rule: **accessibility is a CL-class claim and requires CL-class evidence (Part 31).**

**[A]** This rule is included first because accessibility claims are the most commonly false claim in Indian institutional communication, and because a false accessibility claim is uniquely damaging: **it is believed by exactly the people it excludes, who then arrive and are turned away.**

## 15.2 The five accessibility dimensions

| Dimension | Requirement | Applies to | Cost character |
|---|---|---|---|
| **AX-V Visual** | Text alternatives for every meaningful image; no meaning by colour alone (Rule E-62); contrast sufficient for low-vision reading; no information conveyed by hue, saturation or position alone; screen-reader-parseable structure; **large-print and braille routes for LA-1 and LA-5 texts on request** | All artefacts; **LA-1 and LA-5 mandatory** | Low for digital design discipline; moderate for physical formats |
| **AX-H Hearing** | Captions or transcripts for every audio and video artefact; **no audio-only channel for any LA-1, LA-3-mandatory or LA-5 content**; a text or voice-message alternative for every telephone route | All audio/video; telephone intake | Low; **and the text alternative is required anyway for low-literacy access** |
| **AX-C Cognitive** | Plain language; one idea per sentence in LA-3 and LA-5; **no jargon, no role titles, no process diagrams in first contact [S-ST: §20.3]**; consistent structure across artefacts; the eight first-contact questions answerable without inference (Part 16) | All public artefacts | **Low — and it improves comprehension for everyone** |
| **AX-L Literacy** | **Voice, audio, short video, icons with text labels, demonstration, and a human route** for every process a person must complete; **oral application and oral need-reporting recorded by a role-holder who is not the decision-maker [S-D: OB-2]**; no process whose only route is reading | Intake, application, complaint, consent, grievance, payment confirmation | **Moderate — requires a person, not a form** |
| **AX-D Digital** | **An offline route for every process, mandatory rather than fallback [S-D: OB-3]**; low-bandwidth and low-data pages; no app requirement; no smartphone requirement; works on a shared or borrowed device; **no account required for observation or verification (Rule E-19)** | Everything | **Low if designed in; prohibitive if retrofitted** |

**[X-inherited]** Rural–urban and gender digital divides persist, with a substantial share of rural women not owning a phone — already cited in **[S-D: OB-3]**. **[S-B: §40]**'s pilot runs with **no technology at all**, which proves every process is executable on paper. **[A] That is the strongest accessibility finding available: the architecture's own pilot design demonstrates that nothing in it requires a device.**

## 15.3 The accessibility floor

**[P] Rule E-72 (Every Process Has A Human Route).** For every process a member of the public must complete — report a need, request help, ask a question, check a claim, complain, appeal, consent, decline, give feedback, verify a role claim — **at least one route exists that requires no reading, no writing, no device, no account and no fee, and is completed with a person.**

**[A]** This rule is the operational form of the brief's §26 and §106. It is also the most expensive rule in this Part, because a human route costs a human's time — and **[S-B: §25]**'s `H_gov` is the currency it is paid in. **[P] The mitigation is that the human route is often the *cheaper* route at small scale:** at one team and a few hundred neighbours, answering a question at a tea stall costs less than building, translating, testing, maintaining and supporting a form. **The economics invert at scale, which is why Part 53 treats the digital route as a scaling instrument rather than as the default.**

## 15.4 What accessibility may never become

| Prohibited | Reason |
|---|---|
| **An accessibility claim in any artefact that is not itself accessible** | Rule E-71; the claim is falsified by the medium carrying it |
| **A separate "accessible version" published later** | Sequential publication establishes a hierarchy (Rule E-67 logic). **Accessible by default, or not at all** |
| **A requirement that a person disclose a condition to receive an accommodation** | **[S-A: A-18]** necessity test; **no health or disability field is required for any public process** |
| **Accessibility as a diversity statement** | It is an implementation state, not a value |
| **A disability-specific participation level or track** | Part 3 position 11: **any level**. A parallel track is a lesser track |
| **Assuming the person with the accessibility need is the beneficiary rather than the contributor** | Position 11's contribution is "perspective that improves the design for everyone" |

## 15.5 Testing

**[P]** Three tests, all executable on paper at pilot scale:

| Test | Method | Pass condition |
|---|---|---|
| **AX-T1 Read-aloud test** | A person who does not read the artefact's language fluently, or does not read at all, is asked to complete the process with only the human and voice routes available | The process completes without any written step |
| **AX-T2 One-colour reproduction test** | The artefact is reproduced in one colour on a monochrome photocopier and on a hand-painted board | All meaning survives; nothing depended on hue (Rule E-62) |
| **AX-T3 First-contact comprehension test** | The eight questions of Part 16 §16.2 are put to a person who has seen the artefact for ten seconds | **CI-2** — recorded as a measurement, never as a target |

---

# PART 16 — FIRST CONTACT

## 16.1 The eight-question national test

**[A]** The brief §29 specifies eight things a person must be able to determine on first encounter. **[S-ST: §20.1]** tested the current architecture against a five-question version and found it **fails 4 of 5**. **[P]** v1.3-E uses the brief's eight, because four of them are precisely the questions the current architecture's silence answers wrongly by default.

| # | Question | What the current architecture communicates **[A]** | What must exist |
|---|---|---|---|
| **1** | **What is it?** | "Partially. 'Sewak Sathi Sanstha' suggests service and companionship; it does not suggest business, verification or emergency support. A reasonable guess, an inaccurate one" **[S-ST: §20.1]** | **One category sentence, identical in meaning everywhere, in every operating language** **[S-ST: §18.3 item 1]** |
| **2** | **Why does it exist?** | "No. Nothing visible" **[S-ST: §20.1]** | The purpose in one non-abstract sentence, tied to a local problem |
| **3** | **What can I do?** | "No. The only visible action in the architecture is 'apply for membership'" **[S-ST: §20.1]** | **Two ungated actions: "report a need" and "help once" (NP-1, NP-4)** |
| **4** | **Whether they must join** | Not addressed anywhere | **An explicit "you do not have to join anything" statement at first contact** |
| **5** | **Whether it is political** | Not addressed; **Severe** misclassification risk **[S-ST: §18.2]** | The published Political Neutrality Code; the refusal log; the "what we are not" list |
| **6** | **Whether it is religious** | Not addressed; **Severe** risk | The non-alignment clause; the "what we are not" list |
| **7** | **Whether it is a security organisation** | Not addressed; **Severe** risk **[S-ST: F-09]** | A public "we are not a security force" statement; the DO-NOT list; authorities-first doctrine made public **[S-ST: §18.2]** |
| **8** | **Whether money is involved** | Not addressed; **High** "job portal / scheme" risk **[S-ST: F-02]** and "NGO that needs donations" risk | A one-line funding statement: what is free, what is paid, and that help is never conditional on either |

**[P] Rule E-73 (Questions 4 To 8 Are Answered At First Contact, Not On Request).** The five questions the architecture currently leaves silent are the five a suspicious person answers for themselves — and they answer them with the worst available category. **[A]** Silence at first contact is not neutrality; **it is an invitation to misclassify.**

## 16.2 The category sentence and the "what we are not" list

**[S-ST: §20.2]** — status: **`[P — draft for approval, not adopted language]`**. Reproduced with that status preserved exactly; **v1.3-E does not adopt it.**

> **Core sentence (all languages, identical meaning):** "Neighbourhood teams that fix local problems — verified, recorded, and paid fairly when the work earns."

> **The "what we are not" line, printed smaller underneath:** "Not a political organisation. Not a religious organisation. Not a security agency. Not a job portal. Not a replacement for government."

**[S-ST: §20.2 design constraints, verbatim]** — "the word 'AI' should not appear in the ten-second version — it imports the wrong category. The word 'protection' should not appear either — it imports the most dangerous category (F-09). Both belong in the second conversation, not the first. **This is a *sequencing* decision about truth-telling, not a concealment: the full description must be one tap away.**"

**[P] Rule E-74 (Sequencing Is Not Concealment — And Must Be Auditable).** The shortened first-contact description is permitted only if **all four** hold:
1. The full description, including the business pillar, the protection pillar and the AI doctrine, is **one action away** from every first-contact artefact, in the same language.
2. Nothing omitted is **material to the person's immediate decision** — a person asking for help must be told at first contact if the organisation cannot lawfully or safely handle their kind of need.
3. Nothing omitted is **adverse** — the shortened form may not omit a limitation, a restriction, a failure or a correction.
4. The shortened and full forms are **both versioned and both registered** in the terminology register, so any divergence is detectable.

**[A]** Condition 2 is the one that will be tested in practice, and it is where a well-intentioned simplification becomes a misrepresentation. **[I]** A person who reports a domestic-violence concern to a team whose first-contact material did not mention protection boundaries has been misinformed by omission, however briefly — and **[S-A: A-08]**'s DO-NOT list plus the authorities-first doctrine must therefore be reachable at first contact **for need-seekers specifically**, even where they are not part of the helper's first ten seconds. **Rule E-75: the "report a need" route displays its own boundaries at the point of need-reporting, not one tap away.**

## 16.3 The misclassification map

**[S-ST: §18.2]** — eleven misclassifications, four rated **Severe**. Carried forward as **MC-1…MC-11** and made operational by adding a *detector* and a *first-response* column.

| MC | Perceived as | Danger | Prevention **[S-ST]** | **Detector [P]** | **First response [P]** |
|---|---|---|---|---|---|
| **MC-1** | **Political organisation / party front** | **Severe** | Neutrality Code; refusal log; no distribution near elections; diverse public faces; explicit non-alignment in every onboarding | **CI-3** perceived political association; media scan; approach register | Rule E-34: evidence, never campaigning — code, log, accounts, spokesperson distribution |
| **MC-2** | **Religious or caste outfit** | **Severe** | Composition monitoring; activity-scoped partnership rules; no religious framing ever; deliberately multi-festival service calendar | **CI-4**; routing and calendar pattern review (CN-1, RN-1) | Rule E-41, Rule E-49: behavioural records, never demographic figures |
| **MC-3** | **Private security agency / vigilante group** | **Severe** | Visibility protocol; no uniform or insignia; public "we are not a security force" statement; do-not-attend list; authorities-first doctrine made public | **CI-5**; any VG-5-class incident; visual audit | Part 47; **[S-D: VG-1…VG-6]**; immediate incident review, published if material |
| **MC-4** | **NGO that needs donations** | Moderate | State clearly that the organisation earns revenue and is not donation-dependent; publish the funding mix | First-contact question 8 comprehension | Funding statement; published accounts |
| **MC-5** | **Private company / agency** | Moderate | Separate venture trading names; never use the service brand to endorse commerce | Rule E-18 audit of venture artefacts | Correction; trading-name separation |
| **MC-6** | **Job portal / scheme** | **High** | Published earnings reality; recruitment-conduct rule; separate service and earnings doors | **CI-2**; inbound queries asking about "the salary" | Rule E-15: Door 3 is closed unless a funded local venture exists — **say so plainly** |
| **MC-7** | **AI / tech startup** | Moderate | Describe AI as an internal tool, never as the product; lead with service in every explanation | First-contact wording audit; **"AI" absent from the ten-second version [S-ST: §20.2]** | Restate; Art.12 in plain language |
| **MC-8** | **Volunteer WhatsApp club** | Moderate | Evidence, published records, formal entity, insurance, documented SOPs | Partner and official feedback | Publish the entity status **accurately, including what is pending** (Rule E-59) |
| **MC-9** | **Charity for the poor, with poor people as props** | **High** | Absolute image and consent rules; beneficiaries never used as proof; stories told by participants, not about recipients | **E-34** attribution audit; consent completeness (**CI-14**) | Withdraw the artefact; correction; dignity review |
| **MC-10** | **Parallel government** | **High** | Explicit boundary statement; always route through authorities; never claim authority; publish that it does not replace any government function | Official feedback; any artefact claiming an outcome only government may deliver | Part 26 boundary statement; correction |
| **MC-11** | **Surveillance network** | **High** | Publish what data is held, why, for how long and who can see it; a public privacy notice; QR use restrictions; no public scanning | **CI-1**, **CI-11**; media and civil-society scan | Publish the notice in every operating language; **state plainly that no caste, religion or political data is collected (Rule E-48)** |

**[P] Rule E-76 (Misclassification Is A Safety Issue, Not A Marketing Issue).** MC-1, MC-2, MC-3, MC-9, MC-10 and MC-11 each carry a real-world consequence — police attention, communal classification, vigilante accusation, dignity harm, state hostility, civil-liberties concern — and are therefore owned by **Communications together with Safety, Legal and Audit**, not by Communications alone. **[S: Ch.5]** already structures it this way: National Communications interfaces with "Editors, Social Media Managers, **Safety, Legal**."

## 16.4 The correction instruments

**[S-ST: §18.3]**, carried forward as **E-15**:

| # | Instrument **[S-ST]** | v1.3-E addition **[P]** |
|---|---|---|
| 1 | **One category sentence, identical everywhere, in every language.** Must pass the 10-second test | Registered in the terminology register per language and per state; versioned; **CI-2 measured** |
| 2 | **A published "what we are not" list** — stated plainly and without defensiveness | Present at first contact (Rule E-73), not on request |
| 3 | **Segment-specific explanations** — residents, customers, officials, students, partners, media. "Same facts, different salience. All approved by the Editor function per Ch.24" | **Rule E-77:** segment explanations may vary **salience only**, never content, and each is registered against the same claim record (Rule E-26). A segment explanation that omits a limitation present in the general explanation fails Rule E-74 condition 2 |
| 4 | **Legal-status honesty** — state exactly what entity exists, what registration is pending, and what the organisation is *not yet authorised* to do. "Under-claiming is a trust strategy; over-claiming is a liability" | Rule E-59; Part 31 claim ladder; **entity structure is `UNRESOLVED` and must be described as pending, never as settled [V]** |
| 5 | **A misclassification response protocol** — who responds, how fast, in what tone (calm, factual, non-defensive per **[S: Ch.24]**), with what evidence | Part 47; **CC-1…CC-8** crisis classes |
| 6 | **"Never argue with a label in public; replace it with a fact."** "We are not political" is weak. "Here are the eleven elections in which we distributed nothing and declined four sponsorship offers — the refusals are logged" is strong | **Rule E-33 neutrality is published, not declared.** Every MC response is a record citation, never an adjective |

---

# PART 17 — FIRST FIVE MINUTES

## 17.1 What already exists

**[S-C: H-05]** — First-Five-Minutes Experience, adopted as an amendment. **[S-ST: §20.3]** — the ideal new-citizen experience, minute by minute, with the design principle "**value before vetting; contribution before commitment; a person before a process. Nothing in these five minutes requires understanding the architecture.**"

**[A]** v1.3-E does not restate the minute-by-minute design. It addresses the three things that change when the first contact is **national** rather than **local**, and the one structural gap the stress test itself named.

## 17.2 The gap: there is no public local page

**[S-ST: §20.3, minute 1–2, verbatim annotation]** — "One page, in their language: the core sentence, the 'what we are not' list, three things this team actually did nearby with dates, and two buttons — **'Report a need'** and **'Help once'**… Requires a public local page — **not in the current architecture [P]**."

**[P] Amendment E-16 — The Public Local Record.** One page per operating locality, containing exactly seven elements and nothing else:

| # | Element | Source of truth | Class |
|---|---|---|---|
| **PLR-1** | The category sentence, in the locality's language | Terminology register (Rule E-66) | C1 public **[S-A: A-17]** |
| **PLR-2** | The "what we are not" list | National, registered | C1 |
| **PLR-3** | **Three things this team actually did nearby, with dates** | Project and outcome records **[S: Ch.15, App. F]** | C1, with consent and minimisation **[S-A: A-18, A-19]** |
| **PLR-4** | **"Report a need"** — three fields: what, where, contact (optional) | Intake record **[S: Ch.8 step 2]** | Intake C2; contact C3 |
| **PLR-5** | **"Help once"** — listed one-off tasks with time, place, duration and what to bring | Task records **[S: Ch.22]** | C1 |
| **PLR-6** | **How to check whether a person or group is genuinely associated, and in what role** | Public verification channel **[S-ST: §14.2 Layer 2]**; role record **[S: Ch.22]** | C1 for role-and-validity only |
| **PLR-7** | **How to complain, and to whom outside this locality** | Complaint route reaching outside the unit **[S-D: MVLS-9; S-ST: M10]** | C1 |

**[P] Rule E-78 (The Public Local Record Is Ungated And Unadorned).** PLR-1…PL-7 are available without account, login, form, fee, app, consent prompt or tracking (Rule E-19). **The page contains no newsletter prompt, no donation appeal, no membership invitation, no follower count, no testimonial, no imagery of beneficiaries and no founder reference.** **[A]** Every one of those is a request; the page's only purpose is to answer the eight first-contact questions and to make two actions available. **A page that asks for anything in the first five minutes has failed the design principle.**

**[P] Rule E-79 (The Page Exists On Paper Too).** Where no digital page is available, PLR-1…PL-7 exist as a **single physical sheet posted at the team's meeting point**, in the locality's language, with the same seven elements. **[S-B: §40]**'s no-technology pilot makes this the *primary* form during Stage 0–1 and the fallback permanently. **[A]** The paper sheet is not a degraded version; it is the version that satisfies Rule E-72 (every process has a human route) and AX-D (offline route mandatory, not fallback).

## 17.3 Two different journeys, not one

**[A]** Brief §105 requires that "I need help" and "I want to help" be designed separately. **[I]** They are not two moods of one person; they are two people with opposite needs, opposite vulnerabilities and opposite risks.

| | **HELP SEEKER** | **HELPER** |
|---|---|---|
| **State of mind** | A problem, often urgent, often embarrassing | Curiosity, surplus capacity, often sceptical |
| **What they need first** | To know whether this body can lawfully and safely handle *their kind* of problem — **before** they describe it | To know what is needed, where, when, what skill, whether training is required, what authority they would have, and how the contribution is recorded |
| **Vulnerability** | **Acute.** Describing a need discloses something | Low |
| **Prohibited** | Membership, recruitment, unnecessary data, public exposure, any conversion pathway (**Rule E-13**), any emotional appeal (Rule E-9) | Any promise of income (Rule E-15), any destiny language (NEF-6), any form before an action |
| **First action** | **Report a need — three fields, optional contact, acknowledgement with reference number and a stated response window** **[S-ST: §20.3]** | **Help once — a listed task with time, place, duration and what to bring** |
| **Data collected** | **Minimum safe pathway (Rule E-80)** | Nothing beyond what the task requires |
| **What closes the loop** | A real person responds within the promised window, says what will happen, **and says what the team cannot do** — "we don't handle that; here's the municipal number" **[S-ST: §20.3]** | A real task, a visible result, a personal thank-you by name, and **"you're on the record for this — no obligation to do it again"** |
| **Failure that matters** | Silence; over-promise; a form; a broadcast message; being asked to join | A symbolic task; being asked to return; being counted in a total |

**[P] Rule E-80 (The Minimum Safe Pathway For A Help Seeker).** A person seeking help is never required to: create an account; provide identity documents; disclose caste, religion, political affiliation, health, family circumstances or income; consent to any image; be photographed; be named in any record that is published; join anything; attend anything; reciprocate; or give testimony. **What may be required is only what the priority assessment needs: the nature of the need, its location, its urgency and a way to respond** **[S: Ch.8 step 5]**. **[S-A: A-18]**'s four-branch necessity test governs every field.

**[P] Rule E-81 (The Boundary Is Stated Before The Disclosure).** Where a kind of need is outside the organisation's lawful or safe scope — a criminal matter, a medical emergency, a legal dispute, a custody question, a land conflict — **the help-seeking route states that boundary before the person describes their situation in detail**, and supplies the appropriate authority's contact. **[A]** Reason: a person who discloses a serious matter to a body that cannot lawfully act on it has been placed in a worse position than before they asked, and **[S-A: A-08]**'s DO-NOT list plus the authorities-first doctrine make this a foreseeable and preventable harm.

## 17.4 What is national and what is local in the first five minutes

| Element | National | Local |
|---|---|---|
| Category sentence | **Meaning fixed, registered per language and per state** | Wording local within the register |
| "What we are not" list | **Fixed** | Language local |
| What the team did, with dates | — | **Entirely local** |
| Report-a-need form | Schema and minimum-data rule fixed | Language, channel (paper, voice, in person, message) local |
| Help-once task list | — | **Entirely local** |
| Verification channel | **One national route**, so a query from anywhere resolves | Local role records feed it |
| Complaint route | **Must reach outside the locality — fixed requirement** | Local intake point |
| Response window | Standard exists | Actual window set by local capacity, published honestly |
| Tone and register | Meaning fixed | **Fully local (LA-4)** |

**[A]** The asymmetry is deliberate and is the practical form of Rule E-3 and Rule E-50: **the two things that must be national are the two that protect a stranger — the verification channel and the outward-reaching complaint route.** Everything else that makes the first five minutes work is local, because everything else is about a specific lane.

---

# PART 18 — FIRST REAL WIN

## 18.1 The criteria

**[S-ST: §21.1]** criteria and **[S-ST: §21.3]** the recommended model: **the Paired First Task**, adopted by **[S-C: H-06]**. The brief §31 adds four prohibitions: the first win must not require **joining permanently, recruitment, payment or public praise.**

**[P] Rule E-82 (First-Win Conditions).** A first win is real only if all six hold:

| # | Condition | Source |
|---|---|---|
| **FW-1** | **It is real work with a real outcome** — not a demonstration, a taster, a simulation or an onboarding exercise | **[S-ST: §21.1]**; Part 5 stage 3 |
| **FW-2** | **It is bounded and the bound is honoured** — a stated duration that ends when it says it ends | **[S-C: H-23]**; **[S-ST: §20.3 minute 4–5]** |
| **FW-3** | **It is paired** — alongside two existing members, so the person is not alone and not supervised | **[S-C: H-06]**; Part 5 stage 5 |
| **FW-4** | **The outcome is visible to the person** — they see the before and after, or are told what happened | **[S-C: HM-6, HM-7]** |
| **FW-5** | **The thanks is personal and the expectation is explicitly absent** — "you're on the record for this; no obligation to do it again" | **[S-ST: §20.3]**; **[S-C: H-06 field 9]** |
| **FW-6** | **No joining, no recruitment, no payment, no public praise, no photograph, no data beyond the task** | Brief §31; Rule E-13; Rule E-24; **E-34** |

**[A]** FW-5's second half is the one that determines whether the other five matter. **[S-C: H-06 field 9]** identifies the risk precisely: "the two members become recruiters, destroying the win — **Mitigation: the statement 'nothing further is expected' is mandatory and scripted.**" **[I]** A first win that ends with an invitation is not a first win; it is a first stage of a funnel, and the person will feel the difference immediately, however warmly the invitation is made.

## 18.2 What could go wrong with the first win

**[P]** Four failure modes, each with a control:

| Failure | Mechanism | Control |
|---|---|---|
| **FWF-1 The symbolic task** | The organisation invents easy work so the first win is guaranteed | **FW-1.** A task that produces nothing produces no outcome, and no outcome means no attribution — **the loop breaks at stage 4 and the person correctly concludes it was theatre** |
| **FWF-2 The over-scoped task** | The person is given real work beyond their capacity or authority, and fails | Task listing states skill, duration and authority; **[S: Ch.10]** delegation is explicit, recorded, RBAC-limited and reviewed |
| **FWF-3 The unattributed win** | The person does the work and never hears the outcome | **[S-C: H-15]** attribution is a **required step**, not a courtesy; **HM-7** measures it |
| **FWF-4 The converted win** | The first win becomes the opening of a recruitment conversation | **Rule E-24; FW-5; FW-6.** **The mandatory scripted statement is the control, and its use is auditable** |

## 18.3 The first win at national scale

**[A]** Three things change:

| Change | Consequence | Instrument |
|---|---|---|
| **The first win may be remote** | A translator, designer, researcher or technologist's first win produces no locally visible outcome | **[S-C: H-24]**: "a named local person tells them what their work became on the ground"; **HM-7 measured specifically for remote contributors** |
| **The first win may be a help-seeking win** | For a help seeker, the first win is **not contributing at all** — it is a problem being verified, scheduled and fixed, or being honestly declined with an alternative | **Rule E-5**; **[S-ST: §20.3 minute 3–4]**: "the decline, delivered well, is itself a trust event" |
| **The first win may be an observation win** | For position 24 (the observer), the first win is **finding a claim they can check, and checking it** | Rule E-19; PLR-3, PLR-6; Part 22 |

**[P] Rule E-83 (Three First Wins, Not One).** The organisation designs for three distinct first wins: **a contribution win** (FW-1…FW-6), **a help win** (a need met, or honestly declined with an alternative), and **a verification win** (a stranger checks a claim and it holds). **All three must be available without membership, without payment and without data beyond the minimum.** **[A]** An architecture that only designs the contribution win has designed a recruitment funnel with a good first step; the help win and the verification win are what make it a service.

## 18.4 Value proposition by persona

**[P]** Twelve core personas, per brief §97. **Every cell is `[P]` and none is a promise.**

| # | Persona | Problem | Value | Entry door | Level | First win | Reason to return | Reason to leave | Trust concern | Non-negotiable boundary |
|---|---|---|---|---|---|---|---|---|---|---|
| **1** | **College student** | No verifiable work experience near home | A dated, externally checkable record and a portable credential | Door 2 — PROOF | L2–L3 | A real weekend task with a visible result | The record grows; the people are still there | The record turns out to be unverifiable; the work was symbolic | "Will an employer believe this?" | No unpaid work presented as paid; no fabricated record |
| **2** | **Wage worker** | No time; unpredictable shifts | Bounded local contribution; occasional paid venture work with a published formula | Door 3 **only where a funded venture exists** | L1–L3 | One bounded task that ended when it said it would | Hours stay bounded; payment arrives when stated | Payment late; hours creep; "volunteering" displaces paid work | "Will this cost me my job?" | Rule E-15: Door 3 is not advertised unless real |
| **3** | **Homemaker** | Care responsibilities; socially constrained mobility | A morning slot within walking distance, with other women, that ends when it ends | Door 1 — PURPOSE | L1–L3 | One task at a time and place that works | The time contract is honoured; the team is stable | Timing ignores care work; a venue difficult to enter; being marked "inactive" for pausing | "Will my family object?" | Paused status carries no penalty **[S-C: H-18]** |
| **4** | **Retired professional** | Unused judgement; no structured outlet | Advisory standing without command; teaching | Door 1 / Door 4 | L3–L4 | One consultation that was actually used | Being useful, on their own schedule | Being ceremonial; being asked to be a "face" | "Am I being used for credibility?" | Advises, never commands **[S-D: SP-4]** |
| **5** | **Shopkeeper** | Local disorder affects footfall; wants a reliable partner | Local coordination; documented activity-scoped partnership | Door 1 | L1–L2 / partner | One visible improvement near the shop | The lane stays better; goodwill | Being asked for money repeatedly; their photo used as "support" | "Will this bring trouble to my door?" | No implied endorsement **[S: Ch.5 §4.4]**; BR-3 |
| **6** | **Farmer** | Water, school, animal health, scheme information | Service on the agricultural calendar; voice and paper routes | Door 1 | L0–L2 | One problem verified and acted on, or an honest referral | Cycles match the season | A city process requiring a smartphone; a late decline | "Do they understand my year?" | Rule E-81: boundary stated before disclosure |
| **7** | **Person in acute need** | A problem they cannot solve alone, and shame in asking | Help without distinction, without condition and without exposure | **None — they are not entering a door, they are asking for help** | L0 | The problem is fixed, reduced, or honestly declined with an alternative | The follow-up happened; nobody made them feel like a case | Being photographed; being asked to be grateful; help conditional on attendance | "Will everyone know?" | **Rule E-13: no conversion pathway, ever** |
| **8** | **Small business customer** | Local work needs doing reliably with clear accounting | Verified delivery, QA, dispute route, published formula | Door 3 | Customer | One delivery to specification | Reliability and accounting | Quality differing from what was sold; being pitched membership | "Is this a charity or a business?" | Rule E-18: separate trading name; no service-brand endorsement |
| **9** | **Skilled specialist** | Wants scoped, conflict-declared engagement, not conscription | SP-series scope with authority ceilings; portable credential | Door 2 / Door 4 | L4 | One engagement where the advice was used and credited | Scope grows without command growing | Being asked to take line authority; credential inflation | "Will they overclaim what I said?" | **Advice recorded as advice; the decider is named (Rule E-16)** |
| **10** | **High-income supporter** | Wants giving that is traceable and unromantic | Published accounts with worker compensation shown separately; outcome and follow-up reporting | Door 1 | L1–L2 / donor | One gift whose use they can trace in a published account | The accounts keep coming, including the bad quarters | An emotional appeal; a named beneficiary; discovering a donor influenced an allocation | "Where did it actually go?" | **Rule E-17: money buys a receipt and nothing else** |
| **11** | **Journalist or researcher** | Wants evidence, access and a body that will correct itself | Verified records, named local contributors with consent, correction logs, a documented media protocol | **None — media/research relationship** | Media / research | One story or dataset that held up under checking | Being answered with facts, including unfavourable ones | Access conditional on tone; a staged photograph; no correction when they erred | "Will they manage me?" | **Rule E-84 below** |
| **12** | **Sceptical resident who wants none of it** | Wants to know what it is and to be left alone | A public record they can read with no account, and a promise that nothing further is expected | **None** | L0 permanently | Finding one claim and checking it successfully | Being left alone, and the lane staying fixed | Being canvassed; a newsletter; a form; being counted | "What do they want from me?" | **Rule E-19: observation is ungated; Rule E-11: L0 is complete** |

**[P] Rule E-84 (Media And Research Are Not Participants).** Journalists, researchers and creators engaged in scrutiny are governed by a documented protocol, not by the participation spectrum. **Access is not conditional on tone; no favour is offered or implied; corrections are issued whether or not they are welcome; and the organisation does not attempt to become the subject's advocate.** **[A]** The reason is structural: **a body that treats scrutiny as a relationship to be managed will eventually be caught managing it, and that single event costs more trust than a decade of favourable coverage earns.**

---

# PART 19 — NATIONAL PARTICIPATION FUNNEL

## 19.1 The funnel, and why it is not a funnel

**[P]** The brief specifies: **Awareness → Understanding → First interaction → First contribution → First impact → Return → Deeper participation → Optional membership → Leadership/building**, with no conversion percentages and no growth numbers.

**[A]** The word "funnel" is retained because the brief uses it, and is immediately qualified: **a marketing funnel is designed to maximise the number reaching the bottom. This one is designed to maximise the number receiving value at whatever stage they stop.** The structural difference is that **every stage is a legitimate destination.**

**[P] Rule E-85 (Every Stage Is An Exit And A Destination).** No stage may be described, internally or publicly, as a drop-off, a loss, a failure to convert or an incomplete journey. **L0 Observer is a complete and permanent position (Rule E-11); a person who helps once and never returns is counted as a success** — and **[S-C: §8.4]** already requires the annual report to publish "the number of people who helped once and never returned, **as a success metric**."

## 19.2 The nine stages

| Stage | What happens | Owner | What must be true | What must NOT happen | Measurement |
|---|---|---|---|---|---|
| **S1 AWARENESS** | A person encounters a **result**, not an organisation: a dated board, a neighbour's remark, a photograph wall, a local record **[S-ST: §20.3]** | Team | Something real happened and is visible | Any problem-framing that precedes a result; any campaign | **HM-1** inbound contacts; **CI-11** |
| **S2 UNDERSTANDING** | They can answer the eight first-contact questions | Team + National Communications | PLR-1…PL-7 exist, in their language | Jargon; role titles; process diagrams; the hierarchy | **CI-2**; **HM-2** comprehension |
| **S3 FIRST INTERACTION** | They report a need, ask a question, check a claim, or choose a task | Team | A response inside the stated window by a named person | A form before an action; a broadcast; silence | **HM-4** first-participation completion; **CI-15** |
| **S4 FIRST CONTRIBUTION** | One bounded real task, paired, or one help-seeking interaction completed | Team | FW-1…FW-6 | A symbolic task; an invitation at the end | **HM-5** contribution completion; **HM-6** |
| **S5 FIRST IMPACT** | The outcome is returned to them, dated, specific, place-based, inside a window | Team | **[S-C: H-15]** attribution loop closed | A beneficiary image substituted for evidence | **HM-7** attribution received; **HM-8** follow-up known |
| **S6 RETURN** | They choose to do it again | **Them** | The first experience was worth repeating | Reminders, streaks, guilt, "we miss you" | **HM-9 — second contribution within the window; the primary measure [S-ST: §21.3]** |
| **S7 DEEPER PARTICIPATION** | Scope, specialist engagement, training, mentorship — **taken up voluntarily** | Team + City | Real scope exists with a ceiling and an exit | Destiny language; pressure; "you're a natural" | **HM-10** development taken up voluntarily |
| **S8 OPTIONAL MEMBERSHIP** | Verification, L5 — **if they want it** | HR & Verification | Gate E criteria published; access barriers removed **[S-D: OB-1…OB-7]** | Any implication that S1–S7 were a probation | **[S-D: LM-14]** pipeline throughput |
| **S9 LEADERSHIP / SPECIALISE / BUILD** | A role, a credential, a venture, a team | Appointing authority | Gate R readiness, assessed out of team **[S-D: Rule D-45]**; succession state recorded | Co-option by the incumbent; popularity selection | **[S-D: LM-1, LM-14]** |
| **S10 HELP THE SYSTEM HELP THE NEXT PERSON** | They make the entry easier for someone else — a playbook, a translation, a paired task, a correction, a lesson | Anyone | The contribution is recorded institutionally, not personally **[S-A: A-15 M4]** | **Any reward for introduction (Rule E-24); any commission; any ambassador scheme** | **E-34**; **[S-A: A-15 M5]** lessons entries |

**[A]** S10 is the brief's §200 final step, with its own final rule: "**the last step must NOT become recruitment-for-income.**" **[P]** It is specified as **system improvement**, not as bringing people: **a person at S10 improves the pathway, not the headcount.** Writing the playbook that made their own entry possible, translating the notice that they could not read, pairing with the next person, reporting the friction that stopped them (**HM-15**) — all are S10. **Introducing a person is not S10; it is S1 for that person, and it earns the introducer nothing.**

## 19.3 The funnel's four structural differences from a marketing funnel

| Difference | Marketing funnel | This |
|---|---|---|
| **Objective** | Maximise progression to the bottom | **Maximise value received at the stage reached** (Rule E-85) |
| **Measurement** | Conversion rate per stage | **No conversion rate exists as a target** (brief §34, §162). Stage-reached is recorded (**HM-15**) as a diagnostic of what to fix, never as a score |
| **Friction handling** | Reduce friction to progress | **Retain the friction that protects**: verification before membership, minimum data before service, boundary before disclosure (Rule E-81) |
| **The exit** | A lost lead | **A complete outcome, published as a success** (**[S-C: §8.4]**) |

**[P] Rule E-86 (No Conversion Target, Ever).** No target, quota, incentive, leaderboard, campaign objective, budget line, individual objective or team gate may be expressed as a conversion rate, a membership count, a join rate or a progression percentage. **[A]** The reason is the same one **[S-D]** gives for density targets (**Rule D-37**): **a conversion target is a pressure to sign people up, and a sign-up pressure in a service organisation operating among vulnerable people is a safeguarding risk, not a KPI.** **[S-C: H-03]** prohibits recruitment at the moment of vulnerability; a conversion target manufactures exactly that moment.

## 19.4 Acquisition channels, assessed

**[P]** Brief §35 requires each channel to be assessed on cost, trust, manipulation risk, scalability, local adaptability and dependency.

| Channel | Cost | Trust produced | Manipulation risk | Scalability | Local adaptability | Dependency risk | Verdict |
|---|---|---|---|---|---|---|---|
| **Local service, visibly done** | Low — it is the work itself | **Highest.** Layer 1 micro-trust **[S-ST: §14.2]** | None | Limited by capacity | Total | None | **PRIMARY. Everything else is amplification of this** |
| **Word of mouth** | Zero | **High** | None if unmanaged; **high if incentivised** | Slow but compounding | Total | None | **PRIMARY — and it is an output, not a channel (Part 36 of the brief; §36 below)** |
| **The public local record (PLR)** | Low | High — checkable | None | Scales with publication, not with capacity | High | Low | **PRIMARY** |
| **Published accounts and corrections** | Moderate | **High with institutions and sceptics** | None | High | Low | None | **PRIMARY for legitimacy** |
| **Local events / stalls** | Low | Medium-high | **Medium** — an event is a crowd, and **[S-A: A-01 N3]** prohibits crowd mobilisation capable of being read as political | Medium | Total | None | Permitted with the election-window protocol |
| **Schools and colleges** | Low | Medium | **HIGH** — institutions become recruitment pipelines (brief §51) | High | Medium | **High** — dependency on institutional goodwill | **Restricted to service and education; never to recruitment (Part 28)** |
| **Workplaces** | Low | Medium | Medium | Medium | Low | Medium | Permitted as a participation-mode accommodation **[S-C: H-23]**, not as a recruitment channel |
| **Local businesses** | Low | Medium | Medium — sponsorship seeking influence | Medium | High | Medium | Permitted with BR-3 and Rule E-17 |
| **Community and faith-based bodies** | Low | **High locally** | **HIGH** — alignment risk | Low | Total | Medium | **Activity-scoped, separately branded, non-exclusive, never doctrinal [S-A: A-05 clause 5]** |
| **Digital platforms / social** | Low cash, **high labour** | **Low** — reach without trust | **HIGH** | High | Low | **HIGH** — platform dependency (Part 53) | **Information and service visibility only; never primary proof (Part 24)** |
| **Creators and influencers** | Variable | **Negative-to-low** | **VERY HIGH** | High | Low | **HIGH** — reputational contagion | **Restricted; see Part 24 §24.5** |
| **Celebrities** | High | **None transferable** | **VERY HIGH** | High | Low | **HIGH** | **Not recommended; see Part 24 §24.6** |
| **Paid media / advertising** | **High cash** | **None** — purchased attention is not trust | **VERY HIGH** | High | Low | Medium | **Prohibited by Rule E-25** — emotion is never a budget line, and there is no revenue line for communication |
| **Government interface** | Low | **High where lawful and appropriate** | Medium — becoming an instrument | Medium | Low | **HIGH** — political adjacency | **Part 26 boundaries** |
| **Referral incentives** | Low | **Destroys trust** | **DEFINITIVE** | High | High | None | **PROHIBITED absolutely (Rule E-24)** |

**[A]** The verdict column has a pattern worth stating: **every channel with high scalability has low or negative trust production, and every channel with high trust production is capacity-limited.** This is not a defect in the channel mix; it is the central fact of the architecture. **[P] Rule E-87 (Trust Does Not Scale; Publication Of Trust Scales):** the organisation does not attempt to scale trust-producing activity. **It scales the *publication* of trust-producing activity** — records, accounts, outcomes, corrections, refusals — which costs bytes and translation rather than people, and which lets a stranger in another state verify what a lane in this one experienced.

---

# PART 20 — TRUST ARCHITECTURE

## 20.1 The four questions a stranger is actually asking

**[S-ST: §14.1]**, carried forward with the gap column preserved verbatim — it is the diagnosis this entire Part exists to answer:

| Question | What satisfies it | What the architecture provides **[S]** | **Gap [S-ST]** |
|---|---|---|---|
| **1. Are they competent?** | Repeated, visible, small successes; skill evidence; knowing when to say no | Verification, training, QA, evidence standards, outcome verification | **"Nothing *public* demonstrates competence before engagement; competence is proved only to insiders"** |
| **2. Are they honest?** | Traceable money, published accounts, receipts, no personal enrichment | Waterfall, segregation, receipts, reconciliation, audit, restricted funds | **"Not published. All honesty machinery is internal. A stranger cannot see any of it"** |
| **3. Are they safe?** | Boundaries visibly respected; no weapons; no intimidation; privacy honoured; children protected | Six DO-NOTs, risk tiers, safeguarding training, privacy-controlled records | Visibility protocol, dress/symbol rules, certified safeguarding, privacy notice, data-breach plan — **proposed in [S-A: A-06, A-17…A-20], not operational** |
| **4. Are they accountable?** | A named recipient of complaints, a published outcome, a visible correction | Audit & Ethics department, dispute routes, corrections, appeals | **"No public-facing complaint channel, no ombuds, no published outcomes"** |

**[S-ST: §14.1 conclusion, verbatim]** — "the architecture is strong on *being* trustworthy and almost entirely silent on *being seen to be* trustworthy. **Trust that cannot be observed does not compound.**"

## 20.2 The four trust layers, made operational

**[S-ST: §14.2]**, carried forward as **E-19**, with an owner, an artefact and a test per layer.

| Layer | Content **[S-ST]** | Artefact that must exist **[P]** | Owner | Test |
|---|---|---|---|---|
| **L1 MICRO-TRUST** — "the only layer that actually scales" | Every act of help, done competently, with dignity, on time, with no ask in return, deposits trust in a *person-to-person* account. "Nothing else substitutes for it. Everything in Layers 2–4 exists to protect and amplify Layer 1, never to replace it" | A real service record with outcome and follow-up; a paired first task; a personal thank-you; a well-delivered decline | **The team** | **HM-13** dignity reported by participants **and** beneficiaries separately; **HM-14** promises kept |
| **L2 VERIFIABLE LOCAL PRESENCE** | A public, simple, local record of what this team did, where, when, with what result, in the local language with privacy-protective detail; **a public verification channel where anyone can confirm whether a person or group is genuinely associated, and in what role**; named local accountability **plus a published non-local contact** | **PLR-1…PL-7** (Rule E-78); the public verification channel; the outward complaint route | **Team + National Communications** | PLR exists and is current; **CI-11** verification queries answered; **MVLS-9** route reachable |
| **L3 INSTITUTIONAL TRANSPARENCY** | **Publish the boring things** quarterly: money in, money out, worker compensation paid, reserve position, social-impact fund utilisation, incidents and outcomes, corrections issued, complaints received and resolved, teams recognised and teams closed — "plain language, local languages, no design gloss. **Boring transparency is more credible than polished reporting**." **Publish failures.** **Publish the rules before the results.** Independent review where appropriate **[V]** | The quarterly public record; **the public correction log (E-20)**; the published rules — approval limits, allocation criteria, eligibility criteria, payment formula version; the published refusal log | **Finance + Audit + Communications** | Every item present and dated; **CI-9** correction count and latency; **CI-8** claim traceability |
| **L4 STRUCTURAL TRUST** — "for institutions, not individuals" | Legal entity clarity and honest status disclosure; insurance; data-protection compliance; grievance redressal with timelines; partnership documentation; a mission lock. "Corporates, CSR teams, government counterparts, donors and regulators trust structures, not intentions" | Entity status stated accurately **including what is pending** (Rule E-59); insurance position **[V]**; privacy notice in every operating language; retention schedule; rehearsed breach runbook; partnership agreements; **mission lock [S-A: A-13]** | **National + Legal** | Each item present or its absence honestly disclosed |

**[A]** The layering has a hard implication for sequencing: **Layer 1 must exist before Layer 2 is worth publishing, and Layer 2 before Layer 3 means anything.** A national transparency report from an organisation with no verified local outcomes is a document about intentions. **Rule E-4 (reputation lags capacity) applies to trust layers exactly as it applies to claims.**

## 20.3 The public trust signals

**[P] TS-1 … TS-14.** Each is a **publication of an existing record**, never a new assertion. Each states what it must never become.

| ID | Signal | Record it publishes | Class | Must never become |
|---|---|---|---|---|
| **TS-1** | **Verified activity, with dates and localities** | Project and outcome records **[S: Ch.15, App. F]** | C1 with minimisation | A count without locality; a total without dates |
| **TS-2** | **Outcomes and follow-up: resolved / reduced / unchanged / worsened / unknown** | Follow-up record **[S: Ch.15 step 10; S-C: HM-8]** | C1 aggregate | A success-only summary |
| **TS-3** | **Money in, money out, worker compensation shown separately** | Payment sheets and ledger **[S: Ch.18, Ch.19]** | C1 | A polished report with design gloss |
| **TS-4** | **Reserve position and social-impact fund utilisation** | Finance records **[S: Ch.20]** | C1 | A fundraising appeal |
| **TS-5** | **Incidents and their outcomes, in summary** | Incident records **[S-A: A-09]** | C1 summary; **C4 detail sealed** | Identification of any person, including a complainant |
| **TS-6** | **Corrections issued — the public correction log** | Correction log **[S: Ch.24; S: App. A §8.x Editor outputs]** | C1 | **Empty. An empty log across a reporting period is published as an anomaly (Rule E-61a below)** |
| **TS-7** | **Complaints received and resolved, in aggregate** | Complaint records **[S-D: Part 18]** | C1 aggregate with small-cell suppression | Identification; a "zero complaints" boast |
| **TS-8** | **Political and commercial approaches received and declined, with an annual count** | Approach register **[S-A: A-04]** | C1 | A political statement |
| **TS-9** | **Leadership information: roles, not persons** — what each role may and may not do, and how to reach it | Role records **[S: Ch.9]** | C1 | A personality profile; a photograph-led page |
| **TS-10** | **Governance structure and decision authority, accurately, including what is unresolved** | Authority map **[S: App. E; S-D: Part 34]** | C1 | A claim that a question is settled when it is not |
| **TS-11** | **The rules, published before the results** — approval limits, allocation and eligibility criteria, payment formula version | **[S-ST: §14.2 Layer 3]** | C1 | Publication after an adverse outcome |
| **TS-12** | **The privacy notice: what is held, why, for how long, who can see it** | **[S-A: A-17 P3]** | C1, in every operating language | A legal document nobody can read |
| **TS-13** | **Teams closed and units that stopped operating** | Closure records | C1 | Omitted. **Publishing closures is the credibility condition for publishing openings** |
| **TS-14** | **What is not yet known, and what is being tested** | The pilot plan and its limits **[S-B: §40; S-D: Part 41]** | C1 | Omitted |

**[P] Rule E-88 (The Correction Log Must Not Be Empty).** Where a reporting period produces zero published corrections, zero upheld complaints against the organisation, zero incidents and zero declined approaches, **that fact is published as an anomaly and referred to Audit** — on the logic **[S-A: A-16]** applies to the dissent test, where "a zero count is a warning sign, not a clean bill of health", and **[S-ST: §14.3 item 9]**: "institutions that have never corrected anything are either dishonest or inactive." **[A]** This is the operational form of ES.5, and it is the only control in this document that acts on the *absence* of a record rather than on its content.

## 20.4 What must be true before national trust can exist

**[S-ST: §14.3]** — ten falsifiable pre-conditions, carried forward unchanged and mapped to the claim ladder (Part 31) and the expansion gates (Part 58):

| # | Pre-condition **[S-ST]** | Current status | Blocks |
|---|---|---|---|
| 1 | **Legal form exists and is publicly stated accurately**, with tax and employment classification resolved **[V]** | ❌ `UNRESOLVED` **[S: Ch.33]** | Any national claim; **GATE E0** |
| 2 | **One full year of published accounts** for the pilot, however small, with worker compensation shown separately | ❌ nothing published | CL-2 and above |
| 3 | **Zero unresolved serious safety incidents** in the pilot, every incident published in summary | ❌ no pilot | CL-2 |
| 4 | **A functioning public complaint channel** with published resolution statistics and **at least one published adverse finding against the organisation itself** — "proof the channel has teeth" | ❌ no channel exists | **GATE E2, GATE E3** |
| 5 | **Insurance in force** for members and third parties **[V]** | ❌ **[S-A: A-10]** | Any protection-adjacent public activity |
| 6 | **A privacy notice in every operating language**, a retention schedule, a rehearsed breach response **[V, X]** | ❌ retention `UNRESOLVED` | **GATE E1** |
| 7 | **A Political Neutrality Code adopted and published, with a refusal log demonstrating it has been used** | ❌ `PROPOSED` **[S-A: A-01]** | **GATE E2** |
| 8 | **At least one independently verified impact claim** — an external party confirming an outcome, not the organisation confirming its own | ❌ | **CL-3 and above; GATE E5** |
| 9 | **A published correction** — evidence the organisation has corrected itself publicly at least once | ❌ | **CL-3; GATE E3** |
| 10 | **Succession and mission-lock instruments executed** | ❌ **[S-A: A-13, A-14; S-D: Part 11]** | **GATE E6, GATE E7** |

**[S-ST: §14.3, verbatim]** — "**Until items 1–7 are true, national expansion should not proceed.** This is not caution for its own sake; it is that a trust failure at national scale is not survivable, and each of these items is cheap before scale and unaffordable after."

**[P] Rule E-89 (Pre-Conditions 1–7 Are Gates, Not Aspirations).** They are adopted as **GATE E1 and GATE E2** in Part 58 and are **not waivable by any level of the organisation**, including the founder, because **[S-A: A-14 §13.3]** makes name, brand and entity-structure changes reserved matters.

## 20.5 "Verifiable" versus "trustworthy"

**[A]** The brief §39 requires the distinction to be tested. **[S-C]** and **[S-ST: §19.2]** both land on **"we are verifiable"** and explicitly reject **"we are more trustworthy"** — the latter being "both false and insulting, and it manufactures enemies. The correct claim is: 'we are verifiable' — a different axis, on which you can win without anyone losing."

| | **"We are trustworthy"** | **"We are verifiable"** |
|---|---|---|
| **Type** | An **outcome**, conferred by others over time | A **design claim**, about the organisation's own arrangements |
| **Who may say it** | **Nobody at the organisation.** Only a third party, and only after the fact | The organisation, **if and only if the verification route exists and works** |
| **Falsified by** | One failure | One claim that cannot be checked |
| **Cost of being wrong** | Total — the claim was the asset | Contained — the design is corrected |
| **Comparative?** | **Yes, and therefore insulting and adversarial** | **No — verifiability does not require anyone else to be unverifiable** |
| **Requires** | Years, and other people's mouths | PLR-1…PL-7, published accounts, a correction log, a verification channel, a complaint route |

**[P] Rule E-90 (The Organisation Never Claims To Be Trusted).** No organisational artefact may state, imply or celebrate that the organisation or any person in it is trusted, trustworthy, respected or beloved. **It may state what can be checked and where to check it.** **[A]** The prohibition is not modesty. **A trust claim is unfalsifiable at the moment it is made and catastrophic at the moment it is broken, and it transfers the judgement from the public to the organisation — which is the exact inversion of the differentiation.**

**[A]** The corollary is the one that makes this work: **verifiability must actually be verifiable.** Rule E-19 (ungated observation), Rule E-88 (the correction log must not be empty), Rule E-26 (the claim register) and TS-1…TS-14 exist because a "we are verifiable" claim with nothing to verify is worse than no claim — **it is an invitation to check, followed by a locked door.**

---

# PART 21 — REPUTATION ARCHITECTURE

## 21.1 The two models

**[P] Amendment E-20.** The brief §227 requires the model and its counterfeit to be produced side by side.

```
THE PERMITTED MODEL

REALITY            what the organisation actually did, verified
   |
   v
EVIDENCE           records that exist and can be inspected (Rule E-8, E-26)
   |
   v
TRANSPARENCY       publication of those records (TS-1..TS-14)
   |
   v
CORRECTION         publication of what went wrong (E-20, Rule E-88)
   |
   v
TRUST              conferred by others, never claimed (Rule E-90)
   |
   v
REPUTATION         what people say when the organisation is not in the room
   |
   v
REPEAT PARTICIPATION   HM-9 - the only honest confirmation


THE COUNTERFEIT MODEL

ADVERTISING        purchased attention
   |
   v
ATTENTION          reach without relationship
   |
   v
FOLLOWERS          a count that can be bought and that proves nothing
   |
   v
FALSE REPUTATION   an expectation with no evidence behind it
   |
   v
FIRST FAILURE      the expectation is tested by one real event
   |
   v
COLLAPSE           the fall exceeds the rise (Rule E-4 mechanism)
```

**[A]** The two models differ in exactly one structural respect: **the counterfeit has no arrow returning from failure to reality.** In the permitted model, a failure enters at CORRECTION and improves REALITY. **In the counterfeit, a failure has nowhere to go except down** — because there was never any reality for it to correct.

**[P] Rule E-91 (Reputation Is Downstream And Never A Target).** Reputation is an output of the first six stages. It may be **measured** (CI-1, CI-3, CI-4, CI-5, TS-series completeness) and it may never be **targeted, incentivised, budgeted or campaigned for**. **[A]** A reputation target produces reputation management, and reputation management produces the counterfeit model from the top down.

## 21.2 Reputation-capacity alignment

**[A]** Rule E-4 established the mechanism. This section makes it measurable.

| State | Definition | Detection | Required action |
|---|---|---|---|
| **RC-1 UNDER-KNOWN** | Capability exceeds recognition | Inbound demand below capacity; HM-1 low while HM-14 promises-kept is high | **Publish more.** PLR, accounts, outcomes. This is the *desired* state at every stage |
| **RC-2 ALIGNED** | Recognition matches demonstrated capability | Claim ladder class matches evidence class (Part 31) | Maintain; continue publishing |
| **RC-3 AHEAD** | Recognition exceeds demonstrated capability | Inbound demand exceeds verification or delivery capacity; decline rate rising; claims at CL-n with CL-(n-1) evidence | **Rule E-92: stop publishing scale claims; publish capacity limits; increase publication of declines and rules** |
| **RC-4 FAR AHEAD** | Recognition substantially exceeds capability | Viral attention; media coverage beyond the evidence base; demand the organisation cannot triage | **Rule E-93: the growth-shock protocol (Part 43) activates; public expectation management becomes an explicit communication task** |

**[P] Rule E-92 (Publishing The Limit).** When recognition runs ahead, the corrective publication is **not** a quieter tone. It is the explicit statement of what the organisation cannot currently do, where, and why — with the criteria by which requests are prioritised published in advance. **[S-ST: §14.2 Layer 3]**: "when people know the rule in advance, an outcome they dislike is a disappointment; when they learn the rule afterwards, it is a conspiracy."

## 21.3 "Would people miss us?"

**[S-ST]** originated the test; the brief §93 requires it be made real and warns that followers are not the same as being missed.

**[P] Rule E-94 (The Disappearance Test).** The test is answered **per locality**, not nationally, and only from records:

| Question | Evidence source | What counts as a real answer |
|---|---|---|
| **What would communities lose?** | Service records, follow-up outcomes, unmet-request register | A named, dated, recurring service that stopped |
| **What relationships would disappear?** | HM-3 belonging; the paired-task record; partner agreements | People who would lose contact with each other, not with the organisation |
| **What services would stop?** | Project records; the DO-NOT-safe referrals the team makes | A function nobody else performs |
| **What opportunities would disappear?** | Contribution records, credentials issued, paid venture work | A route to a record, a credential or an income that has no local substitute |
| **What evidence would show genuine dependence or value?** | **Unsolicited inbound contacts (HM-1); requests from people who were never recruited; a partner or authority asking the team to continue something** | **Inbound, unprompted, and from people with nothing to gain** |

**[P] Rule E-95 (Followers Are Not Being Missed).** No social metric, membership count, event attendance figure, page view or media mention may be used as evidence in the disappearance test. **[A]** The test asks what would be *lost*, and a follower is not a loss — a follower is an attention state that transfers at zero cost to whoever posts next.

**[A]** The uncomfortable version of the test, which is the useful one: **at CL-0 the honest answer for every locality is "nothing, because we are not there yet."** The test is not a marketing instrument; it is the reason the claim ladder starts where it does.

## 21.4 The substitution test

**[P]** Brief §94: if Sewak Sathi disappeared, could another organisation replace everything it does?

| Component of the offering | Replaceable by | Uniquely combined? |
|---|---|---|
| Local service delivery | Faith bodies, RWAs, NGOs, municipal contractors, caste and community associations, families | **No — abundantly replaceable, and existing bodies hold far more local trust [S-ST: §19.2]** |
| Emergency and first response | Police, fire, ambulance, municipal authorities, neighbours | **No — and the organisation must not compete here [S-A: A-08; S-D: VG-1…VG-6]** |
| Verification and records | Almost nobody at neighbourhood scale | **Yes — this is the genuine gap [S-ST: §29 item 4]** |
| Traceable money and published accounts | Registered NGOs and companies, under statutory obligation | **Partially — the difference is *voluntary, plain, local-language* publication** |
| Portable contribution record | NSS certificates (bounded to student years), platform ratings (bounded to the platform), employer references (bounded to the job) | **Yes — "the most valuable and least developed asset in the architecture" [S-ST: §19.2]** |
| Paid local work with a published formula | The open labour market | **No — and the architecture must not claim otherwise [S-ST: §19.2: "we pay better than the open market" is not defensible]** |
| National capability deployed locally | State machinery; large NGOs | **Partially — the difference is that it is deployed on request, not on direction (Rule E-55)** |
| Continuity when a local group collapses | Nobody | **Yes** |

**[P] Verdict: the combination is defensible; no component is.** **[S-ST: §19.2]** already reached this: four claims are defensible, three are not. **[A]** The correct formulation of uniqueness is therefore **conjunctive and modest**: *in your neighbourhood, keeping records, showing accounts, and paying fairly when the work earns — and able to prove all three.* **[S-ST: §19.3]**: "nobody will *switch*. The correct model is **complement and escalate.**"

**[P] Rule E-96 (Complement, Never Rival).** No organisational communication may position the organisation against an existing local institution — an RWA, a faith body, a school, a panchayat, a municipal office, an NGO, a caste or community association, or a neighbourhood group. **The default posture is partnership and complementarity, activity-scoped and evidence-shared [S-ST: §19.3; S: Ch.29].** **[A]** The reason is not courtesy: **"a new organisation that arrives as a rival to existing local institutions will be destroyed by them"** — and those institutions hold the trust the organisation needs.

## 21.5 Repair reality before repairing reputation

**[P] Rule E-97 (brief §169).** Where reputation is damaged:

| Step | Action | Prohibited |
|---|---|---|
| **1** | Establish what actually happened, from records, through the appropriate route (Part 47) | Announcing a conclusion before the record supports one |
| **2** | **Repair the underlying failure** — the service, the money, the safety, the governance, the data | Announcing a repair that has not occurred |
| **3** | Publish the finding, the repair and the residual risk | Publishing only the repair |
| **4** | Correct any public claim that the failure falsifies (Rule E-26, TS-6) | Leaving the claim standing |
| **5** | Change the standard, through the versioned route **[S-A: A-15 M2/M3]** | A one-off instruction |
| **6** | Report back at the next reporting date on whether the change worked **[S-A: A-15 M5 "did it work"]** | Closing the matter at step 3 |

**[A]** Rebranding is prohibited as a response to any of steps 1–6. **Rule E-98 (The Rebranding Test):** a change of name, mark, palette or identity is justified only where **(i)** the existing identity is factually misleading about what the organisation is, **(ii)** the misleading is not curable by publication, and **(iii)** the underlying institution is already repaired and evidenced. **A rebrand proposed while a governance, leadership, financial, safety or trust failure is unresolved is refused, and the refusal is recorded.**

## 21.6 Differentiation, restated as architecture

**[S-ST: §19.2]** — four defensible claims, three prohibited. **[P]** Each defensible claim is given its **evidence precondition**, because a differentiator that cannot yet be evidenced is not a differentiator:

| Claim | Evidence precondition | Current status |
|---|---|---|
| **"Verified help that actually arrives, with evidence"** | The verification → priority → execution → evidence → outcome-verification chain operating, and **published locally** | Mechanism designed **[S: Ch.8, Ch.15, App. F]**; publication does not exist |
| **"You can see where the money went"** | Published accounts with worker compensation shown separately, in local languages, plainly | Waterfall and records exist **[S: Ch.18, Ch.19]**; **publication does not exist** |
| **"Your contribution is recorded and portable"** | The contribution record and the portable credential issued and externally checkable | **[S-C: H-09, H-10]** proposed; Part 54 specifies portability |
| **"Neighbourhood-scale, national-capability"** | At least one locality where a national capability was actually deployed on local request | Requires ≥ 2 units and a City. **Not testable at CL-0** |

**[A]** All four are **CL-2 or CL-3 claims** on the Part 31 ladder. **None may be made at CL-0 or CL-1.** At CL-0 the only available claims are the four in Part 6 §6.3, and the fourth of those is a labelled commitment rather than a description.

---

# PART 22 — PUBLIC TRANSPARENCY

## 22.1 The five audiences

**[P] Amendment E-21.** The brief §40 requires definition of what the public, members, leaders, auditors and confidentiality each see. **[S-A: A-17]**'s C1–C4 classification governs; **v1.3-E does not alter it.**

| Audience | May see | May not see | Instrument |
|---|---|---|---|
| **PUBLIC — anyone, including non-members** | **C1**: TS-1…TS-14; the category sentence and "what we are not" list; PLR-1…PL-7; the published rules (approval limits, allocation and eligibility criteria, payment formula version); the Political Neutrality Code; the privacy notice; the entity status **including what is pending**; the DO-NOT list and the authorities-first doctrine; the correction log; the refusal log counts; published accounts and outcomes | **Anything C2, C3 or C4.** No individual's record, no beneficiary identity, no complaint content, no conduct matter, no safeguarding record, no pay of a named person, no small cell that identifies anyone | Rule E-19 ungated; Rule E-78 unadorned |
| **MEMBERS** | **C2** by role need, level and geography per **[S: Ch.23]** RBAC; their **own** record **[S: Const. Art.6; S-A: A-20 §19.7]**; standards and SOPs; the decision register; aggregate metrics | Other members' C3 personal data; sealed categories; anything beyond their role need | **[S-A: A-19]** eight-function access matrix |
| **LEADERS** | C2 for their scope; C3 **only** with a recorded purpose, case scope and reason code | C4 except under the A-20 regime; **their own assessment by their own line [S-D: Rule D-50]** | **[S-A: A-17 C3 rules]**; **[S-D: Part 17]** |
| **AUDITORS** | **Review access across classes, including C4 under the two-person rule — and no operational command** **[S: Ch.23; S-D: INV-15]** | Nothing withheld; **but review only** | **[S: Ch.27]** |
| **CONFIDENTIAL — sealed** | **C4**: conduct and investigation records; safeguarding and protection incidents; allegations and complaints; grievance and integrity-line records; anything identifying a victim, survivor, whistleblower or minor; sensitive personal circumstances; political-declaration records under **[S-A: A-02]** | **Nobody outside the case scope.** Named individuals, case scope, **two-person rule for opening**, reason code, time-limited, logged, audited | **[S-A: A-20]** |

## 22.2 The transparency/privacy boundary

**[P] Rule E-99 (Transparency Is Not Publishing Everything).** Brief §240. Three tests determine whether a record may be published:

| Test | Question | Fails if |
|---|---|---|
| **TP-1 Necessity** | Does publication serve a public accountability purpose that cannot be served by an aggregate? | The same accountability is achieved by a count or a rate |
| **TP-2 Identifiability** | Could any person be identified, directly or by combination, including through a small cell? | **Yes — suppress or aggregate. Rule E-100: no cell of one** **[S-D: Rule D-108]** |
| **TP-3 Harm** | Could publication cause physical, legal, social, economic or reputational harm to any person who has not consented? | **Yes — do not publish, regardless of accountability value** |

**[P] Rule E-100 (Small-Cell Suppression, With Suppression Reported).** Where a cell is too small to publish safely, it is merged upward or suppressed, **and the fact of suppression is itself reported** so the reader knows what is missing. **The threshold is `UNKNOWN — MEASURE IN PILOT`** and until set, the conservative rule applies.

**[A]** The tension is real and is not resolved by principle: **[I]** the records that would most powerfully demonstrate honesty are the ones most likely to identify someone — a single upheld complaint in a small locality, one incident in one team, one closure in one city. **Rule E-99 resolves it toward suppression, which weakens the trust signal.** The mitigation is **temporal**: publish the aggregate annually and the specific case once the identification risk has decayed, and never publish a case that identifies a victim, survivor, complainant, whistleblower or minor at all.

## 22.3 The public reporting calendar

**[P]** Built on **[S: Ch.24]**'s existing cadences, which are **not altered**:

| Cadence **[S: Ch.24]** | Internal content **[S]** | **Public content [P]** | Owner |
|---|---|---|---|
| **Daily** | Operational memory: tasks, attendance, field notes, requests, incidents, stock, delivery notes | Nothing | Team |
| **Weekly** | Money, work and immediate accountability: revenue, expenses, work verification, payments, allocations, projects, incidents, risks | Nothing routine; **immediate publication of any urgent safety or service suspension (LA-5)** | Team |
| **Monthly** | Performance and leadership: metric score, leaderboard evidence, finance, team health, HR, training, safety, business | **PLR-3 refresh** — what this team did, with dates | Team |
| **Quarterly** | Strategic review: audit, safety trends, financial health, venture portfolio, social outcomes, expansion readiness | **The boring-things publication [S-ST: §14.2 Layer 3]**: money in and out, worker compensation paid separately, reserve position, social-impact fund utilisation, incidents and outcomes, corrections issued, complaints received and resolved, teams recognised and teams closed | Finance + Audit + Communications |
| **Annual** | Full organisational accountability: impact, finance, reserves, social funds, member growth, safety, business, governance, risk | **The accountability report**: all of the above plus the refusal-log counts, the four institutional test counts **[S-A: A-16; S-D: Rule D-94]**, the mission-balance statement **[S-ST: §17.3]**, **and the number of people who helped once and never returned, as a success metric [S-C: §8.4]** | National + Audit |

**[P] Rule E-101 (No Reporting Theatre).** Every published item has a named consumer and a stated accountability purpose. An item published for two consecutive periods with no evidenced consumer, no query, no correction and no decision attached is **retired** — on the logic **[S-D: Rule D-53, Rule D-65]** applies to reviews and measurements. **[A]** Reporting theatre is not harmless: **it consumes the translation, audit and communications capacity that the mandatory items need, and it teaches readers to stop reading.**

## 22.4 What must never be published

| Never published | Reason |
|---|---|
| Any beneficiary's identity, image, location precise enough to identify, or circumstance | **[S-A: A-19, A-20]**; **E-34** dignity rules; MC-9 |
| Any individual's performance score, ranking or ordinal position | **[S-C: §23.2]** "a person is never scored"; **[S-D: Rule D-63]** |
| Any individual's pay, load band, dependency band, readiness finding or assessment | **[S-D: §31.2]** classification |
| Complaint content, conduct matters, safeguarding records, investigation records | **C4 sealed [S-A: A-20]** |
| Caste, religion or political affiliation data — **because none is collected** | **[S-A: A-18]**; Rule E-48 |
| Aggregate figures with identifiable small cells | Rule E-100 |
| Any claim above the current claim-ladder class | Rule E-4; Part 31 |
| A membership, follower or reach count as a trust or legitimacy argument | Rule E-2; Rule E-95 |
| Testimonial, endorsement or "success story" from a beneficiary | **E-34**; **[S-C]** testimony-extraction prohibition |
| A trust, trustworthiness or beloved claim about the organisation or any person | Rule E-90 |

---

# PART 23 — CRISIS COMMUNICATION

## 23.1 The source rules

**[S: Ch.24 communication-type table, verbatim]**:

| Type | Rule **[S]** |
|---|---|
| **Internal** | "Clear tasks, decisions, deadlines, risks and changes; **avoid informal orders bypassing records**" |
| **Public / social media** | "**Only verified facts; distinguish completed work from plans; protect privacy**" |
| **Emergency / incident** | "**Fast and factual; no speculation; sensitive statements require safety/legal/communications approval**" |
| **Press / public statements** | "**Authorised spokespersons only; national/relevant approval for sensitive matters**" |
| **Misinformation** | "**Correct calmly with verifiable facts and correction logs**" |

**[S: Ch.5]** — National Communications "owns public narrative, brand standards, crisis communication, misinformation correction and media approvals", interfacing with Editors, Social Media Managers, **Safety** and **Legal**. **[S-A: A-09]** incident reporting; **[S-A: A-17 P5]** breach response; **[S-A: SOP-22]** data breach; **[S-D: Part 37]** crisis leadership — "standards are not suspended in a crisis, only sequence".

## 23.2 The eight crisis classes

**[P] Amendment E-22 — CC-1 … CC-8.** Each specifies who speaks, what evidence is released, what is withheld, timing, correction and follow-up.

| Class | Trigger | **Who speaks** | **Released** | **Withheld** | **Timing** | Correction & follow-up |
|---|---|---|---|---|---|---|
| **CC-1 SAFETY INCIDENT** | Injury, death, endangerment, unsafe act | **Safety function + authorised spokesperson**, with Legal | What happened, where, when; what was done; what is stopped; who to contact; the authorities' role | Any person's identity; clinical detail; C4 content; speculation on cause | **Immediately, and before the cause is known — "fast and factual; no speculation" [S: Ch.24]** | Incident review published in summary (TS-5); standard changed via M3; "did it work" reported |
| **CC-2 FINANCIAL ALLEGATION** | Misuse, misappropriation, unpaid worker, irregularity | **Finance + Audit**, with Legal | The accounts; the specific transactions in question; the audit position; the referral if any | Individual pay; C3/C4; allegations not yet examined | As soon as the record can be stated accurately; **never "we are transparent" without the record** | Independent or statutory audit **[V]**; correction; restitution where due; **priority-1 payment is never suspended by a dispute [S-D: INV-2]** |
| **CC-3 DATA BREACH** | Leak, unauthorised access, loss of member or beneficiary data | **Data function + National Communications**, with Legal | That a breach occurred; what categories are affected; what is being done; what affected people should do; the grievance route | The affected individuals' identities in any public statement; security detail that would aid repetition | **[X]** DPDP Act 2023 requires notification to the Data Protection Board **without delay** with a detailed report within **72 hours**, and notification to affected data principals; **no materiality threshold**; CERT-In separately requires incident reporting within **6 hours**. **[V] REQUIRES LEGAL VALIDATION — application depends on the unresolved entity structure** | Containment, investigation, access review, remediation, prevention, per **[S-A: A-17 P5; SOP-22]** |
| **CC-4 LEADER MISCONDUCT** | Allegation or finding against a role-holder | **Governance/HR panel route; National Communications states process, not conclusion** | That a matter exists; the process; the interim measures; the outcome class when determined | The allegation's detail; the complainant's identity; C4 content; **any conclusion before the panel decides** | Interim measures immediately **[S-D: Rule D-102]**; outcome on determination | Panel decision published as an outcome class; **non-retaliation absolute [S-D: §18.2]**; correction if the organisation's earlier statements were wrong |
| **CC-5 POLITICAL ACCUSATION** | Alleged partisan alignment | **National Communications**, citing records | The Neutrality Code; the refusal log with its annual count; the accounts showing no political money; the spokesperson distribution | **Any political statement, counter-allegation or comment on any party [S-A: A-01 N1, N5, N9]** | **Rule E-32: a false association, once known, must be corrected within a stated window — silence misleads (N9)** | Where substantially true, **Rule E-35: repair, not messaging**; composition and partnership review; published correction |
| **CC-6 RELIGIOUS OR CASTE ACCUSATION** | Alleged communal or caste character | **National Communications**, citing records | The non-alignment clause; the behavioural record — where service went, on what criteria; the multi-festival calendar; the activity-scoped partnership register | **Any composition figure, any theological statement, any individual's identity (Rule E-42, Rule E-48)** | Promptly; **never as a theological argument** | Pattern review of routing, venue, timing and recognition; published correction |
| **CC-7 PROTECTION / VIGILANTE INCIDENT** | Members physically intervened; a video circulates | **Safety + Legal + National Communications** | What the organisation's boundaries are; what the record shows; the incident review; the referral to authorities | Any identification of members or of any other person; legal conclusions **[V]** | **Immediately**, because the video is already circulating | **[S-D: VG-5]** class review; visible-protocol audit; published correction where the record contradicts the video |
| **CC-8 SERVICE FAILURE** | A promised service did not happen; a project failed; a unit closed | **The team, in its own language**, with City support | What was promised, what happened, why, what is owed, what changes | Nothing material. **A service failure has no sealed content** | At the point the failure is known, not at the next reporting date | **TS-2 outcome recorded as "unchanged" or "worsened"; TS-6 correction; TS-13 closure published** |

## 23.3 The seven-step public error response

**[P]** Brief §42's sequence, specified:

| Step | Action | Prohibited response |
|---|---|---|
| **1 DETECT** | From any source: a complaint, an audit, a journalist, a member, a beneficiary, a platform report, an internal review. **Detection from outside is recorded as a detection failure** | Waiting to be told twice |
| **2 VERIFY** | Against records, not against recollection. **Fast and factual** | Verifying against the person accused |
| **3 ACKNOWLEDGE** | Plainly, in the affected locality's language, stating what is known and what is not yet known | **"Mistakes may have been made"; passive voice; acknowledgement of "concern" rather than of fact** |
| **4 CORRECT** | The factual correction, the withdrawn claim, the restored record, the repayment, the re-delivery | Correcting the impression rather than the record |
| **5 EXPLAIN** | The mechanism — what in the process allowed it. **Not the motive** | Explaining why it was not really an error |
| **6 PREVENT RECURRENCE** | A standard change through the versioned route **[S-A: A-15 M2/M3]**, with a reason | A one-off instruction; an exhortation; a training session with no process change |
| **7 FOLLOW UP** | Report at the next reporting date on whether the change worked **[S-A: A-15 M5 "did it work"]** | Closing the matter at step 5 |

**[P] Rule E-102 (The Four Prohibited Crisis Reflexes).** Absolutely prohibited in any crisis artefact: **(i)** denial by reflex before verification; **(ii)** attacking, naming, disparaging or questioning the motive of a critic, complainant, journalist or whistleblower; **(iii)** deleting criticism, comments, posts or records; **(iv)** blaming a named individual before a panel has determined anything. **[A]** Plus a fifth, subtler: **(v)** the **fake apology** — an expression of regret that acknowledges no fact, names no error, commits to no correction and is designed to end the conversation. **Rule E-103: an apology that does not contain a fact, a correction and a change is not an apology and may not be published as one.**

## 23.4 Spokespersons

**[P]** Brief §43 requires that spokesperson titles not be invented unless justified. **The source supplies them.**

| Source | Provision |
|---|---|
| **[S: Ch.24]** | "**Authorised spokespersons only; national/relevant approval for sensitive matters**" |
| **[S: Ch.5]** | **National Communications** owns public narrative, brand standards, crisis communication, misinformation correction and media approvals |
| **[S: App. A §8.x]** | **Social Media Manager** — "draft and publish approved low-risk content; escalate sensitive content; maintain local social channels under brand rules"; **cannot** "publish unverified claims, expose beneficiaries without consent, comment on legal/safety incidents without approval, use intimidation" |
| **[S-A: A-16 §15.4]** | "**Many authorised spokespersons by domain and region**, so the public face is a set of people doing work" |
| **[S-D: CU-1]** | Count distinct public spokespersons over a year; **one is a failure** |

**[P] Rule E-104 (No Invented Spokesperson Titles).** Spokesperson authority derives from the existing role structure — National Communications, the authorised-spokesperson designation under **[S: Ch.24]**, and role-holders speaking within their own domain. **No new title, office or position is created by this document.** **[A]** This matters because a "Chief Communications Officer" or "National Spokesperson" is a single point of reputational failure — and **[S-D: Part 12]**'s continuity discipline applies to communication exactly as to command: **CI-13 measures spokesperson distribution precisely so that one voice is detected as a defect.**

**[P] Rule E-105 (Domain And Region, Not Hierarchy).** Spokespersons are authorised **by domain** (service, finance, safety, data, business, governance) **and by region**, not by seniority. **A City-level safety spokesperson speaks on safety in their region; the National level does not speak for them and may not overrule their factual account.** **[A]** This is the communication form of **[S-D: ML-2]** escalation dumping: a system where every hard statement moves up produces statements that are late, generic and unaccountable.

---

# PART 24 — SOCIAL MEDIA

## 24.1 What it is for, and what it must not become

**[P] Amendment E-23.** The brief §44 lists six permitted purposes and five prohibited outcomes.

| Permitted | Prohibited |
|---|---|
| Information | **The organisation's primary proof** — proof is the record, published and checkable (Rule E-19, TS-series) |
| Service visibility | **A popularity contest** |
| Education | **A leader-fandom system** |
| Community coordination | **A source of unverified incidents** |
| Verified outcomes | **Beneficiary exploitation** |
| Recruitment **where appropriate** — i.e. where a specific role or task exists and access barriers are removed **[S-D: OB-1…OB-7]** | **Recruitment as a standing objective** (Rule E-86) |

**[S]** existing constraints, preserved: "public/social media: **only verified facts; distinguish completed work from plans; protect privacy**"; "misinformation: **correct calmly with verifiable facts and correction logs**"; the Social Media Manager "cannot publish unverified claims, expose beneficiaries without consent, comment on legal/safety incidents without approval, use intimidation, or modify financial records"; succession — "**channel access must be revocable; backup admin appointed with two-person recovery process**."

## 24.2 The vanity-metric prohibition

**[P] Rule E-106.** Followers, likes, views, shares, comments, reach, impressions, engagement rate, sentiment score and video completion are **communication signals at most**. They may never:

| Prohibited use | Source |
|---|---|
| Determine leadership, eligibility, readiness, promotion or recognition | **[S: Ch.25]**: "raw revenue, **follower count, social-media views**, volunteer count, application count or raw activity count **cannot determine leadership**" |
| Appear in any expansion, funding, legitimacy or scale argument | Rule E-2; **[S-D: Goodhart Prohibition List]** |
| Be used as evidence in the disappearance test | Rule E-95 |
| Be published as an organisational achievement | Rule E-27 facts not adjectives |
| Be targeted, incentivised, budgeted or campaign-managed | Rule E-25; Rule E-91 |
| Be used to segment an audience by any identity characteristic | **[S-A: A-01 N8]** no screening; **A-18** minimisation |

**[A]** The reason is not aesthetic. **[I]** A follower count is the single most purchasable, most gameable and least informative number available to an organisation, and it has one property that makes it dangerous: **it rises when the organisation says what people want to hear.** Every other metric in the architecture rises when the organisation does something. **[S-D: GF-30]** identifies the same vector — "optimise the record rather than the work."

## 24.3 What may be posted

**[P] Rule E-107 (Post Only What Is Already Published).** A social artefact may state only what already exists in a published record — PLR-3, TS-1…TS-14, a correction, a rule, a boundary. **Social media is a distribution channel for the public record, never a source of claims.** **[A]** This single rule eliminates most social-media risk, because it removes the category of *statement made for effect*, which is where every failure in §24.1's prohibited list originates.

| May be posted | May never be posted |
|---|---|
| A dated local result, with locality, and a link or reference to the record | A plan described as an achievement — **"distinguish completed work from plans" [S: Ch.24]** |
| A published accounts item | A total without a locality or date |
| A correction | A claim above the current claim-ladder class (Part 31) |
| A boundary or a refusal, in the registered wording | A beneficiary's image, name, location or circumstance |
| A task that needs doing, with time, place, duration | A membership appeal, a donation appeal, an emotional appeal (Rule E-9) |
| A rule, published before its results | Any political, religious or caste content, **including favourable** **[S-A: N5]** |
| An authorised spokesperson's factual statement within their domain | A comment on a legal or safety incident without approval **[S: App. A §8.x]** |
| A "what we are not" statement | An argument with a critic (Rule E-102(ii)) |

## 24.4 Comment, criticism and moderation

**[P]** Brief §125 and §126. **Rule E-108 (Five Categories, Five Responses).** Criticism is not automatically an attack:

| Category | Definition | Response | Prohibited response |
|---|---|---|---|
| **C-CRIT CRITICISM** | A factual or judgemental objection, however blunt | **Answer with a record.** Where correct, correct (CC-8, TS-6). Where incorrect, state the record calmly | Deletion; blocking; a personal reply; questioning motive |
| **C-MIS MISINFORMATION** | A false claim of fact circulating | **"Correct calmly with verifiable facts and correction logs" [S: Ch.24]**; platform reporting where appropriate; **silence where amplification would cause more harm** | Fighting misinformation with more misinformation; repeating the false claim to deny it |
| **C-HAR HARASSMENT** | Sustained abuse directed at a person | Protect the person; document; restrict the abuser; **do not respond publicly** | Naming the harasser; mobilising members |
| **C-THR THREAT** | A threat to safety | **Immediate Safety and Legal route; authorities where lawful [V]**; incident record **[S-A: A-09]** | Public disclosure that increases risk |
| **C-WHB WHISTLEBLOWING** | A report of wrongdoing by someone with inside knowledge | **Route to the Integrity Line, outside the operational line [S-D: MVLS-9; S-ST: M10]; non-retaliation absolute** | **Treating it as criticism, as an attack, or as disloyalty. This is the category most often misfiled, and misfiling it is the most damaging error available** |

**[P] Rule E-109 (Legitimate Criticism Is Preserved).** Comments, posts and records containing legitimate criticism are **not deleted**, even where inaccurate, even where hostile, and even where the organisation has answered them. **Deletion is permitted only for: abuse directed at an identifiable person; content that identifies a beneficiary, complainant, victim, survivor, whistleblower or minor; content that discloses C3 or C4 data; and unlawful content.** **Every deletion is logged with its ground, and the log is auditable.**

**[A]** The reason is institutional rather than ethical: **[I]** an organisation that deletes criticism loses the ability to know what is true about itself, and — decisively — **the deletion becomes the story.** A criticism answered with a record is forgotten in a week. A criticism deleted is screenshot forever.

## 24.5 Creators and influencers

**[P]** Brief §46. Assessed against the five risks it names:

| Risk | Mechanism | Control |
|---|---|---|
| **Personality dependence** | The creator's audience becomes the organisation's audience, and leaves with the creator | **No audience is acquired through a person.** Rule E-91; CI-13 spokesperson distribution |
| **Misinformation** | A creator states something the organisation did not say | Written scope; the creator may report, may not represent; **no approval of content, which would make the organisation responsible for it, and no correction of content, which would make it a party to it** |
| **Political association** | A creator's known alignment transfers | **[S-A: A-01 N1, N4, N6]** — no publicity from a political actor where partisan expectation could be read; due diligence (Part 25) |
| **Audience capture** | The organisation begins to shape its message for the creator's audience | Rule E-107: post only what is already published. **There is nothing to reshape** |
| **Reputational contagion** | The creator's later conduct damages the organisation | **Time-bounded, activity-scoped, terminable written agreement with brand-usage rules [S: Ch.29; BR-3]**; no exclusivity; no mark on the creator's own channels beyond the activity |

**[P] Rule E-110 (Creators Report; They Do Not Represent).** A creator may be given access to records and to named local contributors **with consent**, may produce their own work, and may not be authorised as a spokesperson, may not use the mark beyond the activity scope, may not be paid from any organisational line for favourable treatment, and may not be given anything not available to any other journalist (Rule E-84).

## 24.6 The celebrity endorsement test

**[P]** Brief §47. Tested, not assumed:

| Test | Finding |
|---|---|
| **Trust transfer** | **Does not occur.** Trust in this architecture is produced by verifiable local behaviour (Layer 1) and checkable records (Layers 2–3). **A celebrity can transfer *attention*, and attention without trust produces RC-3/RC-4 — recognition ahead of capacity, which is the failure mode Rule E-4 exists to prevent** |
| **Dependency** | **Creates it.** The endorsement becomes an asset whose value depends on a person the organisation does not control |
| **Cost** | Cash or in-kind, from an organisation with **no revenue line for communication** and a control budget `σ_max` **[S-B: §26.1]**. **Prohibited by Rule E-25 in either form** |
| **Political and religious association** | Indian celebrities carry political and religious readings, regionally variable. **Directly engages [S-A: A-01 N1, N4, N6] and A-05 clauses 6, 7** |
| **Authenticity** | An endorsement is a claim about the endorser's judgement, not about the organisation's records. **It is precisely the kind of unverifiable assertion Rule E-8 prohibits** |
| **Long-term sustainability** | The endorser's reputation is volatile and is not the organisation's to manage — brief §117 |
| **Reversibility** | **Poor.** An endorsement cannot be un-heard, and a withdrawal is itself a story |

**[P] Rule E-111 (No Paid Or Solicited Endorsement).** The organisation does not seek, purchase, solicit or accept celebrity endorsement as a legitimacy instrument. **Where a public person participates as an ordinary contributor, they are treated as one: their contribution is recorded, their fame is not referenced, and no organisational artefact mentions it.** **[A]** The exception is worth stating because it will arise: **a public person may hold a role.** If they pass Gate E and Gate R and are appointed through the vacancy lifecycle, they are a role-holder — and **[S-A: A-16 §15.4]** then requires that decisions be announced in the organisation's name with the deciding role identified, not in their name. **Their prominence makes the anti-cult controls more necessary, not less.**

## 24.7 Account and channel continuity

**[P]** Cross-reference to **Part 53**; the rules are stated there in full. The communication-specific ones:

| Rule | Content | Source |
|---|---|---|
| **No personal account is an official channel** | Every official account is registered to the organisation | Brief §179; **[S-A: A-14 §13.4]** |
| **Dual custody of credentials** | Platform, cloud, code repository, **domain, payment gateway, communication channels, social accounts and statutory portals** are held under dual custody with a documented emergency-access procedure | **[S-A: A-14 §13.4]** verbatim |
| **Channel access revocable; backup admin appointed; two-person recovery** | — | **[S: App. A §8.x Social Media Manager succession]** verbatim |
| **Access revoked same day on role change** | — | **[S-D: TA-b, TA-c, MVLS-11, Rule D-102]** |
| **A platform loss is survivable** | The public record exists independently of any platform (Part 53) | Rule E-119 |

---

# PART 25 — PARTNERSHIPS

## 25.1 What the source already requires

**[S: Ch.5 §4.4, verbatim]** — "**National partnerships must be documented. No team should imply that a partner endorses the entire organisation unless the written agreement says so.** Financial terms, responsibilities, safeguarding duties, data sharing, termination rights and public communication rules must be recorded before implementation."

**[S: Ch.5 §4.4]** — a national project is "an initiative whose scale, risk, funding, **brand impact** or technical complexity exceeds one city or state."
**[S: Ch.29]** — partnership flow; MOU/contract/email agreement defining **scope, responsibilities, data, finance, safeguarding, brand use and termination**.
**[S: Ch.33]** — "Partnership signatory authority: **Not final**. Approval matrix by amount/risk/data/brand impact."
**[S-A: A-05 clause 5]** — faith-based partners are activity-scoped, separately branded, with no religious content, no religious condition on receipt of help, no proselytisation in either direction, a written scope, never as a faith body on matters of belief, **never exclusive where alternatives exist**.
**[S-A: A-01 N6]** — no acceptance of money, materials, premises, media, transport, publicity or volunteers from a political actor where partisan expectation could be read; refusals logged.

## 25.2 The partnership architecture

**[P] Amendment E-24.** Six stages, each with a record:

| Stage | Action | Record | Refusal ground |
|---|---|---|---|
| **PT-A IDENTIFY** | A partner is proposed by a locality, a City or National | Proposal with the activity, the scope and the local need | The activity is outside the organisation's lawful or safe scope (Rule E-81) |
| **PT-B DUE DILIGENCE** | Conflicts, political association, religious association, misconduct risk, financial risk, brand risk (brief §130) | Due-diligence record with the reviewer named | Any unresolved conflict; any partisan expectation readable from the offer (**N6**); any safeguarding concern |
| **PT-C SCOPE** | A written agreement covering **scope, responsibilities, data, finance, safeguarding, brand use, public communication rules and termination** | The agreement **[S: Ch.29]** | Any term implying endorsement of the whole organisation **[S: Ch.5 §4.4]** |
| **PT-D APPROVE** | Approval by amount / risk / data sensitivity / **brand impact** | Approval record **[S: App. E; S: Ch.33 signatory authority `Not final` — carried unresolved]** | — |
| **PT-E OPERATE** | Activity-scoped delivery, separate branding, evidence shared, credit shared | Project and outcome records | Any drift beyond scope |
| **PT-F EXIT** | Termination per the agreement, with data return or destruction per **[S-A: A-17 P2]** and brand-usage cessation | Exit record | — |

**[P] Rule E-112 (Partnership Is Not Endorsement — In Either Direction).** Neither party's mark, name or reputation transfers. Concretely: **the partner's name does not appear in any service record, project outcome, allocation decision or recognition artefact**; and **the organisation's mark does not appear on the partner's general materials**, only on the activity-scoped artefacts the agreement permits (**[S-A: A-06 V5, V8]**).

**[P] Rule E-113 (Due Diligence Is Not Surveillance).** PT-B examines **the proposed partner as an institution** — conflicts, association, misconduct record, financial standing, brand risk — and **never individuals' beliefs, affiliations, identities, family or private conduct**. **[S-A: A-01 N8]** prohibits screening by political belief; **[S-A: A-18]** requires necessity. **[A]** The distinction is between *what this body does* and *what these people believe*, and only the first is examinable.

## 25.3 Partner classes and their specific risks

| Class | Value | Specific risk | Control |
|---|---|---|---|
| **Municipality / panchayat / ward office** | Legitimacy, access, escalation route, continuity | **MC-10 parallel government**; political adjacency at local level; becoming an instrument of one faction | Part 26 boundaries; the authorities-first doctrine made public; **no distribution near elections [S-A: A-03]** |
| **School / college** | Youth participation, service learning, venues | **Institutions become recruitment pipelines (brief §51)**; safeguarding of minors **[V]** | Part 28; **[S-C: SA-1…SA-7]**; **[S-D: LV-17, LV-23]** |
| **PHC / hospital / medical body** | Referral, health awareness, camps | Unlicensed practice; medical advice as organisational position | **[S-C: §47.3]**: no diagnosis or treatment unless licensed **[V]** |
| **NGO / civil-society body** | Complementarity, capability, coverage | Rivalry; funder capture **[S-ST: F-32]**; being absorbed into someone else's programme | **Rule E-96 complement, never rival**; activity scope; separate reporting |
| **Faith-based service body** | Existing reach and trust — kitchens, clinics, shelters, distributions | **MC-2 religious classification**; alignment; proselytisation in either direction | **[S-A: A-05 clause 5]** in full: separate branding, no religious content, no condition, written scope, never as a faith body on belief, **never exclusive where alternatives exist** |
| **Local business / CSR** | Funding, premises, materials, employment, pipeline | **Money buying influence (Rule E-17)**; brand adjacency; sponsorship strings | BR-3; Rule E-17; **aggregate disclosure of funding**; no naming at point of service |
| **Professional body / firm** | Pro-bono specialist scope, standards | Advice becoming an organisational position; conflict of interest | Rule E-16; **[S-D: Part 35]** declarations; **[S-C: §47.3]** "advice is not an organisational position" |
| **Technology company / platform** | Infrastructure, tooling, reach | **Vendor lock-in (Part 53)**; data-processing terms; AI doctrine erosion | Rule E-119; **[S: Const. Art.12]**; **[S-A: A-17]** processor standard; DPIA where applicable **[V]** |
| **Media organisation** | Reach, scrutiny | Access conditional on tone; paid praise (Part 29) | Rule E-84; Part 29 |
| **Political actor or adjacent body** | — | **Prohibited where partisan expectation is readable** | **[S-A: A-01 N6]**; refusal logged; approach register published (TS-8) |
| **Government scheme interface** | Information reach to people who need it | **Brokerage; MC-10; becoming an agent of the state** | **Rule E-114: information only, never brokerage** — **[S-ST: §12.2 rural row]**: "connectivity to government schemes (**information only, never brokerage**)" |

## 25.4 Independence and exit

**[P] Rule E-115 (Every Partnership Is Terminable And Tested For Independence).** Each agreement states the termination right, the notice, the data disposition and the brand-usage cessation. **Annual test:** if this partnership ended tomorrow, could the activity continue, be referred elsewhere, or be honestly stopped? **A partnership on which a locality's only service route depends is a dependency finding, recorded and mitigated — not a success.**

**[A]** The neutrality conditions, restated as partnership tests: a partnership may not compromise **neutrality** (N1…N9, A-05), **safety** (A-08, A-06), **independence** (no funder or partner directs priorities — immutable item 9 reserves problem definition to the neighbourhood), **financial truth** (the waterfall priority order is unchanged; a partner may not fund a reordering), or **mission** (service outcomes are not displaced by commercial or partner work — the mission-balance statement **[S-ST: §17.3; S-ST: M14]**).

---

# PART 26 — GOVERNMENT INTERFACE

## 26.1 The boundary

**[P] Amendment E-25.** The organisation must cooperate with lawful authorities without becoming government, police, a political organisation or an unofficial enforcement body.

| It may | It may never |
|---|---|
| Refer a matter to the appropriate authority, and say so publicly | Claim, exercise or imply any state authority |
| Assist a Magistrate or police officer where lawfully and reasonably required **[X]** BNSS 2023 s.31 binds every person to assist; s.40 permits private arrest in narrow circumstances with handover within six hours; s.43 limits force — **[V] REQUIRES LEGAL VALIDATION per jurisdiction** | Detain, search, confiscate, interrogate, expel, or instruct any person **[S-D: VG-2]** |
| Share information with an authority under lawful obligation, recorded | Share member, beneficiary or complaint data for any other purpose **[S-A: A-01 N7; A-17…A-20]** |
| Coordinate in a declared emergency, under the DO-NOT list | Act as a first responder beyond training and authority **[S: Ch.16; S-A: A-08]** |
| Follow up on a municipal service failure, as a resident would | Replace a government function, or present itself as doing so |
| Publish that it does not replace any government function | Accept a state role, a state symbol, a state title or a state uniform |
| Receive a government official **as a guest, never as a patron** | Give a political figure an organisational platform, or appear beside one **[S-A: A-01 N1]** |

**[S-ST: §18.2 MC-10]** — "A parallel government: perceived by officials, and eventually by the organisation itself… **High** — invites state hostility and mission overreach. Prevention: explicit boundary statement; always route through authorities; never claim authority; publish that it does not replace any government function."

**[P] Rule E-116 (The Boundary Statement Is Published).** A short public statement of what the organisation is not authorised to do, in every operating language, is part of PLR-2's "what we are not" list and is repeated at the point where a need exceeds scope (Rule E-81). **[A]** Publishing one's own limits is counter-intuitive and is the single most effective MC-10 and MC-3 control available, because it removes the ambiguity that both misclassifications depend on.

## 26.2 The election period

**[S-A: A-03 E1…E14]** — the election-period protocol including the internal window and the emergency exception **E9**, carried forward unchanged. **Communication-specific consequences:**

| Rule | Content |
|---|---|
| **Rule E-30** | The election calendar governs the communication calendar, not the reverse |
| **No distribution, announcement, campaign, event or publication timed to an election period** except where the emergency exception E9 applies | **[S-A: A-01 N3]** prohibits crowd mobilisation capable of being read as political |
| **A refusal script exists in every operating language**, so a local member can decline a senior politician without rudeness or capitulation | **[S-A: A-04]** |
| **A written-reply template on organisational letterhead, signed at National level**, so the refusal is institutional rather than personal | **[S-A: A-04]** — "protecting the local member from local consequences" |
| **Refusals are logged and the annual count is published** | **[S-A: A-04]**: "publishing refusals is more credible than declaring neutrality"; TS-8 |
| **Where a member faces pressure or consequence for a logged refusal, the organisation backs them through National Legal, and retaliation is serious misconduct** | **[S-A: A-04 support duty; S: SOP-18]** |

## 26.3 Government interface communication

**[P] Rule E-117 (One Voice, In Writing, To The Right Desk).** Communication with any authority is: in writing where possible; from the authorised role for that domain (Rule E-105); recorded in the decision register **[S-A: A-15 M1]**; and never from a personal account or a personal device. **[A]** The reason is evidential: **an undocumented conversation with an official is indistinguishable, to a later observer, from an improper one.**

---

# PART 27 — BUSINESS INTERFACE

## 27.1 The five business relationships

**[P]** Brief §50: businesses interact as **customer, partner, employer, supplier, supporter**. **The overriding rule: business relationships may not buy leadership authority.**

| Relationship | What it is | What it confers | What it may never confer |
|---|---|---|---|
| **Customer** | Buys a venture service under **[S: Ch.17]** | Delivery to specification, QA, a dispute route, a published formula | Standing, recognition, membership, influence, priority in service |
| **Partner** | A documented activity-scoped agreement (Part 25) | Co-delivery within scope | Endorsement (Rule E-112); brand adjacency beyond scope |
| **Employer** | Hires members or accepts credentials | Access to a verified contribution record **with the person's consent** | Any say in what the record contains; any preferential treatment of a member |
| **Supplier** | Provides goods or services | Payment per the waterfall at the correct priority | Influence over allocation; naming in a service record |
| **Supporter / sponsor** | Gives funds or in-kind support | A receipt; aggregate disclosure | **Nothing else. Rule E-17 absolutely** |

**[P] Rule E-118 (Ability To Pay Never Determines Access To Community Participation).** Brief §98's separation, stated as a rule: **a person's or a body's capacity to pay has no effect on their standing in the participation spectrum, on any service priority assessment, on any allocation, or on any recognition.** Priority assessment uses urgency, vulnerability, resources, expected impact, safety risk and feasibility **[S: Ch.8 step 5]** — never the requester's record, membership or money **[S-C: CR-1]**.

## 27.2 The public firewall between service and sales

**[S-ST: §17.1]** — "the tension is structural and not a matter of discipline." **[S-ST: §18.2 MC-5]** — perceived as "a private company / agency": "collapses the mission; invites 'they use charity to get clients'. Prevention: separate venture trading names; never use the service brand to endorse commerce." **[S-ST: §17.3]** — a published **Mission Balance Statement**. **[S-B: B-09]** — the paid/voluntary boundary must be published.

**[P] Rule E-119a (Four Firewall Rules In Public).**
1. **Separate names.** Venture trading names are distinct from the service identity (Rule E-18).
2. **No cross-endorsement.** The service brand never endorses a commercial offering; a commercial offering never appears in a service artefact.
3. **No service-to-sales conversion at the point of service.** A beneficiary, a help-seeker or a volunteer is never pitched a commercial product, a paid engagement or a venture opportunity. **The doors are separate and the sequence is one-way: a customer may later contribute; a beneficiary may never be sold to.**
4. **The mission balance is published.** Service outcomes versus commercial work, at the cadence the source requires, so displacement is visible before it becomes structural **[S-ST: §17.3; M14; S-B: B-01]**.

**[A]** The fourth rule is the one that determines whether the first three survive. **[I]** A firewall that is asserted but never measured holds exactly as long as commercial revenue is unimportant — which is precisely the period during which nobody checks it.

## 27.3 Earnings claims

**[P] Rule E-120 (No Earnings Claim Without A Local, Funded Reality).** Consistent with Rule E-15 and **[S-ST: F-02]**: no artefact, post, page, conversation or partnership material may state or imply that participation produces income **unless** a specific, funded, approved venture exists in that specific locality with a specific customer pipeline — and where it does, the statement includes the **published formula version**, the fact that work is verified before payment, and that earnings depend on customer demand.

**[A]** **[S-ST: §19.2]**: "'We pay better than the open market' — you almost certainly don't. Claiming it produces F-02." **[X-inherited]** v1.3-C requires that a person seeking livelihood receive "an earnings reality disclosed in writing before joining, describing the weak month, not the good one." **v1.3-E adopts that as a communication rule: the weak month is disclosed in the same artefact, at the same prominence, as the good one.**

---

# PART 28 — EDUCATION INTERFACE

## 28.1 The two rules that govern everything here

**[P] Amendment E-27.**

**Rule E-121 (Educational Institutions Are Not Recruitment Pipelines).** A school, college or university relationship exists for **service, service learning, skill development and mentorship** — never for member acquisition. Concretely: no institution may be given a membership target; no participation may be presented as required or credit-bearing unless the institution itself makes it so, in writing, and the organisation records that it did not ask; **no NSS-style enrolment drive may be run under the organisation's name**; and a student's contribution is recorded on the same basis as anyone else's, with no institutional multiplier.

**Rule E-122 (Young Participants Are Protected Before They Are Useful).** Any activity involving a minor operates under **[S-C: SA-1…SA-7]**, the two-adult rule, guardian consent, and the safeguarding obligations of **[S-A]** and **[S: Ch.12]**'s safeguarding training category. **[V] REQUIRES PROFESSIONAL VALIDATION — jurisdiction-specific, and this document proposes nothing in that domain.** The communication-specific consequences:

| Rule | Content |
|---|---|
| **No image of any minor in any organisational artefact, ever, for any purpose, with any consent** | Absolute. **[S: App. F]** "no exposure of minors"; **[S-A: A-20]** anything identifying a minor is C4 sealed |
| **No minor's contribution is published by name** | Aggregate only, with small-cell suppression |
| **No minor appears in any story, testimonial, case study, report or social artefact** | E-34 |
| **No activity places a minor alone with any adult, including a member, a partner's staff or a volunteer** | Two-adult rule |
| **No recruitment conversation with a minor occurs without a guardian present or informed** | **[S-C: H-27]**; **[S-D: Rule D-86]** |
| **No educational institution relationship may be described as producing "future leaders"** | Destiny language (NEF-6); and it converts an education relationship into a pipeline |

## 28.2 What the education interface may do

| Activity | Permitted | Condition |
|---|---|---|
| **Service learning** — a class or cohort performs a real, bounded local task | **Yes** | FW-1…FW-6 apply; the task is real, paired, bounded, attributed and expects nothing further |
| **Skill development and training** | **Yes** | **[S: Ch.12]** categories; trainer competence; **internal training is not legally sufficient where the domain is regulated [S-C: §47.3]** **[V]** |
| **Mentorship** | **Yes** | Elder/Mentor or SP-5 standing; a mentor may not assess their own mentee's readiness **[S-D: Part 13 §13.6]** |
| **Contribution records and credentials for students** | **Yes — and this is Door 2's core value** | **[S-C: H-09, H-10]**; externally checkable; honest scope **[S-C: §25.3]** — no exaggeration of what was done |
| **Research collaboration** | **Yes** | Aggregate, de-identified, consent-scoped, documented protocol; **access not conditional on tone (Rule E-84)** **[V]** |
| **Campus chapters or student branches** | **No, by default** | A chapter is an organisational unit with a brand, a leadership and a recruitment incentive — all three of which Rule E-121 and BR-9 constrain. **Any exception requires a recorded justification, a named adult role-holder accountable for safeguarding, and no separate mark** |
| **Placement or internship promises** | **No** | The organisation cannot promise what an employer decides; a credential is portable evidence, not a placement |

## 28.3 The honest limit

**[A]** **[X-inherited]** NSS reaches roughly 3.8–3.9 million volunteers — around 5–6% of India's student population — which demonstrates both that mass youth service participation is achievable and that it reaches only a small share, and that it is **time-bound to student life**. **[I]** The education interface therefore produces a **flow**, not a **stock**: capable people arrive, contribute for a bounded period, and leave. **[A]** That is not a failure to be fixed. **The correct design response is to make the exit valuable** — a portable, externally checkable credential that the person carries into employment — rather than to attempt retention the lifecycle does not support. **[S-C: H-10]** and **[S-ST: §19.2 claim 3]** already identify this as the architecture's most valuable and least developed asset.

---

# PART 29 — LOCAL MEDIA

## 29.1 What local media may report, and on what basis

**[P]** Brief §52. Local media are the highest-value and highest-risk channel: **they are the only channel that reaches the people whose opinion actually determines local legitimacy, and they are the channel least able to verify a claim.**

| Subject | What may be provided | Evidence standard | Constraint |
|---|---|---|---|
| **A project** | Locality, dates, what was done, what it cost, who participated (with consent), the outcome | Project and outcome records **[S: Ch.15, App. F]** | **No beneficiary identity or image (E-34)**; locality attribution mandatory |
| **An outcome** | Resolved / reduced / unchanged / worsened / unknown, with the follow-up date | **[S: Ch.15 step 10; S-C: HM-8]** | **"Unknown" is a reportable outcome and must be reported as such** |
| **An incident** | That it occurred, its class, what was done, the review status | Incident record **[S-A: A-09]** | **No comment on a legal or safety incident without approval [S: App. A §8.x]**; no identification |
| **A correction** | The error, the fact, the change made | Correction log (TS-6) | Published whether or not the media asks |
| **Leadership** | The role, its authority and limits, how to reach it, how to complain | Role records **[S: Ch.9]** | **No personality profile; no photograph-led story; decisions in the organisation's name with the deciding role identified [S-A: A-16 §15.4]** |
| **Accounts** | Money in, money out, worker compensation separately | **[S: Ch.18, Ch.19]** | Plain, no design gloss |

## 29.2 Paid coverage

**[P] Rule E-123 (No Paid Praise; Disclosed Paid Information).** The organisation does not pay for favourable coverage, and does not accept favourable coverage it has paid for without disclosure. **Where payment occurs for the *placement of factual information* — a notice, an obituary-class announcement, a classified advertisement of a public record — the payment is disclosed on the artefact and recorded in the accounts.** **[V]** Paid-news regulation is jurisdiction-specific in India and requires legal validation before any such placement.

**[A]** The reason is not only ethical. **[I]** Paid praise is the fastest route to MC-4 ("an NGO that needs donations") and MC-5 ("a private company"), and it destroys the value of the one claim the architecture can uniquely make — **that its good reports are checkable.** A favourable article nobody paid for is evidence. A favourable article that was paid for is advertising, and once one exists, every subsequent favourable article is suspected.

## 29.3 The local media protocol

| Element | Design |
|---|---|
| **Contact** | A named local role-holder within their domain (Rule E-105), plus a **non-local contact**, published — so anyone uncomfortable with the local one has somewhere else to go **[S-ST: §14.2 Layer 2]** |
| **Response time** | A stated window, published in advance, and met. **A missed window is recorded** |
| **Access** | To records, to sites with consent, and to named contributors **with their consent** — the same access given to any journalist (Rule E-84) |
| **Conditionality** | **None.** Access is never conditional on tone, on review before publication, on approval of copy, or on omission |
| **Corrections** | Requested calmly, with the record, per **[S: Ch.24]**; **and issued by the organisation whether or not requested** |
| **Hostile coverage** | Answered with a record, never with a counter-allegation (Rule E-102(ii)); legitimate criticism preserved (Rule E-109) |

---

# PART 30 — NATIONAL MEDIA

## 30.1 The evidence threshold before any national claim

**[P]** Brief §53: no "national movement" merely because the organisation has a website. **Rule E-124 (National Claims Require National Evidence).** A claim of national scope requires evidence from **more than one state**, or an explicit statement that it does not.

| Claim form | Minimum evidence | Claim-ladder class (Part 31) |
|---|---|---|
| "Operating in [locality]" | A published local record with dated outcomes | **CL-1 / CL-2** |
| "Operating in [city]" | ≥ N validated units in that city, N per the gate, with published accounts | **CL-4** |
| "Operating in [state]" | ≥ N validated cities | **CL-6** |
| "Operating in N states" | Published, dated, per-state unit counts with outcomes | **CL-7** |
| "A national network" | **CL-8 evidence: multi-state validated units, published accounts across all of them, independent verification, exercised succession, resolved entity structure, insurance in force, privacy programme live** | **CL-8** |
| "A national movement" | **PROHIBITED FORM.** A movement implies mass participation and shared identity, neither of which is measurable and both of which Rule E-22 forbids soliciting | **Not available at any stage** |

**[P] Rule E-125 (The Word "National" Describes Capability, Not Reach).** Per Rule E-3, "national" may describe **standards, continuity, specialist supply, escalation routes and published records**. It may not describe **belonging, identity, community or movement.** A sentence of the form "a national community of sewaks" is prohibited at every stage; "a national network of independently operating local teams, whose records are published" is permitted at CL-7 and above.

## 30.2 The national media protocol

| Element | Design |
|---|---|
| **Who speaks** | Authorised spokespersons **by domain and region** (Rule E-104, E-105); sensitive matters require national or relevant approval **[S: Ch.24]**; Safety and Legal involved for CC-1, CC-4, CC-7 |
| **What is released** | Records, not narratives. The claim register entry (Rule E-26) for any claim made |
| **What is withheld** | C3 and C4 content; any identification; speculation on cause; conclusions before determination; **any comment on a political, religious or caste question beyond the published code and record** |
| **Timing** | Fast and factual for emergencies; **never speculative [S: Ch.24]**; a stated window for non-urgent queries |
| **Correction** | Calm, factual, with the record, logged (TS-6) |
| **Follow-up** | Whether the correction or the commitment was honoured, reported at the next reporting date |
| **Exclusivity** | **None.** Records available to one are available to all. Exclusivity converts a public record into a favour |
| **Embargo** | Permitted only where it does not delay a safety, safeguarding or correction publication |

**[P] Rule E-126 (No Exclusive Access, No Pre-Publication Review, No Copy Approval).** Three prohibitions that cost coverage and buy credibility. **[A]** Each is a mechanism by which media access becomes a relationship to be managed, and Rule E-84 exists because managed scrutiny eventually becomes visible.

## 30.3 When national media attention arrives early

**[A]** The most dangerous success at CL-0 or CL-1 is national attention. **The mechanism:**

```
NATIONAL ATTENTION AT CL-0/CL-1
   -> recognition jumps several claim-ladder classes at once (RC-4)
   -> inbound demand exceeds verification and delivery capacity
   -> declines multiply, and each decline is now visible to a national audience
   -> the organisation is asked for national evidence it does not have
   -> it either over-claims (fatal) or says "we are one team" (correct, and disappointing)
   -> attention moves on, leaving elevated expectations and unmet demand
```

**[P] Rule E-127 (The Early-Attention Protocol).** Where national attention arrives before CL-3: **(i)** every statement names the actual scale, in numbers, in the first sentence; **(ii)** the claim ladder is published alongside the statement, so the audience can see what the organisation refuses to claim; **(iii)** no interview is given without the published record being sent first; **(iv)** inbound demand is triaged honestly and the decline rate is published; **(v)** **no expansion, hiring, partnership or campaign is initiated on the strength of attention** — expansion is gated on capacity (Part 58), never on coverage.

**[A]** Item (ii) is unusual and is the point: **publishing the ladder converts a limitation into a demonstration.** An organisation that says "here is what we can claim, here is what we cannot yet, and here is the evidence that would change it" is doing in public exactly what it claims to do in service — showing its working.

---

# PART 31 — NATIONAL CLAIMS

## 31.1 The claim ladder

**[P] Amendment E-29 — CL-0 … CL-8.** Per brief §54. Each stage states what may truthfully be claimed and what may not.

| Stage | Name | Evidence required | **May claim** | **May not claim** |
|---|---|---|---|---|
| **CL-0** | **Concept** | Architecture exists; entity status stated accurately **including what is pending**; no operations | "We are designing and testing a neighbourhood service model"; the four CL-0 sentences (Part 6 §6.3); the "what we are not" list; **the commitment to publish corrections, labelled as a commitment (Rule E-28)** | Any impact, service, scale, trust, reach or national claim |
| **CL-1** | **Pilot** | One team operating MVLS; `H_gov` measured; records being produced | "We are testing this in one locality"; what is being tested; the pilot's stated limits **[S-D: Part 41 §41.5]** | That it works; that it will scale; any outcome claim without follow-up |
| **CL-2** | **Proven local unit** | One full cycle with published accounts, published outcomes **including unchanged and worsened**, zero unresolved serious safety incidents, at least one published correction, a functioning complaint route with a published outcome | "In [locality], over [period], we did X, Y and Z; the outcomes were A, B and C; we got D wrong and corrected it" | Multi-locality anything; replicability; any comparative claim |
| **CL-3** | **Multiple validated units** | ≥ N units in **materially different contexts**, each with CL-2 evidence; **at least one independently verified impact claim** — an external party confirming an outcome | "This has now worked in N localities of these kinds"; the independent verification, named | State or national scope; a model; a movement |
| **CL-4** | **City-level validation** | A city network with shared services operating **[S-B: B-21]**; City divisor measured; expansion gate passed | "Operating in [city], across N localities, with a city-level verification and funds-review function" | Multi-city; national |
| **CL-5** | **Multi-city validation** | ≥ N cities, each at CL-4 | "Operating in N cities in [state]" | State-level institution; national |
| **CL-6** | **State-level validation** | A state layer operating as coordination, not as a formal hierarchy **[S-ST: §2.3]**; language equity demonstrated across the state | "Operating across [state], in these languages" | Multi-state; national |
| **CL-7** | **Multi-state validation** | ≥ N states at CL-6; national standards versioned and locally adapted without drift; succession exercised at multiple levels | "A network in N states, with published records for each" | National coverage; universality; "every Indian" |
| **CL-8** | **National network evidence** | All fifteen **[S-ST: §30.3]** pre-conditions; all ten **[S-ST: §14.3]** trust pre-conditions; **N12 and N13 resolved**; insurance in force; privacy programme live; mission lock executed | "A national network of independently operating local teams whose records, accounts, outcomes and corrections are published" | Anything about trust, love, pride, movement or being India's anything |

**[P] Rule E-128 (The Ladder Is Published).** The claim ladder itself is a public artefact. **Any person can see what the organisation claims, what it refuses to claim, and what evidence would change that.** **[A]** This is the strongest available answer to over-claiming, because it makes restraint *visible* — and visible restraint is itself a trust signal in an environment where every institution over-claims **[S-ST: §30.5 item 3]**: "radical plainness is not modesty — it is the most aggressive differentiation available."

## 31.2 Claim discipline — the six classes

**[P] Amendment E-46.** Brief §197. **Public communication must not blur these.**

| Class | Meaning | May be published? | Required marker |
|---|---|---|---|
| **PROVEN** | Independently verified by an external party, or repeatedly observed with follow-up | **Yes** | Cite the verification and its date |
| **OBSERVED** | Recorded by the organisation, with follow-up, not independently verified | **Yes** | State that it is the organisation's own record |
| **REPORTED** | Stated by a participant, partner or beneficiary, not verified | **Yes, with attribution** | "Reported by…"; never presented as fact |
| **PROPOSED** | A design, standard or intention not yet operated | **Yes, as a proposal** | Labelled `PROPOSED` |
| **UNDER TEST** | Currently being measured; the result is unknown | **Yes — and this is the most valuable class** | State what is being tested, what would count as success, and when the result is due |
| **UNKNOWN** | Not known | **Yes** | **Say so.** "We do not know yet" is a permitted public statement (brief §196) |

**[P] Rule E-129 (Humility Is A Published Category).** "We do not know yet" and "we are testing this" are permitted, encouraged and protected public statements. **No role-holder may be criticised, corrected or overruled for making one, and no communication may be revised to remove one.** **[A]** Reason: an organisation that cannot say "unknown" in public will eventually say something false in public instead, and the false statement will be the one that is remembered.

## 31.3 Evidence labels on public dashboards

**[P]** Brief §198: distinguish **measured · estimated · self-reported · independently verified · pending** — without overwhelming ordinary citizens.

**[P] Rule E-130 (Five Labels, Plain Words).** Every public figure carries one of five plain-language labels:

| Label | Public wording | Meaning |
|---|---|---|
| **Measured** | "We counted this" | Directly recorded and reconciled |
| **Estimated** | "We worked this out" | Derived, with the method stated |
| **Self-reported** | "They told us" | Not verified; attribution shown |
| **Independently verified** | "Someone else checked this" | External confirmation, named where consent permits |
| **Pending** | "We don't know yet" | Follow-up not complete; **the date it is due is shown** |

**[A]** "Pending" with a due date is the most important of the five, because it converts an absence of information into a commitment — and a commitment that is later reported against is exactly the mechanism by which TS-6 and Rule E-88 stay non-empty.

## 31.4 Service proof — what "we helped X" requires

**[P]** Brief §120. A public service claim requires **all five**:

| Element | Requirement | Source |
|---|---|---|
| **Activity record** | What was done, where, when, by which roles | **[S: Ch.8, Ch.15]** |
| **Outcome** | Resolved / reduced / unchanged / worsened / unknown | **[S: Ch.15 step 10]** |
| **Verification** | Verified by a role other than the performer; **out-of-team where available** | **[S: Ch.18; S-D: SP-3]** |
| **Privacy protection** | No identification; small-cell suppression; consent where any personal element appears | **[S-A: A-17…A-20]**; Rule E-99 |
| **Follow-up** | The outcome was checked after the fact, and the check is dated | **[S: Ch.15; S-C: HM-8]** |

**[P] Rule E-131 (No Claim Without Follow-Up).** A service claim made before follow-up is a **plan claim**, and must be labelled as one: "we did this; we do not yet know whether it worked; we will report on [date]." **[A]** This is **[S: Ch.15]**'s "do not count planned activities as completed impact" applied to publication, and it is the rule that makes the organisation's claims more informative than a press release — because a press release never says what happened next.

## 31.5 No fake impact

**[P] Rule E-132.** Explicitly prohibited, absolutely, at every level, with no exception:

| Prohibited | Detection |
|---|---|
| **Inflated beneficiary numbers** | Reconciliation against intake and follow-up records; distribution monitoring |
| **Duplicate cases** | De-duplication at intake; audit sampling **[S: App. A §18.3]** |
| **Staged photographs** | Editor rejection authority **[S: App. A §8.x]**; consent record cross-check; **CI-14** |
| **Fabricated testimonials** | Attribution to a named, consented person or not published at all |
| **AI-generated fake beneficiaries, images presented as real, or synthetic evidence of real service** | Rule E-133 below |
| **Misleading before/after claims** | Editor duty: "ensure before/after evidence is not misleading" **[S: App. A §8.x]** verbatim; same-angle, same-season, same-scope requirement |
| **Counting planned activity as completed impact** | **[S: Ch.15]**; Rule E-131 |
| **A total without a locality or date** | Rule E-27; PLR-3 |

**[A]** The consequence of a single proven instance is disproportionate and should be stated: **[I]** the organisation's entire differentiation is verifiability **[S-ST: §19.2 claim 1]**. **One fabricated image does not reduce its credibility by one image's worth; it removes the basis on which every other claim was believed.** This is the reason Rule E-132 admits no exception for a good cause, a compelling story or a fundraising need.

## 31.6 AI-generated content

**[P]** Brief §122. **Rule E-133 (Disclosure And Absolute Prohibition).**

| Situation | Rule |
|---|---|
| **AI-generated or AI-assisted image, video, audio or narration used in any public artefact** | **Disclosed on the artefact itself**, in plain language, in the artefact's language |
| **AI-generated image presented as depicting a real event, person or place** | **PROHIBITED absolutely.** No exception |
| **Synthetic media used as evidence of real service** | **PROHIBITED absolutely** — and is a **fabrication** under Rule E-132, not a disclosure question |
| **AI translation of an LA-1, LA-3-legal or LA-5 text** | **Prohibited from publication without named human review** (Rule E-68) |
| **AI drafting of a public statement** | Permitted as a drafting aid; **the reason and the decision are a human's [S-D: §30.2; S: Const. Art.12]** |
| **AI-generated summary of records** | Permitted where the underlying records are published and inspectable |
| **AI sentiment analysis of public comment** | **Heavily constrained:** aggregate only, no individual profiling, no identity inference, no political or religious classification **[S-A: A-01 N8; A-18]**; and it may never determine a response to a person |
| **AI impersonation of a real person, including a member, leader or beneficiary** | **PROHIBITED absolutely** |
| **AI targeting of a vulnerable group for persuasion** | **PROHIBITED absolutely** — brief §123 |
| **AI making a final reputation, communication or crisis decision** | **PROHIBITED** — **[S: Const. Art.12]**: AI cannot autonomously make consequential decisions |

**[A]** The disclosure rule is weaker than it looks and the prohibition rule is stronger. **[I]** Disclosure of AI-generated decorative imagery will become routine and unread; the load-bearing control is that **no synthetic media may ever occupy the evidential position** — the place in an artefact where a reader would otherwise be looking at proof.

---

# PART 32 — NATIONAL GROWTH FLYWHEEL

## 32.1 The reputation flywheel, in the only permitted order

**[P] Amendment E-30.** Brief §56: **real service → verified outcome → trust → participation → more capability → better service → stronger evidence → reputation.** The prohibited reversal is **brand → publicity → membership → hope that service follows.**

```
PERMITTED                                      PROHIBITED

REAL SERVICE                                   BRAND
    |                                             |
    v                                             v
VERIFIED OUTCOME                             PUBLICITY
    |                                             |
    v                                             v
TRUST (conferred by others)                   MEMBERSHIP
    |                                             |
    v                                             v
PARTICIPATION                                "HOPE THAT SERVICE FOLLOWS"
    |                                             |
    v                                             v
MORE CAPABILITY                              DEMAND EXCEEDING CAPACITY
    |                                             |
    v                                             v
BETTER SERVICE                               DECLINES AND FAILURES
    |                                             |
    v                                             v
STRONGER EVIDENCE                            REPUTATION COLLAPSE
    |
    v
REPUTATION  ->  (returns to REAL SERVICE with more capacity)
```

**[A]** The two diagrams differ in one respect that determines everything: **the permitted loop's output is capacity, and the prohibited loop's output is demand.** Capacity makes the next turn easier; demand makes it harder. **A flywheel that produces demand rather than capacity is not a flywheel; it is a debt.**

**[P] Rule E-134 (No Stage May Be Skipped Forward).** Reputation may not be built before evidence; evidence before outcomes; outcomes before service; service before capability; capability before participation. **Where a stage is skipped, the skip is recorded as a risk in the Part 70 register with its stage and its reason** — on the model of **[S-D: Rule D-110]**, a deferred control is a recorded risk.

## 32.2 The growth flywheel

**[P]** Brief §57: **local proof → community trust → participation → capable people → stronger local unit → repeatable model → adjacent locality → city network → state network → national network.** Transitions requiring validation are marked.

| Transition | What must be true | Validation required | Gate |
|---|---|---|---|
| **Local proof → community trust** | Outcomes published and follow-up completed; declines delivered well | None — it is observed, not validated | — |
| **Community trust → participation** | PLR exists; two ungated actions work; first-win conditions met | None | **GATE E1** |
| **Participation → capable people** | Development and delegation actually occur; **[S-D: LM-14]** pipeline has throughput | **Yes — [S-D: L-12, L-22]** | — |
| **Capable people → stronger local unit** | `H_gov` inside `σ_max`; four capabilities routed; SS-4 on mandatory roles | **Yes — [S-B: §26; S-D: Rule D-33]** | — |
| **Stronger unit → repeatable model** | The playbook lets a non-holder perform the function (**[S-D: CT-B]**); the model has been documented, not just done | **Yes — replication evidence [S-C: HM-15; S-B: §30 Stage 6]** | **GATE E4** |
| **Repeatable model → adjacent locality** | **XG-1…XG-8 all pass, including XG-2 (a named SS-4 successor for the sponsor) and XG-8 (no existing unit falls below continuity cover)** | **Yes — [S-D: Rule D-43, Rule D-44 expansion recorded as a cost]** | **GATE E4** |
| **Adjacent localities → city network** | City shared services operating; City divisor measured; **out-of-team assessment capability exists** | **Yes — [S-B: B-21; S-D: Rule D-45, Rule D-91]** | **GATE E5, GATE E6** |
| **City network → state network** | `H_gov_per_team(K)` measured across a range of `K` and **sub-linear or mitigated**; state-level legal review complete **[V]** | **Yes — [S-D: Rule D-91] gates state formation on measuring the divisor** | **GATE E6** |
| **State network → multi-state** | Language equity demonstrated; standards versioned without drift; succession exercised at multiple levels | **Yes — [S-ST: §30.3 items 10–14]** | **GATE E7** |
| **Multi-state → national network** | All ten **[S-ST: §14.3]** and all fifteen **[S-ST: §30.3]** pre-conditions; **N12 and N13 resolved** | **Yes** | **GATE E7 + Rule E-60** |

## 32.3 The word-of-mouth question

**[P]** Brief §36: what actually causes people to recommend an organisation? **Not branding.**

| Cause | Does it operate here? | Instrument |
|---|---|---|
| **A useful experience** | **Yes — and it is the only one that is necessary** | FW-1…FW-6; the help win; the verification win (Rule E-83) |
| **A visible outcome** | **Yes** | PLR-3; the dated result board |
| **Trust that the record is true** | **Conditionally — requires publication** | TS-1…TS-14; Rule E-19 |
| **Respect — being treated as an agent, not a target** | **Yes, if Rule E-13, E-85 and E-86 hold** | No conversion pathway; every stage a destination |
| **Belonging** | **Yes, locally** | HM-3; the paired task; local ownership of problem definition |
| **Convenience** | **Yes, if the human route exists** | Rule E-72 |
| **Identity — "this is what people like me do"** | **Deliberately not cultivated** | Rule E-7 additive participation; Rule E-22 national connection never solicited |
| **Contribution — "I made this"** | **Yes — the strongest cause available** | The portable contribution record **[S-C: H-09]**; **HM-6** "can they say what they did?" |
| **A reward for recommending** | **PROHIBITED** | Rule E-24 |

**[A]** **[S-ST: §22.2]** examined whether "the 'I know someone who helped me' effect can be an organic growth engine." **[A]** The finding that matters for communication: **word of mouth is an output of the service, not a channel of the communication function, and it cannot be purchased, incentivised, campaign-managed or targeted.** The only thing Communications can do about word of mouth is **make sure the thing being talked about is true, checkable and worth saying.**

**[P] Rule E-135 (No Referral Mechanism).** No referral code, invite link, share incentive, ambassador programme, member-get-member scheme, referral leaderboard or introduction reward may exist in any form, at any level, for any purpose. **[S-C: H-21]** anti-MLM compensation firewall; **[S-D: Rule D-118]**; Rule E-24. **[A]** The prohibition extends to non-monetary referral incentives — recognition, priority, standing, badge or "top referrer" — because **[S-C: MLM-1…MLM-7]**'s concern is the *structure*, not the currency.

---

# PART 33 — REPLICATION

## 33.1 What must be copied exactly, and what may adapt

**[P] Amendment E-31.** The brief supplies candidate lists and instructs that final classifications not be invented without analysis. **[A]** The analysis is already largely done: **[S-ST: §12.1]** gives eight immutable and ten localisable items; **[S-D: INV-1…INV-20 and ADAPT-1…ADAPT-12]** give twenty invariants and twelve adaptable items. **v1.3-E adds only the communication-and-identity layer, and does not contradict either.**

**MUST REPLICATE EXACTLY — communication and identity layer:**

| # | Item | Source | Why exact |
|---|---|---|---|
| **R-1** | The eight immutable items — doctrine, protection DO-NOTs and intervention sequence, financial priority order and segregation, membership verification gates, AI doctrine, privacy/min-data/dignity rules, political and religious non-alignment, evidence standards | **[S-ST: §12.1]** | "short enough to be memorised" |
| **R-2** | The category sentence — **meaning**, not wording | **[S-ST: §18.3 item 1]**; terminology register | Divergent meanings make the security boundary unenforceable **[S-C: §30.1 item 3]** |
| **R-3** | The "what we are not" list | **[S-ST: §18.3 item 2]** | The four Severe misclassifications are the same everywhere |
| **R-4** | The claim ladder and claim classes | Part 31 | A claim made in one locality binds the whole |
| **R-5** | The prohibition set: no fake impact, no earnings claim without local funded reality, no endorsement, no referral mechanism, no vanity metric as evidence, no trust claim, no emotional register | Rules E-9, E-24, E-86, E-90, E-106, E-111, E-120, E-132 | These are the rules whose violation in one place damages every place |
| **R-6** | The visual constraints — V1…V8, BR-1…BR-12, Rule E-61 colour reservation, Rule E-65 four permitted surfaces | **[S-A: A-06; Part 12, Part 13]** | A uniform in one state is a uniform everywhere in the public eye |
| **R-7** | The mandatory translation set and the machine-translation control chain | Rules E-66, E-68 | A rights text that is wrong in one language is wrong |
| **R-8** | The public complaint route reaching outside the locality, and the public verification channel | **MVLS-9; [S-ST: §14.2 Layer 2]** | These are the two national protections a stranger relies on |
| **R-9** | The public correction log and the refusal log | TS-6, TS-8, Rule E-88 | Absence in one place undermines the claim everywhere |
| **R-10** | The beneficiary-dignity and consent rules | Part 38; **[S-A: A-19; S: App. F]** | Not adaptable under any circumstance |

**MAY ADAPT — communication and identity layer:**

| # | Item | Constraint on adaptation |
|---|---|---|
| **R-11** | Wording, register, tone, metaphor, humour, formality | Meaning fixed; registered per language and per state |
| **R-12** | Local colour and motif within national mark rules | **[S-ST: §12.1 item 7]**; Rule E-61 colour reservation; **[V]** per-state political association **[S-C: H-26 field 11]** |
| **R-13** | Story selection, story form and storyteller | **E-34** attribution grammar; consent; no beneficiary exposure |
| **R-14** | Recognition wording and local recognition ritual | **[S-C: H-13]** six ritual tests; **[S-A: A-16 §15.4]** honour contribution and the neighbourhood, never a person's position; guest never patron |
| **R-15** | Channel mix — where the locality actually is | Rule E-79: a paper sheet is a complete implementation, not a degraded one |
| **R-16** | Meeting form, venue and timing | Reviewed for who can attend (CN-2) |
| **R-17** | Service mix and calendar | Immutable items 1–8 unchanged; **multi-festival calendar (Rule E-36)** |
| **R-18** | Role names | **Function fixed, word local [S-ST: §12.1 item 10]**; a word with a caste or partisan referent is refused and the refusal is registered (Rule E-45) |
| **R-19** | Partner set | Activity-scoped, separately branded, non-exclusive, documented |
| **R-20** | Event style and community expression | No oath, salute, uniform, portrait, founder date, loyalty ceremony (**[S-D: §21.7; S-C: H-13]**) |

**[P] Rule E-136 (Adaptation Runs Through The Register, Not Through Discretion).** Every adaptation is recorded in the terminology register or the versioned standards library **[S-A: A-15 M2/M3]** with a reason, and is inspectable by any member. **An unrecorded adaptation is drift** — **[S-D: ML-3]** standard drift, and **[S-ST: F-31/F-13]**.

## 33.2 What replication actually replicates

**[A]** The critical distinction, and the one most often got wrong:

| Replicated | Not replicated |
|---|---|
| **The standard** | The outcome — a new locality's outcomes depend on its own conditions |
| **The record schema** | The record's content |
| **The playbook** **[S-D: PB-1…PB-10]** | The people |
| **The gate criteria** | The gate results |
| **The claim rules** | The claims |
| **The training** | The capability — which requires time, practice and assessed delegation |
| **The mark** | The trust — which is produced locally, person to person, and takes as long in the tenth locality as in the first |

**[P] Rule E-137 (Replication Does Not Transfer Trust).** A new locality starts at **CL-0 locally**, whatever the national stage. **It may reference the network's published record; it may not borrow the network's standing.** **[A]** This rule has a real cost and it is stated: **it means the tenth city's first team is as unknown as the first city's first team was, and national scale buys it nothing except capability.** That is correct, and it is also why "national capability deployed locally" (Rule E-55) is the only legitimate benefit of scale — a specialist, a verifier, a float, a trainer, an escalation route are worth something on day one; a logo is not.

## 33.3 The replication test

**[P]** A model is repeatable when **all five** hold, and **[S-C: HM-15]** plus **[S-B: §30 Stage 6]** provide the evidence:

| # | Test | Evidence |
|---|---|---|
| **RT-1** | A person who was not there can operate it from the playbook | **[S-D: CT-B]** — a non-holder performs a defined function from the playbook alone |
| **RT-2** | It worked in a **materially different** context | ≥ 3 contexts: urban, small town, rural **[S-ST: §30.3 item 10]** |
| **RT-3** | The economics held — `H_gov` inside `σ_max`, priority 1 paid on time | **[S-B]**; **[S-D: LM-12, LM-13]** |
| **RT-4** | The people were produced locally, not imported | **[S-D: LM-14]**; the trainer and verifier supply is local or City-routed |
| **RT-5** | The published claims from the replication are at the same class as from the original | Part 31; the claim register |

---

# PART 34 — ONE INDIA / MANY INDIAS

## 34.1 Method

**[P]** The brief requires investigation of radically different environments **without stereotypes, focusing on structural differences**. **[A]** Part 10 §10.3 fixed ten structural variables. This Part applies them to eleven environment types. **No community, state, region, caste, faith or group is characterised anywhere in this table. Where [S-ST: §12.2] offers illustrative generalisations, they are cited as [S-ST] and retain that source's own marking: hypotheses for field testing, not claims about any community.**

## 34.2 The structural variance register

| Environment | Density / settlement | Literacy & device access | Existing civil-society density | Income rhythm | Migration | Political saturation | Distinct legal regime | Time scarcity of the able | Scrutiny expectation | Local purchasing capacity | **Consequence for the identity and communication architecture** |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **Major metropolitan** | Very high, anonymous | High | **High — RWAs, mandals, NGOs, resident groups** | Salaried, monthly | Moderate | Variable | No | **Very high** | Medium | High | **Belonging design matters more than anywhere [S-ST: §12.2]; Specialist and Contributor tiers carry the unit [S-ST: §9]; the "complement, never rival" rule is hardest here because existing bodies are numerous and organised** |
| **Tier-2 city** | High, semi-acquainted | High | Medium-high | Mixed salaried and informal | Moderate | **Often high** | No | High | Medium-high | Medium | **The most realistic first-expansion environment [S-ST: §2.2 "the most realistic level"]; recognition is highly motivating and highly political — apply [S-A: A-16 §15.4] strictly** |
| **Small town** | Medium, **everyone knows everyone** | Medium-high | Medium | Mixed | **High, seasonal** | **High** | No | Medium | **High** | Low-medium | **Verification is cheap, independence is expensive [S-ST: §12.2] — out-of-team assessment (Rule D-45) is hardest here and matters most; a single incident is known to the whole town within hours, so CC-8 timing is immediate** |
| **Rural region** | Low, dispersed | **Low; device access constrained** | Medium — panchayat, cooperatives, faith bodies | **Agricultural, seasonal** | **High** | Variable | No | Medium | Medium | **Low** | **Voice, paper and human routes are primary, not fallback (Rule E-72, AX-D); weekly payment cycles may not match income rhythms [S-ST: F-06]; scheme connectivity is information only, never brokerage (Rule E-114); paused status is a necessity, not a nicety** |
| **Tribal / community context** | Low | Variable | **Strong existing self-governance** | Variable | Variable | Variable | **Frequently — distinct land and forest regimes** | Medium | **High, and rightly** | Low | **State-level and area-specific legal review is mandatory before any activity [V]; enter only through existing community governance, never parallel to it; language may be non-scheduled — LA-4 applies absolutely and no national artefact may assume a scheduled language** |
| **Industrial area** | High around the workplace | Medium-high | Low-medium — unions, welfare bodies | **Shift-based** | **Very high** | **High** | No | **Extreme — shifts** | Medium | Medium | **Participation windows must follow shifts, not days; the workforce is transient, so paused status and contribution portability (Part 54) are the load-bearing instruments** |
| **Agricultural region** | Low | Variable | Medium | **Crop-cycle** | **Seasonal** | Variable | No | Seasonal | Medium | Low | **The calendar is the crop calendar (R-17); recognition timing follows harvest, not quarters; a "quarterly" public report is meaningless here and must be supplemented by a seasonal one** |
| **Coastal context** | Variable | Variable | Medium | **Fishery/monsoon-dependent** | Seasonal | Variable | **Coastal-zone and fishery regulation [V]** | Seasonal | Medium | Low-medium | **Disaster preparedness and response adjacency is real and raises CC-1 and CC-7 exposure; service priorities are monsoon-shaped; PPE (life jackets) is task-specific and never identity [S-A: A-06 V7]** |
| **Hill region** | Very low, dispersed | Variable | Medium | Variable | **High** | Variable | **Frequently — land, tenancy, permits [V]** | Medium | Medium | Low | **Distance makes City routing expensive and slow, so `H_gov_per_team(K)` behaves differently; a single team may be the only organisation for many kilometres, which raises MC-10 parallel-government risk** |
| **Digitally connected locality** | Any | High | Any | Any | Any | Any | No | Any | **High** | Any | **Digital channels can carry PLR and verification; but Rule E-79 still requires the paper equivalent, and Rule E-119 still forbids platform dependence** |
| **Digitally limited locality** | Any | **Low** | Any | Any | Any | Any | No | Any | Any | Any | **Every process must be human-routed (Rule E-72); no app, no account, no online form may be a required step; LA-5 emergency text must be pre-positioned in voice form (Part 14 §14.5)** |

**[A]** The register produces three findings:

**Finding 1 — The binding variable is not wealth or literacy; it is *independence cost*.** Dense, acquainted environments (small town, rural, industrial) make verification cheap and independent assessment expensive. Sparse environments make both expensive. **[I]** Since **[S-D: ES.5]** identifies independent assessment as the leadership system's largest unresolved weakness, **the environments where the organisation will find it easiest to be trusted are the environments where it will find it hardest to be fair.** That is a structural irony and it is recorded rather than resolved.

**Finding 2 — Every environment has a distinct *first* publication requirement.** Rural and digitally limited: voice and paper. Metro: belonging design and a public record. Small town: immediate CC-8 timing. Tribal and hill: legal review before anything. Coastal: disaster-adjacent boundaries. **A single national communication template is therefore not merely suboptimal; it is wrong in eleven different ways.** Rule E-50's local-by-default is the answer.

**Finding 3 — `H_gov_per_team(K)` cannot be a single function.** Hill, coastal and rural dispersion make City routing slower and dearer per team. **[S-D: Rule D-91]** already requires the divisor to be measured before State formation; **[P] Rule E-138** extends it: **the divisor must be measured per environment type, and a state-level structure may not be authorised on the basis of a divisor measured only in one environment type.**

## 34.3 What does not vary

**[A]** Across all eleven environments, the following are identical: the eight immutable items; the claim ladder; the prohibition set; V1…V8 and BR-1…BR-12; the mandatory translation set; the beneficiary-dignity rules; the public complaint route reaching outward; the correction and refusal logs. **[P] Rule E-139: no environment type is exempt from any R-1…R-10 item, for any reason, including cost, distance, custom or urgency.**

---

# PART 35 — NATIONAL CULTURE

## 35.1 Does the organisation need a shared culture?

**[A]** **[S-ST: §15.1–15.4]** examined this: the culture the architecture *implies*, culture to encourage expressed as **observable behaviours rather than adjectives**, culture that must be prevented with tripwires, and "how culture is actually transmitted (the honest answer)". **[S-ST: §15.4]**'s honest answer governs: **culture is transmitted by what is rewarded, what is tolerated and who is selected — not by what is written.**

**[P] Rule E-140 (Culture Is Transmitted By Consequence, Not By Statement).** Any cultural principle the organisation wishes to hold must be attached to: **a record** (so it can be observed), **a consequence** (so it is rewarded or corrected), and **a selection effect** (so people who hold it are chosen). **A principle with none of the three is a poster.**

## 35.2 The nine candidate principles, made observable

**[P]** The brief supplies nine. Each is converted to a behaviour with a record and a tripwire — **[S-ST: §15.2, §15.3]**'s method.

| Principle | Observable behaviour | Record | Tripwire — culture that must be prevented |
|---|---|---|---|
| **Service** | A need was met, or honestly declined with an alternative, inside the stated window | Intake, outcome and follow-up records **[S: Ch.8, Ch.15]** | **Saviourism** — "we gave them" (NEF-2); service performed where it is visible rather than where it is needed (**[S-D: GF-3]**) |
| **Dignity** | Nobody was exposed, photographed, ranked, shamed or made grateful | **HM-13** reported by beneficiaries separately; consent records; Editor rejection log | **Poverty voyeurism**; before/after imagery; testimony extraction |
| **Reliability** | Promises made were kept, or the failure was reported | **HM-14**; TS-2 outcomes including unchanged and worsened | **Over-promising at intake**; the promise-size inflation **[S-C: HM-14]** warns about |
| **Responsibility** | Decisions were recorded with reasons a stranger could follow | **M1 [S-A: A-15]**; **[S-D: LM-3]** | **Reason-free decision-making**; "as discussed" |
| **Humility** | "We do not know yet" was published; a correction was issued; a limitation was stated before a claim | TS-6 correction log; TS-14 what is being tested; Rule E-129 | **An empty correction log across a reporting period (Rule E-88)** |
| **Evidence** | Claims carried their class and their label | Claim register (Rule E-26); **CI-8** traceability | **Any claim without a record**; any PROVEN label without external verification |
| **Discipline** | Boundaries were held under pressure — a refusal was logged, a stop-work was called, a DO-NOT was observed | Approach register; incident records; **[S-D: Q2 refusals]** | **A zero-refusal record in a locality where approaches occur [S-A: A-16 "a zero count is a warning sign"]** |
| **Cooperation** | Existing local bodies were partnered with, not displaced | Partnership register; **CI-11** queries | **Rivalry with an RWA, school, PHC or faith body (Rule E-96)** |
| **Learning** | A failure produced a lessons entry with a "did it work" column and a standard change | **M5, M3 [S-A: A-15]** | **A lessons entry with no standard change; a standard change with no follow-up** |

## 35.3 Where shared culture becomes conformity

**[P]** Brief §138. The boundary, stated as a test:

| Shared culture | Conformity |
|---|---|
| A behaviour is expected **and the expectation is attached to a record and a consequence** | A behaviour is expected **and deviation is read as a character judgement** |
| The principle is stated as an observable act ("report the failure") | The principle is stated as a disposition ("be committed") |
| Disagreement with the principle is possible through the change-request route **[S-A: A-15 M3]** | Disagreement is treated as disloyalty |
| Local expression of the principle varies and is legitimate | One local expression becomes the unmarked national norm (**RS-1**) |
| A person may leave with dignity and their record intact **[S-C: H-17, H-18]** | Leaving is described as a loss of loyalty |
| **The dissent count is non-zero and published [S-A: A-16 test 3]** | **The dissent count is zero** |

**[P] Rule E-141 (The Conformity Tripwire Is The Dissent Count).** A shared culture is healthy while people successfully disagree with it through the formal route and remain in good standing. **A zero dissent count is the tripwire**, on **[S-A: A-16]**'s own logic — and the count is published annually (TS-series; **[S-D: Rule D-94]**).

## 35.4 What the organisation must never do culturally

| Prohibited | Source |
|---|---|
| Describe leadership as a higher form of service | **[S-C: §8.4]**; **[S-D: INV-6]** |
| Require or expect any religious, political or ideological agreement | **[S-A: A-01 N8; A-05 clause 2]** |
| Use prescriptive *seva* language ("a true sewak would…") | **[S-C: §30.4 item 3]**; Rule E-38 |
| Create an inner circle, a private channel of leadership communication, or an unrecorded advisory group | **[S-D: Rule D-41 no shadow authority]**; **[S-ST: §16.1]** |
| Observe any individual's personal dates as organisational festivals | **[S-A: A-16 §15.4]** |
| Display a portrait in an organisational space | **[S-A: A-16 §15.4]** |
| Require a uniform, a greeting, a salute, an oath or a pledge | **[S-A: A-06 V1…V3]**; **[S-D: §21.7]**; **[S-C: H-13]** |
| Rank people ordinally in any medium | **[S-C: SR-2]**; **[S-D: Rule D-66]** |

---

# PART 36 — SHARED PRACTICES

## 36.1 The test applied to every candidate practice

**[P]** Brief §63 requires every proposal to be **tested for burden**. **[S-D: Rule D-40]**'s body-justification test is applied to practices: *what decision or outcome does it produce, who would otherwise produce it, and what happens if it is abolished?*

| Candidate practice | Outcome it produces | Who else produces it | If abolished | Burden | Verdict |
|---|---|---|---|---|---|
| **After-action review** | A lessons entry with a "did it work" column | Nobody | The same failure recurs | **Low — three lines [S-D: Rule D-99]** | **ADOPT — already required by [S-A: A-15 M5]** |
| **Service reflection** | The team states what it learned about the locality | Partially — the playbook PB-7 known-failures | Local relational knowledge is lost | **Low** | **ADOPT, merged into the after-action review rather than as a separate event (Rule E-142)** |
| **Recognition** | Contribution acknowledged | Anyone, to anyone — appreciation is free **[S-C: §23.1 instrument 1]** | Nothing | **Zero if absolute; high if comparative** | **ADOPT in absolute form only [S-C: §44.3; S-D: Rule D-66]** |
| **Local reporting** | PLR-3 refreshed monthly | Nobody | The public record goes stale; the trust signal disappears | **Low — [S: Ch.24] monthly cadence already exists** | **ADOPT — it is the publication of an existing record** |
| **Learning exchange between localities** | A local solution becomes documented knowledge, then training, then reusable capability (brief §192) | Nobody | Each locality re-invents; **the principal national network effect is lost** | **Moderate** | **ADOPT from CL-3; not before, because at CL-1 there is only one locality** |
| **Annual national assembly of local representatives** | Standards review; published corrections; "three things the ground told us" | Nobody | Standards drift; the centre stops hearing the ground | **High — travel, time, translation** | **ADOPT from CL-5 as a working assembly, never as a rally [S-ST: §12.3 item 3]; and only where it satisfies Rule E-56** |
| **Annual service day** | A single coordinated day of service | Nobody | — | **High — coordination, safety, communication, and a crowd** | **NOT ADOPT BY DEFAULT — see §36.3** |
| **Shared greeting, chant, song or ritual** | Belonging | — | — | Low | **REJECTED — [S-C: H-13] six ritual tests; [S-A: A-05 clause 6]; NEF-3 conformity** |
| **Founder day, founder quote, founder address** | — | — | — | Low | **REJECTED — [S-A: A-16 §15.4]; [S-D: CU-1…CU-10]** |

**[P] Rule E-142 (One Event, Not Two.)** Where two candidate practices produce overlapping outcomes, they are merged and the merger is recorded. **[A]** Applied reflexively: this Part rejects three practices and merges two, and the burden saved is the reason the adopted set is affordable inside `σ_max`.

## 36.2 Shared practice as the national binding mechanism

**[A]** The finding of Part 11 was that national identity should be **epistemic rather than affective** (Rule E-57). Shared practices are the mechanism: **a person in Madurai and a person in Moradabad have nothing in common except that both wrote a lessons entry, both refreshed a public local record, both held a boundary under pressure, and both can show you the record.**

**[P] Rule E-143 (Shared Practice, Not Shared Experience).** National consistency comes from **practices that produce records**, not from events that produce feelings. **A practice that produces a record scales; an event that produces a feeling does not, and its absence is felt as exclusion by everyone who could not attend.**

## 36.3 The annual service day, tested

**[P]** Brief §66 requires that a national service day not be adopted automatically. Six tests:

| Test | Finding |
|---|---|
| **Purpose** | Ostensibly: coordinated service. **Actually: a communication event with a service component.** The service would happen anyway; the coordination exists for visibility |
| **Participation** | Requires simultaneous action across localities, which requires a communication capacity the organisation does not have below CL-5 |
| **Cost** | High: coordination, safety planning, translation, media handling, and **crowd management — which engages [S-A: A-01 N3]'s prohibition on "crowd mobilisation capable of being read as political"** |
| **Local adaptation** | A fixed national date collides with local calendars, harvests, monsoons, exams and festivals — **the exact things R-17 makes localisable** |
| **Inclusivity** | A single national day excludes everyone whose shift, care responsibility, season or faith calendar makes that day impossible. **It creates a hierarchy between those who attended and those who did not — which is ordinal recognition by another name** |
| **Evidence** | A one-day spike in activity is the **activity-count gaming vector [S-D: GF-1, AC-1…AC-5]** applied to communication: it produces countable activity without durable outcome, and follow-up after a single day is nearly impossible |

**[P] Verdict: NOT ADOPTED.** **[A]** The alternative is cheaper and produces more: **each locality marks its own service occasion, on its own calendar, when its own work is done — and the national layer publishes the collection.** That is Rule E-143 applied, and it produces the same national pattern without the coordination cost, the exclusion, the crowd risk or the activity spike.

**[P] Rule E-144 (No National Date.)** The organisation adopts no national day, no founding-day celebration, no anniversary event and no fixed national occasion. **Local occasions are legitimate and are published.** **[A]** Reason beyond burden: **a national date is a ritual, and a ritual attached to the organisation rather than to the locality is the first step toward the identity-as-conformity failure (NEF-3) and toward the founder-date prohibition in [S-A: A-16 §15.4].**

---

# PART 37 — STORIES

## 37.1 The story structure

**[S-C: H-14]** — Story Framework, adopted. **[P]** The brief §67 specifies: **Problem → people → contribution → action → outcome → learning.** Extended with the two elements the source requires and the brief's list omits:

| # | Element | Rule | Fails if |
|---|---|---|---|
| **ST-1** | **PROBLEM** — stated by the locality | Immutable item 9: "the neighbourhood decides what its problem is" **[S-ST: §12.1]** | The problem is defined by the organisation, the funder or the centre |
| **ST-2** | **PEOPLE** — who was there | Named only with consent; roles not ranks; **the beneficiary is a person, not a category** | Anyone appears without consent; anyone is described by their need |
| **ST-3** | **CONTRIBUTION** — who did what | **The contributor is the subject of the action sentence** **[S-C: §17.4]** | The organisation is the subject ("we cleaned the lane") |
| **ST-4** | **ACTION** — what was actually done | Verbs, dates, quantities, costs | Adjectives; effort language; "tirelessly", "selflessly" |
| **ST-5** | **OUTCOME** — what changed | **The beneficiary or the locality is the subject of the outcome sentence** **[S-C: §17.4]**; resolved / reduced / unchanged / worsened / unknown | A claim of success without follow-up (Rule E-131) |
| **ST-6** | **LEARNING** — what was wrong, what would be done differently | **[S-A: A-15 M5]** "did it work" | A story with no learning is a press release |
| **ST-7** | **COST** — what it took, in hours and in money | Published accounts; `H_gov` | A story whose cost is invisible invites the belief that this is free and therefore replicable anywhere |
| **ST-8** | **NEXT** — what happens after, and by when | The follow-up date, published | The story ends at the outcome, which is where over-claiming lives |

**[P] Rule E-145 (The Attribution Grammar).** **[S-C: §17.4]**, adopted absolutely: **the beneficiary is the subject of the outcome sentence; the contributor is the subject of the action sentence; and the organisation is the subject of neither.** **"We gave them" is prohibited in every language, in every artefact, internally as well as publicly.**

**[A]** This rule is the whole of anti-saviourism in operational form, and it is grammatical rather than moral — which is why it can be enforced. **An Editor can reject a sentence. An Editor cannot reject a disposition.** **[S: App. A §8.x]** already gives the Editor authority to "reject or return content that is inaccurate, unsafe, defamatory, privacy-invasive or off-brand" and prohibits them from inventing claims, manipulating images dishonestly or suppressing material facts. **Rule E-145 is an addition to the Editor's rejection grounds.**

## 37.2 Local story to national pattern

**[P]** Brief §158. The scaling structure, with the flattening prohibition:

```
LOCAL STORY       one lane, named people (with consent), dates, verbs, costs
   |              told by the people who did it, in their language (LA-4)
   v
CITY PATTERN      N local stories of the same class, aggregated, small cells suppressed
   |              the pattern is about the PROBLEM CLASS, not about the organisation
   v
STATE PATTERN     N city patterns, with the structural variance register (Part 34) shown
   |              so a reader can see WHY the pattern differs between places
   v
NATIONAL PATTERN  the standard changed, the training updated, the lesson carried
                  [S-A: A-15 M2/M3/M5]  --  "national learning", not national glory
```

**[P] Rule E-146 (No Flattening).** A local story may not be rewritten at a higher level. Concretely: **the national layer may cite a local story with its locality, date and consent intact; it may not summarise several local stories into a composite, an archetype, an "example" or a campaign narrative.** **[A]** A composite story is a fabricated story, and Rule E-132 prohibits fabrication. **This rule will make national communication less compelling. That is the intended cost.**

## 37.3 What a story may never be

| Prohibited | Source |
|---|---|
| **A saviour narrative** — the contributor or the organisation as rescuer | NEF-2; **[S-C: PM-1]**; Rule E-145 |
| **Humiliation** — any framing that displays a person's circumstance as a spectacle | Rule E-9 shame prohibition; **[S-A: A-19]** dignity rules |
| **Poverty voyeurism** — detail included for its emotional effect rather than its informational content | Rule E-99 TP-3 harm test |
| **Beneficiary exploitation** — a beneficiary's image, testimony, name or story used as proof, evidence or appeal | Rule E-13; **E-34**; **[S-C: H-22]**; MC-9 |
| **Leader hero worship** — a story whose subject is a leader's qualities | **[S-A: A-16 §15.4]**; **[S-D: CU-1…CU-10]**; NEF-6 |
| **A headquarters hero narrative** — the centre arriving to solve a local problem | Brief §112; Rule E-55; **E-34** locality attribution |
| **A story without cost, learning or next** | ST-6, ST-7, ST-8 |
| **A composite, archetype or illustrative character presented as real** | Rule E-132; Rule E-146 |
| **A story whose publication was requested by a funder, partner or political actor** | Rule E-112; **[S-A: A-01 N6]** |

## 37.4 Who tells the story

**[P] Rule E-147 (The Person Who Did It, Or The Person It Happened To — With Consent).** Stories are told by participants, in their own words, in their own language, and are recorded rather than written for them. **A story written *about* a contributor by the communications function is a report, not a story, and is labelled as such.** **[S-ST: §18.2 MC-9]**: "stories told by participants, not about recipients."

**[A]** This rule has an operational consequence that will be unpopular: **it means the communications function produces fewer, worse-written and more truthful stories.** **[I]** A polished story is almost always a story whose subject was replaced by a writer, and the replacement is where the saviour grammar enters.

---

# PART 38 — BENEFICIARY DIGNITY

## 38.1 The rules

**[P] Amendment E-34.** Built on **[S: App. F]** ("avoid unnecessary beneficiary documents"; "no exposure of minors"; dignity in food service), **[S-A: A-19]** access separation and dignity rules, **[S-A: A-20]** sealed categories, **[S-C: H-22]** beneficiary/recruitment separation, **[S-C: CR-1…CR-4]**.

| Domain | Rule |
|---|---|
| **Consent** | **Specific, informed, recorded, revocable, and never obtained at the moment of need.** Consent to receive help is separate from consent to be recorded, and separate again from consent to be published. **Three consents, three records, three refusals available** **[S-C: CK-1…CK-7]** |
| **Anonymity** | **Default.** Publication of any identifying element requires an additional specific consent, and **is refused absolutely for minors, for victims and survivors, for safeguarding cases, and for anyone whose identification could cause harm (Rule E-99 TP-3)** |
| **Images** | **No image of a beneficiary in any organisational artefact, for any purpose, with any consent, where the image depicts need, distress, poverty, illness, disability, dependency or receipt of aid.** Images of *places, work and results* are permitted with the property-holder's consent. **No image of any minor, ever** |
| **Children** | Absolute prohibition: no image, no name, no identifying detail, no story, no testimony, no case study, no research inclusion, no social artefact. **Anything identifying a minor is C4 sealed [S-A: A-20]** |
| **Vulnerable people** | As for children, plus: no consent taken during or immediately after a crisis; a waiting period before any consent conversation; **and the person may decline without any effect on the help they receive** |
| **Emergency situations** | **No recording of any kind for communication purposes during an emergency.** The only records are the incident record and the safety record **[S-A: A-09]** |
| **Before/after** | Permitted only with: the same location, same angle, same season, same scope; a stated date on both; no person in either; and **the Editor's explicit duty to "ensure before/after evidence is not misleading" [S: App. A §8.x]** |
| **Testimony** | **Never required, never solicited as a condition, never rewarded, and never used as marketing.** A person may give an account voluntarily, in their own words, with consent, and may withdraw it |
| **Data** | Minimum safe pathway (Rule E-80); **[S-A: A-18]** four-branch necessity test; **"avoid unnecessary beneficiary documents" [S: App. F]** |
| **Recruitment** | **Absolutely separated. Rule E-13: no conversion pathway, at any time, in any direction, by anyone** |
| **Gratitude** | **Never requested, expected, staged, photographed or recorded.** Any artefact depicting gratitude is refused |
| **Exit** | A person who received help may ask for their record to be restricted or erased per **[S: Const. Art.6; S-A: A-20 §19.7]**, and doing so has no effect on any future help |

## 38.2 The one rule that governs all of them

**[P] Rule E-148 (The Person Served Is Not Organisational Material).** A beneficiary's need, circumstance, image, story, gratitude or outcome is **not an asset of the organisation** and may not be used to raise money, attract participants, demonstrate impact, answer a critic, brief a journalist, train a member, or decorate an artefact — **except** where the person has given specific informed consent for that specific use, and **never** where the person is a minor, a victim, a survivor or in a safeguarding case.

**[A]** The exception that proves the rule, and the one that will be argued for: **"but the outcome data is essential to prove impact."** It is — and it is available **without the person**: locality, date, problem class, action, cost, outcome state and follow-up date are all publishable, and none of them identifies anyone. **TS-1, TS-2 and PLR-3 are constructed exactly this way.** The impact proof does not require the person; only the emotional appeal does, and the emotional appeal is prohibited by Rule E-9.

## 38.3 Beneficiary → participant transition

**[P]** Brief §32 requires a dignity-preserving pathway. **The pathway is: there is no pathway.**

| Rule | Content |
|---|---|
| **E-13** | No conversion pathway from beneficiary to participant exists in the architecture, at any time, in any direction |
| **If a person who received help later wishes to contribute** | They use the **same door as everyone else** — PLR-5, "help once" — at a later time, **initiated by them**, with no reference by the organisation to the help they received, and with no record linkage between the two |
| **The organisation may not** | Invite them, suggest it, note their potential, record their interest, follow up, thank them in a way that implies reciprocity, or count them as a conversion |
| **The record separation** | **[S-A: A-19]** eight-function access matrix: a contributor's record is not a beneficiary's record. **The two are not linked, joined, cross-referenced or reconciled** |
| **Why** | Because a person in need who believes that helping later is expected of them is not receiving unconditional help. **And because the appearance of a conversion pathway is indistinguishable, to an observer, from its existence** |

**[A]** This is stricter than **[S-C: H-22]** requires and is deliberately so. **[I]** The mechanism the rule prevents is subtle and common: a person is helped, is warmly welcomed, is gently included, is thanked repeatedly, and one day is asked. **No step in that sequence is coercive, and the sequence is coercive.**

---

# PART 39 — ANTI-CULT ARCHITECTURE (COMMUNICATION LAYER)

## 39.1 What already binds

**[S-A: A-16 §15.4]** — public-representation rules, verbatim: decisions announced **in the organisation's name with the deciding role identified, not in a person's name**; publications carry the institution as author, individuals credited for work not for the existence of the institution; ceremonies honour **contribution and the neighbourhood**, never a person's position; **no portrait as an object of display in organisational spaces**; no founder-attribution requirement in decisions; **no observance of any individual's personal dates as organisational festivals**; **many authorised spokespersons by domain and region**; "the founder may of course speak, lead, decide and be credited. **The rule is about dependence, not about visibility.**"

**[S-C: H-19]** Anti-Cult Safeguard Instrument. **[S-C: §45]** local hero and four charismatic-leader guards. **[S-D: CU-1…CU-10]** cult-resistance controls and the four annual tests. **[S-ST: §11.2]** seven instruments that make MISSION > PERSON real. **[S-ST: §16.1]** prohibited mechanisms.

## 39.2 The nine communication-layer cult vectors

**[P] Amendment E-35.** Each vector named in the brief, with its control:

| # | Vector | How it appears in communication | Control |
|---|---|---|---|
| **AC-1** | **Founder images** | A portrait on a page, poster, office wall, report cover, video thumbnail or event backdrop | **[S-A: A-16 §15.4]**: no portrait as an object of display. **Rule E-149: no image of any individual appears in any organisational artefact except where the individual is the subject of their own recorded contribution and has consented — and never on a cover, header, banner or backdrop** |
| **AC-2** | **Founder quotes as authority** | "As the founder says…" used to settle an argument | **[S-ST: §11.2 instrument 4]**: "the *text* becomes the authority" — doctrine is quoted from the published text by members at every level, never only by the founder. **Rule E-150: authority is cited to a document version, never to a person** |
| **AC-3** | **Founder approval as a gate** | "The founder wants…" used to end a discussion | **[S-D: Rule D-92]** Founder Recusal Register; **[S-D: Rule D-93]** the founder may not assess; **Rule E-151: a founder preference is recorded in the register and is a declared interest, not a decision** |
| **AC-4** | **Leader worship** | Praise of a leader's character, sacrifice, vision or destiny in any artefact | **[S-D: CU-3, CU-6]**; **Rule E-152: a person may be credited for work, never described in terms of quality** |
| **AC-5** | **Personality branding** | A leader's name in a programme name, a channel name, a hashtag, a series title or a local team name | **Rule E-153: no organisational artefact, channel, programme, team, project, award or fund may bear a person's name** — including the founder's, including a donor's, including a deceased member's |
| **AC-6** | **Exclusive inner circles** | A private group, an unlisted channel, an "advisory circle", a WhatsApp group that decides things | **[S-D: Rule D-41 no shadow authority]**; **[S-ST: §16.1]**; **Rule E-154: any channel in which organisational decisions are made is a recorded organisational channel, subject to retention, access and audit. An unrecorded decision channel is an incident** |
| **AC-7** | **Private leader communication** | A leader's personal account used for organisational purposes; members messaging a leader directly about organisational matters | **[S-A: A-14 §13.4]** dual custody of communication channels; BR-10; **Rule E-155: no personal account, personal device or personal number is an organisational channel, and no organisational matter is decided through one** |
| **AC-8** | **Personal fundraising** | "Support my work"; a personal donation link; a leader's appeal in their own name | **Rule E-156: all funds flow through the organisational account and the waterfall [S: Ch.18]; no personal solicitation in any organisational capacity; and no organisational artefact may solicit funds in an emotional register (Rule E-9)** |
| **AC-9** | **Leader-controlled information** | A leader who is the only source of a fact, the only channel to a decision, the only person who knows why | **[S-A: A-15 M1…M7]** memory instruments; **[S-D: Part 28]** playbooks; **Rule E-157: every fact published by the organisation is published from a record, so no person is its only source** |

## 39.3 The communication-specific cult test

**[P] Rule E-158 (The Substitution Test).** For any organisational artefact, ask: **could this artefact work equally well if the person it features were replaced by a different person of the same role?** If not, the artefact is about the person, and it is refused.

**[A]** Applied to the four annual tests **[S-A: A-16]**, which are the cult-detection instrument:

| Test | Communication-layer reading | Healthy sign | Warning |
|---|---|---|---|
| **T1 ABSENCE** | Did public communication continue unchanged during a period when the founder or a senior leader was unreachable? | Statements issued by other authorised spokespersons, in the organisation's name | **Every statement in the period carried one person's name or face** |
| **T2 ATTRIBUTION** | What share of published statements, stories and reports attribute outcomes to **roles and localities** rather than to **persons**? | Nearly all | A rising share of person-attribution |
| **T3 DISSENT** | Has any published correction, refusal or disagreement occurred, and is the dissenter still in good standing? | At least one, yes | **Zero. "A zero count is a warning sign, not a clean bill of health" [S-A: A-16]** |
| **T4 SUCCESSOR** | For every public-facing communication role, is there a named, prepared person who could speak? | Yes, at every domain and region | **One spokesperson (CI-13 = 1) — "one is a failure" [S-D: CU-1]** |

---

# PART 40 — ANTI-MLM ARCHITECTURE (COMMUNICATION LAYER)

## 40.1 What already binds

**[S-C: MLM-1…MLM-7]** and **[S-C: H-21]** anti-MLM compensation firewall. **[S-D: Rule D-118]** — no compensation may depend on another person's participation. **[S-D: §36.3]** — no payment, recognition or promotion criterion may reference recruitment or downline size. **[S-A: A-01 N3]** — no crowd mobilisation capable of being read as political.

## 40.2 The communication-layer vectors

**[P]** The compensation firewall is v1.3-C's and v1.3-D's. **v1.3-E adds the vectors that operate through language and imagery, which no compensation rule reaches:**

| # | Vector | How it appears | Control |
|---|---|---|---|
| **ML-1** | **"Build your team"** | Any phrase treating people as something a person builds or owns | **Rule E-159:** the prohibited-vocabulary list. People are **not** "yours", "your team", "your downline", "your network". A role-holder has a **role**, not a following |
| **ML-2** | **Rank and tier language** | "Level up", "unlock the next tier", "reach Gold", "top performer" | **[S-C: SR-2]** no ordinal numbering; **[S-D: Rule D-66]** recognition confers nothing; Rule E-159 |
| **ML-3** | **Income imagery** | Any artefact showing money, earnings, a payment screenshot, a lifestyle, or a person's material improvement as a result of participation | **Rule E-120:** no earnings claim without a local funded reality; **and no earnings imagery at all in any service or participation artefact (Rule E-18)** |
| **ML-4** | **Urgency and scarcity** | "Limited slots", "closing soon", "only N places", a countdown | **Rule E-9** prohibits urgency-without-basis; **where a real capacity limit exists, it is stated as a fact with its reason** ("this task needs four people; three are needed by Saturday") |
| **ML-5** | **Testimonial and success-story culture** | A person describing what participation did for their income, status or life | **[S-C: MLM-6]**; Rule E-147 — a participant may tell their own story about their own **work**, and **never about their earnings or transformation** |
| **ML-6** | **Recruitment framing of service** | "Bring a friend", "share to help us grow", "invite your neighbourhood" | **Rule E-135: no referral mechanism of any kind.** Sharing a **public record** is permitted; sharing an **invitation that credits the sharer** is not |
| **ML-7** | **Growth as the narrative** | Any communication whose subject is the organisation's expansion | **Rule E-160:** the subject of organisational communication is **the work and the locality**, never the organisation's growth. Growth figures appear only in the annual accountability report, alongside closures (TS-13) |
| **ML-8** | **Leader-as-recruiter expectation** | A role-holder assessed or praised on headcount | **[S-D: PG gates exclude team size; LM-14 no target; Rule D-37 density reported never targeted; Rule D-88 no quota]** |

**[P] Rule E-159 (The Prohibited-Vocabulary List).** Registered in the terminology register per language, so translation cannot reintroduce it: **downline, upline, team-building (of people), my members, my network, level up, unlock, tier, rank, top performer, passive income, financial freedom, life-changing, join my team, be your own boss, limited slots, act now, don't miss out, early adopter advantage, ground floor.**

**[A]** The list is language-dependent and must be built per language by a native reviewer, because **the equivalents do not translate one-to-one and several have legitimate non-commercial meanings** — "level" in a training context, "tier" in a supply context. **Rule E-161: the register records the term, the language, the prohibited sense and the permitted sense, so the prohibition is precise rather than blanket.**

## 40.3 The structural test

**[P] Rule E-162 (The Growth-Source Test).** For any communication artefact, ask: **does its success depend on the reader bringing another person?** If yes, it is refused. **[A]** This is Rule E-118's test applied to communication rather than compensation, and it catches the whole class in one question — because every MLM artefact, however it is worded, has the property that its value to the sender increases with the number of people the recipient recruits.

---

# PART 41 — ANTI-COERCION

## 41.1 The nine things nobody may be pressured to do

**[P]** Brief §74, specified with the detection instrument for each:

| # | Nobody may be pressured to… | Mechanism by which pressure arises anyway | Control | Detection |
|---|---|---|---|---|
| **CO-1** | **Join** | A task that "requires" membership; a record that only exists for members; a social cost to not joining | PLR-5 help-once requires nothing; **Rule E-85** every stage is a destination; **[S-C: H-07]** no forced progression | Whether any activity is unavailable to a non-member without a stated, published, necessary reason |
| **CO-2** | **Donate** | An appeal; a visible list of donors; a suggested amount; a leader asking | **Rule E-9** no guilt or urgency; **Rule E-17** money buys a receipt; **no donor list is published at individual level** | Any artefact containing an appeal, an amount or a donor name |
| **CO-3** | **Recruit** | A target; a leaderboard; praise for bringing people; "we grow through our members" | **Rule E-135** no referral mechanism; **Rule E-86** no conversion target; **Rule E-160** growth is not the narrative | Any artefact whose success depends on the reader bringing someone (Rule E-162) |
| **CO-4** | **Attend** | An event presented as expected; attendance recorded; absence noticed | **[S-C: H-23]** flexible modes; **[S-C: H-18]** paused status without penalty; **Rule E-144** no national date | Attendance records used in any assessment or recognition |
| **CO-5** | **Publicly identify** | A photograph; a name in a story; a badge; a profile; a listing | **Rule E-149** no individual images; **E-34** consent; **[S-C: SR-4]**; **Rule E-148** the person served is not material | Any artefact identifying a person without a specific recorded consent for that use |
| **CO-6** | **Share personal data** | A form with more fields than the purpose needs; a "complete your profile" prompt | **Rule E-80** minimum safe pathway; **[S-A: A-18]** necessity test; AX-9 | Any field without a stated purpose and a stated retention rule |
| **CO-7** | **Participate in politics** | A mobilisation; a rally; a statement; a guest; a distribution near an election | **[S-A: A-01 N1…N9; A-03 E1…E14]**; **Rule E-30** | Any organisational activity in an election window; any political adjacency |
| **CO-8** | **Participate in religion** | A prayer; an auspicious start; a festival framing; a venue; a food practice condition | **Rules E-37, E-38, E-39, E-40**; **[S-A: A-05 clauses 5, 6]** | Any religious element in an organisational activity, **including a favourable one** |
| **CO-9** | **Remain after deciding to leave** | A follow-up; a "we miss you"; a re-engagement campaign; a social cost; an exit interview that argues | **[S-C: H-17]** seven refusal rights; **[S-C: H-18]** paused and alumni status; **[S-D: Rule D-26 dignified exit, Rule D-27 return]**; **Rule E-163** below | **HM-12** understanding that leaving is allowed, **and observation of whether anyone actually paused, reduced or left without adverse consequence** |

**[P] Rule E-163 (Leaving Is Complete And Immediate).** A person who decides to leave: has their decision recorded without a reason being required; **is not contacted to reconsider**; retains their contribution record and credential (which are theirs, not the organisation's **[S-C: H-09, H-10]**); has their personal data handled per the retention schedule **[S-A: A-17 P2]**; may return at any time without re-justification **[S-D: Rule D-27]**; and **is never described in any record or artefact as a loss of loyalty.**

## 41.2 Coercion that does not feel like coercion

**[A]** The four forms that no rule above catches directly, and the instruments that do:

| Form | Mechanism | Instrument |
|---|---|---|
| **Social cost** | In a small locality, not participating is visible and is read as a statement about the person | **Rule E-85** every stage is a destination; **Rule E-11** L0 is complete; **no attendance record is used in any assessment** |
| **Gratitude debt** | A person who was helped feels obliged, and the organisation notices that the feeling is useful | **Rule E-13** no conversion pathway; **Rule E-148** no gratitude staging; **§38.3** no pathway at all |
| **Opportunity structure** | The interesting work, the visible work and the credentialled work all go to the same people, and nobody decided it | **[S-D: Rule D-116]** opportunity-allocation recording, aggregate, suppressed; **Rule E-164** below |
| **Vocabulary** | A language in which refusal has no polite form, or in which "no" is rude | **[S-A: A-04]** the approved refusal script exists in **every operating language**, so a person can decline without rudeness. **Rule E-165: the refusal script is a member-facing artefact, published, in every operating language — not an internal document** |

**[P] Rule E-164 (The Opportunity Structure Is Published).** The aggregate distribution of evidence-generating opportunities — visible projects, delegations, training places, external representation, specialist engagements — is published at team and city level with small-cell suppression, per **[S-D: Rule D-116]**. **[A]** Publication does not prevent favouritism; it makes the pattern visible to the only actor with enough local knowledge to judge it, which is the locality itself.

**[P] Rule E-165 (Refusal Must Be Easy In Every Language).** The refusal script, the exit route, the decline route and the "nothing further is expected" statement are **published, member-facing, in every operating language, in an accessible format.** **[A]** A right that can only be exercised in a language the holder does not read, or in a register that is socially rude, is not a right.

---

# PART 42 — NATIONAL CAPACITY

## 42.1 The capacity formula

**[P]** Brief §132 proposes: **Growth rate ≤ governance + leadership + economic + service capacity**, and warns against fake precision.

**[A]** The correct form is not a sum but a **minimum**. **[S-D: Part 14]** established the same shape for leadership supply; **[S-B: §26.1]** established `σ_max` as the ceiling on control effort.

> **[P]** **Permitted growth in a period ≤ the smallest of the eight capacities below, expressed in units of "new participants that can be served, verified, led, paid, governed, communicated with, protected and accounted for" in that period.**

**[A]** A sum would allow a surplus in one capacity to compensate a deficit in another. **It cannot.** An organisation with abundant leadership and no verification capacity does not grow at the average of the two; it grows at zero, and accumulates unverified members, which is worse than not growing.

## 42.2 The eight capacities and the bottleneck

**[P] Amendment E-36.** Brief §173 requires each to be evaluated before expansion, and §174 requires the bottleneck principle to be tested.

| # | Capacity | Measured by | Source | Current status | Binding at which stage |
|---|---|---|---|---|---|
| **CAP-1** | **Leadership** | Trained leaders and control-role holders produced per period vs units formed per period; **[S-D: LM-1, LM-14, D-ready]** | **[S-D: Part 14]**; **[S-ST: §23.1 S1]** | **Not produced — nothing exists** | **S1 onward. The perennial bottleneck [S-B: §24.5 "leader supply is a stock problem"]** |
| **CAP-2** | **Verification** | SP-3 verifiers available; out-of-team assessment capacity; **[S-D: LM-2]** | **[S-D: Rule D-45; Part 13]**; **[S-B: MVC-2]** | **Not produced. At CL-0/CL-1 there is no outside** | **S2 onward — and it is the constraint on fairness, not only on scale [S-D: ES.5]** |
| **CAP-3** | **Economic** | `σ_max`; `H_gov` inside it; priority-1 payment on time; reserves | **[S-B: §25, §26]**; **[S-D: LM-12]** | **`UNKNOWN — MEASURE IN PILOT`; the 8–40 h/team/month range is the observation window** | **Every stage** |
| **CAP-4** | **Service** | Delivery capacity `P_max`; the ability to meet or honestly decline inbound demand | **[S-B: §17.2]**; **[S: Ch.15]** | Not produced | **S1 onward; and it is the capacity that reputation directly loads (Rule E-4)** |
| **CAP-5** | **Governance** | `H_gov_per_team(K)`; audit at sampling scale; the five retained bodies' capacity | **[S-B: §25, §26]**; **[S-D: Part 34]**; **[S-ST: §23.1 S3]** | **Divisor shape `UNRESOLVED` [S-D: Rule D-91]** | **S3 onward — the City divisor decides whether the state layer is arithmetically possible** |
| **CAP-6** | **Communication** | Translation, publication, moderation, verification-channel and crisis capacity | **This Part; Part 65** | **Not costed anywhere in [S-B]. This is a gap in the prior instruments, recorded at §42.5** | **S2 onward — and it binds earlier than expected, because PLR and the correction log are required from CL-1** |
| **CAP-7** | **Safety** | Stop-work capability present at all times; incident response; certified safeguarding **[V]** | **[S-D: Rule D-33 STOP]**; **[S-A: A-09, A-10]**; **[S-B: §23.2 Safety ● early]** | Not produced | **Every stage. Non-deferrable [S-D: MVLS-1]** |
| **CAP-8** | **Data** | Classification, minimisation, retention, breach readiness, access review, portability | **[S-A: A-17…A-20]**; Part 53, Part 54 | **Retention `UNRESOLVED`; DPIA applicability undetermined [V]** | **S1 onward; and it binds hard at any scale where a breach becomes notifiable [X]** |

**[P] Rule E-166 (The Weakest Critical Capacity Constrains Expansion).** Expansion is authorised at the rate the **smallest** of CAP-1…CAP-8 permits, and the constraining capacity is **named in the expansion authorisation record.** **[A]** Naming it matters: an authorisation that says "expand to five localities" is unauditable; one that says "expand to five localities, constrained by CAP-2 verification, with two out-of-team assessors available and a stated review date" can be checked.

**[P] Rule E-167 (A Capacity May Not Be Substituted By Enthusiasm).** Where a capacity is absent, the responses are: build it, route it to a level that has it (**[S-B: §26.4; S-D: Rule D-103]**), reduce scope, or do not expand. **A fifth response — proceed and rely on people working harder — is prohibited**, because it converts a structural deficit into individual burnout (**[S-D: LLI L2/L3; Rule D-76]**) and hides the deficit from the record.

## 42.3 What could collapse, ranked

**[P]** Brief §133. Ranked by **severity × irreversibility**, not by likelihood:

| Rank | Collapse | Mechanism | Reversible? | Severity |
|---|---|---|---|---|
| **1** | **Trust collapse** | One proven fabrication, one proven cover-up, or one beneficiary exposed. **The differentiation is verifiability, so a single proven falsehood removes the basis of every other claim (Rule E-132 analysis)** | **No, not fully.** Trust rebuilds slower than it falls and never to the same baseline | **Catastrophic** |
| **2** | **Reputation collapse** | RC-4 far-ahead state meeting a real failure; national attention with CL-0 evidence | Partially, by under-claiming and correcting | High |
| **3** | **Leadership collapse** | Simultaneous loss of leadership across a level; **[S-D: Scenario D]** — a whole City team lost takes `K` mohallas' verification and funds review with it | Yes, slowly, with outside cover | High |
| **4** | **Verification collapse** | Verifiers captured, overloaded or absent; **every downstream record becomes unreliable, which is trust collapse with a delay** | Yes, but the affected records are permanently uncertain | **Catastrophic in effect** |
| **5** | **Data collapse** | A breach exposing beneficiary, member, complaint or safeguarding data | **No.** Disclosure cannot be un-disclosed; **[X]** statutory notification and penalty exposure | **Catastrophic** |
| **6** | **Economic collapse** | Priority-1 payment failure; `H_gov > σ_max` sustained; reserves exhausted | Yes, by contraction | High |
| **7** | **Service-quality collapse** | Demand exceeding delivery; declines without alternatives; outcomes unverified | Yes | High |
| **8** | **Legal / legitimacy collapse** | Entity, tax, FCRA, political-activity or safeguarding exposure materialises | Depends entirely on the finding | **Potentially terminal [V]** |

**[A]** Ranks 1, 4 and 5 share a property: **they are caused by a single event and cannot be undone.** Everything else is a slope. **The communication architecture is therefore optimised against single-event catastrophic failure, not against gradual decline** — which is why Rule E-132 admits no exception, why Rule E-88 acts on absence, and why Rule E-109 preserves criticism.

## 42.4 National growth economics

**[P]** Brief §131 requires conceptual modelling with **no invented rupee amounts**. **[A]** Every line below is a **cost driver**, not a figure. **All values are `UNKNOWN — MEASURE IN PILOT` or drawn from [S-B] symbolically.**

| Cost driver | Character | Existing source treatment | Gap |
|---|---|---|---|
| **Verification** | Per participant and per unit; grows with claims made | **[S-B]** control-role costs; **[S-D]** SP-3 supply | — |
| **Leadership** | `C_lead = C_wc_base × m_lead`, `m_lead` `NOT FINAL` | **[S-B: §24]**; **[S-D: Part 23, Part 39]** | — |
| **Software and platform** | Fixed plus per-unit; **[S-B: §26.3]** automate or retire | **[S-B]**; Part 53 | — |
| **Training** | Per cohort × trainer supply — **the binding constraint on leader production [S-ST: Scenario B]** | **[S-B]**; **[S-D: Rule D-47 paid trainer time]** | — |
| **Audit** | Sampling scale, not case scale, from S3 **[S-ST: §23.1]** | **[S-B: §26]**; **[S: Ch.27]** | — |
| **Local service** | Priority 1 and priority 3 per the waterfall | **[S: Ch.18]** | — |
| **Communication — translation** | Per language × per register; LA-1 and LA-5 are full-and-once and pre-positioned | **[S-B: HC-19]** records translation as a hidden cost; **[S-C: §30.5]** | — |
| **Communication — publication** | Per locality per cadence: PLR refresh, quarterly boring-things, annual accountability | **NOT COSTED ANYWHERE** | **§42.5** |
| **Communication — moderation and response** | Per inbound query, comment, complaint, verification request | **NOT COSTED ANYWHERE** | **§42.5** |
| **Communication — crisis** | Event-driven, but **must be pre-funded because a crisis is exactly when capacity is least available** | **NOT COSTED ANYWHERE** | **§42.5** |
| **Communication — media relations** | Per query, with a stated response window | **NOT COSTED ANYWHERE** | **§42.5** |

## 42.5 The finding: national communication is an unfunded obligation

**[A]** **[S-B]** costs governance hours `H_gov` and identifies the control budget `σ_max`. **[S-D]** costs leadership, assessment, development and continuity. **Neither costs communication.** The v1.2 architecture creates a **National Communications department** **[S: Ch.5]**, an **Editor** role and a **Social Media Manager** role **[S: App. A §8.x]**, a **Communication training category** **[S: Ch.12]**, and makes **communication/branding a launch blocker** **[S: Ch.31]** — and there is **no revenue line for communication and no `H_gov` component for it.**

**[P] Rule E-168 (Communication Is A Costed Governance Function).** Communication burden enters the workload ledger and `H_gov` accounting on the same basis as any other control function: **itemised, declared per role, tested against `σ_max`, and subject to the automate-or-retire discipline [S-B: §26.3; S-D: Rule D-52].** **[A]** This is recorded as a **gap in v1.3-B**, not as a criticism of it: v1.3-B's scope was the mohalla unit, and at mohalla scale communication is a few hours a month. **At CL-3 and above it is a function, and an unfunded function is performed badly or not at all.**

**[P] Rule E-169 (The Communication Burden Test).** Brief §177: "does national communication create a second organisation whose job is to communicate about the first organisation?" **The test:** if the hours spent producing, translating, moderating, publishing and responding exceed the hours spent on service and verification at any level, **the level is over-communicated and must retire instruments under [S-D: Rule D-128]** — one retirement for every addition.

## 42.6 Growth versus capacity — the one-million-people question

**[P]** Brief §76. **If a million people wanted to join tomorrow, the correct response is not "welcome everyone."**

| Function | What breaks | Correct response |
|---|---|---|
| **Verification** | A million identity and conduct checks against a capacity built for hundreds | **Queue honestly.** Publish the queue length and the expected window. **Do not lower the standard, and do not admit unverified people to responsibility-bearing roles [S: Ch.12 immutable item 4]** |
| **Safety** | Safeguarding, two-adult rule, incident response across units that do not exist | **Refuse the activity, not the person.** An unformed unit cannot operate **[S-D: Rule D-33, Rule D-127]** |
| **Training** | Trainer supply is the binding constraint **[S-ST: Scenario B]** | Sequence; publish the sequence |
| **Leadership** | Positions are arithmetically scarce — `L_pos/K` **[S-D: Part 10 §10.7]** | **Say so plainly.** Most of a million would be L0–L2 forever, which is a complete outcome (Rule E-14) |
| **Data** | Ingestion, classification, retention, breach exposure **[V]** | Minimum-data at intake (Rule E-80); no speculative collection |
| **Support** | Every person expects a response | **Rule E-5: publish the limit.** A stated response window that is met beats an implied instant one that is not |
| **Service** | Demand exceeds delivery | Triage on need criteria only **[S: Ch.8 step 5]**; honest declines with alternatives (Rule E-5) |
| **Economics** | Priority-1 obligations arrive before revenue | **Never admit beyond the ability to pay for verified work [S: Ch.18]** |
| **Fraud** | A surge is an opportunity: impersonation, fake claims, fake beneficiaries, fake records | Public verification channel (TS-series, PLR-6); BR-11 impersonation incidents; audit sampling |
| **Communication** | Inbound query volume exceeds response capacity | **Pre-drafted, registered, translated FAQ that answers the eight first-contact questions; a published response window; and an honest statement of the queue** |

**[P] Rule E-170 (A Surge Is Managed By Publishing The Limit).** The response to demand exceeding capacity is **not** silence, not a lowered standard, not a waiting list nobody can see. It is the publication of: what the capacity is, what the queue is, what the criteria are, what the window is, and what the alternative routes are. **[A]** This is Rule E-92 applied at speed, and it is the only response that converts a surge from a reputational risk into a demonstration of the exact virtue the organisation claims.

---

# PART 43 — SUDDEN GROWTH

## 43.1 The simulation

**[P]** Brief §77: a video goes viral; **10,000 → 100,000 → 1,000,000** people arrive.

| Scale | **What breaks first** | Who handles it | **What is paused** | How communication changes | How expectations are managed | How fraud is controlled |
|---|---|---|---|---|---|---|
| **10,000** | **The response window.** Inbound queries exceed the team's ability to answer personally | The local team, then City | Nothing yet | PLR and the registered FAQ carry the load; the human route is protected for help-seekers first | Publish the actual response window and meet it | Verification channel queries rise; impersonation appears |
| **100,000** | **Verification and triage.** Intake exceeds capacity to assess need | City, then State | **Expansion; new partnerships; any campaign; any non-urgent publication** | Every statement names the actual scale in numbers in its first sentence (Rule E-127) | Publish the queue, the criteria, the window and the alternatives (Rule E-170) | Duplicate and fabricated claims; fake local teams; fake collection |
| **1,000,000** | **Everything at once: verification, safety, leadership, data, economics, communication** | National, with the reserved-matter procedure if a decision is needed | **All growth activity. All expansion. All new locality. All recruitment. All non-emergency publication except corrections and limits** | A single daily factual update on capacity, queue and limits; **no celebratory communication of any kind** | **Explicit, repeated, numerical under-claiming**: "we are N teams; we can serve M people a month; you are P in the queue" | Full audit sampling; platform impersonation reporting; **public verification channel as the primary defence** |

**[A]** The counter-intuitive finding: **the correct communication response to viral success is to become less inspiring and more arithmetic.** Every celebratory artefact increases inbound demand, and inbound demand is precisely what is breaking. **Rule E-171 (A Surge Suspends Celebration):** during a demand surge, no organisational artefact may celebrate growth, attention, milestones or scale. **The only permitted communications are: the limit, the queue, the criteria, the window, the alternatives, the corrections, and the safety information.**

## 43.2 The three things a surge reveals

| Revelation | Why | Consequence |
|---|---|---|
| **The claim ladder was being ignored** | Attention arrives at CL-n claims regardless of what the organisation says, and the audience supplies the rest | Rule E-127's early-attention protocol; the ladder is published so the organisation can point at it |
| **CAP-6 communication capacity was never costed** | §42.5 | Rule E-168; a pre-funded crisis and surge capacity |
| **The verification channel is the most important public asset** | Impersonation scales with attention faster than service does | PLR-6; BR-11; TS-series |

---

# PART 44 — SLOW GROWTH

## 44.1 The simulation

**[P]** Brief §78: **only 20 new participants arrive per month.** Does the system remain meaningful?

**[A] Yes — and this is the scenario the architecture is actually designed for.** Every instrument in Parts 1–41 operates identically at 20 participants per month as at 20,000, with three exceptions, and none of the three is a failure:

| Instrument | Behaviour at 20/month | Is this a problem? |
|---|---|---|
| **PLR public local record** | Three dated local results a month is a full page | **No — it is the ideal density** |
| **Cohort normalisation** | Cannot operate — a cohort of one is not a cohort **[S-D: Part 41 §41.2]** | **Yes, and it is recorded as untestable, not fudged** |
| **Disparity testing, small-cell suppression** | Everything is suppressed; nothing is publishable in aggregate | **Yes — and the correct response is to publish the specific record instead of the aggregate, with consent** |
| **Out-of-team assessment** | Requires a City with another team | **The binding constraint, unchanged from [S-D: ES.5]** |
| **Claim ladder** | CL-1 / CL-2 | **Correct. Slow growth keeps claims honest by construction** |
| **Word of mouth** | Compounds slowly and durably | **No — this is the only growth mechanism that is not capacity-limited** |

**[P] Rule E-172 (Slow Growth Is The Design Case, Not The Failure Case).** No instrument, target, dashboard, cadence, report or communication may treat a low growth rate as a deficiency. **Specifically prohibited: any artefact that compares growth rates across localities, any "momentum" narrative, any implication that a stable unit is a stalled unit.** **[A]** Reason: an organisation that requires growth to feel successful will manufacture it, and manufactured growth in a service organisation is recruited people, inflated counts and unverified records — the three things that destroy the differentiation.

## 44.2 What slow growth actually tests

**[A]** Slow growth is the **harsher** test of the architecture, not the gentler one, because it removes the excuse:

| Test | What slow growth reveals |
|---|---|
| **Does the work matter?** | With no growth narrative available, the only reason to continue is the outcome. **HM-8 follow-up and HM-14 promises kept become the whole story** |
| **Is the record honest?** | A small record is fully inspectable. **At 20/month, every claim can be checked by one person in an afternoon** |
| **Do people return?** | **HM-9** is the primary measure, and slow growth makes it the *only* measure that moves |
| **Is the burden affordable?** | `H_gov` against a small delivery base is the tightest possible test of `σ_max` |
| **Would they miss us?** | The disappearance test (Rule E-94) is answerable at this scale, and it is answerable in the negative if the answer is negative |

**[P] Rule E-173 (Publish The Small Numbers).** Where the numbers are small, they are published as small. **A report that says "three households, one lane, ₹-equivalent hours unknown, outcome: drainage resolved, follow-up in ninety days" is a stronger trust artefact than a report that says "significant community impact"** — and it is the only kind of report available at CL-1 and CL-2.

---

# PART 45 — ZERO GROWTH

## 45.1 The simulation

**[P]** Brief §79: **membership stops growing for three years.** Can the organisation still serve, learn, earn, retain, improve and matter locally?

| Function | Survives zero growth? | Why | Dependency revealed if not |
|---|---|---|---|
| **Serve** | **Yes** | Service depends on delivery capacity and inbound need, neither of which requires new members | — |
| **Learn** | **Yes** | M5 lessons, M3 change requests, after-action reviews operate on events, not on growth | — |
| **Earn** | **Conditionally** | Venture revenue depends on customers and capability, not on membership. **But priority 1 depends on revenue existing at all, and [S-B] establishes there is no revenue line for service or governance** | **The economic model, not the growth rate. This is the real dependency and it is [S-B]'s, not v1.3-E's** |
| **Retain** | **Yes, and zero growth is the best retention test available** | **HM-9** voluntary return is independent of acquisition | — |
| **Improve** | **Yes** | Standards change through M2/M3 on evidence from operations | — |
| **Matter locally** | **Yes — this is the only function that zero growth cannot damage** | The disappearance test (Rule E-94) measures what would be lost, and what is lost depends on service, not on headcount | — |
| **Develop leaders** | **Conditionally** | Succession requires candidates; a static population still produces them, but positional scarcity `L_pos/K` means fewer roles to fill | **[S-D: Part 10 §10.7] — a static organisation produces ready people with nowhere to go, which is exactly [S-ST: F-24]'s attrition mechanism** |
| **Fund communication** | **Conditionally** | Publication costs are low but non-zero | **§42.5** |

**[P] Verdict: the architecture survives zero growth, with one structural dependency, and it is not a communication dependency.**

**[A]** The dependency is **positional scarcity under stasis**. **[S-D: Part 10 §10.7]** establishes that positions are arithmetically scarce; **[S-ST: F-24]** establishes that capable people leave when the expected reward for three years of excellent work is "still the same role." **In a zero-growth organisation, that expectation is correct, and the specialist track plus scope rewards are the only answers available.**

**[P] Rule E-174 (Zero Growth Changes What Is Communicated, Not Whether).** Under zero growth the communication emphasis shifts from *what we did* to **what we learned and what we would do differently** — because in a static organisation the learning record is the only thing that is still moving. **[A]** This is also the honest answer to the question a funder or journalist will ask: an organisation that has not grown for three years and can show a rich correction and learning record is more credible than one that has grown and cannot.

## 45.2 The failure to avoid

**[I]** The predictable organisational response to zero growth is a **growth campaign** — which is prohibited by Rules E-25, E-86, E-91 and E-135, and which would fail for the reason **[S-B: §24.5]** gives: **leader supply is a stock problem, and a campaign produces a flow of people into a stock that cannot absorb them.**

**[P] Rule E-175 (No Growth Campaign, Ever).** The organisation does not run campaigns for members, followers, participants, donations or attention. **It publishes records.** Where publication produces growth, the growth is a by-product and is capacity-gated (Rule E-166). Where publication does not produce growth, the publication continues, because its purpose is accountability and not acquisition.

---

# PART 46 — NEGATIVE GROWTH

## 46.1 The simulation

**[P]** Brief §80: membership declines. Six functions are required: consolidation, team merger, graceful closure, member transfer, asset transfer, service continuity.

| Function | Design | Source |
|---|---|---|
| **Consolidation** | Reduce scope to what the remaining capacity can serve and verify honestly; publish the reduced scope | Rule E-92 publish the limit; **[S: Ch.14]** support-first recovery |
| **Team merger** | Two units merge with a recorded reason, a combined capability check (Rule D-33 four capabilities), and **the GF-22 control: a merger or split changes denominators and requires City approval with a recorded reason** | **[S-D: GF-22; Part 26 R-2]** |
| **Graceful closure** | A closure is a **published event (TS-13)**, with: what was done, what was achieved, what remains undone, who owes what, where the records go, and how a person can still reach the organisation | **[S-D: Rule D-26 dignified exit]** applied to a unit; **[S-A: A-15 M4]** records are institutional |
| **Member transfer** | A member's contribution record and credential **travel with them** and are recognisable in another locality — this is contribution portability, and a closure is the event that proves it works or does not | Part 54; **[S-C: H-09, H-10]** |
| **Asset transfer** | Per the waterfall and reserved-matter rules: assets, reserves and the social-impact fund are **reserved matters** and may not be transferred by an interim or local authority | **[S-A: A-14 §13.3]**; **[S: Ch.18, Ch.20]** |
| **Service continuity** | Every open commitment is either completed, transferred with the recipient's knowledge, or **honestly closed with an alternative route given** | Rule E-5 well-delivered decline; Rule E-81 boundary stated |

**[P] Rule E-176 (A Closure Is Published On The Same Terms As An Opening).** A unit that stops operating is published with the same prominence, in the same places, in the same languages, and with the same detail as a unit that started. **[A]** Reason: **publishing closures is the credibility condition for publishing openings.** An organisation that announces every beginning and no ending is understood, correctly, to be running a promotional operation rather than an accountable one.

## 46.2 The communication sequence for decline

| Step | Action | Prohibited |
|---|---|---|
| **1** | Establish the facts from records — is this decline, seasonal variation, a paused cohort, or a data error? | Announcing a narrative before the record supports one |
| **2** | Publish the fact, in numbers, with the locality and period | Euphemism ("consolidating our presence", "optimising our footprint") |
| **3** | Publish the reason as far as it is known, with the claim class (Part 31 §31.2) | Attributing the decline to external factors without evidence |
| **4** | Publish what happens to every open commitment | Silence about the people currently being served |
| **5** | Publish where the records go and how to reach the organisation afterwards | Deleting, archiving without notice, or losing the local record |
| **6** | Publish the learning entry and the standard change | Closing the matter at step 3 |
| **7** | Report back on whether the change worked | — |

**[A]** The most important item is step 4. **[I]** In a decline, the people most harmed are not the members who leave — they have alternatives and agency. **They are the households with an open commitment who discover that the person who used to come no longer does, and who were never told.** Rule E-5 makes a well-delivered decline a trust event; an undelivered decline is the opposite, and it is the event that produces the local reputation that follows the organisation to the next locality.

---

# PART 47 — REPUTATION SHOCK

## 47.1 The principle

**[P] Amendment E-38.** Brief §81: a high-profile leader is publicly accused of misconduct, **before any facts are established.**

**[P] Rule E-177 (Process Before Narrative).** Where an allegation concerns a person, the organisation's public communication describes **the process and the interim measures**, never the person, the allegation's merits, or a conclusion. **The panel decides; Communications reports that a panel exists and what it will do.** **[S: App. E]** serious-misconduct removal is a Governance/HR panel matter; **[S-D: Rule D-60]** no score or public pressure removes anyone; **[S-D: Rule D-102]** access is withdrawn at the decision moment.

| Element | Design | Prohibited |
|---|---|---|
| **Communication** | "A matter concerning [role] has been raised. It is being examined by [panel]. Interim measures are in place: [what]. We will report the outcome class when determined." | Any description of the allegation's content; any characterisation of the person; any prediction; any expression of confidence in the person |
| **Investigation** | Panel route **[S: App. E]**; sealed category **[S-A: A-20 C4]**; two-person rule; case-scoped access | Investigation by Communications; investigation by the accused person's line |
| **Public trust** | The interim measures are the trust signal — **they are what an accountable body does before it knows** | Arguing that the accusation is unfair |
| **Leadership continuity** | TL-2 interim; SS state checked; four capabilities maintained (Rule D-33) | Leaving the role unfilled while "waiting to see" |
| **Data protection** | The complainant's, the accused's and any witness's data is C4 sealed; **no identification in any public artefact** | Any leak, however sympathetic the organisation's position |
| **Media response** | The same statement to every outlet; no exclusivity; no pre-publication review (Rule E-126) | Briefing one outlet; "off the record" comment |
| **Members** | Informed of the process and the interim measures; **not** of the content | A member-wide discussion of the allegation |
| **Non-retaliation** | **Absolute.** No adverse change to the complainant, a witness, or anyone associated with them | Any contact with the complainant by the accused person or their line |

## 47.2 Criticism is not automatically an attack

**[P]** Rule E-108 established the five categories. **This section establishes the classification discipline**, because misclassification is the failure:

| Misclassification | Consequence | Control |
|---|---|---|
| **Legitimate criticism classified as an attack** | The organisation defends instead of correcting; the critic is discredited; the underlying problem persists and grows | **Rule E-178: the default classification of any negative public statement is CRITICISM.** Escalation to misinformation, harassment or threat requires a recorded reason |
| **Whistleblowing classified as disloyalty or as an attack** | The most valuable information the organisation will ever receive is destroyed, and the person who provided it is punished | **Rule E-108 C-WHB routes to the Integrity Line, outside the operational line [S-D: MVLS-9; S-ST: M10]; non-retaliation absolute** |
| **Misinformation classified as criticism** | A false claim is answered with an argument rather than a correction, and the argument amplifies it | **"Correct calmly with verifiable facts and correction logs" [S: Ch.24]**; silence where amplification would harm |
| **Harassment classified as criticism** | A person is left exposed | Protect the person; document; restrict; **do not respond publicly** |
| **A threat classified as harassment** | A safety matter is handled as a moderation matter | **Immediate Safety and Legal route [S-A: A-09]** |

**[P] Rule E-179 (The Classification Is Recorded And Auditable).** Every classification decision under Rule E-108 is recorded with its ground and its classifier, and is auditable. **A pattern of criticism being classified as attack, by one classifier or in one unit, is itself a finding** — on the model of **[S-D: §18.3]**'s appeal-pattern detection.

## 47.3 The eight attack scenarios — the response architecture

**[P]** Full simulations at Part 48 (SIM-04…SIM-09, SIM-13). The architecture is common to all eight and differs only in evidence:

| Attack | **The evidence that disproves it** | What must exist beforehand | What must NOT be done |
|---|---|---|---|
| **Political alignment** | The refusal log with its annual count; the accounts showing no political money; the neutrality code; the spokesperson distribution; the election-window record | TS-8; **[S-A: A-01, A-03, A-04]** | Answer politically; mobilise members; comment on any party |
| **Religious or caste character** | The behavioural record: routing, calendar, venue, timing, recognition distribution; the partnership register; the non-alignment clause | TS-1, TS-2 with locality; Rule E-36 multi-festival calendar; Rule E-43 routing records | **Publish any composition figure (Rule E-42, E-48)**; enter a theological argument |
| **Vigilante character** | The DO-NOT list; the visibility protocol; the incident record; the authorities-first doctrine; **zero VG-5 events** | **[S-A: A-06, A-08]**; Part 13; PLR-2 | Argue about the video before the record is established; defend the members publicly before the review |
| **MLM character** | **The absence of any participation-linked term in any compensation, recognition or progression formula** — provable from documents alone | Rule E-118; Rule E-135; Rule E-159; **[S-C: H-21; S-D: Rule D-118]** | Deny without producing the formulas. **Produce the formulas** |
| **Financial misuse** | The published accounts; the waterfall; segregation of duties; the reconciliation record; the audit position; the specific transactions | TS-3, TS-4; **[S: Ch.18, Ch.19, Ch.27]** | "We are transparent" without the record |
| **Data breach** | What happened, what categories, what was done, what affected people should do, the grievance route | **[S-A: A-17 P5; SOP-22]**; rehearsed runbook; notice in every operating language | Delaying notification; minimising scope; notifying selectively **[X][V]** |
| **Fake viral video** | The record: what actually happened, where, when, with what authority, per what boundary | Incident records; the boundary statement; the verification channel | Amplifying by repeated denial; attacking the poster; speculating |
| **Media narrative (cult / political / vigilante / MLM / corporate front / religious)** | **The architectural evidence, item by item** — the code, the logs, the accounts, the DO-NOTs, the formulas, the correction log, the refusal log, the composition of spokespersons | Everything above, **published before the narrative arrives** | Arguing with the label. **"Never argue with a label in public; replace it with a fact" [S-ST: §18.3 item 6]** |

**[A]** The common structure is the finding of this Part: **every attack is disproved by a record that must already be published.** None is disproved by a statement. **[P] Rule E-180 (Defence Is Pre-Publication).** The organisation's defence against every foreseeable attack is the **prior publication** of the record that answers it. **A record published after an accusation is a rebuttal and will be read as one; the same record published before is a fact.** This is why TS-1…TS-14 and Rule E-88 are not transparency theatre — **they are the entire crisis-communication capability, built in advance, at the cost of translation and a page.**

---

# PART 48 — NATIONAL FAILURE SIMULATIONS

**[P]** Twenty simulations mandated by the brief. Each states: **trigger · first failure · response · evidence · responsible level · communication · recovery · residual risk.** Simulations are **not forecasts** — **[S-B]** standing instruction.

## 48.1 SIM-01 … SIM-10

| ID | Trigger | **First failure** | Response | Evidence required | Level | Communication | Recovery | **Residual risk** |
|---|---|---|---|---|---|---|---|---|
| **SIM-01** | **Viral growth** — a video circulates; 100,000 arrive | **The response window breaks**; inbound exceeds triage | Pause expansion, partnerships and campaigns; publish the limit, queue, criteria, window and alternatives (Rules E-170, E-171) | Actual capacity numbers; queue length; decline rate | City → National | Arithmetic, not celebration (Rule E-127) | Re-open growth only when CAP-1…CAP-8 recover (Rule E-166) | **Elevated expectations persist after attention moves; the decline rate becomes the story** |
| **SIM-02** | **Zero growth** — three years flat | **Internal pressure for a growth campaign** | Refuse the campaign (Rule E-175); shift publication emphasis to learning and correction (Rule E-174) | HM-9 return; HM-8 outcomes; the learning record | Team → City | Publish small numbers plainly (Rule E-173) | Specialist track and scope rewards absorb the positional-scarcity pressure **[S-D: F-24]** | **Capable people leave because nothing opens; the organisation loses exactly the people it needs** |
| **SIM-03** | **Negative growth** — decline | **Open commitments are quietly dropped** | Publish the decline, the reason, and what happens to every open commitment (Part 46 §46.2) | Decline figures by locality and period; the open-commitment register | Team → City | No euphemism; closure published on opening terms (Rule E-176) | Consolidation, merger, transfer, graceful closure | **Local reputation damage that precedes the organisation to the next locality** |
| **SIM-04** | **Political accusation** — "secretly aligned with X" | **A defensive or counter-political statement** | Never answer politically (Rule E-34); publish code, refusal log, accounts, spokesperson distribution | TS-8 annual refusal count; accounts showing no political money; the neutrality code | National | Calm, factual, record-citing; correct a false association within the window (Rule E-32, N9) | Where substantially true: **repair, not messaging** (Rule E-35); composition and partnership review | **In a politically saturated locality the accusation is unfalsifiable; residual risk is permanent and is managed, not resolved** |
| **SIM-05** | **Religious or caste accusation** | **A composition figure is produced, or a theological argument is entered** | Neither (Rules E-41, E-42, E-48, E-49); publish the behavioural record | Routing, calendar, venue, timing and recognition distributions; the partnership register; the non-alignment clause | National with local records | Behavioural, never demographic | Pattern review of routing, venue, timing, recognition; published correction | **A genuinely skewed pattern cannot be argued away; only re-routed, slowly** |
| **SIM-06** | **Vigilante accusation** — a video shows members intervening | **The organisation defends the members before the record exists** | Establish the record; state the boundaries; refer to authorities where lawful; incident review | The DO-NOT list; the visibility protocol V1…V8; the incident record; the authorities-first doctrine | Safety + Legal + National | Immediate, factual, no speculation on cause (**CC-7**) | **[S-D: VG-5]** class review; visible-protocol audit; published correction where the record contradicts the video | **Even a lawful intervention is reputationally damaging; the boundary statement must have been published beforehand** |
| **SIM-07** | **MLM accusation** | **A denial without documents** | Produce the formulas (Part 47 §47.3) | Every compensation, recognition and progression formula, showing **no participation-linked term**; the prohibited-vocabulary register | National + Finance | Publish the formulas, not a statement | Where a violation is found: formula voided, published correction | **Low — provable from documents alone. This is the most defensible attack in the set** |
| **SIM-08** | **Financial accusation** — "money is being misused" | **"We are transparent" without a record** | Produce the accounts, the waterfall, the segregation record, the specific transactions, the audit position | TS-3, TS-4; **[S: Ch.18, Ch.19, Ch.27]**; the audit report | Finance + Audit + National | Publish the specific transactions in question; **priority-1 payment is never suspended by the dispute [S-D: INV-2]** | Independent or statutory audit **[V]**; restitution; correction; standard change | **Where the entity structure is unresolved, the accounts cannot be as clear as the accusation is simple** |
| **SIM-09** | **Data breach** — member or beneficiary data leaks | **Notification delayed while scope is assessed** | Contain, notify, investigate, review access, remediate, prevent — per **[S-A: A-17 P5; SOP-22]**. **[X]** DPDP Act 2023: notify the Board **without delay**, detailed report within **72 hours**, notify affected data principals, **no materiality threshold**; CERT-In separately requires 6-hour incident reporting **[V]** | The breach record; the affected-category list; the notification record | Data + Legal + National | Notify affected people **in their language, in an accessible format including voice** (LA-5); publish what happened and what is being done | Access review; retention review; runbook rehearsal; published prevention change | **Catastrophic and irreversible where beneficiary or safeguarding data is involved** |
| **SIM-10** | **Founder controversy** — public criticism of the founder personally | **The organisation speaks about the founder, or the founder speaks as the organisation** | Separate the person from the institution; the organisation states only what its records show | **[S-A: A-16]** four annual tests; the Founder Recusal Register **[S-D: Rule D-92]**; the attribution test T2 | National | **In the organisation's name, about the organisation's conduct — never about the person's character** | Where the criticism concerns organisational conduct: treat it as criticism (Rule E-178) and correct | **Severe and structural: [S-ST: §11.1] — "if the public face is one person, every controversy about that person is a controversy about the institution, and there is no way to defend the institution by separating them." This is the simulation that the architecture is least able to survive, and the reason [S-A: A-16 §15.4] exists** |

## 48.2 SIM-11 … SIM-20

| ID | Trigger | **First failure** | Response | Evidence required | Level | Communication | Recovery | **Residual risk** |
|---|---|---|---|---|---|---|---|---|
| **SIM-11** | **Founder disappearance** — unreachable | **Nobody knows who may speak** | Interim Authority Order operates; authorised spokespersons by domain continue; reserved matters frozen | **[S-A: A-14]** apex Deputy, Interim Authority Order, dual custody; **T1 absence test** | National | Communication continues **unchanged** — which is the proof the architecture works | Continuity test findings published | **Where T1 has never been exercised, the first absence is the test, and it is being taken in public** |
| **SIM-12** | **Leader misconduct** — a high-profile accusation, facts unestablished | **A conclusion is announced, or the person is defended** | Process before narrative (Rule E-177); interim measures; panel; sealed category | The panel's existence and remit; the interim measures; the outcome class when determined | Governance/HR panel + National | Describe process and measures only; **no content, no characterisation, no prediction** | Outcome class published; correction if earlier statements were wrong; standard change | **Reputational damage occurs at accusation speed and reverses at investigation speed, which is slower** |
| **SIM-13** | **Fake viral video** — a fabricated or misattributed clip | **Repeated denial, which amplifies** | Correct calmly once, with the record; platform reporting where appropriate; **silence where amplification would cause more harm** | The actual record: what happened, where, when, with what authority | National + local records | One correction, logged (TS-6); no repetition; no engagement with the poster | Correction log entry; verification channel strengthened | **The correction reaches a fraction of the audience the fabrication reached. This asymmetry is structural and cannot be fixed by communication** |
| **SIM-14** | **National media criticism** | **Access is withdrawn from the critic, or tone becomes a condition** | Answer with records; no exclusivity; no pre-publication review; no copy approval (Rules E-126, E-84) | The claim register entries for every claim challenged | National | Calm, factual, complete; correct where wrong | Where the criticism is right: **publish the correction and the change** | **A national narrative, once set, is expensive to dislodge and is dislodged only by years of contrary records** |
| **SIM-15** | **Local media criticism** | **A local role-holder argues with a reporter** | The local protocol: named contact plus non-local contact; a stated window; records not narratives | PLR-1…PL-7; the local record | Team + City | In the locality's language, by the local role-holder within their domain | Correction; the relationship continues on the same terms | **Local criticism is believed locally, and local belief is the only belief that determines whether service can continue** |
| **SIM-16** | **Partnership scandal** — a partner is exposed | **Guilt by adjacency is denied rather than scoped** | Publish the written scope; state what the partnership was and was not; terminate per the agreement; correct any artefact implying endorsement | PT-C agreement; BR-3, BR-4; **[S: Ch.5 §4.4]** | National + City | "This was an activity-scoped agreement for X. It was not an endorsement and did not cover Y" | Exit per PT-F; data disposition; brand-usage cessation | **Adjacency cannot be un-seen; the pre-existing scope document is the only defence and it must predate the scandal** |
| **SIM-17** | **Business failure** — a venture collapses, a customer is not served | **The service brand is used to absorb or deflect, or the failure is treated as private** | Separate the trading name (Rule E-18); honour the customer obligations; publish the failure in the accounts; **the mission-balance statement shows whether service was displaced** | Venture records; QA and dispute records; **[S-ST: §17.3; M14]**; **[S-B: B-07]** | City + Finance | To the customers first, then in the accounts | Closure rules **[S: Ch.17]**; customer remedy; learning entry | **MC-5 crystallises: "they use charity to get clients." The firewall's credibility is tested exactly once** |
| **SIM-18** | **Mass volunteer surge** — a disaster or a viral moment brings thousands | **Unverified people are deployed to help** | **Never lower the verification standard for responsibility-bearing roles [S: Ch.12 immutable item 4];** offer bounded, paired, supervised tasks (FW-1…FW-6); publish the limit | Verification capacity; task inventory; safety capability | City → National | Honest capacity statement; the alternative routes; the safety boundaries | Absorb into L2–L3 where genuine; let the rest be a complete outcome (Rule E-85) | **A surge that is turned away badly produces a grievance cohort; a surge that is admitted unverified produces a safety incident** |
| **SIM-19** | **Mass volunteer departure** — a cohort leaves at once | **The departure is hidden, or the leavers are characterised** | Publish the number; ask why, through exit themes only **[S-C: §21.4]**; do not characterise anyone | HM-9 return rate; exit themes; the workload ledger (`H_unrecorded`, LLI bands) | Team → City | Plainly, with the learning | Fix the cause — **[X]** leavers' stated reasons cluster on relocation, time pressure and lost follow-up; **[S-D: Rule D-59]** where support was not actually provided, the finding is organisational | **Departure at scale is usually about load and attribution, not about mission — and both are recorded internally long before anyone leaves** |
| **SIM-20** | **Local unit collapse** — a team stops functioning | **The people being served are not told** | Continuity routes operate (Rule D-33); City cover; **every open commitment completed, transferred or honestly closed with an alternative** | SS state; the Interim Authority Order; the open-commitment register; the KT pack | City → State | To the locality first, in its language, before any national record is updated | Re-form or close with publication (Rule E-176); records preserved institutionally **[S-A: A-15 M4]** | **[S-D: Scenario D]**: where the collapsed unit was a City, `K` mohallas lose verification and funds review simultaneously — **the largest single-point exposure below the apex** |

## 48.3 The pattern across twenty simulations

**[A]** Three findings:

1. **In nineteen of twenty, the first failure is a communication act performed too early** — a denial, a defence, a conclusion, a celebration, a composition figure, an argument. **The correct first act in every case is to establish the record and publish the process.** Rule E-177 is therefore not specific to misconduct; it is the general crisis posture.
2. **In eighteen of twenty, the defence is a record that had to be published *before* the event.** Rule E-180 — defence is pre-publication — is the whole of crisis capability.
3. **Two simulations have no good outcome: SIM-10 (founder controversy) and SIM-13 (fake viral video).** The first is structural (**[S-ST: §11.1]**) and is mitigated only by **[S-A: A-16 §15.4]** being honoured over years. The second is arithmetic — **a correction reaches a fraction of the audience a fabrication reaches** — and is mitigated only by having so little sensational content in circulation that there is nothing to fabricate about. **Both residual risks are recorded as unresolvable in Part 70.**

---

# PART 49 — NATIONAL ADOPTION ADVERSARIAL AUDIT

**[P]** Brief §135. Fourteen attacks on the adoption system.

| ID | Attack | Mechanism | Detection | Structural response | Residual |
|---|---|---|---|---|---|
| **AD-01** | **Fake popularity** | Purchased or bot followers create apparent demand | **Rule E-106:** vanity metrics are never evidence, so fake popularity buys nothing. Detection is therefore unnecessary — the attack has no target | The architecture is immune **by refusing to use the metric** | Low |
| **AD-02** | **Influencer manipulation** | A creator shapes the message for their audience | Rule E-107 post only what is already published; Rule E-110 creators report, never represent | No message exists to shape | Medium — the creator's own framing is outside control |
| **AD-03** | **Political capture** | A faction places members, seeks adjacency, offers resources | **[S-A: A-01 N1…N9; A-02 tier restrictions; A-04 refusals logged]**; PC-7 aggregate disparity testing | Refusal log published; approach register; recusal | **High — patient and lawful** |
| **AD-04** | **Religious capture** | A faith body becomes the dominant local partner | **[S-A: A-05 clause 5]**: activity-scoped, separate branding, **never exclusive where alternatives exist** | Partnership register; pattern review | Medium |
| **AD-05** | **Regional faction** | One region's norms become the unmarked national default | RS-1; Rule E-50 local-by-default; terminology register per state | Per-state register review; locality attribution on every outcome | Medium |
| **AD-06** | **Caste faction** | A locality's dominant group controls the team and its routing | CN-1…CN-6; Rule E-43 routing records; Rule E-44 venue and timing review; **[S-D: Rule D-79]** aggregate function distribution | Behavioural pattern review — **never demographic (Rule E-48)** | **High — the data that would prove it is prohibited from collection** |
| **AD-07** | **MLM behaviour** | Members recruit for status, praise or informal reward | Rule E-162 growth-source test; Rule E-159 vocabulary register; **[S-D: GF-series]** | Any artefact whose success depends on the reader bringing someone is refused | Low — document-provable |
| **AD-08** | **Personality cult** | A local leader becomes the organisation locally | AC-1…AC-9; Rule E-158 substitution test; **[S-D: CU-1…CU-10]**; T1–T4 | Many spokespersons; no portraits; no eponymous artefacts; role-attribution | **Medium — affection is not controllable, only its conversion into authority** |
| **AD-09** | **Misinformation** | False claims circulate faster than corrections | The claim register makes every real claim checkable; the verification channel answers "is this person genuine?" | One calm correction, logged; silence where amplification harms | **High — the asymmetry is structural (SIM-13)** |
| **AD-10** | **Recruitment pressure** | Local leaders push membership to appear successful | Rule E-86 no conversion target; Rule E-37 density reported never targeted; **[S-C: H-03]** | **No target exists to hit, so the pressure has no source in the architecture** | Medium — informal status pressure remains |
| **AD-11** | **Status competition** | Recognition becomes a ranking contest | **[S-C: SR-2]** no ordinal numbering; **[S-D: Rule D-66]** recognition confers nothing; NEF-4 | Absolute instruments only; any published individual ranking is a breach on its face | Low |
| **AD-12** | **Wealthy-member dominance** | A donor or customer acquires de facto influence | Rule E-17 money buys a receipt; Rule E-118 ability to pay never determines access; Rule E-12 no standing from a commercial relationship | Aggregate funding disclosure; **no donor name at point of service** | Medium — informal deference is not recordable |
| **AD-13** | **Digital exclusion** | A digital-first design excludes those without devices or literacy | Rule E-72 every process has a human route; Rule E-79 the paper sheet is a complete implementation; AX-D offline mandatory | **AX-T1 read-aloud test** | Low if designed in; **prohibitive if retrofitted** |
| **AD-14** | **Language exclusion** | A language hierarchy forms in practice | Rule E-53 no language is senior; Rule E-67 simultaneous or not at all; Rule E-66 mandatory set; CI-6 language match | Terminology register; per-language L1 legal review | **Medium — practice drifts toward the language of the centre** |

**[A]** The four high-residual attacks are **AD-03 political, AD-06 caste, AD-08 personality, AD-09 misinformation**. **They share one property: each is patient, each is partly lawful or partly invisible, and each is defeated only by sustained behaviour over years rather than by any control.** No architectural instrument closes them, and this is recorded rather than concealed.

---

# PART 50 — NATIONAL TRUST AUDIT

## 50.1 The question

**[P]** Brief §136: **what would make an ordinary Indian stop trusting Sewak Sathi?** Answered by stage of encounter, because trust is lost at different speeds at different stages.

## 50.2 Ten-second failures

**[A]** Lost before any interaction, from a single artefact.

| Failure | Mechanism | Control |
|---|---|---|
| **T10-1** The artefact does not say what the organisation is | Eleven concepts, none visible **[S-ST: §18.1]** | One category sentence, identical in meaning everywhere |
| **T10-2** The artefact looks political | A colour, a symbol, an adjacency, a phrase, a guest | **[S-A: A-01 N4, N5]**; Rule E-61 colour reservation; Rule E-29 adjacency |
| **T10-3** The artefact looks like security or enforcement | Red, a garment, a marking, a formation, the word "protection" in first contact | **[S-A: A-06 V1…V8]**; Rule E-65; **[S-ST: §20.2]** — "protection" belongs in the second conversation |
| **T10-4** The artefact asks for something | A form, a download, a registration, a donation, a follow | Rule E-78 the page is unadorned; Rule E-19 ungated |
| **T10-5** The artefact is not in the reader's language | Language hierarchy in practice | Rule E-53; Rule E-66; **CI-6** |
| **T10-6** The artefact features a person rather than work | A portrait, a leader, a founder | Rule E-149; Rule E-158 substitution test |
| **T10-7** The artefact makes a claim too large for the evidence | "National", "India's", "thousands", "transforming" | Rule E-1; Rule E-4; Part 31 claim ladder |
| **T10-8** The artefact is beautifully designed and says nothing | Design gloss substituting for content | **[S-ST: §14.2 Layer 3]**: "boring transparency is more credible than polished reporting" |
| **T10-9** The artefact shows a beneficiary in need | Poverty imagery | **E-34**; Rule E-148 |
| **T10-10** The artefact promises income | Any earnings implication | Rule E-120; MC-6 |

## 50.3 Five-minute failures

| Failure | Mechanism | Control |
|---|---|---|
| **T5-1** The eight first-contact questions are not answered | Part 16 §16.1 | Rule E-73: questions 4–8 answered at first contact, not on request |
| **T5-2** The only visible action is "apply for membership" | **[S: Ch.12]** entry point | PLR-4 and PLR-5: report a need, help once |
| **T5-3** Jargon, role titles or a hierarchy diagram | **[S-ST: §20.3]**: "no jargon, no role titles, no process diagram" | AX-C cognitive accessibility; R-18 local role names |
| **T5-4** No local evidence — nothing that happened *here* | A national page with no locality | PLR-3: three things this team did nearby, with dates |
| **T5-5** No way to check a claim or a person | No verification channel | PLR-6; **[S-ST: §14.2 Layer 2]** |
| **T5-6** No way to complain, or the complaint goes to the local team only | No outward route | PLR-7; **MVLS-9** |
| **T5-7** No statement of limits — what the organisation cannot do | Over-scope impression | Rule E-81 boundary before disclosure; Rule E-116 published boundary statement |
| **T5-8** No statement of what is not yet known | A finished-product impression | TS-14; Rule E-129; claim class UNDER TEST |
| **T5-9** A login, an app or an account is required | Gated observation | Rule E-19 |
| **T5-10** A response window is promised that will not be met | Over-promising at first contact | **[S-C: HM-14]**; Rule E-5; publish the real window |

## 50.4 First-service failures

| Failure | Mechanism | Control |
|---|---|---|
| **TS-1** Nobody responds inside the promised window | Capacity or process failure | **[S-C: HM-14]**; **[S-B: §20.3]** response times |
| **TS-2** The response is a form, a broadcast or a bot | Depersonalisation | **[S-ST: §20.3 minute 3–4]**: "a real person responds… a name, a face, a time commitment kept" |
| **TS-3** The person is asked for documents that are not needed | Data maximisation | Rule E-80; **[S: App. F]** "avoid unnecessary beneficiary documents" |
| **TS-4** The person is asked to join, register or attend | Conversion pressure at the moment of need | **Rule E-13 absolute**; **[S-C: H-03]** |
| **TS-5** The decline arrives late, or without an alternative | The worst outcome is delivered badly | Rule E-5; **[S-ST: §20.3]** "a well-delivered decline is itself a trust event" |
| **TS-6** The work is done but the person never hears the outcome | Attribution loop broken | **[S-C: H-15, HM-7]** |
| **TS-7** The person is photographed | Dignity violation | Rule E-148; **E-34** |
| **TS-8** The person is thanked publicly in a way that marks them | Gratitude staging | Rule E-148; **no gratitude artefact** |
| **TS-9** The work is symbolic — everyone can tell | FW-1 failure | The task must produce a real outcome |
| **TS-10** Different people are treated differently, and it is visible | Discrimination in practice | **[S-A: A-05 clause 1]**; **[S: Ch.8 step 5]** need criteria published in advance |

## 50.5 Financial, leadership, data, safety and cultural failures

| Class | The failure that ends trust | Control |
|---|---|---|
| **TF-1 FINANCIAL** | Worker compensation late or short; a leader visibly better off; a donor's name changing an allocation; accounts published selectively | **[S: Ch.18]** priority 1 absolute; **[S-D: INV-2]**; TS-3 with worker compensation shown separately; Rule E-17 |
| **TF-2 LEADERSHIP** | A leader who cannot be complained about; a decision with no reason; a successor who is the leader's relative; a leader who never leaves | **[S-D]** entire instrument: RV-4, Rule D-54, Part 35 conflicts, SS states, Rule D-26/27 |
| **TF-3 DATA** | A beneficiary's identity disclosed; a member's data used for anything other than the stated purpose; a breach handled quietly | **[S-A: A-17…A-20]**; Rule E-99; CC-3 with statutory notification **[X][V]** |
| **TF-4 SAFETY** | A child harmed; a member injured; an intervention that escalates; a DO-NOT breached | **[S-A: A-08, A-10]**; **[S-C: SA-1…SA-7]**; Rule D-33 STOP; CC-1 |
| **TF-5 CULTURAL** | A festival, food, venue, language or greeting that excludes; a guest of honour who becomes a patron; a ritual that becomes expected | Rules E-36…E-40; CN-2; **[S-ST: §12.1 item 4]**; **[S-C: H-13]** |
| **TF-6 CORRECTION** | **An error that is not corrected, or a correction that is buried** | **Rule E-88; TS-6. This is the ES.5 weakness and the largest single trust risk in the architecture** |

**[A]** TF-6 is listed last and is first in importance. **[I]** Every other failure on this list is survivable if it is found, acknowledged and corrected quickly, because a corrected failure is evidence that the system works. **An uncorrected failure is evidence that the system protects itself.** And a person who believes an organisation protects itself will believe every subsequent claim is also protected.

---

# PART 51 — NATIONAL IDENTITY ADVERSARIAL AUDIT

## 51.1 "This organisation is not for people like me"

**[P]** Brief §137. Eleven dimensions, each with the mechanism and a **structural** safeguard — not an exhortation.

| Dimension | The mechanism that produces the sentence | Structural safeguard | Instrument |
|---|---|---|---|
| **Language** | The first artefact is in a language they do not read; a national statement arrives in one language first | Mandatory translation set; simultaneous or not published; **no language senior** | Rules E-53, E-66, E-67; **CI-6** |
| **Religion** | A festival calendar, a venue, a greeting, a food practice, a partner that signals one faith | Multi-festival calendar; no religious ritual; activity-scoped separately-branded non-exclusive partnership | Rules E-36…E-40; **[S-A: A-05]** |
| **Caste** | Routing, venue, timing and recognition that mirror the locality's divisions | Behavioural pattern review; **no caste data collected**; rules published before results | Rules E-43…E-48; TS-11 |
| **Region** | The first city's norms become the national default | Local-by-default; per-state terminology register; locality attribution | Rule E-50; Rules E-51, E-52; **CI-7** |
| **Class** | A digital-first, English-fluent, form-based, credentials-oriented process | Human route for every process; minimum data; no fee; paper equivalent; oral application | Rule E-72; Rule E-79; **[S-D: OB-1…OB-7, AX-1…AX-9]** |
| **Gender** | Timing, venue, travel, mixed-company norms, care responsibilities | Venue and timing are localisable and reviewed against who attends; family-inclusive not family-competing; paused status without penalty | CN-2; **[S-C: H-23, H-18]**; **[S-ST: §12.1 item 5]** |
| **Age** | A process that assumes either digital fluency or physical mobility; youth treated as a pipeline; elders treated as honorary | Any level at any age where law permits; Elder/Mentor standing with real function; **no campus chapter by default** | **[S-C: H-27]**; **[S-D: Rules D-84…D-88]**; Rule E-121 |
| **Disability** | An inaccessible artefact, venue, format or process | Five accessibility dimensions; accessible by default not by version; **no disclosure required for accommodation** | Part 15; Rules E-71, E-72 |
| **Profession** | A participation model that assumes discretionary daytime hours | Flexible modes; remote participation; shift-aware windows; specialist scope without command | **[S-C: H-23, H-24]**; **[S-D: SP-4]** |
| **Political perception** | A belief that the organisation is aligned, or a fear that participating signals alignment | Published neutrality code; published refusal count; **no political screening of anyone**; the approach register | **[S-A: A-01, A-04]**; TS-8; **CI-3** |
| **Digital access** | An app, an account, an online form, a QR requirement | Offline route mandatory; observation ungated; paper sheet is a complete implementation | Rules E-19, E-72, E-79 |

**[P] Rule E-181 (The Exclusion Sentence Is Sought, Not Awaited).** The organisation asks the question directly, through the comprehension and experience instruments — **CI-1…CI-7**, **[S-C: HM-2, HM-12, HM-13]** — and through the outward complaint route. **It does not infer exclusion from participation data alone, because the people excluded are precisely the people absent from the data.** **[A]** This is the deepest methodological problem in the whole audit: **non-participation leaves no record.** The only detectors are inbound queries that did not convert (**HM-1** vs **HM-4**), declines, and asking people who never joined — which requires a route to them that the organisation, by definition, does not have. **Recorded as unresolvable: MAF-series.**

## 51.2 The five further adversarial tests

**[P]** Brief §138–§143.

| Test | Question | Finding | Rule |
|---|---|---|---|
| **Culture → conformity** | At what point does a shared culture become conformity? | When deviation is read as a character judgement rather than as a disagreement; **the tripwire is the dissent count** | Rule E-141; **[S-A: A-16 test 3]** |
| **Brand → stronger than reality** | At what point does branding outrun the institution? | When a claim's class exceeds its evidence class, or when recognition outruns capacity (RC-3/RC-4) | **Rule E-182:** the claim register is audited every reporting period against the claim ladder; **any claim found above its evidence class is withdrawn and the withdrawal is published** |
| **Membership → more interesting than problems** | What if the organisation becomes more interested in members than in outcomes? | Detectable from what is measured and what is celebrated | **Rule E-183:** no internal report, dashboard or review may lead with a participation count. **The first item in every report is service outcomes and follow-up states (TS-1, TS-2)** |
| **Dramatic → rewarded over quiet** | What if public attention rewards dramatic service more than quiet service? | Attention follows spectacle; spectacle follows incentive | **Rule E-184:** recognition and publication are allocated by **outcome and follow-up state**, never by novelty, visual quality or media interest. **A resolved drainage problem and a resolved elder-isolation problem are published on identical terms with identical prominence** |
| **Famous leader → more important than the organisation** | What if the most visible leader becomes the identity? | **[S-D: CU-1…CU-10]**; **[S-A: A-16 §15.4]**; **[S-ST: §11.1]** | Rules E-149…E-158; **CI-13** spokesperson distribution; T1–T4 annual tests |
| **Business → more important than service** | What if revenue displaces mission? | **[S-ST: §17.1]**: the tension is structural, not disciplinary | **Rule E-185:** the mission-balance statement is published at the source cadence and **shows displacement before it becomes structural** **[S-ST: §17.3; M14; S-B: B-01, B-09]** |

**[P] Rule E-182 (Claim Ladder Audit).** Every entry in the claim register is audited each reporting period against the current claim-ladder class. **A claim above its class is withdrawn and the withdrawal is published in the correction log (TS-6).** **[A]** This makes Rule E-4 self-enforcing rather than aspirational, and it is one of only two controls in this document that operate on the organisation's own prior speech.

## 51.3 The three positive tests

**[P]** Brief §250's three questions that are not about breaking things:

| Test | Question | What produces a yes | What must not be used to produce a yes |
|---|---|---|---|
| **PT-1** | "I don't need to join this organisation, but I genuinely want it to exist." | Visible local results; a public record they can check; a lane that stayed fixed; a decline delivered well | Any appeal; any membership benefit; any emotional register |
| **PT-2** | "I helped once, it mattered, and I want to come back." | FW-1…FW-6; the attribution loop closing; a personal thank-you; an explicitly absent expectation | Reminders, streaks, guilt, a follow-up ask |
| **PT-3** | "I don't know the national leadership, but I trust my local team." | Local ownership of problem definition; local language; local record; **the national layer supplying capability, not identity** | Any national belonging appeal (Rule E-22) |
| **PT-4** | "I disagree with the organisation on something, but I still feel safe participating." | The dissent route; the change-request route; **preserved criticism**; refusal rights; no loyalty test | Agreement as a condition of anything |

**[A]** PT-3 is the strongest available evidence of distributed legitimacy, and it is **also the test that a national branding programme is most likely to fail** — because a national brand invites a person to relate to the centre, and PT-3 requires that they do not need to. **Rule E-3 (national is derived, never primary) exists to protect PT-3 from the organisation's own ambitions.**

---

# PART 52 — NATIONAL COMMUNICATION GOVERNANCE

## 52.1 Who may publish what

**[P] Amendment E-39.** Built on **[S: Ch.5]** National Communications, **[S: Ch.24]** authorised spokespersons, **[S: App. A §8.x]** Editor and Social Media Manager, **[S: App. E]** approval by amount/risk/data/brand impact. **No committee is created** — **[S-D: Rule D-40]**.

| Artefact class | Who may publish | Approval required | Evidence required | Correction duty |
|---|---|---|---|---|
| **A local result, with dates and locality** | Team, in its language | None beyond the Editor's accuracy check | The project and outcome record | Yes — TS-6 |
| **A task invitation** | Team | None | The task record | Yes |
| **A public local record refresh (PLR-3)** | Team | None | The records | Yes |
| **A statement on a legal or safety matter** | **Authorised spokesperson for that domain, with Safety and Legal** | **National or relevant approval [S: Ch.24]** | The incident record | Yes |
| **A statement on a financial matter** | Finance function, with Audit | National approval | The accounts and ledger | Yes |
| **A statement on a conduct or personnel matter** | **National Communications, describing process only** | Governance/HR panel route | The process record — **never the content** | Yes |
| **A correction** | **Anyone who finds the error, immediately; ratification afterwards** | **None. A correction requires no approval** | The record | — |
| **A national or multi-locality claim** | National Communications | **National approval + claim register entry (Rule E-26)** | Claim class evidence | Yes |
| **An LA-1 or LA-5 text** | National, after legal and terminology review | **Mandatory review (Rule E-68)** | The authoritative text | Yes, immediately |
| **A partnership or co-branded artefact** | Per the written agreement | Approval by brand impact **[S: Ch.33]** | The agreement | Yes |
| **A social artefact** | Social Media Manager, low-risk approved content only | **Escalate sensitive content [S: App. A §8.x]** | Already-published record (Rule E-107) | Yes |

**[P] Rule E-186 (A Correction Requires No Approval).** Any role-holder who identifies a factual error in a published artefact may and must issue the correction immediately, and ratification follows. **[A]** The reason is temporal: **an approval requirement on corrections guarantees that the correction is slower than the error, and the delay is the damage.** This is the only publication class in the table with no approval, and it is deliberate.

**[P] Rule E-187 (Editorial Independence From The Subject).** The Editor function may "reject or return content that is inaccurate, unsafe, defamatory, privacy-invasive or off-brand" and "cannot invent claims, manipulate images dishonestly, publish without approval if policy requires review, or **suppress material facts**" **[S: App. A §8.x verbatim]**. **v1.3-E adds: the Editor may not be the subject of the content they approve, and may not be line-managed by them.**

## 52.2 Brand governance

**[P]** Brief §178. **Carrying N12 and N13 forward unresolved.**

| Asset | Controlled by | Custody | Continuity | Status |
|---|---|---|---|---|
| **The name** | **`UNRESOLVED` — N12** | — | — | **Teams hold no documented right to it [S-A: N12]**; BR-9 interim recorded permission |
| **The mark / logo** | **`UNRESOLVED` — N12** | — | — | Design is a **[S: Ch.31]** blocker deliverable ("approved card mock-up") |
| **Symbols** | National Communications + Legal, within Rule E-63 | — | — | Six-question test per symbol |
| **Official accounts** | National Communications | **Dual custody [S-A: A-14 §13.4]**; **never a personal account (Rule E-155)** | Revocable access; backup admin; two-person recovery **[S: App. A §8.x]** | Specified |
| **Domain** | National + Technology | **Dual custody [S-A: A-14 §13.4]** — "domain, payment gateway, communication channels, social accounts and statutory portals" | Documented emergency-access procedure | **Ownership is `UNRESOLVED` with N13** |
| **Public statements** | Authorised spokespersons by domain and region | — | Rule E-104, E-105 | Specified |
| **Local pages** | The team, under the national schema | Team custody with City fallback | PLR-1…PL-7 schema is national; content is local | Specified |
| **Media library** | National Communications | Institutional, not personal **[S-A: A-15 M4]** | Archive and continuity (Part 53) | Specified |
| **Communication archive** | National + Audit | **Append-only; sealed on transition [S-D: TA-h]** | Retention `UNRESOLVED` | Carried forward |
| **IP in architecture, SOPs, curricula, software, data models** | **`UNRESOLVED` — N13** | — | — | **"The institution's operating system could be withdrawn by a licensor" [S-A: N13]** |

**[P] Rule E-188 (No Personal Account Is An Official Channel).** Every official channel — account, group, page, domain, number, mailbox, cloud workspace, repository, payment gateway, statutory portal — is registered to the organisation, held under dual custody, revocable, and recoverable by a documented two-person procedure. **[A]** This is **[S-A: A-14 §13.4]** applied literally to communication, and it is the control that prevents the most common real-world failure in small organisations: **the person who set up the account leaves, and the account leaves with them.**

## 52.3 Public accountability mechanisms

**[P]** Brief §128. Four mechanisms, each satisfying **[S-D: Rule D-40]**'s body-justification test:

| Mechanism | What it produces | Who owns it | If abolished |
|---|---|---|---|
| **Public issue reporting** | An inbound route reaching outside the locality | Team intake + Integrity Line | The only exit becomes exit |
| **Public correction log (TS-6)** | A dated record of every error corrected | Communications + Audit | **The organisation's central claim becomes unverifiable (ES.5)** |
| **Annual accountability report** | All of TS-1…TS-14 plus the four institutional test counts and the mission-balance statement | National + Audit | Transparency becomes selective |
| **Independent review where appropriate** | Statutory audit; external safeguarding review; periodic external governance review reporting publicly | Audit; external reviewer **[V]** | Self-audit is the only audit — **and [S-ST: §14.2] is explicit: "independence is the only credibility a self-audit cannot manufacture"** |

**[P] Rule E-189 (No Promise Of Independent Review Without A Mechanism).** The organisation may not state that it is independently reviewed unless a named independent reviewer, with a defined remit, a defined cadence and a defined publication route, is in place. **[A]** Brief §128's instruction, adopted literally: **an unmechanised promise of independence is a claim without evidence, and Rule E-8 prohibits it.**

## 52.4 Whistleblowing

**[P]** Carried from **[S-D: Part 18]** and **[S-ST: M10]**, with the communication-layer rules:

| Rule | Content |
|---|---|
| **E-190** | A report of wrongdoing reaches a route **outside the operational line** — the Integrity Line — and is available to members, partners, beneficiaries and **the public** |
| **E-191** | **Non-retaliation is absolute, with the burden reversed**: any adverse change to a reporter's tasks, allocation, standing, role or treatment during or after a report is presumed retaliatory until the organisation shows otherwise **[S-D: §18.2]** |
| **E-192** | A whistleblower's identity is **C4 sealed** with case-scoped access and the two-person rule **[S-A: A-20]** |
| **E-193** | **A reputation system may never be used to identify, discredit, trace or respond to a whistleblower.** Public comment moderation, platform reporting and misclassification handling are all prohibited as responses to an internal report |
| **E-194** | Where a report is substantiated, the correction is published (TS-6) **without identifying the reporter**, and the standard change is published (M3) |
| **E-195** | Where a report is not substantiated, that fact is recorded; **the reporter suffers no consequence, and the non-substantiation is not published in a form that identifies them** |

---

# PART 53 — DIGITAL ARCHITECTURE

## 53.1 What the digital layer is for

**[P]** Brief §102–§105. **Rule E-196 (Digital Serves Physical; It Never Replaces It).** The digital layer exists to make **local, physical, human service** discoverable, recordable, verifiable and connectable. **It does not exist to create community, and no assumption is made that it can.** **[S-C: H-24]** remote participation is real and valuable; **[S-ST: §12.2]** metro belonging design is a human problem; **[S-B: §40]**'s pilot runs with **no technology at all**, which is the proof that nothing essential depends on it.

## 53.2 The two searches

**[P]** Brief §105: "I need help" and "I want to help" are different journeys and get different entry points.

| | **I NEED HELP** | **I WANT TO HELP** |
|---|---|---|
| **First screen** | Three fields: what, where, contact (optional) | A list of tasks near me: what, where, when, how long, what to bring, what skill |
| **Never asked** | Identity, documents, caste, religion, income, health, family, membership, consent to images | Anything beyond what the task requires |
| **Always shown** | **The boundary: what this organisation cannot handle, and who can (Rule E-81)** | The expectation statement: "no obligation to do it again" |
| **Response** | Acknowledgement, reference number, **stated window** | A named person and a meeting point |
| **Human route** | Always available, and primary in low-digital localities | Always available |
| **Privacy** | Minimum safe pathway (Rule E-80); contact optional | Minimum necessary for the task |

**[P] Rule E-197 (Local Discovery Without The Hierarchy).** A person answers "what can I do near me?" using **location, language, availability, skill and interest** — and **never** needs to understand Mohalla/City/State/National, any role title, any level of the participation spectrum, or any part of the architecture. **[A]** The hierarchy is an internal governance object. **Exposing it at first contact is the single most common way an organisation signals that it is more interested in itself than in the person asking.**

## 53.3 Platform and vendor dependency

**[P]** Brief §116. **Rule E-119 (no reliance on a single vendor) specified:**

| Dependency | Risk | Control |
|---|---|---|
| **One social platform** | Account loss, policy change, algorithm change, suspension, regional ban | **The public record exists independently of any platform**; PLR is on the organisation's own domain **and** as a paper sheet (Rule E-79); no platform is the sole route to any process |
| **One messaging platform** | Same, plus group-admin loss | Dual custody; revocable access; **no organisational decision is made in a messaging group (Rule E-154)** |
| **One domain / registrar** | Expiry, dispute, seizure, loss of credentials | Dual custody; renewal diarised at two levels; registrar and ownership recorded — **and ownership is `UNRESOLVED` under N13** |
| **One app store** | Rejection, removal, policy change | **No process may require an app.** Every process has a web and a human route |
| **One cloud provider** | Outage, cost, jurisdiction, exit difficulty | Portability of the record; export tested; **[S-A: A-14 §13.4]** credentials under dual custody |
| **One AI provider** | Model change, price change, terms change, capability loss | **[S: Const. Art.12]** — AI recommends only; **no consequential process depends on a specific model**; model changes versioned (**[S-D: AI-8]**) |
| **One payment provider** | Outage, freeze, KYC change | **[S-A: A-14 §13.4]** two signatories so priority-1 payment continues |

**[P] Rule E-198 (The Public Record Is Platform-Independent).** Everything published for public verification exists in a form the organisation controls and can produce without any third party: **on its own domain, as a downloadable record, and on paper.** **[A]** This is the digital-architecture expression of Rule E-19, and it is the reason a platform loss is an inconvenience rather than an identity event.

## 53.4 Digital identity and continuity

**[P]** Brief §179–§180.

| Requirement | Design | Source |
|---|---|---|
| **Ownership recorded** | Every domain, account, workspace, repository and gateway has a recorded organisational owner and a recorded custodian | **[S-A: A-14 §13.4]**; **N13 `UNRESOLVED`** |
| **Dual custody** | No single person holds all administrative credentials | **[S-A: A-14 §13.4]** verbatim |
| **Emergency access procedure** | Documented, tested, and exercised in the annual continuity test | **[S-A: A-14 §13.4, §13.8]**; **[S-D: CT-C]** |
| **Renewal** | Diarised at two levels, with a fallback payment route | — |
| **Transfer on role change** | Same-day revocation and reissue | **[S-D: TA-b, TA-c, MVLS-11, Rule D-102]** |
| **Archive** | Communication archive is institutional, append-only, retained per schedule | **[S-A: A-15 M4]**; **[S-D: TA-h]**; **retention `UNRESOLVED`** |
| **Media library** | Institutional, not personal; consent records attached to every image | Rule E-148; **[S-A: A-17]** |
| **No personal device as the sole holder of organisational data** | Device and account review on transition | **[S-D: TA-f]** |
| **Domain ownership does not solve server architecture** | Separation of registrant, host, administrator and custodian, each recorded | Brief §180 |

**[A]** The finding worth stating: **[I]** every item in this table is already required by **[S-A: A-14 §13.4]** for *authority* continuity, and **[S-D: Part 29]** for *access* continuity. **v1.3-E adds nothing except the observation that communication assets are the ones most often left out of both, because they were set up informally by an enthusiastic person before the organisation had a process.** That person is the single point of failure, and they are usually still there.

---

# PART 54 — CONTRIBUTION PORTABILITY

## 54.1 The proposition

**[S-ST: §12.3 item 1, verbatim]** — "**One service record, held locally, verifiable nationally.** A person's contribution in Madurai is legible in Moradabad. **This is the single strongest national-binding instrument available and it is already implied by your data architecture [S: Ch.22].**"

**[S-ST: §19.2 claim 3]** — "Your contribution is recorded and portable… **This is the most valuable and least developed asset in the architecture.**"

**[S-C: H-09]** Verified Contribution Record; **[S-C: H-10]** Portable Credentials.

**[A]** v1.3-E's contribution is to specify **portability across localities**, which neither prior instrument addressed, and to hold it against the prohibition on a social-credit score.

## 54.2 The five portability requirements

**[P] Amendment E-41.**

| # | Requirement | Design | Constraint |
|---|---|---|---|
| **PO-1** | **Portable evidence** | A person's contribution record travels with them and is producible by them, in a form a third party can read | **[S-C: H-09]** fields: service, skills, training, projects, responsibilities, leadership, verified achievements, customer work, community contribution — **narrative and non-ordinal** |
| **PO-2** | **Verification** | A receiving locality, employer or institution can confirm that a stated contribution is genuine | The public verification channel (PLR-6); **role-and-validity confirmation only, never a personal record** |
| **PO-3** | **Privacy** | The person controls disclosure; **nothing is disclosed without their action** | **[S-A: A-17…A-20]**; **[S-C: CR-4]** no sale, no sharing, no inference, no third-party profiling; **Rule E-198** the record is not platform-hosted in a form the person cannot export |
| **PO-4** | **Transfer** | On moving locality, the record is recognised at the destination without re-verification of what was already verified | **A destination locality may not demand re-proof of a verified contribution**; it may verify authenticity |
| **PO-5** | **Fraud prevention** | A record cannot be inflated, duplicated, transferred to another person, or fabricated | Append-only; alteration creates a new version with reason **[S-D: SEC-6]**; dual confirmation for consequential instruction **[S-D: SEC-2]**; audit trail preserved |

## 54.3 The social-credit line

**[P] Rule E-199 (Portability Is Not A Score).** A portable contribution record differs from a social-credit system in six specific respects, and **all six must hold**:

| # | Property of the record | Property of a social-credit system |
|---|---|---|
| 1 | **Describes work performed** | Describes behaviour, conformity and loyalty |
| 2 | **Owned and controlled by the person** | Owned by the institution, granted to the person |
| 3 | **Disclosed only by the person's action** | Queried by third parties without the person's action |
| 4 | **Non-ordinal — no rank, no score, no band** | Ordinal by construction |
| 5 | **Never determines access to ordinary community life, dignity, need assessment or anything outside the organisation** — **[S-C: CR-1…CR-4]** | Determines access broadly |
| 6 | **Correctable, appealable and erasable** — **[S: Const. Art.6; S-A: A-17 P2, A-20 §19.7]** | Persistent and accumulative |

**[A]** Property 4 is the one most likely to erode, because an employer or institution receiving a record will want to rank it. **[P] Rule E-200 (The Record Contains No Ordinal Element).** No field in the contribution record or credential may be a score, a rank, a band, a percentile, a grade, a star count or a comparative statement. **Content is dated, specific and narrative.** A credential certifies **a demonstrated skill against a published standard** — absolute, never comparative **[S-C: §23.1 instrument 3]**.

## 54.4 What portability costs and what it requires

| Requirement | Status | Note |
|---|---|---|
| A record schema that is language-independent | **[S-C: H-09]** proposed | Terminology register required (Part 14) so a role word means the same thing in two states |
| A verification route reachable from another locality | **PLR-6; the channel is national (Part 17 §17.4)** | Requires ≥ 2 localities — **not testable at CL-0/CL-1** |
| Consent and disclosure control | **[S-A: A-17…A-20]** | Retention `UNRESOLVED` |
| Anti-fraud controls | **[S-D: SEC-series]** | Requires the platform, or a paper equivalent with dual confirmation |
| External recognisability | **Depends entirely on third parties** | **The organisation can make a record portable; it cannot make anyone accept it.** This is the largest uncertainty in Part 54 and is recorded as such |

**[A]** The last row is the honest finding. **[I]** A portable credential is valuable only if a receiver — an employer, a college, another organisation, an official — treats it as meaningful. **That is outside the architecture's control and cannot be designed.** What can be designed is that the record is **checkable**, which is the property that makes acceptance possible: an employer who can verify a claim in thirty seconds is more likely to rely on it than one who cannot. **[P] Rule E-201: the credential's value proposition to a third party is checkability, not prestige.**

---

# PART 55 — NATIONAL RECOGNITION

## 55.1 What recognition rewards, and what it never rewards

**[P]** Brief §110. **[S-C: H-08]** six instruments and **[S-D: Rule D-66]** recognition confers nothing are carried forward unchanged.

| Recognised | Never recognised |
|---|---|
| **Contribution** — what was done, dated, with an outcome | **Recruitment** — Rule E-24, Rule E-135 |
| **Reliability** — promises kept, windows met, returns made | **Wealth** — Rule E-17; no donor recognition at point of service |
| **Learning** — a lesson recorded, a standard improved, a playbook written | **Popularity** — **[S: Ch.25]**; **[S-D: LC-6/LC-18]** popularity-contamination controls |
| **Service** — outcomes, including unchanged and worsened reported honestly | **Attendance** — no count of events attended |
| **Collaboration** — a partnership that worked; a handover completed with gaps recorded | **Seniority** — **[S-D: D-5]**; tenure is inadmissible evidence |
| **Development** — a successor who became ready; a specialist who was certified | **Visibility** — no recognition for media appearances, speaking or being photographed |

**[P] Rule E-202 (Absolute Instruments Only, At Every Level).** National recognition uses the same absolute instruments as local recognition — appreciation, proof, credential, milestone, story — and **no comparative or ordinal instrument exists at any level.** **[S-C: §44.3]**; **[S-C: SR-2]**.

## 55.2 The hero-language test

**[P]** Brief §69. Four candidate titles tested:

| Term | Connotation | Compatibility with the architecture | Verdict |
|---|---|---|---|
| **Hero** | An individual who acts alone, exceptionally, and is celebrated for it | **Contradicts** the paired first task (FW-3), the attribution grammar (Rule E-145 — the contributor is the subject of the *action* sentence, and a hero is the subject of a *character* sentence), and **[S-A: A-16 §15.4]** honour contribution and neighbourhood, never a person's position | **REFUSED** |
| **Warrior / fighter** | Combat, an adversary, victory over an enemy | **Directly contradicts** Rule E-96 complement-never-rival, the prohibited-outrage register, and **[S-A: A-08]**'s entire doctrine. **Also engages MC-3 vigilante perception** | **REFUSED absolutely** |
| **Guardian** | Protection, custody, authority over others | **Contradicts [S-A: A-06]** — no authority by appearance; and implies a protective mandate the organisation does not hold and must not appear to hold | **REFUSED** |
| **Sewak / server / contributor / neighbour** | Service, mutuality, ordinariness | **Consistent** — *Sewak* is already in the name; **[S-C: §30.4]** permits descriptive use in a language where the term is native, prohibits prescriptive use | **PERMITTED, descriptively, in languages where it is native** |

**[P] Rule E-203 (Service Identity Over Combat Identity).** No organisational term, title, campaign, artefact, award, team name, channel name or programme name may use combat, military, heroic, guardian, warrior, fighter, enemy, battle, front-line or victory vocabulary. **[A]** The organisation contains a protection pillar, which is precisely why the prohibition is necessary: **[S-ST: §18.2 MC-3]** rates the vigilante misclassification **Severe**, and **[S-A: A-06]** exists because "adjacency is read as equivalence by observers and by cameras." **Vocabulary is adjacency.**

## 55.3 Local hero, national hero

**[P]** Brief §111. **Rule E-204 (No National Hero Exists).** There is no national recognition instrument that names a person, and no national "hero", "member of the year", "top contributor" or equivalent. **National recognition recognises a locality, a project, an outcome or a standard — never a person.**

| Principle | Design |
|---|---|
| **A local contributor does not need national fame to matter** | Their record, credential and story exist locally and are complete there. **[S-C: §8.4]**: leadership is not a higher form of service, and national recognition is not a higher form of recognition |
| **National recognition must not erase local contribution** | Locality attribution is mandatory on every published outcome **[S-C: H-26 technology effect]**; Rule E-146 no flattening; Rule E-147 the person who did it tells it |
| **The centre is never the hero** | Brief §112: local problem → local people → local action → local outcome → **national learning** |
| **A national story is a collection of local stories, not a summary** | Rule E-146 |

**[A]** The uncomfortable consequence: **[I]** capable people who want national recognition will not get it from this organisation, and some will leave for one that gives it. **[S-ST: F-24]** prices that exit. **[P]** The response is not to create national recognition but to make the **credential portable and externally checkable** (Part 54), which gives the person something better than fame: **a record a third party will verify.** Rule E-201 — the value proposition is checkability, not prestige.

---

# PART 56 — NATIONAL SPECIALIST NETWORK

## 56.1 What it is

**[P]** Brief §191: a national network of specialists who can support local teams across **safety, finance, HR, AI, technology, planning, communications, legal/compliance** — without creating an elite disconnected class.

**[A]** The architecture already exists: **[S-C: §47]** twelve specialist domains with hard limits; **[S-C: H-11]** ladder S1…S6; **[S-D: Part 13]** SP-1…SP-6 with authority ceilings; **[S-B: §26.4]** City shared services; **[S-B: B-21]** City Shared Services Contract; **[S-ST: F-03(10)]** the out-of-team Funds reviewer.

**[P] v1.3-E adds only the public-facing rules**, because the specialist network is the one national capability that a locality can *see* arrive — and therefore the one that can produce national identity without producing national belonging (Rule E-57).

| Rule | Content |
|---|---|
| **E-205** | A specialist **advises, never commands** **[S-ST: §9.1; S-D: SP-4]**, and holds no RBAC command permission on the specialist track |
| **E-206** | A specialist engagement is **on local request or under an immutable standard**, never as direction (Rule E-55) |
| **E-207** | A specialist's engagement, scope, conflict declaration and outcome are **recorded and published in aggregate**, so the network is visible without being personal |
| **E-208** | **No specialist tier, grade, title or marking is publicly displayed** — SP stages confer scope, not standing (Rule E-202; **[S-C: SR-2]**) |
| **E-209** | The network may not become a closed body: **entry is by evidence-linked assessment against a published standard, open to any member at any level** **[S-C: §47.3; S-D: SP-series]** |
| **E-210** | **The elite-disconnection test:** a specialist who has not performed a local delivery task within a stated period is not eligible for a standard-setting role (SP-6). `[P]` Period `UNKNOWN — MEASURE IN PILOT` |

## 56.2 Why the specialist network is the national binding mechanism

**[A]** Rule E-57 concluded that national identity should be **epistemic**: "the same thing happens elsewhere and it is checkable." **[I]** But checkability alone is cold. **The one national event that produces genuine feeling without producing belonging-pressure is a specialist arriving** — **[S-C: H-26 field 5]**: "identity is produced by **observable events** — a specialist arriving, a local result published — not by claims."

**[A]** A specialist arriving is: national capability, visibly deployed, on local request, for a local problem, with no authority over anyone, leaving again afterwards. **It demonstrates the network without describing it, and it is the only national artefact that does not require anyone to feel national.** That is why Rule E-55 restricts the national layer to exactly this class of act.

---

# PART 57 — KNOWLEDGE NETWORK

## 57.1 Local expertise to national capability

**[P]** Brief §192: a successful local solution becomes **documented knowledge → training → reusable capability.**

```
LOCAL SOLUTION        it worked here, and we can show the record
   |
   v
DOCUMENTED KNOWLEDGE  a playbook entry (PB-3, PB-7) or a case study,
   |                  with its conditions stated -- what had to be true
   v                  for it to work  [S-A: A-15 M5 "did it work"]
STANDARD CHANGE       a change request through the versioned route
   |                  [S-A: A-15 M2/M3]  --  any member may propose
   v
TRAINING              a training module or category update
   |                  [S: Ch.12]  --  delivered by the trainer cadre
   v
REUSABLE CAPABILITY   another locality can do it, and can be assessed on it
   |
   v
PUBLISHED             the pattern is published with its variance (Part 34)
                      so a reader can see WHY it differs between places
```

**[P] Rule E-211 (Conditions Travel With The Solution).** A documented local solution must state **what had to be true** for it to work — density, literacy, season, partner set, income rhythm, existing civil-society density. **A solution published without its conditions is a solution that will be copied into a place where it fails, and the failure will be attributed to the copying locality rather than to the incomplete record.**

## 57.2 Failure to national learning

**[P]** Brief §193: a local failure must not automatically become a national shame.

| Step | Design |
|---|---|
| **Failure** | Recorded as an incident or an outcome state of unchanged/worsened **[S: Ch.15; S-A: A-09]** |
| **Evidence** | The record, with the missing-information field where it was a crisis decision **[S-D: Rule D-120]** |
| **Learning** | M5 lessons entry with the **"did it work"** column **[S-A: A-15 M5]** |
| **Correction** | A standard change through M3, or a playbook update, or a training change |
| **Updated training** | **[S: Ch.12]** category updated; versioned |
| **Safer replication** | The next locality receives the solution **with the failure attached** — PB-7 known failures, "including the failures of previous holders" **[S-D: §28.2]** |

**[P] Rule E-212 (A Failure Is Published With Its Learning, Not Instead Of It).** A failure is never published as shame and never suppressed as embarrassment. **It is published as a record with a correction and a condition.** **[A]** The prohibition on hiding failure is **[S: App. A §16.3]**'s "report results honestly, including failures" and **[S-C]**'s honesty scoring; **the prohibition on publishing it as shame is Rule E-9.** Both bind, and the resolution is the form: **facts, conditions, corrections, no adjectives and no persons.**

## 57.3 The knowledge repository

**[P]** Brief §194. Contents and constraints:

| Content | Constraint |
|---|---|
| Policies and standards | Versioned **[S-A: A-15 M2]**; change route open to any member **[M3]** |
| Playbooks PB-1…PB-10 | **[S-D: Part 28]**; PB-7 known failures is the most valuable and least written section |
| Case studies | **Conditions stated (Rule E-211); no identification; consent where any personal element appears** |
| Lessons entries | M5 with the "did it work" column |
| Training material | LA-2, translated by need |
| Templates | LA-1 templates require legal review before use |
| Terminology register | Per language, per state, including **refusals** (Rule E-45, Rule E-161) |
| Corrections and refusals | TS-6, TS-8 — **the two logs that must not be empty (Rule E-88)** |

**Privacy:** the repository is **C2 internal** by default, with **C3 and C4 content excluded absolutely**; data minimisation per **[S-A: A-18]**; access per **[S-A: A-19]**; and **the public-facing subset is exactly TS-1…TS-14 and PLR-1…PL-7.**

---

# PART 58 — NATIONAL EXPANSION GATES

## 58.1 The eight gates

**[P] Amendment E-30 (with Part 32).** Brief §224 specifies GATE E0…E7 and instructs that they not be assumed mandatory until justified. **Each is analysed below; seven are mandatory and one is conditional.**

| Gate | Requirement | Justification for mandatory / conditional | Evidence | Blocks |
|---|---|---|---|---|
| **GATE E0** | **Identity coherent** — the category sentence, the "what we are not" list, the eight immutable items and the ten localisable items are approved, registered and translated where required | **MANDATORY.** Without it, every locality improvises a self-description, and eleven misclassifications become eleven thousand | Registered terminology; approved texts; Rule E-66 | Any public artefact |
| **GATE E1** | **Local communication understandable** — PLR-1…PL-7 exist for the locality; the eight first-contact questions are answerable; the accessibility floor is met; the mandatory translation set exists in the locality's language | **MANDATORY.** A locality that cannot explain itself cannot serve, and cannot be checked | **CI-2**; AX-T1/T2/T3; PLR present and current | Any inbound public engagement in that locality |
| **GATE E2** | **No major political, religious, cult or MLM confusion** — the neutrality code adopted and published; the refusal log operating; no religious ritual; no participation-linked term in any formula; no prohibited vocabulary | **MANDATORY.** These are the four Severe and High misclassifications, and each carries legal, safety or reputational consequence | TS-8; **CI-3, CI-4, CI-5**; formula audit; vocabulary register | Any public activity in the locality |
| **GATE E3** | **Pilot evidence** — the shared pilot has run a full cycle; PS-1…PS-12 evaluated; PF-1…PF-10 checked; `H_gov` measured; **LM/CI measurements recorded** | **MANDATORY.** Everything above CL-1 depends on it | **[S-B: §40; S-C: §57; S-D: Part 41]**; Part 72 | **Any claim above CL-1** |
| **GATE E4** | **Repeatable local communication** — the communication set (PLR, first-contact artefacts, correction process, complaint route) has been reproduced in a second locality by people who were not the authors | **MANDATORY from the second locality.** A process only its author can run is not a process | **[S-D: CT-B]** analogue for communication; RT-1 | Expansion to a third locality |
| **GATE E5** | **Multi-locality evidence** — ≥ N localities in **materially different contexts** with CL-2 evidence each; **at least one independently verified impact claim; at least one published correction** | **MANDATORY.** **[S-ST: §14.3 items 8, 9; §30.3 item 10]** | Published records; external verification, named | Any city-level claim (CL-4) |
| **GATE E6** | **City/state communication capacity** — translation, publication, moderation, verification-channel and crisis capacity **costed and funded** (Rule E-168); the City divisor measured | **MANDATORY.** §42.5's finding: communication is currently an unfunded obligation | `H_gov` including communication; **Rule E-169** burden test | State-level claim (CL-6) |
| **GATE E7** | **National reputation infrastructure** — all ten **[S-ST: §14.3]** and all fifteen **[S-ST: §30.3]** pre-conditions; **N12 and N13 resolved**; mission lock executed; insurance in force; privacy programme live; language equity demonstrated | **MANDATORY, and Rule E-60 makes N12/N13 independently blocking** | Each item evidenced | Any national claim (CL-8) |
| **GATE E-X** | **A national service day, a national campaign, a celebrity relationship or a paid media programme** | **CONDITIONAL — and the condition is that it is never satisfied below CL-7, and is prohibited at any stage by Rules E-25, E-111 and E-144** | — | — |

**[A]** GATE E-X is recorded as conditional rather than mandatory because the brief instructs that gates not be assumed mandatory without justification — and **the justification here runs the other way: it is a gate whose purpose is to refuse.** Its existence in the register prevents a national campaign from being proposed as a routine expansion step.

## 58.2 What never justifies expansion

**[P] Rule E-213.** Expansion may not be authorised on the basis of: increased membership, increased followers, increased funding, increased media attention, increased inbound demand, a political or commercial invitation, a partner's offer, a leader's ambition, a locality's enthusiasm, or a successful pilot alone.

**Expansion requires evidence of:** local viability, leadership supply and succession, economics inside `σ_max`, safety capability, governance capacity, human participation, repeatability — **which is exactly [S-D: XG-1…XG-8]**, adopted here without modification, plus the communication capacities GATE E1, E4 and E6.

**[P] Rule E-214 (The Communication Gate Is Additional, Not Alternative).** GATE E0…E7 do not replace **[S-D: XG-1…XG-8]** or **[S-B]**'s economic conditions. **All three sets must pass.** A locality that can be served and led but cannot be explained fails; a locality that can explain itself but cannot be served fails.

---

# PART 59 — NATIONAL IDENTITY MATURITY

## 59.1 The levels

**[P] Amendment E-44 — NI-0 … NI-6.** Brief §171 requires that thresholds not be defined arbitrarily and that the evidence required be specified. **A level is determined by what actually exists and is exercised, not by what is documented** — the same discipline **[S-D: MAT-0…MAT-5]** applies.

| Level | Name | **Evidence required** | Claim-ladder correspondence | Identity property |
|---|---|---|---|---|
| **NI-0** | **Conceptual identity** | A name; a category sentence in draft; the eight immutable and ten localisable items identified; **no public artefact beyond a truthful statement of what exists** | **CL-0** | Nothing is recognisable; the identity is a document |
| **NI-1** | **Pilot identity** | One locality; PLR-1…PL-7 published; GATE E0, E1, E2 passed; the mandatory translation set exists in the locality's language; the correction and refusal logs operating | **CL-1** | One neighbourhood can explain the organisation; nobody outside it can |
| **NI-2** | **Validated local identity** | One full cycle with published accounts, published outcomes including unchanged and worsened, zero unresolved serious safety incidents, ≥1 published correction, a functioning complaint route with a published outcome | **CL-2** | **A stranger in that locality can check a claim. This is the first level at which "verifiable" may be said** |
| **NI-3** | **Multi-locality identity** | ≥ N localities in materially different contexts at NI-2; **≥1 independently verified impact claim**; the record is legible across localities (PO-4) | **CL-3** | The pattern is visible: "the same thing happens elsewhere and it is checkable" (Rule E-57) |
| **NI-4** | **State-level identity** | A state operating as coordination, not as a formal hierarchy **[S-ST: §2.3]**; language equity demonstrated across the state **[S-ST: §30.3 item 13]**; standards versioned without drift | **CL-6** | State-level recognition without a state-level belonging claim |
| **NI-5** | **Multi-state identity** | ≥ N states at NI-4; the City divisor measured per environment type (Rule E-138); succession exercised at multiple levels; communication capacity costed and funded (GATE E6) | **CL-7** | "A network in N states" is a factual statement |
| **NI-6** | **National identity** | All ten **[S-ST: §14.3]** and all fifteen **[S-ST: §30.3]** pre-conditions; **N12 and N13 resolved**; mission lock executed; insurance in force; privacy programme live | **CL-8** | A national network of independently operating local teams whose records are published — **and still no national belonging claim (Rule E-22)** |

**[P] Rule E-215 (A Level Is Determined By The Weakest Locality Claimed).** An organisation may not claim NI-3 on the strength of its best three localities while a fourth operates below NI-1. **The level is the level of the weakest locality included in the claim.** **[A]** This mirrors **[S-D: XG-8]** — no expansion that drops an existing unit below continuity cover — and prevents the standard failure of scale claims: **averaging a handful of good units into a network-level assertion.**

## 59.2 What does not mature

**[A]** Three properties are constant across NI-0 to NI-6 and never become permissible:

| Constant | Reason |
|---|---|
| **No national belonging claim** | Rule E-22; Rule E-3 — national is derived, never primary |
| **No ordinal or comparative recognition** | Rule E-202; **[S-C: SR-2]** |
| **No claim of trust, trustworthiness or being beloved** | Rule E-90 |

---

# PART 60 — NATIONAL ADOPTION MATURITY

## 60.1 The levels

**[P] Amendment E-44 (part 2) — MA-0 … MA-6.** Brief §172: **Awareness → Understanding → Participation → Return → Community → Verified contribution → Leadership/building**, with the explicit instruction that national adoption does not mean high membership.

| Level | Name | **Determined by** | Measurement | Not determined by |
|---|---|---|---|---|
| **MA-0** | **Unknown** | Nobody outside the locality has heard of it | — | — |
| **MA-1** | **Awareness** | People have encountered a **result**, not a message | **HM-1** inbound contacts; unsolicited local questions | Follower count; impressions; reach |
| **MA-2** | **Understanding** | People can answer the eight first-contact questions correctly | **CI-2**; **HM-2** comprehension | Volume of content published |
| **MA-3** | **Participation** | People have completed a first interaction — need reported, question asked, claim checked, or task done | **HM-4**, **HM-5**; **CI-15** unaffiliated repeat use | Sign-ups; registrations |
| **MA-4** | **Return** | People come back voluntarily | **HM-9 — second contribution within the window; the primary measure [S-ST: §21.3]** | Retention campaigns; reminders |
| **MA-5** | **Community** | People can name two others here; local relationships exist that would survive the organisation's withdrawal | **HM-3** belonging; Rule E-94 disappearance test | Attendance; event counts |
| **MA-6** | **Verified contribution and building** | People hold portable records and credentials; some build teams, ventures and standards | **HM-10**; **[S-D: LM-14]**; PO-1…PO-5 | Member count; leadership count alone |

**[P] Rule E-216 (Adoption Maturity Is Measured Per Locality, Never In Aggregate).** A national MA level does not exist and may not be stated. **[A]** Reason: an aggregate adoption level is the exact instrument that produces Rule E-183's failure — a number that leads a report and becomes the thing the organisation optimises. **Per-locality measurement makes the number un-optimisable, because there is no single number.**

## 60.2 The two maturity models compared

**[A]** NI and MA are independent, and the relationship between them is the diagnostic:

| NI \ MA | MA-1 | MA-3 | MA-4 | MA-6 |
|---|---|---|---|---|
| **NI-0/1** | **Normal at CL-0/1** | Early success | Early success | **Suspicious — how, with no published record?** |
| **NI-2** | **Under-adopted — publication is not reaching people** | Normal | Good | Good |
| **NI-3+** | **Serious problem — identity without adoption is branding** | **Problem** | Normal | Good |
| **Any NI with MA-6 but NI below 2** | — | — | — | **The best possible position: real contribution without a claim. Rule E-4 says stay here until the evidence exists** |

**[A]** The finding: **the healthy trajectory is MA ahead of NI at every stage.** Adoption maturity should always outrun identity maturity, because identity is derived from adoption and not the reverse. **Where NI outruns MA, the organisation is branding — and Rule E-182's claim-ladder audit is the detector.**

---

# PART 61 — NATIONAL EVIDENCE ARCHITECTURE

## 61.1 One integrated evidence system

**[P] Amendment E-45.** Brief §167: institutional + economic + human + leadership + communication + service → integrated evidence → decision → expand / correct / pause. **This is the bridge from architecture to empirical validation.**

```
      INSTITUTIONAL            ECONOMIC              HUMAN
   [S-A: A-01..A-23]        [S-B: B-P-01..14]      [S-C: HM-1..HM-15]
   neutrality, legal,       H_gov, sigma_max,      comprehension, return,
   privacy, continuity,     priority 1, reserves,  dignity, promises kept,
   refusal log (TS-8)       m_lead [U]             belonging, friction
          \                     |                     /
           \                    |                    /
            v                   v                   v
     +---------------------------------------------------------+
     |              INTEGRATED EVIDENCE SET                    |
     |  one record per locality per period, with claim classes |
     +---------------------------------------------------------+
            ^                   ^                   ^
           /                    |                    \
          /                     |                     \
      LEADERSHIP          COMMUNICATION              SERVICE
   [S-D: LM-1..LM-15]    [v1.3-E: CI-1..CI-15]    [S: Ch.15, App. F]
   succession coverage,  misclassification,       verified outcomes,
   continuity exercise,  claim traceability,      follow-up states,
   decision records,     correction latency,      incidents,
   dependency, load      language match           declines and alternatives
                              |
                              v
                    +---------------------+
                    |      DECISION       |
                    +---------------------+
                       /        |        \
                      v         v         v
                 EXPAND     IMPROVE     PAUSE
```

**[P] Rule E-217 (One Record Per Locality Per Period).** The six evidence families are reported **together, for the same locality, for the same period.** **[A]** Reported separately, each family is optimisable in isolation and each conceals the others: leadership can look healthy while communication is unfunded; communication can look excellent while the economics are inside `σ_max` only because leadership work is unpaid (**[S-D: Rule D-126]** deficit). **A single integrated record per locality makes substitution visible.**

## 61.2 The three expansion outcomes

**[P]** Brief §168. **EXPAND is not the default success condition.**

| Outcome | Meaning | Trigger | Consequence |
|---|---|---|---|
| **EXPAND** | Evidence supports replication **at the next claim-ladder class** | All of **[S-D: XG-1…XG-8]**, all applicable **GATE E0…E7**, and the integrated evidence set shows no capacity in the critical band | Authorised expansion, recorded as a cost (**[S-D: Rule D-44]**) |
| **IMPROVE** | The system works but requires correction | One or more measurements outside band; a correction log entry open; a standard change pending | **No expansion.** Correction, then re-evaluation at the next period |
| **PAUSE** | Critical assumptions are not validated | A PF-class failure **[S-D: Part 41 §41.4]**; priority-1 payment at risk; a Severe misclassification uncorrected; a data or safeguarding event; **N12/N13 unresolved where reliance has grown** | **Stop growth activity; publish the pause; continue service to existing commitments** |

**[P] Rule E-218 (A Pause Is Published).** A decision to pause is published in the same place, with the same prominence and in the same languages as a decision to expand. **[A]** This is Rule E-176's logic applied to strategy: **publishing pauses is the credibility condition for publishing expansions.** An organisation that announces every opening and no pause is understood, correctly, to be promoting rather than reporting.

**[P] Rule E-219 (The Default Outcome Is IMPROVE).** Where the evidence is incomplete, ambiguous, of LOW confidence, or silent on a critical capacity, **the outcome is IMPROVE, not EXPAND.** **[A]** This inverts the ordinary institutional default and is the single most important governance rule in this Part: **an organisation expands when it can prove it should, not when it cannot prove it should not.**

## 61.3 The claim classes meet the evidence labels

**[P]** The two classification systems (Part 31 §31.2 claim classes and §31.3 evidence labels) combine into one public grammar:

| Claim class | Permitted evidence labels | Example of correct public form |
|---|---|---|
| **PROVEN** | Independently verified | "An external reviewer confirmed on [date] that [outcome]. Here is their report." |
| **OBSERVED** | Measured; estimated | "We counted this: [figure], in [locality], over [period]. Here is the record." |
| **REPORTED** | Self-reported | "[Person/partner] told us this. We have not verified it." |
| **PROPOSED** | — | "We propose to do this. It is not yet approved." |
| **UNDER TEST** | Pending | "We are testing whether [X]. We will report on [date]. Success would look like [Y]." |
| **UNKNOWN** | Pending | "We do not know yet. We will know when [condition]." |

**[P] Rule E-220 (No Class Promotion Without A Label Change.)** A claim may not move from REPORTED to OBSERVED to PROVEN without its evidence label changing accordingly, and the change is recorded in the claim register. **[A]** This is the grammar that makes under-claiming enforceable: **the two classifications are independently auditable, and a mismatch between them is detectable from the artefact alone.**

---

# PART 62 — NATIONAL IDENTITY DECISION REGISTER

**[P]** Brief §211 mandates a register `N-E-01 … N-E-N` with: decision, why it matters, current status, source, options, risks, dependencies, validation required. **The twenty minimum items the brief names are all present, plus seven more identified by the analysis.**

| ID | Decision | Why it matters | **Status** | Source | Options | Risks | Dependencies | Validation |
|---|---|---|---|---|---|---|---|---|
| **N-E-01** | **National identity definition** — is national identity affective or epistemic? | Determines every artefact | **`PROPOSED`** — Rule E-57 epistemic before affective | **[S-C: H-26]**; **[S-ST: §11.3, §12.3]** | Affective (symbols, ritual, belonging) / epistemic (records, checkability) / hybrid | Affective → NEF-1, NEF-3, MC-1, MC-2 | All of Part 11 | Cultural and communications review **[V]** |
| **N-E-02** | **Visual identity** — is there a mark at all, and what is it? | Every surface, every locality | **`UNRESOLVED` — blocked by N-E-19** | **[S: Ch.31]** blocker deliverable "approved card mock-up"; **[S-A: A-06 V8]** | Word-only / word + mark / mark-only | A mark creates ownership, imitation and adjacency risk | N12; Rule E-60 | Design, legal and per-state political review **[V]** |
| **N-E-03** | **Red / crimson usage** | The brief's explicit test | **`PROPOSED — RED MAY NOT BE DOMINANT`** (Rule E-61) | **[S: Ch.1]** red = safety/protection/risk/prohibitions; **[S-A: A-01 N2, N4]** | Red dominant / red accent / red prohibited / another colour | Red dominant collides with internal semantics and political fields | Part 13 analysis | **Per-state political-association review [V]** **[S-C: H-26 field 11]** |
| **N-E-04** | **Language policy** — which languages, in which registers, from when? | Hard exclusion if wrong | **`PROPOSED`** — Rules E-53, E-66, E-67 | **[S-C: §30; H-25]**; **[S-A: A-05 clause 8, A-17 P3]** | English-first / Hindi-first / locality-first / simultaneous-multilingual | Any senior language creates a status hierarchy | Terminology register; translation capacity | Legal review of L1 texts per language **[V]** |
| **N-E-05** | **Symbols** | Authority by appearance | **`PROPOSED — highly restricted`** (Rule E-63) | **[S-A: A-06 V3, V8]**; **[S-ST: §12.3 item 4]** "symbols empty of rank" | None / one activity symbol / a symbol set | Any symbol suggesting authority or rank | Rule E-63 six-question test | Cultural and legal **[V]** |
| **N-E-06** | **Dress** | Vigilante and military perception | **`SETTLED BY SOURCE — NO UNIFORM`** | **[S-A: A-06 V1, V2, V3, V7]** | No uniform / optional apparel / role identifiers / event clothing | **V1…V3 prohibit the first three; V5 permits task-scoped removable identification only** | — | Legal **[V]** on any high-visibility garment |
| **N-E-07** | **Ceremonies** | Cult, political and religious risk | **`PROPOSED — most refused`** (Part 36 §36.1) | **[S-C: H-13]** six tests; **[S-D: §21.7]**; **[S-A: A-16 §15.4]** | None / handover and credential conferral only / a fuller set | Any loyalty object is a cult vector | **[S-C: H-13]** tests | Cultural **[V]** |
| **N-E-08** | **National service day** | Coordination cost, exclusion, crowd risk | **`PROPOSED — NOT ADOPTED`** (Rule E-144) | Brief §66; **[S-A: A-01 N3]** crowd mobilisation | Adopt / refuse / local occasions only | A fixed national date excludes and creates a crowd | Part 36 §36.3 analysis | — |
| **N-E-09** | **Public claims** — what may be said, at what stage | Over-claiming is the primary reputational risk | **`PROPOSED`** — CL-0…CL-8; six claim classes; five evidence labels | **[S-ST: §11.3, §18.3, §30.3]** | Claim ladder / free claims / no claims | Free claims → RC-4; no claims → invisibility | Claim register; audit | Legal on any status or regulatory claim **[V]** |
| **N-E-10** | **National spokesperson model** | One voice is one point of failure | **`PROPOSED`** — domain and region, many voices | **[S: Ch.24]**; **[S-A: A-16 §15.4]**; **[S-D: CU-1]** | One national spokesperson / domain-and-region model / local only | One voice → NEF-6, SIM-10 | Rule E-104, E-105 | — |
| **N-E-11** | **Social media** — role, metrics, moderation | Vanity metrics; platform dependency | **`PROPOSED`** — distribution of the public record only | **[S: Ch.24]**; **[S: App. A §8.x]**; **[S-ST: R5]** | Primary channel / distribution channel / none | Primary → MC-8, RC-4, platform risk | Part 53 | — |
| **N-E-12** | **Partnerships** — brand usage, endorsement, exit | Adjacency and capture | **`PROPOSED`** — PT-A…PT-F; BR-1…BR-12 | **[S: Ch.5 §4.4; Ch.29; S-A: A-05 clause 5]** | Open / documented-and-scoped / closed | Open → MC-5, capture; closed → isolation | Signatory authority `Not final` **[S: Ch.33]** | Legal **[V]** |
| **N-E-13** | **Celebrity relationships** | Trust does not transfer; dependency and contagion | **`PROPOSED — PROHIBITED as a legitimacy instrument`** (Rule E-111) | Brief §47; **[S-A: A-01 N6]** | Seek / accept / refuse | Refusing forgoes attention; accepting creates dependency | Rule E-25 no emotion budget | — |
| **N-E-14** | **Public transparency** — what is published, to whom | The central gap in the whole source set | **`PROPOSED`** — five audiences; TS-1…TS-14; Rule E-99 three tests | **[S-ST: §14.1, §14.2]**; **[S-A: A-17]** | Full publication / classified publication / minimal | Full → privacy harm; minimal → invisible honesty | Classification; suppression threshold | **Data-protection [V]** |
| **N-E-15** | **National branding threshold** — when may national branding begin | Brand outrunning institution | **`PROPOSED`** — GATE E7 + Rule E-60 + NI-6 | **[S-ST: §14.3, §30.3]** | Stage-gated / immediate / never | Immediate → RC-4; never → invisibility at scale | N12, N13 | — |
| **N-E-16** | **National expansion threshold** | Capacity-constrained growth | **`PROPOSED`** — GATE E0…E7 **plus** **[S-D: XG-1…XG-8]** plus **[S-B]** economics | **[S-ST: §30.3]**; **[S-D: Rule D-43]** | Three-gate conjunction / single gate | Single gate → the weakest capacity is exceeded | Rule E-214 | — |
| **N-E-17** | **Brand ownership** | Teams hold no documented right to the name | **`UNRESOLVED — CARRIED FORWARD`** | **[S-A: N12]**; **[S: Ch.4; Ch.33]** | Founder/Krytos-owned / entity-owned / licensed / held in trust | Any choice has succession and dissolution consequences | Entity structure | **IP counsel [V] — [S-A: V8]** |
| **N-E-18** | **IP ownership** — architecture, SOPs, curricula, software, data models, brand assets | The operating system could be withdrawn by a licensor | **`UNRESOLVED — CARRIED FORWARD`** | **[S-A: N13]** | As above | As above | Entity structure | **IP counsel [V]** |
| **N-E-19** | **Domain and digital-asset ownership** | Renewal, transfer, seizure, loss | **`UNRESOLVED — downstream of N-E-18`**; custody **`PROPOSED`** under dual custody | **[S-A: A-14 §13.4]** | Organisational registration / personal registration (prohibited by Rule E-188) | Personal registration is the commonest single point of failure | N13 | Legal **[V]** |
| **N-E-20** | **Digital-asset continuity** — accounts, archives, media library | A departure takes the channel with it | **`PROPOSED`** — dual custody, revocable access, backup admin, two-person recovery | **[S-A: A-14 §13.4]**; **[S: App. A §8.x]** | As proposed / informal | Informal is the current default and is the risk | Rule E-188 | — |
| **N-E-21** | **The category sentence** — is any sentence adopted? | The single most reused artefact | **`NOT ADOPTED — draft only`** | **[S-ST: §20.2]** "`[P — draft for approval, not adopted language]`" | Adopt the draft / commission a new one / use none | Adopting without testing imports an unvalidated sentence | GATE E0 | Comprehension testing (**CI-2**) before adoption |
| **N-E-22** | **Composition monitoring** — aggregate, optional, self-declared, or not at all | Exclusion patterns invisible **or** an identity database created | **`UNRESOLVED — DELIBERATELY, CARRIED FORWARD`** | **[S-A: N5 ⟨new⟩]** | Aggregate optional self-declared / not at all | Both options have a real cost | Privacy officer; Council | **Privacy and equality law [V]** |
| **N-E-23** | **Whether the leaderboard or any comparative artefact is public** | Popularity substitution | **`OPEN — CARRIED FORWARD`** | **[S-ST: R5]**; **[S-C: §44.4]** | Public / internal / none | Public → Goodhart at scale | **[S-C: H-08]**; **[S-D: Part 21]** | — |
| **N-E-24** | **Entity structure and legal form** | Determines what may lawfully be said about status, and 12A/80G/FCRA applicability | **`UNRESOLVED — CARRIED FORWARD`** | **[S: Ch.33]**; **[S-A: §3.1 A.3]** | Section 8 company / trust / society / other | Each has different political-activity, disclosure and liability consequences | Everything legal | **Corporate and tax counsel [V]** |
| **N-E-25** | **CEO vs National Council authority** | Who approves a national claim, a partnership, a brand decision | **`UNRESOLVED — CARRIED FORWARD`** | **[S: Ch.33; Ch.4]**; **[S-D: LDR-U01]** | — | A reserved matter with no determined holder | Rule D-113 interim procedure | **Corporate governance [V]** |
| **N-E-26** | **Data retention** | Publication, archive and erasure all depend on it | **`UNRESOLVED — CARRIED FORWARD`** | **[S: Ch.33; S-A: A-17 P2]** | — | Over-retention and under-retention both carry legal risk | TS-series; Part 53 archive | **Data-protection [V]** |
| **N-E-27** | **Insurance** | A precondition of national trust and of any protection-adjacent public activity | **`UNRESOLVED — CARRIED FORWARD`** | **[S-A: A-10; §14.3 item 5]** | — | Uninsured public activity is an existential exposure | CC-1, CC-7 | **Insurance broker [V]** |

**[A]** Of twenty-seven register items: **six are `PROPOSED` and decidable now; one is `NOT ADOPTED`; one is `OPEN`; one is settled by source; and eighteen depend on or carry forward an `UNRESOLVED` source item.** **v1.3-E resolves none of them.**

---

# PART 63 — NATIONAL IDENTITY AMENDMENT PACK E-01 … E-46

## 63.1 How to read the register

**[P]** Forty-six amendments. **The count is a consequence of the Part count, not a target** — no amendment exists without a distinct problem, a distinct scope and a distinct test. **Each is separately mergeable.**

**Every amendment carries all twenty mandated fields.**

| # | Field | # | Field |
|---|---|---|---|
| 1 | ID | 11 | Governance burden |
| 2 | Title | 12 | Data burden |
| 3 | Problem | 13 | Communication burden |
| 4 | Source | 14 | Dependencies |
| 5 | Proposed change | 15 | Validation required |
| 6 | Scope | 16 | Implementation stage |
| 7 | Benefit | 17 | Reversibility |
| 8 | Risk | 18 | Test |
| 9 | Human burden | 19 | Success evidence |
| 10 | Economic burden | 20 | Status |

**Status vocabulary:** `PROPOSED — REQUIRES APPROVAL` / `PROPOSED — PILOT FIRST` / `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` / `PROPOSED — DEFERRED TO STAGE n` / `PROPOSED — BLOCKED BY UNRESOLVED ITEM`.

## 63.2 Register, part 1 of 2 — E-01 … E-23

| 1 ID | 2 Title | 3 Problem | 4 Source | 5 Proposed change | 6 Scope | 7 Benefit | 8 Risk | 9 Human burden | 10 Economic burden | 11 Governance burden | 12 Data burden | 13 Communication burden | 14 Dependencies | 15 Validation required | 16 Implementation stage | 17 Reversibility | 18 Test | 19 Success evidence | 20 Status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **E-01** | Five-Distinction Rule and the Claim Ceiling | Recognition, membership, trust, legitimacy, brand and impact are used interchangeably, so a claim about one is read as a claim about another | **[S-ST: §11.3, §14.1, §18.3]**; **[S: Ch.24, Ch.25]** | Six concepts separately defined with a producer, a measurement and an operable test; Rule E-1 claim ceiling in the order IMPACT→TRUST→LEGITIMACY→MEMBERSHIP→RECOGNITION→BRAND; Rule E-2 substitution prohibition | Every public artefact at every level | Over-claiming becomes detectable from the artefact alone | A ceiling can be read as timidity and may suppress legitimate confidence | Low — a discipline on wording | Nil | One claim-register review per period | Claim register entries | Every artefact is a communication act | Part 31 claim ladder | Communications and cultural review **[V]** | Stage 0–1 | High | Audit a sample of artefacts against the ceiling | Zero artefacts found above their evidence class | `PROPOSED — REQUIRES APPROVAL` |
| **E-02** | Every-Citizen Relationship Matrix | "Every Indian" is read as "every Indian must join", which produces recruitment pressure | **[S-C: H-02, H-03, §8.2]**; **[S-ST: §8, §9]** | Twenty-five legitimate relationships specified, of which membership is one; Rule E-10 relationship not membership; Rule E-11 L0–L4 are complete positions; Rule E-12 commercial, funding, media and research relationships sit outside the spectrum; Rule E-13 no beneficiary conversion pathway | National, all levels | Relevance without recruitment | Twenty-five relationships may be read as twenty-five programmes | Low | Nil | None new | None new | Every artefact must state which relationship it addresses | **[S-C: H-02]** spectrum | Safeguarding review for minors **[V]** | Stage 0–1 | High | Whether any artefact implies L0–L4 is incomplete | Zero such artefacts; **HM-12** understanding that leaving is allowed | `PROPOSED — REQUIRES APPROVAL` |
| **E-03** | National Participation Without Membership | No pathway exists for the nine things a person should be able to do without joining | **[S-ST: §20.3]**; **[S-C: H-02, H-22]**; **[S: Ch.8, Ch.11]** | NP-1…NP-9 with the minimum required from each side; Rule E-16 advice is not authority; Rule E-17 money buys a receipt; Rule E-18 commerce and service separately named; Rule E-19 observation is ungated | National, all levels | Participation and scrutiny without commitment | Unaffiliated participants may acquire informal authority | Low | Nil — all nine are by-products of existing records | One authority check per advice record | Minimum-data per pathway | PLR-4, PLR-5, PLR-6 | **[S-A: A-18]** necessity test | Privacy review of each pathway **[V]** | Stage 0–1 | High | Whether any pathway requires membership, payment or excess data | **CI-15** unaffiliated repeat use is non-zero | `PROPOSED — REQUIRES APPROVAL` |
| **E-04** | Emotional Conditions Architecture | Emotion is treated as a message to send rather than a condition to create | **[S-ST: §10.2, §10.3]**; **[S-C: §3.4 PM-1…PM-8, H-15]** | Eight stages specified as conditions with observable evidence and a prohibited message each; the eight-position emotional hierarchy with national connection last; Rule E-21 conditions not messages; Rule E-9 ten prohibited emotional registers; Rule E-23 one proposition does not serve every relationship; Rule E-25 emotion is never a budget line | All communication and all ceremony | Emotion arises from work and cannot be counterfeited | A conditions-only rule may produce flat, uninspiring artefacts | Low | Nil | None new | None new | Every artefact tested against the prohibited registers | **[S-C: H-06, H-15]** | Organisational-psychology review of the prohibited registers **[V]** | Stage 0–1 | High | Language audit of artefacts for prohibited registers | Zero prohibited-register artefacts; **HM-9** return rises without any retention mechanic | `PROPOSED — REQUIRES APPROVAL` |
| **E-05** | National Story and Claim Traceability | The organisation can generate more evidence than it can publish, and publishes less than it can prove | **[S-ST: §11.3, §19.2, §29, §30.5]** | Ten story questions answered within the claim ceiling; four defensible claims with evidence preconditions; three prohibited claims; Rule E-26 claim register; Rule E-27 facts not adjectives; Rule E-28 labelled commitments | National | Every public statement becomes checkable | The register adds a step before every publication | Low | Nil | One register entry per claim | Claim-to-record linkage | Every national or multi-locality claim | E-01; Part 31 | None | Stage 1 | High | Sample audit: can each published claim be traced to a record? | **CI-8** claim traceability at 100% for sampled claims | `PROPOSED — REQUIRES APPROVAL` |
| **E-06** | Political Neutrality in Expression | N1…N9 govern acts; public expression has four surfaces acts do not | **[S-A: A-01 N1…N9, A-02, A-03 E1…E14, A-04]**; **[S: Ch.24]** | PN-1 adjacency, PN-2 timing, PN-3 vocabulary, PN-4 silence, each with a control; Rule E-29 no third-party mark without written agreement; Rule E-30 the election calendar governs the communication calendar; Rule E-31 per-jurisdiction terminology review; Rule E-32 a false association must be corrected; Rule E-33 neutrality published not declared; Rule E-34 never answer politically; Rule E-35 repair not messaging | All levels; all artefacts | Neutrality becomes auditable from records alone | Per-state vocabulary review is slow and may delay publication | Medium — a local member must be able to refuse without rudeness | Terminology review per language per state | One refusal-log entry per approach | Approach register; per-state terminology register | Every artefact; every event; every partnership | **[S-A: A-01…A-04]** | **Legal and tax review per jurisdiction [V]** | Stage 0–1 for N1…N9 and the refusal log; Stage 2 for per-state registers | Medium | Whether any artefact contains political content, including favourable | **CI-3** perceived political association at or below baseline; TS-8 refusal count non-zero | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-07** | Religious Neutrality in Expression | Pattern-level religious association arises from calendar, venue, ritual and language even where every act is neutral | **[S-A: A-05 clauses 1–8 and four guards]**; **[S: Ch.2, Ch.20]** | RN-1…RN-7 surfaces with controls; Rule E-36 deliberately multi-festival calendar; Rule E-37 no religious ritual as an organisational requirement; Rule E-38 seva descriptive never prescriptive; Rule E-39 food without distinction; Rule E-40 death and disaster are practical and referral-based; Rule E-41 never enter a theological argument; Rule E-42 no composition figure even to rebut | All levels; all artefacts; all activities | Neutrality of pattern, not only of act | Multi-festival scheduling is complex and may please nobody | Low | Nil | One calendar-pattern review per period | None — **no belief data collected** | Every artefact and every event | **[S-A: A-05]** | Cultural and legal review **[V]** | Stage 0–1 | Medium | Calendar, venue and routing distribution reviewed for pattern | **CI-4** perceived religious association at or below baseline | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-08** | Caste Neutrality and the Composition-Monitoring Refusal | Caste is invisible in a record and determinative of a pattern; the instrument that would prove neutrality is the instrument that could sort people | **[S-A: A-05 clause 4, A-18, N5 ⟨new⟩ UNRESOLVED]**; **[S-D: Rule D-79]** | CN-1…CN-6 behavioural surfaces — routing, venue and timing, naming, food and shared space, recognition, leadership composition; Rule E-43 routing recorded by location and need only; Rule E-44 venue and timing reviewed against attendance; Rule E-45 no surname-derived honorific and no caste-referent role word; Rule E-46 no structured separation in food service; Rule E-47 recognition artefacts reviewed for who appears; **Rule E-48 no caste data for any purpose** | All levels | Neutrality examined behaviourally without building an identity database | A genuinely skewed pattern in a caste-segregated settlement cannot be rebutted demographically | Low | Nil | Pattern reviews per period | **None — no identity field** | Aggregate pattern reporting only | **[S-A: N5]** must remain unresolved; **[S-D: Rule D-79]** | **Privacy and equality-law review [V]** | Stage 2 | Medium | Whether any exclusion pattern is detectable from behavioural aggregates | Routing and recognition distributions reviewed; no identity data held | `PROPOSED — BLOCKED BY UNRESOLVED ITEM` |
| **E-09** | Regional Plurality and the Localisation Contract | Without a positive localisable list, localisation happens silently or not at all | **[S-ST: §12.1, §12.2]**; **[S: Ch.6]**; **[S-C: H-26]** | Eight immutable and ten localisable items adopted; Rule E-50 local by default; Rule E-51 no decision by unit count; Rule E-52 state-level legal review where a distinct regime applies; Rule E-53 no language is senior; Rule E-54 structural variables only, never cultural characterisations | All levels | One core mission, many local expressions | Local-by-default may produce inconsistency in items that should have been immutable | Low | Nil | One change-request review per adaptation | Terminology register per state | Every artefact and every process | **[S-A: A-15 M2/M3]** | State-level legal review **[V]** | Stage 0–1 | High | Whether any national instruction was issued on a localisable item without recorded justification | Zero unjustified national instructions; **CI-7** terminology consistency | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-10** | Layered Identity | "Local community" and "something larger" must both be felt without uniformity or coercion | **[S-C: H-26]**; **[S-ST: §11, §12.3]** | H-26's five rules and six-layer sentence test carried unchanged; Rule E-3 national is derived never primary; Rule E-55 capability not direction; Rule E-56 the annual assembly is a governance body; Rule E-57 epistemic before affective | National and local | Identity is produced by observable events, not claims | "Capability deployed locally" can become central control in a helpful costume | Low | Nil | One intervention-justification record per national act | Locality attribution on every outcome | Every national artefact | **[S-C: H-26]**; **[S: App. A §16.2]** | None | Stage 1 | Medium | For every national intervention, can the locality point to its request or to an immutable standard? | 100% of interventions traceable to a request or a standard | `PROPOSED — REQUIRES APPROVAL` |
| **E-11** | Three-Tier Brand Architecture and Parent Subordination | Krytos, the operating name, the locality and the venture appear together with no rule about which is salient | **[S: Ch.4 chain; Ch.4 authority table; Ch.33 public name PROPOSED; Ch.5 §4.4]** | T1 master / T2 parent / T3 local / T4 venture; Rule E-58 parent subordinated in service contexts and named accurately in legal and financial contexts; Rule E-59 no concealment on request; BR-1…BR-12 usage rules; Rule E-60 no national brand before N12 and N13 | All public and all legal artefacts | The right name in front of the right audience | Subordination can be misread as concealment | Low | Nil | Brand-usage audit per period | None new | Every artefact | **N12, N13 UNRESOLVED**; Rule E-60 | **IP counsel [V] — [S-A: V8]** | Stage 1 local; **national blocked** | Medium | Whether any service artefact carries the parent name, or any legal artefact omits the entity | Zero misplacements in audit | `PROPOSED — BLOCKED BY UNRESOLVED ITEM` |
| **E-12** | Visual Identity and the Red-Colour Resolution | Red is already the organisation's colour for safety, risk and prohibition; a red brand would collide with its own semantics and with several political colour fields | **[S: Ch.1 information colour system]**; **[S-A: A-01 N2, N4; A-06 V1…V8]**; **[S: Ch.31, Ch.33 ID card]** | Rule E-61 the nine information colours are reserved and may not be identity colours; Rule E-62 no colour-only meaning; Rule E-63 six-question symbol test; Rule E-64 no symbol grants authority by appearance; Rule E-65 four permitted surfaces; ID card specification constraints; logo, typography and signage constraints; the dated result board as the primary visual artefact | All visual artefacts, all levels | Removes the red question, the green question and the uniform question simultaneously | Excluding nine colours constrains the palette | Low | Nil | One visual audit per period | None | Every artefact and every physical surface | N12; **[S-A: A-06]** | **Per-state political-association review [V]; accessibility and contrast testing [V]** | Stage 0–1 for the prohibitions; **the palette itself is blocked by N12** | High for the prohibitions | Adjacency test: the mark beside a police badge, a party flag, a religious symbol and a corporate logo | No adjacency reading; one-colour and hand-painted reproduction legible | `PROPOSED — BLOCKED BY UNRESOLVED ITEM` |
| **E-13** | Five Language Registers | v1.3-A named language architecture as outside its scope; v1.3-C built three layers for the human system; neither fixed the registers or the mandatory set | **[S-A: A-05 clause 8, A-06 V11, A-17 P3]**; **[S-C: §30, H-25]**; **[S: Ch.24]** | LA-1 governance and legal / LA-2 operational / LA-3 public / LA-4 local participation / LA-5 emergency; Rule E-66 the four-item mandatory translation set; Rule E-67 simultaneous or not published; the terminology register with per-state scope and recorded refusals; Rule E-68 machine translation never publishes; Rule E-69 four error classes; Rule E-70 language is not a scaling feature | All texts, all levels | Linguistic exclusion becomes a design defect rather than an accident | Simultaneous multilingual publication slows national communication | Medium — native-speaker reviewers separate from authors | Translation, once per L1 text; pre-positioned LA-5 | Terminology register governance | Per-language register | Every publication | **[S-C: §30.2]**; **[S-A: H10]** | **Legal review of every LA-1 text per language [V]** | Stage 0–1 for LA-1, LA-3-mandatory and LA-5 in the pilot language | Medium | Whether any process can be completed by a person who does not read the artefact's language | **CI-6** language match at 100% for the mandatory set; **AX-T1** passes | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-14** | Accessibility Standard | Accessibility is claimed more often than implemented, and a false claim is believed by exactly the people it excludes | **[S-C: H-23, H-24]**; **[S-B: §40]** no-technology pilot; **[S-D: OB-1…OB-7, AX-1…AX-9]** | Five dimensions AX-V, AX-H, AX-C, AX-L, AX-D; Rule E-71 implemented or not claimed; Rule E-72 every process has a human route requiring no reading, writing, device, account or fee; four prohibitions; AX-T1…AX-T3 tests | All artefacts and all processes | Accessibility becomes an implementation state, not a statement | The human route costs a person's time, which is `H_gov` | Medium — a human must be available | Human-route time inside `σ_max` | None new | **No disability or health field required for any public process** | Every artefact and process | **[S-B: §40]**; Rule E-72 | **Accessibility standards review [V]** | Stage 0–1 | High | **AX-T1** read-aloud test; **AX-T2** one-colour reproduction | A person who cannot read completes the process; all meaning survives one-colour reproduction | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-15** | First Contact Standard | The ten-second test fails four of five, and the five questions left silent are answered by the observer with the worst available category | **[S-ST: §18.2, §18.3, §20.1, §20.2]**; **[S-C: H-04]** | The eight-question national test; Rule E-73 questions 4–8 answered at first contact; Rule E-74 sequencing is not concealment with four auditable conditions; Rule E-75 need-seekers see boundaries at the point of need; MC-1…MC-11 with detectors and first responses; Rule E-76 misclassification is a safety issue; Rule E-77 segment explanations vary salience only | All first-contact artefacts | The four Severe misclassifications are answered before they form | A short description can under-inform; Rule E-74 constrains this | Low | Nil | One register entry per segment explanation | None | Every first-contact artefact | E-01; terminology register | Cultural review of the category sentence **[V]** | Stage 0–1 | High | **CI-1** misclassification rate; **CI-2** eight-question comprehension | Misclassification below baseline; comprehension above a stated floor | `PROPOSED — PILOT FIRST` |
| **E-16** | First Five Minutes and the Public Local Record | The architecture's first available action is membership application, which is integrity-first and conversion-fatal; and no public local page exists | **[S-ST: §20.3]**; **[S-C: H-05]**; **[S: Ch.12]** | PLR-1…PL-7 public local record, seven elements and nothing else; Rule E-78 ungated and unadorned; Rule E-79 the paper sheet is a complete implementation; Rule E-80 minimum safe pathway for a help seeker; Rule E-81 the boundary is stated before the disclosure; the national/local split for first contact | Every operating locality | Value before vetting; a person before a process | A public page creates an inbound load the team must answer | Medium — someone must answer | PLR maintenance inside `H_gov` | None new | Minimum data at intake | PLR-1…PL-7 | E-03; E-13; E-14 | Privacy review of PLR content **[V]** | Stage 0–1 | High | PLR exists, is current, and is ungated; **HM-4** first-participation completion | A stranger completes the first five minutes with no form, no account and no membership language | `PROPOSED — PILOT FIRST` |
| **E-17** | First Real Win, national version | A first win that ends with an invitation is a funnel stage, not a win | **[S-ST: §21.1, §21.3]**; **[S-C: H-06]** | FW-1…FW-6 conditions; FWF-1…FWF-4 failure modes; Rule E-82; Rule E-83 three first wins — contribution, help and verification; the twelve-persona value-proposition table; Rule E-84 media and research are not participants | Every locality | The first experience is worth repeating, which is the only growth mechanism that is not capacity-limited | Real work must exist to give; a symbolic task is worse than none | Medium — pairing requires two existing members | Paired-task time | None new | Task and outcome records only | FW-1…FW-6 | **[S-C: H-06]**; E-03 | None | Stage 0–1 | High | **HM-5, HM-6, HM-7, HM-9** | **HM-9** second contribution within the window, with no retention mechanic in use | `PROPOSED — PILOT FIRST` |
| **E-18** | National Participation Funnel | A funnel is designed to maximise progression; this one must maximise value at the stage reached | **[S-C: H-02, H-07, §8.4]**; **[S-ST: §9, §21.3]** | S1…S10 with owner, precondition and prohibition per stage; S10 is system improvement, not bringing people; Rule E-85 every stage is an exit and a destination; Rule E-86 no conversion target ever; the fourteen acquisition channels assessed | National | The number who helped once and never returned is published as a success | Refusing conversion targets removes the most familiar management instrument | Low | Nil | None new | Stage-reached recorded as a diagnostic (**HM-15**) | None | **[S-C: H-07, §8.4]**; **[S-D: Rule D-37]** | None | Stage 0–1 | High | Whether any target, incentive or dashboard expresses a conversion rate | Zero conversion targets anywhere; **HM-9** is the primary reported measure | `PROPOSED — REQUIRES APPROVAL` |
| **E-19** | Trust Production System | The architecture is strong on being trustworthy and silent on being seen to be trustworthy | **[S-ST: §14.1, §14.2, §14.3]** | Four layers operationalised with an owner, an artefact and a test each; TS-1…TS-14 public trust signals, each a publication of an existing record; Rule E-88 the correction log must not be empty and an empty log is published as an anomaly and referred to Audit; Rule E-89 pre-conditions 1–7 are gates; Rule E-90 the organisation never claims to be trusted | National and local | Invisible honesty becomes visible without becoming promotional | Publishing accounts, incidents and closures exposes the organisation to scrutiny it may fail | Medium — publication is work | Translation and publication cost | Quarterly and annual publication cycle | Aggregates with small-cell suppression | **Every TS item is a communication act** | E-20; E-21; **[S-A: A-17]** | **Data-protection and accounting review [V]** | Stage 1 for TS-1, TS-2, TS-6, TS-11; Stage 2 for the full set | Medium | Whether every TS item exists, is dated and is current | **CI-9** correction count non-zero; TS-1…TS-14 complete at the required stage | `PROPOSED — PILOT FIRST` |
| **E-20** | Reputation Architecture | The counterfeit model — advertising to attention to followers to false reputation — has no arrow returning from failure to reality | **[S-ST: §14, §30.5]**; **[S: Ch.15, Ch.24]** | Reality→Evidence→Transparency→Correction→Trust→Reputation→Repeat participation, against the counterfeit; Rule E-91 reputation is downstream and never a target; RC-1…RC-4 alignment states; Rule E-92 publish the limit; Rule E-93 the surge protocol; Rule E-94 the disappearance test; Rule E-95 followers are not being missed; Rule E-96 complement never rival; Rule E-97 repair reality before repairing reputation; Rule E-98 the rebranding test | National | Reputation becomes an output rather than an objective | Refusing reputation as a target removes a familiar motivation | Low | Nil | One claim-register audit per period | None | All of it | E-01; E-19 | None | Stage 1 | High | **Rule E-182** claim-ladder audit; the disappearance test per locality | Zero claims found above their evidence class; at least one locality answers the disappearance test from records | `PROPOSED — REQUIRES APPROVAL` |
| **E-21** | Four-Audience Transparency Regime | "Transparency" is treated as one thing; it is five audiences with different entitlements | **[S-A: A-17 C1–C4, A-19, A-20]**; **[S: Ch.23, Ch.24]** | Five audiences specified; Rule E-99 three tests — necessity, identifiability, harm; Rule E-100 small-cell suppression with suppression reported; the public reporting calendar mapped to **[S: Ch.24]** cadences; Rule E-101 no reporting theatre; the never-publish list | National and local | Publication is precise rather than maximal or minimal | Suppression weakens the trust signal in small populations | Low | Translation and audit | One consumer-and-purpose declaration per published item | Classification per field | Every publication | **[S-A: A-17…A-20]** | **Data-protection review [V]** | Stage 1 | Medium | Whether any published item identifies a person or a small cell | Zero identifiability findings; every item has a named consumer | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-22** | Crisis Communication Protocol | Crisis is when procedure is most needed and most likely to be abandoned, and the first failure is usually a statement made too early | **[S: Ch.24 communication-type table; Ch.5 National Communications]**; **[S-A: A-09, A-17 P5]**; **[S-D: Part 37]** | CC-1…CC-8 classes with who speaks, what is released, what is withheld, timing, correction and follow-up; the seven-step public error response; Rule E-102 four prohibited reflexes plus the fake apology; Rule E-103 an apology must contain a fact, a correction and a change; Rule E-104 no invented spokesperson titles; Rule E-105 domain and region not hierarchy | National and local | A crisis produces a record-based response rather than a narrative one | Speaking slowly while a video circulates is reputationally costly | Medium — approvals under time pressure | Pre-positioned crisis capacity (**§42.5**) | Approval matrix by risk and brand impact | Sealed categories protected | **All of it is communication** | **[S: Ch.24]**; E-19 | **Legal review per class [V]**; DPDP notification obligations **[X][V]** | Stage 0–1 for CC-1, CC-3, CC-8; Stage 2 for the full set | Medium | A rehearsal: is the statement factual, timely, approved and record-citing? | **CI-9** correction latency; zero prohibited reflexes in any artefact | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-23** | Social Media Doctrine and the Vanity-Metric Prohibition | Followers, likes, views and shares are the most purchasable and least informative numbers available, and they rise when the organisation says what people want to hear | **[S: Ch.24; Ch.25]**; **[S: App. A §8.x Social Media Manager]**; **[S-ST: R5]** | Six permitted purposes and six prohibited outcomes; Rule E-106 vanity metrics may never determine, evidence, target or be published as achievement; Rule E-107 post only what is already published; the may/may-never posting table; Rule E-108 five categories with five responses; Rule E-109 legitimate criticism is preserved and deletion is logged; Rule E-110 creators report never represent; Rule E-111 no paid or solicited endorsement; Rule E-135 no referral mechanism | National and local | Social media becomes a distribution channel for the public record | Refusing engagement reduces apparent reach | Low | Nil | One deletion-log review per period | No audience profiling; no identity inference | **All of it** | **[S: Ch.24]**; E-19 | Platform-terms and data-protection review **[V]** | Stage 0–1 | High | Whether any artefact uses a vanity metric as evidence or target; whether any criticism was deleted | Zero vanity-metric uses; deletion log contains only the four permitted grounds | `PROPOSED — REQUIRES APPROVAL` |

## 63.3 Register, part 2 of 2 — E-24 … E-46

| 1 ID | 2 Title | 3 Problem | 4 Source | 5 Proposed change | 6 Scope | 7 Benefit | 8 Risk | 9 Human burden | 10 Economic burden | 11 Governance burden | 12 Data burden | 13 Communication burden | 14 Dependencies | 15 Validation required | 16 Implementation stage | 17 Reversibility | 18 Test | 19 Success evidence | 20 Status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **E-24** | Partnership Architecture | A partner's mark, reputation or politics can transfer by adjacency, and "no team should imply that a partner endorses the entire organisation" is currently unenforced | **[S: Ch.5 §4.4; Ch.29; Ch.33 signatory authority Not final]**; **[S-A: A-01 N6, A-05 clause 5]** | PT-A…PT-F six stages with a record each; Rule E-112 partnership is not endorsement in either direction; Rule E-113 due diligence is not surveillance; eleven partner classes with specific risks; Rule E-114 information only never brokerage; Rule E-115 every partnership is terminable and tested for independence | All levels | Adjacency risk is documented before it materialises | Due diligence may be experienced as suspicion by a partner | Medium | Legal review per agreement | One approval per agreement by amount, risk, data and brand impact | Data-sharing terms | Co-branded artefacts | **[S: Ch.29]**; BR-3 | **Legal review [V]** | Stage 1 | High | Whether any artefact implies general endorsement without a written term saying so | Zero implied endorsements; every partnership has a termination right | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-25** | Government Interface Communication Boundaries | Cooperation with authorities can shade into becoming an instrument, an agent or a parallel government | **[S-A: A-08 DO-NOT list]**; **[S: Ch.16]**; **[S-ST: §18.2 MC-10]**; **[X]** BNSS 2023 ss.31, 40, 43 | The may/may-never table; Rule E-116 the boundary statement is published; Rule E-30 the election calendar governs; the election-period communication rules; Rule E-117 one voice, in writing, to the right desk, recorded | All levels | MC-10 and MC-3 are answered before they arise | Publishing one's own limits may be read as weakness | Low | Nil | One record per authority interaction | None | The boundary statement in every operating language | **[S-A: A-03, A-08]** | **Criminal and administrative law review per jurisdiction [V]** | Stage 0–1 | High | Whether any artefact claims or implies state authority | Zero implied-authority artefacts; the boundary statement published in every operating language | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-26** | Business Interface and the public Service/Sales Firewall | The business pillar collapses the mission in public perception and invites "they use charity to get clients" | **[S-ST: §17.1, §17.2, §17.3, §18.2 MC-5]**; **[S: Ch.17, Ch.18]**; **[S-B: B-09]** | Five business relationships with what each confers and may never confer; Rule E-118 ability to pay never determines access; four public firewall rules; Rule E-120 no earnings claim without a local funded reality, with the weak month disclosed at equal prominence | All levels | Door 3 stays honest and the service identity stays clean | Refusing earnings imagery forgoes the strongest recruitment message available | Low | Nil | One mission-balance publication per cadence | None | Every commercial artefact | **[S-B: B-07, B-09]**; Rule E-15 | Tax and consumer-law review **[V]** | Stage 1 | High | Whether any service artefact carries a commercial offer, or any commercial artefact carries the service mark | Zero cross-appearances; the mission-balance statement published | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-27** | Education Interface | Educational institutions are the most available and most dangerous recruitment channel | **[S-C: SA-1…SA-7, H-27]**; **[S: Ch.12]**; **[S-D: Rules D-84…D-88]** | Rule E-121 institutions are not pipelines; Rule E-122 young participants are protected before they are useful, with six absolute prohibitions including no image of any minor ever; the permitted and prohibited activity table; the honest limit — education produces a flow, not a stock | All levels | Youth participation without youth exploitation | Refusing campus chapters forgoes the fastest available growth route | Medium — safeguarding supervision | Safeguarding training and supervision | One guardian-consent record per minor activity | **No minor's data published in any form** | None | **[S-C: SA-1…SA-7]** | **Safeguarding and education-law review [V]** | Stage 0–1 for the prohibitions | Low — the prohibitions should not be reversible | Whether any artefact contains a minor's image, name or identifying detail | Zero, absolutely | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-28** | Media Interface, local and national | Local media reach the people whose opinion determines local legitimacy and are least able to verify a claim; national attention at CL-0 is the most dangerous success available | **[S: Ch.24]**; **[S-ST: §18.3, §20.2]** | What may be provided per subject with its evidence standard; Rule E-123 no paid praise, disclosed paid information; the local protocol with a non-local contact; Rule E-124 national claims require national evidence; Rule E-125 "national" describes capability not reach; Rule E-126 no exclusivity, no pre-publication review, no copy approval; Rule E-127 the early-attention protocol | All levels | Media access is granted on records, not on relationships | Refusing exclusivity and copy review forgoes favourable treatment | Low | Nil | One response-window record per query | Consent for any named contributor | Every media interaction | E-05; E-19 | **Paid-news and media regulation review [V]** | Stage 1 | High | Whether any access was conditional, any exclusivity granted, or any copy approved | Zero conditional access; every claim sent with its record | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-29** | Claim Ladder and Under-Claiming | No mechanism ties a public claim to a demonstrated stage, so recognition can outrun capability by several classes at once | **[S-ST: §18.3 item 4, §30.3, §55]**; brief §54 | CL-0…CL-8 with evidence required, what may be claimed and what may not; Rule E-128 the ladder is itself published; Rule E-4 reputation lags capacity; Rule E-127 early attention; Rule E-182 claim-ladder audit each period with withdrawal published | National | Under-claiming becomes a policy with an audit rather than a disposition | Under-claiming may forgo attention that would have been harmless | Low | Nil | One register audit per period | Claim-to-record linkage | Every public claim | E-01; E-05 | None | Stage 0–1 | High | **CI-8** traceability; the Rule E-182 audit | Zero claims above class; withdrawals published when found | `PROPOSED — REQUIRES APPROVAL` |
| **E-30** | Reputation and Growth Flywheels, and the expansion gates | The prohibited order — brand to publicity to membership — produces demand rather than capacity | **[S-ST: §22, §23, §30.3]**; **[S-D: Rule D-43, D-44]**; **[S-B: §24.5, §26]** | Both flywheels drawn with the prohibited reversal; Rule E-134 no stage skipped forward, a skip is a recorded risk; the growth flywheel with validation required at each transition; GATE E0…E7 plus GATE E-X; Rule E-213 what never justifies expansion; Rule E-214 the three gate sets are conjunctive; Rules E-135, E-162, E-175 | National | Growth is evidence-gated rather than attention-gated | Gates slow growth, including growth that would have been safe | Low | Nil | One gate record per expansion authorisation | None | Expansion communication | **[S-D: XG-1…XG-8]**; **[S-B]**; E-36 | None | Stage 1 | Medium | Whether any expansion was authorised without all three gate sets passing | Zero; every authorisation names its constraining capacity | `PROPOSED — REQUIRES APPROVAL` |
| **E-31** | Replication Classification | What must be copied exactly and what may adapt is not separated for the communication layer | **[S-ST: §12.1]**; **[S-D: INV-1…INV-20, ADAPT-1…ADAPT-12]** | R-1…R-10 must-replicate and R-11…R-20 may-adapt; Rule E-136 adaptation runs through the register not through discretion; Rule E-137 replication does not transfer trust; RT-1…RT-5 replication tests | National | Drift is detectable and local expression is protected | Registering every adaptation adds a step | Low | Nil | One register entry per adaptation | Versioned standards | Every adapted artefact | **[S-A: A-15 M2/M3]** | None | Stage 2 | High | **CI-7** terminology consistency; whether any R-1…R-10 item was adapted | Zero adaptations of immutable items | `PROPOSED — REQUIRES APPROVAL` |
| **E-32** | Structural Variance Register | A single national communication template is wrong in eleven different ways | **[S-ST: §12.2, §2.2]**; brief §60 | Ten structural variables applied to eleven environment types; three findings — independence cost is the binding variable; every environment has a distinct first publication requirement; the City divisor is environment-dependent; Rule E-138 the divisor must be measured per environment type; Rule E-139 no environment is exempt from R-1…R-10 | National | Localisation is planned against structure, not against stereotypes | Eleven environment types is a planning burden | Low | Nil | One divisor measurement per environment type | None | Local artefacts | **[S-B: §26]**; **[S-D: Rule D-91]** | Area-specific legal review **[V]** | Stage 3 | Medium | Whether any national template was applied without local adaptation | Zero; divisor measured per environment before any state structure | `PROPOSED — REQUIRES APPROVAL` |
| **E-33** | National Culture and Shared Practices | Culture is transmitted by what is rewarded, tolerated and selected, not by what is written; and shared practice can become conformity | **[S-ST: §15.1–15.4]**; **[S-A: A-16 §15.4]** | Rule E-140 culture is transmitted by consequence; nine principles converted to observable behaviours with a record and a tripwire; the shared-practice burden test — three practices rejected, two merged, four adopted; Rule E-141 the conformity tripwire is the dissent count; Rule E-142 one event not two; Rule E-143 shared practice not shared experience; Rule E-144 no national date; the never-do-culturally list | National | Consistency without conformity | Rejecting a national service day forgoes a visibility opportunity | Low | Nil | One dissent-count publication per year | None | Ceremonies and recognition | **[S-A: A-16 test 3]**; **[S-D: Rule D-40]** | Cultural review **[V]** | Stage 1 | High | The published dissent count; whether any practice produces no record | **Non-zero dissent count**; every adopted practice produces a record | `PROPOSED — REQUIRES APPROVAL` |
| **E-34** | Story Architecture and Beneficiary Dignity | Saviour grammar enters through syntax, and beneficiary imagery is the fastest route to the MC-9 misclassification and to real dignity harm | **[S-C: §17.4, H-14, H-22]**; **[S: App. F]**; **[S-A: A-19, A-20]**; **[S-ST: §10.2, §18.2]** | ST-1…ST-8 story elements including cost and next; Rule E-145 the attribution grammar; Rule E-146 no flattening or composites; Rule E-147 the person who did it tells it; the never-be list; Rule E-148 the person served is not organisational material; the dignity rules for consent, anonymity, images, children, vulnerable people, emergencies, before/after, testimony, data, gratitude and exit; §38.3 no beneficiary-to-participant pathway exists | All levels | Stories become evidence rather than appeals | Refusing imagery removes the most emotionally effective material available | Low | Nil | Editor rejection log | Consent records; C4 sealed | Every story artefact | **[S-A: A-19, A-20]**; **[S-C: H-14, H-22]** | **Safeguarding, privacy and media-law review [V]** | Stage 0–1 | Low | **CI-14** attribution and consent compliance; Editor rejection log | Zero beneficiary images; zero "we gave them" constructions; consent complete for every published personal element | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-35** | Anti-Cult, Anti-MLM and Anti-Coercion in Communication | Compensation firewalls do not reach vocabulary, imagery, urgency or referral mechanics | **[S-A: A-16 §15.4]**; **[S-C: H-19, H-21, MLM-1…MLM-7, H-17, H-18]**; **[S-D: CU-1…CU-10, Rule D-118]**; **[S-ST: §11.2, §16.1]** | AC-1…AC-9 cult vectors with controls; Rule E-149 no individual images; Rule E-150 authority cited to a document version; Rule E-151 a founder preference is a declared interest; Rule E-152 credit for work never quality; Rule E-153 no eponymous artefact; Rule E-154 no unrecorded decision channel; Rule E-155 no personal account as an organisational channel; Rule E-156 no personal fundraising; Rule E-157 no person is the only source of a fact; Rule E-158 the substitution test; ML-1…ML-8 vectors; Rule E-159 the prohibited-vocabulary list; Rule E-161 permitted and prohibited senses registered; Rule E-162 the growth-source test; CO-1…CO-9 with detectors; Rule E-163 leaving is complete and immediate; Rules E-164, E-165 | All levels | The three capture vectors are closed at the level of language and imagery | A long prohibited-vocabulary list can feel restrictive and be resented | Low | Nil | One formula and vocabulary audit per period | None | Every artefact | **[S-C: H-21]**; **[S-D: CU-series]** | Cultural and employment review **[V]** | Stage 0–1 | Medium | **Rule E-162** growth-source test on every artefact; formula audit for participation terms | Zero artefacts whose success depends on the reader bringing someone; zero participation-linked terms | `PROPOSED — REQUIRES APPROVAL` |
| **E-36** | National Capacity and the Bottleneck Principle | Growth is authorised on demand rather than on capacity, and communication capacity is not costed anywhere in the prior instruments | **[S-B: §17.2, §24.5, §25, §26]**; **[S-D: Rule D-43, Part 42]**; **[S-ST: §23.1]** | CAP-1…CAP-8 with the binding stage named; the minimum-not-sum capacity formula; Rule E-166 the weakest critical capacity constrains and is named in the authorisation; Rule E-167 capacity may not be substituted by enthusiasm; eight collapse modes ranked by severity and reversibility; the growth-cost drivers; **Rule E-168 communication is a costed governance function — recorded as a gap in v1.3-B**; Rule E-169 the communication burden test; Rule E-170 a surge is managed by publishing the limit | National | Expansion is authorised against a named constraint | Naming a constraint makes refusal explicit and may be resisted | Low | **Communication capacity is currently unfunded** | One named constraint per authorisation | None | Expansion communication | **[S-B: §25, §26]**; **[S-D: Rule D-91]** | None | Stage 1 | Medium | Whether any authorisation proceeded without naming its constraining capacity | Every authorisation names a constraint; communication hours appear in `H_gov` | `PROPOSED — REQUIRES APPROVAL` |
| **E-37** | Four Growth-Shock Protocols | Viral, slow, zero and negative growth each break something different, and only the viral case is usually planned for | **[S-ST: §22, §23]**; **[S-B: §24.5]**; brief §77–§80 | Viral: what breaks first at 10k / 100k / 1M, what is paused, Rule E-171 a surge suspends celebration; slow: Rule E-172 slow growth is the design case, Rule E-173 publish the small numbers; zero: Rule E-174 communication shifts to learning, Rule E-175 no growth campaign ever; negative: consolidation, merger, graceful closure, member transfer, asset transfer, service continuity, Rule E-176 a closure is published on the same terms as an opening, and the seven-step decline sequence | National | All four growth states have a protocol, not only the exciting one | Publishing declines and closures forgoes the promotional value of good news | Medium | Nil | One publication per event | Open-commitment register | All of it | E-19; E-36; **[S-D: Rule D-26]** | None | Stage 1 | High | Whether any decline, closure or pause went unpublished | Every closure published on opening terms; open commitments accounted for | `PROPOSED — REQUIRES APPROVAL` |
| **E-38** | Reputation Shock and Attack Response | Every attack is disproved by a record that must already be published; none is disproved by a statement | **[S: Ch.24 misinformation rule]**; **[S-A: A-01…A-06, A-17 P5]**; **[S-ST: §18.3]** | Rule E-177 process before narrative; the eight-element misconduct-accusation protocol; Rule E-178 the default classification of any negative statement is criticism; Rule E-179 classification is recorded and auditable; the eight attack scenarios with the evidence that disproves each; **Rule E-180 defence is pre-publication** | National and local | Crisis capability is built in advance, at the cost of translation and a page | Pre-publication exposes the organisation to scrutiny it may fail | Medium | Pre-funded crisis capacity | One classification record per matter | Sealed categories protected | All of it | E-19; E-22 | **Legal review per attack class [V]** | Stage 1 | Medium | Whether every attack scenario has a pre-published answering record | TS-1…TS-14 complete before the first attack; zero premature conclusions published | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-39** | National Communication Governance | Publishing authority is distributed across roles with no rule about which artefact needs which approval, and a correction that needs approval arrives after the damage | **[S: Ch.5; Ch.24; App. A §8.x; App. E]**; **[S-D: Rule D-40]** | The artefact-class publication matrix with approver, evidence and correction duty; **Rule E-186 a correction requires no approval**; Rule E-187 editorial independence from the subject; the brand-governance asset table carrying N12, N13, N19 forward unresolved; Rule E-188 no personal account is an official channel; four public-accountability mechanisms each passing the body-justification test; Rule E-189 no promise of independent review without a mechanism; E-190…E-195 whistleblowing | National and local | Publication is governed without creating a committee | Rule E-186 permits an unreviewed correction, which could itself be wrong | Medium | Nil | One publication-matrix review per period | Archive is append-only | All of it | **[S-A: A-14 §13.4; A-15 M4]**; N12, N13 | Legal and IP review **[V]** | Stage 0–1 | Medium | Whether any artefact was published outside its class authority; whether any correction was delayed for approval | Zero unauthorised publications; zero delayed corrections | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-40** | Digital Architecture and Platform Dependency | The public record currently depends on platforms the organisation does not control, and communication assets are the ones most often omitted from continuity arrangements | **[S-A: A-14 §13.4]**; **[S: Ch.22, Ch.23]**; **[S-B: §40]** no-technology pilot; **[S-C: H-24]** | Rule E-196 digital serves physical and never replaces it; the two searches designed separately; Rule E-197 local discovery without the hierarchy; seven platform dependencies with controls; **Rule E-198 the public record is platform-independent**; digital-identity and continuity requirements | National and local | A platform loss is an inconvenience rather than an identity event | Maintaining three forms of the record — platform, own domain, paper — costs more | Low | Hosting and domain; paper production | Custody and renewal records | None | The public record | **[S-A: A-14 §13.4]**; N13 | Security and data-protection review **[V]** | Stage 1 for paper and own-domain; Stage 3 for platform work | High | Remove one platform: is the public record still producible? | Yes, within one working day, without any third party | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-41** | Contribution Portability | The most valuable and least developed asset in the architecture; and portability is one design decision away from a social-credit score | **[S-ST: §12.3 item 1, §19.2 claim 3]**; **[S-C: H-09, H-10, CR-1…CR-4]**; **[S: Ch.22]** | PO-1…PO-5 requirements; Rule E-199 six properties separating a record from a social-credit system, all of which must hold; Rule E-200 no ordinal element in any field; Rule E-201 the value proposition to a third party is checkability not prestige | National | A contribution in one city is legible in another | Third-party acceptance is outside the organisation's control | Low | Schema and verification route | One verification response per query | **Person-controlled disclosure only** | The verification channel | **[S-C: H-09, H-10]**; **[S-A: A-17…A-20]** | **Privacy and data-protection review [V]** | Stage 3 — requires ≥ 2 localities | Medium | Whether any field is ordinal, and whether any disclosure occurred without the person's action | Zero ordinal fields; zero non-consented disclosures | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **E-42** | National Recognition and the Hero-Language Rule | The organisation contains a protection pillar, so combat vocabulary is available and would be read as a mandate | **[S-C: H-08, §44.3, SR-2]**; **[S-D: Rule D-66, D-67]**; **[S-A: A-06]**; **[S-ST: §18.2 MC-3]** | What recognition rewards and never rewards; the four-term hero-language test — hero, warrior, guardian refused; sewak and contributor permitted descriptively; Rule E-202 absolute instruments only at every level; Rule E-203 service identity over combat identity; Rule E-204 no national hero and no national recognition of a person | National and local | MC-3 is answered at the level of vocabulary | Refusing heroic language forgoes the most shareable register | Low | Nil | One vocabulary audit per period | None | Every artefact and every award | **[S-C: H-08]**; E-35 vocabulary register | Cultural review **[V]** | Stage 0–1 | High | Whether any artefact uses combat, heroic or guardian vocabulary | Zero; **CI-5** perceived security association at or below baseline | `PROPOSED — REQUIRES APPROVAL` |
| **E-43** | Specialist and Knowledge Networks in public | The specialist network is the one national capability a locality can see arrive, and the knowledge network is the principal national network effect — but either can become a visible elite | **[S-C: §47, H-11]**; **[S-D: Part 13 SP-1…SP-6]**; **[S-B: §26.4, B-21]**; **[S-A: A-15 M2, M3, M5]** | E-205 advises never commands; E-206 engagement on request or under an immutable standard; E-207 engagements published in aggregate; E-208 no publicly displayed tier or title; E-209 entry open by evidence; **E-210 the elite-disconnection test — recent local delivery required for standard-setting**; the knowledge chain local solution → documented knowledge → standard change → training → reusable capability → published pattern; Rule E-211 conditions travel with the solution; Rule E-212 a failure is published with its learning, not instead of it | National | National capability is visible without national hierarchy | Requiring recent local delivery may exclude genuinely expert people | Low | Specialist deployment cost | One aggregate publication per period | Aggregate only | Specialist and knowledge publication | **[S-D: SP-series]**; **[S-A: A-15]** | None | Stage 3 | Medium | Whether any specialist holds a standard-setting role without recent local delivery | Zero; **E-211** conditions present in every published solution | `PROPOSED — REQUIRES APPROVAL` |
| **E-44** | Identity and Adoption Maturity | A maturity claim based on documentation rather than operation is unfalsifiable, and an aggregate adoption level becomes the thing the organisation optimises | **[S-ST: §23.1]**; **[S-D: MAT-0…MAT-5]**; brief §171–§172 | NI-0…NI-6 with evidence required and claim-ladder correspondence; Rule E-215 a level is determined by the weakest locality claimed; MA-0…MA-6 determined by measurement not by count; Rule E-216 adoption maturity is measured per locality, never in aggregate; the NI/MA diagnostic matrix — the healthy trajectory is MA ahead of NI | National | Branding is detected as an NI-ahead-of-MA condition | Per-locality measurement prevents a single national figure, which management will want | Low | Nil | One maturity assessment per locality per stage | None | Maturity reporting | E-29; E-30 | None | Stage 1 | High | Whether NI exceeds MA anywhere | **MA ahead of NI in every locality** | `PROPOSED — REQUIRES APPROVAL` |
| **E-45** | One Integrated Evidence System | Six evidence families reported separately are each optimisable in isolation and each conceals the others | **[S-A]**; **[S-B: §40]**; **[S-C: §58]**; **[S-D: Part 44]**; brief §167 | The integrated architecture diagram; **Rule E-217 one record per locality per period across all six families**; EXPAND / IMPROVE / PAUSE with triggers and consequences; Rule E-218 a pause is published on the same terms as an expansion; **Rule E-219 the default outcome is IMPROVE**; Rule E-220 no class promotion without a label change | National | Substitution between families becomes visible | An integrated record is harder to produce than six separate ones | Low | Nil | One integrated record per locality per period | As per family | The record itself | All five prior instruments | None | Stage 2 | Medium | Whether any EXPAND was decided on partial evidence | Zero; **every decision names its outcome class and its evidence** | `PROPOSED — REQUIRES APPROVAL` |
| **E-46** | Claim Discipline and Evidence Labels | Six claim classes and five evidence labels exist separately; uncombined, they cannot be audited from an artefact | **[S-ST: §11.3]**; brief §197–§198 | PROVEN / OBSERVED / REPORTED / PROPOSED / UNDER TEST / UNKNOWN with publication permission and required marker; Rule E-129 "we do not know yet" is a protected public statement; the five plain-language evidence labels with "pending" carrying a due date; the combined grammar table; Rule E-220 no class promotion without a label change | National and local | A reader can tell what kind of statement they are reading | Labels may be experienced as hedging and reduce impact | Low | Nil | One register audit per period | Claim register | Every public figure and claim | E-05; E-29 | None | Stage 0–1 | High | Sample audit: does every published figure carry a label and every claim a class? | **CI-8** traceability at 100%; zero unlabelled figures | `PROPOSED — REQUIRES APPROVAL` |

## 63.4 Mergeability and sequencing

**[P]** Adoption order by dependency:

| Wave | Amendments | Precondition |
|---|---|---|
| **W1 — Stage 0–1, immediate** | E-01, E-02, E-03, E-04, E-14, E-15, E-16, E-17, E-18, E-23, E-34, E-35, E-42, E-46 | None. All are paper-executable and cost nothing but discipline |
| **W2 — Stage 1** | E-05, E-06, E-07, E-09, E-10, E-13, E-19, E-20, E-21, E-22, E-25, E-26, E-27, E-29, E-30, E-33, E-37, E-39, E-44 | W1 operating for one cycle; the shared pilot run |
| **W3 — Stage 2–3** | E-08, E-24, E-28, E-31, E-32, E-36, E-38, E-40, E-43, E-45 | ≥ 2 localities; communication capacity costed and funded (GATE E6) |
| **W4 — blocked by unresolved source items** | **E-11, E-12 (the palette and mark only), E-41** | **N12 brand ownership, N13 IP ownership, and the entity structure must be resolved by the source hierarchy. Nothing in this document resolves them** |

**[A]** E-12 is split across waves deliberately: **the prohibitions (no red dominance, no colour-only meaning, no uniform, no insignia, four permitted surfaces) are Stage 0–1 and cost nothing**, while **the positive palette and mark are blocked by N12.** An organisation can know what it may not look like long before it may decide what it does.

---

# PART 64 — CONTRADICTION AUDIT E-C-01 … E-C-20

## 64.1 Method

**[P]** Each item states the two positions, classifies the relationship as **TRUE CONTRADICTION**, **TENSION** or **APPARENT CONFLICT**, and gives the treatment. **No item is resolved by silently preferring one source.** Where a contradiction is real and beyond this document's authority, it is carried to Part 62 and Annexure K.

## 64.2 The audit

| ID | Position A | Position B | Class | Treatment |
|---|---|---|---|---|
| **E-C-01** | **National identity** — the organisation should be recognisable across India and feel Indian | **Political neutrality** — no adoption of political symbols, slogans, flags, colours, insignia, gestures, songs, portraits or dress; no political content including favourable **[S-A: A-01 N4, N5]** | **TENSION.** A national identity expressed through any of the prohibited forms is political; expressed through none of them, it is thin | **Resolved by Rule E-6 (presence not claim) and Rule E-57 (epistemic before affective).** National identity is built from checkable records, not from symbols. **The tension is permanent and is managed, not eliminated** |
| **E-C-02** | **National identity** — a shared identity across faiths | **Religious neutrality** — no theological position expressed; no religious framing including favourable **[S-A: A-05 clauses 2, 6]** | **APPARENT CONFLICT.** A shared *service* identity requires no theological content | Both preserved. Rule E-37 no religious ritual; Rule E-38 seva descriptive only; the shared element is **the eight immutable items and the record**, which are secular in form |
| **E-C-03** | **National identity** — one organisation across castes | **Caste neutrality** — no individual caste data collected; composition monitoring `UNRESOLVED — deliberately` **[S-A: A-18, N5]** | **TRUE CONTRADICTION in evidence terms.** A national identity that must be shown to be caste-neutral cannot be shown demographically, because the data may not exist | **Not resolved by collecting data.** Rule E-48 prohibits it. **Resolved behaviourally** (CN-1…CN-6) and the residual is recorded: a skewed pattern in a segregated settlement cannot be rebutted demographically, only by published criteria and routing records |
| **E-C-04** | **National identity** — consistency across localities | **Local autonomy** — the neighbourhood decides what its problem is; ten items are localisable **[S-ST: §12.1; S: Ch.6]** | **APPARENT CONFLICT.** Consistency of *standards* versus consistency of *expression* | Both preserved by Rule E-50 (eight immutable, rest local by default) and Rule E-136 (adaptation runs through the register). **Consistency applies to R-1…R-10; expression is free** |
| **E-C-05** | **Brand visibility** — a mark that makes the organisation recognisable | **Vigilante perception** — no uniform, no uniform-like garment, no insignia, no outward-displayed ID; the mark may not appear on worn garments or crowd-facing vehicles **[S-A: A-06 V1…V3, V8]** | **TRUE CONTRADICTION for worn visibility.** A brand that is only on documents and banners is far less visible than a brand on shirts | **Resolved against visibility.** Rule E-65 four permitted surfaces is exhaustive. **The organisation accepts lower visual recognition as the price of not being mistaken for a security force** — and MC-3 is rated **Severe** |
| **E-C-06** | **Recognition** — people should be acknowledged for contribution | **Personality cult** — no portrait, no founder attribution, no eponymous artefact, honour contribution and neighbourhood never a person's position **[S-A: A-16 §15.4]** | **APPARENT CONFLICT.** Recognising a *person* versus recognising a *position* | Both preserved: **a person may be credited for work, never described in terms of quality (Rule E-152)**, and no national recognition names a person (Rule E-204) |
| **E-C-07** | **Growth** — the organisation should expand | **Anti-MLM** — no compensation, recognition or progression may depend on another person's participation **[S-C: H-21; S-D: Rule D-118]** | **TENSION.** Growth requires people to tell other people; anti-MLM prohibits rewarding them for it | Both preserved. **Rule E-135 no referral mechanism of any kind, including non-monetary; Rule E-162 the growth-source test.** Growth happens or it does not, and nobody is paid or praised for causing it |
| **E-C-08** | **National membership** — a large member base | **Voluntary participation** — every stage is a destination; L0 is complete; no forced progression **[S-C: H-02, H-07]** | **TRUE CONTRADICTION if membership is a target.** A target creates pressure; pressure destroys voluntariness | **Resolved against the target.** Rule E-86 no conversion target ever; Rule E-183 no report leads with a participation count. **Membership is an output, never an objective** |
| **E-C-09** | **Transparency** — publish so people can check | **Privacy** — C3/C4 classification, minimisation, sealed categories, small-cell suppression **[S-A: A-17…A-20]** | **TENSION, permanent.** The records that would most powerfully demonstrate honesty are the ones most likely to identify someone | **Resolved toward suppression (Rule E-99)** with a temporal mitigation: aggregate now, specific later when identification risk decays, never for victims, survivors, complainants, whistleblowers or minors. **The trust signal is weakened, and that is accepted** |
| **E-C-10** | **National communication** — reach, frequency, presence | **Evidence discipline** — every claim traceable to a record; nothing published above its class **[S-ST: §11.3]** | **TENSION.** Communication volume is limited by evidence volume | **Resolved in favour of evidence.** Rule E-107 post only what is already published. **Communication frequency is therefore a function of service frequency, which is the correct dependency** |
| **E-C-11** | **National expansion** — more localities | **Economic viability** — `H_gov ≤ σ_max`; no revenue line for service, governance, training **or communication** **[S-B: §25, §26]** | **TRUE CONTRADICTION at the margin.** Each new locality adds governance and communication cost with no revenue line for either | **Resolved by Rule E-166 (weakest capacity constrains), Rule E-168 (communication costed) and GATE E6 (communication capacity funded).** Where `σ_max` cannot carry it, the locality is not opened |
| **E-C-12** | **National expansion** | **Leadership capacity** — leader supply is a stock problem; positions are arithmetically scarce `L_pos/K`; out-of-team assessment requires a City **[S-B: §24.5; S-D: Part 10 §10.7, ES.5]** | **TRUE CONTRADICTION.** Expansion multiplies units faster than it multiplies leaders and assessors | **Not resolved — carried.** **[S-D: XG-1…XG-8]** adopted unchanged; Rule E-214 makes the gate sets conjunctive. **This is the binding constraint on national identity, and no communication instrument affects it** |
| **E-C-13** | **National expansion** | **Human-system validation** — the fifteen human measurements have not been run; the pilot has not happened **[S-C: §57, §58]** | **TRUE CONTRADICTION in sequence.** National communication describes a human system that has not been observed | **Resolved by the claim ladder.** CL-0 and CL-1 permit only statements about design and testing. **Nothing national may be claimed before GATE E3** |
| **E-C-14** | **National claims** — what the organisation wants to say | **Pilot evidence** — one team, no technology, and seven explicit limits on what the pilot can prove **[S-D: Part 41 §41.5]** | **TRUE CONTRADICTION.** The pilot cannot validate succession, promotion, assessment independence, cohort normalisation, burden at scale, the multiplier, or anti-favouritism | **Resolved by Rule E-129 and TS-14: publish what is not known.** The limits are published alongside the results, so a narrow success cannot be reported as a general one |
| **E-C-15** | **National brand** — an institutional identity | **Founder identity** — ownership includes "property, brand, strategy and ultimate founder-level control" **[S: Ch.4]**; **[S-A: A-16]** requires the public face to be a set of people doing work | **TENSION, and structural.** The brand is owned by a person while the identity must not be a person | **Not resolved — carried.** Rules E-149…E-158 constrain the *expression*; **[S-A: N12]** brand ownership remains `UNRESOLVED`; **[S-D: ES.5]** and **[S-ST: §11.1]** record that visibility is controllable and dependence is not |
| **E-C-16** | **National communication** — AI translation, drafting, summarisation, sentiment analysis | **AI governance** — AI may recommend; humans decide; AI cannot autonomously make consequential legal, safeguarding or safety decisions **[S: Const. Art.12]** | **APPARENT CONFLICT.** A translated consent text or safety instruction *is* a consequential legal or safety decision | Both preserved by Rule E-68 (machine translation never publishes; named human review mandatory for LA-1, LA-3-legal and LA-5) and Rule E-133 (AI content disclosed; synthetic evidence absolutely prohibited) |
| **E-C-17** | **Digital scale** — a national platform reaching millions | **Physical community** — trust is deposited person to person; belonging is local; the pilot runs with no technology **[S-ST: §14.2 Layer 1; S-B: §40]** | **TENSION.** Digital reach is cheap; digital belonging is not a thing | **Resolved by Rule E-196 (digital serves physical) and Rule E-198 (the public record is platform-independent).** Digital carries records and discovery; **physical carries trust** |
| **E-C-18** | **National consistency** — one meaning everywhere | **Local culture** — L3 is fully local; the organisation sets meaning, never phrasing **[S-C: §30.2]** | **APPARENT CONFLICT.** Consistency of meaning versus consistency of wording | Both preserved: **meaning is registered per language and per state; wording is local.** The terminology register is the instrument that makes the distinction operable |
| **E-C-19** | **National reputation** — protect the institution | **Truthful failure disclosure** — report results honestly including failures; publish failures; a published correction is a precondition of national trust **[S: App. A §16.3; S-ST: §14.2, §14.3 item 9]** | **TRUE CONTRADICTION in incentive terms.** The people who decide whether to publish a failure are the people it damages | **Not fully resolved — this is ES.5.** The minimum correction is **Rule E-88**: an empty correction log across a reporting period is published as an anomaly and referred to Audit. **A control that acts on absence is the only available answer, and whether it will be honoured is `EMPIRICALLY UNVALIDATED`** |
| **E-C-20** | **National growth** — more units, more people, more activity | **Governance burden** — `H_gov` per unit, the City divisor of unknown shape, the automate-or-retire discipline **[S-B: §25, §26.3; S-D: Rule D-91]** | **TRUE CONTRADICTION if the divisor is not sub-linear.** Then adding localities adds governance faster than capacity | **Not resolved — carried.** Rule E-91 gates State formation on measuring the divisor; Rule E-138 requires measurement per environment type; Rule E-169 requires retirement when communication exceeds service and verification hours |

## 64.3 Summary

| Class | Count | Items |
|---|---|---|
| **TRUE CONTRADICTION — resolved against the growth, visibility or reputation interest** | 4 | E-C-05, E-C-08, E-C-11, E-C-13 |
| **TRUE CONTRADICTION — NOT RESOLVED, carried forward** | 5 | **E-C-03, E-C-12, E-C-14, E-C-19, E-C-20** |
| **TRUE CONTRADICTION in incentive terms — minimum correction only** | 1 | **E-C-19** (counted above) |
| **TENSION — both preserved with a control** | 5 | E-C-01, E-C-07, E-C-09, E-C-10, E-C-15, E-C-17 |
| **APPARENT CONFLICT — resolved by reading** | 5 | E-C-02, E-C-04, E-C-06, E-C-16, E-C-18 |

**[A]** The pattern is the finding: **in every true contradiction, v1.3-E resolves against growth, visibility, reputation or reach — and in favour of evidence, dignity, capacity and honesty.** Four are resolved that way; five cannot be resolved at all. **Of the five unresolved, E-C-12 (leadership capacity) and E-C-19 (failure disclosure) are the two that determine whether the other three matter.**

---

# PART 65 — BURDEN AUDIT

## 65.1 Method

**[P]** Every mechanism this document adds is assigned to the level that operates it, with a burden class. **`T` trivial (minutes, per event) · `L` light (under an hour, per cycle) · `M` moderate (hours, per cycle) · `H` heavy (recurring hours competing with delivery) · `X` requires a person or capability that does not currently exist.**

**[A]** Brief §214 requires eleven dimensions per mechanism. They are aggregated here into the burden class, the operator, and the specific dimension that dominates — because a table with eleven columns per mechanism and forty-six mechanisms would be unreadable and would itself be reporting theatre (Rule E-101).

## 65.2 Mohalla level

| Mechanism | Class | Who does the work | Dominant dimension | Deferrable? |
|---|---|---|---|---|
| PLR-1…PL-7 public local record | **M** once, **L** monthly | Team, in its language | Translation and communication | **No from GATE E1** |
| Paper sheet equivalent (Rule E-79) | **L** | Team | Communication | **No** |
| Dated result board at completed sites | **T** per site | Team | Economic — materials | **No** |
| First-contact artefacts, eight questions answered | **L** once | Team + National | Translation | **No** |
| Two ungated actions operating (report a need / help once) | **L** | Team | Human — someone must answer | **No** |
| Paired first task | **M** per newcomer | Two existing members | Human — their time | **No** |
| Attribution loop closure | **T** per contribution | Team | Communication | **No** |
| Correction log entries | **T** per error | Anyone who finds it | Governance — none, by Rule E-186 | **No** |
| Refusal log entries | **T** per approach | Role-holder | Governance | **No** |
| Terminology register use | **T** per term | Team + National | Translation | **No** |
| Vocabulary discipline (Rule E-159) | **T** | Everyone | Training | **No** |
| Beneficiary-dignity rules in practice | **T** per artefact | Editor function | Training | **No** |
| Complaint route reaching outward | **T** per matter | Any member | Governance | **No** |
| Story production (ST-1…ST-8) | **M** per story | The person who did it, recorded not written for | Communication | **Yes — Stage 2** |
| LA-5 pre-positioned emergency text | **M** once | National + local reviewer | Translation | **No — a launch condition** |
| Accessibility implementation | **L** | Team + National | Technology and training | **No** |

**[A] Mohalla finding:** the non-deferrable set is dominated by **translation and by someone having to answer**. Both are human costs inside `H_gov`. **Neither is a technology cost, and both are payable at CL-0** — which is why **[S-B: §40]**'s no-technology pilot is the correct validation environment for this instrument.

## 65.3 City, State and National levels

| Level | Mechanism | Class | Dominant dimension | Deferrable? |
|---|---|---|---|---|
| **City** | Translation and terminology review per language | **H** | Translation | **No from GATE E1** |
| **City** | Verification channel responses (PLR-6) | **M** | Human | **No** |
| **City** | Media and query response within a stated window | **M** | Communication | **No** |
| **City** | Aggregate reporting with small-cell suppression | **L** | Data | **Yes — Stage 3** |
| **City** | Pattern reviews — routing, calendar, venue, recognition | **M** | Governance | **Yes — Stage 2** |
| **State** | Per-state terminology and political-association review | **M** | Legal and cultural | **No before operation in that state** |
| **State** | Language equity demonstration | **H** | Translation | **No before CL-6** |
| **National** | Claim register and claim-ladder audit | **M** per period | Governance | **No from GATE E0** |
| **National** | TS-1…TS-14 publication | **H** per period | Communication, translation, audit | **Tiered by stage** |
| **National** | Crisis capacity, pre-funded and rehearsed | **M** standby | Economic — **currently unfunded (§42.5)** | **No** |
| **National** | Brand governance, account custody, dual-custody administration | **L** | Governance | **No** |
| **National** | Independent review arrangements | **M** | Economic | **No before CL-3** |
| **National** | Knowledge repository and versioned standards | **M** | Data, governance | **Yes — Stage 2** |

**[A] National finding:** the heavy items are **translation, publication and crisis standby** — and **all three are absent from [S-B]'s cost model.** Rule E-168 records this as a gap in the prior instruments, not as a criticism: v1.3-B's scope was the mohalla unit, where communication is a few hours a month. **At CL-3 and above it is a function.**

## 65.4 The burden verdict

**[P]** Three findings:

1. **The mohalla burden is light and is dominated by translation and by answering.** Both are payable at CL-0 and neither requires technology.
2. **The City carries the translation, verification-channel and media-response load** — the same pattern **[S-D: Part 48]** found for assessment independence. **The City is where every local `X` becomes an `H`.**
3. **National communication is an unfunded obligation across all five instruments.** `UNKNOWN — PILOT / FUTURE VALIDATION` is the honest entry for its cost, and **Rule E-169 supplies the test that will detect the problem before it becomes structural: if communication hours exceed service and verification hours at any level, that level is over-communicated and must retire instruments.**

---

# PART 66 — ECONOMIC AUDIT

## 66.1 The rule about money

**No rupee value, budget, salary, media spend, event cost, travel assumption or growth figure is invented in this Part.** **[S: App. A §1.1]** records that the economic blueprint was never attached. **[S: Ch.18]**'s waterfall is the control. **[S: Ch.33]** leaves the entity structure, worker classification, leader multiplier and founder compensation unresolved. **Every unknown reads `UNKNOWN — PILOT / FUTURE VALIDATION`.**

## 66.2 Economic dependencies, not figures

| # | Dependency | Nature | Status |
|---|---|---|---|
| **EA-E1** | **There is no revenue line for communication.** The source has no revenue line for service, governance or training **[S-B]**, and none for communication | **Structural.** Communication is paid from the same pool as delivery | **`UNKNOWN`; Rule E-168 requires it to be costed into `H_gov`** |
| **EA-E2** | **Translation is the largest single communication cost** | Per language × per register; LA-1 and LA-5 are full-and-once, LA-2 by need, LA-4 free, LA-5 pre-positioned **[S-C: §30.5]** | **[S-B: HC-19]** already records translation as a hidden cost |
| **EA-E3** | **Crisis capacity must be pre-funded** | A crisis is exactly when capacity is least available | **`UNKNOWN`; not currently in any cost model** |
| **EA-E4** | **The human accessibility route costs a person's time** | Rule E-72; **cheaper than a digital route at small scale, dearer at large scale** | The economics invert at an unmeasured scale |
| **EA-E5** | **Publication costs rise with localities, not with participants** | PLR is per locality; TS is per period | Sub-linear in participants; **linear in localities** |
| **EA-E6** | **Brand ownership unresolved (N12) creates an unquantifiable exposure** | Teams hold no documented right to the name; exit and dissolution become chaotic **[S-A: N12]** | **`UNRESOLVED`; Rule E-60 blocks national brand use** |
| **EA-E7** | **IP ownership unresolved (N13) means the operating system could be withdrawn** | Architecture, SOPs, curricula, software, data models, brand assets **[S-A: N13]** | **`UNRESOLVED`** |
| **EA-E8** | **Entity structure unresolved determines tax, disclosure and political-activity exposure** | **[X]** 12A exemption is conditional on applying at least 85% of income to charitable purposes and on no political activity or support to any party or candidate, with cancellation risk; 80G donor deduction; FCRA required for foreign contribution | **`UNRESOLVED` [V]** |
| **EA-E9** | **Insurance is a precondition of any protection-adjacent public activity** | **[S-A: A-10; S-ST: §14.3 item 5]** | **`UNRESOLVED` [V]** |
| **EA-E10** | **A data breach carries statutory penalty exposure** | **[X]** DPDP Act 2023 penalties up to ₹200 crore for failure to notify and roughly ₹250 crore for inadequate safeguards | **`[X]` external fact; application depends on the unresolved entity structure [V]** |
| **EA-E11** | **Paid media, celebrity endorsement and national campaigns are prohibited** | Rules E-25, E-111, E-175 | **Zero cost by prohibition — the cheapest line in this audit** |
| **EA-E12** | **Growth is capacity-constrained, so communication spend cannot buy scale** | Rule E-166; GATE E0…E7 | **Communication has no growth lever, which removes the usual justification for a marketing budget** |

## 66.3 The economic verdict

**[A]** Three findings, stated plainly:

1. **The communication architecture is cheap because it is almost entirely publication of existing records.** TS-1…TS-14, PLR-1…PL-7, the correction log, the refusal log and the accounts are all **by-products of work the organisation must already do**. The marginal cost is translation and a page.
2. **The three expensive items are translation, crisis standby and independent review** — and all three are **non-deferrable pre-conditions of national trust** **[S-ST: §14.3]**, not optional enhancements.
3. **The largest economic exposure is not a cost but an unresolved ownership question.** **N12 and N13 mean the organisation may build a valuable national identity on an asset it does not documentedly own.** Rule E-60 exists for exactly this reason, and it is the only control in this document that blocks an activity for a legal rather than an operational cause.

---

# PART 67 — HUMAN-SYSTEM AUDIT

## 67.1 Does national branding create the six harms?

**[P]** Brief §216, tested against **[S-C]**'s protections, which are **converted into constraints and never rewritten.**

| Harm | Does this instrument create it? | Control | Residual |
|---|---|---|---|
| **Pressure** | **No, if Rule E-86 and Rule E-135 hold.** No conversion target, no referral mechanism, no growth campaign, no national date | Rules E-24, E-25, E-86, E-135, E-144, E-175 | **Medium — informal local status pressure is not controllable by rule** |
| **Status competition** | **No.** Absolute recognition only; no ordinal instrument at any level; no national recognition of a person | Rule E-202; Rule E-204; **[S-C: SR-2]** | Low |
| **Exclusion** | **No, if the language and accessibility rules hold.** Every process has a human route; the mandatory translation set is a launch condition; no language is senior | Rules E-53, E-66, E-67, E-70, E-72 | **Medium — practice drifts toward the language of the centre (AD-14)** |
| **Conformity** | **No, if Rule E-141 holds.** The dissent count is the tripwire and is published | Rule E-140; Rule E-141; **[S-A: A-16 test 3]** | **High — conformity is comfortable and self-reinforcing** |
| **Identity replacement** | **No.** Additive participation; no uniform, no oath, no title, no eponymous artefact, no greeting, no ritual; **L0 is complete** | Rule E-7; Rules E-149…E-158; Rule E-11; **[S-C: §8.4]** | Low |
| **Recruitment pressure** | **No.** No beneficiary conversion pathway at all; no referral; no growth campaign; no membership target | Rule E-13; Rule E-135; Rule E-175; **[S-C: H-03, H-22]** | Low |

## 67.2 The protections, verified as preserved

| Protection **[S-C]** | Preserved? | Where it binds here |
|---|---|---|
| **H-02 nine-level spectrum** | **Yes** | Part 4 §4.1; Rule E-14 low-level participation is a complete outcome |
| **H-03 never recruit at the moment of vulnerability** | **Yes — strengthened** | Rule E-13 no conversion pathway at all; §38.3 no pathway exists; Rule E-86 no conversion target |
| **H-04 first ten seconds / H-05 first five minutes** | **Yes — extended nationally** | Parts 16, 17; PLR-1…PL-7 |
| **H-06 paired first task** | **Yes** | FW-3 |
| **H-07 no forced progression; six endpoints** | **Yes** | Rule E-85; Rule E-11 |
| **H-08 six recognition instruments** | **Yes** | Rule E-202; Part 55 |
| **H-09 contribution record / H-10 portable credential** | **Yes — extended to portability across localities** | Part 54 |
| **H-11 specialist and Elder/Mentor paths** | **Yes** | Part 56; **[S-D: SP-series]** |
| **H-13 rituals under six tests** | **Yes — most rituals refused** | Part 36; Rule E-144 |
| **H-14 story framework** | **Yes — extended with cost and next** | ST-1…ST-8 |
| **H-15 attribution and follow-up loop** | **Yes** | Part 5 stage 4; HM-7, HM-8 |
| **H-17 seven refusal rights / H-18 paused and alumni status** | **Yes — mirrored in Rule E-165 published refusal scripts** | Part 41; Rule E-163 |
| **H-19 anti-cult safeguard** | **Yes — extended to the communication layer** | Part 39 AC-1…AC-9 |
| **H-21 anti-MLM compensation firewall** | **Yes — extended to vocabulary and imagery** | Part 40 ML-1…ML-8 |
| **H-22 beneficiary/recruitment separation** | **Yes — strengthened to "no pathway exists at all"** | Rule E-13; §38.3 |
| **H-23 flexible modes / H-24 remote participation** | **Yes** | Part 15; Part 56 |
| **H-25 language architecture (L1/L2/L3)** | **Yes — extended to five registers** | Part 14 |
| **H-26 layered identity** | **Yes — carried unchanged and made operational** | Part 11 |
| **H-27 youth and elder participation rules** | **Yes** | Part 3; Part 28 |
| **§8.4 no instrument may describe leadership as a higher form of service** | **Yes — absolute** | Rule E-204; Part 55 |
| **§23.2 a person is never scored** | **Yes — absolute** | Rule E-200; Part 22 never-publish list |
| **CR-1…CR-4 record limits** | **Yes** | Rule E-199 six-property test |
| **HM-1…HM-15** | **Yes — and CI-1…CI-15 duplicate none of them** | Part 73 |

## 67.3 The human-system verdict

**[P] PASS WITH TWO QUALIFICATIONS.**

**Qualification 1 — non-participation leaves no record.** The people excluded by language, caste, class, gender, age, disability or digital access are precisely the people absent from every dataset the organisation holds. **Rule E-181 seeks the exclusion sentence rather than awaiting it, but the only detectors are inbound queries that did not convert, declines, and asking people who never joined — which requires a route to them that the organisation, by definition, does not have.** This is recorded as unresolvable.

**Qualification 2 — informal social pressure is not controllable by rule.** In a small locality, not participating is visible and is read as a statement about the person. **No instrument in this document removes that.** The mitigations are structural — L0 is complete, every stage is a destination, no attendance record is used in any assessment, refusal scripts are published in every language — and they reduce the pressure without eliminating it.

---

# PART 68 — LEADERSHIP AUDIT

## 68.1 Does national communication create the four harms?

**[P]** Brief §217, tested against **[S-D]**.

| Harm | Does this instrument create it? | Control | Residual |
|---|---|---|---|
| **Central personality** | **No, if the spokesperson model holds.** Many authorised spokespersons by domain and region; no portrait; no eponymous artefact; decisions in the organisation's name with the deciding role identified | Rules E-104, E-105, E-149, E-153; **[S-A: A-16 §15.4]**; **CI-13** | **Medium — a single compelling spokesperson will be sought by media, and the incentive to provide one is real** |
| **Leader worship** | **No.** Credit for work, never quality; no national recognition of a person; no hero vocabulary | Rule E-152; Rule E-204; Rule E-203 | Medium — affection is not controllable, only its conversion into authority |
| **Communication concentration** | **Yes, as a risk — and it is measured.** If one role or one person produces most public artefacts, the organisation has a single point of reputational failure | **CI-13** spokesperson distribution; Rule E-105 domain and region, not hierarchy; **[S-D: CU-1]** "one is a failure" | **Medium** |
| **National spokesperson dependency** | **Yes, as a risk — and it is treated as a continuity problem.** A spokesperson is a covered role and requires an SS state | **[S-D: SS-0…SS-5]** applied to communication roles; Part 52 continuity; **T4 successor test** | Medium |

## 68.2 The leadership-system interactions

| Interaction | Finding |
|---|---|
| **Does communication create a new leadership route?** | **No.** No communication role confers authority over people, and Rule E-105 explicitly separates domain authority from hierarchy |
| **Does visibility become a selection criterion?** | **Prohibited.** Part 55: recognition never rewards visibility, media appearances, speaking or being photographed. **[S-D: Part 3 §3.2]**'s nine deliberately-absent eligibility criteria include prior standing, and visibility is prior standing |
| **Does the founder's communication role create dependence?** | **This is the largest leadership risk in the instrument.** **[S-ST: §11.1]**: "if the public face is one person, every controversy about that person is a controversy about the institution, and there is no way to defend the institution by separating them." Rules E-149…E-158 and **CI-13** are the controls; **SIM-10 records that this is the simulation the architecture is least able to survive** |
| **Does communication burden fall on leaders?** | **Yes, and it must be costed.** Rule E-168 brings communication into `H_gov`; **[S-D: LLI]** bands apply; Rule E-169 requires retirement when communication exceeds service and verification |
| **Is a communication role a covered role for succession?** | **Yes.** National Communications, Editor and Social Media Manager are role families with a Succession column **[S: Ch.9]**, and **[S: App. A §8.x]** already requires "channel access must be revocable; backup admin appointed with two-person recovery process" |
| **Does the architecture let a leader control information?** | **Prohibited by Rule E-157:** every fact is published from a record, so no person is its only source. **[S-A: A-15 M1…M7]** and **[S-D: Part 28]** supply the mechanism |

## 68.3 The leadership verdict

**[P] PASS, WITH ONE UNRESOLVED DEPENDENCY.** The communication architecture does not create a new power centre, does not make visibility a selection criterion, and treats communication roles as covered roles with succession obligations. **The unresolved dependency is the founder's public role: [S-A: A-16 §15.4] constrains it, [S-D: CU-1…CU-10] audits it, and neither eliminates it — because [S: Const. Art.3] ownership is APPROVED architecture and is not this document's to change.** **[S-D: ES.5]**'s finding stands and is not softened: **v1.3-D remains unproven, and a national identity built above an unproven leadership system inherits its uncertainty in full.**

---

# PART 69 — INSTITUTIONAL AUDIT

## 69.1 The seven institutional tests

**[P]** Brief §218, tested against **[S-A]**.

| Test | Question | Result | Basis |
|---|---|---|---|
| **IA-1 NEUTRALITY** | Does any communication instrument compromise political, religious, caste or regional neutrality? | **PASS** | N1…N9 extended to expression (E-06); A-05 eight clauses extended (E-07); Rule E-48 no identity data; Rules E-50…E-54 regional plurality |
| **IA-2 LEGAL BOUNDARIES** | Does anything here assert a legal position? | **PASS — nothing asserted.** Every legal proposition is `[V]` or `[X]` with its source named | Entity structure, tax, FCRA, 12A political-activity condition, DPDP notification, BNSS provisions, paid-news regulation, minor participation, symbol use — all `[V]` |
| **IA-3 OWNERSHIP** | Does anything resolve or presuppose an answer to brand or IP ownership? | **PASS — both carried unresolved.** Rule E-60 blocks national brand use until N12 and N13 are settled; BR-9 records that teams hold no documented right | **[S-A: N12, N13, I6, V8]** |
| **IA-4 GOVERNANCE** | Does this create committees, bodies or approval layers beyond what the source provides? | **PASS — none created.** Publication authority maps onto existing roles: National Communications, Editor, Social Media Manager, authorised spokespersons, Finance, Audit, Safety, Legal | **[S-D: Rule D-40]** body-justification test applied; **no communications committee exists** |
| **IA-5 PRIVACY** | Does communication collect or disclose more than the purpose requires? | **PASS with one recorded tension.** Rule E-99 three tests; Rule E-100 suppression; the never-publish list; **E-C-09 records that transparency and privacy are in permanent tension and that this instrument resolves it toward suppression, weakening the trust signal** | **[S-A: A-17…A-20]**; **[S-C: CR-1…CR-4]** |
| **IA-6 POLITICAL PERCEPTION** | Could any instrument be read as political? | **PASS with a residual.** Colours, symbols, vocabulary, timing, adjacency, guests and silence are all controlled; **the residual is that in a politically saturated locality any large membership organisation is read politically whatever it does** — **[S-ST: §18.2 MC-1 Severe]** | Rules E-6, E-29…E-35; **[S-A: A-01, A-03, A-04]** |
| **IA-7 CONTINUITY** | Does communication survive the loss of a person, a platform or a leader? | **PASS.** Dual custody of domain, gateway, channels, social accounts and statutory portals; no personal account is an official channel; revocable access; backup admin; two-person recovery; platform-independent public record | **[S-A: A-14 §13.4]**; **[S: App. A §8.x]**; Rules E-188, E-198 |

## 69.2 The institutional verdict

**[P] PASS ON ALL SEVEN, WITH TWO RECORDED DEPENDENCIES.**

1. **IA-3: nothing here can be implemented nationally until N12 and N13 are resolved.** Rule E-60 is not a caution; it is a block. **A national identity built on an unowned mark is an asset the organisation may not be entitled to use, licence, defend or transfer.**
2. **IA-6: political perception risk is managed, never eliminated.** **[S-A: A-01]**'s own analysis rates it **Severe**, and **[S-ST: §12.2]** notes that in one politically saturated environment "the neutrality code will be tested here first and hardest." **The residual is permanent and is the reason the refusal log — not a declaration — is the instrument.**

---

# PART 70 — MASS-ADOPTION FAILURE REGISTER

**[P] MAF-01 … MAF-28.** Twelve fields per entry, as the brief requires.

| ID | Failure | Sev | Lik | Early warning | Impact | Prevention | Detection | Recovery | Owner | Residual | Validation |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **MAF-01** | **The first contact asks for something** | High | High | Any artefact containing a form, a download, a registration or an appeal | The gate appears before the value; conversion-fatal **[S-ST: §20.3]** | Rule E-78; PLR-4/PLR-5 ungated | **CI-2**; AX-T1 | Remove the ask; republish | Team + Comms | Low | None |
| **MAF-02** | **Misclassification as political, religious, security or surveillance** | **Critical** | High | CI-3/4/5 above baseline; a first hostile article | Legal, safety and legitimacy exposure | Parts 7–9, 13, 16; N1…N9; V1…V8 | **CI-1, CI-3, CI-4, CI-5** | Rule E-34/41/49 evidence-based response | National + Legal + Safety | **High in saturated localities** | Legal and cultural **[V]** |
| **MAF-03** | **A claim exceeds its evidence class** | High | High | A superlative; a national adjective; an unreferenced figure | RC-3/RC-4; the fall exceeds the rise | Rule E-1; Rule E-4; claim ladder | **CI-8**; Rule E-182 audit | Withdraw and publish the withdrawal | Comms + Audit | Medium | None |
| **MAF-04** | **The correction log stays empty** | **Critical** | **High** | Two consecutive periods with zero entries | **The central claim becomes unverifiable — ES.5** | Rule E-88; Rule E-186 no approval needed | TS-6 emptiness; Audit referral | Publish the anomaly; refer to Audit | Audit | **High — this is the least enforceable control in the instrument** | None |
| **MAF-05** | **A beneficiary is exposed** | **Critical** | Medium | Any image, name, locality detail or testimony in draft | Dignity harm; MC-9; privacy breach | Rule E-148; E-34; Editor rejection authority | **CI-14**; Editor rejection log | Withdraw; notify if required; correction | Editor + Data | Low | Privacy **[V]** |
| **MAF-06** | **A fabricated or synthetic impact claim** | **Critical** | Low | An artefact with no record behind it | **Total — the differentiation is destroyed (Rule E-132 analysis)** | Rule E-132; Rule E-133; claim register | **CI-8**; audit sampling | Publish the fabrication and the correction; treat as serious misconduct | Audit + Governance | Low | None |
| **MAF-07** | **Language exclusion in practice** | High | Medium | A national statement published in one language first | Hard exclusion, not friction **[S-C: §30.1]** | Rules E-53, E-66, E-67 | **CI-6**; **CI-7** | Publish in the missing languages; register the failure | Comms | Medium | Legal review of L1 texts **[V]** |
| **MAF-08** | **Digital-only process excludes** | High | Medium | A form, app or account required for any step | Class and access exclusion | Rule E-72; Rule E-79; AX-D | **AX-T1** | Restore the human route | Team + Technology | Low | Accessibility **[V]** |
| **MAF-09** | **Recruitment pressure emerges locally** | High | Medium | Membership language at first contact; "bring a friend" | **[S-C: H-03]** breach; MLM reading | Rules E-86, E-135, E-162, E-175 | Vocabulary audit; **HM-12** | Withdraw the artefact; retrain | Team + Comms | Medium | None |
| **MAF-10** | **Vanity metrics become evidence** | Medium | High | A follower count in any report, pitch or argument | Goodhart; RC-4 | Rule E-106; Rule E-2 | Any artefact audit | Withdraw; correct | Comms + Audit | Medium | None |
| **MAF-11** | **A creator or celebrity becomes the face** | High | Medium | One person's audience drives inbound | NEF-6; dependency; contagion | Rules E-110, E-111; **CI-13** | Spokesperson distribution | End the arrangement; distribute voices | National Comms | Medium | None |
| **MAF-12** | **Platform or account loss** | High | Medium | A single custodian; a personal account in use | The public record becomes unreachable | Rule E-188; Rule E-198; dual custody | Continuity test | Restore from the platform-independent record | Technology + Comms | Low | Security **[V]** |
| **MAF-13** | **Viral surge exceeds capacity** | High | Medium | Inbound rising faster than triage | Declines multiply; RC-4 | Rule E-166; Rule E-170 | Inbound vs capacity ratio | Publish the limit; pause growth | City → National | Medium | None |
| **MAF-14** | **Slow growth treated as failure** | Medium | High | A "momentum" narrative; cross-locality growth comparison | Manufactured growth; recruited people | Rule E-172 | Any artefact comparing growth rates | Withdraw; republish small numbers plainly | Comms | Medium | None |
| **MAF-15** | **A decline or closure goes unpublished** | High | Medium | Openings published, endings absent | Promotion is correctly inferred | Rule E-176; TS-13 | Compare openings to closures published | Publish the closure retroactively | National | Medium | None |
| **MAF-16** | **Criticism deleted** | High | Medium | A moderation action without a logged ground | **The deletion becomes the story** | Rule E-109 | Deletion log audit | Restore; publish the error | Comms + Audit | Low | None |
| **MAF-17** | **Whistleblowing classified as an attack** | **Critical** | Medium | A report handled by the line it concerns | The most valuable information is destroyed and the reporter punished | Rule E-108 C-WHB; Rule E-178 default is criticism; E-190…E-195 | Classification record audit (Rule E-179) | Route to the Integrity Line; non-retaliation | Audit + Integrity Line | Medium | Legal **[V]** |
| **MAF-18** | **A partnership implies endorsement** | Medium | Medium | A partner's mark on a service artefact | MC-5; capture | BR-3, BR-4; Rule E-112; PT-C | Brand-usage audit | Withdraw; correct; terminate if needed | Comms + Legal | Low | Legal **[V]** |
| **MAF-19** | **Door 3 is implied where no funded venture exists** | High | Medium | Any earnings language in a service artefact | **MC-6; material harm to a low-income person (Rule E-15 analysis)** | Rule E-15; Rule E-120 | **CI-2** question 8; vocabulary audit | Withdraw; publish the correction | Comms + Business | Low | None |
| **MAF-20** | **Hero or combat vocabulary appears** | Medium | Medium | Any artefact using hero, warrior, guardian, front-line | MC-3 vigilante reading | Rule E-203; vocabulary register | Vocabulary audit | Withdraw; re-register the term | Comms | Low | Cultural **[V]** |
| **MAF-21** | **A national day or eponymous artefact is created** | Medium | Low | Any proposal for a founding day, an award named for a person | NEF-3, NEF-6 | Rule E-144; Rule E-153 | Any artefact audit | Refuse; record the refusal | National | Low | None |
| **MAF-22** | **Composition data is collected to prove neutrality** | **Critical** | Low | Any identity field in any form | **Creates the instrument that would later be used to sort people** | Rule E-48; **[S-A: A-18, N5]** | Data-field audit | Delete; notify if required; refer | Data + Legal | Low | Privacy and equality **[V]** |
| **MAF-23** | **Communication hours exceed service and verification hours** | High | Medium | `H_gov` composition shifting | A second organisation whose job is describing the first | Rule E-168; Rule E-169 | Ledger composition review | Retire instruments (Rule D-128 logic) | National + City | Medium | None |
| **MAF-24** | **Expansion authorised on attention rather than capacity** | High | Medium | An expansion proposal citing followers, funding or coverage | Capacity exceeded; **E-C-11, E-C-12** | Rule E-213; Rule E-214; GATE E0…E7 | Authorisation record audit | Reverse or pause; publish the pause | National | Medium | None |
| **MAF-25** | **Non-participation is invisible, so exclusion is undetected** | High | **High** | Every dataset shows only participants | The excluded are never counted and never addressed | Rule E-181 seek the exclusion sentence | Inbound-that-did-not-convert; declines; direct asking | Ask people who never joined — **which requires a route the organisation does not have** | City + National | **High — recorded as unresolvable** | None |
| **MAF-26** | **A record is portable in form but not accepted in practice** | Medium | **High** | A credential presented and discounted | The most valuable asset yields no value | Rule E-201 checkability, not prestige | Third-party acceptance observation | Improve checkability; never inflate the claim | National | **High — outside the organisation's control** | None |
| **MAF-27** | **Reputation is built before the institution** | **Critical** | Medium | NI ahead of MA (Part 60 §60.2) | Brand outruns reality; the fall exceeds the rise | Rule E-4; Rule E-91; Rule E-182; Rule E-219 default IMPROVE | NI/MA matrix per locality | Stop publishing scale claims; publish capacity limits | National | Medium | None |
| **MAF-28** | **The whole communication system is complied with nominally** | **Critical** | Medium | Artefacts exist, are approved, and change nothing | **The architecture exists and does not operate — [S-D: LF-17]** | Rule E-101 no reporting theatre; Rule E-53 every review has a consequence route | **No internal control detects it.** Only F-360c-class downward experience, the Integrity Line, and asking people | Unknown | Audit + National | **CRITICAL — the terminal weakness, inherited from [S-D: LF-17] and unresolved here** | None |

## 70.1 The unresolvable failures

**[A]** Four register entries are recorded as unresolvable rather than mitigated: **MAF-04** (the empty correction log — the least enforceable control, and ES.5), **MAF-25** (non-participation leaves no record), **MAF-26** (third-party acceptance of a portable record is outside the organisation's control), **MAF-28** (nominal compliance is undetectable from inside).

**[P] Rule E-221 (An Unresolvable Failure Is Published, Not Managed).** Each of the four appears in the annual accountability report as a **known limitation**, with its mechanism and its residual. **[A]** Reason: **an organisation that lists only the risks it has controlled is describing its controls, not its risks.** Publishing the unresolvable ones is the only form of honesty available about them, and it is consistent with TS-14 and Rule E-129.

---

# PART 71 — NATIONAL RED TEAM

**[P] NRT-01 … NRT-20.** Each attacker is **intelligent, patient, and pursuing a legitimate interest by illegitimate means.**

| ID | Attacker | Attack | Detection | Response | Residual |
|---|---|---|---|---|---|
| **NRT-01** | A political operative | Places members, seeks adjacency, offers resources, times requests to elections | Approach register; refusal log; **CI-3** | N1…N9; refusals logged and published; recusal | **High — patient and lawful** |
| **NRT-02** | A religious body | Becomes the dominant local partner; supplies premises, volunteers and legitimacy | Partnership register; **CI-4**; calendar and venue pattern | A-05 clause 5 — activity-scoped, separate branding, **never exclusive where alternatives exist** | Medium |
| **NRT-03** | A dominant local caste group | Controls routing, venue, timing and recognition without any rule being broken | Behavioural pattern review (CN-1…CN-6) | Publish criteria in advance; re-route on pattern | **High — the proving data may not be collected** |
| **NRT-04** | The founder's own circle | Uses proximity as an implicit instruction, never recorded | Founder Recusal Register **[S-D: Rule D-92]**; attribution test T2 | Rule E-151 a founder preference is a declared interest; Rule E-150 authority cited to a document | **High** |
| **NRT-05** | An influencer | Offers reach in exchange for access, framing or adjacency | **CI-13**; the creator agreement | Rule E-110 creators report, never represent | Medium |
| **NRT-06** | A member with commercial intent | Builds a downline informally; trades on the mark; sells introductions | Vocabulary audit; formula audit; brand-usage audit | Rules E-118, E-135, E-159, E-162; BR-11 | Low — document-provable |
| **NRT-07** | A journalist seeking a scandal | Requests access conditional on framing; offers favourable treatment for cooperation | Rule E-126 — no exclusivity, no pre-publication review, no copy approval | Same access as any journalist; records, not narratives | **Medium — and refusing is correct even when it costs coverage** |
| **NRT-08** | A misinformation actor | Fabricates a video, a document or a claim | The claim register makes every real claim checkable; the verification channel | One calm correction, logged; platform reporting; **silence where amplification harms** | **High — the asymmetry is structural (SIM-13)** |
| **NRT-09** | An attacker on the data estate | Exfiltrates member, beneficiary or complaint data | Access logging; export logging; anomaly detection | CC-3; statutory notification **[X][V]**; containment | **Critical if successful** |
| **NRT-10** | A financial accuser | Alleges misuse without evidence, and demands a response | The published accounts already answer it | Produce the accounts and the specific transactions | Medium |
| **NRT-11** | A leadership claimant | Alleges misconduct against a rival before any determination | Classification record | Rule E-177 process before narrative; sealed category; interim measures | **High — damage occurs at accusation speed** |
| **NRT-12** | A vigilante provocateur | Engineers an incident in which members intervene, and films it | The DO-NOT list; V1…V8; the boundary statement published in advance | CC-7; incident review; the pre-published record | **High** |
| **NRT-13** | An over-claiming insider | Publishes a scale or impact claim to attract funding or attention | Claim register; Rule E-182 audit | Withdraw; publish the withdrawal; treat as a governance matter | Medium |
| **NRT-14** | A wealthy supporter | Gives substantially and expects deference | Rule E-17; aggregate funding disclosure; no donor name at point of service | Refuse the expectation; disclose the gift in aggregate; recuse on any related matter | Medium |
| **NRT-15** | A growth-maximising manager | Sets informal membership targets; celebrates headcount | **HM-12**; Rule E-183 no report leads with a count | Rule E-86 no conversion target; withdraw the artefact | Medium |
| **NRT-16** | A platform | Changes terms, suspends an account, alters reach | Rule E-198 platform-independent record | Continue publishing from the own domain and on paper | Low |
| **NRT-17** | An impostor | Uses the name or mark to collect money or gain access locally | **PLR-6 public verification channel**; BR-11 | Publish the verification route; treat as an incident; legal process **[V]** | **Medium — and this attack only becomes possible once the brand has value, which is why it arrives after success** |
| **NRT-18** | A partner in difficulty | A scandal engulfs a co-branded partner | PT-C scope document, predating the scandal | Publish the scope; terminate; correct any artefact implying endorsement | Medium |
| **NRT-19** | An internal faction | Uses local pages, marks and language to advance a regional or personal position | **CI-7** terminology consistency; brand-usage audit; locality attribution | Version-control the artefact; correct publicly; Rule E-136 | Medium |
| **NRT-20** | Nobody | **The system is complied with nominally and fails actually** | **None available from inside** | Unknown | **CRITICAL — MAF-28; inherited from [S-D: LF-17] and unresolved** |

**[A]** Score: **6 low residual, 9 medium, 5 high or critical.** The five high-or-critical residuals — **NRT-01 political, NRT-03 caste, NRT-04 founder proximity, NRT-08 misinformation asymmetry, NRT-20 nominal compliance** — share a property: **each is patient, each is partly lawful or partly invisible, and each is defeated only by sustained behaviour over years rather than by any control.** This is the same finding **[S-D: Part 43 §43.3]** reached about leadership, and it is not a coincidence: **the attacks that cannot be controlled architecturally are the attacks on the parts of an organisation that are human.**

---

# PART 72 — SHARED PILOT

## 72.1 One pilot, five instruments

**[P]** The brief is absolute: **do not create a second pilot.**

| Instrument | Pilot | Status |
|---|---|---|
| **[S-B: §40]** | **One mohalla team, no technology.** Measurements **B-P-01…B-P-14** | PRIMARY |
| **[S-C: §57]** | **The same team.** Human measurements **HM-1…HM-15** | SAME PILOT |
| **[S-D: Part 41]** | **The same team.** Leadership measurements **LM-1…LM-15** | SAME PILOT |
| **v1.3-E** | **The same team again.** Identity and communication measurements **CI-1…CI-15** | SAME PILOT |

**[P] Rule E-222 (No Second Pilot, No New Site, No New Cohort, No New Timeline).** v1.3-E adds fifteen observations to the existing pilot. **Where a CI observation requires a population the single team cannot supply, it is recorded `NOT TESTABLE AT PILOT SCALE` with its minimum population — it is not approximated and it is not satisfied by a second pilot.** This mirrors **[S-D: Rules D-130, D-131]**.

## 72.2 What one team can and cannot test about identity

| Can be tested with one team | Cannot be tested with one team |
|---|---|
| Whether a stranger can answer the eight first-contact questions (**CI-2**) | Misclassification rates across contexts — one locality has one first impression |
| Whether the category sentence works in the locality's language (**CI-6**, **CI-7**) | National language equity **[S-ST: §30.3 item 13]** |
| Whether PLR-1…PL-7 can be produced on paper and kept current | The verification channel across localities (PO-4) |
| Whether a help-seeker completes the minimum safe pathway (**HM-4**) | Cohort or comparative anything |
| Whether the two ungated actions actually work and are used | Claim-ladder progression beyond CL-1/CL-2 |
| Whether a first win satisfies FW-1…FW-6 (**HM-5, HM-6, HM-7**) | Word of mouth at scale |
| Whether a correction can be issued without approval (**Rule E-186**) and whether one occurs | **CI-9** correction latency across periods — needs several periods |
| Whether the refusal script works in the local language | **TS-8** annual refusal counts — needs an election cycle |
| Whether a dated result board changes anything observable | **CI-3, CI-4, CI-5** perceived associations — need a sample |
| Whether honest failure reporting happens when it costs something (**HM-14**, TS-6) | Reputation-capacity alignment (RC states) |
| Whether the human accessibility route works (**AX-T1**) | Digital accessibility at scale |
| Whether `H_gov` includes communication, and how much (**Rule E-168**) | Communication cost at CL-3 and above |
| Whether anyone uses the public record without joining (**CI-15**) | Contribution portability across localities |
| Whether the organisation can say "we do not know yet" in public (**Rule E-129**) | Whether it will, under national attention |

## 72.3 Pilot success conditions specific to identity and communication

**[P]** Falsifiable, observable without technology.

| # | Condition | Falsified by |
|---|---|---|
| **PS-E1** | PLR-1…PL-7 exist for the locality, in its language, ungated, and were refreshed at the monthly cadence | Any element missing, gated, stale or in the wrong language |
| **PS-E2** | A stranger, approached independently, can answer at least six of the eight first-contact questions | Fewer than six |
| **PS-E3** | At least one person used "report a need" and at least one used "help once", and **neither was asked to join** | Any membership language at first contact |
| **PS-E4** | At least one first win satisfied FW-1…FW-6, including the scripted "nothing further is expected" statement | The statement omitted, or an invitation made |
| **PS-E5** | At least one correction was issued, without approval, and logged | Zero corrections **and** zero errors found — which is not credible and is treated as a detection failure |
| **PS-E6** | At least one refusal was logged using the script in the local language | No script exists, or no refusal was logged in a period where approaches occur |
| **PS-E7** | No artefact contained a prohibited emotional register, prohibited vocabulary, combat language, a beneficiary image, or a vanity metric used as evidence | Any single instance |
| **PS-E8** | Every published claim carried its class and its evidence label | Any unlabelled claim |
| **PS-E9** | The human accessibility route completed a process for a person who could not read the artefact's language | The route required reading |
| **PS-E10** | Communication hours were recorded inside `H_gov` and did not exceed service and verification hours | Unrecorded, or exceeding (Rule E-169) |
| **PS-E11** | Nobody was recruited at a moment of vulnerability, and no beneficiary was approached about contributing | Any instance — **a fatal condition** |
| **PS-E12** | The team judges that the public record was worth its cost | A negative judgement by the people who produced it |

## 72.4 Pilot failure conditions

| # | Condition | Why fatal |
|---|---|---|
| **PF-E1** | A beneficiary's identity, image or circumstance was published | Dignity and privacy; **irreversible** |
| **PF-E2** | A claim was published above its evidence class and not withdrawn on discovery | The claim ladder is not real |
| **PF-E3** | A person was recruited, pressured or converted at a moment of need | **[S-C: H-03]**; the architecture's foundational prohibition |
| **PF-E4** | A correction was suppressed, delayed for approval, or the correction log was kept empty while errors were known | **ES.5 materialised** |
| **PF-E5** | A political, religious or caste artefact was published, including a favourable one | N1…N9; A-05 |
| **PF-E6** | Any uniform, insignia, worn mark or authority-suggesting object appeared | **[S-A: A-06 V1…V3]** |
| **PF-E7** | The public record required an account, a form or a fee | Rule E-19 |
| **PF-E8** | Communication hours displaced service or verification hours with no retirement | Rule E-169; **the second organisation has formed** |

## 72.5 What the pilot cannot prove about national identity

**[A]** Recorded so the result is not over-read — mirroring **[S-D: Rule D-132]**:

1. **It cannot prove national recognition.** One locality, one first impression.
2. **It cannot prove the claim ladder works under attention.** No national attention will occur.
3. **It cannot prove language equity.** One language.
4. **It cannot prove portability.** One locality.
5. **It cannot prove the correction log survives reputational pressure.** At CL-1 there is no reputation to protect.
6. **It cannot prove resistance to political, religious or caste capture.** One locality, one social field, no external actor incentive.
7. **It cannot prove communication cost at scale.** No technology, no range of `K`.

**[P] Rule E-223 (Pilot Scope Statement).** Every claim made about national identity after the pilot must state which of the seven limits applies. **[A]** This is **[S-D: Rule D-132]** applied to communication, and it exists because **the most likely failure after a successful pilot is that a narrow success is reported as a general one** — which is, precisely, a claim above its evidence class.

---

# PART 73 — FIFTEEN MEASUREMENTS

## 73.1 Constraints

**[P]** Exactly fifteen, per brief §222. **They must not duplicate [S-C: HM-1…HM-15] or [S-D: LM-1…LM-15].** Four further constraints: no invented targets; every measurement has a named consumer and a consequence route; **no measurement ranks an individual**; every measurement is producible on paper by one team without technology, or is marked `NOT TESTABLE AT PILOT SCALE`.

**[A] Non-duplication check, stated explicitly:** HM measures the *human journey* (comprehension, belonging, contribution, attribution, return, dignity, promises, friction). LM measures the *leadership system* (succession, continuity, decision records, vacancies, load, dependency, complaints, honesty latency, governance hours, pipeline, independence). **CI measures the *public interface*: what a stranger perceives, what may be claimed, and whether the published record is true, complete and reachable.** The three sets intersect nowhere.

## 73.2 CI-1 … CI-15

| ID | Measurement | Definition and method | Why it matters | Source | Frequency | Owner | Privacy | Interpretation | Limitation | Pilot-testable? |
|---|---|---|---|---|---|---|---|---|---|---|
| **CI-1** | **Misclassification rate** | Of people asked independently what the organisation is, the distribution of categories assigned, mapped to MC-1…MC-11 | Eleven categories, four rated Severe; the public will choose one **[S-ST: §18.1]** | **[S-ST: §18.2]**; Part 16 | Per cohort | City, aggregate | **Aggregate only; no respondent identified** | A concentration in MC-1, MC-2, MC-3 or MC-11 is an action trigger | Self-report; the question primes the categories | **Partially** — one locality, one impression |
| **CI-2** | **First-contact comprehension** | How many of the eight first-contact questions a stranger can answer after ten seconds with one artefact | The current architecture **fails 4 of 5** on a five-question version | **[S-ST: §20.1]**; Part 16 §16.1 | Per cohort | City, aggregate | Aggregate only | Below the floor, the artefact is wrong, not the reader | Distinct from **HM-2** (restating purpose) — **CI-2 measures the eight specific questions including political, religious, security, money and membership** | **Yes** |
| **CI-3** | **Perceived political association** | Share of respondents who associate the organisation with any party, ideology or political movement | MC-1 is rated **Severe**; **N9** makes a false association a correction duty | **[S-A: A-01]**; **[S-ST: §18.2]** | Per cohort | National, aggregate | Aggregate only; **no respondent's own political view is recorded** | Any non-zero is investigated, not merely noted | Perceptions are not facts, and the measurement cannot distinguish a perception from a reality | **No** — needs a sample across localities |
| **CI-4** | **Perceived religious or caste association** | Share who associate the organisation with any faith or caste | MC-2 **Severe**; **A-05** pattern-level neutrality | **[S-A: A-05]**; Part 8, Part 9 | Per cohort | National, aggregate | Aggregate only; **no respondent identity data** | Any non-zero triggers a routing, calendar, venue and recognition pattern review | As CI-3; and the behavioural rebuttal is slow | **No** |
| **CI-5** | **Perceived security or vigilante character** | Share who believe the organisation enforces, protects by force, or acts as security | MC-3 **Severe**; the protection pillar makes this the most available misreading | **[S-A: A-06]**; **[S-ST: F-09]** | Per cohort | National + Safety, aggregate | Aggregate only | Any non-zero triggers a visual and vocabulary audit | As CI-3 | **No** |
| **CI-6** | **Language match** | Whether the language of first contact equals the language of the material, per person, as a rate | Language is a **hard exclusion**, not a friction | **[S-C: §30.1, FR-11]**; Rule E-66 | Continuous | Team | Own record only; no language-identity inference | Any mismatch is a defect in the mandatory set | Only measures people who arrived; the excluded are absent (**MAF-25**) | **Yes** |
| **CI-7** | **Terminology consistency** | Share of registered terms whose meaning is identical across every operating language and state artefact sampled | Divergent meanings make the security boundary unenforceable | **[S-C: §30.1 item 3, §30.3 rule 3]**; **[S-A: A-06 V11]** | Per cycle | National Comms | None — texts, not people | Below 100% is a defect, and the defect is named | Sampling cannot cover every artefact | **Partially** — one language at pilot |
| **CI-8** | **Public-claim traceability rate** | Share of published claims that carry a claim class, an evidence label and a claim-register entry pointing to an inspectable record | **Every public claim must be traceable to a record a member could inspect** | **[S-ST: §11.3]**; Rules E-8, E-26, E-130 | Per period | Audit | None — claims, not people | **Must be 100%. Any shortfall is a governance finding, not a statistic** | Audits the published artefact, not whether the underlying record is true | **Yes** |
| **CI-9** | **Correction performance** | Count of published corrections and the interval from discovery to publication; **and whether the log was empty in the period** | The correction log is the load-bearing trust instrument and the ES.5 weakness | **[S: Ch.24 correction logs]**; Rule E-88; TS-6 | Per period | Audit + Comms | None — corrections concern the organisation | **Zero corrections across a period is published as an anomaly and referred to Audit** | An organisation can avoid corrections by making no claims; CI-8 must be read with CI-9 | **Yes** |
| **CI-10** | **Refusal-log operation** | Count of political and commercial approaches received and declined, and whether the log was published | "Publishing refusals is more credible than declaring neutrality" | **[S-A: A-04]**; TS-8; Rule E-33 | Annual | National + Legal | **Aggregate counts only; no approacher identified beyond what the log requires** | **Zero in a period where approaches occur is a warning sign**, on **[S-A: A-16]**'s logic | A locality may decline to log; detection depends on the register being mandatory | **No** — needs an election cycle or a full year |
| **CI-11** | **Verification-channel use** | Count of public queries asking whether a person or group is genuinely associated, and the response rate and interval | The channel is the anti-impersonation defence and the Layer-2 trust instrument | **[S-ST: §14.2 Layer 2]**; PLR-6; BR-11 | Monthly | City | Query logged without identifying the querier beyond necessity | **A rising count is a good sign — it means the channel is known and used** | Only counts people who know the channel exists | **Yes** |
| **CI-12** | **Publication completeness** | Share of TS-1…TS-14 and PLR-1…PL-7 items present, current and dated, at the required stage | The whole trust architecture is these publications | Part 20, Part 17 | Per period | Audit | None | Below 100% at the required stage blocks the next claim-ladder class | Presence is not quality; CI-8 covers quality | **Yes** |
| **CI-13** | **Spokesperson distribution** | Count of distinct authorised spokespersons who actually spoke publicly in the period, by domain and region | "One is a failure"; a single voice is a single point of reputational failure | **[S-A: A-16 §15.4]**; **[S-D: CU-1]**; Rule E-104 | Annual | National Comms | Names are role-holders acting in role — **published as roles, not as personalities** | **A count of one is a finding** | Counting speakers does not measure whether they were independent | **No** — one locality has one voice |
| **CI-14** | **Attribution and consent compliance** | Share of published stories where the beneficiary is the subject of the outcome sentence, the contributor of the action sentence, the organisation of neither; **and** where every personal element has a specific recorded consent for that use | Saviour grammar enters through syntax; consent is the dignity control | **[S-C: §17.4, H-14]**; Rule E-145, E-148; **E-34** | Per period | Editor + Audit | Consent records are C3; **aggregate reporting only** | **Must be 100%. Any shortfall means an artefact is withdrawn** | Audits grammar and consent, not whether the person felt dignified — **HM-13 covers that** | **Yes** |
| **CI-15** | **Unaffiliated repeat use** | Count of distinct people who used a public channel — reported a need, checked a record, asked a question, used the verification channel — **more than once, without ever joining** | This is the measurement of "national participation without membership", and of Rule E-10 | Part 3, Part 4 §4.3; Rule E-85 | Monthly | Team + City | **Contact optional; a contact is not an identity [S-C: HM-1]** | **A non-zero count is the primary evidence that the architecture's central proposition works** | Cannot count people who used no channel; anonymous use may be under-counted | **Yes** |

## 73.3 Testability summary

| Category | Count | Items |
|---|---|---|
| **Fully testable by one team on paper** | 8 | CI-2, CI-6, CI-8, CI-9, CI-11, CI-12, CI-14, CI-15 |
| **Partially testable** | 2 | CI-1, CI-7 |
| **`NOT TESTABLE AT PILOT SCALE`** | 5 | **CI-3, CI-4, CI-5, CI-10, CI-13** |

**[P]** Per Rule E-222, the five not-testable items are recorded in **Annexure I** with their minimum populations. **They are not approximated.**

**[A]** The pattern is the finding of this Part: **the measurements that test what a stranger *perceives* cannot be run at pilot scale, and the measurements that test what the organisation *published* can.** At CL-0 and CL-1 the organisation can therefore verify its own honesty but not its own reputation — **which is exactly the correct ordering, and exactly why Rule E-4 (reputation lags capacity) is a rule rather than a preference.**

---

# PART 74 — PRE-PILOT / PILOT / POST-PILOT MATRIX

**[P]** Brief §223. Eleven capabilities across four stages. **A cell states what may exist and what may be claimed at that stage.**

| Capability | **PRE-PILOT** | **PILOT** | **POST-PILOT** | **NATIONAL** |
|---|---|---|---|---|
| **Identity** | NI-0: a name (PROPOSED, unvalidated), a draft category sentence, the eight immutable and ten localisable items identified. **No mark, no palette — blocked by N12** | NI-1: GATE E0, E1, E2 passed for one locality; PLR published; the local name registered | NI-2 → NI-3: CL-2 evidence; ≥ N materially different localities; **≥ 1 independently verified impact claim; ≥ 1 published correction** | NI-6: all ten **[S-ST: §14.3]** and fifteen **[S-ST: §30.3]** pre-conditions; **N12 and N13 resolved** |
| **Communication** | The comms policy and the non-police ID card design — **both [S: Ch.31] launch blockers**; the mandatory translation set in the pilot language; LA-5 emergency text pre-positioned | PLR-1…PL-7 on paper and, if available, on the own domain; two ungated actions operating; the correction and refusal logs live | Story production; segment explanations; local and national media protocols; the claim register audited | Multi-language simultaneous publication; spokespersons by domain and region; crisis capacity pre-funded; knowledge repository |
| **Trust** | Nothing exists to be trusted. **Only the design of trustworthiness exists** | Layer 1 micro-trust begins; Layer 2 PLR and the verification channel | Layer 3 institutional transparency: quarterly boring-things publication; Layer 4 begins with entity and insurance clarity | All four layers operating; independent review in place **[V]** |
| **Participation** | No participants. The nine NP pathways are designed, not operating | NP-1, NP-4, NP-9 operating; **CI-15** non-zero | NP-2…NP-8 operating; Door 2 credentials issued | All nine; portability operating across localities (PO-4) |
| **Service** | Nothing delivered | One locality, real tasks, real outcomes, follow-up recorded | Multiple localities; outcomes including unchanged and worsened published | Multi-state; mission-balance statement published |
| **Leadership** | **[S-D: D — NOT YET PROVEN.]** Nothing selected, nothing assessed | Gate E operating; **Gate R recorded as a gap — there is no outside assessor [S-D: EF-6]** | Out-of-team assessment capability built at City level — **[S-D: §52.3 step 5, the pivot]**; RV-3 operating | Succession exercised at multiple levels; SS-4/SS-5 on all mandatory roles |
| **Economics** | `H_gov` unmeasured; `σ_max` unknown; **communication not costed anywhere (EA-E1)** | `H_gov` measured including communication hours (Rule E-168); priority-1 payment on time | Multiple localities inside `σ_max`; **City divisor measured, per environment type (Rule E-138)** | `H_gov_per_team(K)` sub-linear or mitigated; reserves; insurance in force |
| **Governance** | Reserved matters identified; **the holder is `UNRESOLVED` (E-C-15, LDR-U01 equivalent)** | Decision records (M1); the refusal log; the correction log | Claim register audited; pattern reviews; classification recorded and auditable | Independent review; the annual assembly as a working governance body; four annual tests published |
| **Safety** | The DO-NOT list; the boundary statement drafted | STOP capability present; incident reporting live; **CC-1, CC-7, CC-8 protocols rehearsed** | Certified safeguarding **[V]**; zero unresolved serious incidents | Multi-state incident and emergency communication in every operating language |
| **Data** | Classification designed; **retention `UNRESOLVED`** | Minimum-data intake operating; no identity data collected; consent separated three ways | Privacy notice in every operating language; retention schedule; rehearsed breach runbook | Full programme; DPIA where applicable **[V]**; portability with person-controlled disclosure |
| **Reputation** | **None, and none may be claimed.** CL-0 permits only statements about design and testing | A local reputation begins to form, unmeasured except by inbound contacts | RC-1 or RC-2 in each locality; **the disappearance test answerable from records** | RC-2 aligned across localities; NI ahead of nothing; **MA ahead of NI everywhere** |

**[P] Rule E-224 (A Stage May Not Be Claimed Before Its Row Is Complete.** Progression to any column requires every cell in that column, for the localities claimed. **A capability that is ahead does not carry one that is behind** — the same logic as Rule E-166 (weakest capacity constrains) and Rule E-215 (level determined by the weakest locality claimed).

---

# PART 75 — FINAL NATIONAL IDENTITY ARCHITECTURE

## 75.1 The master identity model

**[P]** Brief §225.

```
LOCAL REALITY
   A problem exists in a specific place, and the people who live there
   define what the problem is                    [immutable item 9]
        |
        v
LOCAL PARTICIPATION
   People contribute - bounded, paired, real work, no joining required
   NP-1..NP-9 ; FW-1..FW-6 ; L0 is a complete position
        |
        v
VERIFIED IMPACT
   Something actually improves - and the organisation knows which:
   resolved / reduced / unchanged / worsened / unknown
        |
        v
LOCAL TRUST
   People return.  HM-9 - second contribution within the window.
   Trust is deposited person to person and is the only layer that scales
        |
        v
LOCAL COMMUNITY
   Relationships form that would survive the organisation's withdrawal
   (Rule E-94 disappearance test)
        |
        v
REPLICABLE SYSTEM
   Others can reproduce the model: playbook, standard, conditions stated
   RT-1..RT-5 ; Rule E-211 conditions travel with the solution
        |
        v
CITY / STATE NETWORK
   Capabilities connect - a specialist arrives, a verifier reviews,
   a float moves, an escalation route opens.  CAPABILITY, NOT IDENTITY
        |
        v
NATIONAL NETWORK
   Local communities remain locally meaningful.  The centre publishes
   their records and supplies what they ask for.  Rule E-55
        |
        v
NATIONAL IDENTITY
   A shared identity emerges from shared contribution -
   EPISTEMIC, not affective:  "the same thing happens elsewhere,
   and it is checkable."   Rule E-57.  Rule E-22: never required
```

## 75.2 The master adoption model

**[P]** Brief §226.

```
SEE            a dated local result.  Not an organisation.  Not a message
   |
   v
UNDERSTAND     the eight first-contact questions answered at once (Rule E-73)
   |
   v
TRY            "report a need" or "help once" - neither requires joining
   |
   v
CONTRIBUTE     real work, bounded, paired, with a real outcome
   |
   v
EXPERIENCE IMPACT   the outcome is returned to them, dated, specific, place-based
   |
   v
RETURN         voluntarily.  No reminder.  No streak.  No guilt
   |
   v
BELONG         locally, without being told to.  Never nationally (Rule E-22)
   |
   v
DEVELOP        scope, credential, specialist standing - taken up voluntarily
   |
   v
SPECIALISE / LEAD / BUILD     three tracks, two endpoints, none superior
   |
   v
HELP THE SYSTEM HELP THE NEXT PERSON
   a playbook, a translation, a paired task, a correction, a lesson.
   IMPROVE THE PATHWAY - NEVER THE HEADCOUNT.
   No referral mechanism.  No commission.  No coercion.  No ideology.
```

**[A]** Every arrow in this model is optional, and **every box is a legitimate place to stop.** That is the structural difference from a funnel (Rule E-85), and it is why the model is drawn vertically but reads horizontally: **a person may enter at any box and leave at any box, and the organisation's obligation is identical at every one.**

## 75.3 The master reputation model, and its counterfeit

**[P]** Brief §227, restated as the governing diagram of this instrument:

```
PERMITTED                                   COUNTERFEIT

REALITY        what was actually done        ADVERTISING    purchased attention
   |                                             |
   v                                             v
EVIDENCE       records that exist            ATTENTION      reach without relationship
   |                                             |
   v                                             v
TRANSPARENCY   TS-1..TS-14 published         FOLLOWERS      a count that proves nothing
   |                                             |
   v                                             v
CORRECTION     TS-6, and it must not         FALSE REPUTATION  an expectation with no
   |           be empty (Rule E-88)          |                 evidence behind it
   v                                         v
TRUST          conferred by others,          FIRST FAILURE    one real event tests it
   |           never claimed (Rule E-90)     |
   v                                         v
REPUTATION     what people say when          COLLAPSE         the fall exceeds the rise
   |           we are not in the room                        (Rule E-4 mechanism)
   v
REPEAT PARTICIPATION   HM-9 - the only honest confirmation
```

**[A]** The single structural difference remains the one identified in Part 21: **the permitted model has an arrow from failure back into reality; the counterfeit has nowhere for failure to go.** Every rule in this instrument exists to keep that arrow open — which is why **Rule E-88, the empty-correction-log anomaly, is the most important control in v1.3-E despite being the least dramatic.**

## 75.4 The final message, tested

**[P]** Brief §252 supplies eleven statements and instructs that they **not** be adopted as doctrine without testing. Each is tested against the source and classified.

| Statement | Test against the architecture | Classification |
|---|---|---|
| "You do not have to become the same as us to participate." | **SUPPORTED.** Rule E-7 additive participation; **[S-A: A-05 guard 1]** not cultural erasure; eight immutable items and ten localisable | **[P] — supported by [S-A], [S-C: H-26]** |
| "You do not have to become a member to contribute." | **SUPPORTED.** NP-1…NP-9; Rule E-10; **[S-C: H-02]** L0–L2 are levels | **[P] — supported by [S-C: H-02]** |
| "You do not have to become a leader to matter." | **SUPPORTED.** **[S-C: §8.2]** L5 with no role is complete; **§8.4** no higher form of service; Rule E-204 no national hero | **[P] — supported by [S-C: §8.2, §8.4]** |
| "You do not have to agree with every person to belong." | **PARTIALLY SUPPORTED.** Dissent is protected **[S-A: A-16 test 3]** and criticism is preserved (Rule E-109) — **but "belong" is the wrong word: belonging is local and is not conferred by the organisation (Rule E-22)** | **[P] — with correction: "…to participate"** |
| "You do not have to trust a slogan to verify what happened." | **STRONGLY SUPPORTED — this is the whole instrument.** Rule E-8; Rule E-19; TS-1…TS-14; Rule E-90 the organisation never claims to be trusted | **[P] — supported by [S-ST: §11.3, §14.2]** |
| "You do not have to travel to the national headquarters to make a difference." | **SUPPORTED.** Rule E-55 capability not direction; immutable item 9 local problem definition; Rule E-3 national is derived | **[P] — supported by [S-C: H-26]** |
| "Your neighbourhood can matter." | **SUPPORTED — and it is the primary claim, not a secondary one.** **[S-ST: §29 item 1]**; Rule E-3 | **[A] — this is the architecture's actual proposition** |
| "Your contribution can matter." | **SUPPORTED.** ST-1…ST-8; the attribution loop; HM-6, HM-7 | **[A]** |
| "Your language can remain yours." | **SUPPORTED.** Rule E-53 no language is senior; Rule E-66 mandatory set; LA-4 fully local | **[P] — supported by [S-A: A-05 clause 8; S-C: §30]** |
| "Your local identity can remain yours." | **SUPPORTED.** R-11…R-20; Rule E-50 local by default; Rule E-7 additive | **[P]** |
| "And millions of different local contributions can still become one national network." | **CONDITIONALLY SUPPORTED — and this is the only statement that is not yet true.** It requires CL-7/CL-8 evidence, N12 and N13 resolved, and all twenty-five **[S-ST: §14.3, §30.3]** pre-conditions. **At CL-0 the honest form is: "and different local contributions could become one national network, if it works, and we are testing whether it does."** | **[P] — NOT ADOPTABLE AT CL-0. Rule E-4 and Rule E-28 require the conditional form** |

**[A]** Ten of eleven are supported and one is conditional. **[P] Rule E-225: none of the eleven is adopted as doctrine by this document.** They are tested propositions requiring approval, and the eleventh requires evidence before it may be said aloud. **A statement that is true at CL-8 and false at CL-0 must be published in its CL-0 form** — which is Rule E-4 applied to the organisation's own most attractive sentence about itself.

## 75.5 The architecture in one statement

> **[A]** Sewak Sathi's national identity is: **a small set of rules that are the same everywhere** — doctrine, safety, financial priority, verification, AI boundaries, privacy and dignity, non-alignment, evidence standards — **and a very large set of things that are local** — language, calendar, venue, service mix, role words, recognition form, partner set, dress, colour and motif, and above all the definition of the problem itself; **producing dated records of real work** that are published plainly, in the language of the place they happened, at a scale no larger than the evidence supports; **carrying no uniform, no insignia, no rank, no oath, no portrait, no national date, no hero, no ordinal, no referral reward, no emotional appeal and no trust claim**; **answerable to anyone through a complaint route that reaches outside the locality, a verification channel that answers whether a person is genuine, and a correction log that must not be empty**; **owned by whoever N12 and N13 eventually determine, which is not yet known**; **and recognisable nationally, if it ever is, not because it told India what it was, but because a lane in one city could check what a lane in another had done.**

---

# PART 76 — FINAL VERDICT

## 76.1 The verdict

> # **D — NATIONAL IDENTITY & MASS-ADOPTION SYSTEM NOT YET PROVEN**
> ### with a defined, testable path to **B — VIABLE WITH TESTING**

| Grade | Meaning | Applies? |
|---|---|---|
| **A — READY** | Operated, measured, corrected, and observed working across multiple materially different localities with a published record | **NO — and the brief itself states that a document cannot prove national adoption** |
| **B — VIABLE WITH TESTING** | Architecturally complete, economically bounded, claim-disciplined, independently checkable, and scheduled for validation | **NO — but reachable; §76.3** |
| **C — REQUIRES MAJOR REDESIGN** | The concept is wrong or the mechanisms are mutually incompatible | **NO — and saying so would be dishonest. v1.2 already contains a National Communications department, two specified communication roles with explicit prohibitions, a communication training category, a five-row communication rule table, a launch blocker requiring a comms policy, an information colour system with an explicit anti-decoration rule, and a partnership brand rule. v1.3-A added a Political Neutrality Code, a non-alignment principle, a Protection Visibility Protocol, dual custody of channels and domains, and public-representation rules. v1.3-C added a three-layer language architecture, layered identity, first-contact standards and fifteen human measurements. That is more communication governance than most national institutions possess** |
| **D — NOT YET PROVEN** | The architecture is specified, coherent, bounded and cheap — **and nothing in it has been seen by a single member of the public** | **YES** |

## 76.2 The eight requirements for B, assessed

| # | Requirement | Status today | What closes it |
|---|---|---|---|
| **1** | An approved category sentence passing the eight-question test in every operating language | **NOT SATISFIED** — fails 4 of 5 **[S-ST: §20.1]**; a draft exists but is `[P — not adopted language]` | E-15, E-13; **CI-2** measured |
| **2** | Brand ownership (**N12**) and IP ownership (**N13**) resolved | **NOT SATISFIED** — both `UNRESOLVED` **[S-A: §22]** | **The source hierarchy, not this document.** Rule E-60 blocks national brand use until then |
| **3** | A public local record and a public complaint route reaching outside the locality | **NOT SATISFIED** — "not in the current architecture" **[S-ST: §20.3]**; "no public-facing complaint channel" **[S-ST: §14.1]** | E-16 PLR-1…PL-7; **MVLS-9** |
| **4** | A published "what we are not" statement and a misclassification response protocol | **NOT SATISFIED** — proposed **[S-ST: §18.3]**, unadopted | E-15; MC-1…MC-11 |
| **5** | The two source launch blockers delivered: a comms policy and an approved non-police ID card design | **NOT SATISFIED** — both `PROPOSED` **[S: Ch.31; App. A blocker list]** | E-12, E-39 |
| **6** | One published year of accounts, one published correction, one logged political refusal | **NOT SATISFIED** — nothing published; nothing has occurred | E-19 TS-1…TS-14; Rule E-88 |
| **7** | National communication costed against `σ_max` | **NOT SATISFIED** — **no communication line exists in any prior cost model (EA-E1, §42.5)** | Rule E-168, E-169; GATE E6 |
| **8** | Any of it observed on real people | **NOT SATISFIED — and this is the requirement the other seven exist to serve** | **The single shared pilot** with PS-E1…PS-E12 evaluated and PF-E1…PF-E8 checked |

**[A] Eight requirements, zero satisfied.** The same arithmetic that returned **D** from v1.3-B, v1.3-C and v1.3-D returns **D** here — **for a sharper reason: those three instruments describe systems that have not been operated. This one describes a reputation that has not been earned, for systems that have not been operated, to an audience that has not yet been addressed.**

## 76.3 The path from D to B

**[P]** Seven steps, in order. Each is a decision or a publication, not a project.

| Step | Action | Amendment | Precondition | Evidence of completion |
|---|---|---|---|---|
| **1** | Approve the **eight immutable and ten localisable items**, and Rule E-50 local-by-default | E-09 | None | The two lists approved and published internally |
| **2** | Deliver the **two source launch blockers**: a comms policy and an approved non-police ID card design within V1…V8 | E-12, E-39 | Step 1; **[V]** legal review of the card | **[S: Ch.31]** blocker cleared |
| **3** | Build **PLR-1…PL-7 on paper** for one locality, with the mandatory translation set and pre-positioned LA-5 emergency text | E-16, E-13, E-14 | Step 1 | PS-E1, PS-E9 |
| **4** | Open the **two ungated actions** and the outward complaint route; publish the claim ladder and the "what we are not" list | E-03, E-15, E-29 | Step 3 | PS-E3; **CI-2**, **CI-15** |
| **5** | Run the **shared pilot** with CI-1…CI-15 added, and evaluate PS-E1…PS-E12 and PF-E1…PF-E8 | E-19, Part 72 | Steps 1–4 | The pilot record |
| **6** | Publish the **first correction and the first refusal**, whatever they are | E-19, Rule E-88, TS-6, TS-8 | Step 5 | **CI-9 non-zero; CI-10 non-zero** |
| **7** | Resolve **N12 and N13**, and cost communication into `H_gov` | E-11, Rule E-168 | **The source hierarchy; [V] IP counsel** | Brand licence documented; communication hours in the ledger |

**[A]** Step 6 is the pivot, and it is unusual: **the step that moves the grade is not building anything, but publishing something adverse about the organisation for the first time.** **[S-ST: §14.3 item 9]**: "institutions that have never corrected anything are either dishonest or inactive." Until a correction exists, every claim in this instrument is a description of an intention — and Rule E-28 requires intentions to be labelled as such.

## 76.4 What B would not mean

| B does not mean | Because |
|---|---|
| India has heard of the organisation | Recognition is not a requirement for B, and is not a target ever (Rule E-91) |
| The identity is validated | **§72.5 limits 1–7:** one locality, one language, one first impression, no national attention |
| The claim ladder survives pressure | At CL-1 there is no reputation to protect, so the ladder has not been tested |
| Political, religious or caste neutrality holds | **MAF-02, NRT-01…NRT-03:** tested only in one social field, with no external actor incentive |
| Communication is affordable at scale | **§40.5 of [S-D] and §65.3 here:** the pilot runs without technology and without a range of `K` |
| Contribution portability works | Requires ≥ 2 localities and third-party acceptance, which is outside the organisation's control (**MAF-26**) |
| Brand ownership is secure | **N12 and N13 must be resolved by the source hierarchy** |
| Nominal compliance is detected | **MAF-28 / NRT-20: no internal control detects it** |

## 76.5 What A would require

**[P]** Grade **A** requires all of the following, none available before scale:

1. **NI-6 and CL-8 evidenced**, with all ten **[S-ST: §14.3]** and all fifteen **[S-ST: §30.3]** pre-conditions demonstrably true.
2. **N12 and N13 resolved**, with documented brand licence terms and IP ownership.
3. **At least three materially different contexts** — urban, small town, rural — each at NI-2 with published accounts, outcomes, corrections and closures.
4. **At least one independently verified impact claim** by an external party.
5. **At least one published adverse finding against the organisation itself**, acted upon — "proof the channel has teeth" **[S-ST: §14.3 item 4]**.
6. **Language equity demonstrated**: members in every operating state able to complete onboarding, a task record, a grievance and a payment confirmation entirely in their own language **[S-ST: §30.3 item 13]**.
7. **A national attention event survived** — coverage, a political accusation, a misinformation episode or a surge — with the claim ladder held and no artefact withdrawn in embarrassment.
8. **CI-3, CI-4, CI-5 all measured across multiple localities and at or below baseline**, with the misclassification rate falling.
9. **The four institutional tests reported at least twice**, with non-zero dissent and non-zero absence counts.
10. **The v1.3-D leadership system at B or above** — because a national identity above an unproven leadership system inherits its uncertainty in full, and **[S-D]**'s own path to B runs through building out-of-team assessment capability.

**[A]** Items 1–9 are events and publications, not documents. **Item 10 is another instrument's verdict.** **No further architectural work brings A closer, and this document is complete while the organisation is not yet begun.**

## 76.6 The closing finding

**[A]** This instrument was asked one question: *how can Sewak Sathi become nationally recognisable and emotionally meaningful to people across India without requiring everyone to become a member, without manipulating identity, and without building a national brand before the local system has earned trust?*

**The answer is: by publishing, plainly and in local languages, what it actually did — and by refusing to say anything else.**

| Condition | Why decisive |
|---|---|
| **1. The record is public, ungated and unadorned** | Without it, "verifiable" is a claim and not a property. Rules E-19, E-78; PLR-1…PL-7 |
| **2. The claim never exceeds the evidence** | Without it, recognition outruns capacity and the fall exceeds the rise. Rules E-1, E-4; CL-0…CL-8 |
| **3. The correction log is never empty** | Without it, nothing distinguishes the organisation from every body that over-claims. Rule E-88 — **and this is the least enforceable control in the instrument** |
| **4. Nobody is required to join, to feel, to believe, to wear, to speak or to stay** | Without it, participation is extraction and belonging is conformity. Rules E-7, E-10, E-13, E-22, E-85, E-135, E-163 |
| **5. The whole thing costs less than the smallest unit can afford** | Without it, the architecture is complied with nominally and fails actually. Rules E-168, E-169, E-101 |

**[A]** Conditions 1, 2, 4 and 5 can be built with paper, translation and discipline by one team. **Condition 3 cannot be built at all — it can only be honoured, by people who bear the cost of honouring it, in the moment when honouring it is worst.**

**[A]** And the final finding, offered without softening because the brief requires it: **this document is 76 parts long about an organisation that has not yet spoken to a single member of the public.** That is not a criticism of the document; it is a description of the risk it exists to manage. **The most likely way this architecture fails is not that any rule in it is wrong. It is that all of it is approved, written up, translated, designed and published — and the correction log stays empty for three years, because the correction log is the one instrument whose operation depends entirely on the willingness of the people it reflects badly on to keep it.** Rule E-88 exists for exactly that reason, and it is the only control in five instruments that acts on the *absence* of a record. **If that single rule is honoured, the national identity will take care of itself. If it is not, nothing else in these seventy-six parts will be believed.**

---

# THE REQUIRED ONE-PAGE ANSWER

> ## **"How can Sewak Sathi become nationally recognisable and emotionally meaningful to people across India without requiring everyone to become a member, without manipulating identity, and without building a national brand before the local system has earned trust?"**
>
> **[A] Every answer below is `ARCHITECTURALLY SPECIFIED — EMPIRICALLY UNVALIDATED`. Nothing has been seen by a member of the public. Nothing here is a promise.**

| # | Question | Answer | Where |
|---|---|---|---|
| **1** | **Why would an ordinary Indian care about Sewak Sathi?** | Because a specific problem in their own lane got fixed, on a date, and they can check it. **Not because of anything the organisation says about itself.** India's problems and India's capacity are both hyper-local; the people who could fix a problem usually live within two kilometres | Part 1 §1.3; Part 6; PLR-3 |
| **2** | **Why would they participate without becoming a member?** | Because nine things are available with no membership, no verification, no fee and no data beyond the minimum — report a need, request help, give expertise once, help once, donate, support a project, buy a service, learn, and observe-and-check. **And because L0 is a complete position, not a stage of failure** | Part 4 §4.3; Rules E-10, E-11, E-85 |
| **3** | **Why would they return?** | Because the first experience was worth repeating: real work, a bounded time that ended when it said, a visible result, a personal thank-you, and an explicit statement that nothing further is expected. **Return is measured (HM-9) and is never manufactured — no reminder, no streak, no guilt, no campaign** | Part 18; Rule E-21 |
| **4** | **Why would they trust it?** | **It should not ask to be trusted; it should be checkable.** Published accounts with worker compensation shown separately, published outcomes including unchanged and worsened, a published correction log, a published refusal log, a verification channel, and a complaint route that reaches outside the locality. **And the organisation never claims to be trusted — that word is for other people to use** | Part 20; Rule E-90 |
| **5** | **What makes it emotionally meaningful?** | Conditions, never messages: a visible local result; two ungated actions; a real task with a real outcome; **the outcome returned to the person who helped**; others visibly doing the same; local ownership of the problem. **Ten emotional registers are prohibited — guilt, fear, shame, indebtedness, superiority, outrage, dependency, envy, baseless urgency, and admiration for a person rather than for work** | Part 5; Rules E-9, E-21 |
| **6** | **How can it feel Indian without becoming political?** | **Presence, not claim.** It is of India by being in Indian neighbourhoods, in Indian languages, on Indian calendars, solving Indian-scale local problems, under Indian law — never by adjectives, symbols, flags, anthems, colours or possessive nouns. Nine neutrality prohibitions already bind; four more are added for expression: adjacency, timing, vocabulary and silence | Part 7; Rules E-6, E-29…E-33 |
| **7** | **How can it respect religious diversity?** | Service without distinction; institutional non-alignment with no theological position expressed; cultural respect without alignment; faith-based partners activity-scoped, separately branded, never exclusive; **no religious ritual as an organisational requirement**; *seva* descriptive never prescriptive; and **no composition figure produced even to rebut an accusation — the answer is always behavioural** | Part 8; Rules E-36…E-42 |
| **8** | **How can it respect regional and linguistic diversity?** | Eight immutable items and ten localisable ones, with **everything not immutable local by default**; no language senior; national communication simultaneous in every operating language **or not published at all**; a terminology register per language and per state; and **structural variables only, never cultural characterisations** | Part 10, Part 14; Rules E-50, E-53, E-66, E-67 |
| **9** | **How can it reach every type of citizen without pretending everyone should join?** | Twenty-five legitimate relationships, of which membership is one. **Twenty-one require no membership.** Three — customer, donor, media/research — are deliberately outside the participation spectrum so that progression is never implied. **And the two the architecture currently serves worst are the observer and the critic, who are also the two that determine whether the other twenty-three believe anything** | Part 3; Rules E-10, E-12, E-19 |
| **10** | **What is the first experience Sewak Sathi should give a new person?** | A **result**, not an organisation — a cleaned lane with a small dated board. Then one page in their language with the category sentence, the "what we are not" list, three things this team did nearby with dates, and two buttons: **report a need** and **help once**. No form, no app, no account, no membership language, no donation appeal, no photograph. **And on paper, identically** | Part 16, Part 17; Rules E-78, E-79 |
| **11** | **What makes Sewak Sathi different from existing organisations?** | **Four claims are defensible and three are prohibited.** Defensible: verified help that actually arrives with evidence; you can see where the money went; your contribution is recorded and portable; neighbourhood-scale with national capability. **Prohibited: cheaper or faster than an agency; pays better than the market; more trusted than existing community bodies — the last is both false and insulting.** The posture toward existing bodies is **complement and escalate, never rival** | Part 21 §21.4, §21.6; Rule E-96 |
| **12** | **What happens if growth becomes faster than capacity?** | Permitted growth is bounded by the **smallest** of eight capacities — leadership, verification, economic, service, governance, communication, safety, data — and the constraining capacity is **named in the authorisation record**. A surge is managed by **publishing the limit**: the capacity, the queue, the criteria, the window and the alternatives. **Celebration is suspended during a surge** | Part 42, Part 43; Rules E-166, E-170, E-171 |
| **13** | **What prevents national identity from becoming personality cult?** | Nine communication-layer controls: no individual images, authority cited to a document version not a person, a founder preference recorded as a declared interest, credit for work never for quality, **no artefact bearing a person's name**, no unrecorded decision channel, no personal account as an organisational channel, no personal fundraising, and **no person as the only source of a fact** — plus the substitution test and four annual tests where **a zero dissent count is the warning** | Part 39; Rules E-149…E-158 |
| **14** | **What prevents national growth from becoming MLM?** | **No reward for introduction, ever — monetary or otherwise.** No referral code, invite link, share incentive, ambassador scheme or member-get-member mechanic. No participation-linked term in any compensation, recognition or progression formula. A prohibited-vocabulary register per language. And one test that catches the whole class: **does this artefact's success depend on the reader bringing another person?** | Part 40; Rules E-24, E-118, E-135, E-159, E-162 |
| **15** | **What prevents national branding from becoming stronger than reality?** | **The claim ladder, published.** CL-0…CL-8 tie every claim to a demonstrated stage; six claim classes and five evidence labels make an over-claim detectable from the artefact alone; the register is audited every period and **a claim found above its class is withdrawn and the withdrawal is published**; identity maturity must lag adoption maturity; and the default expansion outcome is **IMPROVE, not EXPAND** | Part 31, Part 59, Part 61; Rules E-4, E-128, E-182, E-219 |

## The single biggest unresolved weakness in Sewak Sathi's national identity and mass-adoption architecture

> ### **[A] The entire architecture depends on the organisation publishing what went wrong — and no instrument in v1.2 or v1.3-A/B/C/D/E compels it, detects its absence, or penalises its omission.**
>
> Every other value in this five-instrument set has a control. Money has the waterfall, segregation of duties and audit. Safety has the DO-NOT list and stop-work authority. Data has classification, minimisation and sealed categories. Leadership has gates, independent assessment and appeals. Participation has refusal rights and dignity rules. AI has Article 12. Neutrality has nine prohibitions and a refusal log.
>
> **Publication of failure has nothing.** v1.2 requires failures in *internal* reports. The stress test proposes extending that to public reporting and calls it "the single most differentiating trust act available to this organisation, and almost no Indian institution does it." It proposes that "a published correction" is a precondition of national trust, on the ground that "institutions that have never corrected anything are either dishonest or inactive." **Every one of those is a proposal. None is a gate. None is a blocker. None appears in the launch checklist, the control budget, the human measurements or the leadership gates.**
>
> And the incentive runs the wrong way. The people who decide whether to publish a failure are the people the failure damages. Under-claiming is prescribed as *strategy* — and a strategy is what an organisation does when it is convenient. **There is no mechanism that makes radical plainness inconvenient to omit.** The predictable result is a well-designed transparency architecture that publishes accounts, outcomes and successes on schedule, and whose correction log stays empty for years: not because nothing went wrong, but because nothing compelled the entry.
>
> The minimum correction proposed here is **Rule E-88** — an empty correction log across a reporting period is itself published as an anomaly and referred to Audit, on the same logic v1.3-A applies to the dissent test, where "a zero count is a warning sign, not a clean bill of health." **It is the only control in five instruments that operates on the absence of a record rather than on its content.**
>
> And it may not work. **[I]** A rule requiring an organisation to publish its own failures is the rule most likely to be quietly reinterpreted as applying only to failures that were already public — because a failure nobody knows about is, from inside, not yet a failure. **The weakness is not that the control is badly designed. It is that the control's operation depends entirely on the willingness of the people it reflects badly on to keep it, which is a property of persons and not of architecture, and which no document can supply.**

---

# ANNEXURE A — SOURCE CONSISTENCY MATRIX

**[P]** Chain: **v1.2 → Stress Test → A → B → C → D → E.** **Legend: `P` preserved verbatim · `E` extended (added to, not altered) · `C` carried forward unresolved · `T` tested and found defective or incomplete · `N` not touched.**

| Source instrument | Treatment | v1.3-E location | Note |
|---|---|---|---|
| **[S: Ch.1]** Visual Legend and Information Colour System — nine colours; "colour is used as an information system, not decoration"; "no mandatory rule is communicated by icon alone" | **P/E** | Part 13 §13.1, §13.2 | **The decisive find of this instrument.** Red is already semantically committed to safety/protection/risk/prohibitions; green to social service. Rule E-61 reserves all nine from identity use; Rule E-62 extends the icon rule to all colour |
| **[S: Ch.2]** Core doctrine and operating formula; non-discrimination in service | **P** | Part 2 §2.1; Part 9; immutable item 1 | Verbatim; never restated as a slogan |
| **[S: Ch.3]** Four pillars | **N** | — | Out of scope |
| **[S: Ch.4]** Master chain KRYTOS → SEWAK SATHI SANSTHA → NATIONAL → STATE → CITY → MOHALLA → VERIFIED MEMBERS; authority table "Property, brand, strategy and ultimate founder-level control" | **P/E** | Part 12 §12.1, §12.2 | Brand authority preserved; **Rules E-58, E-59 govern salience and non-concealment** |
| **[S: Ch.5]** National Communications department; National Audit and Ethics; §4.4 national projects and partnerships — "no team should imply that a partner endorses the entire organisation unless the written agreement says so" | **P/E** | Part 25; Part 52 | BR-3, BR-4, Rule E-112 implement the partnership rule |
| **[S: Ch.6]** State functions; states may adapt within standards but not alter constitutional principles, compensation percentages, protection boundaries, data policies or legal structures | **P** | Part 10; Part 33 | Immutable list foundation |
| **[S: Ch.7]** City functions; escalation lane 6 | **P** | Part 26; Part 56 | — |
| **[S: Ch.8]** Mohalla ten-step loop; step 2 intake; step 5 priority assessment on need criteria only | **P** | Part 3; Part 17; Rule E-118 | Priority never uses the requester's record, membership or money |
| **[S: Ch.9]** Eleven role families with purpose, authority, limits, metrics, training, reporting and succession; "Cannot do" boundaries | **P/E** | Part 52; Annexure F | Communication roles inherit the same discipline |
| **[S: Ch.12]** Twelve-step member lifecycle; ten training categories including **Communication: "verified information, public statements and misinformation correction"**; safeguarding; "application — begins verification; not entitlement to join" | **P/T** | Part 17 §17.2; Part 28 | The Communication training category exists; **the entry-point design is tested and found conversion-fatal [S-ST: §20.3]** and is not altered, only sequenced differently at first contact |
| **[S: Ch.15]** Service; outcome verification; "do not count planned activities as completed impact"; failures and partial outcomes in reports; dignity in food service; "avoid unnecessary beneficiary documents"; "no exposure of minors" | **P/E** | Part 31 §31.4; Part 38 | Rule E-131 extends the follow-up discipline to publication |
| **[S: Ch.16]** Protection; DO-NOT list | **P** | Part 26; Part 47 | Rule E-203 vocabulary control added |
| **[S: Ch.17]** AI Business; ventures; QA; closure rules | **P/E** | Part 27 | Rule E-119a four public firewall rules |
| **[S: Ch.18]** Waterfall priority order; four distinct finance hands | **P** | Part 22; Part 66; **INV-equivalent** | Never altered; a reserved matter |
| **[S: Ch.19]** Payment sheet with formula version; step 13 | **P** | Part 27; TS-3 | — |
| **[S: Ch.20]** Social-impact fund; may not support political or religious activity | **P** | Part 8; TS-4 | — |
| **[S: Ch.21]** AI doctrine | **P** | Part 31 §31.6; Rule E-68 | Art.12 applied to translation |
| **[S: Ch.22]** Data and software fields; RBAC profiles; contribution-relevant records | **P/E** | Part 53; Part 54 | Portability built on existing fields |
| **[S: Ch.23]** RBAC matrix; Auditor "review only; not operational commander" | **P** | Part 22; Part 52 | — |
| **[S: Ch.24]** Six dashboards × five cadences; **the five-row communication-type rule table** — internal, public/social, emergency/incident, press/public statements, misinformation | **P/E** | Part 22 §22.3; Part 23 §23.1 | **The single most important source table for this instrument. Preserved verbatim; cadences unchanged; public content added per cadence** |
| **[S: Ch.25]** Performance; eight anti-gaming controls; "raw revenue, follower count, social-media views, volunteer count, application count or raw activity count cannot determine leadership" | **P/E** | Part 24 §24.2 | Extended from determining *leadership* to determining *scale, funding and legitimacy claims* (Rule E-2) |
| **[S: Ch.27]** Audit | **P** | Part 52; TS-series | — |
| **[S: Ch.28]** Risk register; conflict of interest; "mission drift", "reputational/safeguarding failure" | **P** | Part 70; Part 71 | — |
| **[S: Ch.29]** Partnership flow; MOU fields — scope, responsibilities, data, finance, safeguarding, brand use, termination | **P/E** | Part 25 §25.2 | PT-A…PT-F stages added around the existing fields |
| **[S: Ch.30]** Roadmap; Phase 5 national expansion | **P/E** | Part 32; Part 58 | GATE E0…E7 proposed as additions to, not replacements for, the roadmap |
| **[S: Ch.31]** Launch checklist — **"Communication / branding: ID card, public statement rules, misinformation correction → approved card mock-up and comms policy → Blocker"** | **P** | Part 13 §13.5; Part 52; Part 76 | **Two launch blockers, both undelivered. Steps 2 and 5 of the path to B** |
| **[S: Ch.33]** Decision register — public name `PROPOSED`; QR ID card `PROPOSED`; partnership signatory authority `Not final`; entity structure, CEO-vs-Council, worker classification, data retention `UNRESOLVED` | **C** | Part 62; Annexure B, K | **Nothing resolved** |
| **[S: App. A §1.1]** Economic blueprint never attached | **C** | Part 66 | All rupee questions open |
| **[S: App. A §8.x]** **Editor** role — authority to "reject or return content that is inaccurate, unsafe, defamatory, privacy-invasive or off-brand"; cannot invent claims, manipulate images dishonestly or suppress material facts; outputs include **correction logs**; metrics include correction rate, privacy compliance, readability, evidence clarity. **Social Media Manager** — "communicate verified work and opportunities publicly without exaggeration or privacy violations"; cannot publish unverified claims, expose beneficiaries without consent, comment on legal/safety incidents without approval, use intimidation; succession — **"channel access must be revocable; backup admin appointed with two-person recovery process"** | **P/E** | Part 37; Part 38; Part 52; Part 53 | **Rule E-145 adds the attribution grammar to the Editor's rejection grounds; Rule E-187 adds independence from the subject. The succession sentence is the source of Rule E-188** |
| **[S: App. A]** Venture categories — Design: "branding, posters, packaging, social creatives — IP ownership and content rights must be clear" | **P** | Part 12; Part 62 N-E-18 | — |
| **[S: App. E]** Approval matrix by amount / risk / data / **brand impact** | **P/E** | Part 52 §52.1 | Brand impact is already an approval dimension |
| **[S: App. F]** Evidence standards | **P** | Part 31 §31.4; Part 38 | — |
| **[S-ST: §10.2, §10.3]** Core emotional proposition; seven prohibited emotions | **P/E** | Part 5 | Extended to ten registers (Rule E-9); the proposition remains `[P]` and is tested across ten contexts |
| **[S-ST: §11.1–§11.3]** Mission > Person; seven instruments; identity from facts not adjectives | **P** | Part 6; Part 39 | Rule E-27 facts not adjectives; Rule E-26 claim register |
| **[S-ST: §12.1]** The localisation contract — eight immutable, ten localisable | **P** | Part 10 §10.1; Part 33 | Reproduced; **"one core mission, many local expressions"** |
| **[S-ST: §12.2]** How it feels native in different Indias | **P** | Part 34 | **Cited with its own marking preserved: illustrative generalisations requiring local validation, not claims about any community** |
| **[S-ST: §12.3]** Connecting local to national — one record verifiable nationally; two-way flow; annual working assembly; symbols empty of rank | **P/E** | Part 11 §11.3; Part 54; Part 55 | Rule E-56 makes the assembly a governance body |
| **[S-ST: §13.1–§13.4]** Language strategy; three layers; the Hindi/English trap; cost | **P/E** | Part 14 | Extended to five registers with a mandatory set and a machine-translation control chain |
| **[S-ST: §14.1–§14.3]** Four stranger questions; four trust layers; ten national-trust pre-conditions | **P/E** | Part 20 | **The gap column is preserved verbatim — it is the diagnosis of this instrument** |
| **[S-ST: §15.1–§15.4]** Culture architecture; observable behaviours; tripwires; how culture is actually transmitted | **P** | Part 35 | Rule E-140 consequence not statement |
| **[S-ST: §16.1]** Prohibited cult mechanisms | **P** | Part 39 | — |
| **[S-ST: §17.1–§17.3]** Business/service tension; mission balance statement | **P** | Part 27; Rule E-185 | — |
| **[S-ST: §18.1–§18.3]** Eleven misclassifications; six correction instruments | **P/E** | Part 16 §16.3, §16.4 | **MC-1…MC-11 given detectors and first responses** |
| **[S-ST: §19.1–§19.3]** Competitive set; four defensible and three prohibited claims; complement and escalate | **P** | Part 21 §21.4, §21.6; Rule E-96 | — |
| **[S-ST: §20.1–§20.3]** Ten-second test fails 4 of 5; a simpler explanation `[P — draft, not adopted language]`; first five minutes; "requires a public local page — not in the current architecture" | **P/E** | Part 16, Part 17 | **PLR-1…PL-7 is the missing page. The draft sentence is reproduced with its status marker intact and is NOT adopted** |
| **[S-ST: §21.1–§21.3]** First real win; the Paired First Task; **HM-9 second contribution within 30 days chosen over conversion** | **P** | Part 18; Part 19 | FW-1…FW-6 |
| **[S-ST: §22.1–§22.4]** The national growth loop; the "I know someone who helped me" effect; bottlenecks; metrics | **P/E** | Part 32 §32.3 | Word of mouth treated as an output, not a channel |
| **[S-ST: §23.1, §23.2]** Stage model; twenty functions | **P** | Part 59; Part 74 | Mapped to NI-0…NI-6 |
| **[S-ST: §29]** Why India — five factual, non-manipulative propositions | **P** | Part 6 §6.1 | External facts retain their **[X]** marking |
| **[S-ST: §30.3]** Fifteen pre-conditions for national expansion | **P** | Part 58 GATE E7; Part 76 §76.5 | Adopted as gates, not aspirations |
| **[S-ST: §30.5]** The four things that produce voluntary choice | **P** | Part 75 §75.5; Part 76 §76.6 | — |
| **[S-ST: F-02, F-05, F-08, F-09, F-13, F-14, F-15, F-17, F-21, F-27, F-28, F-31, F-32, F-33, F-34, F-36]** | **T** | Throughout | Each given a minimum correction |
| **[S-ST: M14, M17, R5]** | **P/C** | Part 27; Part 14; Part 62 N-E-23 | **R5 left open** |
| **[S-A: A-01 N1…N9]** Political Neutrality Code | **P/E** | Part 7 | Extended from conduct to expression: PN-1…PN-4 |
| **[S-A: A-02]** Member political activity; tier restrictions; political-declaration records as C4 | **P** | Part 7; Part 22 | — |
| **[S-A: A-03 E1…E14]** Election-period protocol; emergency exception E9 | **P** | Part 7 §7.2; Rule E-30 | **Namespace disambiguated: v1.3-E amendments are `E-nn` hyphenated and zero-padded** |
| **[S-A: A-04]** Civic/partisan boundary; refusal script; written-reply template; approach register with published annual count; support duty | **P** | Part 7 §7.2; Part 26 §26.2; TS-8; CI-10 | Rule E-165 makes the refusal script a published member-facing artefact |
| **[S-A: A-05]** Equal Treatment & Non-Alignment Principle, eight clauses and four guards | **P/E** | Part 8, Part 9, Part 10 | **Clause 8 names language architecture as out of scope — v1.3-E Part 14 fills that named gap** |
| **[S-A: A-06 V1…V8]** Protection Visibility Protocol | **P** | Part 13 §13.4; Part 55 | **V8's four permitted surfaces are adopted as exhaustive (Rule E-65). V7 PPE-never-identity preserved** |
| **[S-A: A-08]** Protection DO-NOT list | **P** | Part 26; Part 47 | Reserved matter; binds at every level |
| **[S-A: A-09]** Incident reporting | **P** | Part 23 CC-1; TS-5 | — |
| **[S-A: A-10]** Insurance | **C** | Part 20 §20.4; Part 66 EA-E9 | `UNRESOLVED` **[V]** |
| **[S-A: A-13, A-14]** Mission lock; reserved matters including **name and brand**; apex Deputy; Interim Authority Order; **dual custody of "domain, payment gateway, communication channels, social accounts and statutory portals"**; §13.8 annual unannounced 72-hour continuity test | **P/E** | Part 12; Part 52 §52.2; Part 53 §53.4 | **Rule E-188 is A-14 §13.4 applied literally to communication assets** |
| **[S-A: A-15 M1…M7]** Memory instruments | **P** | Part 57; TS-6; Rule E-157 | M5 "did it work" column is the follow-up instrument for every correction |
| **[S-A: A-16]** Seven founder conditions; four annual tests; **§15.4 public representation rules** | **P/E** | Part 39 §39.3; Part 55; Part 68 | **"Many authorised spokespersons by domain and region" is the source of Rules E-104, E-105 and CI-13** |
| **[S-A: A-17…A-20]** Classification C1–C4; necessity test; access separation; sealed categories with two-person rule; prohibited uses; subject rights; P2 retention; P3 notice in English or any Eighth Schedule language; P5 breach response; SOP-22 | **P** | Part 22; Part 31; Part 54 | Retention `UNRESOLVED`; **[X]** DPDP notification timelines cited with **[V]** |
| **[S-A: A-21, A-22]** AI | **P** | Part 31 §31.6 | — |
| **[S-A: A-23 N19]** Council charter | **C** | Part 62 N-E-25 | `PROPOSED`; not created |
| **[S-A: §22 N12, N13, I6, V8]** Brand ownership; IP ownership; "must be settled before many parties rely on the brand"; IP counsel | **C** | Part 12 §12.4; Part 62; Part 63 W4 | **`UNRESOLVED`. Rule E-60 blocks national brand use. The largest legal dependency in this instrument** |
| **[S-B: §17.2]** `P_max` | **P** | Part 42 | — |
| **[S-B: §24, §24.2, §24.5]** `C_lead`; success tax; leader supply as a stock problem | **P** | Part 42; Part 66 | No figure asserted |
| **[S-B: §25, §26]** `H_gov` 8–40 h/team/month; `σ_max`; automate or retire; City divisor; `K_min`; B-21 shared services | **P/E** | Part 42 §42.5; Part 65; Part 66 | **Rule E-168 records communication as a cost gap in v1.3-B's model — a finding, not a criticism** |
| **[S-B: §30 Stage 6]** Replication evidence | **P** | Part 33 RT-2 | — |
| **[S-B: §39 NM-4, NM-11]** Prohibited data uses | **P** | Part 54; Rule E-199 | — |
| **[S-B: §40 B-P-01…B-P-14]** One pilot, no technology | **P/E** | Part 72 | **CI-1…CI-15 added to the same pilot. No second pilot (Rule E-222)** |
| **[S-B: B-01, B-05, B-07, B-09]** Mission balance; accruals; venture gating; paid/voluntary boundary published | **P** | Part 27; TS-2 | — |
| **[S-B: HC-19]** Translation as a hidden cost | **P** | Part 14 §14.5; Part 66 EA-E2 | — |
| **[S-C: H-02]** Nine-level participation spectrum | **P** | Part 4 §4.1 | Rule E-14 low-level participation is a complete outcome |
| **[S-C: H-03]** Never recruit at the moment of vulnerability | **P/E** | Part 3; Rule E-13; §38.3; PF-E3 | **Strengthened: no beneficiary-to-participant pathway exists at all** |
| **[S-C: H-04, H-05]** First ten seconds; first five minutes | **P/E** | Parts 16, 17 | **Extended to eight questions and to the national scale; PLR-1…PL-7 supplied** |
| **[S-C: H-06]** Paired first task | **P** | Part 18 FW-3 | — |
| **[S-C: H-07, §8.2]** No forced progression; six endpoints; L5 votes nothing, manages nobody | **P** | Part 4; Rule E-85; Rule E-11 | — |
| **[S-C: H-08, §23.1–§23.3]** Six recognition instruments; contribution record; portable credential; performance scoped to teams and cohorts; "a person is never scored"; narrative non-ordinal | **P** | Part 55; Part 22; Rule E-200 | — |
| **[S-C: H-09, H-10]** Contribution record fields; portable credentials | **P/E** | Part 54 | **PO-1…PO-5 portability across localities is v1.3-E's addition** |
| **[S-C: H-11, §47]** Specialist ladder S1…S6; twelve domains with hard limits; "a path with no economic expression is a hobby"; Elder/Mentor excluded from command and scoring | **P/E** | Part 56 | E-205…E-210; **E-210 the elite-disconnection test is new** |
| **[S-C: H-13]** Rituals under six tests | **P** | Part 36 | Most rituals refused |
| **[S-C: H-14, §17.4]** Story framework; **attribution rules — the beneficiary is the subject of the outcome sentence, the contributor of the action sentence; never "we gave them"** | **P/E** | Part 37 ST-1…ST-8; Rule E-145 | **Cost and Next added as story elements** |
| **[S-C: H-15, H-16]** Attribution and follow-up loop; community experience charter | **P** | Part 5 stage 4; Part 18 | — |
| **[S-C: H-17, H-18]** Seven refusal rights; paused and alumni status | **P/E** | Part 41; Rule E-163, E-165 | **Refusal scripts published as member-facing artefacts in every operating language** |
| **[S-C: H-19, H-20, H-21, H-22]** Anti-cult; psychological safety; anti-MLM compensation firewall; beneficiary/recruitment separation | **P/E** | Parts 38, 39, 40 | **Extended from compensation to vocabulary, imagery and referral mechanics** |
| **[S-C: H-23, H-24]** Flexible modes; remote participation | **P** | Part 15; Part 56 | Remote attribution measured specifically |
| **[S-C: H-25, §30]** Language architecture — three layers; no language senior; terminology registered; preserving the meaning of *seva*; translate L1 fully, L2 by need, leave L3 local | **P/E** | Part 14 | **Extended to five registers, a mandatory four-item set, and a machine-translation control chain** |
| **[S-C: H-26, §31]** Layered identity — five rules; six-layer sentence test; two-way flow; "the national layer supplies capability, not identity"; identity produced by observable events | **P/E** | Part 11 | **Rule E-55 capability not direction; Rule E-57 epistemic before affective** |
| **[S-C: H-27]** Youth and elder participation rules | **P** | Part 3; Part 28 | — |
| **[S-C: §25.3, §44, §45]** Honest credential scope; recognition instruments; local hero and four charismatic-leader guards | **P** | Part 21; Part 55 | — |
| **[S-C: §57, §58 HM-1…HM-15]** Human pilot; fifteen human measurements | **P/E** | Part 72; Part 73 | **CI-1…CI-15 duplicate none of them; the non-duplication check is stated at §73.1** |
| **[S-C: CR-1…CR-4]** Record may never determine dignity, ordinary community access, worth, or eligibility outside the organisation | **P** | Part 54 §54.3; Rule E-199 | — |
| **[S-D]** entire instrument — leadership, succession, performance, gates, MVLS, invariants, 135 rules, 40 amendments | **P/E** | Throughout | **The v1.3-D verdict is carried visibly: `D — NOT YET PROVEN`. Rule E-224 and Part 76 §76.5 item 10 make national identity dependent on it** |
| **[S-D: Rule D-43 XG-1…XG-8]** Expansion gate | **P** | Part 32 §32.2; Part 58 Rule E-214 | **Adopted without modification; the three gate sets are conjunctive** |
| **[S-D: Rule D-108, D-116, D-118, D-126, D-128, D-130, D-131, D-132]** | **P** | Parts 22, 40, 42, 51, 72 | Small-cell suppression; opportunity-allocation recording; no participation-linked compensation; unpaid-work deficit; simplification obligation; no second pilot; untestable is recorded; pilot scope statement |
| **[S-D: CU-1…CU-10, VG-1…VG-6, PC-1…PC-8, PR-1…PR-6]** | **P/E** | Parts 7, 8, 26, 36, 39 | Cult, vigilante, political and public-representation controls carried into the communication layer |
| **[S-D: LM-1…LM-15; MAT-0…MAT-5]** | **P** | Part 59; Part 73 | **CI-1…CI-15 duplicate none; NI-0…NI-6 use the same "determined by operation, not documentation" discipline** |

---

# ANNEXURE B — NATIONAL IDENTITY DECISION REGISTER

**[P]** Consolidated index. Full content at **Part 62**.

| Series | Count | Content | Location |
|---|---|---|---|
| **N-E-01 … N-E-27** | 27 | National identity decisions: **six `PROPOSED` and decidable now; one `NOT ADOPTED`; one `OPEN`; one settled by source; eighteen depending on or carrying forward an `UNRESOLVED` source item** | Part 62 |
| **E-01 … E-46** | 46 | Amendments, twenty fields each, separately mergeable | Part 63; Annexure J |
| **Rules E-1 … E-225** | 225 | Operating rules issued inline across Parts 1–76 | Throughout |
| **Carried `UNRESOLVED` source items** | 12 | Public name; brand ownership N12; IP ownership N13; CEO-vs-Council; entity structure; non-police ID card design; composition monitoring N5; data retention; leaderboard publicity R5; Council charter N19; worker classification and leader multiplier; insurance | Rule 2 table; Part 62; Annexure K |

**[A]** **v1.3-E resolves none of them.** The two that block the most are **N12 (brand ownership)** and **N13 (IP ownership)** — because Rule E-60 makes national brand use contingent on both, and **[S-A: I6]** requires them settled **before many parties rely on the brand**.

---

# ANNEXURE C — PROFESSIONAL VALIDATION REGISTER

**[P]** Every **[V]** in this document. **None may be adopted before the corresponding validation is obtained.**

| ID | Subject | Why required | Discipline | Blocking? |
|---|---|---|---|---|
| **LV-E-1** | Entity structure, objects clause and lawful public description | Determines what may be said about status, and 12A / 80G / FCRA applicability | Corporate and tax law | **Yes — N-E-24** |
| **LV-E-2** | 12A political-activity condition and its interaction with N1…N9 | **[X]** exemption is conditional on applying at least 85% of income to charitable purposes and on no political activity or support to any party or candidate, with cancellation risk | Tax law | **Yes — Part 7** |
| **LV-E-3** | FCRA eligibility, timing and account requirements if any foreign contribution is received | **[X]** generally requires a track record and a dedicated account | Regulatory law | Conditional — Part 25, Part 66 |
| **LV-E-4** | Brand ownership, licensing terms, use conditions and post-exit restrictions | **N12 `UNRESOLVED`; teams hold no documented right to the name** | IP counsel **[S-A: V8]** | **Yes — N-E-17, Rule E-60** |
| **LV-E-5** | IP ownership of architecture, SOPs, curricula, software, data models and brand assets | **N13 `UNRESOLVED`; the operating system could be withdrawn by a licensor** | IP counsel | **Yes — N-E-18** |
| **LV-E-6** | Trade-mark availability, registration and conflict for the public name | **[S: Ch.33]** "validate name availability and registration" | IP counsel | **Yes — before any public use at scale** |
| **LV-E-7** | Use of any national symbol, flag, emblem or map outline | Regulated; Rule E-6 prohibits but a design may still propose | Constitutional and IP law | **Yes — Part 13** |
| **LV-E-8** | Per-state political association of any colour, symbol, date, motif or term | **[S-C: H-26 field 11]** requires **[V]** for any symbol, date or colour with political association per state | Political and cultural risk, per jurisdiction | **Yes — Part 13, Part 14** |
| **LV-E-9** | Non-police ID card design | **[S: Ch.31]** blocker; **[S-A: A-06 V3]**; resemblance to any official credential is a legal exposure | Legal and design | **Yes — N-E-02** |
| **LV-E-10** | QR element on the card — what it resolves to and who may scan it | **[S-A: A-17 §16.4; A-20]** use restrictions on the approved QR concept | Data-protection law | **Yes — Part 13 §13.5** |
| **LV-E-11** | LA-1 texts in every operating language | Rights, duties, consent and liability must mean the same thing in each | Legal, per language | **Yes — Rule E-66, E-68** |
| **LV-E-12** | Privacy notice, retention schedule and erasure route | **[S-A: A-17 P2, P3]**; retention `UNRESOLVED` | Data-protection law | **Yes — Part 22, Part 53** |
| **LV-E-13** | Data-breach notification obligations and timelines | **[X]** DPDP Act 2023: notify the Board without delay, detailed report within 72 hours, notify affected data principals, no materiality threshold; CERT-In separately requires 6-hour incident reporting | Data-protection and cyber law | **Yes — CC-3** |
| **LV-E-14** | Significant Data Fiduciary status and any DPIA or independent data-auditor obligation | Depends on scale and entity structure | Data-protection law | Conditional — Part 53 |
| **LV-E-15** | Aggregate pattern reporting — routing, recognition, function distribution | What may lawfully be collected, inferred and reported; equality-law exposure | Data-protection and equality law | **Yes — Part 9, Part 51** |
| **LV-E-16** | Composition monitoring in any form | **N5 `UNRESOLVED — deliberately`**: "exclusion patterns invisible or an identity database is created" | Privacy, equality and employment law | **Yes — N-E-22, Rule E-48** |
| **LV-E-17** | Minor participation, guardian consent, two-adult rule and safeguarding obligations | Jurisdiction-specific | Safeguarding and education law | **Yes — Part 28** |
| **LV-E-18** | Images and consent — publication rights, withdrawal, and any consent involving a minor or a vulnerable adult | Media, privacy and safeguarding law | Legal | **Yes — Part 38** |
| **LV-E-19** | BNSS 2023 ss.31, 40, 43 and state variations — assistance duties, private arrest, use of force | Determines the lawful boundary of any intervention | Criminal law, per jurisdiction | **Yes — Part 26, CC-7** |
| **LV-E-20** | Insurance for members, third parties, public liability and media/defamation exposure | **[S-A: A-10]**; a precondition of national trust | Insurance | **Yes — Part 20 §20.4** |
| **LV-E-21** | Paid placement of factual information; paid-news regulation | Jurisdiction-specific | Media and electoral law | **Yes — Rule E-123** |
| **LV-E-22** | Defamation, contempt and the limits of public correction | A correction can itself create exposure | Media law | **Yes — Part 23, Part 47** |
| **LV-E-23** | Partnership agreements, co-branding, data sharing and termination | **[S: Ch.29]**; **[S: Ch.33]** signatory authority `Not final` | Commercial law | **Yes — Part 25** |
| **LV-E-24** | Consumer protection and service warranties for venture work | Door 3 public statements | Consumer law | Conditional — Part 27 |
| **LV-E-25** | AI-generated content disclosure obligations | Emerging; Rule E-133 adopts disclosure regardless | Technology and advertising law | Conditional — Part 31 §31.6 |
| **LV-E-26** | Accessibility standards applicable to public digital artefacts | Rule E-71 requires implementation before any claim | Accessibility standards and law | **Yes — Part 15** |
| **LV-E-27** | Area-specific legal and land regimes in tribal, hill, coastal and Northeast contexts | **[S-ST: §12.2]** notes state-level legal review is mandatory | Legal, per area | **Yes — Part 34, Rule E-52** |
| **LV-E-28** | Research data sharing and publication agreements | Aggregate, de-identified, consent-scoped | Data-protection and research ethics | Conditional — Part 3 position 23 |
| **LV-E-29** | Electoral-period conduct and the E1…E14 protocol | Jurisdiction-specific duties | Electoral law | **Yes — Part 26 §26.2** |
| **LV-E-30** | Cultural and linguistic review of the category sentence, terminology register and any symbol | Meaning, register and association cannot be assessed by the architect | Cultural, linguistic and communications | **Yes — N-E-01, N-E-21** |

---

# ANNEXURE D — NATIONAL IDENTITY FAILURE-MODE REGISTER

**[P]** Consolidated index to the complete adversarial catalogue.

| Series | Count | Content | Location |
|---|---|---|---|
| **MAF-01 … MAF-28** | 28 | Mass-adoption failure modes with severity, likelihood, early warning, impact, prevention, detection, recovery, owner, residual risk and validation | Part 70 |
| **NRT-01 … NRT-20** | 20 | National red-team attacks with detection, response and residual risk | Part 71 |
| **SIM-01 … SIM-20** | 20 | National failure simulations with trigger, first failure, response, evidence, level, communication, recovery and residual risk | Part 48 |
| **NEF-1 … NEF-10** | 10 | National emotional failure modes with early warning, prevention, detection, response and residual risk | Part 5 §5.5 |
| **MC-1 … MC-11** | 11 | Misclassification classes with detector and first response | Part 16 §16.3 |
| **T10-1…T10-10 / T5-1…T5-10 / TS-1…TS-10 / TF-1…TF-6** | 36 | Trust-loss failures by stage of encounter | Part 50 |
| **AD-01 … AD-14** | 14 | Adoption-system attacks | Part 49 |
| **PN-1…PN-4 / RN-1…RN-7 / CN-1…CN-6 / RS-1…RS-4** | 21 | Political, religious, caste and regional neutrality surfaces | Parts 7–10 |
| **AC-1…AC-9 / ML-1…ML-8 / CO-1…CO-9** | 26 | Anti-cult, anti-MLM and anti-coercion vectors in communication | Parts 39–41 |
| **FWF-1…FWF-4** | 4 | First-win failure modes | Part 18 §18.2 |
| **RC-1…RC-4** | 4 | Reputation-capacity alignment states | Part 21 §21.2 |
| **CAP-1…CAP-8** | 8 | Capacities, with the binding stage named | Part 42 §42.2 |
| **E-C-01 … E-C-20** | 20 | Contradictions, of which **five are NOT RESOLVED** | Part 64 |

**[A] The five unresolvable failures: MAF-04 (the empty correction log — ES.5), MAF-25 (non-participation leaves no record), MAF-26 (third-party acceptance of a portable record), MAF-28 / NRT-20 (nominal compliance is undetectable from inside), and E-C-19 (the incentive against publishing one's own failure).** Each requires an external actor, an external payer or a willingness that no document can supply.

---

# ANNEXURE E — NATIONAL COMMUNICATION METRICS DICTIONARY

**[P]** Every measure this document defines, with its object, unit, owner, privacy and prohibited use.

| Metric | Object | Unit | Owner | Cadence | Privacy | **Prohibited use** |
|---|---|---|---|---|---|---|
| **CI-1 … CI-15** | As Part 73 §73.2 | As specified | As specified | As specified | As specified | **None may rank an individual, determine leadership, or serve as a conversion target** |
| **HM-1 … HM-15** | The human journey **[S-C]** | As specified **[S-C]** | As specified | As specified | As specified | **Not duplicated by any CI measurement (§73.1)** |
| **LM-1 … LM-15** | The leadership system **[S-D]** | As specified **[S-D]** | As specified | As specified | As specified | **Not duplicated by any CI measurement** |
| **B-P-01 … B-P-14** | The pilot **[S-B]** | As specified **[S-B]** | As specified | Pilot | As specified | **Namespace-separated from `P-nn` simulations [S-D: Rule D-129]** |
| **CL-0 … CL-8** | The organisation's claim entitlement | Stage | National + Audit | Per period | C1 | Any claim above the demonstrated stage |
| **NI-0 … NI-6** | Identity maturity | Level, determined by operation not documentation | National | Per stage | C1 aggregate | A league table of localities |
| **MA-0 … MA-6** | Adoption maturity | Level | City | Per stage | C1 aggregate | **Any national aggregate (Rule E-216)** |
| **RC-1 … RC-4** | Reputation-capacity alignment | State | National + Audit | Per period | C1 | Treating RC-1 as a deficiency to be corrected by promotion |
| **TS-1 … TS-14** | Public trust signals | Publication items | Finance, Audit, Comms | Per cadence | C1 with suppression | Publishing any C2, C3 or C4 content |
| **Followers, likes, views, shares, reach, impressions, engagement, sentiment** | **Nothing** | — | — | — | — | **Any use as evidence, target, incentive or achievement (Rule E-106)** |
| **Membership count** | The organisation | Count | HR | Annual **[S: Ch.24]** | C1 aggregate | **Leading any report (Rule E-183); justifying expansion (Rule E-213)** |
| **Inbound contacts (HM-1)** | Awareness proxy | Count | Team, City | Monthly | Minimal — a contact is not an identity | A conversion denominator |
| **Decline rate** | Capacity honesty | Rate | Team, City | Monthly | Aggregate | Concealment. **A well-delivered decline is a trust event (Rule E-5)** |
| **Correction count and latency (CI-9)** | Honesty performance | Count and interval | Audit + Comms | Per period | C1 | **Zero is not a success (Rule E-88)** |
| **Refusal count (CI-10)** | Neutrality performance | Count | National + Legal | Annual | C1 aggregate | **Zero in a period where approaches occur is a warning sign** |
| **Spokesperson count (CI-13)** | Distribution of the public face | Count by domain and region | National Comms | Annual | Role-holders as roles | **A count of one is a finding** |
| **Claim traceability (CI-8)** | Whether every claim is checkable | Percentage | Audit | Per period | C1 | **Must be 100%; any shortfall is a governance finding** |
| **`H_gov` including communication hours** | Burden | Hours per team per month | City owner | Monthly | C2 | Cross-team punitive comparison |
| **`σ_max`** | Burden ceiling | Hours | Derived from unit economics **[S-B: §26.1]** | Per period | C2 | Exceeding. **Rule E-169: communication hours must not exceed service and verification hours** |

---

# ANNEXURE F — NATIONAL BRAND GOVERNANCE MATRIX

**[P]** Every brand and digital asset, its controller, custodian, permitted surfaces, continuity arrangement and status. **Nothing here resolves N12 or N13.**

| Asset | **Controlled by** | **Custody** | **Permitted surfaces** | **Prohibited surfaces** | Continuity | **Status** |
|---|---|---|---|---|---|---|
| **The name "Sewak Sathi Sanstha"** | **`UNRESOLVED` — N12** | — | All four tiers per BR-1 | — | — | **`PROPOSED` public operating name; availability and registration unvalidated [S: Ch.33]** |
| **The parent name "Krytos"** | **[S: Ch.4]** ownership | — | Legal, financial, contractual, regulatory, funding and accountability contexts only (Rule E-58) | **Any service, participation, recognition or help-seeking artefact** | — | APPROVED as parent context |
| **The mark / logo** | **`UNRESOLVED` — N12** | — | Documents; banners at authorised service activities; digital channels; task-scoped removable identification **[S-A: A-06 V8]** | **Worn garments; crowd-facing vehicles; any object suggesting rank or authority** | — | **Design not begun; blocked by N12 and Rule E-60** |
| **Identity colour / palette** | **`UNRESOLVED` — N12** | — | To be determined | **Any of the nine information colours (Rule E-61); any colour with a per-state political association without [V]** | — | **Red may not be dominant (Part 13 §13.2)** |
| **Symbols** | National Communications + Legal | — | Where the Rule E-63 six-question test passes | Anything implying authority, rank, government, military, police or religion | Versioned | Not designed |
| **Local identity "Sewak Sathi Sanstha — [locality]"** | The team, under the national schema | Team | First contact; local pages; local records; local stories; locality attribution on outcomes | Alone in any legal or financial context | City fallback | **Pattern fixed, locality word local, registered (Part 12 §12.2)** |
| **Venture trading names** | Business function | — | Commercial contexts only | **Any service artefact; any adjacency with the service mark (Rule E-18)** | Per venture | Separate by rule |
| **Official social accounts** | National Communications | **Dual custody [S-A: A-14 §13.4]** | Distribution of the public record (Rule E-107) | Personal accounts; unrecorded decision channels (Rules E-154, E-155, E-188) | Revocable access; backup admin; two-person recovery **[S: App. A §8.x]** | Specified |
| **Domain** | National + Technology | **Dual custody [S-A: A-14 §13.4]** | The platform-independent public record (Rule E-198) | — | Renewal diarised at two levels; fallback payment route | **Ownership `UNRESOLVED` with N13** |
| **Public local pages / paper sheets** | The team | Team, City fallback | PLR-1…PL-7 and nothing else (Rule E-78) | Appeals, donation prompts, membership invitations, follower counts, testimonials, beneficiary imagery, founder references | Paper equivalent always (Rule E-79) | **Not built — [S-ST: §20.3] "not in the current architecture"** |
| **Media library** | National Communications | Institutional, never personal **[S-A: A-15 M4]** | Consented, non-identifying images of places, work and results | **Any beneficiary image; any minor's image; any staged or synthetic image presented as real** | Archive and continuity | Specified |
| **Communication archive** | National + Audit | **Append-only; sealed on transition [S-D: TA-h]** | Audit and subject access | Deletion by any role | Retention `UNRESOLVED` | Specified |
| **ID card** | Communications + Legal **[S: App. A blocker]** | Dual custody of blank stock and issuing function | **Carried, never worn or displayed [S-A: A-03 V3, V4]** | Lanyards, outward display, use to gain compliance | Revocable; returned or invalidated same day on role change **[S-D: TA-b, TA-c]** | **`PROPOSED` — a launch blocker, undelivered** |
| **Task-scoped identification (vest / table banner)** | The team, per authorisation | Team | Name and activity only, at an authorised activity, removed at the end **[S-A: A-06 V5]** | Worn while travelling; any authority implication; any styling or branding as identity | Per activity | Specified |
| **Dated result board** | The team | Team | At a completed site: locality, date, what was done, how to check, how to complain | Any person's name or image; any claim above CL-2 | Replaced or removed at site change | **Recommended — the highest-value visual artefact in this instrument (Part 13 §13.7)** |
| **Category sentence and "what we are not" list** | National Communications | Terminology register | Every first-contact artefact, in every operating language | Alteration without register entry | Versioned **[S-A: A-15 M2]** | **`NOT ADOPTED — draft only` (N-E-21)** |
| **Spokesperson designations** | National Communications | — | By domain and region (Rule E-105) | A single national voice; any personal capacity statement presented as organisational | Successor named per domain (T4 test) | Specified |
| **IP in architecture, SOPs, curricula, software, data models, brand assets** | **`UNRESOLVED` — N13** | — | — | — | — | **"The institution's operating system could be withdrawn by a licensor" [S-A: N13]** |

---

# ANNEXURE G — LANGUAGE ARCHITECTURE MATRIX

**[P]** Five registers across governance, operations, public, local and emergency use. **Extends — never replaces — [S-C: §30.2 L1/L2/L3].**

| Register | Content | Authoritative text | Translation | Reviewer | Failure if wrong | Pre-positioned? |
|---|---|---|---|---|---|---|
| **LA-1 GOVERNANCE & LEGAL** | Constitution; DO-NOT list; protection doctrine; privacy notice; compensation formula; consent text; exit rights; grievance and appeal routes; partnership agreements; brand-usage permission | **One authoritative text per language; every version legally reviewed; no publication without review [S-C: §30.2; S-A: H10]** | **MANDATORY in every operating language before publication** | **Legal [V]** plus a native speaker separate from the author | A person is bound by, consents to, or is denied something they could not read | Yes |
| **LA-2 OPERATIONAL** | SOPs; task descriptions; forms; training material; dashboards; role briefs; playbooks | Local language first | **By need** — only what a role-holder in that language must use | Native speaker; terminology register | A duty cannot be performed; a safety instruction is misunderstood | By need |
| **LA-3 PUBLIC COMMUNICATION** | Category sentence; "what we are not" list; published records and accounts; project outcomes; corrections; refusal-log summaries; the complaint route; media statements | **Meaning fixed nationally; wording local** | **MANDATORY for the category sentence, the "what we are not" list, the complaint route and every correction. Otherwise by locality** | Editor function **[S: Ch.24]**; terminology register | A person cannot check a claim, cannot complain, or is told something they cannot read | The four mandatory items, yes |
| **LA-4 LOCAL PARTICIPATION** | Invitations; stories; recognition wording; event language; local naming; meeting form; first-contact conversation | **Fully local. The organisation sets meaning, never phrasing [S-C: §30.2]** | **NEVER — translating L3 is an error** | The locality | The organisation sounds like a head office; grammatically correct and socially wrong | No |
| **LA-5 EMERGENCY** | Incident notification; safety instruction; avoidance guidance; service suspension; breach notice to affected people; urgent correction | **Fast and factual; no speculation; sensitive statements require safety, legal and communications approval [S: Ch.24]** | **MANDATORY, immediately, in every language of the affected locality, in an accessible format including voice** | Safety + Legal + Communications | **People are harmed because they could not read the warning** | **YES — before the emergency. There is no time to translate during one (Part 14 §14.5)** |

**Cross-cutting rules:** **no language is senior** (Rule E-53); **simultaneous or not published** (Rule E-67); **the mandatory four-item set is a launch condition, not a scaling feature** (Rules E-66, E-70); **terminology registered per language and per state, including refusals** (Rules E-31, E-45, E-161); **machine translation never publishes** (Rule E-68); **four error classes with different reviewers** (Rule E-69); **translate L1 fully and once, L2 by need, leave L3 local** (Part 14 §14.5).

---

# ANNEXURE H — NATIONAL EXPANSION GATE MATRIX

**[P]** Evidence required at every scale. **Three gate sets are conjunctive (Rule E-214): v1.3-E's GATE E0…E7, [S-D]'s XG-1…XG-8, and [S-B]'s economic conditions.**

| Scale | **v1.3-E identity gates** | **[S-D] leadership gates** | **[S-B] economic conditions** | **Claim permitted** | **Blocked while** |
|---|---|---|---|---|---|
| **One locality (CL-0 → CL-1)** | **GATE E0** identity coherent; **GATE E1** local communication understandable; **GATE E2** no political/religious/cult/MLM confusion | Four capability routes (Rule D-33); Interim Authority Order; MVLS-1…MVLS-12 | `H_gov` measured and inside `σ_max`; priority 1 on time | Design and testing statements only | The two **[S: Ch.31]** launch blockers are undelivered |
| **One validated locality (CL-2)** | GATE E1, E2 held; PLR current; correction and refusal logs operating | SS states recorded; Gate E operating; decision records complete | One full cycle of published accounts; zero unresolved serious safety incidents | "In [locality], over [period], we did X; the outcomes were Y; we got Z wrong and corrected it" | No published correction exists |
| **Multiple localities (CL-3)** | **GATE E3** pilot evidence; **GATE E4** repeatable local communication; **GATE E5** multi-locality evidence with ≥1 independent verification | Gate R with an out-of-team assessor — **[S-D: §52.3 step 5, the pivot]**; RV-3 | Three materially different contexts costed | "This has worked in N localities of these kinds" | Communication in the second locality was produced by the first locality's authors |
| **City (CL-4)** | GATE E5 held; City verification channel operating | XG-1…XG-8 all pass; City shared services operating | **B-21** City Shared Services Contract; City divisor measured | "Operating in [city] across N localities" | Any existing unit fell below continuity cover (**XG-8**) |
| **Multi-city (CL-5)** | GATE E5 held across cities | Succession exercised at City level; SS-4/SS-5 on City roles | Divisor measured across a range of `K` | "Operating in N cities in [state]" | The divisor was measured in one environment type only (Rule E-138) |
| **State (CL-6)** | **GATE E6** City/state communication capacity costed and funded; language equity demonstrated | State assessment independence; cross-city succession | `H_gov_per_team(K)` sub-linear or mitigated — **[S-D: Rule D-91]** | "Operating across [state], in these languages" | State formation preceded divisor measurement |
| **Multi-state (CL-7)** | GATE E6 held per state; standards versioned without drift | Multi-state succession; four annual tests published | Per-state economics viable | "A network in N states, with published records for each" | Any state below CL-6 (**Rule E-215 weakest locality determines the level**) |
| **National (CL-8)** | **GATE E7** national reputation infrastructure: all ten **[S-ST: §14.3]** and all fifteen **[S-ST: §30.3]** pre-conditions | National leadership proven; **[S-D]** at B or above | Reserves; insurance in force; entity resolved | "A national network of independently operating local teams whose records, accounts, outcomes and corrections are published" | **N12 or N13 unresolved (Rule E-60)**; CEO-vs-Council unresolved; any pre-condition unmet |
| **Any scale** | **GATE E-X** — a national service day, national campaign, celebrity relationship or paid media programme | — | — | — | **Prohibited at every stage by Rules E-25, E-111, E-144, E-175** |

**Never justifies expansion (Rule E-213):** increased membership, followers, funding, media attention or inbound demand; a political or commercial invitation; a partner's offer; a leader's ambition; a locality's enthusiasm; **or a successful pilot alone.**

---

# ANNEXURE I — MASS-ADOPTION MEASUREMENT PLAN

**[P]** The fifteen additional measurements. **Same shared pilot — one mohalla team, no technology [S-B: §40; S-C: §57; S-D: Part 41]. No second pilot (Rule E-222).**

| ID | Measurement | Method on paper | **Testable by one team?** | **Minimum population if not** | Threshold |
|---|---|---|---|---|---|
| **CI-1** | Misclassification rate | Ask independent respondents what the organisation is; map to MC-1…MC-11 | **PARTIAL** — one locality, one first impression | ≥ 3 localities, ≥ 30 respondents | No target; **a concentration in MC-1/2/3/11 is an action trigger** |
| **CI-2** | First-contact comprehension | Ten seconds with one artefact; how many of the eight questions can they answer? | **YES** | — | A stated floor, `PROPOSED` |
| **CI-3** | Perceived political association | Independent respondents; aggregate | **NO** | ≥ 3 localities, ≥ 30 respondents, suppression-safe | Any non-zero is investigated |
| **CI-4** | Perceived religious or caste association | As CI-3 | **NO** | As CI-3 | Any non-zero triggers a pattern review |
| **CI-5** | Perceived security or vigilante character | As CI-3 | **NO** | As CI-3 | Any non-zero triggers a visual and vocabulary audit |
| **CI-6** | Language match | Language of first contact vs language of material, per person, as a rate | **YES** | — | **100% for the mandatory set** |
| **CI-7** | Terminology consistency | Sample artefacts across languages; check registered meanings | **PARTIAL** — one language at pilot | ≥ 2 languages | **100%** |
| **CI-8** | Public-claim traceability | Every published claim: class, label, register entry, inspectable record | **YES** | — | **100%. Any shortfall is a governance finding** |
| **CI-9** | Correction performance | Count and discovery-to-publication interval; **and whether the log was empty** | **YES** | — | **Zero across a period is published as an anomaly (Rule E-88)** |
| **CI-10** | Refusal-log operation | Count approaches received and declined; was the log published? | **NO** — needs an election cycle or a full year | One full year, or one election in the operating area | **Zero where approaches occur is a warning sign** |
| **CI-11** | Verification-channel use | Count queries and response rate and interval | **YES** | — | **A rising count is a good sign** |
| **CI-12** | Publication completeness | TS-1…TS-14 and PLR-1…PL-7 present, current, dated, at the required stage | **PARTIAL** — the stage-required subset only | Full set needs CL-2 | **100% of the stage-required subset** |
| **CI-13** | Spokesperson distribution | Count distinct authorised spokespersons who actually spoke, by domain and region | **NO** — one locality has one voice | ≥ 3 localities or a City layer | **A count of one is a finding** |
| **CI-14** | Attribution and consent compliance | Every published story: correct grammatical subject; specific recorded consent for each personal element | **YES** | — | **100%. Any shortfall means withdrawal** |
| **CI-15** | Unaffiliated repeat use | Distinct people using a public channel more than once without ever joining | **YES** | — | **Non-zero is the primary evidence that the central proposition works** |

## I.1 Testability summary

| Category | Count | Items |
|---|---|---|
| **Fully testable by one team on paper** | 8 | CI-2, CI-6, CI-8, CI-9, CI-11, CI-12 (subset), CI-14, CI-15 |
| **Partially testable** | 2 | CI-1, CI-7 |
| **`NOT TESTABLE AT PILOT SCALE`** | 5 | **CI-3, CI-4, CI-5, CI-10, CI-13** |

**[P]** Per Rule E-222 the five not-testable items are recorded here with minimum populations and are **not approximated, estimated or inferred from one team.**

## I.2 What the pilot will and will not prove about national identity

| Will prove | Will not prove |
|---|---|
| Whether a stranger can answer the eight first-contact questions from one artefact | Whether India would classify the organisation correctly |
| Whether PLR-1…PL-7 can be produced and kept current on paper | Whether publication scales to N localities |
| Whether the two ungated actions are actually used, by people who never join | Whether participation without membership holds at scale |
| Whether a correction can be issued without approval — **and whether one is** | **Whether the correction log survives reputational pressure. At CL-1 there is no reputation to protect** |
| Whether the refusal script works in the local language | Whether neutrality holds under a real political approach |
| Whether the human accessibility route completes a process for a non-reader | Whether digital accessibility works at scale |
| Whether communication hours fit inside `H_gov` at one team | Whether they fit at CL-3 and above |
| Whether the organisation can say "we do not know yet" in public | Whether it will, under national attention |

---

# ANNEXURE J — NATIONAL IDENTITY AMENDMENT REGISTER

**[P]** Index to **Part 63**. All forty-six amendments carry the twenty mandated fields there.

| ID | Title | Part | Stage | Status |
|---|---|---|---|---|
| **E-01** | Five-Distinction Rule and the Claim Ceiling | 1, 2 | 0–1 | PROPOSED — REQUIRES APPROVAL |
| **E-02** | Every-Citizen Relationship Matrix | 3 | 0–1 | PROPOSED — REQUIRES APPROVAL |
| **E-03** | National Participation Without Membership | 4 | 0–1 | PROPOSED — REQUIRES APPROVAL |
| **E-04** | Emotional Conditions Architecture | 5 | 0–1 | PROPOSED — REQUIRES APPROVAL |
| **E-05** | National Story and Claim Traceability | 6 | 1 | PROPOSED — REQUIRES APPROVAL |
| **E-06** | Political Neutrality in Expression | 7 | 0–1 / 2 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-07** | Religious Neutrality in Expression | 8 | 0–1 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-08** | Caste Neutrality and the Composition-Monitoring Refusal | 9 | 2 | **PROPOSED — BLOCKED BY UNRESOLVED ITEM (N5)** |
| **E-09** | Regional Plurality and the Localisation Contract | 10 | 0–1 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-10** | Layered Identity | 11 | 1 | PROPOSED — REQUIRES APPROVAL |
| **E-11** | Three-Tier Brand Architecture and Parent Subordination | 12 | 1 local; **national blocked** | **PROPOSED — BLOCKED BY UNRESOLVED ITEM (N12, N13)** |
| **E-12** | Visual Identity and the Red-Colour Resolution | 13 | 0–1 prohibitions; **palette blocked** | **PROPOSED — BLOCKED BY UNRESOLVED ITEM (N12)** |
| **E-13** | Five Language Registers | 14 | 0–1 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-14** | Accessibility Standard | 15 | 0–1 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-15** | First Contact Standard | 16 | 0–1 | PROPOSED — PILOT FIRST |
| **E-16** | First Five Minutes and the Public Local Record | 17 | 0–1 | PROPOSED — PILOT FIRST |
| **E-17** | First Real Win, national version | 18 | 0–1 | PROPOSED — PILOT FIRST |
| **E-18** | National Participation Funnel | 19 | 0–1 | PROPOSED — REQUIRES APPROVAL |
| **E-19** | Trust Production System | 20 | 1 / 2 | PROPOSED — PILOT FIRST |
| **E-20** | Reputation Architecture | 21 | 1 | PROPOSED — REQUIRES APPROVAL |
| **E-21** | Four-Audience Transparency Regime | 22 | 1 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-22** | Crisis Communication Protocol | 23 | 0–1 / 2 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-23** | Social Media Doctrine and the Vanity-Metric Prohibition | 24 | 0–1 | PROPOSED — REQUIRES APPROVAL |
| **E-24** | Partnership Architecture | 25 | 1 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-25** | Government Interface Communication Boundaries | 26 | 0–1 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-26** | Business Interface and the public Service/Sales Firewall | 27 | 1 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-27** | Education Interface | 28 | 0–1 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-28** | Media Interface, local and national | 29, 30 | 1 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-29** | Claim Ladder and Under-Claiming | 31 | 0–1 | PROPOSED — REQUIRES APPROVAL |
| **E-30** | Flywheels and Expansion Gates | 32, 58 | 1 | PROPOSED — REQUIRES APPROVAL |
| **E-31** | Replication Classification | 33 | 2 | PROPOSED — REQUIRES APPROVAL |
| **E-32** | Structural Variance Register | 34 | 3 | PROPOSED — REQUIRES APPROVAL |
| **E-33** | National Culture and Shared Practices | 35, 36 | 1 | PROPOSED — REQUIRES APPROVAL |
| **E-34** | Story Architecture and Beneficiary Dignity | 37, 38 | 0–1 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-35** | Anti-Cult, Anti-MLM and Anti-Coercion in Communication | 39, 40, 41 | 0–1 | PROPOSED — REQUIRES APPROVAL |
| **E-36** | National Capacity and the Bottleneck Principle | 42 | 1 | PROPOSED — REQUIRES APPROVAL |
| **E-37** | Four Growth-Shock Protocols | 43–46 | 1 | PROPOSED — REQUIRES APPROVAL |
| **E-38** | Reputation Shock and Attack Response | 47 | 1 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-39** | National Communication Governance | 52 | 0–1 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-40** | Digital Architecture and Platform Dependency | 53 | 1 / 3 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-41** | Contribution Portability | 54 | 3 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **E-42** | National Recognition and the Hero-Language Rule | 55 | 0–1 | PROPOSED — REQUIRES APPROVAL |
| **E-43** | Specialist and Knowledge Networks in public | 56, 57 | 3 | PROPOSED — REQUIRES APPROVAL |
| **E-44** | Identity and Adoption Maturity | 59, 60 | 1 | PROPOSED — REQUIRES APPROVAL |
| **E-45** | One Integrated Evidence System | 61 | 2 | PROPOSED — REQUIRES APPROVAL |
| **E-46** | Claim Discipline and Evidence Labels | 31, 61 | 0–1 | PROPOSED — REQUIRES APPROVAL |

**Merge waves:** **W1 (Stage 0–1):** E-01, E-02, E-03, E-04, E-14, E-15, E-16, E-17, E-18, E-23, E-34, E-35, E-42, E-46. **W2 (Stage 1):** E-05, E-06, E-07, E-09, E-10, E-13, E-19, E-20, E-21, E-22, E-25, E-26, E-27, E-29, E-30, E-33, E-37, E-39, E-44. **W3 (Stage 2–3):** E-08, E-24, E-28, E-31, E-32, E-36, E-38, E-40, E-43, E-45. **W4 (blocked by unresolved source items):** E-11, E-12 (palette and mark only), E-41 — **blocked by N12, N13 and the entity structure.**

---

# ANNEXURE K — OPEN QUESTIONS

**[P]** Questions this document **refuses to answer**, with the reason and the authority that must answer.

| ID | Open question | Why it is open | Who must answer | Consequence if unanswered |
|---|---|---|---|---|
| **OQ-E01** | **Who owns the brand, on what licence terms, with what use conditions and what post-exit restrictions?** | `UNRESOLVED` **N12 [S-A: §22]** | Founder/CEO + IP counsel **[S-A: V8]** | **Teams hold no documented right to the name. Rule E-60 blocks all national brand use** |
| **OQ-E02** | **Who owns the IP in the architecture, SOPs, curricula, software, data models and brand assets?** | `UNRESOLVED` **N13 [S-A: §22]** | Founder/CEO + IP counsel | **The institution's operating system could be withdrawn by a licensor** |
| **OQ-E03** | **What is the legal entity, and what may therefore be said about status?** | `UNRESOLVED` **[S: Ch.33]** | Corporate and tax counsel | 12A political-activity conditions, 80G, FCRA, disclosure duties and liability all undetermined |
| **OQ-E04** | **Does the CEO or a National Council approve a national claim, a partnership or a brand decision?** | `UNRESOLVED` **[S: Ch.33; Ch.4]**; **[S-D: LDR-U01]** | The source hierarchy | Publication authority has no determined apex |
| **OQ-E05** | **Is the public name available and registrable?** | `PROPOSED` **[S: Ch.33]** — "validate name availability and registration" | IP counsel | Investment in a name that cannot be used |
| **OQ-E06** | **What is the mark, and what is the palette?** | **Blocked by OQ-E01**; per-state political-association review required | Design + Legal + cultural review | **[S: Ch.31]** blocker "approved card mock-up" cannot be delivered |
| **OQ-E07** | **Is red used at all, and in what role?** | Part 13 finds red may not be dominant; **whether it may appear as an accent is a design and per-state political question** | Design + per-state review **[V]** | The information colour system and the identity collide |
| **OQ-E08** | **Which category sentence, if any, is adopted?** | **[S-ST: §20.2]** is explicitly "draft for approval, not adopted language"; **CI-2** must be measured first | Founder/CEO + Communications, after comprehension testing | Every locality improvises a self-description |
| **OQ-E09** | **Is composition monitoring undertaken at all, and in what form?** | `UNRESOLVED — deliberately` **N5 [S-A]** | CEO + Council + privacy officer | **Exclusion patterns invisible, or an identity database created. Rule E-48 forbids the second and cannot produce the first** |
| **OQ-E10** | **What is the small-cell suppression threshold?** | `UNKNOWN — MEASURE IN PILOT`; **[S-D: Rule D-108]** | Data-protection advice plus scale measurement | Aggregate reports may identify individuals |
| **OQ-E11** | **What is the data retention period, including for the communication archive?** | `UNRESOLVED` **[S: Ch.33; S-A: A-17 P2]** | Data-protection counsel | Publication, archive and erasure all undetermined |
| **OQ-E12** | **Should any comparative artefact be public?** | **[S-ST: R5]** open; **[S-C: §44.4]** | The source hierarchy | Part 24 specifies what must be true under either answer |
| **OQ-E13** | **What does national communication cost?** | **No communication line exists in any prior cost model (EA-E1, §42.5)** | **[S-B]**'s model extended, after pilot measurement | **Rule E-169's test cannot be applied; a second organisation may form undetected** |
| **OQ-E14** | **How many languages, and from when?** | Depends on the operating footprint, which does not exist | National, per locality, before operation | Rule E-70 makes the mandatory set a launch condition, so the answer is required before service, not after |
| **OQ-E15** | **Is insurance in force, and for what?** | `UNRESOLVED` **[S-A: A-10]**; **[S-ST: §14.3 item 5]** | Insurance broker | Any protection-adjacent public activity is an uninsured exposure |
| **OQ-E16** | **What is the response window for public queries, and can it be met?** | `UNKNOWN — MEASURE IN PILOT` | Team + City | A promised window that is not met is worse than none (**HM-14**) |
| **OQ-E17** | **Who is the independent reviewer, with what remit and cadence?** | **[S-ST: §14.2 Layer 4]** proposes it; no mechanism exists; Rule E-189 forbids promising it without one | Audit + Council + external appointment **[V]** | Self-audit remains the only audit |
| **OQ-E18** | **May a politically active person hold organisational leadership?** | **[S-D: OQ-18]** — the tension between civic rights and organisational neutrality cannot be resolved by rule | The source hierarchy with legal advice | Local capture risk versus exclusion of capable local leaders |
| **OQ-E19** | **Will the correction log be kept when keeping it is costly?** | **ES.5. No instrument compels it; the incentive runs against it** | **Nobody, from inside.** Only the willingness of the people it reflects badly on | **The whole reputation architecture is unverifiable** |
| **OQ-E20** | **Will a portable credential be accepted by anyone outside the organisation?** | **MAF-26 — third-party acceptance is not designable** | Employers, institutions and other organisations | The most valuable asset in the architecture yields no value |
| **OQ-E21** | **Would India care?** | **No instrument can answer this and the brief forbids assuming it** | Real people, over years | Every projection in this document is a hypothesis |
| **OQ-E22** | **Can nominal compliance be detected?** | **MAF-28 / NRT-20 — no internal control detects a system complied with nominally and failed actually** | Nobody, from inside | **The architecture exists, is reported favourably, and does not operate** |

---

# COMPLETENESS AUDIT

**[P]** Brief §233. Seventeen checks, each answered.

| Check | Question | Result |
|---|---|---|
| **SOURCE** | Did v1.2's national/local architecture survive? | **YES.** The master chain, four levels, eleven role families, five cadences, the five-row communication rule table, National Communications, Editor and Social Media Manager roles, the information colour system and the partnership brand rule are all preserved. Annexure A |
| **A** | Did neutrality and institutional safeguards survive? | **YES.** N1…N9, A-05's eight clauses and four guards, A-06 V1…V8, A-08, A-14 §13.3–§13.8, A-15 M1–M7, A-16 §15.4 and the four annual tests, A-17…A-20 — all carried, several extended to expression |
| **B** | Did economic constraints survive? | **YES.** `σ_max`, `H_gov`, the waterfall, the absence of any revenue line for service/governance/training, the City divisor and B-21 all bind. **v1.3-E adds one finding: communication is not costed in v1.3-B (EA-E1), recorded as a gap, not a criticism** |
| **C** | Did human participation remain voluntary? | **YES — and is strengthened.** Nine pathways without membership; L0 a complete position; no conversion target; no referral mechanism; no beneficiary-to-participant pathway at all; refusal scripts published |
| **D** | Did leadership remain accountable and non-personality-based? | **YES.** **[S-D]**'s verdict is carried visibly; no communication role confers authority over people; visibility is prohibited as a selection criterion; spokesperson distribution is measured; **Part 76 §76.5 item 10 makes national identity dependent on v1.3-D reaching B** |
| **BRAND** | Did branding remain subordinate to reality? | **YES.** Rule E-1 claim ceiling; Rule E-4 reputation lags capacity; CL-0…CL-8; Rule E-91 reputation never a target; Rule E-182 the ladder is audited and over-claims withdrawn and published |
| **LANGUAGE** | Did national communication avoid English-only assumptions? | **YES.** No language senior; simultaneous or not published; a mandatory four-item set per locality before operation; L3 never translated; **v1.3-A's explicitly deferred language architecture is filled** |
| **CULTURE** | Did local identities remain legitimate? | **YES.** Eight immutable, ten localisable, local by default; adaptation through the register; no national date; no national hero; locality attribution on every published outcome |
| **POLITICS** | Did neutrality remain intact? | **YES.** N1…N9 extended to adjacency, timing, vocabulary and silence; refusal log published; never answer a political claim politically |
| **RELIGION** | Did religious diversity remain intact? | **YES.** No religious ritual as an organisational requirement; *seva* descriptive never prescriptive; faith-based partners activity-scoped, separately branded, never exclusive; **no composition figure produced even to rebut an accusation** |
| **CASTE** | Did caste neutrality remain intact? | **YES — behaviourally, not demographically.** Routing, venue, timing, naming, food and recognition are reviewed for pattern; **no caste data is collected for any purpose (Rule E-48)**; N5 remains unresolved |
| **DATA** | Did communication avoid unnecessary personal-data collection? | **YES.** Minimum safe pathway; three separate consents; no image of a beneficiary or a minor; no identity field required for any public process; five audiences with C1–C4 preserved |
| **GROWTH** | Did growth remain capacity-constrained? | **YES.** The smallest of eight capacities constrains and is named in the authorisation; three gate sets are conjunctive; expansion on attention is prohibited; **EXPAND is not the default outcome — IMPROVE is** |
| **REPUTATION** | Can the organisation admit mistakes? | **ARCHITECTURALLY YES; BEHAVIOURALLY UNVALIDATED.** Rule E-186 makes a correction approval-free; Rule E-88 makes an empty log an anomaly; **ES.5 and OQ-E19 record that nothing compels it and the incentive runs against it** |
| **AI** | Did AI remain advisory? | **YES.** Art.12 preserved; machine translation never publishes; named human review mandatory for LA-1/LA-3-legal/LA-5; synthetic evidence absolutely prohibited; AI content disclosed; no AI reputation decision |
| **ECONOMICS** | Did national identity avoid unfunded obligations? | **PARTIALLY — and the shortfall is recorded.** Most instruments are publication of existing records and cost translation and time. **Three are unfunded: crisis standby, translation at scale, and independent review. Rule E-168 requires all three to enter `H_gov`; the values are `UNKNOWN`** |
| **PILOT** | Can the important assumptions actually be tested? | **PARTIALLY.** Eight of fifteen CI measurements are fully testable by one team on paper; two partially; **five are recorded `NOT TESTABLE AT PILOT SCALE` with minimum populations and are not approximated.** **§72.5 lists seven things the pilot cannot prove about national identity** |

---

## END OF INSTRUMENT

**v1.3-E — National Identity, Communication, Reputation & Mass Adoption Architecture.**
**76 Parts · 11 Annexures · 46 Amendments (E-01…E-46) · 225 Rules (E-1…E-225) · 27 Decision-Register Items (N-E-01…N-E-27) · 15 Measurements (CI-1…CI-15) · 28 Failure Modes (MAF-01…MAF-28) · 20 Red-Team Attacks (NRT-01…NRT-20) · 20 Simulations (SIM-01…SIM-20) · 20 Contradictions (E-C-01…E-C-20) · 30 Validation Items (LV-E-1…LV-E-30) · 22 Open Questions (OQ-E01…OQ-E22).**

**Status: `NATIONAL-IDENTITY DESIGN — PROPOSED`.**
**Verdict: `D — NATIONAL IDENTITY & MASS-ADOPTION SYSTEM NOT YET PROVEN`, with a seven-step path to `B`.**

**Nothing in this document is policy, brand, copy, claim or promise until approved. No slogan, sentence, tagline, mark, palette or symbol is adopted. No successor is named. No rupee value, budget, salary, media spend, membership target, growth rate or conversion percentage is invented. No `UNRESOLVED` source item is closed. No second pilot is created. The v1.3-D finding — `LEADERSHIP SYSTEM NOT YET PROVEN` — is carried visibly and is not softened.**

**DO NOT BUILD A NATIONAL BRAND BEFORE BUILDING A TRUSTWORTHY LOCAL REALITY.**

**Prepared 5 October 2026.**
