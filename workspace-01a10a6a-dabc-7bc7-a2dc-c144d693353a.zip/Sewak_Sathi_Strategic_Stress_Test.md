# SEWAK SATHI SANSTHA — DEEP STRATEGIC STRESS TEST

**Subject:** KRYTOS / SEWAK SATHI SANSTHA — Visual Master Architecture, Constitution & Launch Specification v1.2 (1 Oct 2026), including the preserved v1.1 source text (81 pages) in Appendix A.
**Purpose:** Attempt to break the model before reality breaks it; then determine how it could become a trusted, useful, emotionally meaningful, scalable Indian institution that people *voluntarily* choose.
**Analyst stance:** Adversarial first, constructive second. No flattery. No assumption of success or failure.

---

## EVIDENCE LABELLING CONVENTION (applies to every claim below)

| Tag | Meaning |
|---|---|
| **[S]** | **SOURCE-DERIVED FACT** — stated in v1.2/v1.1. Chapter/page referenced where useful. |
| **[A]** | **ANALYSIS** — reasoning applied to source facts; no new facts asserted. |
| **[I]** | **INFERENCE** — a probable consequence derived from analysis plus general real-world behaviour; not verified for this organisation. |
| **[P]** | **PROPOSAL** — my recommendation. Not architecture. Requires your approval before it changes anything. |
| **[V]** | **REQUIRES VALIDATION** — legal, tax, financial, safeguarding, insurance, regulatory, or field evidence needed. |
| **[X]** | **EXTERNAL FACT** — from published sources outside your documents; cited in Annexure C. |

**Nothing below silently alters your architecture.** Every proposed change appears in §26 (KEEP / MODIFY / RECONSIDER) with its original principle, the problem found, the change, the benefit, the *new* risk it creates, and implementation difficulty.

**Numbers discipline.** Your document deliberately refuses to invent numbers (percentages, staffing thresholds, multipliers) **[S: Ch.18, Ch.33]**. I honour that. Where I need quantities for stress-testing, they are labelled **[A-assumption]** with a stated range and a note on how sensitive the conclusion is to them. No number in this report should be treated as organisational policy.

---

# 1. EXECUTIVE FINDINGS

## 1.1 The one-sentence verdict

**The architecture is unusually strong as a *control system* and unusually weak as a *human system*.** It is one of the more carefully designed anti-corruption, anti-gaming, anti-vigilante governance documents I have seen for an early-stage organisation — and it contains almost no design for desire, friction, money-in-the-first-six-months, status, grief, boredom, or the ordinary messiness of why Indians actually show up. **[A]**

## 1.2 Ten findings, ranked by how much damage they can do

**Finding 1 — The organisation has designed a fortress with one small door.**
Every meaningful contribution routes through Verified Membership: application → screening → identity verification → interview → beginner training → probation → role assignment **[S: Ch.12]**. There is no defined tier *below* Verified Member except "Supporting Member", which is itself described as "membership status appropriate to task" **[S: Ch.20 vacancy catalogue]**. The architecture therefore demands organisational-grade vetting from people who may want to give one hour. **[A]** This is the single largest adoption constraint in the document. It is also the easiest to fix without weakening verification (see §9).

**Finding 2 — The Mohalla team's *control* cost is higher than its likely *revenue* in year one.**
A Starter Team must still carry safety, HR verification, finance integrity and evidence duties **[S: Ch.10, State A]**, inside an estate of 22 SOPs **[S: Appendix D]**, 14 evidence record types **[S: Appendix F]**, 5 reporting cadences **[S: Ch.24]**, 8 autonomy gates **[S: Ch.13]**, a 13-step vacancy lifecycle **[S: Ch.11]** and a 13-step weekly payment cycle **[S: Ch.19]**. Nowhere does the document cost the *human hours* this consumes, or say who absorbs them. **[A]** Compliance labour is the hidden fixed cost per team, and it is regressive: it hurts small, poor teams most. **[I]**

**Finding 3 — The wage-protection buffer arrives after it is needed.**
Reserves/wage-protection buffer sit at priority 6 in the waterfall, i.e. they fill only after worker compensation, statutory dues, direct costs, founder cap and organisation fee **[S: Ch.18]**. But the "bad month" protection that keeps members engaged is required in months 1–6, precisely when reserves are zero. **[A]** The architecture protects workers in a downturn it has not yet funded. There is no cold-start capital, minimum-hours guarantee, or seed float anywhere in the document. **[A]** — **This is a sequencing flaw, not a values flaw.**

**Finding 4 — Political and vigilante *perception* is the fastest route to death, and it is uncontrolled.**
The internal doctrine is genuinely excellent: no weapons, no retaliation, no mob justice, no unlawful detention/search, no police impersonation, no intimidation **[S: Ch.16]**. But the document contains **no rule at all** on: members holding political party office while holding organisational roles; conduct during elections; symbols/colours/dress that resemble a political or communal outfit; how to refuse an approach by a political actor; or how to respond when media frames the organisation as a *senā*/vigilante body. **[A]** Meanwhile the combination "mass verified membership + street presence + protection identity + leaderboards + founder ownership" is, in the Indian context, the exact silhouette that observers will read politically regardless of intent. **[I]** Note also: a tax-exempt charitable entity in India must not engage in political activity or support parties/candidates, and 12A registration can be jeopardised if it does **[X]**. **This is the highest-severity gap in the entire document.**

**Finding 5 — The growth model hollows out the teams that succeed.**
"Best Mohalla Team → City Head Team; best City Head Team → State Head Team; best State Head Team → National Team opportunity" **[S: Ch.26, Const. Art.15]**. The document never states whether the promoted leader *leaves* their team, nor requires a successor to be seated before transition. **[A]** If the best team's leader and deputies move upward, the strongest ground unit is weakened as the *reward* for strength. This is a self-consuming growth loop, and it is the kind of thing that quietly kills distributed organisations. **[I]**

**Finding 6 — Leaderboards compare incomparable Indias.**
Proposed weights: mission impact 20, execution 15, business 15, financial discipline 15, member development 10, community trust 10, safety/compliance 10, innovation 5 **[S: Ch.25]**. There is no baseline normalisation, no peer-cohort stratification, and no adjustment for starting conditions. **[A]** A metro mohalla with paying SME customers and a peri-urban mohalla with subsistence households would be ranked on the same scale. Anti-gaming controls exist **[S: Ch.25]** but they police *manipulation*, not *structural unfairness*. Result: chronic demoralisation of exactly the areas the mission says must be served without discrimination. **[I]**

**Finding 7 — Governance capacity scales linearly; trusted people do not.**
Every team needs readiness audits, monthly score verification with anomaly review, finance reconciliation review, incident reviews, AI recommendation reviews with a *named human*, and append-only audit trails **[S: Ch.13, 21, 25, 27]**. Audit and Ethics is a National department **[S: Ch.5]**, and auditors are "review only, not operational commanders" **[S: Ch.23]**. But there is no capacity model: how many auditors per 100 teams? What is reviewed exhaustively vs. by sampling? **[A]** At scale you get one of two outcomes, both bad: an approval backlog that freezes growth, or exhausted reviewers who rubber-stamp — which silently deletes the entire control system. **[I]**

**Finding 8 — Ownership concentration is an institutional ceiling.**
Article 3: owned by Krytos under founder/CEO Vasu; the Council does not own above the CEO unless a future legal charter changes it **[S: Const. Art.3]**. CEO-vs-Council authority is explicitly **UNRESOLVED** **[S: Ch.33]**. There is no founder-succession clause, no incapacity provision, and no **mission lock** — nothing preventing a future owner of Krytos from legally redirecting or dissolving the institution. Article 19 covers dissolution but only as "requires professional validation" **[S: Const. Art.19]**. **[A]** People do not entrust twenty years of their lives to an instrument that one person can legally repurpose. **[I]**

**Finding 9 — The data estate is a liability, not just an asset.**
The platform will hold verified identity, contact and emergency contacts, skills, team/role/status, **conduct records (warnings, complaints, investigations)** **[S: Ch.12]**, beneficiary/request records including safety incidents **[S: Ch.8, Appendix F]**, financial records, and AI logs **[S: Ch.22]**. Under India's DPDP regime, personal data breach notification runs to the Board "without delay" with a detailed report within 72 hours, plus notification of affected individuals; Significant Data Fiduciaries must appoint an India-based DPO, run Data Protection Impact Assessments and annual audits; privacy notices must be understandable and available in English or any of the 22 Eighth Schedule languages; grievance resolution is time-bound; and penalties run to hundreds of crores **[X]**. Data retention and AI model policy are listed as **UNRESOLVED** in your own register **[S: Ch.33]**. **[A]** The sharpest harm is not regulatory: a leaked conduct or request record can out a survivor of domestic violence, abuse, or a minor in danger to the very people they sought protection from. **[I]**

**Finding 10 — There is no competition chapter.**
The document has a risk register **[S: Ch.28]**, a partnership flow **[S: Ch.29]**, a launch roadmap **[S: Ch.30]** — and no analysis of what already occupies this space in an Indian neighbourhood: the mohalla WhatsApp group, the resident welfare association, the temple/mosque/gurdwara/church service committee, the caste or community association, established ideological service networks, NSS (~3.8–3.9 million student volunteers) **[X]**, NGOs, and gig/freelance platforms for the income motive. **[A]** An architecture that does not name its substitutes cannot price its differentiation, and "we are better governed" is not a reason anyone joins. **[I]**

## 1.3 Severity distribution of the 36 failure modes mapped in §3

| Severity | Count | Interpretation **[A]** |
|---|---|---|
| **CRITICAL** | 5 | Can end the organisation, or end its legitimacy, in a single event or a single year. All five are *external-facing* or *structural*: political capture, vigilante perception, protection incident without insurance/legal cover, data breach exposing vulnerable people, mission-lock/founder concentration. |
| **HIGH** | 14 | Will reliably occur without new controls; degrade trust, retention or mission integrity over 12–36 months. |
| **MODERATE** | 13 | Occur predictably but are containable with existing components plus process discipline. |
| **LOW** | 4 | Manageable with the architecture as written. |

**The pattern worth noticing:** almost none of the CRITICAL and HIGH items are failures of *logic*. They are failures of **sequence** (controls that arrive after the risk), **capacity** (controls that assume unpaid human throughput), **perception** (controls that govern insiders but not how outsiders read the organisation), and **incentive direction** (controls that punish gaming but reward visibility over outcomes). **[A]**

## 1.4 What is genuinely excellent and must not be touched

To be adversarial is not to be dismissive. These are load-bearing strengths **[S + A]**:

1. **"The priority order is the control; percentages are a planning tool"** **[S: Ch.18]** — this single sentence prevents more financial self-deception than most NGOs' entire finance manuals.
2. **AI may recommend; humans decide**, with an explicit prohibited-decisions list and append-only AI logs **[S: Ch.21]** — ahead of most real organisations.
3. **The six DO-NOTs of protection** **[S: Ch.16]** — clear, memorable, non-negotiable, and repeated.
4. **Central standards ≠ central control** **[S: Ch.13]** — the correct diagnosis of why distributed organisations fail.
5. **Support-first team recovery** **[S: Ch.14]** — nine steps, root-cause before replacement. Most organisations skip straight to replacement.
6. **Anti-fake-impact rules** **[S: Ch.15]** — "do not count planned activities as completed impact", "include failures and partial outcomes in reports". Rare institutional honesty.
7. **The status-labelling discipline** (APPROVED / PROPOSED / REQUIRES VALIDATION / UNRESOLVED / FUTURE) **[S: front matter]** — the document tells the truth about its own incompleteness. That is a governance asset.
8. **Evidence standards that name what is *not* acceptable** **[S: Appendix F]** — "only group selfie or social post", "inflated headcount without stock reconciliation", "counting planted saplings as long-term survival".
9. **One role = one primary holder** **[S: Ch.22]** — prevents the duplicate-head chaos that destroys volunteer organisations.
10. **Segregation of duties stated as a *pattern*, not a form** — "no single person should receive money + approve expense + record transaction + audit transaction" **[S: Ch.18]**.

**Overall judgement [A]:** the architecture is *buildable* and *worth building*. It is not yet *launchable* at scale, and it is not yet *joinable* by an ordinary citizen. Both problems are addressable without redesigning the spine.

---

# 2. CAN THE ARCHITECTURE ACTUALLY WORK?

Method: for each level, I ask four questions — (i) can it be **staffed**, (ii) can it be **funded**, (iii) can it be **governed**, (iv) will people **stay**? A level fails if any one of the four fails.

## 2.1 MOHALLA LEVEL — verdict: **WORKS ONLY UNDER CONDITIONS THE DOCUMENT DOES NOT YET CREATE**

**What must be true [A]:**

- 8–15 adults in one neighbourhood, with 2–6 hours/week each of *reliable* availability, must be found who will accept: identity verification, an interview, training modules, probation, a role, evidence duties, weekly reporting, and conduct rules **[S: Ch.12, Ch.10 State A]**.
- At least one of them must be willing to hold money responsibility under segregation rules, one to hold safety responsibility, one to hold HR/verification responsibility **[S: Ch.9, Ch.18]**. These three roles carry *social cost* in a neighbourhood: the person who verifies neighbours, records conduct, and controls cash will be resented, lobbied, and accused.
- The team must find either real customer revenue or a resourced service pipeline within roughly one quarter, or the "transparent compensation" promise becomes a visible emptiness **[A]**.

**Staffing: FRAGILE [I].** The binding constraint is not bodies — an Indian mohalla has plenty of people. It is the *three unpopular control roles*. Volunteer research consistently shows the first year has the worst retention, and that cliques/exclusion, unsupportive leadership, and unclear time expectations are among the top stated reasons people leave **[X]**. Your architecture makes the time expectation clear (a strength) but concentrates social friction on HR/Funds/Safety holders with no stated support, rotation, or relief for them.

**Funding: THE HARDEST PROBLEM [A].** The zero-capital local venture model **[S: Exec Summary, Ch.17]** is elegant on paper and brutal in a neighbourhood: local customers are price-sensitive, seasonal, and relationship-bought; a 14-step venture lifecycle **[S: Ch.17]** with QA and acceptance is a lot of process for a ₹6,000 website; and weekly payment **[S: Ch.19]** assumes weekly receipts. Real local service revenue is lumpy. Without a float, the first bad week is paid in *credibility*, not rupees.

**Governance: OVER-SPECIFIED FOR THE UNIT SIZE [A].** The Mohalla team is simultaneously required to be the *execution engine* (10-step operating loop **[S: Ch.8]**) and a *compliance node* (SOPs, evidence, RBAC, audit trail, reports). A nine-person volunteer team cannot do both at the specified fidelity. Something will give — and in practice what gives is evidence quality, which then fails the autonomy gate, which then keeps the team dependent, which then demoralises the leader. **[I]** This is a self-reinforcing trap.

**Retention: WEAKLY DESIGNED [A].** The document is rich on *accountability* and thin on *reward psychology*. Retention mechanisms present: role progression, leadership opportunity, compensation for verified work, member development metric, community trust. Retention mechanisms **absent**: friendship/belonging design, a portable credential, recognition rituals, family-level inclusion, grief/hardship support, a "come back after a break" path, exit interviews, and any protection against burnout for control-role holders. (Note: your Volunteer Manager tracks "fatigue" **[S: Ch.9]** — the only burnout instrument in 179 pages.)

**Mohalla verdict [A]:** It can work — but only if (a) the first team is seeded, not recruited; (b) the compliance load is cut by ~70% for the first two quarters; (c) there is a small float or a guaranteed minimum of paid work; and (d) the three control roles get rotation, backing, and explicit protection from social retaliation. None of these four exist in v1.2.

## 2.2 CITY LEVEL — verdict: **THE MOST REALISTIC LEVEL; ALSO THE FIRST HARD BOTTLENECK**

**Strengths [S+A]:** the City layer is well-conceived — six-lane escalation map **[S: Ch.7]**, Mohalla formation support, cross-mohalla projects, inventory allocation, customer pipeline and venture proposals, weekly/monthly data review. A city is the natural scale for a *professional* function (one good Funds reviewer, one good Safety reviewer, one warehouse, one editor) shared across 20–80 mohalla teams. This is where the architecture's economics actually work.

**Failure conditions [A]:**
1. **City support capacity is the multiplier on everything below it.** Phase 3 exit gate is "city dashboard, support process, performance review" **[S: Ch.30]** — but a city team cannot coach 40 mohalla teams with 8 people. The ratio of city support staff to mohalla teams is never stated. That ratio *is* the growth rate.
2. **The City layer becomes the political centre.** City Head Team status is a prize **[S: Ch.26]**. Whoever controls city support, inventory allocation and venture approval controls real resources. Expect faction formation at city level before anywhere else. Your risk register names "leader abuse" and "conflict of interest" **[S: Ch.28]** but places detection at the level of the individual leader, not at the level of a *city faction*.
3. **Inventory and resource allocation is the classic corruption point.** "Allocate donated/purchased materials with approved evidence and priorities" **[S: Ch.7]** — allocation discretion plus scarcity plus local relationships equals favouritism allegations, even where none occurred. The architecture has receipts and audit, but no *allocation-visibility* rule (e.g. published allocation criteria and a published allocation log).

**City verdict [A]:** works, and is the right place to concentrate professional capability. Needs: a stated support ratio, published allocation criteria, and a city-level conflict/faction detection instrument distinct from individual leader abuse.

## 2.3 STATE LEVEL — verdict: **WORKS AS COORDINATION; FAILS AS A FORMAL LAYER TOO EARLY**

**Strengths [S+A]:** the "why this is not National duplication" table **[S: Ch.6]** is the best-reasoned part of the hierarchy: city coaching, specialist pool, multi-city projects, escalation filter, regional market context. The prohibition on states altering constitutional principles, final compensation percentages, protection boundaries, data policies and legal structures **[S: Ch.6]** is exactly right.

**Failure conditions [A]:**
1. **A state layer costs more than it returns until you have ~4–8 functioning cities.** Before that, "State Team" is a title looking for work, and titles without work become status — which your own risk register warns about ("fake vacancies", "deputy authority creep" **[S: Ch.28]**).
2. **The escalation filter filters truth as well as volume.** "Assess city problems and escalate serious/unresolved issues nationally. Prevents national overload" **[S: Ch.6]**. Every filter is also an editor. A state leader with something to hide is the *only* person who benefits from a filter with no bypass. **[I]**
3. **Inter-state legal and tax heterogeneity is unaddressed.** Labour, professional tax, shop-and-establishment, public-collection permissions, and state-specific trust/society regimes differ by state; one national entity operating in 20 states carries a compliance surface the document does not enumerate **[V]**.
4. **Language and cultural authority.** If the state layer becomes the localisation authority without a written localisation contract (see §12), you get 20 silent variants of the architecture — inconsistency without adaptation.

**State verdict [A]:** correct design, wrong default timing. Should be *earned* by city density, not created by org chart. Needs a bypass escalation channel and a written localisation contract.

## 2.4 NATIONAL LEVEL — verdict: **WORKS AS A STANDARDS BODY; DOES NOT YET WORK AS AN INSTITUTION**

**Strengths [S+A]:** nine national departments with clear links **[S: Ch.5]**; national escalation triggers named (serious safety, fraud, data breach, controversy, high-value contracts, serious misconduct, legal notices, media crisis, collapse) **[S: Ch.5]**; audit separated from command **[S: Ch.23]**; reserves centralised with an approval matrix **[S: Ch.18]**.

**Failure conditions [A]:**
1. **Three layers of aggregation between National and ground.** Mohalla → City → State → National, with data moving up "only when needed" **[S: Ch.6]**. Aggregate data is *lossy by design*. National leadership will see trend lines while the ground sees faces. The architecture has no downward-immersion mechanism: no mandatory field time for national leaders, no skip-level listening, no unfiltered complaint intake, no independent ombuds. **[A]** This is the classic disconnect your own risk register half-names ("national leadership disconnected") without a control.
2. **Unresolved apex authority.** CEO-vs-Council is UNRESOLVED **[S: Ch.33]**; there is no dispute-resolution clause in the constitution for a CEO–Council deadlock (Art.17 covers member disputes **[S: Const. Art.17]**). An organisation cannot scale past its own unresolved apex. **[I]**
3. **No mission lock, no succession, no key-person provision [S: Const. Art.3, Art.19; A].** For a *national institution* claim, this is disqualifying as written.
4. **National cost base vs. local revenue base.** National departments (Legal, AI & Data, Audit, Communications, Finance) are fixed costs funded by an organisation service fee drawn from local ventures **[S: Ch.18]**. If local ventures are weak, the national layer is unfunded — and an unfunded national layer either atrophies (losing the standards function) or starts demanding revenue (becoming the mission-drift engine). **[I]** There is no stated cross-subsidy policy: who pays for a mohalla team that is service-heavy and revenue-poor? Absent an answer, the network will drift toward richer neighbourhoods, contradicting Article 1. **[A]**

**National verdict [A]:** the national design is coherent as a *standards and assurance body*. It is not yet an *institution*. The gap is constitutional, not operational.

## 2.5 The cross-level structural faults (the ones that appear at every level)

| # | Fault | Mechanism **[A]** | Present control **[S]** | Sufficient? |
|---|---|---|---|---|
| 1 | **Control roles are socially costly and unsupported** | HR/Funds/Safety holders must say no to neighbours and friends | Role boundaries, conduct rules, audit | **No** — boundaries define what they can't do, not how they're protected |
| 2 | **Evidence burden scales with process, not with capacity** | Every claim needs evidence; evidence needs hours | Evidence standards, audits | **No** — no hours budget, no graduated fidelity |
| 3 | **Reward is a tournament with few prizes** | Leadership = the main reward; one Head Team per level | Eligibility gates, appeals, safeguards | **No** — no horizontal reward ladder |
| 4 | **Money promise precedes money reality** | Compensation protected in priority order; reserves fill late | Waterfall, bad-month rule | **No** — no cold-start float |
| 5 | **Perception is ungoverned** | Outsiders classify the org from silhouette, not from doctrine | Six DO-NOTs, comms rules | **No** — no dress/symbol/political-firewall/election protocol |
| 6 | **Verification centralises trust in one honest person per team** | Ground-Level Manager verifies; HR verifies; both are local | Segregation, audit, random checks | **Partially** — no cross-team verification rotation |
| 7 | **The software is assumed** | RBAC, append-only logs, dashboards, delegation expiry all presuppose a platform | Phase 1 exit gate allows "manual process" **[S: Ch.30]** | **No** — manual process cannot deliver the stated controls |

---

# 3. SEWAK SATHI FAILURE MAP

**How to read each entry.** Every failure is stated as a *mechanism*, not a label. Severity is justified explicitly against three axes: **likelihood** (will it happen without a new control?), **blast radius** (one team / one city / the whole institution), and **reversibility** (can it be undone once it happens?). A CRITICAL rating requires high likelihood *or* irreversible institutional damage.

**Severity scale used here:**
- **CRITICAL** — can end the organisation or its public legitimacy; often irreversible; or legally existential.
- **HIGH** — will occur without new controls; damages trust, retention, mission integrity or money over 12–36 months; recoverable with effort.
- **MODERATE** — predictable, containable by existing components plus discipline; recoverable.
- **LOW** — manageable as designed.

## Cluster A — Entry, motivation and human supply

### F-01 · The verification funnel converts almost nobody — **HIGH**

| Field | Content |
|---|---|
| **1. Failure** | Interested citizens arrive, meet a 12-stage membership lifecycle before they can do anything meaningful, and leave. The organisation ends up with a small, self-selected, highly compliant core and no broad base. |
| **2. Why it happens** | Value is *back-loaded*: application → screening → identity verification → interview → beginner training → probation → verified → role assignment **[S: Ch.12]**. Nothing in that chain delivers benefit to the applicant. Cost is front-loaded (documents, time, interviews, training). Volunteer research consistently shows unclear time expectations and mismatch between promise and reality drive early exit, and that the first year has the worst retention **[X]**. |
| **3. Early warning signs** | Applications started ≫ applications completed; median days-to-verification rising; drop-off concentrated at identity documents and at training scheduling; interview no-shows; "I just wanted to help once" appearing in exit conversations; a single mohalla team's membership flat while community requests rise. |
| **4. If ignored** | Growth depends entirely on personal networks of existing leaders → the organisation becomes a set of friendship circles with governance paperwork → no diversity of background → accusations of cliquishness → stagnation at pilot scale. |
| **5. Component supposed to prevent it** | Ch.12 lifecycle; Ch.11 vacancy/eligibility engine; Ch.10 "Supporting Member" tier. |
| **6. Is that control sufficient?** | **No.** The lifecycle is designed to protect *organisational integrity*, not to convert *citizen intent*. "Supporting Member" exists but is defined as an internal assigned position under a coordinator **[S: Ch.10]**, not as a public entry tier. |
| **7. Additional control needed** | A **public contribution tier below Verified Member** with no operational permissions, no restricted tasks, no access to records, and no vote — one that lets a person contribute within 48 hours while verification proceeds in parallel *only if they want responsibility*. See §9 for the full spectrum. **[P]** |
| **8. Owner** | National HR & Verification (design) + City Teams (delivery) + National Communications (framing). |
| **9. Evidence to record** | Funnel cohort report per city: started / documented / interviewed / trained / verified / first contribution, with median days per stage and drop-off reason codes; **time-to-first-contribution** as a headline metric. |
| **10. Recovery** | Retro-fit the tier; re-contact lapsed applicants ("you can still help this Saturday without completing verification"); shorten stage count for low-risk contributions. |
| **11. Worst case** | A permanently narrow organisation that looks like a private club with a national charter — and is described that way publicly. |
| **12. Architecture change needed?** | **Yes — MODIFY** (additive tier; does not weaken verification because permissions stay at Verified Member and above). |
| **Severity reasoning** | Likelihood **very high** (structural friction, not behavioural luck); blast radius **national** (it caps total participation); reversibility **high** (fixable later) → **HIGH**, not CRITICAL, only because it is fixable after the fact. |

### F-02 · Money-motivated influx, then disappointment — **HIGH**

| Field | Content |
|---|---|
| **1. Failure** | "Verified work = compensation" **[S: Ch.2, Ch.18]** becomes the recruitment message by word of mouth. People join expecting income. Venture revenue is insufficient or irregular. Members feel deceived; the service mission is crowded out; the most transactional members stay longest while the idealists leave. |
| **2. Why it happens** | In a labour market with abundant underemployment, any organisation that mentions payment will be *reclassified by the public as an employment scheme* regardless of what its documents say **[I]**. The architecture has no demand-side constraint: nothing limits intake to the amount of verified paid work actually available. |
| **3. Early warning signs** | Applicant questions dominated by "how much/when" rather than "what work"; attendance spikes on payment days and collapses between them; members declining non-paid service tasks; recruitment claims by local leaders about earnings; rising complaints about payment calculation. |
| **4. If ignored** | Reputation as a fake job scheme; possible complaints to labour authorities; members pressuring leaders to invent work → fake projects/fake revenue **[S: Ch.28]**; service pillars hollowed out. |
| **5. Component supposed to prevent it** | Ch.2 "serve without expecting reward" (while allowing compensation for verified work); Ch.18 waterfall; Ch.25 anti-gaming; Ch.28 risk "fake work/fake revenue". |
| **6. Is that control sufficient?** | **Partially.** It governs *reporting* honesty, not *recruitment* honesty. There is no rule that a member may not be recruited with an earnings claim, and no published earnings expectation. |
| **7. Additional control needed** | (a) **Published earnings reality statement** per city/venture category: typical weekly hours, typical range, and the explicit statement that income is not guaranteed **[P]**; (b) a **recruitment-conduct rule**: earnings claims without approved wording = ordinary violation **[P]**; (c) **intake throttling** tied to available verified work capacity **[P]**; (d) separate *service* and *earnings* tracks so a person can be in one without the other **[P]**. |
| **8. Owner** | National HR + National Business + City Team Leaders. |
| **9. Evidence** | Applicant expectation survey at intake and at 90 days; recruitment-material approval log; earnings-vs-expectation variance per team; complaint categories. |
| **10. Recovery** | Public correction, reset of expectations, prioritise service-track onboarding, offer skill training instead of income promise. |
| **11. Worst case** | The organisation is publicly described as a scheme that recruited poor people with income promises it could not meet. That single framing can end national trust. |
| **12. Architecture change needed?** | **Yes — MODIFY** (add recruitment-conduct and expectation-disclosure rules; add intake throttle). |
| **Severity reasoning** | Likelihood **high** (this is how such organisations are perceived everywhere); blast radius **institutional** (public trust); reversibility **low–medium** (a "fake job scheme" label is very hard to remove) → **HIGH**, escalating to CRITICAL if it becomes public before corrections. |

### F-03 · Nobody wants the unpopular control roles — **MODERATE**

| Field | Content |
|---|---|
| **1. Failure** | Teams cannot fill HR & Verification, Funds Manager, or Safety Lead. Roles are combined informally, defeating segregation of duties **[S: Ch.18]**, or remain vacant so verification/finance/safety discipline quietly stops. |
| **2. Why it happens** | These roles say "no" to friends and neighbours, handle other people's money and conduct records, and carry blame when things go wrong — with no stated reward, protection, or relief. The document lists what each role *cannot do* **[S: Ch.9]** in far more detail than what it *gets*. |
| **3. Early warning signs** | Same person holding Funds + HR + Warehouse "temporarily" for months; vacancies marked Open beyond two cycles; delegation records with no end date being renewed; audit findings about combined roles; reluctance in interviews for these roles. |
| **4. If ignored** | Segregation collapses → leakage risk rises → an incident occurs → the whole control architecture is retroactively discredited as theatre. |
| **5. Component supposed to prevent it** | Ch.10 sub-roles; Ch.11 vacancy lifecycle; Ch.22 "one role = one primary holder"; Ch.18 segregation. |
| **6. Is that control sufficient?** | **No.** It forbids the *pattern* without supplying the *person*. Prohibition without pipeline produces hidden non-compliance. |
| **7. Additional control needed** | **Control-role support package [P]**: fixed tenure with mandatory rotation, a named City-level backstop for every mohalla control role, protection-from-retaliation clause, priority access to training and paid work, and explicit recognition. Plus a **combined-role exception register** with expiry dates and City approval, so reality is recorded instead of hidden. |
| **8. Owner** | National HR + City Team Leaders + Audit. |
| **9. Evidence** | Vacancy ageing report; combined-role exception register with expiry; rotation completion; retaliation complaints by control-role holders. |
| **10. Recovery** | City-level shared control roles for small teams (a city Funds reviewer serving 10 mohallas) instead of pretending each team has one. |
| **11. Worst case** | Systemic off-the-books role combination; the first fraud occurs in a team where one person held money and records. |
| **12. Architecture change needed?** | **Yes — MODIFY** (permit and *regulate* city-shared control roles for State A teams; today the architecture implies each team must have them). |
| **Severity reasoning** | Likelihood **high**; blast radius **team/city** (but it is the precondition for financial fraud, which is institutional); reversibility **medium** → **MODERATE** as a standalone, **HIGH** when combined with F-24. |

### F-04 · Volunteer attrition as ordinary life happens — **MODERATE**

| Field | Content |
|---|---|
| **1. Failure** | Members leave for exams, jobs, marriage, migration, illness, childbirth, family duty. The organisation reads this as failure or disloyalty and responds with more tracking, accelerating exit. |
| **2. Why it happens** | Attrition from life circumstances is the *normal* condition of voluntary organisations: in one studied programme, over a quarter of departing volunteers left simply because they moved, and ~38% cited busyness with work/school or in general **[X]**. Indian life adds seasonal migration, exam cycles, and household duty. Your architecture has statuses (active, suspended, removed, resigned) **[S: Ch.12]** but no *dormant/paused* state and no re-entry path. |
| **3. Early warning signs** | Attendance falling without complaints; members going quiet rather than resigning; no "paused" status being used; rising share of members with zero activity in 60 days; leaders describing departures as betrayal. |
| **4. If ignored** | Perpetual recruitment treadmill; institutional memory loss; the same 20% doing everything; burnout of the core; a membership list that is numerically large and functionally small (which also corrupts metrics — see F-27). |
| **5. Component supposed to prevent it** | Ch.12 review stage; Volunteer Manager fatigue tracking **[S: Ch.9]**; Ch.25 "healthy active retention, not inactive names". |
| **6. Is that control sufficient?** | **No.** The architecture *detects* inactive members for metric hygiene but provides no humane mechanism to keep them affiliated. |
| **7. Additional control needed** | **"Sewak Sathi Alumni / Paused" status [P]**: retains identity and service record, removes operational permissions, allows one-tap return, and is explicitly *not* counted as active. Plus **exit interviews** and **stay interviews** — both are among the highest-rated retention interventions in volunteer research **[X]**. |
| **8. Owner** | HR & Verification + Volunteer Manager. |
| **9. Evidence** | Pause/resume rates; reactivation rate; exit-interview reason codes; 12-month cohort survival curves. |
| **10. Recovery** | Annual "come back for one project" invitation; festival-linked service events; recognition of past service preserved on return. |
| **11. Worst case** | A churn machine: constant recruitment, constant training cost, no accumulated memory, no long-term leaders — and long-term leadership is the entire succession model **[S: Ch.26]**. |
| **12. Architecture change needed?** | **Yes — MODIFY** (add paused/alumni status and re-entry path; add exit/stay interview SOPs — SOP set currently has none **[S: Appendix D]**). |
| **Severity reasoning** | Likelihood **certain**; blast radius **cumulative/organisational**; reversibility **high** → **MODERATE**, because it degrades rather than destroys — unless it runs for five years, at which point it prevents institutional memory entirely. |

## Cluster B — The local unit's viability

### F-05 · Compliance labour exceeds team capacity — **HIGH**

| Field | Content |
|---|---|
| **1. Failure** | The team spends more hours on records, reports, verification and approvals than on service and revenue. Either the paperwork is done badly (audit failure) or the work is done badly (mission failure) or both, and the team quietly stops complying. |
| **2. Why it happens** | Count the obligations a single Mohalla team carries: 10-step operating loop **[S: Ch.8]**; 12-step service loop **[S: Ch.15]**; 13-step weekly payment **[S: Ch.19]**; 22 SOPs **[S: Appendix D]**; 14 evidence record types **[S: Appendix F]**; daily/weekly/monthly reporting **[S: Ch.24]**; 8 autonomy gates **[S: Ch.13]**; vacancy lifecycle per appointment **[S: Ch.11]**; delegation records with start/end/reviewer **[S: Ch.10]**. **[A-assumption]** Even at 2 hours/week/team for records and reports plus 1 hour for verification, that is ~13 hours/month of pure governance for a 10-person volunteer team — i.e. roughly one full person-equivalent per team, before any service or business work. Sensitivity: if the true figure is 6 hours/month it is survivable; if it is 25 hours/month the unit cannot exist. **The document has no estimate at all**, which is itself the finding. |
| **3. Early warning signs** | Reports filed late then back-filled; identical photo evidence across projects; weekly payment sheets completed after payment rather than before; "we'll do the record later" becoming normal; autonomy gate failures concentrated in *documentation* rather than *performance*. |
| **4. If ignored** | Two possible outcomes, both bad: (a) audit finds systemic non-compliance and the network is declared unready → expansion freezes; (b) audits are softened to keep the network growing → the control system becomes ceremonial → the first real fraud is undetected. |
| **5. Component supposed to prevent it** | Ch.28 risk "centralisation/bureaucracy — local delays, too many forms"; Ch.13 central standards vs central control. |
| **6. Is that control sufficient?** | **No.** The risk is *named* with a generic remedy ("autonomy charter, lean processes; delegate and simplify") but there is no measured compliance-hour budget and no rule that a new control must be paid for by removing one. |
| **7. Additional control needed** | (a) **Time-and-motion study in the pilot** measuring actual governance hours per team per month **[P, V]**; (b) a **two-tier evidence standard**: "Pilot Fidelity" (6 mandatory records) vs "Full Fidelity" (all 14), with promotion between them tied to team maturity **[P]**; (c) a **control-budget rule**: any new mandatory record requires either automation or the retirement of an existing one **[P]**; (d) auto-generated reports from the platform so humans supply facts, not formatting **[P]**. |
| **8. Owner** | National Operations + AI & Data + Audit & Ethics. |
| **9. Evidence** | Governance hours per team per month; report lateness distribution; share of records auto-populated; audit findings by category (documentation vs. substance). |
| **10. Recovery** | Cut the mandatory set for teams below a maturity threshold; move verification sampling to City level; automate. |
| **11. Worst case** | A network that is *documentarily* perfect and *operationally* hollow — or the reverse. Either way, the evidence-based culture that is the architecture's core claim becomes false. |
| **12. Architecture change needed?** | **Yes — MODIFY** (graduated fidelity; measured hour budget; control-budget rule). |
| **Severity reasoning** | Likelihood **very high** (arithmetic, not behaviour); blast radius **all teams**; reversibility **medium** (culture of back-filling is hard to remove once normalised) → **HIGH**. |

### F-06 · Weekly payment meets lumpy local revenue — **HIGH**

| Field | Content |
|---|---|
| **1. Failure** | Some weeks there is nothing to distribute. Members who joined on the "transparent weekly compensation" idea experience two or three empty weeks and conclude they were misled. Alternatively the organisation smooths payments from money it does not have, creating a hidden liability. |
| **2. Why it happens** | The cycle is fixed (Monday–Sunday, 13 steps, distributable amount "calculated under approved waterfall, not gross receipts" **[S: Ch.19]**), while local service/SME revenue in India is irregular, festival-linked, and collection-lagged **[I]**. Reserves sit at priority 6 and therefore do not exist early **[S: Ch.18]**. |
| **3. Early warning signs** | Weeks with zero distributable amount; member payment counts falling while member counts hold; invoices raised but not collected; rising advance/loan requests; leaders paying from personal funds "temporarily". |
| **4. If ignored** | Attrition of exactly the members you most need (those doing paid delivery work); informal personal lending inside teams (creating debt-based loyalty — an unhealthy retention mechanism, §7); venture abandonment. |
| **5. Component supposed to prevent it** | Ch.18 waterfall + reserves/wage-protection buffer; Ch.19 audit trail; Ch.20 social-impact fund (explicitly *not* for salaries). |
| **6. Is that control sufficient?** | **No — sequence error.** The buffer is *downstream* of the revenue it is supposed to stabilise. There is no cold-start instrument anywhere in the document. |
| **7. Additional control needed** | **A "first-season float" [P, V]**: a small, time-bound, explicitly accounted advance against future distributable amounts for teams in months 1–6, with a cap, an approval, and a repayment/reconciliation rule. Alternatives: (i) minimum guaranteed paid hours from a *national* pool funded by organisation service fees once they exist; (ii) shift early teams to fortnightly/monthly distribution and be explicit about it; (iii) seed each pilot team with one anchored, contracted revenue source (a single SME retainer or a single institutional service contract) before launch rather than after. All require financial and tax validation. |
| **8. Owner** | National Finance + National Business + CEO. |
| **9. Evidence** | Weekly distributable-amount series per team; float outstanding and ageing; member payment continuity rate (% of members paid in ≥8 of 12 weeks). |
| **10. Recovery** | Public reset of payment expectations; convert to monthly cycle for struggling teams; redeploy members to teams with revenue. |
| **11. Worst case** | Unpaid labour inside an organisation that publicly promises transparent compensation — a reputational and potentially legal exposure **[V]**. |
| **12. Architecture change needed?** | **Yes — MODIFY** (add cold-start float or anchored-revenue precondition to Phase 2 exit gate **[S: Ch.30]**). |
| **Severity reasoning** | Likelihood **very high** (revenue lumpiness is a property of the market, not of the team); blast radius **team + public trust**; reversibility **medium** → **HIGH**. |

### F-07 · The Starter Team that never grows past five people — **MODERATE**

| Field | Content |
|---|---|
| **1. Failure** | A team forms around one energetic leader plus four relatives/friends, stays at that size for two years, and functions as a personal initiative wearing organisational branding. |
| **2. Why it happens** | State A permits role combination **[S: Ch.10]**, which is correct and necessary — but there is no *growth obligation* and no time limit on State A. The minimum-staffing thresholds are explicitly NOT FINAL **[S: Ch.33]**. Comfort plus low accountability produces stable smallness. |
| **3. Early warning signs** | No new verified members in 2 quarters; no vacancy ever opened; all decisions by one person; no delegation records; the same 3 people in every photo; community requests declining because residents have learned "that group is just those people". |
| **4. If ignored** | The network's *team count* grows while its *capability* does not; a single exit (job, marriage, illness) ends the team; leadership succession never develops. |
| **5. Component supposed to prevent it** | Ch.13 team formation and growth; Ch.11 vacancies; Ch.25 member development metric (10%); Ch.14 recovery. |
| **6. Is that control sufficient?** | **Partially.** Member development is a weighted metric, but weights are unapproved **[S: Ch.25]** and there is no minimum growth expectation for a team to remain in good standing. |
| **7. Additional control needed** | **Team maturity clock [P]**: a State A team has a defined window (e.g. 2–4 quarters) to reach minimum verified-member and role-coverage thresholds or to be merged/supported/re-scoped — with support offered first, consistent with Ch.14. Also a **"second leader" rule**: no team remains in good standing with zero trained deputies after two cycles. |
| **8. Owner** | City Operations + State support (when it exists). |
| **9. Evidence** | Team age vs. member count; deputy coverage; vacancy openings per team per year; merger/support decisions. |
| **10. Recovery** | Merge into a neighbouring team; convert to a "community participant group" tier (§9) rather than a full team; re-seed with a coordinator from a stronger team. |
| **11. Worst case** | Hundreds of nominal teams, few real ones — and a national count that is a lie in the exact way Ch.15 forbids ("do not count planned activities as completed impact"). |
| **12. Architecture change needed?** | **Yes — MODIFY** (add maturity clock and deputy-coverage minimum; both need thresholds approved per Ch.33). |
| **Severity reasoning** | Likelihood **high**; blast radius **network quality and metric integrity**; reversibility **high** → **MODERATE**. |

## Cluster C — Power, politics and legitimacy

### F-08 · Political capture or the perception of it — **CRITICAL**

| Field | Content |
|---|---|
| **1. Failure** | The organisation is used by, infiltrated by, or publicly identified with a political party, faction, caste association, or communal mobilisation — with or without anyone inside intending it. |
| **2. Why it happens** | A mass-membership network with local presence, service delivery credibility, a protection function, ranked teams and a single recognised founder is *exactly* the asset a political actor wants **[I]**. Approaches will come as sponsorship offers, "help during elections", requests to distribute material, requests to mobilise a crowd, or offers of free media. The architecture contains **no rule** on party office-holding by members, election-period conduct, political donations, use of the brand at political events, or refusal protocols. **[A]** Independently: an Indian tax-exempt entity must not engage in political activity or support parties/candidates, and 12A registration can be jeopardised if it does **[X]** — so this is also a **tax-existence** issue, not only a reputation issue. |
| **3. Early warning signs** | A leader's political affiliation becoming known locally and being used in recruitment; service events scheduled near elections; material distributed with a politician's name alongside the org's; requests to "arrange a crowd"; social-media posts by team accounts engaging in partisan commentary; local officials treating the org as an affiliate; members of one community disproportionately represented or absent in a team. |
| **4. If ignored** | Loss of tax-exempt eligibility **[X]**; police/administrative suspicion; the organisation's service work read as mobilisation; communities that oppose the associated faction withdraw; violence risk at events; media framing becomes permanent; the mission ("help without discrimination" **[S: Ch.2]**) becomes factually false in the eyes of half the locality. |
| **5. Component supposed to prevent it** | Ch.2 non-discrimination principle; Ch.24 communications rules and authorised spokespersons; Ch.28 risk "mission drift" and "reputational/safeguarding failure"; Ch.29 partnership due diligence; National Legal & Compliance **[S: Ch.5]**. |
| **6. Is that control sufficient?** | **No — this is the largest single gap in v1.2.** Non-discrimination governs *service delivery*, not *organisational alignment*. Partnership due diligence covers formal partners, not informal political patronage. Communications rules cover *publication*, not *association*. Nothing addresses a member who is a party office-bearer. |
| **7. Additional control needed** | **A Political Neutrality Code [P, V]** as a constitutional article: (i) no use of organisational role, brand, records, events, distribution or member lists for any partisan purpose; (ii) declared conflict rule — a person holding party office or a candidacy may not hold an organisational role (or must suspend it, published); (iii) election-period protocol: freeze on mass distribution events and on new public-facing campaigns for a defined window, with an exception process for genuine emergencies; (iv) refusal script and escalation path for political approaches, owned by National Legal; (v) a public, standing statement of non-alignment in every onboarding and public document; (vi) audit test: sampling of events for political adjacency. All of this requires legal and tax validation. |
| **8. Owner** | National Legal & Compliance + CEO + proposed Council + Audit & Ethics. |
| **9. Evidence** | Conflict declarations register; refusal log (approaches received and declined); event-calendar review near elections; complaint records; media-mention classification. |
| **10. Recovery** | Immediate suspension of implicated leaders; public statement; independent review; re-training; if tax status is affected, professional remediation. Recovery is possible but expensive and slow. |
| **11. Worst case** | The organisation becomes, in public memory, a political front. Service work continues but trust across communities does not. This is effectively unrecoverable inside one generation. |
| **12. Architecture change needed?** | **Yes — MODIFY (urgent, pre-launch).** Add a constitutional article and a standing SOP. This is the highest-priority change in this report. |
| **Severity reasoning** | Likelihood **high over a 5-year horizon** (any organisation of this shape in India gets approached); blast radius **institutional, existential**; reversibility **very low** → **CRITICAL**. |

### F-09 · Vigilante perception after a single incident — **CRITICAL**

| Field | Content |
|---|---|
| **1. Failure** | Members intervene in a theft, harassment, accident or dispute; someone is injured or a video circulates; the organisation is nationally described as a vigilante outfit, whatever the internal doctrine says. |
| **2. Why it happens** | The doctrine is sound: protect → de-escalate → contact authorities → first aid if trained → physical intervention only if reasonably necessary and lawful → document → review; six explicit DO-NOTs **[S: Ch.16]**. But doctrine governs *trained intent*, while perception is formed by *one clip*. Three amplifiers: (i) a mass membership with a protective identity invites self-selection of people who want authority **[I]**; (ii) members are not professionals and will misjudge risk; (iii) once labelled, the label attracts further incidents and further self-selection. |
| **3. Early warning signs** | Members describing themselves as "keeping the area safe" in public posts; language of "teaching a lesson"; formation of informal night groups; any member carrying anything weapon-like; complaints from residents about the org's presence being intimidating; incident reports where the member was the initiator rather than responder. |
| **4. If ignored** | Criminal cases against members; police hostility; a statewide or national media story; loss of the ability to operate in public; collapse of the protection pillar; guilt by association damaging the service pillar. |
| **5. Component supposed to prevent it** | Ch.16 doctrine + DO-NOT panel + risk-tier matrix; SOP-13 Safety Incident; Ch.28 risk "unsafe protection"; training category "emergency response/first aid" **[S: Ch.12]**; caveat that internal training is not legally sufficient **[S: Ch.12]**. |
| **6. Is that control sufficient?** | **Substantially yes on behaviour; no on visibility.** Missing entirely: dress/symbol/uniform policy; rules about patrolling or group movement; a rule on recording/filming interventions; a public statement of what the organisation is *not*; media protocol specific to protection incidents; a "do not attend" list (e.g. communal tension, political processions, any situation with weapons present). |
| **7. Additional control needed** | **Protection Visibility Protocol [P, V]**: no uniform or uniform-like dress; no insignia that suggests authority; no patrolling; members never move as a group to an incident beyond two persons; no filming of interventions by members (authorities and designated documentation only); a published "we are not a security force, we do not carry weapons, we call the police" statement in onboarding and public material; a mandatory **do-not-attend list**; incident media protocol with a single national spokesperson; legal review of the intervention boundary against BNSS/BNS provisions, including the private-person arrest provision and the six-hour handover requirement **[X]** and the general obligation of the public to assist police when lawfully demanded **[X]**. Insurance before any protection activity is publicised. |
| **8. Owner** | National Safety/Protection + National Legal + National Communications. |
| **9. Evidence** | Incident records with initiator/responder classification; training completion for safety roles; refusal/do-not-attend compliance; media mention classification; complaints from residents about presence. |
| **10. Recovery** | Immediate stand-down of the protection function in the affected area; independent review; publication of findings; personal legal support for members who acted in good faith within policy; re-training. |
| **11. Worst case** | A death or serious injury during an intervention, with the organisation's name attached. Legal, financial, reputational and moral catastrophe simultaneously. |
| **12. Architecture change needed?** | **Yes — MODIFY.** Keep the doctrine verbatim; add the visibility protocol, do-not-attend list, dress/symbol rules and legal review. Consider **RECONSIDER**-ing whether "Protection / First Response" should be publicly named as a *pillar* in the first 2–3 years, versus being internally trained and externally described as "emergency support and community safety awareness". That is a naming/sequencing decision, not a doctrine change — and it is yours to make. |
| **Severity reasoning** | Likelihood **medium-high** (any street-facing mass organisation eventually has an incident); blast radius **institutional**; reversibility **very low** (video does not expire) → **CRITICAL**. |

### F-10 · Protection incident without insurance or legal cover — **CRITICAL**

| Field | Content |
|---|---|
| **1. Failure** | A member is injured, injures someone, or is charged after acting in the organisation's name. There is no insurance, no legal-aid protocol, no notification procedure, and no defined organisational responsibility. The individual is abandoned; the organisation is sued or prosecuted. |
| **2. Why it happens** | Insurance is listed in the launch checklist as a blocker requiring "insurance advice/coverage decision" **[S: Ch.31]** and appears in the decision register as unresolved **[S: Ch.33]**. Meanwhile the protection pillar is described as a *core function* **[S: Ch.3]**. **[A]** The architecture permits promotion of a function whose liability wrapper does not exist. |
| **3. Early warning signs** | Any protection activity publicised before cover is in place; members asking "who pays if I get hurt"; incident reports with no legal review field; a first-aid intervention performed by a member without certification. |
| **4. If ignored** | Personal financial ruin for a member acting in good faith → the most damaging possible internal story ("they left him to face the case alone") → nobody will ever hold a safety role again. |
| **5. Component supposed to prevent it** | SOP-13; Ch.28 risk response "suspend, authority contact"; Ch.5 National Legal & Compliance; Ch.31 checklist. |
| **6. Is that control sufficient?** | **No.** These are process controls for *handling* an incident, not financial/legal instruments for *absorbing* one. |
| **7. Additional control needed** | **Pre-launch liability package [P, V]**: (i) personal accident cover for active members; (ii) public liability / third-party cover for events and service activities; (iii) professional indemnity where advice is given; (iv) a written legal-support protocol (who instructs counsel, within how many hours, at whose cost); (v) an incident notification SLA to National Legal; (vi) explicit scope statement of what is *not* covered, so members are never misled; (vii) mandatory certified first aid before any first-aid role, per the document's own caveat **[S: Ch.12]**. All items require professional validation. |
| **8. Owner** | National Legal & Compliance + National Finance + CEO. |
| **9. Evidence** | Policy documents, certificates per member, claim register, legal-support invocation log, notification timestamps. |
| **10. Recovery** | Retroactive cover is often unavailable for known events — hence pre-launch necessity. If an incident occurs uncovered: immediate organisational legal support anyway (moral and reputational necessity), then structural remediation. |
| **11. Worst case** | A member imprisoned or bankrupted after acting on the organisation's doctrine. There is no version of this that the organisation survives intact. |
| **12. Architecture change needed?** | **Yes — MODIFY.** Add insurance and legal-support as an explicit *precondition* to any publicised protection activity, not merely a launch-checklist item. |
| **Severity reasoning** | Likelihood **medium**; blast radius **institutional + individual, irreversible harm**; reversibility **none** → **CRITICAL**. |

### F-11 · Founder concentration without mission lock or succession — **CRITICAL**

| Field | Content |
|---|---|
| **1. Failure** | The institution's legal purpose, brand, reserves and social-impact fund are all downstream of one person's ownership of the parent. If that person dies, is incapacitated, is discredited, changes their mind, sells Krytos, or is pressured, nothing in the architecture prevents redirection of the institution. |
| **2. Why it happens** | Article 3 vests ownership in Krytos under the founder/CEO, with the Council explicitly *not* above the CEO unless a charter changes it **[S: Const. Art.3]**. CEO-vs-Council authority is UNRESOLVED **[S: Ch.33]**. Article 19 treats dissolution/restructuring only as "requires professional validation" **[S: Const. Art.19]**. There is no founder-succession article, no incapacity provision, no irrevocable purpose clause, no golden-share/protective-vote mechanism. **[A]** |
| **3. Early warning signs** | Decisions of constitutional magnitude taken without a recorded governance process; amendments made without versioning (contrary to Art.18 **[S]**); no written succession discussion after 12 months; the Council not yet constituted while the network grows. |
| **4. If ignored** | Institutional investors, partners, government counterparts and serious professionals decline to engage (they do due diligence on continuity); long-serving members hedge their commitment; a succession event forces an improvised outcome. |
| **5. Component supposed to prevent it** | Art.18 versioned amendments; Ch.26 dynamic leadership and succession (for *teams*, not for the apex); Ch.33 decision register (flags the issue honestly). |
| **6. Is that control sufficient?** | **No.** Ch.26 solves succession *below* the CEO. Nothing solves succession *of* the CEO or continuity *of* the mission. |
| **7. Additional control needed** | **Mission-lock instrument [P, V]**, options in ascending strength: (i) an irrevocable purpose clause in the governing document of the operating entity, with amendment requiring a supermajority plus a cooling-off period plus publication; (ii) a Council charter with a *suspensive veto* (not ownership) over constitutional amendment, transfer of the brand, transfer of reserves/social-impact fund, and change of mission — while the CEO retains full executive authority over operations; (iii) a founder-succession article: nominated successor process, incapacity trigger, interim authority, and a requirement that the successor be bound by the same constitution; (iv) at national scale, a federated structure where the mission is held by a body that no single shareholder controls. Requires legal and tax validation and, critically, the founder's own willingness — which is a decision, not an analysis. |
| **8. Owner** | CEO + proposed National Council + external legal counsel. |
| **9. Evidence** | Executed charter; versioned constitution with amendment log; succession plan document with review date; Council minutes. |
| **10. Recovery** | Very difficult after a succession event; straightforward before one. This is a *now* item. |
| **11. Worst case** | A national institution with lakhs of members and real community trust is legally repurposed or dissolved by a decision no member can contest. |
| **12. Architecture change needed?** | **Yes — MODIFY (constitutional).** Note the tension: this *reduces* founder flexibility, which the architecture currently protects **[S: Ch.4 "broad executive flexibility"]**. That trade-off is real and must be decided deliberately. |
| **Severity reasoning** | Likelihood **low in any given year, near-certain over 20 years**; blast radius **total**; reversibility **none** → **CRITICAL**. |

### F-12 · CEO–Council deadlock with no resolution mechanism — **HIGH**

| Field | Content |
|---|---|
| **1. Failure** | The Council (once constituted) and the CEO disagree on a matter of standards, ethics, audit finding or a senior appointment. There is no rule for who prevails, so the dispute is settled by power, and the loser's supporters factionalise. |
| **2. Why it happens** | The document *intentionally* leaves this unresolved and says so **[S: Ch.4, Ch.33]** — which is honest but means the operating system has no kernel panic handler. Article 17 provides dispute routes for *members*, not for the apex **[S]**. |
| **3. Early warning signs** | Council recommendations repeatedly "noted" without action; audit findings closed without remediation; parallel communication channels forming; senior resignations citing "differences". |
| **4. If ignored** | Governance layer becomes decorative → audit loses authority → the control system degrades from the top. |
| **5. Component supposed to prevent it** | Ch.33 decision register (tracks it); Ch.27 audit; proposed Council design. |
| **6. Is that control sufficient?** | **No** — tracking an unresolved item is not resolving it. |
| **7. Additional control needed** | **Apex dispute clause [P, V]**: define (i) the Council's exact reserved matters (a short list: constitutional amendment, mission change, brand/reserve transfer, CEO conduct, audit independence, appointment/removal of the head of Audit & Ethics); (ii) a resolution ladder — written positions, 14-day cooling period, joint session, then an external mediator/arbiter drawn from a pre-agreed panel; (iii) a rule that operations continue under the CEO's authority during any dispute, so the network is never paralysed; (iv) mandatory publication of the *existence* (not the content) of unresolved apex disputes in the annual report — transparency as the discipline. |
| **8. Owner** | CEO + Council + external counsel. |
| **9. Evidence** | Charter; dispute log; mediation records; annual-report disclosure. |
| **10. Recovery** | Charter amendment after the first dispute is much harder than before it. |
| **11. Worst case** | A public split at the apex; two factions claim legitimacy; the network fractures along that line. |
| **12. Architecture change needed?** | **Yes — MODIFY.** Resolve the UNRESOLVED item before constituting the Council, not after. |
| **Severity reasoning** | Likelihood **high once a Council exists** (all governance dyads conflict eventually); blast radius **institutional**; reversibility **medium** → **HIGH**. |

### F-13 · Local teams become independent power centres — **MODERATE→HIGH**

| Field | Content |
|---|---|
| **1. Failure** | A strong Mohalla or City leader controls members, community relationships, local revenue and the neighbourhood's perception of the brand — then negotiates with the organisation as an external party, refuses a standard, or leaves and takes the network with them. |
| **2. Why it happens** | Trust in India is *personal and local* **[I]**. The architecture deliberately builds local autonomy **[S: Ch.13]** and local credibility — which is correct — but it never specifies who owns the *channel* to members (phone lists, groups), who owns the *brand* at local level, or what a departing leader may and may not do. Risk register names "team collapse" and "leader abuse" **[S: Ch.28]** but not secession. |
| **3. Early warning signs** | A team's communication happening entirely in a leader-owned group; members saying "we joined X-bhai's team"; refusal to submit a report "because it is internal"; local branding variants appearing; a leader publicly disagreeing with a national standard before raising it internally. |
| **4. If ignored** | Standards become optional where strongest leaders are; the network's comparability collapses; a defection becomes a public story about the organisation "losing" a district. |
| **5. Component supposed to prevent it** | Ch.6 state authority limits; Ch.13 autonomy conditional on central standards; Ch.27 audit; Ch.22 RBAC and data ownership. |
| **6. Is that control sufficient?** | **Partially.** Strong on *authority limits*, silent on *relationship and brand portability*. |
| **7. Additional control needed** | (i) **Organisation-owned communication channel** as the primary member channel, with leader-owned groups permitted only as a supplement **[P]**; (ii) a **brand-use and post-exit conduct rule**: on resignation/removal, a leader may not use the name, marks, records or member lists for a competing activity for a defined period, and must hand over records and access **[P, V]**; (iii) **cross-team rotation** for control roles and reviewers, which also fixes F-26 **[P]**; (iv) a **standard-change request route**, so a leader who objects to a standard has a legitimate channel instead of informal refusal **[P]**. |
| **8. Owner** | National Operations + National HR + National Legal + Audit. |
| **9. Evidence** | Channel ownership register; handover checklists on every exit; rotation log; standard-change requests and outcomes. |
| **10. Recovery** | Support-first per Ch.14 **[S]**; if secession occurs, protect the members' records and the community relationship by continuing service through remaining members rather than by public conflict. |
| **11. Worst case** | Fragmentation into branded fiefdoms; the national name becomes a label of convenience. |
| **12. Architecture change needed?** | **Yes — MODIFY.** |
| **Severity reasoning** | Likelihood **medium** (only where leaders are strong and standards are unfunded — see F-29); blast radius **city/state**; reversibility **medium** → **MODERATE**, rising to **HIGH** once the network exceeds ~50 teams because the incentive to defect grows with the value of the brand. |

### F-14 · National leadership disconnects from the ground — **MODERATE**

| Field | Content |
|---|---|
| **1. Failure** | National decisions are made from aggregates and dashboards; ground realities (a standard that cannot be met, a payment formula that produces absurd results, a verification step that humiliates applicants) are never felt upward. Standards become resented; the centre becomes a rumour. |
| **2. Why it happens** | Four layers of aggregation **[S: Ch.4]**, upward-only data minimisation **[S: Ch.6]**, and an escalation filter designed to prevent national overload **[S: Ch.6]**. All three are individually correct; combined they create an epistemic wall. There is no downward immersion mechanism anywhere in the document. **[A]** |
| **3. Early warning signs** | National documents referencing metrics but never naming a mohalla; no field visits in a quarter; exception requests rising; local teams adopting informal workarounds; survey sentiment diverging between national and ground levels. |
| **4. If ignored** | Standards drift into non-compliance; the organisation loses the ability to detect its own failures; the "central standards" claim becomes aspirational. |
| **5. Component supposed to prevent it** | Ch.5 National Operations readiness and state support; Ch.24 dashboards; Ch.27 audit; Ch.28 risk "centralisation/bureaucracy". |
| **6. Is that control sufficient?** | **No.** All of these pull *data* up. None push *people* down. |
| **7. Additional control needed** | (i) **Mandatory field immersion**: every national and state leader spends a defined number of days per quarter working *inside* a mohalla team in a non-command capacity, with a written observation report to the Council **[P]**; (ii) **skip-level listening**: a standing channel where any member can send an observation directly to National without their leader's knowledge, logged and acknowledged, with privacy protection **[P]**; (iii) an **independent ombuds/grievance function** reporting to the Council rather than to the line **[P]** — this also fixes F-21; (iv) publish at national level a monthly "three things the ground told us" note, closing the loop visibly **[P]**. |
| **8. Owner** | National Operations + proposed Council + Audit & Ethics. |
| **9. Evidence** | Field-day log per leader; observation reports; skip-level intake and resolution times; "ground told us" notes. |
| **10. Recovery** | Reset a standard that has failed in the field and say so publicly — the fastest way to restore belief that the centre listens. |
| **11. Worst case** | A large, compliant-on-paper, disconnected organisation that cannot see its own decline. |
| **12. Architecture change needed?** | **Yes — MODIFY** (add downward mechanisms; keep upward minimisation). |
| **Severity reasoning** | Likelihood **high** (structural); blast radius **network-wide but slow**; reversibility **high** → **MODERATE**. |

## Cluster D — Money, fairness and leakage

### F-15 · Leader multiplier perceived as self-dealing — **MODERATE**

| Field | Content |
|---|---|
| **1. Failure** | Leaders receive "the same framework with higher allocation" **[S: Ch.19]** while the multiplier is NOT FINAL **[S: Ch.33]**. Members conclude leaders enrich themselves from collective work — the single most corrosive belief available in a volunteer-plus-earnings organisation. |
| **2. Why it happens** | Undisclosed differential pay plus concentrated local authority plus no published rationale. Even a *fair* multiplier reads as unfair if unexplained. |
| **3. Early warning signs** | Questions in team meetings about "who decides the leader share"; members comparing payment sheets; a leader's allocation rising while team revenue falls; resignation letters mentioning fairness. |
| **4. If ignored** | Attrition of honest members; retention of transactional ones; leaders become reluctant to publish anything; a fairness complaint becomes a public allegation. |
| **5. Component supposed to prevent it** | Ch.18 segregation; Ch.19 audit trail with formula version; Ch.27 financial audit; Ch.25 financial-discipline weight. |
| **6. Is that control sufficient?** | **Partially** — the *audit* control is strong; the *legitimacy* control is absent. Audit proves correctness after resentment has formed. |
| **7. Additional control needed** | (i) **Publish the multiplier rationale and the band**, even before final approval — publish it as "proposed, under validation" **[P]**; (ii) tie leader differential to *verified additional responsibility* (hours of coordination, number of approvals carried, on-call safety duty), not to team revenue alone, so it cannot read as a commission **[P]**; (iii) cap the ratio between the highest and lowest allocation in a team and publish the cap **[P, V]**; (iv) never allow a leader to approve their own allocation (already implied by segregation — make it explicit in the payment SOP) **[P]**. |
| **8. Owner** | National Finance + National HR + Audit. |
| **9. Evidence** | Formula version per payment sheet; approval chain showing the leader absent from their own approval; published band; fairness complaints. |
| **10. Recovery** | Publish a plain-language explanation with worked examples; correct any past payment found unfair. |
| **11. Worst case** | The organisation is internally described as "leaders eat first" — after which no control system is believed. |
| **12. Architecture change needed?** | **Yes — MODIFY** (transparency and responsibility-linkage; the priority order stays untouched). |
| **Severity reasoning** | Likelihood **high**; blast radius **team and network morale**; reversibility **high** (transparency is cheap) → **MODERATE**. |

### F-16 · Financial leakage in small, close-knit, cash-handling teams — **HIGH**

| Field | Content |
|---|---|
| **1. Failure** | Money leaks: unrecorded cash, inflated expenses, related-party suppliers, stock "losses", donation diversion, payment-sheet inflation, or plain non-payment of a member's share. |
| **2. Why it happens** | Segregation of duties requires *different people* **[S: Ch.18]**, but a 6–10 person neighbourhood team consists of people who are socially intimate, mutually dependent, and possibly related. Collusion cost is near zero where the social cost of refusing is high **[I]**. Cash remains common in local Indian commerce **[X]**, and cash is the least traceable medium. |
| **3. Early warning signs** | Cash receipts without digital trace; the same supplier recurring across teams; expense claims clustering just below approval limits; stock counts differing systematically in one direction; a member reporting they were paid less than the sheet shows; delayed reconciliation becoming normal. |
| **4. If ignored** | Worker compensation — the *first* priority in your own waterfall **[S: Ch.18]** — is the thing that gets stolen. That converts a financial failure into a moral failure and destroys the organisation's core promise. |
| **5. Component supposed to prevent it** | Ch.18 controls; Ch.19 reconciliation and audit trail; SOP-07 donations, SOP-08 expenses, SOP-09 weekly payment, SOP-10 reserve release **[S: Appendix D]**; Appendix F revenue/expense evidence standards; Ch.28 risk "financial fraud"; RBAC financial permission profiles **[S: Ch.22]**. |
| **6. Is that control sufficient?** | **Design yes, deployment no.** The controls are excellent and are all *documentary*. They assume the documents are created contemporaneously by people who are not colluding. At State A team size, that assumption fails. |
| **7. Additional control needed** | Move the control **up a level and into the rails**: (i) **digital-first receipts** — customer payments to an org-owned account/UPI ID, never to a personal one **[P]**; (ii) **city-level accounting** for State A teams (the mohalla supplies facts, the city prepares and reviews the sheet) **[P]**; (iii) **cross-team review rotation** — a Funds reviewer from a *different* city reviews a sample monthly **[P]**; (iv) **member payment confirmation** — every listed member confirms receipt through a one-tap channel; unconfirmed entries are auto-flagged **[P]**; (v) **published approval limits** so members know what a leader may and may not spend **[P]**; (vi) an anonymous financial-integrity reporting channel (see F-21). |
| **8. Owner** | National Finance + Audit & Ethics + City Finance Review. |
| **9. Evidence** | Digital-vs-cash receipt ratio; reconciliation ageing; cross-team review findings; member payment-confirmation rate; supplier concentration; expense distribution around approval thresholds. |
| **10. Recovery** | Freeze discretionary spending and reconcile **[S: Ch.14]**; repay affected members first, publicly; audit/suspend if fraud suspected **[S: Ch.14]**; publish the outcome to the affected team. |
| **11. Worst case** | A proven case of a leader underpaying members while the organisation advertises worker-first compensation. That is the story a competitor or a hostile journalist would choose. |
| **12. Architecture change needed?** | **Yes — MODIFY** (keep segregation as principle; relocate its *implementation* to city level and digital rails for small teams). |
| **Severity reasoning** | Likelihood **high** (opportunity + intimacy + cash); blast radius **core promise + legal exposure**; reversibility **medium** → **HIGH**. |

### F-17 · Service becomes dependent on business; business becomes the mission — **HIGH**

| Field | Content |
|---|---|
| **1. Failure** | Revenue-generating work consumes the team's best people and hours; service projects become occasional photo events; the organisation drifts into being a small business network with a service appendix. |
| **2. Why it happens** | Incentive asymmetry, not bad intent: revenue is immediate, measurable, and pays people; service impact is delayed, contestable, and pays nobody. Business performance carries 15% of the score and *also* funds compensation; mission impact carries 20% and funds nothing **[S: Ch.25, Ch.18]**. Rational actors follow the money. The risk register names "mission drift — revenue over service/safety" **[S: Ch.28]**, which shows the designers saw it. |
| **3. Early warning signs** | Service project count falling while venture count rises; the same members appearing only on paid work; service reports dominated by awareness events rather than outcomes; leaders describing service as "what we do when we have time"; social-impact contributions falling to zero for consecutive quarters while organisation fees continue. |
| **4. If ignored** | The founding proposition becomes false; the membership that joined for service leaves; the organisation's differentiation from an ordinary agency disappears; donor/public trust (which is *service*-based) erodes while revenue (which is *market*-based) cannot replace it. |
| **5. Component supposed to prevent it** | Ch.2 "not charity-only" but also mission primacy; Ch.25 balanced weights; Ch.28 mission-drift risk with response "rebalance score, close ventures; CEO/Council"; Ch.20 social-impact fund restrictions. |
| **6. Is that control sufficient?** | **No.** The control is *detective and discretionary* (rebalance the score) rather than *structural*. Nothing obliges a team to do service, and nothing limits how much of a team's capacity may go to business. |
| **7. Additional control needed** | **Structural firewalls [P]**: (i) a **service floor** — a team in good standing must complete a minimum number of verified service outcomes per quarter, defined by team size and local need, or its score is capped regardless of revenue; (ii) a **capacity ceiling** — a defined maximum share of a team's logged hours that may go to commercial work (with emergency exceptions); (iii) **separate P&L ownership** — the AI & Business Manager may not also hold Funds or audit roles in the same team (extend segregation to *mission* conflict, not only financial conflict); (iv) **service-first scheduling** — during a declared local emergency or a committed service project, commercial work is deferred by rule; (v) publish an annual **mission-balance statement**: hours and outcomes split service vs. commercial, per city and nationally. |
| **8. Owner** | CEO + National Operations + National Business + Audit & Ethics. |
| **9. Evidence** | Hours split by pillar; verified service outcomes per team per quarter; score-cap applications; mission-balance statement; venture closures for mission conflict. |
| **10. Recovery** | Rebalance by rule not by appeal; close or transfer ventures that structurally conflict; re-recruit service-motivated members through the service door (see §9). |
| **11. Worst case** | A profitable, efficient, well-audited organisation that is no longer the organisation described in Article 1 — and which cannot explain itself to the communities that trusted it. |
| **12. Architecture change needed?** | **Yes — MODIFY** (add service floor, capacity ceiling, mission-conflict segregation, mission-balance disclosure). |
| **Severity reasoning** | Likelihood **high** (incentive gradient is structural); blast radius **identity-level**; reversibility **medium-high if caught early, low if late** → **HIGH**. |

### F-18 · Cross-subsidy failure: the network drifts to rich neighbourhoods — **MODERATE**

| Field | Content |
|---|---|
| **1. Failure** | Teams in better-off, SME-dense, digitally fluent neighbourhoods succeed; teams in poor, informal, low-literacy areas stall and close. The network's geography quietly becomes a map of privilege — while Article 1 promises help without discrimination **[S: Const. Art.1]**. |
| **2. Why it happens** | Governance cost per team is roughly constant **[A: F-05]**, but revenue capacity per team varies by an order of magnitude across Indian neighbourhoods **[I]**. With no cross-subsidy policy and no differentiated standard, low-capacity teams are structurally non-viable. |
| **3. Early warning signs** | Team survival rates by neighbourhood income proxy; service-only teams closing while business-heavy teams thrive; leaderboards dominated by the same few cities; recruitment easier in some postal areas than others. |
| **4. If ignored** | The organisation's *stated* universalism becomes empirically false; the "help without discrimination" claim is contradicted by its own footprint map — a devastating critique because it uses the organisation's own doctrine. |
| **5. Component supposed to prevent it** | Ch.2 non-discrimination; Ch.20 social-impact fund (education, emergency participant support, community infrastructure); Ch.6 state specialist support. |
| **6. Is that control sufficient?** | **No.** The social-impact fund is restricted, surplus-dependent **[S: Ch.20]**, and therefore unavailable exactly when and where capacity is weakest. |
| **7. Additional control needed** | (i) **Differentiated team models**: a "Service Cell" variant with a *reduced* control set and city-hosted finance/HR/safety functions, for areas with no viable venture base **[P]**; (ii) an explicit **cross-subsidy policy**: a defined share of national organisation service fees earmarked to fund governance capacity in low-revenue areas, with published allocations **[P, V]**; (iii) **cohort-normalised scoring** (see F-19) so low-capacity teams are not permanently last; (iv) partnership-first strategy in low-capacity areas (municipal, hospital, school, CSR) rather than venture-first **[P]**. |
| **8. Owner** | CEO + National Finance + National Operations + proposed Council. |
| **9. Evidence** | Team survival andactivity by area deprivation index; cross-subsidy allocation log; service-cell performance; cohort score distributions. |
| **10. Recovery** | Convert failing teams to service cells rather than closing them; reallocate cross-subsidy; publish the footprint map with the correction plan. |
| **11. Worst case** | "Sewak Sathi works only where people can pay" becomes the public summary. |
| **12. Architecture change needed?** | **Yes — MODIFY** (add differentiated team model and cross-subsidy policy; both need financial validation). |
| **Severity reasoning** | Likelihood **high**; blast radius **mission integrity**; reversibility **medium** → **MODERATE** (rising to HIGH if the footprint map is ever published without a policy). |

## Cluster E — Measurement, truth and incentives

### F-19 · Leaderboards compare incomparable contexts — **HIGH**

| Field | Content |
|---|---|
| **1. Failure** | Teams in difficult contexts are permanently ranked low; teams in easy contexts are permanently high. The low-ranked conclude the system is rigged; the high-ranked become complacent; leadership transitions repeatedly favour the same geographies. |
| **2. Why it happens** | Eight weighted dimensions **[S: Ch.25]** with no baseline normalisation, no peer cohort, no difficulty adjustment, and a *prize* attached (Head Team status **[S: Ch.26]**). Anti-gaming controls address manipulation, not comparability. |
| **3. Early warning signs** | Score distributions clustered by city type; the same teams at the top for 6+ consecutive months; appeals arguing context rather than calculation; low-ranked teams reducing effort ("what's the point"); leaders avoiding hard areas. |
| **4. If ignored** | Effort migrates to easy areas (see F-18); the performance system loses legitimacy; the leadership pipeline narrows to a few privileged teams — which contradicts "earned leadership" **[S: Ch.2]** because the earning is partly inherited from geography. |
| **5. Component supposed to prevent it** | Ch.25 evidence-backed metrics, anomaly review, appeals; Ch.26 eligibility gates. |
| **6. Is that control sufficient?** | **No.** It ensures the *score is honest*, not that the *comparison is fair*. |
| **7. Additional control needed** | (i) **Cohort stratification**: score and rank teams within peer cohorts (urban/peri-urban/rural; venture-active/service-only; team age band) and promote *within* cohort **[P]**; (ii) **improvement-based scoring**: a material share of the score from *change versus own baseline* rather than absolute level **[P]**; (iii) **difficulty weighting** for objectively hard conditions (declared emergency, no venture base, low literacy) with published criteria **[P]**; (iv) publish raw *and* cohort-normalised scores so no team is invisible; (v) never rank teams publicly in the first two cycles — use the score diagnostically before using it as a prize **[P]**. |
| **8. Owner** | National Operations (performance) + Audit & Ethics + proposed Council. |
| **9. Evidence** | Cohort definitions and membership; baseline records per team; distribution of scores by cohort; appeal reasons; promotion outcomes by cohort. |
| **10. Recovery** | Re-score the affected period; publicly explain the correction; reset baselines. |
| **11. Worst case** | A permanently demoralised majority and a small rotating elite; the "dynamic leadership" idea becomes a dynastic one in practice. |
| **12. Architecture change needed?** | **Yes — MODIFY.** (Weights themselves remain unapproved per Ch.33 — normalisation is separable from weights.) |
| **Severity reasoning** | Likelihood **near-certain**; blast radius **motivation of the entire network + fairness of leadership selection**; reversibility **high if fixed before the first promotion, low after** → **HIGH**. |

### F-20 · Outcome lag forces the metric toward visible activity — **HIGH**

| Field | Content |
|---|---|
| **1. Failure** | Because scoring is monthly and leadership is monthly-evaluated **[S: Ch.25, Ch.26]**, while real outcomes take months or years (a child's learning, a sapling's survival, a household's stability), teams optimise what is countable *now*: events held, packets distributed, sessions run, photos taken. Performative service replaces effective service. |
| **2. Why it happens** | Measurement window ≪ outcome window. Your own document anticipates the failure ("do not count planned activities as completed impact"; "counting planted saplings as long-term survival" is listed as unacceptable evidence **[S: Ch.15, Appendix F]**) but retains a monthly scoring engine that creates exactly that pressure. |
| **3. Early warning signs** | Rising activity counts with flat outcome indicators; event-heavy calendars near month end; beneficiary feedback not collected; repeat beneficiaries counted as new; saplings planted with no survival follow-up; "awareness" as the dominant service category. |
| **4. If ignored** | The organisation becomes very good at looking helpful; communities notice the difference long before dashboards do; the first investigative story writes itself. |
| **5. Component supposed to prevent it** | Ch.15 outcome verification and anti-fake-impact rules; Appendix F evidence standards; Ch.25 anti-gaming; Ch.27 audit. |
| **6. Is that control sufficient?** | **Directionally strong, temporally insufficient.** The rules are right; the cadence undermines them. |
| **7. Additional control needed** | (i) **Two-speed scoring**: monthly for *conduct and execution hygiene* (records, safety, finance, responsiveness) and **quarterly/annual for impact claims**, with leadership transitions evaluated on the longer window **[P]**; (ii) **follow-up obligations**: any project claiming an outcome must schedule a follow-up verification at a defined interval, and unverified follow-ups reduce rather than increase score **[P]**; (iii) **beneficiary-sourced verification samples** (short, privacy-safe confirmation from a random subset) **[P]**; (iv) **cap the score contribution of activity counts** so volume can never carry a team **[P]**; (v) publish *failures and partial outcomes* per Ch.15 — and score the honesty of reporting as part of execution quality **[P]**. |
| **8. Owner** | National Operations + Audit & Ethics + City review. |
| **9. Evidence** | Outcome follow-up completion rate; activity-vs-outcome ratio per team; beneficiary confirmation samples; published failure counts. |
| **10. Recovery** | Re-score affected periods; require follow-up on outstanding claims; publicly correct inflated claims (per Ch.15's own honesty rule). |
| **11. Worst case** | A large, well-documented, well-audited organisation that has measurably improved very little — and a community that knows it. |
| **12. Architecture change needed?** | **Yes — MODIFY** (separate the hygiene cadence from the impact cadence; decouple leadership transitions from the short window). |
| **Severity reasoning** | Likelihood **very high** (Goodhart pressure is mechanical); blast radius **mission substance**; reversibility **medium** → **HIGH**. |

### F-21 · No protected channel to report your own leader — **HIGH**

| Field | Content |
|---|---|
| **1. Failure** | A member knows their Team Leader is inflating work, mishandling cash, favouring relatives, or behaving abusively. Every available route passes through the person accused or their local peers. The member stays silent, or resigns, or speaks publicly. |
| **2. Why it happens** | Escalation routes are line-based: Mohalla → City HR/Finance/Safety → State → National **[S: Ch.7]**. Appeals exist **[S: Const. Art.17]**. But there is **no anonymous intake, no whistleblower protection, and no independent recipient** anywhere in 179 pages. Evidence standards even mark "anonymous unverifiable rumour treated as fact" as unacceptable **[S: Appendix F]** — correct as an *evidence* rule, but it leaves no legitimate anonymous *intake* channel. |
| **3. Early warning signs** | Complaints only ever arriving after a member has resigned; complaints about a leader always coming from outside the team; clusters of resignations in one team with no stated reason; audit findings discovered by reviewers but never reported internally; social media posts as the first place a problem appears. |
| **4. If ignored** | Problems surface publicly rather than internally — the most expensive possible discovery channel. Honest members learn that speaking up costs them their position. |
| **5. Component supposed to prevent it** | Ch.27 audit and complaints; Ch.5 Audit & Ethics department; SOP-17/SOP-18 violations and misconduct; Const. Art.17 disputes. |
| **6. Is that control sufficient?** | **No.** All are line-dependent or triggered by an identified complainant. |
| **7. Additional control needed** | **Integrity Line [P, V]**: (i) an intake channel (phone/WhatsApp/form) owned by Audit & Ethics, reporting to the Council rather than the line, accepting anonymous and named reports; (ii) a **non-retaliation rule** with retaliation itself classified as serious misconduct; (iii) a triage SLA and a case register with outcomes; (iv) an explicit rule that anonymous reports are *investigable leads* but not *sufficient evidence* — reconciling with Appendix F rather than contradicting it; (v) protection of the reporter's identity by default, with a narrow, recorded exception where law requires disclosure. |
| **8. Owner** | National Audit & Ethics + proposed Council + National HR. |
| **9. Evidence** | Intake volume and source mix; time-to-triage; substantiation rate; retaliation complaints and outcomes; reporter-protection exceptions log. |
| **10. Recovery** | Publish an annual integrity report (counts, categories, outcomes, no identities) so the channel is visibly real. |
| **11. Worst case** | A serious abuse runs for years inside a team because every reporting path led to the abuser. |
| **12. Architecture change needed?** | **Yes — MODIFY** (additive; strengthens Ch.27 without altering it). |
| **Severity reasoning** | Likelihood **high** (line-only reporting always under-reports); blast radius **institutional trust and member safety**; reversibility **high** → **HIGH**. |

### F-22 · Weaponised allegations against leading teams — **MODERATE**

| Field | Content |
|---|---|
| **1. Failure** | "High score void if fraud/safety breach/manipulation" **[S: Ch.26]** means a rival can damage a leading team by alleging fraud or a safety breach shortly before evaluation. The allegation costs nothing; the defence costs weeks. |
| **2. Why it happens** | An asymmetric penalty with no stated cost for a *false* allegation. The document has a correction window and appeals for *scores* **[S: Ch.25, Ch.26]** but no penalty for proven-malicious complaints. |
| **3. Early warning signs** | Allegations clustering in the final week of a scoring period; allegations from competing teams or their affiliates; repeated unsubstantiated allegations by the same source; suspension requests preceding evaluations. |
| **4. If ignored** | The best teams learn that visibility is dangerous → they under-report achievement → the metric system degrades; or they retaliate with counter-allegations → a grievance economy. |
| **5. Component supposed to prevent it** | Ch.27 evidence-based audit; Ch.25 appeals; Ch.28 conflict-of-interest risk; SOP-18 serious misconduct with impartial review. |
| **6. Is that control sufficient?** | **Partially.** Impartial review protects against false *findings*, not against the *cost of being investigated*. |
| **7. Additional control needed** | (i) **Interim measures instead of automatic voiding**: an allegation triggers a scoped review and a *hold* on promotion, not a score cancellation, until substantiated **[P]**; (ii) a **proven-false-allegation consequence**, graded and published **[P]**; (iii) **allegation-timing analytics** as an audit signal **[P]**; (iv) fast-track review SLA when an allegation lands inside an evaluation window, so it cannot be used as delay **[P]**. |
| **8. Owner** | Audit & Ethics + National HR + proposed Council. |
| **9. Evidence** | Allegation register with source, date, timing relative to evaluation, substantiation outcome, and consequences applied. |
| **10. Recovery** | Restore scores and publish the restoration; sanction the abuse of process. |
| **11. Worst case** | A culture where being excellent is punished by process. |
| **12. Architecture change needed?** | **Yes — MODIFY** (retain the voiding rule for *substantiated* fraud/safety breach; change the interim handling). |
| **Severity reasoning** | Likelihood **medium** (requires a motivated rival; rises with leaderboard stakes); blast radius **team-level, cultural**; reversibility **high** → **MODERATE**. |

### F-23 · Removal is socially expensive, so underperformance persists — **MODERATE**

| Field | Content |
|---|---|
| **1. Failure** | A member who is unreliable, unskilled, or mildly dishonest remains for years because removing them means confronting a neighbour, a relative, or a friend of the leader. |
| **2. Why it happens** | Conduct rule is clear (first violation warning; repeat same violation removal **[S: Const. Art.8]**) but *low contribution* is not misconduct, and the removal path is HR + Team Leader with City HR on dispute **[S: Appendix E]** — i.e. two socially embedded people must act against a third. Research on volunteer organisations points to cliques/exclusion and unsupportive leadership as leading departure reasons **[X]** — the same social fabric that makes removal hard. |
| **3. Early warning signs** | No removals or warnings recorded anywhere in a city for a year; performance distributions with no bottom; the same members assigned nothing but never released; leaders describing people as "family". |
| **4. If ignored** | Effective members carry inactive ones and leave; teams exceed their useful size while capacity falls; the metric system's credibility erodes because everyone can see the scores are not acted on. |
| **5. Component supposed to prevent it** | Ch.25 evidence-backed metrics; Ch.12 lifecycle stage 12 (demotion/suspension/removal with fair process); Ch.14 recovery; Appendix E approval matrix. |
| **6. Is that control sufficient?** | **No for the social cost.** The process is fair but it is *local*, and fairness does not make it easy. |
| **7. Additional control needed** | (i) **Non-social status transitions**: after N consecutive months below a contribution floor, status changes automatically to *inactive/paused* (not "removed") without requiring a confrontation, with a re-activation path **[P]**; (ii) **out-of-team review** for role suitability decisions in small teams — a reviewer from another city **[P]**; (iii) **role re-matching before exit**: move the person to a role that fits rather than removing them (uses Ch.11's "alternate path" **[S]**, currently applied only to non-selected vacancy applicants) **[P]**; (iv) publish per-city *action rates* (warnings issued, transitions applied, roles re-matched) so inaction is visible **[P]**. |
| **8. Owner** | National HR + City HR + Audit. |
| **9. Evidence** | Status transition log with reasons and approver location; contribution distribution per team; action rates by city; re-activation rates. |
| **10. Recovery** | Periodic membership reconciliation with an amnesty window allowing people to self-pause without stigma. |
| **11. Worst case** | A large nominal membership, a small real one, and metrics that describe the nominal one. |
| **12. Architecture change needed?** | **Yes — MODIFY** (add automatic status transitions and out-of-team review). |
| **Severity reasoning** | Likelihood **high**; blast radius **team capability and metric truth**; reversibility **high** → **MODERATE**. |

### F-24 · High performers exit because the ladder is a lottery — **HIGH**

| Field | Content |
|---|---|
| **1. Failure** | The most capable members — the ones who could carry a city — conclude that after three years of excellent work their expected reward is "still Team Leader of the same mohalla", and leave for something that recognises them. |
| **2. Why it happens** | The reward architecture is a **promotion tournament**: best Mohalla Team → City Head Team → State Head Team → National opportunity **[S: Ch.26]**. In a network of *N* teams there is one City Head Team per city. **[A-assumption]** With 50 teams per city, the annual probability of any given leader reaching city leadership is a few percent even for excellent performers; the expected value of three years of effort is therefore near zero in *positional* terms. Sensitivity: if promotion is the *only* reward, the model fails at any N above ~20; if there are parallel rewards (skill, income, credential, recognition, scope), the tournament can stay small and still work. **The document currently offers almost no parallel rewards** — only compensation for verified work and a member-development metric. |
| **3. Early warning signs** | Resignations concentrated among the highest scorers; exit reasons mentioning "no growth"; leaders declining vacancy applications for higher roles; the same faces in every training; skilled members taking paid work outside the organisation while remaining nominally members. |
| **4. If ignored** | Adverse selection: the ambitious leave, the compliant stay, quality of leadership declines over 3–5 years, and the organisation's ceiling becomes the ability of its second-tier members. |
| **5. Component supposed to prevent it** | Ch.9 succession paths per role (Coordinator → Sub → Manager); Ch.25 member development weight; Ch.11 alternate path for non-selected applicants; Ch.12 advancement/transfer. |
| **6. Is that control sufficient?** | **Partially.** Role succession exists *within* a team and *within* a function — but a 10-person team has ~11 primary roles, so intra-team progression saturates almost immediately. The only real upward path is positional, and it is scarce. |
| **7. Additional control needed** | **Build a horizontal ladder [P]**: (i) **graded skill certification** (Level 1–5 per function: verification, finance integrity, safety, project delivery, business QA, data privacy) that is *portable and externally verifiable* — the single highest-value, lowest-cost addition available; (ii) **specialist tracks** that confer standing and pay without conferring command (§9); (iii) **scope rewards** rather than rank rewards: leading a bigger *project*, a cross-mohalla initiative, a training cohort, or a venture — temporally bounded, so scope circulates; (iv) **reference and experience letters** issued from the verified service record, usable with employers **[P]**; (v) **alumni network** so leaving is not erasure (also mitigates F-04). |
| **8. Owner** | National HR & Verification + National Operations + City Teams. |
| **9. Evidence** | Certification attainment; scope assignments per member; reference letters issued; retention of top-quartile performers at 12/24/36 months; exit reasons for top performers. |
| **10. Recovery** | Re-engage departed high performers as Specialists or mentors — a tier that does not require them to re-enter the tournament. |
| **11. Worst case** | A permanent underclass of excellent people with no future inside the organisation, who become its most credible external critics. |
| **12. Architecture change needed?** | **Yes — MODIFY** (additive; the positional ladder stays, a competence ladder is added beside it). |
| **Severity reasoning** | Likelihood **high** (arithmetically guaranteed once N is large); blast radius **organisational capability ceiling**; reversibility **medium** → **HIGH**. |

### F-25 · Growth outruns governance; a bad team is launched and cannot be closed — **HIGH**

| Field | Content |
|---|---|
| **1. Failure** | Expansion targets (explicit or implicit) cause teams to be approved before verification, training, finance and safety capability exist. The bad team then commits an error — financial, safeguarding, or protection — that the organisation must answer for, and closing it is socially and politically harder than never opening it. |
| **2. Why it happens** | Phase 5 "national scale — replication across states" with blockers "professional compliance and platform reliability" **[S: Ch.30]**; risk register names "uncontrolled expansion — new teams without training/finance" with response "freeze expansion, audit" **[S: Ch.28]**. So the risk is *seen*. What is missing is the **gate that makes it impossible**: there is no rule that a team may not be recognised until named capability exists, and no costed capacity plan for producing that capability. |
| **3. Early warning signs** | Team recognition granted in batches; training completion *after* first project; a city recognising teams faster than it can review them; leaders appointed from among members verified weeks earlier; "we'll complete the records once we're active". |
| **4. If ignored** | A safeguarding or financial incident in a team that was never ready; the incident is attributed to the *national* organisation because the brand is national; expansion freezes mid-flight leaving half-built teams. |
| **5. Component supposed to prevent it** | Ch.30 launch gates; Ch.13 autonomy readiness gates; Ch.11 eligibility; Ch.28 freeze-expansion response. |
| **6. Is that control sufficient?** | **Design yes, incentive no.** Gates exist for *autonomy* but the *recognition* of a new team is not gated with the same rigour in the document. And nothing penalises a city for recognising too fast. |
| **7. Additional control needed** | (i) **Team Recognition Gate**: no team may use the name, hold money, or run projects until it has (a) a verified Team Leader with completed leadership/safety/finance-integrity training, (b) a named HR verifier, (c) a named Safety Lead with training, (d) an org-owned payment channel, (e) a City sponsor who accepts written responsibility for the first two quarters **[P]**; (ii) **sponsor liability**: the sponsoring city's own readiness score is affected by the failure of teams it sponsored **[P]** — this aligns the incentive; (iii) **recognition rate limits per city per quarter** tied to reviewer capacity **[P]**; (iv) a **graceful closure path** with member protection, so closing a team is a normal administrative act rather than a public defeat **[P]**. |
| **8. Owner** | National Operations + City Teams + Audit & Ethics + CEO. |
| **9. Evidence** | Recognition gate checklist per team; sponsor assignments; training-before-first-project compliance rate; team closure records with member outcomes. |
| **10. Recovery** | Freeze recognition in the affected city; deploy support team per Ch.14; re-gate existing teams retrospectively. |
| **11. Worst case** | A safeguarding incident involving minors in an unready team, with national branding, and no insurance. (Combine with F-10 and F-09 and this is the single most likely *existential* sequence.) |
| **12. Architecture change needed?** | **Yes — MODIFY** (convert the launch roadmap's phase gates into a per-team recognition gate with sponsor liability). |
| **Severity reasoning** | Likelihood **high during any growth push**; blast radius **institutional**; reversibility **low** (an incident cannot be un-happened) → **HIGH**, and **CRITICAL when combined with F-09/F-10**. |

### F-26 · Verification is performed by the same social network that produces the claim — **MODERATE**

| Field | Content |
|---|---|
| **1. Failure** | Fake members, fake work, fake beneficiaries, or fake evidence pass verification because the verifier is a neighbour, relative, friend, or subordinate of the person making the claim. |
| **2. Why it happens** | Ground-Level Manager verifies sites; HR verifies identity; Volunteer Manager verifies attendance; reviewers verify outcomes — all *within* the team **[S: Ch.8, Ch.9, Ch.12, Ch.15]**. Random audits and beneficiary confirmation exist **[S: Ch.15]** but no rotation or cross-team verification is specified. |
| **3. Early warning signs** | Verification notes that are formulaic; identical photo metadata across projects; attendance sheets with uniform handwriting; beneficiaries who never appear in confirmation samples; verification always completed by the same person on the same day. |
| **4. If ignored** | The evidence base — the organisation's core differentiator — becomes fiction. Every downstream control (score, audit, waterfall, promotion) inherits the falsity. |
| **5. Component supposed to prevent it** | Ch.15 verification + random audits + reconciliation; Appendix F "not acceptable" column; Ch.27 audit; Ch.28 risks "fake members/projects/revenue". |
| **6. Is that control sufficient?** | **Partially.** Strong standards, weak independence. |
| **7. Additional control needed** | (i) **Cross-team verification sampling**: a defined % of high-value or high-risk verifications performed by a member of a *different* team **[P]**; (ii) **verifier rotation** for control roles (also fixes F-13) **[P]**; (iii) **metadata and duplicate-image detection** in the platform **[P, future]**; (iv) **beneficiary confirmation sampling** as a standing function, not an exception **[P]**; (v) treat verification independence as an auditable property, reported per city. |
| **8. Owner** | Audit & Ethics + City Operations + AI & Data. |
| **9. Evidence** | % cross-team verified; duplicate-evidence detections; beneficiary confirmation response rates; verifier concentration index per team. |
| **10. Recovery** | Re-verify a sample; reverse scores where claims fail (already provided for **[S: Ch.28]**); retrain verifiers. |
| **11. Worst case** | A public demonstration that the "evidence-based" organisation's evidence was self-certified. |
| **12. Architecture change needed?** | **Yes — MODIFY.** |
| **Severity reasoning** | Likelihood **medium-high**; blast radius **core claim**; reversibility **medium** → **MODERATE** (becomes HIGH once scale makes independent audit sampling the only feasible assurance). |

## Cluster F — Data, AI and platform

### F-27 · Data breach exposing conduct, incident or beneficiary records — **CRITICAL**

| Field | Content |
|---|---|
| **1. Failure** | Personal data is compromised: identity references, contacts and emergency contacts, skills, membership status, **conduct records (warnings, complaints, investigations)**, safety incident records, beneficiary/request records, financial records, AI logs **[S: Ch.12, Ch.22]**. |
| **2. Why it happens** | A single centralised estate with high-value sensitive data, operated initially by a small team with limited security maturity, accessed from many low-trust local environments and personal devices **[I]**. Retention policy and AI model policy are **UNRESOLVED** in your own register **[S: Ch.33]**. India's DPDP regime requires notification to the Board without delay and a detailed report within 72 hours, notification of affected individuals, specified security safeguards, log retention, time-bound grievance handling, and — for Significant Data Fiduciaries — an India-based DPO, DPIAs and annual audits, with penalties up to hundreds of crores **[X]**. |
| **3. Early warning signs** | Unusual logins or exports (named in your own risk register **[S: Ch.28]**); shared credentials; members accessing records on personal devices without MFA; no retention schedule; no incident-response runbook; no privacy notice in member languages; consent captured as a single blanket tick-box. |
| **4. If ignored** | **The sharpest harm is human, not regulatory**: a leaked conduct or request record can identify a survivor of domestic violence, an abused child, a person who reported a crime, or a beneficiary receiving food support — to the very people they needed protection from. This is physical danger caused by the organisation's own records. Secondary: regulatory penalty, criminal exposure, irreversible loss of trust, and the end of the "trustworthy institution" proposition. |
| **5. Component supposed to prevent it** | Ch.22 data architecture + least privilege; Ch.23 RBAC; Ch.28 risk "data breach — RBAC, MFA, encryption, logs; contain, notify where required, recover"; SOP-22 Data Breach Response; Ch.12 privacy-controlled HR content; Ch.33 unresolved retention/AI policy. |
| **6. Is that control sufficient?** | **Architecture yes; operational readiness no.** SOP-22 exists but the document has no retention schedule, no data classification, no DPIA trigger, no DPO/privacy officer designation, no breach-notification timeline, no processor/vendor contract standard, no device policy, and no privacy notice. "Notify where required" is not a plan. |
| **7. Additional control needed** | **Privacy Programme [P, V]**: (i) data classification with a *restricted* class for conduct, incident, beneficiary-identity and minor-related records; (ii) retention schedule with automatic purge, and legal-hold exception; (iii) named privacy officer and, at scale, an India-based DPO per Significant Data Fiduciary obligations **[X]**; (iv) DPIA before deploying AI matching, QR verification, or any profiling **[X]**; (v) breach runbook with hour-zero actions and a 72-hour report template **[X]**; (vi) privacy notice in every member language, in plain language **[X]**; (vii) survivor-centred defaults: pseudonymised case identifiers, case-scoped access with reason codes, sealed records, no local-team visibility of another team's conduct records; (viii) device and access policy for field use; (ix) annual independent privacy audit. |
| **8. Owner** | National AI & Data + National Legal & Compliance + proposed Council (oversight). |
| **9. Evidence** | Classification applied to every field; retention/purge logs; DPIA register; breach drill results; access-reason-code logs; privacy notice publication per language; audit report. |
| **10. Recovery** | Contain, revoke, preserve logs, investigate, notify per law, remediate **[S: SOP-22]** — plus: support the affected individuals directly, publish what happened at the level of category (not identity), and pause the affected function. |
| **11. Worst case** | A vulnerable person harmed because of a record the organisation held. There is no recovery from that in moral terms, whatever the legal outcome. |
| **12. Architecture change needed?** | **Yes — MODIFY (pre-launch).** Retention and AI policy must move from UNRESOLVED to decided before the first thousand records exist. |
| **Severity reasoning** | Likelihood **medium** (rises sharply with scale and with manual processes); blast radius **individual physical safety + institutional**; reversibility **none** → **CRITICAL**. |

### F-28 · QR member verification becomes a private checkpoint — **MODERATE**

| Field | Content |
|---|---|
| **1. Failure** | Members begin asking residents, beneficiaries, or attendees to show and scan their card — or worse, asking *others* to prove they are members — creating an experience indistinguishable from an identity check by a private organisation. |
| **2. Why it happens** | The QR ID card is CONCEPT APPROVED with minimal data, revocable token, non-police visual design **[S: Ch.33]** — good intent. But the *purpose* of scanning is not restricted anywhere: the document never says who may scan, whom, for what, and under what prohibition. Any identity instrument develops enforcement use unless explicitly forbidden. **[A]** |
| **3. Early warning signs** | Scans at entry to events; scans of beneficiaries before distribution; members requesting to see others' cards; QR used in disputes ("show me your card"); scans concentrated in one team. |
| **4. If ignored** | Public fear of the organisation; complaint that it is building a private registry; a political/vigilante framing that is very hard to reverse (feeds F-09). |
| **5. Component supposed to prevent it** | Ch.33 concept constraints; Ch.12 privacy-minimised data; Ch.23 RBAC; Ch.16 no-intimidation rule. |
| **6. Is that control sufficient?** | **No — the no-intimidation rule prohibits *threats*, not *verification requests*.** The gap is definitional. |
| **7. Additional control needed** | **QR use rule [P, V]**: scanning is permitted only (i) by an authorised verifier, (ii) of a person *voluntarily claiming* a role or entitlement, (iii) for a recorded purpose, (iv) never of beneficiaries as a condition of service, (v) never of members by other members except at role-restricted task assignment, and (vi) never in a public queue or at an entrance. Every scan logged with reason code and auditable. Card design must carry the words for its purpose ("service record") and not resemble an authority credential. |
| **8. Owner** | National HR & Verification + AI & Data + Safety + Legal. |
| **9. Evidence** | Scan logs with reason codes and location; anomaly detection on scan volume per verifier; complaints; audit samples. |
| **10. Recovery** | Suspend scanning capability; retrain; publish the rule. |
| **11. Worst case** | A viral image of a Sewak Sathi member "checking" a resident's card. |
| **12. Architecture change needed?** | **Yes — MODIFY** (add use restriction to the already-approved concept). |
| **Severity reasoning** | Likelihood **medium**; blast radius **public perception**; reversibility **low once imaged** → **MODERATE**, escalating in combination with F-09. |

### F-29 · AI review fatigue converts "humans decide" into rubber-stamping — **MODERATE**

| Field | Content |
|---|---|
| **1. Failure** | The rule "every medium/high-risk recommendation needs a named human decision and audit trail" **[S: Ch.21]** is met formally — a human clicks approve — and substantively voided, because the volume of recommendations exceeds reviewer capacity and attention. |
| **2. Why it happens** | The architecture specifies *that* review must occur and *what* must be logged, but never *how many reviewers*, *how much time per review*, *what share of recommendations is material*, or *what happens to low-risk ones*. **[A]** Human-in-the-loop systems fail by throughput, not by principle. |
| **3. Early warning signs** | Median review time per recommendation falling to seconds; approval rates at ~100%; the same reviewer approving hundreds daily; reviewers unable to explain a sample of their approvals; AI drafts published without edits. |
| **4. If ignored** | An automated decision system operating under a human-accountability label — the exact failure the architecture was written to prevent, now with an audit trail that *proves* compliance while providing none. |
| **5. Component supposed to prevent it** | Ch.21 AI governance, prohibited decisions, human reviewer, append-only audit; SOP-21 AI Recommendation Review; Ch.23 auditor review of AI logs; Ch.28 risk "AI hallucination/misuse". |
| **6. Is that control sufficient?** | **Principled but unresourced.** SOP-21 says "check sources, limitations, risk tier, human approve/reject, log outcome" — with no capacity model. |
| **7. Additional control needed** | (i) **Risk-tiered review with published thresholds**: which decision classes *must* have human review, which may proceed with post-hoc sampling **[P]**; (ii) **reviewer capacity budget** — a maximum recommendations per reviewer per day, enforced by the platform **[P]**; (iii) **friction by design**: material decisions require the reviewer to state a reason in their own words, not click a dropdown **[P]**; (iv) **review-quality audit**: sample approved recommendations and test whether the reviewer can justify them **[P]**; (v) **kill-switch and rollback** for any AI-assisted process **[P]**; (vi) explicit prohibition on AI-generated text being published as organisational statement without human authorship (extends Ch.24 rules). |
| **8. Owner** | National AI & Data + Audit & Ethics + role-specific reviewers. |
| **9. Evidence** | Review time distribution; approval/modify/reject ratios; reason-text presence and quality; sampled review-quality audit results; rollback events. |
| **10. Recovery** | Reduce AI scope; increase reviewer capacity; re-decide a sample of affected cases. |
| **11. Worst case** | An AI-influenced HR, payment, or safety decision harms a person, and the organisation's defence is a log showing a human clicked "approve" in four seconds. |
| **12. Architecture change needed?** | **Yes — MODIFY** (keep the doctrine; add capacity, tiers, friction, and review-quality audit). |
| **Severity reasoning** | Likelihood **high at scale**; blast radius **core doctrine credibility + individual harm**; reversibility **medium** → **MODERATE** (would be HIGH if AI were given any authority over pay or safety — currently prohibited **[S: Ch.21]**, which is why it stays MODERATE). |

### F-30 · The platform does not exist when the controls assume it does — **HIGH**

| Field | Content |
|---|---|
| **1. Failure** | Phase 1–2 run on "pilot-ready platform/manual process" **[S: Ch.30]**. In the manual phase, RBAC profiles, append-only logs, delegation expiry, dashboards, anomaly detection, financial permission profiles and AI logs **[S: Ch.22, Ch.23]** cannot exist. The architecture's guarantees are therefore false during the exact period when the organisation is forming its habits and its reputation. |
| **2. Why it happens** | The document is simultaneously a governance constitution and a software specification, and the governance layer presupposes the software layer. The roadmap acknowledges the manual option without acknowledging that *the controls do not survive it*. **[A]** |
| **3. Early warning signs** | Permissions tracked in a spreadsheet; logs editable by the people they record; delegation without end dates; weekly payment sheets assembled in chat; no way to produce an audit trail on demand. |
| **4. If ignored** | Habits formed without controls are extremely hard to change later ("we've always done it in the group"); the first audit finds no evidence; a dispute cannot be adjudicated because records are mutable. |
| **5. Component supposed to prevent it** | Ch.22 modules; Ch.23 RBAC; Ch.27 append-only records; Ch.31 technology blocker "blocker before scale". |
| **6. Is that control sufficient?** | **No.** "Blocker before scale" permits the pilot to run without the control system at all. |
| **7. Additional control needed** | **Minimum Viable Control Stack for the manual phase [P]**: (i) an *immutable* record medium (append-only Google Sheet with protected ranges + weekly hash/export to a second custodian, or a simple ledger with two signatures) — imperfect but non-editable-by-one-person; (ii) **six** mandatory paper forms only (request, verification, expense, payment sheet, incident, evidence index); (iii) two-person rule for every money movement; (iv) a weekly City review that physically inspects records; (v) an explicit written statement that manual-phase records are *provisional* and will be re-verified on platform migration; (vi) a hard trigger: manual process is not permitted beyond N teams or N members **[P]**. |
| **8. Owner** | National AI & Data + National Operations + City reviewer + Audit. |
| **9. Evidence** | Custodian logs; two-signature compliance; form completion rates; city inspection notes; migration reconciliation. |
| **10. Recovery** | Retro-audit the manual period on migration; accept that some evidence will be irrecoverable and say so. |
| **11. Worst case** | Two years of operations with no reliable evidence base, then an allegation the organisation cannot rebut — because its own records are mutable and untrustworthy. |
| **12. Architecture change needed?** | **Yes — MODIFY** (define the manual-phase control minimum and its expiry trigger). |
| **Severity reasoning** | Likelihood **near-certain** (a platform of this scope is 12–24 months of work; the pilot starts earlier); blast radius **evidence integrity, which underwrites everything**; reversibility **medium** → **HIGH**. |

### F-31 · Vernacular AI quality and the language hierarchy — **MODERATE**

| Field | Content |
|---|---|
| **1. Failure** | AI drafting, translation, matching and reporting perform well in English and Hindi and poorly in low-resource languages and dialects. Non-Hindi, non-English teams receive worse tooling, worse content quality and more errors — and experience this as second-class status. |
| **2. Why it happens** | Model capability is unevenly distributed across Indian languages **[I]**; the source document is written in English with English role titles (Team Leader, Ground-Level Manager, Volunteer Manager) **[S: throughout]**; no language architecture exists anywhere in v1.2. **[A]** |
| **3. Early warning signs** | Translation used without review; local teams reverting to their own language informally while official records stay in English; errors in published local-language content; member complaints that forms are incomprehensible; low completion rates for training in certain languages. |
| **4. If ignored** | The organisation becomes an English/Hindi-speaking metro project — precisely the failure mode you asked to avoid — and entire states become ungovernable culturally even if they are governed procedurally. |
| **5. Component supposed to prevent it** | Ch.24 Editor role (accuracy); Ch.5 National Communications; Ch.21 AI source tracking and human review. |
| **6. Is that control sufficient?** | **No.** Editor quality control presupposes an editor who is fluent; nothing addresses availability, terminology consistency, or language equity. |
| **7. Additional control needed** | See §13 for the full architecture. Minimum: a controlled terminology glossary per language; mandatory human review of any AI translation before publication or before it affects a person's status/pay; a language-equity metric (share of members able to operate fully in their own language); local-language primacy for member-facing text with English as the internal specification layer. |
| **8. Owner** | National Communications + AI & Data + State Teams. |
| **9. Evidence** | Terminology register per language; translation review logs; language-coverage per module; member language-preference data (self-declared, minimal). |
| **10. Recovery** | Retract and correct erroneous published material (Ch.24 misinformation rule **[S]**); invest in the neglected language. |
| **11. Worst case** | A state withdraws or a public accusation of linguistic imposition. |
| **12. Architecture change needed?** | **Yes — MODIFY** (add a language architecture chapter; v1.2 has none). |
| **Severity reasoning** | Likelihood **high** in any non-Hindi-belt state; blast radius **regional legitimacy**; reversibility **medium** → **MODERATE**, HIGH in specific states. |

## Cluster G — Mission drift, culture and meaning

### F-32 · The social-impact fund becomes the growth engine and donors become the master — **MODERATE**

| Field | Content |
|---|---|
| **1. Failure** | Because venture revenue is hard, donation/grant/CSR income becomes attractive and grows. Programme priorities start following funder interests rather than community-identified need. Restricted funds are stretched. The organisation becomes an NGO competing for grants — the exact identity it was designed not to have **[S: Exec Summary, Ch.2 "not charity-only"]**. |
| **2. Why it happens** | The social-impact fund is surplus-dependent and restricted **[S: Ch.20]**; the architecture has no *fundraising* doctrine at all (donations appear only as a service category and in SOP-07 **[S: Ch.15, Appendix D]**). Absent a doctrine, fundraising behaviour is improvised under financial pressure. **[A]** |
| **3. Early warning signs** | Grant applications driving the annual plan; new programmes appearing that match a funder's theme and no recorded community need; restricted-fund accounting ambiguities; donor names prominent in service publicity; a foreign-funding conversation beginning without FCRA analysis **[X]**. |
| **4. If ignored** | Mission capture by funders; loss of the "self-sustaining, community-rooted" differentiation; regulatory exposure if foreign contribution is received without FCRA registration or prior permission, which generally requires about three years of track record **[X]**; tax exposure if 12A conditions (including the ~85% application-of-income rule and the no-political-activity condition) are not met **[X]**. |
| **5. Component supposed to prevent it** | Ch.20 restricted ledger, approval tiers, prohibited uses ("not ordinary operating salaries, not venture bailouts, not political or religious activity, not personal favour pool"); Ch.29 partnership due diligence; SOP-07 donation handling. |
| **6. Is that control sufficient?** | **Strong on use of funds; silent on pursuit of funds.** The failure mode is *agenda capture*, not misappropriation, and nothing addresses it. |
| **7. Additional control needed** | **Funding Doctrine [P, V]**: (i) community-identified need precedes funder interest — no programme launched solely because funding exists; (ii) a cap on the share of any team's or the national budget that may come from any single funder; (iii) refusal criteria (partisan, communal, conditional-on-outcome-inflation, data-access, or naming-rights demands); (iv) separate accounting for restricted funds with published utilisation; (v) explicit rule that the social-impact fund may not fund the organisation's own operating salaries **[already S — restate with teeth]**; (vi) FCRA analysis before any foreign contribution **[X]**; (vii) 12A/80G eligibility conditions embedded in the compliance calendar **[X]**. |
| **8. Owner** | National Finance + National Legal + CEO + proposed Council. |
| **9. Evidence** | Funder concentration ratios; programme-origin field (community-need vs. funder-initiated) on every programme record; restricted-ledger reconciliation; refusal log; compliance calendar. |
| **10. Recovery** | Decline non-conforming funds publicly; re-plan from community need; publish the doctrine. |
| **11. Worst case** | A grant-dependent organisation with a business chapter in its constitution and no business — losing both its differentiation and its tax position. |
| **12. Architecture change needed?** | **Yes — MODIFY** (add a funding doctrine; v1.2 lacks one). |
| **Severity reasoning** | Likelihood **medium-high under financial pressure**; blast radius **mission + legal/tax**; reversibility **medium** → **MODERATE**, HIGH if foreign funds are accepted without FCRA cover. |

### F-33 · Recognition becomes status; status becomes hierarchy; hierarchy becomes politics — **MODERATE**

| Field | Content |
|---|---|
| **1. Failure** | Badges, milestones, service records and leaderboards — introduced to celebrate contribution — become a parallel status system. People optimise for visible recognition, trade or fabricate achievements, and internal politics organise around rank rather than work. |
| **2. Why it happens** | Any ranked recognition system in a status-conscious social environment will be converted into hierarchy **[I]**; the architecture already contains a *prize* structure (Head Team) **[S: Ch.26]** and a public leaderboard **[S: Ch.25]**, and your brief contemplates badges and ceremonies. |
| **3. Early warning signs** | Members referring to each other by rank in public; recognition being requested rather than awarded; disputes about badge eligibility; ceremonies becoming larger than the service they mark; social media dominated by recognition posts rather than outcome posts. |
| **4. If ignored** | Contribution culture is replaced by credential culture; the humble, effective member who refuses to perform becomes invisible; the organisation's stated value "serve without expecting reward" **[S: Ch.2]** becomes untrue in practice. |
| **5. Component supposed to prevent it** | Ch.2 doctrine; Ch.25 anti-gaming; Ch.31 evidence standards; Ch.28 risk "leaderboard gaming". |
| **6. Is that control sufficient?** | **Partially.** Anti-gaming protects *metrics*, not *meaning*. |
| **7. Additional control needed** | **Recognition design rules [P]**: (i) recognise **contribution and competence**, never loyalty, tenure alone, or proximity to leadership; (ii) most recognition is **local and specific** ("this lane was cleaned by these five people on this date") rather than national and abstract; (iii) no public ranking of *individuals* below leadership level — rank teams and functions, celebrate individuals by story; (iv) recognition cannot be self-nominated by a leader for their own relatives (conflict rule); (v) every recognition must cite evidence from the record, so it cannot be invented; (vi) ceremonies include beneficiaries' voices only with consent and never as emotional spectacle (see §16); (vii) an annual review of whether recognition is correlating with outcomes or with visibility. |
| **8. Owner** | National Communications + HR + proposed Council (culture oversight). |
| **9. Evidence** | Recognition register with evidence links; conflict declarations; distribution of recognition across teams/roles; correlation analysis recognition-vs-outcome. |
| **10. Recovery** | Retract an undeserved recognition publicly; reissue criteria; shift weight from rank to story. |
| **11. Worst case** | A ceremonial organisation with a status economy and thin service output. |
| **12. Architecture change needed?** | **Yes — MODIFY** (add recognition design rules; the architecture currently has recognition only as a metric concept). |
| **Severity reasoning** | Likelihood **high** wherever recognition is introduced; blast radius **cultural**; reversibility **medium** → **MODERATE**. |

### F-34 · Skilled members leave for better-paying platforms — **MODERATE**

| Field | Content |
|---|---|
| **1. Failure** | The AI Business Network's best designers, developers, editors and marketers take work from open platforms at higher rates, leaving the organisation with beginners, lower QA pass rates, unhappy customers and falling revenue. |
| **2. Why it happens** | The venture model offers local, small-ticket work with process overhead (14-step lifecycle, QA, acceptance, waterfall deductions **[S: Ch.17, Ch.18]**) and an unapproved compensation formula. Open platforms offer higher rates and no governance overhead. **[I]** There is no rate benchmarking, no skill tiering, no retention instrument for scarce skills, and no non-compete or exclusivity expectation stated. |
| **3. Early warning signs** | QA rejection rates rising; customer revisions increasing; the same senior members absent from venture work while remaining "active"; delivery timelines slipping; venture categories narrowing to low-skill work. |
| **4. If ignored** | The business pillar becomes a beginner pool with a quality problem → customers leave → revenue falls → compensation falls → more skilled members leave. A downward spiral that also starves the social-impact fund (which depends on venture surplus **[S: Ch.20]**). |
| **5. Component supposed to prevent it** | Ch.17 QA and category controls; Ch.25 business-performance weight; Ch.18 worker-compensation priority; Ch.9 role boundaries (cannot set wages alone). |
| **6. Is that control sufficient?** | **No.** Nothing in the architecture addresses *market competitiveness of compensation* or *skill retention*. |
| **7. Additional control needed** | (i) **Skill tiering with market-referenced rates** per category, reviewed periodically and published internally **[P, V]**; (ii) **rate-setting process** (who benchmarks, who approves — currently "cannot set wages alone" tells you who may not, not who does) **[P]**; (iii) **quality-gate before acceptance**: refuse work the team cannot deliver well, rather than accept and fail — protects the brand **[P]**; (iv) **non-monetary retention for scarce skills**: certification, portfolio rights (with customer consent), lead credits, teaching roles, and venture equity-like upside within the residual-surplus rules **[P, V]**; (v) **venture selection discipline**: prefer categories where the organisation's advantage (local trust, verification, accountability) beats a platform's advantage (price, volume) — e.g. local business technology, on-ground services, verified data work, rather than commodity design. |
| **8. Owner** | National Business + National Finance + City AI & Business Managers. |
| **9. Evidence** | Rate benchmark per category and tier; QA pass rate; customer satisfaction and repeat rate; senior-skill retention; venture win/loss reasons. |
| **10. Recovery** | Re-price; re-scope to defensible categories; re-recruit departed specialists as mentored Specialists (§9) rather than full members. |
| **11. Worst case** | The business pillar quietly dies while the constitution still describes it as a core function. |
| **12. Architecture change needed?** | **Yes — MODIFY** (add rate governance and category-selection discipline). |
| **Severity reasoning** | Likelihood **medium-high**; blast radius **one pillar + funding of the social fund**; reversibility **medium** → **MODERATE**. |

### F-35 · The readiness gate excludes the teams that most need autonomy — **MODERATE**

| Field | Content |
|---|---|
| **1. Failure** | Autonomy requires passing eight evidence gates including accurate HR records, reconciled finance, and a passed readiness audit **[S: Ch.13]**. A new or low-capacity team cannot produce that evidence, so it never gains autonomy, so it stays dependent, so its leaders never develop judgement, so it never produces the evidence. A closed loop. |
| **2. Why it happens** | The gate measures *documentation maturity* as a proxy for *trustworthiness*. In a resource-poor team the two diverge: they may be highly trustworthy and poorly documented. |
| **3. Early warning signs** | Zero teams achieving autonomous status in the first year; the same teams failing gates on documentation items only; City support time consumed by paperwork assistance; leaders describing gates as "impossible". |
| **4. If ignored** | Either the gates are quietly waived (destroying their meaning) or the network stays permanently centralised (destroying the autonomy principle) — the two failure modes your document explicitly tries to avoid **[S: Ch.13]**. |
| **5. Component supposed to prevent it** | Ch.13 gates + Ch.14 support-first recovery + Ch.10 three staffing states. |
| **6. Is that control sufficient?** | **No.** The staffing states address *role coverage*, not *evidence maturity*. |
| **7. Additional control needed** | **Graduated evidence ladder [P]**: Tier 1 (recognition) requires only the six core records; Tier 2 (operating) adds finance reconciliation and training records; Tier 3 (autonomous) requires the full eight gates. Each tier grants specific, published freedoms, so teams experience autonomy *increasing* rather than arriving all-at-once. Plus **evidence assistance as an explicit City duty with a time budget**, so the gate is supported rather than merely imposed. |
| **8. Owner** | National Operations + City Teams + Audit. |
| **9. Evidence** | Tier distribution over time; median time between tiers; gate failures by category; City assistance hours. |
| **10. Recovery** | Re-tier teams already operating above their paperwork; grant provisional freedoms with a review date. |
| **11. Worst case** | A permanently centralised "autonomy" architecture — the document's central promise unfulfilled in practice. |
| **12. Architecture change needed?** | **Yes — MODIFY** (graduated tiers; keep all eight gates for full autonomy). |
| **Severity reasoning** | Likelihood **high**; blast radius **core principle**; reversibility **high** → **MODERATE**. |

### F-36 · Public misclassification: nobody knows what it is — **HIGH**

| Field | Content |
|---|---|
| **1. Failure** | Different audiences classify the organisation differently and mostly wrongly: a political outfit, a religious group, a private company, an NGO, a security agency, a job portal, an AI startup, a WhatsApp volunteer club. Each misclassification imports the wrong expectations and the wrong risks. |
| **2. Why it happens** | The architecture is genuinely hybrid — four pillars including business and protection **[S: Ch.3]** — and hybrid organisations are cognitively expensive. People resolve ambiguity by analogy to whatever they fear or want. The document has no *external* category statement, no positioning, and no competitor analysis. **[A]** |
| **3. Early warning signs** | Media descriptions varying wildly; residents asking "is this a party?"; job applications arriving for roles that do not exist; customers assuming it is a cheap agency; police asking who authorised the group; donors assuming it is a registered charity **[V]**. |
| **4. If ignored** | Wrong-expectation failures in every direction: people expecting jobs get service; people expecting charity get invoices; people expecting security get de-escalation; authorities expect a registered entity that does not yet exist. Each produces a small trust failure; together they prevent the formation of a stable public identity. |
| **5. Component supposed to prevent it** | Ch.24 communications rules; Ch.2 identity statements; Ch.29 partnership documentation; Ch.31 branding checklist item (ID card, public statement rules). |
| **6. Is that control sufficient?** | **No.** These govern *accuracy of statements*, not *clarity of category*. Accuracy without category produces truthful confusion. |
| **7. Additional control needed** | See §18 and §20 for the full design. Minimum: (i) a single **category sentence** used identically everywhere, in every language; (ii) a **"what we are not"** list published alongside it (not a political organisation, not a religious organisation, not a security agency, not a job portal, not a charity dependent on donations, not a replacement for government); (iii) **legal-status honesty** in every public document — state exactly what entity exists today and what is pending **[V]**; (iv) a **misclassification response protocol** for media and officials; (v) segment-specific explanations (see §21) so a student, a shopkeeper and a municipal officer each get the version relevant to them, all consistent with one core. |
| **8. Owner** | National Communications + Legal + CEO. |
| **9. Evidence** | Media-mention classification tracking; public comprehension testing (short intercept surveys); inbound enquiry categories; official correspondence types. |
| **10. Recovery** | Republish the category statement; correct specific misclassifications calmly with facts (Ch.24 misinformation rule **[S]**). |
| **11. Worst case** | The organisation is permanently filed under the wrong mental category in a state — most dangerously "political" or "security". |
| **12. Architecture change needed?** | **Yes — MODIFY** (add an external identity/positioning chapter; the architecture is entirely inward-facing). |
| **Severity reasoning** | Likelihood **near-certain** (hybrid + no positioning); blast radius **public trust and regulatory standing**; reversibility **medium** → **HIGH**. |

## 3.37 Failure-map summary

| ID | Failure | Severity | Existing control sufficient? | Architecture change |
|---|---|---|---|---|
| F-01 | Verification funnel converts nobody | HIGH | No | MODIFY |
| F-02 | Money-motivated influx then disappointment | HIGH | Partial | MODIFY |
| F-03 | Control roles unfilled / informally combined | MODERATE | No | MODIFY |
| F-04 | Ordinary-life volunteer attrition | MODERATE | No | MODIFY |
| F-05 | Compliance labour exceeds capacity | HIGH | No | MODIFY |
| F-06 | Weekly payment vs lumpy revenue; buffer arrives late | HIGH | No (sequence) | MODIFY |
| F-07 | Starter team never grows | MODERATE | Partial | MODIFY |
| F-08 | Political capture / perception | **CRITICAL** | **No — largest gap** | MODIFY (pre-launch) |
| F-09 | Vigilante perception after one incident | **CRITICAL** | Partial (doctrine yes, visibility no) | MODIFY |
| F-10 | Protection incident without insurance/legal cover | **CRITICAL** | No | MODIFY (pre-launch) |
| F-11 | Founder concentration, no mission lock/succession | **CRITICAL** | No | MODIFY (constitutional) |
| F-12 | CEO–Council deadlock unresolved | HIGH | No | MODIFY |
| F-13 | Local power centres / secession | MODERATE→HIGH | Partial | MODIFY |
| F-14 | National disconnect from ground | MODERATE | No | MODIFY |
| F-15 | Leader multiplier read as self-dealing | MODERATE | Partial | MODIFY |
| F-16 | Leakage in small cash-handling teams | HIGH | Design yes, deployment no | MODIFY |
| F-17 | Business overpowers service | HIGH | Detective only | MODIFY |
| F-18 | Drift toward rich neighbourhoods | MODERATE | No | MODIFY |
| F-19 | Leaderboards compare incomparable contexts | HIGH | No | MODIFY |
| F-20 | Monthly scoring forces performative service | HIGH | Directionally yes, temporally no | MODIFY |
| F-21 | No protected channel to report your own leader | HIGH | No | MODIFY |
| F-22 | Weaponised allegations against leading teams | MODERATE | Partial | MODIFY |
| F-23 | Removal too socially expensive | MODERATE | No | MODIFY |
| F-24 | High performers exit (tournament lottery) | HIGH | Partial | MODIFY |
| F-25 | Growth outruns governance | HIGH | Design yes, incentive no | MODIFY |
| F-26 | Verification by the same social network | MODERATE | Partial | MODIFY |
| F-27 | Data breach exposing conduct/incident/beneficiary data | **CRITICAL** | Architecture yes, readiness no | MODIFY (pre-launch) |
| F-28 | QR becomes a private checkpoint | MODERATE | No | MODIFY |
| F-29 | AI review fatigue → rubber-stamping | MODERATE | Principled, unresourced | MODIFY |
| F-30 | Controls assume a platform that does not exist yet | HIGH | No | MODIFY |
| F-31 | Vernacular AI quality and language hierarchy | MODERATE | No | MODIFY |
| F-32 | Funder agenda capture of the social fund | MODERATE | Strong on use, silent on pursuit | MODIFY |
| F-33 | Recognition becomes status hierarchy | MODERATE | Partial | MODIFY |
| F-34 | Skilled members leave for better platforms | MODERATE | No | MODIFY |
| F-35 | Readiness gate excludes those needing autonomy | MODERATE | No | MODIFY |
| F-36 | Public misclassification | HIGH | No | MODIFY |

**Not one of the 36 requires RECONSIDER-ing the mission, the four pillars, the hierarchy, the waterfall priority order, the AI doctrine, or the protection DO-NOTs.** **[A]** Every failure is addressable by *adding* a control, *sequencing* an existing one correctly, *relocating* a control to a level that can actually perform it, or *supplying capacity* to a control that assumed free throughput. That is a strong result for the architecture and it is the main reason my overall verdict is "buildable, not yet launchable".

---

# 4. WORST-CASE SCENARIOS ("what if everything goes wrong?")

## 4.1 The compound failure sequence (most likely path to collapse)

Failures rarely arrive singly. **[A]** The most probable collapse sequence for this specific architecture:

> **Phase 2 pilot launches (F-30: controls are manual, so evidence is weak) → the team recruits on an earnings implication (F-02) → first weeks have no distributable revenue (F-06) → three members leave, two stay for money, one control role is combined (F-03) → to keep the score respectable, activity is counted instead of outcome (F-20) → a resident is helped but the credit is invisible (F-12 growth-loop failure, §22) → a small intervention at a local dispute is filmed (F-09) → no insurance, no legal protocol (F-10) → the story is picked up locally and framed politically (F-08, F-36) → the national organisation has no ombuds and no bypass to hear the ground's warning (F-14, F-21) → the founder's authority is absolute and unchartered, so the response is improvised (F-11, F-12) → expansion freezes (F-25) → the institution never passes Phase 2.**

**Total elapsed time in this scenario: 9–18 months. Cost: the entire idea.** **[I]**

Note what this sequence has in common: **not one step is a failure of the written architecture.** Every step is a failure of *sequence, capacity, perception or incentive*. That is the most important sentence in this report. **[A]**

## 4.2 The "success but rotten" scenario (worse than failure)

> The organisation *works*: 5,000 teams, real revenue, real service, national recognition. And internally it has become: a status economy (F-33) where rank matters more than service; a city-faction politics (F-13) where three cities control the leaderboard; a performative-impact machine (F-20) with beautiful dashboards; a business-first culture (F-17) where service is the marketing department; a leader-dependent institution (F-11) that cannot survive its founder; and a data estate (F-27) that could endanger the people it was built to protect.

This is the outcome to fear more than collapse, because it is *stable* and it is *legible as success*. It would satisfy most of your metrics while violating most of your principles. **[A]** The defence against it is not more measurement — it is the cultural and constitutional instruments in §15, §16 and §11.

## 4.3 Scenario stress: what if the single worst event happens in year one?

| Event **[I]** | Immediate consequence | Does the architecture survive? | Why |
|---|---|---|---|
| A member is killed or kills during an intervention | Criminal case, media storm, panic in every team | **Only if F-09/F-10 controls pre-exist.** Otherwise: no. | Doctrine is good; insurance, legal protocol and visibility rules are absent |
| Conduct/beneficiary records leak | People endangered; DPDP exposure **[X]** | **No**, without a privacy programme | Retention/AI policy is UNRESOLVED **[S: Ch.33]** |
| Proven financial fraud by a City-level leader | Trust collapse in that city; audit credibility test | **Probably yes** | Ch.14, Ch.27, Ch.28 responses are genuinely strong *if* the evidence exists (F-30) |
| Founder incapacitated | Constitutional vacuum | **No** | No succession or incapacity clause **[S: Const. Art.3, 19]** |
| Organisation publicly linked to a party | Cross-community trust lost; tax-status risk **[X]** | **No** | No political neutrality code |
| A child is harmed during a service activity | Safeguarding crisis; possible criminal liability | **Only if** safeguarding training is certified, insurance exists, and a response protocol is rehearsed | Document flags training insufficiency **[S: Ch.12]** but has no certified-safeguarding requirement |
| A rival organisation runs a "fake Sewak Sathi" scam in a city | Residents defrauded under your name | **Partly** | Brand-use rules and verification exist for insiders; no public verification channel for outsiders to check authenticity |

**Conclusion [A]:** the architecture survives *internal* failures reasonably well and *external* failures badly. Its immune system is strong against its own cells and weak against the world.

---

# 5. SCALING STRESS TEST (Scenarios A–F)

**Ratio assumptions — all [A-assumption], derived from the architecture's own structure, not from the source (which deliberately sets no numbers [S: Ch.33]).** Each conclusion below states its sensitivity to these.

| Assumption | Value used | Derivation | Sensitivity |
|---|---|---|---|
| Verified members per Mohalla team | 10–25 (State A ~6–10 combined-role holders) | Ch.10 staffing states; 11 role families **[S]** | If teams average 40, team counts below fall by ~half; bottlenecks shift from *leader supply* to *coordination* |
| Primary/sub roles to fill at State C | ~22 per team | Ch.10 catalogue **[S]** | Lower if roles stay combined; raises the leader-supply problem |
| Active ratio (contributing in a given month) | 30–50% early; 20–35% at scale | Volunteer attrition literature **[X]** + F-04 | If 15%, every capacity figure below worsens by ~2× |
| Teams per city | 20–80 | Ch.7 city responsibilities **[S]** | Metro cities could exceed 200, requiring a sub-city zone layer not in the architecture |
| Governance hours per team per month | 8–40 (unknown; F-05) | Summation of SOP/report/evidence obligations **[S]** | **This is the single most important unknown in the whole model** |
| Trained-leader production rate | Limited by trainer supply, not by curriculum | Ch.12 training categories **[S]** | The binding constraint at every stage above 1,000 members |

---

## SCENARIO A — FIRST 100 MEMBERS (≈5–10 teams, one city)

**Sub-case: only 10% remain active (≈10 people across the city).**
- **[A]** With 10 active people you cannot staff even *one* State A team properly (needs ~6–8 combined-role holders including three unpopular control roles). You cannot have segregation of duties. You cannot run a weekly payment cycle honestly.
- **What actually happens:** the organisation becomes one small group doing occasional service, with a 179-page architecture it cannot operate. The gap between document and reality becomes the culture — people learn that the rules are aspirational. That habit, formed at 100 members, persists at 100,000. **[I]**
- **Correct response:** *shrink the operating scope, not the standards.* Run one team. Suspend the leaderboard, the weekly payment cycle, the vacancy catalogue and the state layer entirely. Keep only: verification, safety doctrine, two-signature money, six evidence records, one monthly report. **[P]** The architecture permits this implicitly (State A) but does not say so explicitly — it should.

**Sub-case: members join only for money.**
- **[A]** At 100 members with no venture revenue, this is fatal within one quarter — the promise is visibly empty (F-02, F-06). At 100 members *with* one anchored revenue source (a single institutional contract, one SME retainer, one paid project pipeline), it is survivable but produces a transactional culture that is very hard to convert later. Culture formed under monetary framing resists re-framing. **[I]**
- **Correct response:** do not recruit on earnings at 100 members. Recruit on a specific, achievable first project with a named community outcome, and let earnings arrive as a *surprise* rather than a promise. **[P]**

**Sub-case: nobody wants leadership responsibility.**
- **[A]** Likely, because leadership here means: accountability without pay certainty, social friction (F-03), compliance labour (F-05), and a lottery-sized upside (F-24).
- **Correct response:** make leadership *temporally bounded and shared* at the start — a rotating facilitator role for one quarter, explicitly not a rank, with the City holding the accountability. This is not in the architecture and would need approval; it does not contradict Ch.10 (one primary holder) if the rotation is recorded as successive appointments. **[P]**

**Sub-case: the first leaders are weak.**
- **[A]** At 100 members there is no bench. Weak first leaders set the cultural template: their tolerance for sloppy evidence becomes the network's tolerance. Ch.14 support-first recovery is the correct instrument, but at this scale the *support team* is the same five people.
- **Correct response:** the founder/CEO or a national appointee personally mentors the first three teams for two quarters, and the City sponsor model (F-25) is used from day one. Accept that the first teams are *taught*, not *recruited*. **[P]**

**Sub-case: service demand ≫ capacity.**
- **[A]** Certain. A neighbourhood has unlimited need. Without a triage rule that says *no*, the team burns out and disappoints everyone. The architecture has priority assessment **[S: Ch.8 step 5]** and a decision log including "decline" **[S: Ch.8]** — good — but no *capacity-based* refusal doctrine and no public explanation of why some requests are declined.
- **Correct response:** publish a **capacity statement** ("this team can complete N projects per month; here is how we prioritise; here is how to reach the municipality for the rest") — this converts refusal from a personal rejection into an institutional fact, and it protects the relationship. **[P]**

**Bottleneck at 100:** *founder/mentor time and one viable revenue or resource source.* Not governance, not software, not policy.

---

## SCENARIO B — FIRST 1,000 MEMBERS (≈50–100 teams, 2–5 cities, first State layer)

**What changes [A]:**
1. Personal knowledge of every member ends. Trust must become *procedural* — which is exactly what the architecture is built for. This is the scale at which the design starts to pay off.
2. The City layer becomes real and becomes the organisation's actual operating company.
3. Money movement becomes non-trivial: 1,000 people paid weekly under a waterfall cannot be done on spreadsheets.
4. Identity verification becomes an industrial problem: manual identity checks for 1,000 applicants, with re-verification, transfers and conduct records.

**What breaks first [I], in order:**
1. **Weekly payment operations.** Manual reconciliation × 100 teams × 52 weeks. Needs a payment engine, bank/UPI rails, tax and classification decisions — all of which are UNRESOLVED in the register **[S: Ch.33]**. This breaks at roughly 300–800 members.
2. **Trained leader supply.** ~100 teams need ~100 Team Leaders plus ~100 deputies plus ~300 control-role holders. Producing that many people with leadership, safety, finance-integrity, HR and privacy training **[S: Ch.15]** takes 12–24 months of deliberate effort and a trainer cadre. This breaks silently — teams get recognised before leaders are ready (F-25).
3. **Verification throughput.** Interviews, site verifications, probation supervision. Needs either a central verification cell or digital identity rails (e.g. government digital identity/document infrastructure — widely available in India **[X]**) plus human judgement on top. Note: any use of government identity infrastructure for verification carries its own legal conditions and requires validation **[V]**.
4. **Evidence consistency across teams.** 100 teams produce 100 dialects of evidence. Needs templates enforced by software, not by SOP documents.
5. **First serious incident.** With 100 teams in public spaces, the probability of a protection, safeguarding or financial incident in a year approaches certainty **[I]**. The organisation's *response* to incident #1 will define its culture more than any document.

**Bottleneck at 1,000:** *production of trusted, trained people into control roles, plus payment/verification rails.*

---

## SCENARIO C — 100,000 MEMBERS (≈5,000–10,000 teams, 100–300 cities, 10–20 states)

**Systems that become bottlenecks [A]:**
1. **Audit and assurance.** Exhaustive review is arithmetically impossible: 5,000–10,000 teams × (readiness audit + monthly score verification + finance review + incident review + AI-log review). You must move to **risk-based sampling + statistical control + anomaly triage**, which is a *different discipline* from the case-by-case audit the architecture describes. The document's audit model is exhaustive-by-implication and has no sampling doctrine. **[A]** This is the deepest architectural change required by scale.
2. **Dispute and grievance resolution.** Even a 1% annual grievance rate is 1,000 cases/year requiring impartial review, appeals and timelines. There is no case-management capacity model.
3. **Training throughput.** Certification of control roles across 20 states, in multiple languages, with quality assurance of trainers. Requires a training institution, not a curriculum.
4. **Safety operations.** A 24×7 national safety/integrity line, incident triage, and legal response capability across jurisdictions.
5. **Data protection compliance.** At this volume and sensitivity, Significant Data Fiduciary obligations (India-based DPO, DPIA, annual audit, Board reporting) become live **[X]**. Retention, which is UNRESOLVED **[S: Ch.33]**, becomes a legal liability at scale.
6. **Insurance and liability** across 20 states and thousands of public events **[V]**.
8. **Customer acquisition for the business pillar.** 5,000 teams cannot each find their own customers; a national demand engine (category focus, sales capability, contracts, quality brand) becomes necessary — which is a *different business* from local venture brokering, and it will pull the organisation toward being an agency.
9. **Financial governance.** Reserves, cross-subsidy (F-18), restricted funds, statutory compliance in multiple states, audits under multiple regimes **[V]**.

**Bottleneck at 100,000:** *assurance capacity (audit at sampling scale) and the professional institutional functions (legal, privacy, insurance, safety ops, training institution).*

---

## SCENARIO D — 1 MILLION MEMBERS (≈50,000–100,000 teams)

**What must change [A]:**
1. **The hierarchy must flatten or federate.** Seven levels (Krytos → Council → National → State → City → Mohalla → Members) **[S: Ch.4]** produce latency, information loss (F-14) and a very large intermediate management population. At this scale you need either (i) zones/regions between state and national, or (ii) **federation**: legally distinct state entities bound by a common constitution, standards body and brand licence — the model used by large mass-membership institutions worldwide. Federation also solves inter-state legal heterogeneity **[V]** and dilutes single-owner control (which mitigates F-11 but reduces founder flexibility — a deliberate trade).
2. **The performance system must stop being a ladder and become a diagnostic.** With 50,000 teams, "best team becomes Head Team" is not a career system; it is a rounding error. Leadership selection must move to *qualification + nomination + assessment*, with score as one input. **[P]**
3. **Governance becomes a profession.** Audit, privacy, safeguarding, finance review, safety review become full-time paid cadres with their own training, ethics code, and independence protections. The architecture currently treats audit as a role, not a profession.
4. **The brand becomes public property in practice.** With a million members, the organisation cannot control how the name is used. It needs a licensing/standards regime and a public authenticity-verification channel (F-4.3 last row).
5. **Political attention becomes structural, not incidental.** An institution with a million members and street presence in every district *will* be courted, infiltrated, suspected and regulated. The Political Neutrality Code (F-08) stops being a policy and becomes a survival organ, requiring an enforcement function with real independence.
6. **The business pillar faces market and possibly competition-law questions** if it operates a large verified-labour or local-services marketplace **[V]**.

**Bottleneck at 1 million:** *governance form (federation) and the professionalisation of assurance.*

---

## SCENARIO E — 10 MILLION MEMBERS

**Which parts of the current architecture stop scaling [A]:**

| Component **[S]** | Limit | Why it fails | What replaces it **[P, V]** |
|---|---|---|---|
| Single-entity ownership under Krytos (Art.3) | ~1M | No legal form comfortably holds a 10M-member public institution under one private owner; public legitimacy and continuity demand otherwise | Federated entities + a mission-holding body with an irrevocable purpose |
| Monthly national leaderboard (Ch.25–26) | ~10k teams | Comparison across 100k contexts is meaningless; the prize is negligible; gaming becomes industrial | Cohort diagnostics + qualification-based leadership selection |
| Exhaustive evidence per claim (Ch.15, App. F) | ~5k teams | Human verification throughput; cost per claim exceeds value of claim | Statistical assurance + risk-tiered verification + beneficiary-sourced sampling |
| Weekly payment per team (Ch.19) | ~1k teams (manual) / ~100k (system) | Transaction volume and payroll compliance | Central payroll engine with standard cycles; team supplies verified work data only |
| 11 role families per team (Ch.9–10) | Always, but binding ~50k teams | Role supply; small teams cannot fill; combines roles de facto | Shared city-level function centres; team holds only 3–4 core roles |
| 22 SOPs per team (App. D) | ~5k teams | Compliance labour (F-05) | SOP tiers by team maturity; software-embedded procedure |
| Escalation filter via State (Ch.6) | ~100 cities | Information loss; filtering of truth (F-14) | Parallel independent channels (ombuds, integrity line, sampling field visits) |
| AI human-review of all material recommendations (Ch.21) | ~100k reviews/yr | Reviewer capacity (F-29) | Risk-tiered review + sampling + review-quality audit |
| Founder-CEO as apex decision-maker on all constitutional matters | Immediately at this scale | Legitimacy, continuity, single point of failure | Charter-bound executive + independent standards/ethics body with reserved matters |

**Bottleneck at 10 million:** *legitimacy and legal form.* Operations can be engineered; the question becomes whether a founder-owned entity can hold a national public institution — and the honest answer is no. **[A]**

---

## SCENARIO F — 100 MILLION+ PARTICIPANTS

**What becomes fundamentally different [A]:**

At this scale the word "member" is meaningless, and so is "organisation" in the current sense. 100 million participants is roughly the scale of a national digital public infrastructure or a mass civic movement, not an NGO or a company. Three things change qualitatively:

1. **It stops being an organisation and becomes a protocol.** The value is no longer in the teams but in the *standards* that let strangers cooperate: a verified-service record that any employer trusts, a community-need registry that any institution can query, an assurance method that any funder can rely on, a safety doctrine that any local group can adopt. The institution's job becomes maintaining the protocol and certifying those who use it. **[I]**
2. **Governance must become public-interest governance.** No private owner, no single family, no single founder, and arguably no single corporate board can legitimately govern an institution that a twelfth of the country participates in. Expect — and plan for — statutory recognition, an independent trustee/board structure, public reporting obligations, regulator relationships, and possibly interoperability mandates. **[V]**
3. **Its failures become systemic.** A data breach is a national event. A protection incident is a law-and-order question. A financial failure affects household incomes in thousands of towns. Its political significance becomes structural regardless of intent, so neutrality must be *demonstrable and independently verified*, not merely stated.

**Architectural implication [P]:** the design should be **layered for separation now**, even at small scale — mission/standards body, service delivery network, business venture company, data/technology platform, assurance function — each with its own governance, so that at scale they can be separated legally without being torn apart. Doing this at 100 members costs almost nothing; doing it at 10 million costs everything.

**The scaling verdict [A]:** the architecture scales to roughly **1,000–5,000 members with modest modification**, to **~100,000 with a professional institutional layer and sampling-based assurance**, to **~1 million only with federation and a charter-bound apex**, and beyond that only by becoming a protocol with public-interest governance. **Nothing in the document currently anticipates the transitions between those regimes** — which is normal and acceptable for a v1.2, but should be named as a future-architecture obligation rather than discovered as a crisis.

---

# 6. WHY PEOPLE WOULD JOIN — THE HONEST ANSWER

## 6.1 The question, correctly framed

"Why would an ordinary Indian citizen join?" is the wrong first question. **[A]** The right first question is: **"What is this person already doing, and what would make them stop?"** An ordinary citizen in Moradabad, Pune, Madurai or Siliguri already has: a family WhatsApp group, a mohalla/colony group, an RWA or panchayat interface, a temple/mosque/gurdwara/church committee, a caste or community association, a school parent group, a shopkeepers' association, a gymkhana or club, a political WhatsApp universe, and — if they are a student — NSS/NCC or a coaching-centre peer group. **[I]** Sewak Sathi does not enter an empty space. It enters the most crowded space in Indian life.

Therefore: **nobody joins because the architecture is better.** Nobody has ever joined anything because its RBAC matrix was sound. **[A]**

## 6.2 Motivation inventory — compatible vs. corrosive

Rating key: **✅ compatible** (can be safely appealed to) · **⚠️ double-edged** (powerful but distorts behaviour if made primary) · **❌ corrosive** (do not build on this).

| # | Motivation | Who feels it most strongly | Rating | Reasoning **[A/I]** | Architectural support today |
|---|---|---|---|---|---|
| 1 | **Purpose / meaning** — "my life does something" | Students, retirees, people after a personal crisis, religiously inclined | ✅ | Durable, non-rivalrous, survives bad weeks. The only motivation that survives when there is no money and no status. | Strong: doctrine, mission primacy **[S: Ch.2]** |
| 2 | **Contribution efficacy** — "my help actually reached someone" | Everyone, especially competent professionals | ✅ | The strongest single emotion available (see §10). Requires evidence, which the architecture has. | Strong: evidence + outcome verification **[S: Ch.15]** |
| 3 | **Belonging / friendship** — "these are my people" | Migrants, new residents, students, homemakers, retirees | ✅ | Highest retention value; volunteer research points to inclusion and camaraderie as decisive **[X]** | **Weak**: no belonging design anywhere in 179 pages |
| 4 | **Local identity / pride in place** — "my mohalla, my city" | Small towns, old city neighbourhoods, rural areas | ✅ | Extremely strong in India and *free*. Turns geography into loyalty. | **Weak**: implied by Mohalla structure, never designed |
| 5 | **Learning and skills** | Students, early-career, career-changers | ✅ | Cheap to supply, high perceived value, produces capability the organisation needs. | Medium: 10 training categories **[S: Ch.12]** but no certification ladder |
| 6 | **Verifiable credential / proof of work** — "something I can show an employer" | Students, job-seekers, rural youth, women re-entering work | ✅ | **The most under-exploited asset in the entire architecture.** The organisation already holds verified service records **[S: Ch.12, App. F]** — it simply never issues them outward. | **Absent**: no reference letter, no certificate, no external verification |
| 7 | **Earning / livelihood** | Unemployed and underemployed youth, part-time workers, gig workers | ⚠️ | Real and legitimate, but if made the primary appeal it produces F-02 (transactional influx, disappointment, mission crowding-out). Must be *truthful* and *secondary* in messaging. | Medium: compensation for verified work **[S: Ch.2, Ch.18]** — but no expectation management |
| 8 | **Entrepreneurship / building something** | Small business owners, ambitious youth, skilled freelancers | ⚠️ | Powerful energy and the engine of the business pillar; also the engine of mission drift (F-17). Needs a firewall, not suppression. | Strong: 14-step venture lifecycle **[S: Ch.17]** |
| 9 | **Recognition / status** | Local notables, youth, people invisible in their families | ⚠️ | Cheap, immediate, addictive. Drives performance *and* gaming (F-33). Must be evidence-linked and mostly local. | Partial: leaderboard exists **[S: Ch.25]**; recognition design rules do not |
| 10 | **Leadership / authority** | Ambitious members, local influencers, ex-servicemen, retired officials | ⚠️ | Necessary — someone must lead. But it attracts the *highest* proportion of the wrong people per unit of appeal, and it is the scarcest reward (F-24). | Strong on limits **[S: Ch.9]**, weak on supply |
| 11 | **Protector identity** — "I defend my area" | Young men, especially in areas with real safety anxiety | ⚠️❌ | The most emotionally powerful appeal available and **the most dangerous**. It self-selects for people who want authority over people, and it is the direct feeder of F-09. Must never be used in recruitment. | Strong doctrine **[S: Ch.16]**, no recruitment prohibition |
| 12 | **Network access / business contacts** | Shopkeepers, professionals, contractors | ⚠️ | Legitimate and useful, but turns the organisation into a chamber of commerce if made primary; also imports caste/community business clustering. | Partial: partnerships **[S: Ch.29]** |
| 13 | **Religious merit / seva as religious duty** | Practising members of all faiths | ⚠️ | Deeply motivating and culturally authentic — but appealing to it *organisationally* begins the process of the organisation being classified by faith (F-08, F-36). Must be *accepted individually, never invoked institutionally*. | Partial: non-discrimination **[S: Ch.2]**; no rule on religious framing |
| 14 | **Grief / loss transformation** — "something good came out of it" | Bereaved families, accident survivors, people who lost someone to a social problem | ✅ | One of the most committed volunteer populations anywhere; also one of the most fragile. Requires care, not recruitment. | **Absent**: no mention |
| 15 | **Family / intergenerational duty** — "my parents would want this" | All ages in Indian family structures | ✅ | Uniquely strong in India; makes membership a *family* fact rather than an individual hobby, which dramatically improves retention. | **Absent**: architecture treats membership as purely individual |
| 16 | **Fear / protection membership** — "join so we are safe from them" | Residents in high-tension areas | ❌ | Converts the organisation into a faction. Directly produces F-08/F-09. | Prohibited in spirit **[S: Ch.16]**, not in recruitment rules |
| 17 | **Belief in the founder personally** | Early adopters | ❌ | Fastest growth, worst durability. Produces personality dependence (F-11) and collapses at the first founder controversy. | Not addressed; the document is explicitly founder-owned **[S: Art.3]** |
| 18 | **Anger / opposition to a local enemy** | Any group in conflict | ❌ | Mobilises instantly, poisons permanently. Contradicts "stand against injustice without becoming unjust" **[S: Ch.2]**. | Doctrine prohibits; no recruitment rule |

## 6.3 The synthesis: there is no single reason, there are four doors

**[A]** The mistake would be choosing one motivation as *the* message. The architecture already contains four distinct value propositions, and they appeal to four different people:

1. **The Purpose Door** — "something worth doing with my life." Entry: a service project. Reward: meaning, belonging, contribution.
2. **The Proof Door** — "something I can show." Entry: a task with a verified record. Reward: credential, skill, reference. *(This is the door for students and job-seekers — probably the largest single reachable population in India, and the architecture currently does not open it at all.)*
3. **The Livelihood Door** — "honest work with honest accounting." Entry: a venture task. Reward: pay under a worker-first waterfall. *(Must be truthful, bounded and never the headline.)*
4. **The Building Door** — "help me build something of my own, inside something bigger." Entry: a venture proposal or a new team. Reward: scope, ownership, upside within rules.

**All four doors lead into the same verification spine.** That is the design insight: **multiple entry motivations, one integrity standard.** **[P]** Today the architecture has one door (Verified Member) with four rooms behind it. Inverting this — four doors, one spine — is the highest-leverage adoption change available and requires no weakening of any control (see §9).

## 6.4 What must never be the reason

**[P]** Write these into the recruitment-conduct rule (F-02): no recruitment may appeal to (i) an earnings figure not approved in writing, (ii) protection from any group of people, (iii) religious or caste merit, (iv) political change, (v) personal loyalty to any leader, or (vi) fear of missing out on a benefit. Each of these will work in the short term. Each of them builds the organisation that the constitution forbids.

---

# 7. WHY PEOPLE WOULD STAY (5 years, 20 years)

## 7.1 Joining is a marketing problem; staying is a design problem

**[A]** Attrition in voluntary organisations is dominated by ordinary life and by social experience, not by ideology: in one studied programme, 26% of leavers left simply because they moved and ~38% cited busyness with work/school or in general; elsewhere, cliques/exclusion, unsupportive leadership, unclear time expectations and a mismatch between promise and reality were the leading stated reasons; the first year is consistently the worst; and recognition was associated with materially lower turnover in one large study **[X]**. None of these are Indian-specific — they are human-specific. Your architecture addresses **expectation clarity** well (role boundaries, training, probation) and addresses **exclusion, unsupportive leadership, life-events and recognition** barely at all.

## 7.2 Retention mechanisms present in the architecture **[S]**

| Mechanism | Where | Strength **[A]** |
|---|---|---|
| Compensation for verified work | Ch.2, Ch.18–19 | Real but volatile (F-06); transactional retention is the weakest kind |
| Role progression and succession paths | Ch.9, Ch.10 | Saturates quickly in a 10-person team (F-24) |
| Leadership opportunity (Head Team) | Ch.26 | Powerful for ~1% of members; irrelevant to 99% |
| Member development as a scored dimension | Ch.25 (10%) | Right idea, unapproved weights, no individual development plan |
| Training across 10 categories | Ch.12 | Valuable, but training alone does not retain — in one study trained volunteers were *more* likely to leave, suggesting training raises expectations that the role then fails to meet **[X]** |
| Fair process, appeals, access to own records | Const. Art.6 (PROPOSED) | Strong *hygiene* factor: prevents leaving, does not cause staying |
| Fatigue tracking by Volunteer Manager | Ch.9 | The only burnout instrument in the document |
| Community trust as a scored dimension | Ch.25 (10%) | Indirectly retention-relevant: people stay where they are respected |

## 7.3 Retention mechanisms that are missing **[P]** — the actual answer to "why 20 years?"

**Tier 1 — Year 0–1 (survival):**
1. **A named human relationship on day one.** Every newcomer paired with one existing member for their first three contributions. Belonging is produced by a person, not a programme.
2. **A first win within 48 hours** (§21). Research and common practice both point to the first shift as decisive **[X]**.
3. **Explicit time contract.** "This role needs about N hours a month. You can pause." Removes the top stated reason for leaving **[X]**.
4. **A paused status, not a resigned status** (F-04). Life events should be a comma, not a full stop.
5. **Exit and stay interviews** (SOP gap — the 22 SOPs contain neither **[S: App. D]**).

**Tier 2 — Year 1–5 (identity):**
6. **A portable, verifiable credential** — graded certification plus an employer-usable service record and reference. People stay where their time is *converting into something they can carry*. This is also the strongest protection against F-24, because it makes staying rational even for those who will never be promoted.
7. **Friendship infrastructure** — stable small teams (not reshuffled), team rituals, shared meals after projects, family-inclusive events. Cheap, unglamorous, decisive.
8. **Scope growth without rank growth** — lead a bigger project, train a cohort, mentor a new team, run a city workstream. Circulating scope prevents the tournament bottleneck.
9. **Visible consequence of one's own work** — the person you helped, the lane that stayed clean, the shop that survived. Closed feedback loops are the emotional fuel; the architecture verifies outcomes but never *returns* them to the person who did the work.
10. **Fair treatment demonstrated, not promised** — one visibly fair grievance outcome per year in a city does more for retention than any policy document.

**Tier 3 — Year 5–20 (institutional self):**
11. **A service record that becomes part of the person's biography** — twenty years of dated, verified contribution that no other employer or institution can produce for them.
12. **Elder/mentor status** — a recognised non-command role for long-serving members: teaching, verifying, witnessing, blessing new teams. This is how institutions keep 60-year-olds useful and how knowledge survives turnover. *Not present in the architecture.* **[A]**
13. **Family continuity** — children and spouses participating at appropriate tiers; Indian institutions survive generations only when they are family-legible.
14. **Ownership of the institution's memory** — archives, anniversary records, named local achievements. People stay where their past is stored.
15. **A say in the rules** — the standard-change request route (F-13). People defend institutions they can amend.

## 7.4 Healthy retention vs. unhealthy dependency — the line

**[A]** The architecture's own values give the test: "serve without expecting reward", "responsibility follows earned trust", no retaliation, no coercion **[S: Ch.2]**. Applying them:

| Healthy (build this) | Unhealthy (prohibit this) |
|---|---|
| Staying because the work matters | Staying because leaving would be seen as betrayal |
| Staying because of friendships | Staying because one's social world would vanish |
| Staying because the record has value outside | Staying because the record is worthless outside (captivity) |
| Staying because income is fair and predictable | Staying because an advance/debt binds you (F-06 risk) |
| Staying because you can leave and come back | Staying because a break would erase your standing |
| Staying because you can criticise and be heard | Staying because criticism is disloyalty |
| Staying because the institution outlives its leaders | Staying because the institution *is* a leader |

**[P]** Add one explicit rule: **no member may be owed money, records, or credentials as a condition of continued membership.** Any mechanism that makes leaving costly rather than sad is a dependency mechanism, and it will eventually be exposed — usually by the person it trapped.

---

# 8. CITIZEN SEGMENTATION — THE CITIZEN-VALUE MAP

**Premise [A]:** the goal is **not** universal membership. It is *universal usefulness* — an institution that nearly every kind of citizen finds worth supporting, whether or not they ever hold a role. The library analogy is exact: most people who benefit from a library are not librarians, and the library does not want them to be.

**Participation levels referenced below are defined in §9.** Columns: what they *need*, what they can *give*, realistic level, first win, principal risk.

| Segment | What they need from Sewak Sathi **[A/I]** | What they can give | Realistic level | First win (≤2 hours) | Risk if mishandled |
|---|---|---|---|---|---|
| **School students (14–17)** | Safe structured activity, certificates, adult mentors | Energy, numbers, digital fluency, family reach | Community Participant → Volunteer (with guardian consent; safeguarding-mandatory) | One supervised clean-up or one digital-literacy helper slot | Safeguarding failure = institutional death; child-labour perception |
| **College students** | Verifiable experience, references, skills, belonging, some income | Time, skills, energy, campus networks | Volunteer → Verified Member → Coordinator | One verified project with a record they can put on a résumé | Being treated as free labour; credential that employers don't recognise |
| **Young professionals (23–32)** | Purpose, network, competence use, leadership experience | Specialist skills, pro-bono hours, credibility | Specialist → Coordinator (part-time, remote-capable) | One 3-hour pro-bono deliverable (accounts, design, legal, IT) | Bureaucracy; being asked to attend meetings instead of doing work |
| **Unemployed / underemployed youth** | Income, skill, dignity, a reference | Labour, local knowledge, availability | Verified Member (earnings track) | One paid task with transparent payment sheet | F-02: income promise not kept → scheme accusation |
| **Gig / informal workers** | Income continuity, insurance-adjacent solidarity, collective voice | Skills, availability, street-level knowledge | Volunteer → Verified Member (earnings track) | One task in their existing skill | Being poached into a worse deal than the open market (F-34) |
| **Women / homemakers** | Safe, time-bounded, near-home participation; income; recognition | Organisation, teaching, cooking, care, networks, meticulous records | Community Participant → Volunteer → Coordinator | One morning-slot activity within walking distance, with other women | Safety, timing, and male-dominated leadership freezing them out |
| **Small shopkeepers / local business** | Customers, footfall, a trustworthy local partner, help in crisis | Space, material, sponsorship, local information, in-kind support | Community Participant → Partner/Resource Member | One referral or one sponsored activity that brings visible goodwill | Being treated as a donor ATM; political contamination of their shop |
| **SME owners / contractors** | Reliable verified labour, delivery capacity, CSR channel, reputation | Contracts, paid work, mentorship, equipment | Partner + Venture customer | One small paid contract delivered well with evidence | Quality failure; being asked for free work under "social cause" pressure |
| **Farmers / rural households** | Inputs, information, labour pooling, market access, emergency help | Land, labour, local authority, produce | Community Participant → Volunteer | One village-level activity tied to a real need (water, school, animal health) | Urban-designed process that assumes literacy, smartphones, weekly cycles |
| **Teachers** | Student engagement channels, resources, recognition, safe volunteering | Teaching, curriculum, discipline, credibility with parents | Specialist → Coordinator | One class or one training session | Safeguarding exposure; unpaid labour expectations |
| **Doctors / nurses / allied health** | A safe, lawful channel to give care; medico-legal protection | Clinical expertise, camps, referrals, training | Specialist (strictly bounded: referral, awareness, camps under licence) | One awareness camp or one referral pathway | **Unlicensed practice, medico-legal liability** — the architecture already warns internal training is not legally sufficient **[S: Ch.12]** |
| **Lawyers / CAs / compliance professionals** | Pro-bono channel, reputation, institutional client | Legal, tax, audit, governance expertise | Specialist → Council-adjacent adviser | One document reviewed or one clinic hour | Unqualified advice being represented as organisational position |
| **Engineers / technical professionals** | Meaningful application of skill; visible local impact | Design, water/sanitation, safety, digital, energy expertise | Specialist → Project owner | One assessed local infrastructure problem | Liability for designs executed by untrained volunteers |
| **Retired persons / elders** | Purpose, company, respect, use of accumulated judgement | Time, patience, verification, mentoring, local memory, dispute mediation | Volunteer → Specialist → **Elder/Mentor** (proposed new role, §7.3) | One verification or mentoring assignment | Being marginalised by a youth-dominated, app-first design |
| **Creators / artists / journalists** | Stories worth telling, access, platform, integrity | Content, documentation, credibility, reach | Specialist → Communications contributor | One documented local story with evidence and consent | Being used to produce promotional content that violates Ch.24 accuracy rules |
| **People with disabilities** | Accessible participation, dignity, help | Perspective, skills, advocacy, meticulous work | Any level, with accessibility provision | One contribution designed to their access needs | Being excluded by physical/digital inaccessibility — a visible moral failure |
| **Residents who need help (beneficiaries)** | Reliable, dignified, non-humiliating help; someone to call | Local knowledge; later, participation (the growth loop, §22) | **Recipient → Community Participant** (the single most important conversion path) | Being helped well, once, with dignity and no publicity | Humiliation, data exposure (F-27), being photographed as proof |
| **Local authorities (municipal, police, school, hospital)** | A reliable, non-political, documented partner | Permissions, referrals, legitimacy, information | Institutional Partner (not member) | One clean, documented, permissioned joint activity | Being used as a parallel authority; F-09/F-28 perceptions |
| **Diaspora / NRIs** | A trustworthy channel to give to their home town | Money, skills, networks, technology | Donor/Resource Participant + Specialist (remote) | One transparent, evidenced, small project in their own village | FCRA exposure if foreign contribution is received without cover **[X]** |
| **Corporate CSR teams** | Compliant, auditable, documented implementation | Funds, volunteers, expertise, systems | Institutional Partner | One auditable project with a full evidence pack | Restricted-fund misuse; agenda capture (F-32) |
| **Faith-based service groups** | Collaboration without absorption | Volunteers, kitchens, spaces, distribution networks | Project Partner (strictly activity-scoped) | One joint activity with clear branding separation | Being classified as a religious organisation (F-08) |
| **Sceptics / critics / journalists** | Truth, access, accountability | Scrutiny — which is a service to the institution | **Non-participant, deliberately served** | A published report, an answered RTI-style query, an honest correction | Hostility born of unanswered questions |
| **People who will never join** | A cleaner lane, a safer street, a working drain, help in a crisis | Nothing — and that is fine | **Beneficiary of the commons** | Receiving help without being asked to join | Being recruited at the moment of need (coercive by effect, whatever the intent) |

**Two conclusions from this map [A]:**
1. **The last row is the strategic one.** If the organisation is *useful to people who never join*, it acquires the only asset that cannot be bought: ambient public legitimacy. That legitimacy is what protects it during F-08/F-09/F-36 crises. Design for non-members deliberately, not as an afterthought.
2. **Eight of these segments (students, young professionals, retirees, professionals, shopkeepers, women/homemakers, recipients, authorities) require no earnings and no command role** — yet the current architecture offers them essentially one participation format: Verified Member. That is the adoption gap quantified.

---

# 9. PARTICIPATION SPECTRUM — EVALUATION OF A LAYERED MODEL

**You asked me to evaluate, not to adopt. Here is the evaluation. [P throughout]**

## 9.1 Proposed spectrum (nine levels)

| Level | Definition | Verification required | Permissions | Time | Can they hold money/safety/HR responsibility? |
|---|---|---|---|---|---|
| **0. Observer / Well-wisher** | Knows what the organisation is; receives public information; may donate or sign a petition of support | None | None | 0 | No |
| **1. Community Participant** | Takes part in a specific, supervised, open activity; may raise a need; may receive help | Minimal: name + contact + consent, no identity documents | None in system beyond own participation record | Minutes to hours, once or occasionally | **No** |
| **2. Contributor (single-act)** | Gives one defined thing: one hour, one skill, one item, one introduction, one idea, one session | Identity *for the record* only where the contribution must be attributed; otherwise self-declared | Own contribution record | One act | No |
| **3. Volunteer (recurring)** | Repeats contributions; scheduled; supervised; trained for the tasks they actually do | Identity verification + task-specific training + safeguarding where relevant | Own tasks, own schedule, own record | Recurring, bounded | No |
| **4. Specialist (professional)** | Contributes licensed or professional expertise under a bounded, time-limited engagement | Professional credential verification + conflict declaration + scope agreement | Scope-limited; may advise; may not command | Episodic, remote-capable | Advisory only; never custodial |
| **5. Verified Member** | The architecture's existing spine: application → screening → identity verification → interview → training → probation → role | Full lifecycle **[S: Ch.12]** | Role-based RBAC | Sustained | **Yes — this is the entry point to responsibility** |
| **6. Coordinator** | Owns a workstream under a primary/sub-role **[S: Ch.10]** | Full + role training | Workstream-scoped | Sustained | Delegated, bounded |
| **7. Leader (primary/sub-role)** | Accountable owner of a function or team | Full + leadership/safety/finance-integrity training + conduct clearance | Full role authority within limits | Sustained, high | Yes |
| **8. Organisational Builder** | Creates new teams, ventures, systems, partnerships; sponsors others | Full + track record + audit clearance + Council/CEO process | Cross-team, with charter limits | Long-term | Yes, with enhanced oversight |

**Also proposed: Elder/Mentor** — a *non-command* standing for long-serving members: teaches, verifies, witnesses, mediates, blesses new teams, holds memory. Explicitly excluded from RBAC command permissions and from scoring. (§7.3, §15.)

## 9.2 Does this weaken verification? — **No, if three rules hold [A]**

1. **Responsibility begins at Level 5 and nowhere below.** Money, HR records, safety decisions, verification of others, publications, appointments — all remain behind the existing full lifecycle. The spectrum adds *nothing* to the permission surface below Level 5.
2. **Restricted tasks require role-specific training regardless of level** — the architecture already says so for volunteers ("cannot assign untrained people to restricted tasks" **[S: Ch.9]**). The spectrum makes that enforceable by giving low levels no system access at all.
3. **Data collected matches responsibility.** Level 1 needs name/contact/consent; Level 5 needs the full HR record. Collecting identity documents from a person who came once to plant trees would be a privacy failure *and* an adoption killer. This is also DPDP-aligned: data must be necessary for the specified purpose **[X]**.

**Compatibility with the existing architecture [A]:** the spectrum does not contradict the source — it *generalises* two things already in it. (i) The vacancy catalogue already contemplates a "Supporting Member" whose eligibility is "membership status appropriate to task" **[S: Ch.20]** — an explicit acknowledgement that status can vary with task. (ii) The Type field already distinguishes "volunteer, paid, mixed, stipend/contract/employee" **[S: Ch.19 vacancy record template]**. A formalised spectrum is therefore a **clarification of latent design**, not a silent change. It must still be approved per your own status-labelling discipline (PROPOSED — REQUIRES FINAL APPROVAL).

## 9.3 Dangers the spectrum creates (and their controls)

| Danger **[A/I]** | Control **[P]** |
|---|---|
| A shadow unverified workforce doing restricted tasks | Hard RBAC floor: no system write access below Level 5; task assignment for Levels 1–4 only through a Verified Member who is recorded as responsible |
| A second status hierarchy with its own politics (F-33) | Levels 0–4 are **not ranked publicly**; no badges, no leaderboards, no titles in public. Recognition at these levels is *narrative* ("these 40 people cleaned the lane"), never ordinal |
| Level inflation — everyone calls themselves a member | One word, one meaning: "Member" is reserved for Level 5+. Levels 0–4 use "participant/volunteer/specialist". Enforced in all communications per Ch.24 |
| Specialist tier capturing the organisation (professionals steering priorities) | Specialists advise, never command; conflict declarations; a cap on specialist-held coordinator positions per team |
| Low tiers used as a recruitment funnel that feels like a trap | No automatic progression; upgrading is always an explicit, separate, opt-in application with its own consent |
| Data creep — "we already have their number" | Purpose limitation and re-consent on upgrade; deletion on request at low tiers, retention per schedule at Level 5+ **[X]** |
| Beneficiaries recruited at the moment of need (coercive in effect) | **A hard rule: no person may be invited to participate within a defined window of receiving help, and never by the person who delivered it.** Assistance and recruitment must be separated by role and by time |
| Volunteer hours becoming expected free labour for the business pillar | Levels 1–4 may not be assigned to commercial venture work. Ever. Commercial work requires Level 5+ with the compensation framework applied |

## 9.4 Verdict

**[A]** A layered participation model is **necessary, not optional** — not because it is nice, but because the architecture's current single-door design (F-01) caps total participation at the number of people willing to undergo organisational vetting, which in any population is a small minority. The spectrum multiplies reachable citizens by an order of magnitude while *reducing* the permission surface at the bottom. It also fixes F-04 (paused/alumni), F-24 (specialist and scope paths), and the eight segments in §8 that currently have no legitimate place.

**It should not be finalised automatically.** It requires: your approval; legal review of the volunteer-vs-worker boundary at each level **[V]**; a privacy assessment of what is collected at each level **[V]**; and a safeguarding review of Levels 1–3 where minors or vulnerable adults participate **[V]**.

---

# 10. EMOTIONAL CONNECTION FRAMEWORK

## 10.1 Method

I tested each candidate emotion against three criteria: **(a) architectural consistency** — does the existing design actually produce this feeling, or would we be advertising something the system cannot deliver? **(b) durability** — does it survive no money, no promotion, and no applause? **(c) weaponisability** — can it be turned into fear, guilt, or us-vs-them?

| Candidate | (a) Consistency | (b) Durability | (c) Weaponisable? | Verdict **[A]** |
|---|---|---|---|---|
| **SEVA** (selfless service) | High — doctrine is seva-shaped **[S: Ch.2]** | Very high — needs no reward | **Yes** — can become moral blackmail, guilt, and a claim to moral superiority over those who don't serve; also carries faith-specific readings that could sectarianise the brand | **Core vocabulary, with two guards**: never used to induce guilt; never framed in one faith's terms |
| **BELONGING** ("sathi" = companion) | **Low today** — no belonging design exists in the document | Very high — the strongest retention force known | **Yes** — belonging defines an outside; it curdles into faction, clique and exclusion (both are named risks **[S: Ch.28]**) | **Essential but must be earned through design, and bounded by an explicit rule that belonging never overrides evidence** |
| **PURPOSE** | High | High | Mildly — can become self-righteousness | Support layer, not core |
| **RESPONSIBILITY** | High — "responsibility follows earned trust" **[S: Ch.2]** | Medium-high | Yes — becomes burden and guilt if unreciprocated | Support layer; must be paired with recognition |
| **COMMUNITY** | Medium — Mohalla structure is community-shaped | High | Yes — "community" in India is frequently a euphemism for caste or religious group | Use "neighbourhood" and "mohalla" (geographic, inclusive) rather than "community" (ambiguous, appropriable) **[P]** |
| **DIGNITY** | High — "dignity" appears in food service and evidence rules **[S: Ch.15, App. F]** | Very high | **No** — dignity is the only candidate that cannot be weaponised against the person it protects | **Non-negotiable floor** |
| **TRUST** | **Highest of all** — the entire architecture is a trust-production machine: verification, evidence, segregation, audit, transparency | High | No | **Core** |
| **CONTRIBUTION** ("I helped") | High — evidence and outcome verification exist precisely to make contribution *real* | Very high | No | **Core** |
| **HOPE** | Medium | Medium — hope needs evidence or it becomes disappointment | Mildly — false hope is the F-02 mechanism | Consequence, not premise: hope should be the *result* of a kept promise, never the *promise* |

## 10.2 The core emotional proposition

**[A]** Ranked, the compound that is most consistent with the architecture and least weaponisable is:

> **"My help reached someone real — and I was not alone in it."**
> *Trust × Contribution × Belonging, standing on a floor of Dignity, expressed in the cultural vocabulary of Seva.*

**Why this and not something simpler:**

- **"Reached someone real"** is the only claim your architecture can *prove*. Verification, evidence, outcome checks and the anti-fake-impact rules **[S: Ch.15]** exist precisely to make contribution non-fictional. That is your unfair emotional advantage: in an environment saturated with performative charity, you can show the work. Most organisations can only assert impact; this one is designed to evidence it.
- **"I was not alone in it"** supplies belonging — the missing half. Contribution without companionship produces burnout; companionship without contribution produces a club. The architecture has the first and needs the second.
- **Dignity as floor, not as slogan.** The person helped must not be humiliated, exposed, photographed as proof, or recruited at the moment of need. This is the constraint that keeps the emotional proposition from becoming extraction. It is already latent in your evidence standards ("avoid unnecessary beneficiary documents"; "no exposure of minors"; "dignity" in food service **[S: Ch.15, App. F]**) and should be elevated to an explicit article.
- **Seva as vocabulary, not as obligation.** The word carries enormous cultural legitimacy across Indian traditions and it is already implied by the name (*Sewak* = one who serves). Used descriptively it is powerful; used prescriptively ("a true sewak would…") it becomes the guilt mechanism that burns out good people.
- **Trust is the enabling condition, not the message.** You do not advertise trust; you accumulate it by keeping small promises visibly. Trust is what makes the other three emotions believable.

## 10.3 What the organisation must never make people feel

**[P]** Explicit prohibitions for all communications, ceremonies and internal culture:

1. **Guilt** for not giving enough time or money.
2. **Fear** — of any group of people, of the organisation's displeasure, or of losing standing.
3. **Shame** — of poverty, of receiving help, of low rank, of leaving, of a family's circumstances.
4. **Indebtedness** to a leader, a family, a community, or the founder personally.
5. **Superiority** over non-members, other organisations, other neighbourhoods, other faiths, castes, regions or languages.
6. **Outrage** as a mobilising fuel.
7. **Dependency** — the organisation should be a *floor people stand on*, not a *wall they lean against*.

Each of these works in the short term. Each of them produces the institution described in §27.

---

# 11. NATIONAL IDENTITY WITHOUT MANIPULATION, AND WITHOUT A PERSON

## 11.1 Mission > Person: why this is structurally urgent, not stylistic

**[S]** Article 3 vests ownership in Krytos under the founder/CEO; the Council is explicitly not above the CEO unless a charter changes it; CEO-vs-Council authority is UNRESOLVED. **[A]** Therefore, today, the institution's identity and its legal continuity are the same object, held by one person. That is survivable for a network of 50 teams. It is not survivable for a national institution, for three reasons:

1. **Mortality and incapacity** are certainties over a 20-year horizon (F-11).
2. **Identification risk:** if the public face is one person, every controversy about that person is a controversy about the institution — and there is no way to defend the institution by separating them.
3. **Motivational distortion:** personality-driven organisations recruit believers rather than contributors, and believers leave when the person disappoints them (F-17 motivation table, ❌ items).

**This is not a criticism of the founder.** Founder-led origin is normal and often necessary. The criticism is that the architecture has **no exit ramp from founder-centrality** — no instrument that transfers weight from the person to the institution over time.

## 11.2 The seven instruments that make MISSION > PERSON real **[P]**

| Instrument | What it does | Cost | Difficulty |
|---|---|---|---|
| **1. Mission lock** | Irrevocable purpose clause + supermajority + cooling-off + publication for any change to mission, brand, reserves or social-impact fund | Legal drafting | **Medium — requires the founder's willing consent, which is the real difficulty** |
| **2. Reserved matters for the Council** | A short list where the Council has a suspensive veto: constitutional amendment, mission change, brand/reserve transfer, CEO conduct, audit independence, head of Audit appointment | Charter | Medium |
| **3. Founder-succession article** | Nominated successor process, incapacity trigger, interim authority, successor bound by the same constitution | Charter | Medium |
| **4. Doctrine spoken by many voices** | The six core doctrine lines and the protection DO-NOTs are recited/quoted by members at every level in public, never only by the founder; the *text* becomes the authority | Zero | Low |
| **5. Institutional memory** | An archive: dated service records, decisions with reasons, corrections, failures, and an annual published report. Institutions survive because their memory is external to people | Low | Low |
| **6. Rituals that honour contribution, not persons** | Ceremonies name the work and the neighbourhood; no portrait-worship, no founder-day as the primary festival, no titles derived from a person's name | Zero | Low |
| **7. Distributed public representation** | Many spokespersons by domain and region, authorised under Ch.24 **[S]**, so the public image of the organisation is a *set of faces* doing work | Low | Low |

**The test to apply annually [P]:** *"If the founder were unavailable for twelve months, would any external observer notice a difference in what the organisation does?"* The goal is: no.

## 11.3 National identity built from facts, not adjectives

**[A]** A national identity that is not manipulative is built from **verifiable accumulation**: N neighbourhoods, N verified projects, N outcomes, N people trained, N rupees paid to workers, N incidents handled lawfully, N corrections published. The architecture already generates every one of these numbers. The identity strategy is simply to *publish them plainly, in local languages, without adjectives*, and let scale do the emotional work.

**Rule [P]:** every public claim must be traceable to a record a member could inspect. This is Ch.15's anti-fake-impact discipline applied to national branding — and it is the only form of patriotic-adjacent pride that cannot become propaganda.

---

# 12. LOCAL IDENTITY + NATIONAL NETWORK ("ONE INDIA, MANY INDIAS")

## 12.1 The localisation contract

**[A]** The document already draws the right line — states may adapt within standards but may not alter constitutional principles, final compensation percentages, protection boundaries, data policies or legal structures **[S: Ch.6]**. What is missing is the *positive* list: what MUST be local for the organisation to feel native. Without it, localisation happens silently (inconsistency) or not at all (rejection) — F-31/F-13.

**[P] IMMUTABLE (identical everywhere, word for word):**
1. Core doctrine and the six principle statements **[S: Ch.2]**
2. The six protection DO-NOTs and the intervention sequence **[S: Ch.16]**
3. Financial priority order and segregation of duties **[S: Ch.18]**
4. Membership verification gates for responsibility-bearing roles **[S: Ch.12]**
5. AI doctrine: recommend only; prohibited decisions; human review and logs **[S: Ch.21]**
6. Privacy, minimum-data, and dignity-of-beneficiary rules **[S: Ch.12, Ch.15, App. F]**
7. Political and religious non-alignment; non-discrimination in service **[S: Ch.2 + proposed F-08 code]**
8. Evidence standards: what counts and what never counts **[S: App. F]**

**LOCALISABLE (must be local, and locally decided):**
1. **Language and script** of every member-facing and public artefact
2. **Service mix** — which of the seven categories matter here (a coastal village's priorities are not a metro colony's)
3. **Calendar** — festival-linked service, harvest, monsoon, exam seasons, local fairs
4. **Recognition rituals** — how achievement is marked, what is considered honourable, who is invited (a village elder, a school head, a ward councillor as guest of honour — *as a guest, never as a patron*)
5. **Meeting form** — chai at a tea stall, a courtyard, a schoolroom, a community hall, an evening after prayers; time of day suited to who must be able to attend (women's participation depends almost entirely on timing and venue)
6. **Partner set** — municipality, panchayat, school, PHC, hospital, NGO, temple/mosque/gurdwara/church *service* committees (activity-scoped, never doctrinal), CSR
7. **Dress and visual identity** — no uniform (F-09); local colour and motif within national mark rules
8. **Venture categories** — what the local economy can actually buy
9. **Problem-definition authority** — the neighbourhood decides what its problem is; the centre decides only how it may be verified
10. **Names for roles** — the *function* is fixed, the *word* may be local (this matters enormously; "HR & Verification Manager" is a foreign phrase in most mohallas)

**Result: ONE CORE MISSION, MANY LOCAL EXPRESSIONS** — the immutable list is short enough to be memorised; the localisable list is long enough to feel like home.

## 12.2 How it feels native in different Indias

**[I — illustrative generalisations, each requiring local validation before use. These are hypotheses for field testing, not claims about any community.]**

| Context | Plausible first service focus | Plausible first venture focus | Native expression notes |
|---|---|---|---|
| **Uttar Pradesh (small city / old mohalla)** | Sanitation and drainage follow-up with the nagar nigam; school-support for first-generation learners; winter relief | Local business technology for traders; tuition/digital literacy; handicraft and metalwork-adjacent commerce | Dense kinship networks mean verification is easy and *independence* is hard — cross-team review matters more here than anywhere; language: Hindi first, with attention to regional speech |
| **Maharashtra (metro + semi-urban)** | Monsoon waterlogging, waste segregation, migrant-worker support | Design/development/content services; SME digital; event support | Higher formal-economy fluency: invoices, GST, contracts are natural; strong existing civic culture (RWAs, mandals) means partnership-first, not replacement |
| **Tamil Nadu** | School and library support, water conservation, elder care | Print/media services, software services, training | Strong existing civil-society and self-help-group fabric; enter as a partner and a complement, never as a rival; Tamil-first communications are non-negotiable |
| **Kerala** | Elder care, palliative support adjacency, environmental work, disaster preparedness | Skilled services, digital services, tourism-adjacent quality work | Highest civic literacy and strongest existing local-government interface; expect scrutiny and demand for transparency; publish more, earlier |
| **Punjab** | Drug-awareness and youth engagement, blood/medical-support adjacency, environment | Agri-services, logistics, fabrication, digital marketing | Existing religious service infrastructure is powerful (langar/seva traditions) — collaborate on activity, never on identity; be alert to F-13 (strong local leaders) |
| **Gujarat** | Education, health awareness, small-enterprise support | Trade-adjacent services, bookkeeping, digital commerce | Business-native culture: the venture pillar will outperform the service pillar here unless the F-17 service floor is enforced; watch mission drift closely |
| **West Bengal** | Flood/cyclone preparedness, education, health camps, cultural preservation | Creative services, content, design, printing | Politically saturated environment: the F-08 neutrality code will be tested here first and hardest; local-language primacy (Bengali) is existential |
| **Rajasthan** | Water, girls' education, animal health, heat relief | Handicraft commerce, tourism services, logistics | Seasonal migration means the *paused* status (F-04) is not a nicety but a necessity; timing around agricultural and wedding seasons |
| **Northeast India** | Health access, education, disaster and landslide response, environment | Agri and horticulture value chains, handicrafts, digital services, tourism | Distinct legal/land regimes and distinct identity politics: **state-level legal review is mandatory [V]**; Hindi-first anything will be read as imposition (F-31); partner with existing student and community bodies, do not compete |
| **Metropolitan cities** | Isolation/elder care, waste, migrant support, mental-health-adjacent awareness (referral only), emergency response | Professional services, digital, B2B | Participation is time-scarce: Specialist and Contributor tiers (§9) carry the city; anonymity means belonging design matters more here than anywhere |
| **Smaller towns** | Municipal follow-up, school support, sanitation, small emergency response | Local commerce digitalisation, repair and service businesses | Everyone knows everyone: verification is cheap, independence is expensive; recognition is highly motivating and highly political — apply F-33 rules strictly |
| **Rural** | Water, school, animal health, farm-adjacent support, connectivity to government schemes (information only, never brokerage) | Agri services, produce aggregation (careful: regulated markets **[V]**), rural digital services | Literacy and device constraints: voice/IVR and paper-first processes; weekly payment cycles may not match agricultural income rhythms (F-06) |

## 12.3 Connecting local identity to the national network

**[P]** The connection must run through **records and stories, not through hierarchy**:
1. **One service record, held locally, verifiable nationally.** A person's contribution in Madurai is legible in Moradabad. This is the single strongest national-binding instrument available and it is already implied by your data architecture **[S: Ch.22]**.
2. **Local achievement published nationally, national capability deployed locally.** Two-way flow: the network celebrates the lane that was fixed; the network sends a trainer, a specialist or a float when the lane cannot be fixed alone.
3. **An annual national assembly of local representatives** — not a rally, a working assembly: standards review, published corrections, and the "three things the ground told us" report (F-14). Ritual plus governance.
4. **National symbols that are empty of rank**: a mark, a colour, a phrase, a shared date of service. Nothing wearable that suggests authority (F-09), nothing ordinal that suggests status (F-33).

---

# 13. LANGUAGE STRATEGY

## 13.1 The problem, stated plainly

**[S]** The v1.2 document is written in English. Its role titles are English. Its concepts ("RBAC", "segregation of duties", "vacancy taxonomy", "Ground-Level Manager") are English-language management vocabulary. **[A]** If that vocabulary becomes the organisation's operating language, Sewak Sathi will be experienced in half of India as a metropolitan import — regardless of how sincere its mission is. Language is not a communications detail here; it is the *membership test that nobody writes down*.

## 13.2 Three-layer language architecture **[P]**

| Layer | Language(s) | Purpose | Who reads it |
|---|---|---|---|
| **L1 — Specification layer** | English (+ Hindi parallel) | Constitution, SOPs, legal documents, data dictionary, software spec, contracts, national reports | National team, lawyers, auditors, developers, partners |
| **L2 — Operational layer** | State's principal official language(s) | Training material, forms, dashboards, payment sheets, vacancy notices, incident forms, member records | City and Mohalla teams, members |
| **L3 — Public layer** | Local language and, where relevant, local dialect/register | Public notices, recruitment, service information, stories, recognition, helplines, signage | Citizens, beneficiaries, authorities, families |

**Rules:**
1. **Nothing that affects a person's money, status, safety or obligations may exist only in English.** Payment sheets, appointment letters, conduct warnings, suspension notices, safety instructions, consent forms — all in the member's declared language. This is also aligned with the DPDP requirement that privacy notices be clear, plain and available in English or any of the 22 Eighth Schedule languages **[X]**.
2. **One source of truth, one controlled translation.** A terminology register per language, so "Verified Member", "Team Leader", "incident" and "reserve" mean exactly one thing in every language. Version-controlled; a translation is a *release*, not an improvisation.
3. **Human review of every machine-translated text before publication or before it affects a person.** AI may draft; a named fluent human approves and is recorded (extends the AI doctrine **[S: Ch.21]** to language).
4. **Local-language role names.** Functions are immutable; words are local. Publish a mapping table so a "Verification Officer" in Tamil Nadu and in UP is the same role with the same authority and a different name.
5. **Voice-first and low-literacy design** for L3: IVR/voice notes, audio training, pictorial forms, in-person explanation as the default for rural and low-literacy participants. A form nobody can read is not a record; it is a liability.
6. **A language-equity metric**, published annually: % of members able to complete onboarding, training, a task record, a grievance and a payment confirmation *entirely in their own language*. Target: 100%. This metric will be embarrassing for two years and decisive for twenty.

## 13.3 Hindi and English: the political trap and how to avoid it **[P, V]**

**[A/I]** Any national organisation in India is read through the language question. Two failure modes are available and both are fatal in different regions:
- **Hindi-first** reads as imposition in Tamil Nadu, Kerala, Karnataka, West Bengal, Maharashtra and the Northeast, and will generate organised resistance and a permanent "north Indian organisation" label.
- **English-first** reads as elite and metropolitan everywhere outside the metros, and will exclude precisely the people the mission prioritises.

**The only safe design: state-language-first in each state, with Hindi and English as internal link languages and never as public impositions.** In UP, Bihar, MP, Rajasthan, Haryana, Delhi, Hindi is simply the local language — no special status needed. Everywhere else, the local language leads. Nationally, published material appears in multiple languages *simultaneously*, not in a translated cascade where one language is original and the rest are derivative. Simultaneity is a small operational cost and a large symbolic gain.

## 13.4 What this costs

**[A-assumption]** Terminology registers and translation of the core operating set (constitution summary, 22 SOPs, 14 evidence templates, training modules, forms) into, say, 8–12 languages is a substantial but *bounded* one-time effort, plus ongoing maintenance. It is far cheaper than losing a state. **Do not do all languages at once**: start with the languages of the pilot geographies, and add a language only when a state is actually being entered — but *commit publicly to the principle* immediately, because the commitment itself is what changes perception.

---

# 14. TRUST ARCHITECTURE — "WHY SHOULD A STRANGER TRUST SEWAK SATHI?"

## 14.1 The four things a stranger is actually asking

**[A]** "Trust" is not one question. A resident deciding whether to let Sewak Sathi into their lane, their home, or their child's tuition class is asking four separate questions, and each needs a different kind of answer:

| Question | What satisfies it | What the architecture provides **[S]** | Gap |
|---|---|---|---|
| **1. Are they competent?** (will they actually fix it / not make it worse) | Repeated, visible, small successes; skill evidence; knowing when to say no | Verification, training, QA, evidence standards, outcome verification | Nothing *public* demonstrates competence before engagement; competence is proved only to insiders |
| **2. Are they honest?** (will the money and material actually reach the purpose) | Traceable money, published accounts, receipts, no personal enrichment | Waterfall, segregation, receipts, reconciliation, audit, restricted funds | **Not published.** All honesty machinery is internal. A stranger cannot see any of it |
| **3. Are they safe?** (will they not harm me, my family, my data, my reputation) | Boundaries visibly respected; no weapons; no intimidation; privacy honoured; children protected | Six DO-NOTs, risk tiers, safeguarding training, privacy-controlled records | Visibility protocol, dress/symbol rules, certified safeguarding, privacy notice, data-breach plan |
| **4. Are they accountable?** (if something goes wrong, is there someone to go to, who will act) | A named recipient of complaints, a published outcome, a visible correction | Audit & Ethics department, dispute routes, corrections, appeals | **No public-facing complaint channel, no ombuds, no published outcomes** |

**Conclusion [A]:** the architecture is strong on *being* trustworthy and almost entirely silent on *being seen to be* trustworthy. Trust that cannot be observed does not compound.

## 14.2 The trust-production system **[P]**

**Layer 1 — Micro-trust (the only layer that actually scales):**
Every act of help, done competently, with dignity, on time, with no ask in return, deposits trust in a *person-to-person* account. This is the growth loop in §22. Nothing else substitutes for it. Everything in Layers 2–4 exists to protect and amplify Layer 1, never to replace it.

**Layer 2 — Verifiable local presence:**
- A public, simple, local record: what this team did, where, when, with what result — published in the local language, with privacy-protective detail.
- A way for any resident to check authenticity: a public verification channel (phone/WhatsApp/website) where anyone can confirm whether a person or a group is genuinely associated, and in what role. This also defends the brand against impostors (§4.3).
- Named local accountability: a published local contact and a published *non-local* contact, so anyone uncomfortable with the local one has somewhere else to go (fixes F-21 publicly).

**Layer 3 — Institutional transparency:**
- **Publish the boring things.** Quarterly: money in, money out, worker compensation paid, reserve position, social-impact fund utilisation, incidents and their outcomes, corrections issued, complaints received and resolved, teams recognised and teams closed. Plain language, local languages, no design gloss. Boring transparency is more credible than polished reporting.
- **Publish failures.** Ch.15 already requires including failures and partial outcomes in reports **[S]**. Extending that to *public* reporting is the single most differentiating trust act available to this organisation, and almost no Indian institution does it. **[I]**
- **Publish the rules before the results:** approval limits, allocation criteria, eligibility criteria, payment formula version. When people know the rule in advance, an outcome they dislike is a disappointment; when they learn the rule afterwards, it is a conspiracy.
- **Independent review where appropriate [V]:** statutory audit; an external safeguarding review; a periodic external governance review reporting publicly. Independence is the only credibility a self-audit cannot manufacture.

**Layer 4 — Structural trust (for institutions, not individuals):**
Legal entity clarity and honest status disclosure; insurance; data-protection compliance; grievance redressal with timelines (DPDP expects time-bound grievance handling **[X]**); partnership documentation; a mission lock (§11). Corporates, CSR teams, government counterparts, donors and regulators trust structures, not intentions.

## 14.3 What must be true before national trust can exist **[P]**

A pre-condition list. Each is falsifiable and each should be *demonstrated*, not asserted:

1. **Legal form exists and is publicly stated accurately**, with tax/employment classification resolved **[V]** — currently UNRESOLVED **[S: Ch.33]**.
2. **One full year of published accounts** for the pilot, however small, with worker compensation shown separately.
3. **Zero unresolved serious safety incidents** in the pilot, and every incident published in summary form.
4. **A functioning public complaint channel** with published resolution statistics and at least one *published adverse finding against the organisation itself* — proof the channel has teeth.
5. **Insurance in force** for members and third parties **[V]**.
6. **A privacy notice in every operating language**, a retention schedule, and a rehearsed breach response **[V, X]**.
7. **A Political Neutrality Code adopted and published**, with a refusal log demonstrating it has been used (F-08).
8. **At least one independently verified impact claim** — an external party confirming an outcome, not the organisation confirming its own.
9. **A published correction** — evidence that the organisation has corrected itself publicly at least once. Institutions that have never corrected anything are either dishonest or inactive.
10. **Succession and mission-lock instruments executed** (F-11) — the point at which an institution stops being a person's project.

**Until items 1–7 are true, national expansion should not proceed.** This is not caution for its own sake; it is that a trust failure at national scale is not survivable, and each of these items is cheap before scale and unaffordable after.

---

# 15. CULTURE ARCHITECTURE

## 15.1 The culture the architecture implies

**[A]** Read the document as a cultural artefact rather than an operational one and a clear personality emerges. It is: **evidence-obsessed, dignity-conscious, anti-theatrical, suspicious of power, protective of workers, hostile to inflation of claims, and impatient with sentiment unaccompanied by proof.** Phrases like "do not count planned activities as completed impact", "include failures and partial outcomes in reports", "unsafe success is not success", and "raw revenue cannot determine leadership" **[S]** are cultural statements, not accounting rules.

That is a *good* culture and a *rare* one. It is also a *hard* culture — it asks people to be honest when dishonesty is cheaper, and to be modest when visibility is rewarded. It will not survive on exhortation. It survives only if it is **practised by the most senior people first, in public, at cost to themselves.**

## 15.2 Culture to encourage — with observable behaviours (not adjectives)

**[P]** Adjectives are unenforceable. Behaviours are. Each row: the value, the behaviour that proves it, the behaviour that fakes it.

| Value | Proving behaviour | Faking behaviour (watch for this) |
|---|---|---|
| **Truthful** | Publishes a failure before being asked; corrects a claim against its own interest | Publishes only successes; corrections buried in footnotes |
| **Competent** | Says "we cannot do this well yet" and refers elsewhere | Accepts every request and delivers badly |
| **Humble** | Credits the neighbourhood and the people helped; leaders speak last | Credits the organisation; leaders speak first |
| **Accountable** | A named person answers a complaint in writing within a stated time | "The matter is under review" forever |
| **Courageous** | Stops unsafe work; refuses a politically useful offer; reports a friend's violation | Courage only toward people with no power |
| **Disciplined** | Records exist *before* the payment, not after | Back-filled registers with identical handwriting |
| **Inclusive** | The quietest person in the room is asked; women, elders and marginalised residents are present and speaking | Inclusion photographed but not practised |
| **Locally rooted** | The team knows the lane's actual problem in its own residents' words | The team arrives with a national template |
| **Entrepreneurial** | Finds legitimate paying work without compromising service | Finds paying work instead of service |
| **Frugal** | Spends less than it could and shows the receipt | Frugality demanded of others, not of leadership |
| **Warm** | People are greeted by name; tea is offered; children are welcome | Warmth reserved for useful people |

## 15.3 Culture that must be prevented — with tripwires

| Toxic culture | How it starts | Tripwire metric **[P]** | Owner |
|---|---|---|---|
| **Status-seeking** | Titles used socially; rank mentioned in introductions | Recognition concentration index (are the same people always recognised?); title usage in public posts | Communications + HR |
| **Factionalism** | City clusters vote as blocs; information withheld across teams | Cross-team collaboration rate; complaint source clustering; promotion patterns by origin team | Audit + Council |
| **Metric theatre** | Activity counts rise, outcomes flat | Activity-vs-outcome ratio; follow-up verification completion (F-20) | Operations + Audit |
| **Favouritism / nepotism** | Relatives in control roles; appointments without vacancy records | Relationship declarations; appointment-without-vacancy rate; reviewer independence rate | HR + Audit |
| **Fear culture** | No warnings issued, no complaints filed, no dissent in meetings | Complaint volume *per team* (near-zero is a bad sign, not a good one); anonymous-channel usage; exit-interview candour | Council + HR |
| **Bureaucratic suffocation** | Forms multiply; decisions wait for approval | Governance hours per team (F-05); median decision latency; exception requests | Operations |
| **Founder worship** | Portrait prominence; quotes attributed; decisions deferred to "what sir would want" | Frequency of founder attribution in internal decisions; whether decisions are made in his absence | Council |
| **Moral superiority** | Members describe non-members as selfish; service framed as virtue over others | Language audit of public content; complaints from partner organisations | Communications |
| **Mercenary drift** | Paid work crowds out service | Hours split by pillar; service floor compliance (F-17) | Business + Operations |
| **Grievance economy** | Allegations used as tactics | Allegation timing analysis (F-22); proven-false rate | Audit |

## 15.4 How culture is actually transmitted (the honest answer)

**[A]** Culture is transmitted by five things, in this order of power: **what is rewarded, what is punished, what is tolerated, what is told, and what is written.** Training is sixth. Your architecture invests almost entirely in #5 and #6 — written rules and training categories **[S: Ch.12]** — and has weak instruments for #1–#4: rewards are an unapproved leaderboard; punishment is a conduct rule with no protected reporting channel; tolerance is undefined (what does a leader get away with?); stories have no owner.

**[P]** Therefore:
- **Make the reward system legible and fair before making it ambitious** (F-19 normalisation, F-24 horizontal ladder).
- **Publish one punishment per year that hurts** — a leader removed for a proven violation, described plainly. Nothing teaches a culture faster, and nothing is harder to do.
- **Define tolerance explicitly**: a short published list of "we do not let this slide, ever" (back-filled records, unverified claims, cash without receipt, unsupervised work with children, political use of the brand).
- **Appoint a story owner**: a function whose job is to collect, verify (per Ch.24 accuracy rules **[S]**) and distribute true stories of service. This is not propaganda if and only if every story is evidence-linked and consented — which your own rules already require.

---

# 16. ANTI-CULT / ANTI-ABUSE SAFEGUARDS

**[A]** This section matters more than it might appear. An organisation with: a single charismatic owner, a moral mission, ranked teams, recognition rituals, a service record, a shared identity word ("sathi"), local cells, a doctrine recited in common, and an emotionally charged purpose — has, structurally, most of the *apparatus* of a high-demand group. **[I]** The absence of cult behaviour is not guaranteed by good intentions; it is guaranteed by specific, boring, enforceable constraints. None of these exist explicitly in v1.2.

## 16.1 Prohibited mechanisms (constitutional-level prohibitions) **[P, V]**

1. **No compelled participation.** No member may be required to attend an event, contribute money, recruit others, or post publicly as a condition of standing, role, score or payment.
2. **No guilt-based mobilisation.** No communication may imply that a person's worth, faith, patriotism, community loyalty or family honour depends on participation.
3. **No information control.** Members may speak to anyone — including journalists, critics, other organisations and former members — without permission. No rule may require internal approval to *describe one's own experience*.
4. **No isolation.** No practice that separates members from family, friends or other affiliations; no residential or retreat-style programme without independent safeguarding review; family inclusion actively encouraged.
5. **No confession or disclosure rituals.** No requirement to disclose personal beliefs, family circumstances, finances, relationships or faith practice. Conduct records only for conduct that affects the organisation's work or safety.
6. **No purity testing or ideological certification.** Membership criteria are conduct, verification and training — never belief, opinion, or loyalty.
7. **No personality veneration.** No portraits in official spaces as objects of reverence; no founder-attribution requirement in decisions; no titles derived from a person; no birthday/anniversary observances of individuals as organisational festivals.
8. **No enemy construction.** No internal or external communication that identifies a group of people (political, religious, caste, regional, linguistic, or organisational) as an adversary. Criticism of *acts* is permitted; construction of *enemies* is not.
9. **No financial entrapment.** No loans, advances, deposits, or debts binding a member to the organisation; no withholding of records, credentials or earned compensation as leverage (see §7.4).
10. **No exit cost.** Leaving must be administratively trivial, socially sanctioned, and reputationally safe. A published "how to leave" page. Alumni remain welcome.
11. **No dependency framing.** The organisation must not describe itself as the only source of help, safety, income or dignity available to a member or a neighbourhood.
12. **No secrecy tiers among members.** Information asymmetry must follow *role need* (RBAC) and never *inner-circle* membership. If a fact is known to five people because they are close to power rather than because of role, that is a cult structure forming.

## 16.2 Institutional checks that make the prohibitions real **[P]**

- **An independent ethics function** reporting to the Council, not the line — with authority to review culture, complaints, recognition patterns and leadership conduct (extends Audit & Ethics **[S: Ch.5]** with independence guarantees).
- **A published annual culture report**: complaint volumes and outcomes, exits and reasons, recognition distribution, founder-attribution frequency, tolerance-list violations, and the results of an anonymous member experience survey with *unflattering items included*.
- **Anonymous member experience survey** with a mandatory response: if a metric deteriorates, the organisation publishes what it will do.
- **Term limits or rotation for control roles** (F-03, F-13, F-26): long tenure in one place is the substrate for both corruption and personality cults.
- **A public "how to complain about us" page**, including how to complain to an external body (regulator, consumer forum, police) — explicitly naming external routes. An organisation that only offers internal routes is signalling that it intends to control the outcome.
- **Two-deep rule for authority**: no single person may simultaneously control recruitment, money, records and discipline in one team (a generalisation of the segregation principle **[S: Ch.18]** to *power* rather than only finance).
- **Anti-retaliation as serious misconduct**, with a published case outcome at least once.

## 16.3 The safeguarding dimension (distinct from cult risk, and more urgent) **[P, V]**

Working with children, elders, people with disabilities, survivors of violence and distressed households creates duties that a volunteer architecture can fail catastrophically:
- **Certified safeguarding training** for anyone working with minors or vulnerable adults — the document already warns that internal training is not legally sufficient **[S: Ch.12]**; that warning must become a hard gate, not a caveat.
- **Two-adult rule**: no member alone with a minor or vulnerable adult, ever, in any circumstance.
- **Consent and image rules**: no photograph of a minor, no beneficiary image used as proof, no publication of a recipient's identity — extending **[S: Ch.15, App. F]** into an absolute prohibition with disciplinary consequence.
- **A reporting duty to authorities** for suspected abuse, with a written protocol and legal review **[V]** — currently the architecture says "contact authorities when risk requires" **[S: Ch.16]** without specifying the mandatory-reporting situations.
- **A survivor-centred records regime** (F-27): pseudonymised case identifiers, sealed records, access with reason codes.
- **An external safeguarding adviser** with direct access to the Council and the right to publish.

---

# 17. BUSINESS vs SERVICE — THE CENTRAL TENSION, AND THE FIREWALLS

## 17.1 Why this tension is structural and not a matter of discipline

**[A]** The architecture makes business and service co-equal pillars **[S: Ch.3]** and then attaches money to one of them. Specifically:
- Business produces **revenue → compensation** (immediate, certain, personal) **[S: Ch.18–19]**.
- Service produces **impact → a weighted score component (20%)** (delayed, contestable, impersonal) **[S: Ch.25]**.
- Business also funds the social-impact fund, which is the *only* mechanism converting commercial success into mission spending **[S: Ch.20]**.

Three consequences follow mechanically, without anyone behaving badly:
1. **Time flows to the pillar that pays.** Best people, best hours, best attention.
2. **Measurement flows to what is countable now** (F-20), and revenue is countable now.
3. **The organisation's self-image follows its income.** An institution that earns 80% of its money from services rendered will describe itself as a services organisation within three years, whatever its constitution says.

The document *sees* this ("mission drift — revenue over service/safety" **[S: Ch.28]**) and answers it with "rebalance score, close ventures; CEO/Council" — a discretionary, detective control. **Discretion loses to incentives over time.** The answer must be structural.

## 17.2 Specific failure situations and their safeguards

| Situation | How it manifests | Existing control **[S]** | Sufficient? | Additional safeguard **[P]** |
|---|---|---|---|---|
| **Business becomes more important than service** | Service projects become occasional; venture work dominates calendars | Mission impact 20% weight; risk register | No | **Service floor**: minimum verified service outcomes per team per quarter, or score capped regardless of revenue |
| **Service consumes too much money** | Donations and reserve diverted to unfunded service; venture capital starved | Restricted social-impact fund; reserve approval matrix | Partially | **Service cost discipline**: every service project has a budget, a funding source and an approved scope; no unfunded commitments (already implied by Ch.8 step 6 — make it a hard gate) |
| **Workers are underpaid** | "Distributable amount" is small; leader multiplier absorbs it; members get tokens | Priority 1 = worker compensation; bad-month rule | **Yes in principle** | Add: published minimum per-task rates by category; a rule that a venture below viability threshold is *not started* rather than started and underpaid |
| **Customers are dissatisfied** | Beginner-heavy delivery, over-promising, scope disputes | QA step, acceptance step, category controls | Partially | **Right of refusal**: a team may decline work it cannot deliver well, without score penalty — protects the brand and prevents the F-34 spiral |
| **Ventures lose money** | Repeated losses disguised by activity | "Close/restructure and pay obligations" **[S: Ch.28]** | Yes on closure, no on detection | **Stage gates with a stop-loss**: a venture gets N cycles to reach contribution positive; failure closes it without stigma (make closure a *normal* administrative act, or it will be hidden) |
| **Social projects depend on business revenue** | A bad quarter cancels committed service | Social-impact fund only on surplus | No — this is by design and is a real fragility | **Commitment rule**: never publicly commit to recurring service that depends on venture surplus; recurring commitments require recurring funding (partnership, municipal, CSR, or reserve) |
| **Leaders prioritise profitable communities** | Teams cluster in wealthy areas; hard areas unstaffed | Non-discrimination doctrine | No | **Cross-subsidy policy + cohort scoring** (F-18, F-19); a published footprint map by area deprivation, so drift is visible |
| **Financial incentives distort volunteer behaviour** | Volunteers steer toward paid tasks; free help declines | Volunteer Manager boundaries; anti-gaming | Partially | **Separate tracks**: service volunteering and venture work are different registers with different recognition; a member's *service* record is never enhanced by commercial work |
| **Business interests capture governance** | Business leaders dominate councils, standards, and the leaderboard | Department separation; conflict disclosure | No | **Mission-conflict segregation**: the AI & Business Manager may not hold Funds, Audit, or performance-scoring roles in the same team; business representation on governance bodies capped |
| **The brand is used to sell** | "Sewak Sathi-recommended" products; charity-adjacent marketing | Editor and communications rules; no unverified claims | Partially | **Absolute rule**: the organisation's name and service record may never be used to endorse a commercial product or service, including its own ventures. Ventures trade under their own names |

## 17.3 The balance instrument: a published Mission Balance Statement **[P]**

Annually, per city and nationally, publish: hours by pillar; verified service outcomes; venture revenue; worker compensation paid; social-impact fund utilisation; teams closed for mission conflict; exceptions granted. One page. No commentary.

**Why this works [A]:** it converts an unenforceable value ("service matters most") into an observable quantity that members, critics and the Council can watch over time. Mission drift then becomes *legible* before it becomes irreversible — and legibility is the only defence that does not depend on anyone's virtue.

---

# 18. PUBLIC PERCEPTION — WHAT PEOPLE WILL THINK IT IS

## 18.1 What the architecture says it is **[S]**

A Krytos-owned, founder-led, nationally scalable, locally distributed organisation with four functions: social service, community network, protection/first response, and AI-enabled business operations. Not charity-only; not vigilantism; not AI-controlled; not micromanaged; not status-based. Verified membership; earned autonomy; priority waterfall; AI recommends, humans decide.

**[A]** That is eleven concepts. No human being holds eleven concepts about an organisation. The public will collapse it into **one** category, chosen by whatever they encounter first and whatever they fear most.

## 18.2 Misclassification map

| Perceived as | Who perceives it | Why **[A/I]** | Danger level | Prevention |
|---|---|---|---|---|
| **A political organisation / party front** | Media, rivals, police, opposing communities, urban middle class | Mass membership + street presence + leaderboards + single founder + service distribution near elections | **Severe** — F-08 | Political Neutrality Code; refusal log; no distribution near elections; diverse public faces; explicit non-alignment statement in every onboarding |
| **A religious or caste outfit** | Neighbourhoods where a team is compositionally skewed | Local teams reflect local demographics; service near religious festivals | **Severe** | Composition monitoring; activity-scoped partnership rules with faith bodies; no religious framing ever; service calendar deliberately multi-festival |
| **A private security agency / vigilante group** | Police, residents in tension areas, media after any incident | The word "protection"; group presence; intervention stories | **Severe** — F-09 | Visibility protocol; no uniform/insignia; public "we are not a security force" statement; do-not-attend list; authorities-first doctrine made public |
| **An NGO that needs donations** | General public, well-wishers | Service imagery; "sanstha" in the name | Moderate — imports dependency and funder capture (F-32) | State clearly that the organisation earns revenue and is not donation-dependent; publish the funding mix |
| **A private company / agency** | Customers, competitors | The business pillar, invoices, QA, delivery | Moderate — collapses the mission; invites "they use charity to get clients" | Separate venture trading names; never use the service brand to endorse commerce (§17.2) |
| **A job portal / scheme** | Job-seekers, and their families | Any mention of payment for verified work | **High** — F-02 | Published earnings reality; recruitment-conduct rule; separate service and earnings doors |
| **An AI/tech startup** | Urban professionals, investors, media | "AI Business Network", platform modules, dashboards | Moderate — attracts the wrong partners and the wrong expectations | Describe AI as an internal tool, never as the product; lead with service in every explanation |
| **A volunteer WhatsApp club** | Sceptics, officials, journalists | Local groups, informal feel, early-stage manual processes | Moderate — undermines credibility with authorities and partners | Evidence, published records, formal entity, insurance, documented SOPs |
| **A charity for the poor (with poor people as props)** | Donors, media, beneficiaries themselves | Beneficiary imagery | **High** — dignity violation, and it defines the organisation as hierarchical | Absolute image and consent rules; beneficiaries never used as proof; stories told by participants, not about recipients |
| **A parallel government** | Officials, and eventually the organisation itself | Municipal follow-up, emergency coordination, local problem-solving at scale | **High** — invites state hostility and mission overreach | Explicit boundary statement (§29); always route through authorities; never claim authority; publish that it does not replace any government function |
| **A surveillance network** | Privacy-conscious citizens, journalists, minorities | Verification, records, QR cards, member databases | **High** — F-27/F-28 | Publish what data is held, why, for how long, and who can see it; a public privacy notice; QR use restrictions; no public scanning |

## 18.3 The correction instruments **[P]**

1. **One category sentence, identical everywhere, in every language.** It must pass the 10-second test (§20).
2. **A published "what we are not" list** — the six or seven misclassifications that matter most, stated plainly and without defensiveness.
3. **Segment-specific explanations** — one for residents, one for customers, one for officials, one for students, one for partners, one for media. Same facts, different salience. All approved by the Editor function per Ch.24 **[S]**.
4. **Legal-status honesty**: state exactly what entity exists, what registration is pending, and what the organisation is *not yet authorised* to do. Under-claiming is a trust strategy; over-claiming is a liability.
5. **A misclassification response protocol**: who responds, how fast, in what tone (calm, factual, non-defensive, per Ch.24's misinformation rule **[S]**), and with what evidence.
6. **Never argue with a label in public; replace it with a fact.** "We are not political" is weak. "Here are the eleven elections in which we distributed nothing and declined four sponsorship offers — the refusals are logged" is strong.

---

# 19. COMPETITIVE DIFFERENTIATION — WHAT PEOPLE USE INSTEAD

## 19.1 The real competitor set **[A/I]**

| Alternative | What it does better than Sewak Sathi | What it does worse | Why someone stays with it |
|---|---|---|---|
| **Mohalla WhatsApp group** | Zero friction; instant; everyone is already in it; no verification | No accountability; no evidence; no resources; collapses into rumour and politics; nobody responsible | It costs nothing and requires nothing |
| **RWA / colony association / panchayat interface** | Legitimacy with authorities; existing mandate; property-owning stakeholders | Narrow (residents only); often caste/class-exclusive; slow; political | It already has the authority relationship |
| **Faith-based service committees (langar, seva dal, church/temple committees)** | Enormous trust, volunteers, kitchens, funding, and moral motivation | Restricted by identity; not open to all; not evidence-based; not scalable as a neutral body | Deep meaning and community sanction |
| **Established ideological service networks** | Decades of presence, cadres, discipline, schools, clinics, and street-level organisation | Identity-bound; politically adjacent; exclusive in practice | Belonging and lifelong identity |
| **Caste / community associations** | Real mutual aid, real credit, real marriage and job networks | Exclusionary by definition | They are the actual social insurance system for many Indians |
| **Professional NGOs** | Grant access, professional staff, domain expertise, compliance capability | Absent from most neighbourhoods; project-driven; accountable upward to funders; expensive | Funding and legitimacy |
| **NSS / NCC (≈3.8–3.9 million NSS volunteers) [X]** | Institutional reach through colleges; certificates students value; government backing | Time-bound to student years; activity-driven; weak on outcomes and continuity | It is already in the college calendar and gives a certificate |
| **Gig / freelance platforms** | Higher pay, instant demand, no governance overhead, global customers | No community, no purpose, no verification of character, race-to-bottom pricing | Money, immediately |
| **Local service providers (plumbers, tutors, designers, agencies)** | Speed, price negotiation, no membership, known quality | No accountability, no verification, no recourse, no social purpose | Convenience |
| **Government schemes and helplines** | Authority, funding, entitlement | Access problems, delays, corruption, no personal relationship | It is the legitimate provider |
| **Social networks** | Attention, virality, fundraising, awareness | Performative; no delivery; no verification; outrage-driven | They are where people already are |

## 19.2 Honest differentiation — what Sewak Sathi can actually claim

**[A]** Four claims are *defensible* because the architecture genuinely produces them, and three commonly-assumed claims are *not*.

**Defensible:**
1. **"Verified help that actually arrives, with evidence."** The verification + evidence + outcome-verification chain **[S: Ch.8, Ch.15, App. F]** is something a WhatsApp group, an NGO press release, and a social campaign all lack. This is the core claim and it is real.
2. **"You can see where the money went."** Priority waterfall + receipts + reconciliation + published accounts **[S: Ch.18–19]**. In the Indian giving environment, this is close to unique — and it is only a differentiator if actually *published* (§14).
3. **"Your contribution is recorded and portable."** A verified, dated, externally checkable service record and reference. Nothing else in the informal civic space offers this to a 19-year-old or a returning homemaker. **This is the most valuable and least developed asset in the architecture.**
4. **"Neighbourhood-scale, national-capability."** A local team that can pull a specialist, a warehouse, a city reviewer, a safety escalation and a float from a national network. Neither a WhatsApp group nor a national NGO can do both ends.

**Not defensible (do not claim these):**
1. ~~"We are cheaper/faster than a professional agency."~~ You are not; you carry a governance cost they don't (F-05).
2. ~~"We pay better than the open market."~~ You almost certainly don't (F-34). Claiming it produces F-02.
3. ~~"We are more trustworthy than existing community organisations."~~ Existing faith, caste and neighbourhood bodies hold *far* more trust than a new entity. Claiming superiority is both false and insulting, and it manufactures enemies. The correct claim is: *"we are verifiable"* — a different axis, on which you can win without anyone losing.

## 19.3 The strategic answer to "why would someone use this instead?"

**[A]** Nobody will *switch*. The correct model is **complement and escalate**:
- **Complement** what already exists: work *with* the RWA, the school, the PHC, the faith-based kitchen, the shopkeepers' association — activity-scoped, evidence-shared, credit-shared. This is permitted by Ch.29 partnerships **[S]** but should become the *default* posture rather than an option. A new organisation that arrives as a rival to existing local institutions will be destroyed by them; one that arrives as capacity will be adopted.
- **Escalate** what they cannot do: verification at scale, cross-neighbourhood resource movement, specialist deployment, audited accounts, portable records, digital capability, safety escalation, and continuity when a local group collapses.

**The one-sentence competitive answer [P]:** *"Your mohalla group means well and cannot keep records. An NGO keeps records and is not in your mohalla. A platform pays and does not care. We are the thing that is in your mohalla, keeps records, and pays fairly — and we can prove all three."*

---

# 20. THE 10-SECOND TEST AND THE FIRST 5 MINUTES

## 20.1 The 10-second test applied to the current architecture

**Test:** a person sees the name, a poster, a stall, or a member for ten seconds. Can they answer: (1) what is it, (2) why does it exist, (3) what can I do, (4) what do I gain, (5) how do I participate?

**Result [A]:** **Fails 4 of 5.**
1. *What is it?* — Partially. "Sewak Sathi Sanstha" suggests service and companionship; it does not suggest business, verification or emergency support. A reasonable guess, an inaccurate one.
2. *Why does it exist?* — No. Nothing visible.
3. *What can I do?* — No. The only visible action in the architecture is "apply for membership".
4. *What do I gain?* — No. And the honest answer differs by segment (§8).
5. *How do I participate?* — No.

## 20.2 A simpler explanation **[P — draft for approval, not adopted language]**

**Core sentence (all languages, identical meaning):**
> **"Neighbourhood teams that fix local problems — verified, recorded, and paid fairly when the work earns."**

Three supporting lines, used depending on who is listening:
- To a **resident**: *"Tell us a problem in your lane. We verify it, we work on it with you, and we show you what happened."*
- To a **student / job-seeker**: *"Do real work near home. Get a verified record and a reference you can show an employer."*
- To a **business / customer**: *"Local work delivered by verified people, with quality checks and clear accounting."*
- To an **official / partner**: *"A documented, non-political neighbourhood partner with audited records and insurance."*

**The "what we are not" line, printed smaller underneath (§18):**
> *Not a political organisation. Not a religious organisation. Not a security agency. Not a job portal. Not a replacement for government.*

**Design constraints [A]:** the word "AI" should not appear in the ten-second version — it imports the wrong category. The word "protection" should not appear either — it imports the most dangerous category (F-09). Both belong in the second conversation, not the first. This is a *sequencing* decision about truth-telling, not a concealment: the full description must be one tap away and must be complete.

## 20.3 The First 5 Minutes — ideal new-citizen experience

**Design principle [P]:** value before vetting; contribution before commitment; a person before a process. Nothing in these five minutes requires understanding the architecture.

| Minute | Stage | What happens | What must NOT happen | Architecture touchpoint |
|---|---|---|---|---|
| **0–1 Discovery** | They encounter a *result*, not an organisation: a cleaned lane with a small dated board; a neighbour saying "they fixed the drain"; a stall with a photograph wall of local work; a QR that opens one page in their language | No form. No app download. No membership language | Asking for identity documents; explaining the hierarchy; describing four pillars | Ch.24 public communication; Ch.15 evidence (the board *is* the evidence, published) |
| **1–2 Understanding** | One page, in their language: the core sentence, the "what we are not" list, three things this team actually did nearby with dates, and two buttons — **"Report a need"** and **"Help once"** | No jargon. No role titles. No process diagram | The 12-stage lifecycle; the constitution; RBAC | Requires a public local page — **not in the current architecture [P]** |
| **2–3 First participation** | Either (a) they submit a need in 60 seconds — three fields: what, where, contact (optional) — and get an acknowledgement with a reference number and an expected response time; or (b) they choose a listed one-off task happening this week with a time, place, duration and what to bring | No verification. No commitment. No account required beyond a phone number | Any implication that they must join; any collection of identity data | Levels 1–2 of the spectrum (§9); Ch.8 request intake, simplified to a public front door |
| **3–4 Trust** | A real person responds: a named local member calls or messages within the promised window, explains what will happen, and says what the team *cannot* do ("we don't handle that — here's the municipal number") | Honest limits. A name. A face. A time commitment kept | Overpromising; a form; silence; a broadcast message | Ch.8 triage + decline decision (the decline, delivered well, *is* the trust moment) |
| **4–5 Meaningful action** | They either see their reported problem verified and scheduled (and are told the date), or they spend 90 minutes on a real task alongside two existing members, are thanked by name, are shown the before/after, and are told: *"you're on the record for this — no obligation to do it again"* | A visible result. A personal thank-you. A record they can see. An explicit absence of obligation | A recruitment pitch; a membership form; a group photo posted without consent | Ch.15 evidence + outcome verification; Ch.12 record, exposed to the contributor themselves (§25 credential) |

**The single most important design decision in these five minutes [A]:** *the first action available must be either "tell us a problem" or "help once", and neither may require joining.* The current architecture's first available action is "application — begins verification; not entitlement to join" **[S: Ch.12]**. That is an integrity-first design and a conversion-fatal one. Both can be satisfied by the spectrum in §9: **value first, verification only at the moment responsibility is requested.**

---

# 21. THE FIRST REAL WIN

## 21.1 Criteria **[A]**

The first win must be: **fast** (≤48 hours), **small** (≤2 hours), **visible** (a before/after exists), **safe** (no restricted task, no minors, no money, no conflict), **legal** (no permission needed, or permission already held), **social** (done *with* two existing members, not for them), and **recorded** (the person can see their name attached to a real outcome).

## 21.2 Candidate first wins, evaluated against the existing architecture

| Candidate | Fits criteria? | Verdict |
|---|---|---|
| Neighbourhood clean-up of one defined stretch | Fast, small, visible, safe, social, recordable; needs municipal permission in some cases **[V]** | **Best universal first win** — already Scenario A in the source **[S: Ch.35]** |
| Delivering a verified request (medicine pickup, grocery for an elderly neighbour, escort to a clinic) | Fast, small, deeply meaningful, dignified; requires care with privacy and safeguarding | **Best emotional first win** — highest trust produced per hour |
| One digital-literacy or homework-help session | Fast, visible to parents, uses existing skill; safeguarding rules apply (two-adult rule) | **Best for students and professionals** |
| Contributing one professional skill pro-bono (accounts, design, a legal opinion, a repair) | Fast, high value, dignifies the contributor; needs scope discipline | **Best for Specialists** — the single most under-used resource in the model |
| Verifying one need (a site visit with a photo and a note) | Fast, small, and *is* the organisation's core competence | **Best for people who want responsibility early** — but note this is a restricted-ish task; keep it observational only at Level 3 |
| Donating one item or one introduction | Fast, tiny, dignified | **Best zero-time entry** (§23) |
| Attending a training module | Slow, invisible, no result | **Worst first win** — this is what the architecture currently front-loads (F-01) |
| Applying for membership | Slow, extractive, no value | **Worst possible first action** |

## 21.3 The recommended model: the Paired First Task **[P]**

> A newcomer is matched within 48 hours to **one** small, safe, visible task, performed **alongside two existing members**, ending with a **before/after record** that the newcomer can see and keep, and an explicit statement that **nothing further is expected**.

Why paired: belonging is produced by a person, not a programme (§7.3), and the two existing members are the actual product being delivered — the task is the pretext. Why two: it satisfies the two-adult rule where relevant, prevents isolation, and gives the newcomer two relationships instead of one. Why "nothing further is expected": it removes the pressure that makes first experiences feel like recruitment, and paradoxically it is what makes people come back **[I]**.

**Metric that matters [P]:** *percentage of first-time participants who complete a second contribution within 30 days.* Not member conversions. Conversion is a lagging indicator of a good first win; measuring it directly causes the organisation to sell membership during the first win, which destroys the win.

---

# 22. THE NATIONAL GROWTH LOOP — VIABILITY, BOTTLENECKS, INSTRUMENTS

## 22.1 The loop you proposed, tested

```
LOCAL NEED → SERVICE → VISIBLE IMPACT → TRUST → PARTICIPATION
   → MORE CAPABILITY → MORE SERVICE → MORE TRUST
   → LOCAL TEAM GROWTH → CITY NETWORK → STATE NETWORK → NATIONAL NETWORK
```

**Verdict [A]: the logic is sound and every link is *possible* — but three links are broken in the current architecture, and one is missing entirely.**

| Link | Status | Why |
|---|---|---|
| Local need → Service | **Works** | Ch.8's 10-step loop and Ch.15's 12-step loop are genuinely good **[S]** |
| Service → Visible impact | **Conditional** | Requires outcome verification (F-20) and requires the outcome to be *published locally in the local language* — which no component currently does |
| Visible impact → Trust | **Conditional** | Requires attribution: the person helped must know *who* helped them, and must not be humiliated by it. No attribution design exists |
| Trust → Participation | **BROKEN** | The only participation door is Verified Member (F-01). Trust with no low-friction door produces goodwill, not participation |
| Participation → More capability | **Works** | Roles, training, vacancies **[S: Ch.9–12]** |
| Capability → More service | **Conditional** | Requires revenue/resources (F-06) and requires compliance capacity (F-05) |
| More trust → Team growth | **Conditional** | Requires leader supply (Scenario B) and a recognition gate (F-25) |
| Team growth → City → State → National | **Conditional** | Requires governance capacity that scales sub-linearly (F-07 in §5, Scenario C) |
| **Missing link: beneficiary → participant** | **ABSENT** | The single highest-propensity convert in any service organisation is the person who was helped. The architecture treats recipients purely as *objects of service* and never as *candidates for participation*. There is no path, no rule, no metric |

## 22.2 The "I know someone who helped me" effect — can it be an organic growth engine?

**[A]** Yes, and it is the only growth engine this organisation can afford. Paid acquisition would import the wrong people (F-02); viral mechanics would import performative participants; political patronage would be fatal (F-08). Reciprocity-based growth is free, self-selecting for people who already believe in the value, and it produces exactly the emotional proposition in §10 ("my help reached someone real").

**But it does not happen automatically.** Three conditions must be engineered:

1. **Attribution at the moment of help.** The person helped must know, unambiguously, that *these specific people from this neighbourhood team* did it. Not a logo on a packet — a name, a face, and a sentence: "We're from the Sewak Sathi team in this mohalla; we'll come back on Thursday to check whether this is still working." Anonymous help produces gratitude; attributed help produces *trust in an institution*. **[P]** (Constrained by dignity and privacy: attribution must never become publicity — no photograph, no audience, no ceremony at the moment of need.)
2. **A follow-up visit.** Ch.15's outcome verification **[S]** already requires returning to check the result. That return visit is *the* conversion moment — it demonstrates reliability, which is rarer than generosity. Make it a rule, not an option. **[P]**
3. **A zero-friction return path.** When the helped person says "I want to help too", there must be something they can do *this week* that requires no verification (Level 1–2, §9). Today, the answer would be "fill in an application". That single exchange is where the loop dies. **[A]**

**Guard rails [P]:**
- **No recruitment at the moment of need** (§9.3) — an invitation must come later, from a different person, and must be refusable without any change in service.
- **No incentive for conversion** — nobody may be rewarded for converting a beneficiary. That would turn help into prospecting instantly, and the community would detect it within a month.
- **No testimony extraction** — beneficiaries are not asked for endorsements, quotes, photographs or public gratitude as a condition or expectation of help.
- **Measurement without pressure**: track "helped-to-helper" conversion as a *diagnostic* (what share of participants in year N were helped in year N-1 or N-2?), never as a target for any individual member. Targets on human conversion produce coercion.

## 22.3 Bottlenecks in the loop, ranked **[A]**

1. **Attribution and follow-up discipline** (cheap, behavioural, immediate impact) — fix first.
2. **A low-friction participation tier** (F-01; requires your approval and a legal/privacy review) — fix second.
3. **Published local evidence in local language** (F-20, §13) — fix third.
4. **Leader and control-role supply** (Scenario B; requires a training institution) — the long pole.
5. **Revenue/resources per team** (F-06) — determines whether capability actually grows.
6. **Assurance capacity** (Scenario C) — determines whether growth can be *trusted* rather than merely counted.

## 22.4 Growth-loop metrics **[P]**

| Metric | What it proves | Healthy signal |
|---|---|---|
| Time-to-first-contribution (median, from first contact) | Friction at the door | Falling; target ≤48 hours |
| Second-contribution rate within 30 days | Quality of the first win | Rising |
| Helped-to-helper conversion (24-month lag) | Whether the loop actually turns | Any non-zero, rising trend — never a target for individuals |
| Outcome follow-up completion rate | Whether impact claims are real | High and audited |
| Share of participants recruited by someone they already knew | Organic vs. organised growth | High — this is a *good* metric here, unlike in commercial growth |
| Local publication rate (teams publishing local evidence in local language per quarter) | Whether impact is visible | Rising |
| Request-to-response time and refusal-with-referral rate | Competence and honesty at the front door | Stable and published |

---

# 23. ADOPTION BOTTLENECKS AND THE NATIONAL SCALING ARCHITECTURE

## 23.1 Stage model with the *single* binding constraint at each stage

**[A-assumption]** Team sizes and ratios are my derived estimates (see §5), not source numbers. The value of the table is the *identity* of the bottleneck at each stage, which is robust across a wide range of assumptions.

| Stage | Scale | Structure | **The one binding constraint** | Second constraint | Kill condition | First instrument to build |
|---|---|---|---|---|---|---|
| **S0 Seed** | 1 team, 8–15 people | Mohalla only, City sponsor | **A viable first revenue or resource source + founder/mentor time** | Trust of one neighbourhood | Two consecutive months with no distributable amount and no funded service | A single anchored engagement (one institutional service contract, one SME retainer, or one municipal partnership) *before* launch |
| **S1 Pilot city** | 5–15 teams, 100–400 members | Mohalla + City | **Trained leaders and control-role holders** (3 per team: HR/Funds/Safety) | Evidence consistency | Teams recognised before leaders are trained (F-25) | A leader-training pipeline with certification, run by the city, plus the 6-form manual control stack (F-30) |
| **S2 Multi-city / first state** | 50–300 teams, 1k–10k members | + State | **Payment, verification and identity rails** (cannot be manual beyond ~1k) | Specialist pool | Weekly payment backlog, or verification queue >30 days | Platform minimum: member record, task record, payment sheet with two approvals, evidence index, immutable log |
| **S3 Multi-state** | 1k–10k teams, 10k–200k members | + Zones | **Assurance capacity** — audit at sampling scale, not case scale | Legal/tax/insurance per state **[V]** | Audit findings ageing; unreviewed incidents accumulating | Risk-based sampling doctrine + a professional assurance cadre + state-level legal entities or a compliance matrix |
| **S4 National** | 10k+ teams, 200k–1M+ members | Federated | **Governance form and continuity** — mission lock, succession, apex dispute resolution | Political-neutrality enforcement | Any apex dispute without a rule; any failed founder-dependency test (§11.2) | Constitution with reserved matters, Council charter, founder-succession article, federated structure |
| **S5 Institutional** | 1M+ members / 10M+ participants | Protocol + federation | **Public legitimacy and independence** | Data protection at Significant Data Fiduciary scale **[X]** | A breach, a politicisation event, or a protection incident | Independent trustees, statutory-scale audit, public-interest reporting, open standards |

**[A] The critical insight:** the bottleneck is **never the same thing twice in a row**, and each stage's bottleneck is the *previous* stage's strength. Leader supply (S1) is solved by training; training at scale (S2) is solved by systems; systems at scale (S3) are solved by assurance; assurance at scale (S4) is solved by governance form. Organisations die when they keep applying the previous stage's solution — e.g. solving a 10,000-team assurance problem by hiring more auditors case-by-case, or solving a national legitimacy problem with a better dashboard.

## 23.2 The twenty functions, per stage

Legend: **○ = informal/manual** · **◐ = defined process** · **● = institutional function with named owner, budget and metrics**

| Function | S0 | S1 | S2 | S3 | S4/S5 | What must be true before it can be ● **[A]** |
|---|---|---|---|---|---|---|
| Recruitment | ○ | ◐ | ◐ | ● | ● | Level 1–4 tiers exist (§9); earnings-reality disclosure approved |
| Onboarding | ○ | ◐ | ● | ● | ● | Paired First Task SOP written; time-to-first-contribution measured |
| Verification | ○ | ◐ | ● | ● | ● | Digital identity rails decided **[V]**; central verification cell or city-level verifier cadre |
| Local activation | ● | ● | ◐ | ◐ | ○ | Never fully institutionalised — this stays human at every scale |
| Training | ○ | ◐ | ● | ● | ● | Trainer certification; multilingual content (L2/L3, §13); certified safeguarding and first aid **[V]** |
| Leadership | ○ | ◐ | ◐ | ● | ● | Horizontal ladder (F-24); cohort-normalised scoring (F-19); successor-before-transition (M9) |
| Communication | ○ | ◐ | ◐ | ● | ● | Category sentence; "what we are not"; multilingual publication; spokesperson register |
| Technology | ○ | ○ | ◐ | ● | ● | Manual control stack retired at a hard trigger (F-30); platform minimum at S2 |
| Finance | ○ | ◐ | ● | ● | ● | Entity/tax/classification resolved **[V]**; digital rails; city-level accounting for small teams |
| Service delivery | ● | ● | ● | ◐ | ◐ | Never centralise this — it is the product |
| Quality control | ○ | ◐ | ◐ | ● | ● | Sampling doctrine; beneficiary confirmation; duplicate-evidence detection |
| Safety | ◐ | ● | ● | ● | ● | Insurance in force **[V]**; visibility protocol; do-not-attend list; 24×7 line at S3 |
| Trust / public legitimacy | ○ | ○ | ◐ | ● | ● | Published accounts; published failures; public complaint channel; authenticity verification |
| Retention | ○ | ○ | ◐ | ● | ● | Paused/alumni status; exit & stay interviews; credential issuance; elder/mentor role |
| National brand | ○ | ○ | ◐ | ◐ | ● | Deliberately *late*: brand follows evidence, never precedes it |
| Local identity | ● | ● | ● | ● | ● | Localisation contract (§12.1) published and honoured |
| Multilingual operations | ○ | ◐ | ● | ● | ● | Terminology register per language; L1/L2/L3 rule; language-equity metric |
| Partnerships | ◐ | ◐ | ● | ● | ● | Due diligence per Ch.29 **[S]**; funding doctrine (F-32); FCRA analysis before foreign funds **[X]** |
| Measurement | ○ | ◐ | ● | ● | ● | Two-speed scoring (F-20); cohort normalisation; published mission-balance statement |
| Assurance / audit | ○ | ◐ | ◐ | ● | ● | Risk-based sampling; independent ethics function; external reviews **[V]** |

**[A] Reading of this table:** only two functions must be institutional (●) *early* — **Safety** and **Finance** — because their failure is irreversible. Everything else may legitimately begin informal, provided the *trigger* for institutionalising it is written down in advance. The architecture's mistake is that it makes almost everything ● from day one on paper, and ○ in reality (F-30, F-05). **Better to promise less and deliver it than to promise everything and back-fill.**

---

# 24. ARCHITECTURE STRESS-TEST RESULTS (component by component)

**Method [A]:** each architectural component is tested against three questions — does it survive (i) *human behaviour* (self-interest, fatigue, social pressure), (ii) *arithmetic* (throughput, cost, ratios), and (iii) *the external world* (law, politics, perception, market)?

| Component **[S]** | Human behaviour | Arithmetic | External world | Overall |
|---|---|---|---|---|
| Four pillars (Ch.3) | Pass — four motivations, four doors | Pass | **Strain** — "protection" and "business" import dangerous perceptions (F-08/09/36) | **Keep pillars; change public sequencing and naming** |
| Hierarchy National→State→City→Mohalla (Ch.4–8) | Pass | **Fail at ~1M** — latency, information loss, management population | Strain — inter-state legal heterogeneity **[V]** | **Keep to ~100k; then federate/zone** |
| Authority distinctions (Ch.4) | Pass — well bounded | Pass | **Fail** — apex unresolved (F-11/12) | **Modify: charter the apex** |
| 11 role families + sub-roles (Ch.9–10) | **Strain** — three roles are socially costly (F-03) | **Fail at team level** — 11 families from 10–25 people | Pass | **Modify: shared city-level functions for small teams** |
| One primary holder rule (Ch.22) | Pass | Pass | Pass | **Keep verbatim** — one of the strongest rules in the document |
| Vacancy lifecycle + eligibility engine (Ch.11) | Pass | **Strain** — 13 steps per appointment × thousands | Pass | **Modify: tier the process by role risk** |
| Member lifecycle, 12 stages (Ch.12) | **Fail** — front-loaded cost, back-loaded value (F-01) | Strain | Pass | **Modify: add pre-membership tiers; keep the spine** |
| Conduct rule: warning → removal (Art.8) | Pass | Pass | Strain — needs certified safeguarding and legal review **[V]** | **Keep; add the serious-misconduct procedure (already PROPOSED)** |
| Training categories (Ch.12) | Pass | Strain — throughput | **Fail** — internal training is not legally sufficient (the document admits this) | **Modify: certification for restricted domains** |
| Three staffing states (Ch.10) | Pass | Pass | Pass | **Keep; add a maturity clock (F-07)** |
| Autonomy readiness gates (Ch.13) | Pass | Strain | Pass | **Modify: graduate into three tiers (F-35)** |
| Team failure recovery (Ch.14) | **Pass — excellent** | Pass | Pass | **Keep verbatim** |
| Social service engine + anti-fake-impact (Ch.15) | **Pass — excellent** | Strain — outcome verification is expensive | Pass | **Keep; add two-speed scoring (F-20)** |
| Protection doctrine + 6 DO-NOTs (Ch.16) | **Pass — excellent** | Pass | **Fail** — no visibility protocol, no insurance, no legal review (F-09/10) | **Keep doctrine verbatim; add the wrapper** |
| AI business lifecycle (Ch.17) | Strain — pulls the best people (F-17) | Strain — small-ticket economics | **Strain** — market rates, category legality **[V]** (F-34) | **Modify: service floor, capacity ceiling, rate governance** |
| Financial waterfall priority order (Ch.18) | **Pass — the best single design in the document** | **Strain** — buffer arrives late (F-06) | Strain — tax/labour classification **[V]** | **Keep order verbatim; add a cold-start instrument** |
| Weekly payment cycle (Ch.19) | Strain — empty weeks read as betrayal | **Fail** — manual beyond ~1k; lumpy revenue | Strain — payroll compliance **[V]** | **Modify: allow fortnightly/monthly cycles early; keep the audit trail** |
| Social-impact fund (Ch.20) | Pass | Strain — surplus-dependent | Strain — funder capture (F-32) | **Keep restrictions; add a funding doctrine** |
| AI doctrine (Ch.21) | **Pass — excellent** | **Fail** — reviewer capacity (F-29) | Strain — model quality by language (F-31) | **Keep doctrine; add capacity, tiers, review-quality audit** |
| Data architecture + modules (Ch.22) | Pass | Strain — build time | **Fail** — DPDP obligations, retention unresolved **[X]** (F-27) | **Modify: privacy programme before scale** |
| RBAC matrix (Ch.23) | **Pass — excellent** | Pass | Pass | **Keep; extend to a hard floor below Level 5 (§9)** |
| Dashboards + reporting cadence (Ch.24) | Strain — reporting burden (F-05) | **Fail** — 5 cadences × every team | Pass | **Modify: auto-generate; reduce human input to facts only** |
| Performance system + weights (Ch.25) | **Strain** — Goodhart (F-20); unfairness (F-19) | Pass | Pass | **Modify: cohorts, baselines, two speeds** |
| Dynamic leadership (Ch.26) | Strain — hollows out winners (§1.2 Finding 5) | **Fail** — tournament scarcity (F-24) | Pass | **Modify: successor-before-transition + horizontal ladder** |
| Audit pathway (Ch.27) | Pass | **Fail at scale** — exhaustive by implication | Pass | **Modify: risk-based sampling doctrine** |
| Risk register (Ch.28) | **Pass — genuinely good** | Pass | **Strain** — missing external risks: political capture, misclassification, funder capture, secession | **Modify: add the four missing risks** |
| Partnerships (Ch.29) | Pass | Pass | Strain — FCRA/political adjacency **[X]** | **Modify: add funding doctrine and refusal criteria** |
| Launch roadmap Phases 0–5 (Ch.30) | **Pass — honest** | Strain — no capacity plan | Pass | **Modify: add a per-team recognition gate + sponsor liability (F-25)** |
| Launch checklist (Ch.31) | Pass | Pass | Pass | **Keep; add political-neutrality and privacy items** |
| Constitution, 19 articles (Ch.32) | Pass | Pass | **Fail** — no mission lock, no succession, no political-neutrality article, no dignity-of-beneficiary article | **Modify: add four articles** |
| Decision register (Ch.33) | **Pass — exemplary honesty** | Pass | Pass | **Keep; this is a governance asset** |
| SOP index, 22 SOPs (App. D) | Pass | **Fail** — throughput (F-05) | Strain | **Modify: tier by team maturity; add exit/stay interview, integrity intake, standard-change request, translation review, recognition and team-closure SOPs** |
| Approval & delegation matrix (App. E) | **Pass** | Pass | Pass | **Keep** |
| Evidence standards (App. F) | **Pass — excellent** | Strain | Pass | **Keep; add tiering by maturity** |
| Self-audit (App. G) | Pass | Pass | **Fail** — it audits *preservation*, not *viability*. Every answer is "Yes" because the question asked was "did we keep the source?" | **Modify: add a viability self-audit (the 36 failures above are a starting instrument)** |

**Summary [A]:** of 35 components tested — **11 keep verbatim**, **23 modify**, **1 (the hierarchy's upper reaches) reconsider beyond ~1 million members**. **Zero components require abandonment.** The spine is sound.

---

# 25. KEEP / MODIFY / RECONSIDER

**Every MODIFY entry below states: original principle → problem discovered → proposed change → reason → benefit → new risk created → implementation difficulty (L/M/H).** Nothing here is adopted; all of it is **PROPOSED — REQUIRES FINAL APPROVAL** under your own status discipline **[S: front matter]**.

## 25.1 KEEP (do not touch)

| # | Element | Why it must survive **[A]** |
|---|---|---|
| K1 | **Priority order of the financial waterfall** (worker compensation first; percentages are only a planning tool) **[S: Ch.18]** | The moral and operational core. Prevents the most common failure of earning-based volunteer organisations. Changing it would destroy the claim to fairness |
| K2 | **AI may recommend; humans decide** + prohibited-decisions list + append-only logs **[S: Ch.21]** | Correct in principle and rare in practice. Keep even though capacity must be added (F-29) |
| K3 | **The six protection DO-NOTs and the intervention sequence** **[S: Ch.16]** | The most important text in the document. Add a wrapper around it; never dilute it |
| K4 | **One role = one primary holder; one designated deputy** **[S: Ch.22]** | Prevents duplicate-head chaos and deputy authority creep |
| K5 | **Central standards ≠ central control** **[S: Ch.13]** | The correct diagnosis of distributed-organisation failure |
| K6 | **Support-first team failure recovery** **[S: Ch.14]** | Protects people and institutional memory; also the cheapest form of quality control |
| K7 | **Anti-fake-impact rules and the "not acceptable" evidence column** **[S: Ch.15, App. F]** | The differentiator is verifiable honesty; these rules are what make it true |
| K8 | **Segregation of duties as a pattern** (receive + approve + record + audit never one person) **[S: Ch.18]** | Extend it from finance to *power* (§16.2 two-deep rule); never weaken it |
| K9 | **Status-labelling discipline** (APPROVED / PROPOSED / REQUIRES VALIDATION / UNRESOLVED / FUTURE) **[S]** | Institutional honesty. It is why this stress test was possible at all |
| K10 | **Membership is not automatic; verification precedes responsibility** **[S: Ch.12, Art.5]** | Correct — but it must be *sequenced after value*, not before (see M1) |
| K11 | **Decision register with named unresolved items** **[S: Ch.33]** | Keep publishing it. An organisation that lists its own open questions is trusted more than one that claims completeness |

## 25.2 MODIFY (23 items)

**M1 — Add a participation spectrum below Verified Member (§9)**
*Original:* the membership lifecycle is the single entry path; "Supporting Member" exists as an internal assigned position **[S: Ch.10, Ch.12]**.
*Problem:* front-loaded cost with back-loaded value caps participation at the small minority willing to undergo vetting (F-01); eight major citizen segments have no legitimate place (§8).
*Change:* nine-level spectrum; Levels 0–4 carry **zero** operational permissions, zero record access, zero command; responsibility begins at Level 5 unchanged.
*Reason:* the verification spine protects *responsibility*, not *contribution*. Nothing in the source ties contribution to verification.
*Benefit:* order-of-magnitude increase in reachable citizens; a conversion path from beneficiary to participant (§22); less data collected at low tiers (DPDP-aligned **[X]**).
*New risk:* a shadow unverified workforce; level inflation; a second status hierarchy. *Controls:* hard RBAC floor, the word "Member" reserved for Level 5+, no public ranking below Level 5, a responsible member attributed to every low-tier task.
*Difficulty:* **M** (policy + platform permissions + legal review of the volunteer boundary **[V]**).

**M2 — Publish a Political Neutrality Code as a constitutional article (F-08)**
*Original:* non-discrimination in service; communications rules; partnership due diligence **[S: Ch.2, Ch.24, Ch.29]**.
*Problem:* nothing governs party office-holding, election-period conduct, political approaches, symbols, or brand use at political events; tax-exempt status in India is conditional on not engaging in political activity or supporting parties/candidates **[X]**.
*Change:* a code with six instruments — no partisan use of role/brand/records/events/lists; declared-conflict rule; election-period protocol with emergency exceptions; refusal script and log owned by National Legal; standing public non-alignment statement; audit sampling for political adjacency.
*Reason:* the highest-severity uncontrolled risk in the document; existential and near-irreversible.
*Benefit:* protects tax position, cross-faction community trust, and the ability to operate in public.
*New risk:* over-application chilling legitimate civic engagement (advocating for a drain to be fixed is civic, not partisan); members feeling policed. *Control:* a written distinction between **issue advocacy** (permitted, evidence-based, non-partisan) and **electoral/partisan activity** (prohibited), plus an appeal route for members who believe a refusal was wrong.
*Difficulty:* **L** to draft; **M** to enforce credibly; requires legal/tax validation **[V]**.

**M3 — Add a Protection Visibility Protocol and a legal/insurance wrapper (F-09, F-10)**
*Original:* doctrine + risk tiers + SOP-13 + a checklist item for insurance **[S: Ch.16, Ch.31]**.
*Problem:* doctrine governs intent, not appearance; no dress/symbol rules, no group-movement rules, no filming rules, no do-not-attend list, no insurance or legal-support instrument before activity is publicised.
*Change:* the seven-item protocol in F-09(7) plus the pre-launch liability package in F-10(7), plus a legal review of the intervention boundary against BNSS/BNS provisions — including private-person arrest and the six-hour handover requirement, and the public's duty to assist police when lawfully demanded **[X]**.
*Reason:* one filmed incident defines the institution permanently; an uncovered incident destroys it morally as well as legally.
*Benefit:* members protected; perception managed; the pillar becomes sustainable.
*New risk:* members who joined for the protective function feel restricted — some will leave. *That is the intended effect.* Over-restriction could also prevent lawful, morally necessary help in a genuine emergency. *Control:* the emergency exception remains exactly as the source states it (any member may call emergency authorities; a trained Safety Lead coordinates; intervention only where reasonably necessary and lawful **[S: Ch.16, Ch.17 risk matrix]**).
*Difficulty:* **M**; insurance and legal review require professional input **[V]**.

**M4 — Add four constitutional articles: Mission Lock & Founder Succession; Apex Dispute Resolution; Dignity of the Person Helped; Political & Religious Non-Alignment (F-11, F-12, §10.2, M2)**
*Original:* Art.3 ownership by Krytos under the founder/CEO; Art.17 member disputes; Art.19 dissolution requires validation **[S]**.
*Problem:* no continuity instrument, no apex deadlock rule, no explicit dignity article, no non-alignment article.
*Change:* four articles as described; Mission Lock options range from an irrevocable purpose clause to Council reserved matters with a suspensive veto.
*Reason:* institutional longevity requires the mission to outlive the person who holds it.
*Benefit:* partner, regulator, professional and member confidence; twenty-year survivability.
*New risk:* **reduces founder flexibility**, which the architecture currently protects ("broad executive flexibility within final legal structure" **[S: Ch.4]**); could slow decisions; could create an obstructive Council. *Control:* keep the reserved-matters list *short and specific*; operations remain fully with the CEO; add a dispute ladder with a 14-day cooling period and a rule that operations continue during any dispute.
*Difficulty:* **M** legally; **H** politically — it requires the founder to accept a constraint voluntarily. This is a decision, not an analysis.

**M5 — Add a cold-start instrument for early teams (F-06)**
*Original:* reserves at priority 6; the bad-month rule protects worker compensation **[S: Ch.18]**.
*Problem:* sequence error — the buffer exists only after success, but is needed before it.
*Change:* one of (i) a capped, time-bound, explicitly accounted first-season float; (ii) an anchored-revenue precondition in the Phase 2 exit gate; (iii) a shift to fortnightly/monthly cycles until a venture is contribution-positive. Published, approved, reconciled.
*Reason:* the first three empty weeks determine whether the earnings promise is read as honest.
*Benefit:* retention through the fragile period; honest expectation-setting.
*New risk:* floats become permanent subsidies and create dependency; teams optimise for float access rather than viability. *Control:* hard cap, fixed term, mandatory reconciliation, one renewal maximum with City sponsor sign-off, publication of float utilisation.
*Difficulty:* **M**; requires financial and tax validation **[V]**.

**M6 — Reduce and tier the compliance load (F-05, F-35)**
*Original:* 22 SOPs, 14 evidence types, 5 reporting cadences, 8 readiness gates, 13-step vacancy and payment cycles **[S]**.
*Problem:* unmeasured human cost; regressive on small teams; produces back-filling and falsified evidence.
*Change:* measure governance hours in the pilot; define **Pilot Fidelity (6 mandatory records)** vs **Full Fidelity (all)**; graduate readiness gates into three tiers; adopt a control-budget rule (any new mandatory record requires automation or the retirement of another).
*Reason:* a control nobody can perform is worse than no control — it teaches that rules are decorative.
*Benefit:* real compliance instead of performed compliance; faster team formation; honest audit.
*New risk:* reduced evidence weakens assurance and could allow abuse in low-fidelity teams. *Control:* low fidelity is time-bound and paired with **higher** external review frequency (the city inspects what the team does not document); promotion to higher fidelity is required before money-handling autonomy.
*Difficulty:* **M** (requires choosing the six records — I would propose: request log, verification note, expense/receipt, payment sheet, incident report, evidence index).

**M7 — Relocate small-team financial control to city level and digital rails (F-16)**
*Original:* segregation of duties inside the team; Funds Manager limits **[S: Ch.18]**.
*Problem:* a 6–10 person intimate team cannot achieve real segregation; cash is untraceable.
*Change:* org-owned payment channel only (no personal accounts for customer money); the city prepares/reviews the payment sheet for State A teams; cross-city reviewer rotation; one-tap member payment confirmation.
*Reason:* worker compensation is priority 1; its theft is the most damaging possible internal failure.
*Benefit:* leakage falls; members believe the payment sheet; audit becomes feasible.
*New risk:* city-level preparation slows payment and centralises what the architecture wants local; a city Funds reviewer becomes a single point of failure or corruption. *Control:* an SLA on payment timing; the mohalla team retains the *facts* and approves work verification; rotate city reviewers; sample-audit the auditors.
*Difficulty:* **M**; requires payment rails and classification decisions **[V]**.

**M8 — Normalise and slow the performance system (F-19, F-20)**
*Original:* eight weighted dimensions, monthly evaluation, published leaderboard, monthly-evaluated leadership transitions **[S: Ch.25–26]**.
*Problem:* incomparable contexts; outcome lag forces activity-optimisation; the prize is scarce.
*Change:* cohort stratification; a material share of score from improvement-versus-own-baseline; **two-speed scoring** (monthly for conduct/hygiene, quarterly–annual for impact); cap the activity-count contribution; no public individual ranking; do not use the leaderboard as a prize in the first two cycles.
*Reason:* a measurement system that is unfair or that rewards theatre will be obeyed and resented.
*Benefit:* effort migrates to hard areas; impact claims become real; leadership selection becomes legitimate.
*New risk:* complexity — teams may not understand their own score; cohort boundaries can themselves be gamed (teams seeking an easy cohort); slower feedback reduces motivational immediacy. *Control:* publish a plain-language score explanation per team; assign cohorts by objective criteria (area type, team age, venture status) not by choice; keep a fast, non-scored feedback loop for hygiene items.
*Difficulty:* **M**.

**M9 — Add successor-before-transition and a horizontal ladder (F-24)**
*Original:* best team → Head Team opportunity; role succession within function **[S: Ch.26, Ch.9]**.
*Problem:* promotion hollows out the winning team; the positional ladder is a lottery for all but a few.
*Change:* no transition until a named, trained successor has completed one full cycle in the role; add graded skill certification (portable, externally verifiable), specialist tracks, scope-based rewards, reference letters generated from the service record, and an elder/mentor non-command role.
*Reason:* retaining capable people requires rewards that do not depend on someone else's vacancy.
*Benefit:* team continuity; capability accumulation; a credential asset that also serves students and job-seekers (§8).
*New risk:* certification becomes a paper mill; references get inflated; elder status becomes gerontocracy. *Control:* certification requires evidence-linked assessment by an out-of-team assessor; references are auto-generated from the verified record and cannot be narratively edited; the elder/mentor role has no command permissions and no scoring weight.
*Difficulty:* **M**.

**M10 — Add an Integrity Line and an independent ombuds (F-21, F-14)**
*Original:* audit and complaints via Audit & Ethics; line-based escalation; member dispute routes **[S: Ch.5, Ch.7, Ch.27, Art.17]**.
*Problem:* every route passes through or near the person accused; no anonymous intake; no non-retaliation guarantee.
*Change:* an intake channel owned by Audit & Ethics reporting to the Council, accepting anonymous reports; non-retaliation classified as serious misconduct; a triage SLA; a case register; an annual published integrity report (categories and outcomes, no identities); a standing skip-level channel to National; mandatory field immersion for national/state leaders.
*Reason:* internal reporting systems that route through the accused under-report to near zero.
*Benefit:* problems surface internally rather than in media; leaders behave; the ground is heard.
*New risk:* the channel is abused for vendettas (F-22); anonymity prevents defence; a Council-controlled function could be captured by the apex it should check. *Control:* triage discipline and published substantiation rates; anonymous reports are investigable leads but never sufficient evidence alone (consistent with App. F **[S]**); proven-false malicious reports carry consequences; the ombuds has a published direct line to an *external* adviser as well as to the Council.
*Difficulty:* **M**.

**M11 — Add a privacy programme and resolve retention (F-27)**
*Original:* RBAC, encryption/MFA/logs in the risk register, SOP-22, privacy-controlled HR content, retention UNRESOLVED **[S: Ch.12, Ch.22, Ch.28, Ch.33]**.
*Problem:* no classification, retention schedule, DPIA trigger, DPO/privacy officer, breach timeline, notice, processor standards, or survivor-centred record handling; DPDP obligations are specific and penalties are large **[X]**.
*Change:* the nine-item privacy programme in F-27(7).
*Reason:* the sharpest harm available to this organisation is endangering a vulnerable person through its own records.
*Benefit:* legal compliance; the ability to say truthfully "your data is safe here" — itself a differentiator in India.
*New risk:* over-restriction impedes legitimate operations (a safety lead who cannot see an emergency contact); compliance cost. *Control:* role-and-case-scoped access *with reason codes* rather than blanket denial; a documented emergency-disclosure procedure with after-the-fact review.
*Difficulty:* **H** (mostly policy and process; the technical part is bounded).

**M12 — Define the manual-phase minimum control stack and its expiry (F-30)**
*Original:* the Phase 1 exit gate permits "pilot-ready platform/manual process"; technology is a blocker *before scale* **[S: Ch.30–31]**.
*Problem:* the controls (immutability, RBAC, delegation expiry, audit trail) cannot exist manually, yet the pilot runs manually.
*Change:* six mandatory forms; a two-person rule for money; an immutable medium with a second custodian; weekly city inspection; a hard trigger beyond which manual process is not permitted (teams or members); an explicit statement that manual records are provisional and will be re-verified at migration.
*Reason:* habits formed without controls persist after controls arrive.
*Benefit:* an evidence base that survives audit; honest self-assessment.
*New risk:* the manual stack still fails under volume; two custodians can collude. *Control:* keep the manual phase short and small by design — this is an argument for a *smaller* pilot, not a better spreadsheet.
*Difficulty:* **L**.

**M13 — Add a Team Recognition Gate with sponsor liability (F-25)**
*Original:* phase gates at roadmap level; readiness gates for autonomy **[S: Ch.13, Ch.30]**.
*Problem:* nothing prevents recognising a team before it is capable; nobody bears the cost of a bad team launch.
*Change:* five preconditions for using the name, holding money or running projects (trained leader; named HR verifier; named trained Safety Lead; org-owned payment channel; a City sponsor accepting written responsibility for two quarters) + the sponsor's own readiness affected by sponsored-team failure + recognition rate limits tied to reviewer capacity + a graceful closure path.
*Reason:* incentives, not exhortations, control growth speed.
*Benefit:* growth matches governance; bad teams are prevented rather than repaired.
*New risk:* sponsors become conservative and refuse to sponsor; growth slows more than intended; sponsored teams become dependent. *Control:* the sponsor obligation is *time-bound* (two quarters) and *defined* (a checklist, not open-ended responsibility); recognise and reward good sponsorship.
*Difficulty:* **M**.

**M14 — Add mission firewalls: service floor, capacity ceiling, mission-conflict segregation (F-17)**
*Original:* balanced weights; mission-drift risk with discretionary rebalancing **[S: Ch.25, Ch.28]**.
*Problem:* a discretionary control loses to a structural incentive.
*Change:* minimum verified service outcomes per team per quarter (score-capping if unmet); a maximum share of team hours on commercial work; the AI & Business Manager may not hold Funds/Audit/scoring roles in the same team; service-first scheduling during declared emergencies; a published annual Mission Balance Statement.
*Reason:* mission integrity cannot depend on each leader's virtue in each quarter.
*Benefit:* drift becomes legible and correctable while still reversible.
*New risk:* the service floor becomes performative compliance (F-20 in a new costume); the capacity ceiling starves viable ventures. *Control:* the floor is measured in *verified outcomes with follow-up*, not activities; the ceiling is set from pilot data and adjustable by published rule with an exception process.
*Difficulty:* **M**.

**M15 — Cohort-normalise everything and publish the footprint map (F-18, F-19)**
*Original:* non-discrimination doctrine; state specialist support **[S: Ch.2, Ch.6]**.
*Problem:* constant governance cost against wildly variable local revenue capacity drifts the network toward affluent areas.
*Change:* peer-cohort scoring; a differentiated "Service Cell" team model with a reduced control set and city-hosted functions; an explicit cross-subsidy policy with published allocations; an annual published footprint map by area type.
*Reason:* the organisation's own doctrine makes equitable geography a testable claim.
*Benefit:* mission consistency; credibility with authorities and funders; service reach into hard areas.
*New risk:* cross-subsidy creates resentment in earning teams ("our money pays for them"); Service Cells may become permanent dependents. *Control:* publish cross-subsidy as *mutual insurance* (every team is a net receiver in its first year); Service Cells have their own maturity path and review cycle.
*Difficulty:* **M–H** (policy + finance + platform).

**M16 — Add recruitment-conduct and earnings-reality rules (F-02)**
*Original:* compensation for verified work; "serve without expecting reward"; anti-gaming **[S: Ch.2, Ch.18, Ch.25]**.
*Problem:* nothing governs what may be *promised* during recruitment.
*Change:* a published earnings reality per category (typical hours, typical range, explicit non-guarantee); unapproved earnings claims = ordinary violation; intake throttled to available verified work; separate service and earnings tracks.
*Reason:* the "fake job scheme" label is unrecoverable and is generated entirely at the recruitment moment.
*Benefit:* honest expectations; the right people join; fewer early exits.
*New risk:* honest disclosure reduces recruitment volume. **Yes — deliberately.** A smaller honest intake beats a larger deceived one.
*Difficulty:* **L**.

**M17 — Add a language architecture (F-31, §13)**
*Original:* none. The document is English-language throughout **[S]**.
*Problem:* language operates as an unwritten membership test; vernacular AI quality varies; non-Hindi states will read an English/Hindi organisation as an imposition.
*Change:* the three-layer model (specification / operational / public), the six rules in §13.2, a state-language-first public posture, terminology registers, human review of machine translation, a language-equity metric.
*Reason:* local authenticity is impossible without it; it is also a legal requirement for privacy notices **[X]**.
*Benefit:* reach beyond the metro/Hindi belt; genuine "many Indias" expression (§12).
*New risk:* translation inconsistency creating divergent rules; cost; a language hierarchy emerging anyway (English-speaking leaders advance faster). *Control:* one controlled source of truth per artefact with versioned translations; monitor leadership composition by language background as a fairness metric.
*Difficulty:* **M–H** (bounded but real; sequence by pilot geography).

**M18 — Add recognition design rules and culture instruments (F-33, §15, §16)**
*Original:* leaderboard; evidence-linked claims; no recognition architecture **[S: Ch.25]**.
*Problem:* recognition converts into a status hierarchy; culture has no transmission instruments beyond documents and training.
*Change:* the §15.2 behaviour table; §15.3 tripwire metrics; §16.1 twelve prohibited mechanisms; §16.2 institutional checks; local, specific, evidence-cited recognition; no public individual ranking below leadership; a published annual culture report.
*Reason:* culture is transmitted by what is rewarded, punished, tolerated and told — none of which the architecture currently instruments.
*Benefit:* the good culture in the document becomes the actual culture of the organisation.
*New risk:* culture reporting becomes PR; prohibited-mechanism lists feel like a compliance chore; tripwire metrics get gamed. *Control:* include unflattering survey items and publish them; keep the list short and memorisable; audit the culture report itself.
*Difficulty:* **L–M** (mostly will, not engineering).

**M19 — Add a funding doctrine (F-32)**
*Original:* social-impact fund restrictions; partnership due diligence; SOP-07 donations **[S: Ch.20, Ch.29]**.
*Problem:* strong on *use* of funds, silent on *pursuit* of funds; funder agenda capture and tax/FCRA exposure **[X]**.
*Change:* community need precedes funder interest; a single-funder concentration cap; refusal criteria; separate restricted accounting with published utilisation; FCRA analysis before any foreign contribution; 12A/80G conditions embedded in the compliance calendar.
*Reason:* grant dependency silently rewrites missions.
*Benefit:* mission durability; tax and regulatory safety.
*New risk:* refusing available money slows growth and frustrates teams. *Control:* publish refusal criteria in advance so refusals are institutional rather than personal; build the venture pillar so refusals are affordable.
*Difficulty:* **L**; requires tax/legal validation **[V]**.

**M20 — Add QR-use restrictions (F-28)**
*Original:* QR card CONCEPT APPROVED — minimal data, revocable token, non-police design **[S: Ch.33]**.
*Problem:* no restriction on *who may scan whom, for what*.
*Change:* the six-condition use rule in F-28(7); every scan logged with a reason code; card wording describes a service record, not an authority credential.
*Reason:* any identity instrument develops enforcement use unless forbidden.
*Benefit:* prevents the private-checkpoint perception that would feed F-09.
*New risk:* legitimate verification becomes cumbersome. *Control:* verifying a person *claiming a role* remains quick; only verification *of others* is restricted.
*Difficulty:* **L**.

**M21 — Add AI review capacity governance (F-29)**
*Original:* every medium/high-risk recommendation needs a named human decision and audit trail **[S: Ch.21]**.
*Problem:* no capacity model; review fatigue converts the doctrine into theatre.
*Change:* published risk tiers; a per-reviewer daily cap enforced by the platform; a free-text reason required for material decisions; sampled review-quality audits; kill-switch and rollback.
*Reason:* human-in-the-loop systems fail by throughput, not by principle.
*Benefit:* the doctrine stays true at scale.
*New risk:* caps create queues; queues delay operations. *Control:* tier design must ensure only genuinely material decisions enter the capped queue — that is the real work.
*Difficulty:* **M**.

**M22 — Add the four missing risks and extend the audit doctrine to sampling (F-13, F-32, F-36, §5 Scenario C)**
*Original:* an 18-risk register; audit exhaustive by implication **[S: Ch.28, Ch.27]**.
*Problem:* the register is internally focused — it omits political capture, public misclassification, funder agenda capture and local secession; the audit model has no sampling doctrine for scale.
*Change:* add the four risks with detection/prevention/response/owner; add a risk-based sampling doctrine (what is reviewed exhaustively, what by sample, what by exception, and at what team counts the transition occurs).
*Reason:* a risk register listing only internal risks gives false assurance; exhaustive audit is arithmetically impossible beyond a few thousand teams.
*New risk:* sampling means some fraud is not caught — statistically certain. *Control:* publish the sampling rate and the detection philosophy; combine with a strong integrity intake (M10) so detection does not depend on sampling alone.
*Difficulty:* **L–M**.

**M23 — Add the missing SOPs (F-04, F-13, F-21, M17, M18)**
*Original:* 22 SOPs covering application through data breach **[S: App. D]**.
*Problem:* no SOP for exit interviews, stay interviews, integrity-line intake and triage, standard-change requests, translation review and release, recognition decisions, team closure, or beneficiary-to-participant conversion.
*Change:* add those eight SOPs in the same format (trigger / minimum steps / stop-or-escalate-if / owner).
*Reason:* the architecture's own operating method is SOP-based; a rule without an SOP is an aspiration.
*Benefit:* closes the retention, whistleblowing, localisation, recognition and graceful-exit gaps using the document's own instrument.
*New risk:* more SOPs add to the compliance load (F-05). *Control:* all eight are tiered — only integrity intake and team closure are mandatory at Pilot Fidelity.
*Difficulty:* **L**.

## 25.3 RECONSIDER (serious concerns; decisions for the founder)

**R1 — Whether "Protection / First Response" should be a publicly named pillar in the first years**
*Original:* pillar 3 of four **[S: Ch.3]**.
*Concern:* the *function* is well-designed and morally serious. The *label* imports the most dangerous public misclassification (F-09), attracts the most dangerous self-selection (motivation #11, §6.2), and requires an insurance/legal wrapper that does not yet exist (F-10).
*Options:* (i) keep the pillar and add the wrapper before any publicity; (ii) retain the capability internally but describe it publicly as "emergency support and community safety awareness" for the first years, renaming once legitimacy and insurance exist; (iii) restrict the function to *certified, insured, small* first-response teams rather than general membership.
*Reason to reconsider:* naming is not cosmetic — it determines who joins and how the state and media classify you.
*New risk of changing:* members who joined for the protective function feel the mission was diluted; internal credibility loss. *New risk of not changing:* one filmed incident in year one.
*Decision owner:* Founder/CEO with legal and safety review **[V]**. **Not my call to make.**

**R2 — Whether the weekly payment cycle should be the default**
*Original:* a Monday–Sunday cycle, 13 steps **[S: Ch.19]**.
*Concern:* weekly cadence is a *promise* that creates an expectation the revenue base cannot reliably meet (F-06), and it is operationally heavy at small scale. Its virtues — transparency and worker-first discipline — do not require weekly frequency.
*Options:* weekly for teams with stable weekly revenue; fortnightly/monthly elsewhere, with the same waterfall, the same audit trail and the same published formula.
*New risk:* less frequent payment weakens the motivational feedback loop and may read as a downgrade.
*Decision owner:* Finance + CEO with legal/payroll validation **[V]**.

**R3 — Whether the State layer should exist by org chart or be earned by density**
*Original:* State Teams as a formal hierarchy level **[S: Ch.4, Ch.6]**.
*Concern:* a state layer costs more than it returns until several cities function, and titles without work become status ("fake vacancies" is already a named risk **[S: Ch.28]**).
*Options:* create the state layer only when a state has N functioning cities (N to be approved); until then let National coordinate cities directly with a designated anchor city.
*New risk:* skipping the layer may overload National — the very thing the escalation filter exists to prevent **[S: Ch.6]**.
*Decision owner:* CEO + National Operations.

**R4 — Whether one legal entity can hold all four pillars**
*Original:* legal structure under Krytos is UNRESOLVED; options listed include internal division, subsidiary, nonprofit/social arm, hybrid **[S: Ch.33]**.
*Concern:* service (donation/CSR-eligible, tax-exempt-eligible, politically restricted **[X]**), business (taxable, contractual, market-facing) and protection (liability-heavy, insurance-dependent) have conflicting legal natures. A single entity will serve none of them well.
*Options:* (i) single entity now, restructure later — cheap now, expensive or impossible later once contracts and reputation attach to one name; (ii) two entities from the start — a not-for-profit service entity and a for-profit venture entity — with a brand licence, related-party agreements and strict transfer-pricing discipline **[V]**; (iii) a holding structure with the mission held separately from both.
*New risk of separating:* administrative burden, related-party scrutiny, and a possible public perception of "charity and business being mixed" whichever way it is done; donor confusion.
*Decision owner:* Founder/CEO with corporate, tax and regulatory counsel **[V]**. **This is the Phase 0 decision on which most others depend, and it should be made first.**

**R5 — Whether the leaderboard should be public at all**
*Original:* "published after anomaly review, corrections and appeals" **[S: Ch.25]**.
*Concern:* publication converts a management instrument into a status and political instrument (F-19, F-22, F-33). Its stated purposes — accountability and motivation — can be met by publishing *outcomes and integrity* rather than *rank*.
*Options:* publish outcomes and integrity metrics, with rank visible only inside the network and only to the teams concerned; or publish rank with cohort normalisation and no individual names.
*New risk:* less public competition may reduce motivation for the competitively inclined.
*Decision owner:* CEO + proposed Council + Operations.

---

# 26. CRITICAL CHANGES REQUIRED BEFORE LAUNCH

**Sequenced. Each item states why it is *pre*-launch rather than post-launch. [P; V where marked]**

| # | Change | Why it cannot wait | Owner | Effort |
|---|---|---|---|---|
| **1** | **Decide the legal structure (R4)** — entity form, tax position, worker classification, service/business separation | Everything downstream (payment, insurance, contracts, tax exemption, FCRA, political-neutrality obligations) depends on it; it is UNRESOLVED **[S: Ch.33]** and it is Phase 0 **[S: Ch.30]** | Founder/CEO + counsel **[V]** | H |
| **2** | **Adopt the Political Neutrality Code (M2)** | Must exist *before* the first public activity, because the first approach will come early and the answer given then becomes precedent | CEO + Legal + Council | L |
| **3** | **Protection visibility protocol + do-not-attend list + insurance and legal-support package (M3)** | An incident in month three with no cover ends the institution; you cannot retro-insure a known event | Safety + Legal + Finance **[V]** | M |
| **4** | **Privacy minimum: data classification, retention schedule, privacy notice in operating languages, rehearsed breach runbook, named privacy officer (M11)** | The first thousand records are the ones you will wish you had handled correctly; retention is UNRESOLVED **[S: Ch.33]**; DPDP duties are live **[X]** | AI & Data + Legal **[V]** | M |
| **5** | **Participation spectrum Levels 0–4 (M1)** | Determines the entire adoption curve; retrofitting after habits form is far harder | HR + Legal **[V]** | M |
| **6** | **Team Recognition Gate + City sponsor model (M13)** | Prevents the un-closable bad team; cheap now, impossible later | Operations + CEO | M |
| **7** | **Manual-phase control stack: 6 forms, two-person money rule, hard expiry trigger (M12)** | The pilot *will* run manually; the habits formed there become the culture | Operations + AI & Data | L |
| **8** | **Earnings-reality disclosure and recruitment-conduct rule (M16)** | The first recruitment conversation sets an expectation that will either be met or resented | HR + Business + Communications | L |
| **9** | **Cold-start instrument decision (M5)** — float, anchored-revenue precondition, or slower payment cycle | Determines whether the first teams survive their first quarter | Finance + CEO **[V]** | M |
| **10** | **Language architecture: L1/L2/L3 rule + terminology register for the pilot languages (M17)** | Every artefact produced before this exists will need re-translation later | Communications + AI & Data | M |
| **11** | **Mission lock, apex dispute clause, founder-succession article (M4)** | Costs almost nothing before the institution has value; costs everything after | CEO + Council + counsel **[V]** | M (legal) / H (willingness) |
| **12** | **Integrity Line + ombuds + non-retaliation rule (M10)** | Must be operational *before* the first leader-abuse case, or the first case will be discovered publicly | Audit & Ethics + Council | M |
| **13** | **Certified safeguarding, two-adult rule, image/consent absolutes, mandatory reporting protocol (§16.3)** | Working with children without certified safeguarding is the highest-consequence operational risk in the model | HR + Safety + Legal **[V]** | M |
| **14** | **Two-speed scoring decision and cohort definitions (M8)** — decide *before* the first leaderboard exists | Once teams have been ranked, the ranking cannot be un-felt | Operations + Council | M |
| **15** | **Public complaint channel + "how to leave" page + authenticity verification channel (§14.2, §16.2)** | Trust instruments must pre-exist the first distrust event | Communications + Council | L |

**What is deliberately NOT on this list [A]:** the software platform (a manual stack suffices for S0–S1 if M12 is honoured); the full 14-module data architecture; the vacancy catalogue at all four levels; the state layer; the leaderboard; badges and ceremonies; the QR card; national branding. All are correctly deferrable — and deferring them is a *strength*, not a compromise.

---

# 27. WHAT MUST NEVER BE COMPROMISED AS WE SCALE

**[P]** Five items. Each is chosen because it is (a) load-bearing for everything else, (b) cheap to keep and impossible to restore once lost, and (c) already latent in your architecture — so keeping it is fidelity, not innovation.

**1. The dignity and privacy of the person being helped.**
No photograph of a recipient as proof. No identity exposed to justify a claim. No recruitment at the moment of need. No humiliation disguised as gratitude. *Why non-negotiable:* this is the only item whose violation harms a person who trusted you and had no power in the transaction. Everything else on this list protects the institution; this protects the citizen. **Enforcement:** absolute prohibition with removal as the sanction, plus an external safeguarding adviser with publication rights (§16.3).

**2. Worker compensation first in the priority order, and truthful accounting.**
The order stays **[S: Ch.18]**; the arithmetic gets published; nobody's verified work is sacrificed to an organisational fee, a reserve or a social contribution. *Why non-negotiable:* it is the organisation's only economic promise, and the one whose breach is immediately visible to the people least able to complain. **Enforcement:** member payment confirmation (M7); published formula version; a leader may never approve their own allocation.

**3. No weapons, no retaliation, no mob justice, no unlawful detention or search, no impersonation of authority, no intimidation.**
Verbatim from Ch.16 **[S]**, extended by the visibility protocol (M3). *Why non-negotiable:* one violation converts a service institution into a feared one — permanently, in the memory of a neighbourhood and in video that does not expire. **Enforcement:** immediate removal, not warning; published doctrine; insurance and legal review; do-not-attend list.

**4. AI recommends; humans decide — and a named human is accountable.**
Including the prohibited-decisions list **[S: Ch.21]**, extended by review-capacity governance (M21). *Why non-negotiable:* the moment a person is hired, fired, paid, denied or endangered by an unreviewed system, the organisation has transferred moral responsibility to a process nobody can be accountable for — and every other promise in the document becomes unenforceable. **Enforcement:** free-text reasons on material decisions; review-quality audits; kill-switch; AI logs preserved.

**5. Political and religious non-alignment, and non-discrimination in service.**
Extended from Ch.2 **[S]** by M2. *Why non-negotiable:* the entire value proposition is that the organisation serves everyone in a locality. That proposition is not partially divisible. The first partisan act does not reduce trust by a fraction — it reclassifies the institution for everyone who disagrees, permanently, and it jeopardises tax-exempt standing **[X]**. **Enforcement:** declared conflicts, refusal log, election-period protocol, audit sampling, and removal for partisan use of organisational resources.

**The test for every future compromise [P]:** *"If this compromise were published in full, on the front page, with the reasoning, would the people we serve still trust us?"* If the answer requires the reasoning to be hidden, it is not a compromise — it is a concealment.

---

# 28. MATURE-STATE VISION (a possible architecture, not a prediction)

**Framing [A]:** the following describes *what a mature state could look like if the modifications in §25–26 are made and the failure modes in §3 are managed*. It is not a forecast. Nothing here should be read as an expectation, a commitment, or a claim about scale or timing.

## 28.1 The progression

**A person → a contributor.**
Someone in a neighbourhood hears that a lane was fixed, or is helped once with dignity, or attends one Saturday activity. They give an hour. Their name is attached to a real, dated, verified outcome. Nothing is asked of them. They may never give another hour — and the institution is still better for having helped them, or for having been helped by them.

**A contributor → a team member.**
They come back. They are paired with two people. They learn a skill and are certified for it. They choose — explicitly, with a separate consent — to take responsibility: verification, training, probation, a role. They now hold permissions and duties. They may instead choose to remain a contributor for twenty years and be honoured for it, because the institution no longer treats membership as the only respectable state.

**A team → a local institution.**
The team survives its founders. It has a service record the neighbourhood can inspect, a published account of what it spent, a named person to complain to, a rotating set of leaders who were trained before they were promoted, a store others borrow from, a specialist list others call, and local rituals that mark real achievement. Residents who never join describe it as "ours". Municipal officials call it before calling a contractor. Its credibility is *local, specific and earned* — and it is portable to the next neighbourhood when its members move.

**Local institutions → a connected national network.**
Hundreds and then thousands of such teams share: one doctrine, one set of prohibitions, one evidence standard, one payment ethic, one privacy regime, one service-record format, one training and certification system, one assurance method, one published set of accounts. They do not share a manager. The centre is small and strong: constitution, standards, assurance, specialist pools, platform, reserve and cross-subsidy mechanism, legal and privacy office, public record. The edges hold everything else.

**The national network → value returned to the communities that sustain it.**
This is the step most institutions never design. Return flows could include: a verified service record and reference that helps a member get a job or a loan; certified skills that travel; specialist help a small town could never afford alone; a wage-protection buffer in a bad season; a safety escalation path that reaches authorities faster than an individual could; audited accounts that let a neighbourhood see what happened to money given in its name; an archive of what the place achieved, which becomes part of its own history; and a standing channel through which a locality can organise itself without waiting for permission from anyone.

**The loop closes:** `LOCAL SERVICE → TRUST → CAPABILITY → COMMUNITY → NETWORK → NATIONAL SCALE → (returns to) LOCAL SERVICE`.

## 28.2 What the mature institution would look like structurally **[P]**

- **Federated:** state or regional entities bound by a common constitution and brand licence; a national standards and assurance body; no single owner able to redirect the mission (M4, R4).
- **Layered for separation:** mission/standards, service delivery, ventures, platform and assurance separately governed, so a failure in one does not consume the others (§5 Scenario F).
- **Protocol-like at the edges:** the value lies in the *standards* that let strangers cooperate and verify each other's work, not in central command.
- **Small centre, thick edges:** which is what "central mission, local autonomy" **[S: Ch.2]** actually implies at scale.
- **Publicly accountable by design:** published accounts, failures, corrections, integrity statistics, mission-balance statement; independent external review; a public complaint route including external routes.
- **Economically plural:** venture revenue, fee-for-service, partnerships, CSR, restricted grants, individual contributions — with no single source able to set the agenda (M19, F-18).
- **Emotionally plain:** no rallies, no personality, no enemies, no guilt. Recognition is local and specific. The proudest sentence a member can say is factual: *"We fixed the drain near the school. Here is the record. Here is what it cost. Here is what we got wrong the first time."*

## 28.3 The honest caveat **[A]**

Everything in §28 depends on three things the document cannot supply: **a legal structure that survives its founder; a local unit that pays for its own governance; and a supply of trusted people that grows as fast as the network does.** If those three are solved, the architecture as written is unusually well-suited to become a durable Indian institution. If they are not, no amount of additional design will compensate — and the failure will look, from inside, like bad luck rather than like arithmetic.

---

# 29. WHY INDIA? (a factual, non-manipulative narrative)

**Constraints honoured [P]:** no nationalism as emotional fuel; no political persuasion; no claim of superiority over existing Indian institutions; no invented statistics. Everything below is either a structural observation or a cited external fact.

1. **India's problems and India's capacity are both hyper-local.** The lane that floods, the school that needs a teacher on Saturday, the elderly neighbour who cannot reach a clinic, the shopkeeper who needs a website — these are visible only at neighbourhood scale, and the people who could fix them usually live within two kilometres. **[A]**
2. **India has an enormous quantity of under-used capability.** Students, retirees, professionals, homemakers, skilled tradespeople and a very large diaspora — people with hours, skills and equipment that no institution currently aggregates at neighbourhood scale. NSS alone involves on the order of 3.8–3.9 million student volunteers **[X]**, which demonstrates both the willingness and the limitation: it is real, and it is time-bound to student life. **[A]**
3. **India already has the digital rails that make verification cheap.** National digital identity at roughly 1.4 billion enrolments, a payments interface processing on the order of 16–18 billion transactions a month, and a document-vault service with several hundred million users **[X]**. An organisation whose core promise is *verifiable* service and *traceable* money is, for the first time, technically feasible at low cost in India. Any use of government identity infrastructure for verification carries legal conditions and requires validation **[V]**. **[A]**
4. **India's binding constraint is not willingness but verifiable trust.** People give, help and volunteer constantly — through families, faith bodies, caste and community associations, neighbourhood groups. What is scarce is an institution that is *neutral, verifiable and continuous*: one that will help anyone, show its accounts, keep its records, and still be there in five years. **[A]**
5. **Therefore the useful thing to build is not another charity, party, platform or NGO.** It is a **verification and continuity layer over local goodwill** — one that keeps records so trust can compound, pays workers first so effort is honoured, refuses political alignment so everyone can use it, and connects a neighbourhood to national capability when a local problem is bigger than the locality. **[A]**

**The message, in one line [P]:**
> **MANY COMMUNITIES. ONE COMMITMENT TO SERVICE.**

**And the supporting line, for people who are rightly suspicious:**
> *We will show you what we did, what it cost, who did it, and what we got wrong.*

---

# 30. FINAL STRATEGIC CONCLUSIONS

## 30.1 If we built this exactly as designed, the three most likely reasons it would fail

**1. Legitimacy collapse from an external event it has no defence against.**
A protection incident, a politicisation episode, or a public misclassification (F-08, F-09, F-10, F-36) reframes the organisation permanently. *Why most likely:* the doctrine governing insider behaviour is excellent, while the instruments governing outsider perception, legal liability and political approach are absent. External events are not rare; over a multi-year horizon they are certain for any street-facing mass organisation.

**2. The local unit does not pay for itself.**
Compliance labour (F-05), a weekly payment promise against lumpy revenue (F-06), a wage buffer that arrives only after success, and small-ticket venture economics (F-34) leave the Mohalla team structurally unviable in year one. Teams close, or survive as paper entities, and the network stalls at pilot scale — while the architecture continues to describe a national organisation. *Why most likely:* it is arithmetic, not behaviour, and the arithmetic is currently unmeasured and unfunded.

**3. The trusted-people bottleneck.**
Every control in the document — verification, evidence, segregation, audit, human review of AI, safeguarding, incident response, readiness gating — is executed by a trained, honest human being with time. Their supply grows far more slowly than the demand created by growth (§5 Scenario B, F-25). The organisation then either relaxes gates silently (destroying the control system) or freezes growth (destroying the mission). *Why most likely:* it is the binding constraint at every stage above ~1,000 members, and there is no capacity model anywhere in 179 pages.

## 30.2 The three things that would most determine whether it survives

**1. The legal-and-political firewall, built before the first public act.**
Entity structure and tax position (R4); worker classification; insurance and legal-support package (M3); Political Neutrality Code (M2); protection visibility protocol; privacy programme (M11). This is Phase 0 **[S: Ch.30]** — currently the least-developed part of the model relative to its importance.

**2. A proven, costed, replicable local unit.**
One Mohalla team that, over four consecutive quarters: completes verified service outcomes; generates or receives enough resource to pay its people honestly under the waterfall; produces its six core records contemporaneously; survives one incident and one complaint without concealment; and does so within a *measured* governance-hour budget. Until that unit exists and is documented, nothing about scale is knowable. **This single artefact — the costed, evidenced unit economics of one team — is the most valuable thing the organisation could produce next.** **[P]**

**3. A governance-people pipeline with an assurance model that can sample.**
Training as an institution (trainer certification, multilingual content, certified restricted-domain training); a horizontal competence ladder so capable people stay without promotion (M9); rotation of control roles; and a risk-based sampling doctrine so assurance scales sub-linearly with team count (M22). Without this, growth is either dishonest or frozen.

## 30.3 What must be true before national expansion

**[P]** A gate, not a mood. National expansion (Phase 5 **[S: Ch.30]**) should require all of the following to be *demonstrably* true, each with evidence:

1. Legal entity, tax position and worker classification resolved and documented **[V]**.
2. Insurance in force for members and third parties **[V]**.
3. Political Neutrality Code adopted, published, and *used at least once* (a logged refusal).
4. Privacy programme live: classification, retention, notices in operating languages, rehearsed breach runbook, named privacy officer **[V, X]**.
5. Certified safeguarding for all work with minors and vulnerable adults; two-adult rule enforced; zero unresolved safeguarding allegations **[V]**.
6. At least N consecutive quarters of published accounts, with worker compensation shown separately (N to be approved).
7. At least one independently verified impact claim, and one published correction of the organisation's own error.
8. A functioning public complaint channel with published resolution statistics, including at least one adverse finding acted upon.
9. Mission lock, apex dispute clause and founder-succession article executed (M4).
10. A costed unit model for a Mohalla team, validated across at least three materially different contexts (urban, small town, rural).
11. An assurance model specifying what is audited exhaustively, what by sample, and at what team counts the transition occurs.
12. A leader pipeline producing trained leaders and control-role holders at a measured rate exceeding the team-formation rate.
13. Language equity: members in every operating state able to complete onboarding, a task record, a grievance and a payment confirmation entirely in their own language.
14. A mission-balance statement showing service outcomes not being displaced by commercial work (M14).
15. Zero unresolved CRITICAL items from this failure map.

**Until items 1–5 and 9 are true, the organisation should not describe itself as national in any public document.** Under-claiming is a strategy; over-claiming is a liability that compounds.

## 30.4 What should never be compromised

See §27 — in one line each:
1. **The dignity and privacy of the person helped.**
2. **Worker compensation first, and truthful accounting.**
3. **No weapons, no retaliation, no mob justice, no unlawful detention, no impersonation, no intimidation.**
4. **AI recommends; a named human decides and is accountable.**
5. **Political and religious non-alignment; service without discrimination.**

## 30.5 The answer to your ultimate question

> *"How do we build an organisation that people would voluntarily choose because it makes their community and their own contribution more meaningful?"*

**[A]** Not by persuading them. By doing four things so consistently that the conclusion forms inside them without your help:

1. **Be useful before asking anything.** Help first; verify later; never invite at the moment of need. The first transaction must cost the citizen nothing and give them something real (§20, §21).
2. **Prove the contribution was real.** Show the person what their hour produced — dated, specific, recorded — and let them carry that proof into their own life as a credential (§6.2 item 6, §14.2). This is the emotion nobody else in this space can supply, and your architecture already generates the evidence for it.
3. **Be visibly honest, especially when it costs you.** Publish the accounts, the failures, the corrections, the complaints and the refusals. In an environment where every institution over-claims, radical plainness is not modesty — it is the most aggressive differentiation available (§14, §18).
4. **Make it belong to the neighbourhood, not to the centre.** Local language, local calendar, local names for roles, local rituals, local credit, local authority over what the problem *is*. The centre supplies standards, specialists, resources, assurance and continuity — and stays out of the way (§12).

Do those four, and the sentence you want people to reach on their own — *"this is useful to my community, I can contribute something here, my contribution matters, I trust how this organisation operates, I want to be part of this"* — becomes the natural output of the system rather than a marketing objective.

**And the hardest truth in this report [A]:** the architecture you have built is already better at *deserving* that sentence than at *delivering the experience* that produces it. Nearly every modification proposed here is about moving weight from the first to the second — from documents that describe integrity to moments that create it.

---
---

# ANNEXURE A — MAP OF YOUR 34 PARTS TO THIS REPORT

| Your part | Section here | Your part | Section here |
|---|---|---|---|
| 1 The hardest question | §2, §3 | 18 Trust | §14 |
| 2 Failure map | §3 (F-01…F-36) | 19 Public perception risks | §18 |
| 3 What if everything goes wrong | §4, §5 (Scenario A) | 20 Competition and alternatives | §19 |
| 4 Why would anyone join | §6 | 21 The 10-second test | §20.1–20.2 |
| 5 Do not make everyone join | §8 premise, §28.2 | 22 First 5 minutes | §20.3 |
| 6 Participation spectrum | §9 | 23 First real win | §21 |
| 7 National emotional connection | §10 | 24 National growth loop | §22 |
| 8 Core emotional idea | §10.2 | 25 What makes people proud | §15.2, §22.4, §28.2 |
| 9 One India, many Indias | §12 | 26 Design the culture | §15 |
| 10 Language strategy | §13 | 27 Worst-case culture | §4.2, §15.3 |
| 11 Local identity | §12.1, §12.3 | 28 Foundational question | §8 (last row), §28.1, §30.5 |
| 12 "I know someone who helped me" | §22.2 | 29 National social contract | §12.3, §18.2, §28.2, §29 |
| 13 National brand without personality cult | §11 | 30 Test architecture against reality | §24 |
| 14 Symbols and culture | §15.2, §16.1(7), F-33 | 31 National adoption architecture | §23 |
| 15 Everyone can contribute | §8, §9, §21.2 | 32 "Why India?" narrative | §29 |
| 16 Why would people stay | §7 | 33 Final strategic question | §30.1–30.4 |
| 17 Economic sustainability vs service | §17 | 34 Final national vision | §28 |
| — | — | Required 30-section output | §1–§30, in order |

**Note on Part 29 (national social contract):** the boundary position recommended here is that Sewak Sathi may act as a *documented, neutral, non-authority-bearing interface* — it can identify a need, verify it, organise help, escalate to the legitimate authority, and record what happened. It must never: claim authority it does not have; substitute for police, municipal, medical, judicial or welfare functions; broker access to government schemes for a fee; detain, adjudicate or punish; or present itself as an official channel. This follows from the source's own doctrine ("contact authorities"; "authorities first, no obstruction"; protection is not enforcement **[S: Ch.15, Ch.16]**) and from the misclassification risk in §18.2.

---

# ANNEXURE B — CONSOLIDATED VALIDATION REGISTER

Everything below requires a qualified professional before it is relied upon. Items marked ◆ are **pre-launch**.

**Corporate / entity ◆** — entity form and structure (single vs. two-entity vs. holding); objects clauses permitting all four pillars; feasibility of altering objects later; related-party and transfer-pricing discipline if service and business are separated; brand licensing between entities; dissolution and asset-transfer constraints; enforceability of a mission lock.

**Tax ◆** — eligibility for and conditions of income-tax exemption for a charitable entity (including the application-of-income requirement and the prohibition on political activity); donor-deduction eligibility and its cash-donation limits; GST treatment of services rendered; taxation of venture revenue; treatment of the social-impact fund and reserves; FCRA analysis before accepting any foreign contribution **[X]**.

**Employment / labour ◆** — classification of members as employee / contract labour / volunteer / stipend / business participant; minimum-wage and payment-cycle legality; statutory social-security and deduction obligations; appointment letters and contracts in member languages; legality of the grievance and disciplinary procedure; the volunteer-vs-worker boundary at each spectrum level (§9).

**Safeguarding ◆** — adequacy of certified child-protection and vulnerable-adult training; mandatory reporting duties and to whom; two-adult rule implementation; consent, image and records handling for minors; external safeguarding review.

**Criminal / liability ◆** — legal review of the protection intervention boundary, including private-person arrest powers and the handover requirement, and the public's duty to assist police when lawfully demanded **[X]**; Good-Samaritan-type protections for emergency assistance; assault/negligence exposure for members acting in organisational capacity; vicarious liability of the organisation.

**Insurance ◆** — personal accident for members; public/third-party liability for events and service work; professional indemnity for advice; director/officer cover; claims protocol.

**Data protection ◆** — DPDP compliance programme: lawful basis and consent design; privacy-notice content and languages; purpose limitation and data minimisation per tier; retention schedule and erasure; security safeguards; Significant Data Fiduciary assessment and obligations (India-based DPO, DPIA, annual audit, Board reporting); breach-notification timelines to the Board and to affected individuals; grievance-redressal timelines; processor/vendor contracts; children's-data rules; cross-border transfer restrictions if any cloud processing occurs **[X]**.

**Sector permissions** — food safety for distribution; health-support and camp boundaries (no diagnosis/treatment without licence); municipal permissions for cleaning/plantation/infrastructure; disaster-response coordination with statutory bodies; animal-welfare legality; public-collection permissions where applicable; regulated-market constraints on produce aggregation.

**Financial / audit** — reserve-release matrix; legality and accounting of a cross-subsidy policy; restricted-fund accounting; treatment of a cold-start float (M5); statutory audit arrangements; internal-audit independence.

**IP / brand** — name availability and registration for "Sewak Sathi Sanstha" **[S: Ch.33 PROPOSED]**; trademark classes; mark-usage rules for local variants; protection against impostor use.

---

# ANNEXURE C — EXTERNAL SOURCES RELIED ON (tagged [X] in the text)

Used only to ground real-world constraints. They are not evidence about your organisation, and each should be re-verified with a professional before reliance.

1. **DPDP Act 2023 / DPDP Rules 2025 (India)** — breach notification to the Board "without delay" with a detailed report within 72 hours; notification of affected data principals; prescribed security safeguards; Significant Data Fiduciary obligations (India-based DPO, DPIA, annual audit, reporting to the Board); privacy notice in clear plain language available in English or any of the 22 Eighth Schedule languages; time-bound grievance redressal; large financial penalties; separate CERT-In incident reporting within 6 hours under IT Act directions.
 *ey.com — "Decoding the Digital Personal Data Protection Act, 2023"; ssrana.in — "Data Breach Reporting in India: Legal obligations and Best Practices"; complyzero.com — "DPDP Breach Notification: The 72-Hour Rule"; lexology.com — "India's New Digital Privacy Law: The DPDP Act and Rules Explained"; hlc.com — "India's Digital Personal Data Protection Act 2023 brought into force".*
2. **Indian not-for-profit legal forms and tax treatment** — trust / society / Section 8 company comparison; 12A income-tax exemption and its conditions, including application of income (~85%) and the prohibition on political activity or support to parties/candidates; 80G donor deduction and its cash-donation limit; FCRA generally requiring about three years of track record and a dedicated account before foreign contribution may be received.
 *incorpx.io; legalsuvidha.com; taxaj.com; ebizfiling.com; setindiabiz.com.*
3. **India Stack scale** — Aadhaar ≈1.4 billion+ enrolments; UPI ≈16–18 billion transactions per month (2025–26); DigiLocker reported ≈545 million users (July 2025). Used only to support the claim that verification and payment rails are technically cheap in India.
 *en.wikipedia.org/wiki/India_Stack; theprayasindia.com; outlookbusiness.com; thequantumhub.com — "The DPI Decade".*
4. **Private-person arrest and duty to assist police** — Bharatiya Nagarik Suraksha Sanhita, 2023: §40 (arrest by a private person of someone committing a non-bailable cognizable offence in their presence, or a proclaimed offender, with handover to police within six hours); §31 (the public is bound to assist a Magistrate or police officer reasonably demanding aid). Used only to show that the protection boundary requires legal review — not to define it.
 *indiacode.nic.in — BNSS 2023 text; mha.gov.in — BNSS gazette; legalserviceindia.com.*
5. **NSS scale** — National Service Scheme launched 1969 with 40,000 volunteers in 37 universities; current allocation reported at 3.8–3.9 million volunteers across 300+ universities and +2 councils, covering roughly 5–6% of the student population.
 *nss.gov.in/faq; dsyw.assam.gov.in.*
6. **Volunteer attrition and retention** — in one community-health volunteering study, 26.3% of leavers left because they moved and ~38% cited busyness with work/school or generally; in US volunteer fire-service research, cliques/exclusion, unsupportive leadership and unclear time expectations were leading stated reasons for leaving, the first year was worst for retention, and exit/stay interviews were the highest-rated interventions; in a Boy Scouts council study, volunteers receiving recognition had materially lower turnover (6% vs 15%) while training alone did not reliably improve retention; cross-study nonprofit volunteer turnover has been reported in the 24–47% range, and a commonly cited average retention is ~65% year-on-year.
 *pmc.ncbi.nlm.nih.gov (PMC10078732); nvfc.org — Volunteer Retention Research Report; naturalhazards.com.au — Holtrop et al. 2024; scholarworks.indianapolis.iu.edu — BSA Crossroads of America; givebutter.com.*

**Caveat [A]:** items 5 and 6 are largely non-Indian or single-programme studies. They are used to establish *human* regularities (attrition causes, recognition effects, first-year fragility), not Indian magnitudes. Any India-specific retention or participation assumption must be measured in your own pilot — which is itself one of this report's recommendations.

---

*End of report. Prepared as an adversarial strategic analysis of v1.2. No architectural decision has been altered. Every proposal is labelled PROPOSED and requires your approval and, where marked, professional validation.*
