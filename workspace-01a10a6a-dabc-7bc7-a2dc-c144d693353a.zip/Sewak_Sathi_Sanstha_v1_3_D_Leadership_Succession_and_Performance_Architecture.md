# SEWAK SATHI SANSTHA v1.3-D
# LEADERSHIP, SUCCESSION & PERFORMANCE ARCHITECTURE

| | |
|---|---|
| **Instrument** | v1.3-D — fourth major v1.3 instrument, following v1.3-A (Institutional Survival & Legitimacy), v1.3-B (Costed Mohalla Unit Economics) and v1.3-C (Human System, Participation & Mass Adoption) |
| **Question answered** | **HOW DOES THE ORGANISATION PRODUCE TRUSTWORTHY LEADERS AND SURVIVE LOSING THEM?** — how a person becomes eligible, becomes ready, receives authority, remains accountable, develops a successor, and leaves without damaging what they built |
| **Source hierarchy** | **(1)** `…v1_2.pdf` 179 pp. incl. Appendix A preservation of v1.1 — **PRIMARY**; **(2)** `…v1_3_A_Institutional_Survival_and_Legitimacy_Amendment.md` — **PRIMARY AMENDMENT**; **(3)** `…v1_3_B_Costed_Mohalla_Unit_Economics_and_Economic_Survival_Model.md` — **PRIMARY AMENDMENT**; **(4)** `…v1_3_C_Human_System_Participation_and_Mass_Adoption_Architecture.md` — **PRIMARY AMENDMENT**; **(5)** `Sewak_Sathi_Strategic_Stress_Test.md` — **ADVERSARIAL DIAGNOSIS**; **(6)** the v1.3-D brief — **SCOPE** |
| **Relationship to prior instruments** | v1.2 = control system. v1.3-A = can it be trusted. v1.3-B = can it survive economically. v1.3-C = does anyone want to be in it. **v1.3-D = can it produce, replace and hold accountable the people who run it.** Each is additive; none rewrites another |
| **Scope** | Leadership philosophy, eligibility and readiness, the capability model, the evidence model, performance architecture, team performance, outcome windows, cohort normalisation, promotion, succession, continuity, the specialist path, development, apprenticeship, certification, review, complaints and appeals, improvement and removal, gaming, leaderboards, recognition, compensation, workload, burnout, distribution, founder succession, institutional memory, RBAC and security, AI-assisted leadership, privacy, multi-level leadership, selection methods, governance, ethics, anti-cult, crisis, resilience, economic feasibility, control budget, pilot, simulations, audits, measurements, registers and the L-series amendment pack |
| **Explicitly out of scope** | Any change to the four-pillar mission **[S: Ch.3]**, the hierarchy of levels **[S: Ch.4]**, the financial waterfall priority order **[S: Ch.18]**, the protection DO-NOT list **[S-A: A-08]**, the nine-level participation spectrum **[S-C: H-02]**, or the launch roadmap **[S: Ch.30]**. **No performance weight is altered.** No rupee value is invented. No successor is named |
| **Document status** | **LEADERSHIP-SYSTEM DESIGN — PROPOSED.** Nothing here is policy, rule or promise until approved. Every capability claim is a hypothesis to be tested against real people; every threshold is `PROPOSED — REQUIRES PILOT VALIDATION` |
| **Prepared** | 5 October 2026 |

---

## HOW TO READ THIS INSTRUMENT

### Classification tags

| Tag | Class | Meaning |
|---|---|---|
| **[S]** | **SOURCE-DERIVED** | Stated in v1.2 or the preserved v1.1 source; cited by chapter, article, SOP, appendix or database field |
| **[S-ST]** | Source-derived from the **Strategic Stress Test** | Cited by section or failure-mode ID (F-01…F-36, M1…M23, R1…R5) |
| **[S-A]** | Source-derived from **v1.3-A** | Cited by amendment ID (A-01…A-23) or section |
| **[S-B]** | Source-derived from **v1.3-B** | Cited by amendment ID (B-01…B-27) or section |
| **[S-C]** | Source-derived from **v1.3-C** | Cited by amendment ID (H-01…H-28) or section |
| **[A]** | **ANALYSIS** | Reasoning applied to source facts. Not evidence |
| **[I]** | **INFERENCE** | Probable consequence derived from analysis and ordinary organisational behaviour |
| **[P]** | **PROPOSAL** | Recommended here. **Not architecture.** Requires approval before it binds anyone |
| **[V]** | **REQUIRES VALIDATION** | Legal, employment, governance, accounting, privacy, safeguarding, safety or organisational-psychology advice required before adoption |
| **[X]** | **EXTERNAL FACT** | Published source outside the supplied architecture |
| **[X-inherited]** | External fact **already cited inside the stress test or v1.3-B/C** | Recorded for honesty; **not re-asserted here as independent evidence** |
| **[C]** | **CALCULATED** | Derived arithmetically from stated variables; carries no new factual content |
| **[M]** | **MODEL ASSUMPTION** | A value or coefficient that must be **measured**, never asserted |
| **[U]** | **UNRESOLVED — DO NOT INVENT** | The source hierarchy has not decided this, and this document refuses to decide it silently |

### Five rules that govern every page

**RULE 1 — No invented evidence.** No adoption rate, no retention percentage, no psychological statistic, no salary, no multiplier, no term length, no span-of-control ratio and no training-hour count is asserted anywhere in this document. Where a number would normally appear, a variable, a formula, a band or the phrase `UNKNOWN — MEASURE IN PILOT` appears instead. **[A]** This is not caution; it is the only way the document can be audited.

**RULE 2 — Preserve the unresolved.** Every UNRESOLVED / NOT FINAL / PROPOSED / REQUIRES FINAL APPROVAL / REQUIRES PROFESSIONAL VALIDATION item in v1.2, v1.3-A, v1.3-B and v1.3-C that touches leadership, performance or succession is carried forward into **Part 45** unchanged. **This document closes nothing that the source hierarchy left open.** In particular:

| Carried item | Source status | Where it reappears here |
|---|---|---|
| **CEO vs National Council authority** | `UNRESOLVED` **[S: Ch.33; Ch.4]** | Part 27, Part 34, Part 45 — **not resolved** |
| **Leader multiplier** | `NOT FINAL` **[S: Ch.33; App. A §15.3]** | Part 23, Part 39 — **no number proposed** |
| **Leaderboard weights 20/15/15/15/10/10/10/5** | `PROPOSED` **[S: Ch.25; Ch.33]** | Part 6, Part 7 — **preserved verbatim, not altered** |
| **Leadership transition rules** | `NOT FINAL` **[S: Ch.33]** | Part 10, Part 11 |
| **Team readiness threshold** | `NOT FINAL` **[S: Ch.33]** | Part 3, Part 40 |
| **Minimum staffing thresholds** | `NOT FINAL` — "no final numbers invented" **[S: Ch.33]** | Part 26, Part 40 |
| **Serious misconduct procedure** | `PROPOSED` **[S: Ch.33]** | Part 18, Part 19 |
| **Legal structure under Krytos** | `UNRESOLVED` **[S: Ch.33]** | Part 27, Part 32 |
| **Worker classification** | `UNRESOLVED` **[S: Ch.33]** | Part 23, Part 39 |
| **Data retention** | `UNRESOLVED` **[S: Ch.33; S-A: A-17]** | Part 31 |
| **Whether the leaderboard should be public at all (R5)** | open reconsideration item **[S-ST: §25.3 R5]** | Part 21 — **left open** |
| **Council charter and authority (N19)** | `PROPOSED — REQUIRES FINAL APPROVAL` **[S-A: A-23]** | Part 34 |

**RULE 3 — No silent architectural change.** Where this document proposes a modification, it states the original principle, the problem discovered, the proposed change, the reason, the benefit, **the new risk created**, and the burden — in the L-series format of **Part 46**. Nothing is amended by implication.

**RULE 4 — Architecture completeness is not empirical proof.** The distinction `ARCHITECTURALLY SPECIFIED` versus `EMPIRICALLY VALIDATED` is applied throughout and is the basis of the verdict in **Part 52**. A system that can be drawn is not a system that works. **[A]** Every mechanism in this document that has not been observed operating on real people is marked as specified-but-unvalidated.

**RULE 5 — Do not design a leaderboard; design a leadership system.** This is the brief's absolute rule and it is enforced structurally: **Part 21** examines the existing leaderboard concept and its limits, and every ranking mechanism it retains is subordinated to a responsibility mechanism elsewhere in the document. Where a choice existed between making the measurement more sophisticated and making the succession more real, succession was chosen.

### Naming conventions

| Prefix | Meaning |
|---|---|
| **D-1 … D-135** | Operating rules issued inline across Parts 1–52 |
| **L-01 … L-40** | v1.3-D amendments, twenty fields each (Part 46, Annexure H). **Distinct from `A-nn`, `B-nn`, `H-nn`** |
| **LDR-C01… / LDR-U01… / LDR-01…** | Leadership Decision Register — carried, unresolved, newly proposed (Part 45, Annexure B) |
| **LC-1 … LC-20** | The twenty leadership capability dimensions (Part 4) |
| **LE-1 … LE-5** | The five evidence classes (Part 5) |
| **O-1 … O-3 / W-1 … W-3 / CN-1 … CN-7** | Performance-model options considered; weighting options; cohort normalisation instruments (Parts 6, 9) |
| **W-A … W-D / AC-1 … AC-5** | The four outcome windows; the activity cap (Part 8) |
| **PG-1 … PG-12 / BD-1 … BD-4** | Performance hard gates; team-performance boundary rules (Part 7) |
| **LG-1 … LG-10, LG-X / PT-1 … PT-9** | Promotion readiness gates; promotion transition steps (Part 10) |
| **SS-0 … SS-5 / SD-1 … SD-6 / UC-1 … UC-5** | Succession states; admissible successor-development forms; unintended consequences (Part 11) |
| **TL-1 … TL-5 / KT-1 … KT-10 / E-1 … E-7** | Temporary-leadership instruments; handover artifacts; layer-explosion modes (Part 12, Part 14) |
| **SP-1 … SP-6 / SI-1 … SI-6** | Specialist-track stages, extending **[S-C: H-11 S1…S6]**; status-inflation risks (Part 13) |
| **PL-0 … PL-6 / XG-1 … XG-8 / D-team…D-city** | Pipeline stages; expansion gate; density measures (Part 14) |
| **DV-1 … DV-5 / AF-C1 … AF-C12** | Development components; authority capabilities (Part 15) |
| **RV-1 … RV-4 / F-360a-c** | Review types; the three decomposed 360 instruments (Part 17) |
| **CR-1 … CR-4 / IP-1 … IP-7 / RM-1 … RM-10** | Complaint routes; improvement steps; removal steps (Part 18) |
| **SD-a … SD-e / T-1 … T-6** | Succession-dimension components; teaching obligations (Part 19) |
| **GF-1 … GF-30** | Gaming failure modes (Part 20) |
| **LF-1 … LF-4** | Leaderboard-fatigue mechanisms (Part 21) — **distinct from LF-01…LF-30 below** |
| **BN-1 … BN-9 / DF-1 … DF-3 / LLI** | Burnout signals; distribution failures; Leadership Load Index (Part 24) |
| **OB-1 … OB-7 / AX-1 … AX-9** | Opportunity access barriers; system accessibility requirements (Part 25) |
| **PB-1 … PB-10 / M1 … M7** | Playbook sections; the source's memory instruments **[S-A: A-15]** (Part 28) |
| **TA-0 … TA-4 / TA-a … TA-h / SEC-1 … SEC-10** | Transition access phases, checklist and security threats (Part 29) |
| **AI-1 … AI-8** | AI fairness controls (Part 30) |
| **ML-1 … ML-8** | Cross-level leadership failure modes (Part 32) |
| **PR-1 … PR-6 / CU-1 … CU-10 / VG-1 … VG-6 / PC-1 … PC-8** | Public representation; cult resistance; anti-vigilante; anti-political controls (Parts 27, 36) |
| **CT-A … CT-C / LDI / DEP-C…DEP-L** | Continuity tests; Leadership Dependency Index and its bands (Part 38) |
| **EF-1 … EF-5 / EA-1 … EA-14 / CB-1 … CB-4** | Economic findings; economic audit; control-budget test (Parts 39, 40, 49) |
| **MVLS-1 … MVLS-12 / MAT-0 … MAT-5** | Minimum viable leadership system; maturity levels (Part 40) |
| **PS-1 … PS-12 / PF-1 … PF-10 / B-P-01 … B-P-14** | Pilot success and failure conditions; **[S-B: §40]** pilot measurements (Part 41) |
| **P-01 … P-20** | **Performance adversarial simulations (Part 42) — numbering mandated by the brief. Disambiguated from `B-P-nn` by Rule D-129** |
| **Scenario A … Scenario L** | Succession simulations (Part 42) — numbering mandated by the brief |
| **ATK-01 … ATK-20 / LF-01 … LF-30** | Red-team attacks; leadership failure-mode register (Part 43, Annexure D) |
| **LM-1 … LM-15** | The fifteen leadership measurements (Part 44, Annexure I) |
| **C-D-01 … C-D-20** | Contradiction audit items (Part 47) — numbering mandated by the brief |
| **INV-1 … INV-20 / ADAPT-1 … ADAPT-12** | Invariants; locally adaptable items (Part 51) |
| **LV-1 … LV-25** | Professional validation register (Annexure C) |
| **OQ-01 … OQ-22** | Open questions this document refuses to answer (Annexure J) |
| **F-01 … F-36** | Failure modes from the stress test — **cited, never renumbered** |
| **M1 … M23, R1 … R5** | Stress-test modification and reconsideration items — **cited, never renumbered** |

### Three separations maintained throughout

1. **PERFORMANCE vs. LEADERSHIP.** A score describes what a team produced inside a window under a set of conditions. Leadership describes what a person can be trusted with. Part 1 establishes that these are different objects, and every subsequent part is built on the separation. **[A]** Collapsing them is the single most common design error in performance-managed volunteer organisations.
2. **AUTHORITY vs. STANDING.** Responsibility, authority, compensation, credential, recognition and appreciation are six different instruments **[S-C: §23.1 H-08]**. Part 22 keeps them separate; Part 13 provides the paths that do not require authority.
3. **ARCHITECTURE vs. EVIDENCE.** What this document specifies is not what the organisation has. Every mechanism carries a status: `SPECIFIED — UNVALIDATED` until the pilot (Part 41) observes it working.

### The absolute rule applied to this pack

> **Do not design a perfect leader. Design an organisation that remains healthy when leaders are imperfect.**

**[A]** This is the operative constraint on every proposal below. A mechanism that only works when the person holding it is honest, tireless, self-aware and unambitious is not a mechanism; it is a hope. Every instrument in this document is therefore tested against the question: *what happens when the person in this role is ordinary, tired, ambitious, popular, wrong, or gone?*

---

# EXECUTIVE SUMMARY

## ES.1 The finding in one paragraph

**[A]** The existing architecture contains a **complete and coherent theory of earned leadership** — "Leadership is earned through performance" **[S: Const. Art.4, APPROVED ARCHITECTURE]**; "give greater responsibility only to those who have earned greater trust" **[S: Const. Art.2]**; "Not status-based — Leadership is earned through evidence, trust, performance, safety and conduct" **[S: Ch.2]**; a per-role `Succession` column for all four levels **[S: Ch.9]**; a `succession_status` database field with "ready/acting/nominated status and succession pathway" **[S: Ch.22]**; a Primary → Sub-Role → Coordinator → Supporting Member ladder with explicit, recorded, RBAC-limited, reviewed delegation **[S: Ch.10]**; a 13-step vacancy lifecycle with an eligibility engine **[S: Ch.11]**; a support-first failure-recovery loop **[S: Ch.14]**; an eight-dimension multidimensional score with eight anti-gaming controls **[S: Ch.25, App. A §18]**; and a dynamic-leadership transition with eligibility gates, tie-breaks, correction windows, appeals and voiding rules **[S: Ch.26, Const. Art.15]**.

**[A]** What it does not contain is a **theory of the person**. The architecture can tell you which team scored highest, who is eligible, who holds which permission and what happens when a role is vacant. It cannot tell you: whether the highest-scoring team's leader is *capable of the next level*; whether the score is *comparable* across contexts; whether the promotion *destroyed the team that earned it*; whether the leader has *a successor*; whether the leader is *exhausted*; whether the leader is *dependent on their own indispensability*; whether an *unpopular but competent* person can ever be selected; or whether the whole ladder is *a lottery whose expected value drives the best people out* **[S-ST: F-24]**. **v1.3-D exists to supply that missing half — and to stress-test the half that already exists.**

## ES.2 The central diagnosis

**[A]** Five structural faults, each traced to source:

| # | Fault | Mechanism | Source anchor |
|---|---|---|---|
| **1** | **The reward architecture is a tournament with a scarce prize, and tournaments with scarce prizes produce adverse selection** | Best Mohalla Team → City Head Team → State Head Team → National opportunity **[S: Ch.26; Const. Art.15]**. In a network of *N* teams there is one Head Team per layer. With promotion as the only visible advancement, expected positional value falls toward zero as *N* rises, and the most capable people leave first | **[S-ST: F-24 HIGH]**; **[S-B: §24.5]** "leader supply is a *stock* problem" |
| **2** | **Success is taxed by success** | The promoted leader removes decision capacity, relationships, tacit knowledge and credibility from the team that produced the score — so the score falls, and the leaderboard rewards the team that was *not* promoted | **[S-B: §24.2]** "a success tax on success"; **[S-ST: Finding 5]** |
| **3** | **Comparison is structurally unfair and the unfairness is inherited, not earned** | Eight weighted dimensions with no baseline normalisation, no peer cohort, no difficulty adjustment and no maturity band — with a prize attached. A 20-member team in a low-demand locality and a 200-member team in a high-demand one are ranked on one board | **[S-ST: F-19 HIGH]**; **[S-B: §26.5]** `K_min` rises exactly where formation capacity falls |
| **4** | **The measurement window is shorter than the outcome window** | "Performance is monthly and multidimensional" **[S: Const. Art.14, APPROVED]** while outcomes take months to years. The architecture already knows this — "do not count planned activities as completed impact" **[S: Ch.15]** — but retains a monthly engine that creates precisely the pressure the rule forbids | **[S-ST: F-20 HIGH]** |
| **5** | **Succession is specified as a *pathway* and not as a *state*** | The `Succession` column says "Sub-Leader → Team Leader → higher level" **[S: Ch.9]** and `succession_status` has ready/acting/nominated values **[S: Ch.22]** — but no rule requires a successor to *exist*, no rule measures whether one does, and no rule prevents a leader from blocking one. v1.3-A built apex succession (S1–S8) **[S-A: A-14]** and v1.3-B proposed successor-before-transition **[S-B: B-18]**; neither is yet a standing obligation with a measured state | **[S-A: A-16 test 4 — the successor test]**; **[S-B: §24.4]** |

**[I]** Together these produce the failure the stress test named: **an organisation that is unusually strong as a control system and unusually weak as a people system — and whose leadership system is the exact point where the two weaknesses meet.**

## ES.3 What this instrument builds

**[P]** Fifty-two parts, ten annexures, **135 operating rules (D-1…D-135)**, twenty invariants and **40 separately mergeable amendments (L-01…L-40)**. **The amendment count is a consequence of the Part count, not a target.** The load-bearing ones:

| Amendment | One-line content | Answers | Part |
|---|---|---|---|
| **L-01** | **Eligibility ≠ Readiness** — two gates, separately evidenced, decided, recorded and appealed; Gate R assessed **out of team** | Why a promotion can be legitimate and still be wrong | 3 |
| **L-02** | **The twenty-dimension Leadership Capability Model (LC-1…LC-20)** with GATED / SCORED / MONITORED / NARRATIVE treatment rather than one composite — **seven of the twenty are invisible to the existing team score** | How capability is assessed without reducing a person to a number | 4 |
| **L-03** | **The five-class Evidence Model (LE-1…LE-5)** — decision, verified task, behaviour, trust, leadership-development — with an admissibility rule per decision type, nine prohibited evidence types and a self-assembled portfolio | What may legitimately be used to promote someone | 5 |
| **L-04** | **Performance Gate Architecture (PG-1…PG-12)** — hard gates that void *status*, never payment and never dignity | How a high score can be refused | 7 |
| **L-05** | **Four outcome windows** (activity, outcome, sustainability, correction), two-speed scoring, an activity cap, a confidence attribute and **honesty of failure reporting scored** | F-20 | 8 |
| **L-06** | **Cohort Normalisation (CN-1…CN-7)** — cohorts assigned from records, never elected; raw and normalised views both retained | F-19 | 9 |
| **L-07** | **Baselines locked once recorded**, maturity bands and provisional status with a hard expiry on newness | How a new team is neither punished nor permanently excused | 8, 9 |
| **L-08** | **Succession State Model (SS-0…SS-5)** — every covered role carries a *state*, not a pathway; mandatory state by role class; SS-0 is a reported organisational risk | F-11, **[S-A: A-16 test 4]**, **[S-B: B-18]** | 11 |
| **L-09** | **Promotion Transition Protocol (PT-1…PT-9)** — successor-before-transition, bounded overlap, bounded mentorship, promotion-cohort reporting, a Promotion Decision Record, eight tie-breaks and a prohibited-tie-break list | F-24, **[S-B: §24.2]** | 10 |
| **L-10** | **Temporary Leadership Instruments (TL-1…TL-5)** — Acting, Interim, Emergency, Delegated, Permanent — each with scope, start, end condition, authority limit and review; **all expire; reserved matters excluded absolutely** | **[S-B: B-19]**, **[S-A: A-14]** applied at every level | 12 |
| **L-11** | **Triple career architecture** — Leadership, Specialist (SP-1…SP-6 with authority ceilings) and Builder, plus the Contributor endpoint and Elder/Mentor standing, under an explicit no-track-superiority rule | F-24, **[S-C: H-11, §8.2]** | 13 |
| **L-12** | **Development Programme (DV-1…DV-5)** including the new **Authority Formation** component with twelve capabilities AF-C1…AF-C12 and demonstration methods; apprenticeship rules; **mentorship as paid work** | How the next generation is produced — **no hour counts invented** | 15 |
| **L-13** | **Four review types (RV-1…RV-4), never merged**; reviewer independence; skip-level; and **360 feedback rejected as a scored instrument and adopted as three decomposed ones** | How leaders are reviewed without creating a popularity market | 17 |
| **L-14** | **Succession as a scored dimension of leadership performance** — coverage as a gate, readiness and exercised delegation assessed at RV-3, **with no new weight added to the PROPOSED source weighting** | Why replaceability is a duty and not a virtue | 19 |
| **L-15** | **Leadership Compensation Structure** — leadership work itemised and paid, allocation bounded and capped, delivery paid separately, **no premium for indispensability**. **No multiplier proposed** | **[S: App. A §15.3]** made auditable | 23 |
| **L-16** | **Role Playbook (PB-1…PB-10), tested not filed**, plus relational memory captured at transition with consent and minimisation | The economic substitute for a third redundant person | 28 |
| **L-17** | **Transition Access Protocol (TA-0…TA-4, TA-a…TA-h)** — no overlapping write authority, bounded advisory access, suspended and removed holders hold nothing, sealed audit log | The highest-risk window in any access system | 29 |
| **L-18** | **Anti-gaming register (GF-1…GF-30)**, the **Goodhart Prohibition List**, and the **two-independent-signal rule** | What may never become a target | 20 |
| **L-19** | **Cult Resistance Controls (CU-1…CU-10)** — no person as organisational identity, no loyalty object, attribution discipline, dissent counted, replaceability as a duty, **the founder bound** | How affection is prevented from becoming unaccountable authority | 36 |
| **L-20** | **Continuity Testing (CT-A/B/C)** — delegation exercise, playbook exercise, unannounced 72-hour test; **unexercised counts as absent**; a failure is a governance finding, not a person finding | False continuity | 38 |
| **L-21** | **Minimum Viable Leadership System (MVLS-1…MVLS-12)** — non-deferrable at any stage; everything else tiered; a deferral is a recorded risk | The smallest leadership system that can safely run one mohalla | 40 |
| **L-22** | **Pipeline (PL-0…PL-6) and Expansion Gate (XG-1…XG-8)** — density reported but never publicly targeted; span basis declared; **expansion recorded as a cost** | Growth that does not hollow out the organisation that grows | 14 |
| **L-23** | **Complaints, appeals, improvement and removal (CR-1…CR-4, IP-1…IP-7, RM-1…RM-10)** — four routes that may never be substituted for one another; non-retaliation with the burden reversed; **no removal from a score** | F-21, F-22, F-23 | 18 |
| **L-24** | **Leaderboard scope and recognition–authority separation** — permitted and prohibited uses enumerated; fatigue mechanisms; measurement retirement; **recognition confers nothing**; **R5 left open** | F-19, F-33, R5 | 21, 22 |
| **L-25** | **Load and Dependency Indices (LLI, LDI)** as *organisational resilience* measures in bands, **never as personal scores**; `H_unrecorded` as the primary overload signal | Overload and dependency felt but never measured | 24, 38 |
| **L-26** | **AI-assisted leadership boundary** — permitted and prohibited function table, AI-1…AI-8 fairness controls, the stranger test for explainability, **historical bias never used as prediction labels** | F-29, **[S-A: A-21, A-22]** | 30 |
| **L-27** | **Opportunity fairness and access (OB-1…OB-7, AX-1…AX-9)** — access corrections are not favouritism; a mandatory specific feedback obligation to every non-selected applicant; the four-affordance route for the unpopular competent person | Why eligibility on paper is unequal in practice | 25 |
| **L-28** | **Staffing, span and function routing** — `n_min` as a five-condition set with **no number invented**; held-versus-routed; **the City divisor must be measured before State formation** | Minimum staffing is `NOT FINAL` in the source | 26 |
| **L-29** | **Founder concentration and institutional independence** — Founder Recusal Register, the founder may not assess, the four annual tests applied with counts published internally, interim reserved-matter procedure | F-14, F-15 | 27 |
| **L-30** | **Privacy and data classification for leadership records** — every new data type classified, small-cell suppression with suppression itself reported, the six-condition social-credit test | No universal human score | 31 |
| **L-31** | **Multi-level leadership differentiation** — per-level evidence, capability and assessment-independence obligations; staged obligations S0…S5; **a deferred control is a recorded risk** | One model cannot serve four levels | 32 |
| **L-32** | **Selection typology and democracy of voice** — five acts distinguished; act typing recorded with ambiguity resolved to the least consequential type; **strong voice rights, deliberately weak selection rights** | Democracy versus efficiency | 33 |
| **L-33** | **Governance bodies, RACI and the interim reserved-matter procedure** — authority map with every unresolved point marked; five bodies retained and **five refused**; CEO-vs-Council **not resolved** | Seven reserved matters with no determined holder | 34 |
| **L-34** | **Conflict of interest and anti-favouritism** — declaration before participation; recusal on the matter, not removal from the role; **recusal is not suspicion**; opportunity-allocation recording | The favouritism that leaves no record | 35 |
| **L-35** | **Anti-capture controls** — no compensation may depend on another person's participation; VG-1…VG-6 anti-vigilante; PC-1…PC-8 anti-political, **preserving members' civic rights** | MLM, vigilante and political capture | 36 |
| **L-36** | **Crisis leadership and incident review** — **standards are not suspended in a crisis, only sequence**; a mandatory missing-information field; blameless by default and accountable by record | Hindsight bias as an institutional selection pressure | 37 |
| **L-37** | **Leadership economics and feasibility** — an eighteen-component cost structure, five findings, six sustainability tests, and **unpaid leadership work recorded as an organisational deficit** | There is no revenue line for governance or training | 39 |
| **L-38** | **Maturity model (MAT-0…MAT-5)** determined by what a unit actually operates, plus the **simplification obligation**: one retirement for every addition | Obligation grows monotonically in every governance system | 40 |
| **L-39** | **Pilot integration and scope statement** — LM-1…LM-15 added to the **single shared pilot**; twelve falsifiable success conditions; ten fatal failure conditions; **seven explicit limits on what the pilot can prove** | No second pilot may be created | 41 |
| **L-40** | **Leadership invariants (INV-1…INV-20), local adaptation (ADAPT-1…ADAPT-12) and the final architecture** — four interlocking loops and one master data flow | What may never vary, and what may | 51 |

**Full twenty-field register at Part 46. Merge waves at §46.4.**

## ES.4 The verdict, stated in advance

> # **D — LEADERSHIP SYSTEM NOT YET PROVEN**
> ### with a defined, testable path to **B — LEADERSHIP SYSTEM VIABLE WITH TESTING**

**[A]** The reasoning is given in full in **Part 52**. In summary: the architecture is **not** deficient in concept — **[S: Const. Art.4]**, **[S: Ch.25]**, **[S: Ch.26]**, **[S: Ch.9]**, **[S: Ch.10]**, **[S: Ch.11]** and **[S: Ch.14]** together are a better starting point than most organisations of any size possess, and **C — REQUIRES MAJOR REDESIGN** would be dishonest. But **A** and **B** are unavailable, because:

| Requirement for B | Status today |
|---|---|
| Cohort definitions exist and are objective | ❌ none exist **[S-ST: F-19]** |
| Two-speed scoring decided and implemented | ❌ **Const. Art.14** says monthly; weights `PROPOSED`; **[S-ST: M8]** unadopted |
| Successor state recorded for every covered role | ❌ field exists **[S: Ch.22]**; no obligation, no measurement, no report |
| Promotion transition protocol exists | ❌ **[S-B: B-18]** proposed, unadopted |
| Specialist track exists with real scope and real pay expression | ❌ **[S-C: H-11]** proposed, unadopted |
| Independent complaint route exists | ❌ **[S-ST: M10]**, **[S-A]**, **[S-C: CK-1]** all proposed, none operational |
| Leadership workload measured | ❌ `H_lead` coefficient is **[M]** — unknown **[S-B: §25.1]** |
| Any of it observed working on real people | ❌ nothing has been |

**[A] Eight requirements, zero satisfied.** The same arithmetic that produced **D** in v1.3-B and **D** in v1.3-C produces **D** here, for the same underlying reason: **the organisation has designed four interlocking systems and has not yet operated one team.**

## ES.5 The single biggest unresolved weakness — stated without softening

> **[A] Sewak Sathi's leadership system has no theory of the *unpopular competent person*, and no theory of the *popular incompetent person* — and therefore, as specified, it will systematically select the second over the first.**

**[A]** Every selection signal the architecture currently produces is **socially mediated**: the score depends on evidence the team itself generates and the City reviews **[S: Ch.25 reviewer column]**; the transition depends on "evidence review, tie-breaks, correction window, appeals" **[S: Ch.26]**; the vacancy depends on interview and assessment **[S: Ch.11 step 7]**; the community-trust dimension depends on "verified feedback" **[S: Ch.25]**; and the promotion decision at leadership level sits with "Team Leader + HR" co-reviewed by the "City/State role owner" **[S: App. E — Role promotion row]**. **[I]** In a neighbourhood organisation where the selectors, the selected and the reviewers are socially embedded in one another **[S-ST: F-23, F-26]**, every one of those signals is contaminated by likability, proximity, articulateness and caste/class/language fluency — none of which is capability.

**[A]** The architecture *forbids* the crude versions of this bias — "Raw revenue, follower count, social-media views, volunteer count, application count or raw activity count cannot determine leadership" **[S: Ch.25]** — but forbidding the crude proxies does not remove the subtle one. **What is missing is an instrument that produces capability evidence *independently of the candidate's social position*: an out-of-team assessor, a blind evidence portfolio, a structured scenario assessment, a recorded decision with reasons that can be appealed on capability grounds, and a dissent route that does not pass through the person being assessed** **[S-ST: M9, M10; S-C: CK-1]**.

**[A]** Until that instrument exists and has been observed working, the honest statement is: **the leadership system will reproduce the social hierarchy of the locality it operates in, and will call the result "earned".** That is the weakness. It is not fixable by weights, formulas or dashboards. It is fixable only by independence — and independence costs people, which is why **Part 39** and **Part 40** must be read together with this paragraph.

## ES.6 What this instrument refuses to do

| Refusal | Reason |
|---|---|
| **Name, imply, rank or hint at any successor to any role, including the founder** | **[S-A: A-14]** established the rule; this document observes it absolutely |
| **Resolve the CEO-vs-National-Council authority question** | `UNRESOLVED` **[S: Ch.33]**. Part 27 and Part 34 specify the *mechanism* that works under either resolution, and Part 45 carries the question forward |
| **Invent a leader multiplier, a term length, a span-of-control ratio, a training-hour count, a certification fee or any rupee value** | **[S: App. A §15.3]** "This document does not invent the exact multiplier"; **[S: Ch.33]** "no final numbers invented"; **[S-B]** discipline |
| **Alter the proposed performance weights 20/15/15/15/10/10/10/5** | `PROPOSED — FINAL WEIGHTS REQUIRE APPROVAL` **[S: Ch.25]**. Part 7 *tests* weighting models and proposes treatment classes; it does not renumber them |
| **Alter the financial waterfall priority order** | **[S: Ch.18]**; a reserved matter under **[S-A: A-13/A-14]** |
| **Resolve whether the leaderboard should be public (R5)** | Open **[S-ST: §25.3 R5; S-C: §44.4]**. Part 21 specifies what must be true under *either* answer |
| **Create a universal human score** | **[S-C: §24.2 CR-1…CR-4]**; Part 31 makes the prohibition explicit for leadership records |
| **Design an emotionally compelling leadership narrative** | The brief forbids turning doctrine into motivation. Part 2 defines philosophy as *constraints on authority*, not as inspiration |
| **Assume that the strongest worker, the most popular person, the highest-revenue leader, the largest team, the most active team, or a successful pilot proves anything about leadership** | The brief's §169. Each assumption is tested and, where it fails, the failure mechanism is shown |

## ES.7 How to use this document

| If you are… | Read |
|---|---|
| The founder deciding what to approve first | **ES.3, Part 40, Part 41, Part 46 (Stage 1 items), Part 52** |
| The person who will run the pilot | **Part 40, Part 41, Part 44, Annexure I** |
| The person worried this becomes a bureaucracy | **Part 26, Part 40, Part 48** |
| The person worried about fairness | **Part 9, Part 33, Part 35, Part 50, ES.5** |
| The person worried about the founder | **Part 27, Part 34, Part 45 (LDR-C items)** |
| The person worried about cult dynamics | **Part 36, Part 22, Part 50** |
| The person who must merge this into v1.2 | **Part 46 (merge targets), Annexure A, Annexure H** |
| The person auditing this document | **Part 43, Part 47, Part 52, Annexure J** |

---

# PART 1 — THE LEADERSHIP PROBLEM

## 1.1 The thirty questions, and where each is answered

**[P]** The brief poses thirty questions. Each is answered at least once; several are answered more than once because they constrain more than one part. This table is the document's own completeness index.

| # | Question | Primary answer | Also constrains |
|---|---|---|---|
| **1** | What makes someone eligible to become a leader? | **Part 3** (eligibility gate) | Part 10 LG-1, Part 33 |
| **2** | What makes someone actually ready? | **Part 3** (readiness gate) | Part 4, Part 10 LG-2, Part 15 |
| **3** | What makes someone trustworthy? | **Part 5** (LE-4 trust evidence), **Part 35** | Part 2, Part 17, Part 18 |
| **4** | What makes someone capable? | **Part 4** (LC-1…LC-20) | Part 14, Part 16 |
| **5** | How should performance be measured? | **Part 6** | Part 7, Part 20, Part 39 |
| **6** | How should incomparable teams be compared? | **Part 9** | Part 21, Part 32 |
| **7** | How should performance windows differ from outcome windows? | **Part 8** | Part 6, Part 20 |
| **8** | How should leaders be promoted? | **Part 10** | Part 3, Part 9, Part 33 |
| **9** | How should specialists progress without becoming managers? | **Part 13** | Part 22, Part 39 |
| **10** | What happens when a leader fails? | **Part 19** | Part 17, Part 35, Part 42 |
| **11** | What happens when a leader leaves? | **Part 10** (dignified exit), **Part 12** | Part 28, Part 29 |
| **12** | Who becomes interim leader? | **Part 12** (TL-1…TL-5) | Part 29, Part 34 |
| **13** | How is succession prepared before failure? | **Part 11** (SS-0…SS-5) | Part 15, Part 38 |
| **14** | How do we prevent founder dependence? | **Part 27** | Part 34, Part 36, Part 38 |
| **15** | How do we prevent personality cults? | **Part 36** | Part 2, Part 22, Part 50 |
| **16** | How do we prevent leaderboard gaming? | **Part 20** | Part 6, Part 7, Part 21 |
| **17** | How do we prevent popularity contests? | **Part 17** (360 adversarial test), **Part 33**, **ES.5** | Part 9, Part 35 |
| **18** | How do we prevent revenue from dominating service? | **Part 7**, **Part 23** | Part 6, **[S: Ch.25 mission-impact 20%]** |
| **19** | How do we prevent service activity from becoming performative? | **Part 8** | Part 20, Part 21 |
| **20** | How do we prevent leaders from burning out? | **Part 25** | Part 24, Part 26 |
| **21** | How do we develop the next generation of leaders? | **Part 14** | Part 15, Part 16, Part 32 |
| **22** | How do we preserve the original team after promotion? | **Part 10** (L-09) | Part 11, Part 12, **[S-B: B-18]** |
| **23** | How do we handle disputes and appeals? | **Part 18** | Part 17, Part 19, **[S: Const. Art.17]** |
| **24** | How do we measure leadership at Mohalla, City, State and National? | **Part 32** | Part 6, Part 9, Annexure F |
| **25** | How does AI assist without becoming the decision-maker? | **Part 30** | Part 31, **[S: Const. Art.12]** |
| **26** | How does leadership remain economically sustainable? | **Part 39** | Part 23, Part 24, Part 49 |
| **27** | How does leadership remain human? | **Part 50** | Part 2, Part 13, Part 22, Part 25 |
| **28** | How does leadership remain accountable? | **Part 17, Part 29, Part 34** | Part 18, Part 35 |
| **29** | How does leadership remain replaceable? | **Part 11, Part 12, Part 38** | Part 26, Part 28 |
| **30** | How does the organisation remain functional when its best individual leaves? | **Part 38** (the resilience test) | Part 11, Part 12, Part 51 |

## 1.2 The central design problem, stated as a fault tree

**[S]** The existing idea, verbatim: **"teams perform → performance is measured → strong teams can advance → leaders can rise."** Concretely: "Performance-based leadership transition — Not automatic status; transition requires rules and approval" **[S: Ch.26 step 5]**; "Best Mohalla Team → City Head Team … Minimum eligibility, evidence review, tie-breaks, correction window, appeals, transition" **[S: Ch.26]**; "Leadership is earned through performance" **[S: Const. Art.4, APPROVED]**.

**[A]** The brief is right not to assume this is sufficient. The fault tree below shows **seven independent breaks** between "team performed well" and "this person should lead at the next level". Each break is a place where the inference can be false while every step of the source process is followed correctly.

```
TEAM PERFORMED WELL (measured)
   │
   ├─ BREAK 1 · MEASUREMENT VALIDITY
   │    Was the score honest?  [S: Ch.25 anti-gaming — 8 controls exist]
   │    Residual: gaming is controlled; fabrication of *difficulty* is not.  → Part 20
   │
   ├─ BREAK 2 · MEASUREMENT COMPARABILITY
   │    Is the score comparable to other teams' scores?
   │    [S-ST: F-19] — no cohort, no baseline, no difficulty adjustment.  → Part 9
   │
   ├─ BREAK 3 · MEASUREMENT HORIZON
   │    Does a monthly window measure anything that lasts?
   │    [S-ST: F-20]; [S: Const. Art.14 "monthly"].  → Part 8
   │
   ├─ BREAK 4 · TEAM → INDIVIDUAL ATTRIBUTION
   │    Did the *leader* cause the team's performance, or did the team carry
   │    the leader?  A high-scoring team may contain an unexamined leader.  → Part 5, Part 7
   │
   ├─ BREAK 5 · PERFORMANCE → CAPABILITY
   │    Does producing output at level X demonstrate capability at level X+1?
   │    The next level is a *different job*: coordination, governance, audit
   │    capacity, cross-team allocation, policy interpretation.  → Part 4, Part 32
   │
   ├─ BREAK 6 · CAPABILITY → TRUSTWORTHINESS
   │    A capable person may be dishonest, retaliatory, favouring, or
   │    dependent on their own indispensability.  → Part 5 (LE-4), Part 35
   │
   └─ BREAK 7 · APPOINTMENT → CONTINUITY
        Does the appointment leave the *originating* team able to function?
        [S-B: §24.2] "success tax on success".  → Part 10, Part 11, Part 12
```

**[A]** Breaks 1 and 7 are partially addressed by source and prior instruments. **Breaks 2, 3, 4, 5 and 6 are unaddressed anywhere in the 179-page source, and are the reason this instrument exists.**

**[I]** The practical consequence of leaving Break 5 unaddressed is the one most often observed in growing organisations: **the best Mohalla operator becomes the worst City head**, because City work is coordination, allocation, audit tolerance and conflict adjudication across teams that do not report to you socially — and none of those is exercised or measured by running one excellent neighbourhood team **[S: Ch.7 City responsibilities are materially different in kind, not only in scale]**. Part 32 and Part 33 address this; Part 42 Scenario G simulates it.

## 1.3 The six distinctions that must become architecture

**[P]** The brief states six inequalities. Each is converted below from a slogan into an instrument with a named owner, a record and a failure mode. **A distinction without an instrument is a poster.**

| Distinction | What it means operationally | The instrument that enforces it | Where the instrument lives | Failure mode if unenforced |
|---|---|---|---|---|
| **PERFORMANCE ≠ LEADERSHIP** | A score may *nominate* a candidate; it may never *appoint* one. Performance is an input to a decision that also requires capability, conduct, safety, governance, team-development, succession and human-decision approval | **LG-1…LG-10 promotion readiness gates**; a score alone satisfies only LG-5 | Part 10 | The #1 team's leader is appointed to a role they cannot perform, and both the new layer and the old team lose |
| **LEADERSHIP ≠ POPULARITY** | No dimension of assessment may be sourced solely from people the candidate can reward or punish; community feedback is *signal*, never *command*; 360 feedback carries seven protections | **Part 17 §17.5 (360 adversarial test)**; **Part 35 §35.4 (community trust as input)** | Parts 17, 35 | Selection converges on the most liked person; the unpopular competent person is permanently invisible — **ES.5** |
| **SENIORITY ≠ LEADERSHIP** | Tenure is an *eligibility floor* in some roles and is otherwise not a criterion; the Elder/Mentor standing carries respect without command and without score | **Part 3 §3.3**; **Part 13 §13.6** (Elder/Mentor, per **[S-C: §6.10]**) | Parts 3, 13 | Gerontocracy; capable younger members blocked; **[S-ST: M9]** "elder status becomes gerontocracy" |
| **REVENUE ≠ LEADERSHIP** | "Raw revenue … cannot determine leadership" **[S: Ch.25]**; business performance is one of eight dimensions at a proposed 15%; a revenue gate cannot be passed by revenue alone and a revenue failure cannot be excused by service volume | **Part 7 §7.4 (business dimension bounded)**; **Part 23 §23.4 (venture-leader evaluation)** | Parts 7, 23 | The organisation becomes an agency with a service department — **[S-ST: F-17]** |
| **ACTIVITY VOLUME ≠ IMPACT** | "do not count planned activities as completed impact" **[S: Ch.15]**; activity counts are capped in score contribution; outcome claims carry a follow-up obligation whose non-completion *reduces* score | **Part 8 §8.4 (activity cap)**; **Part 20 GF-1…GF-4** | Parts 8, 20 | Performative service; beautiful dashboards; a community that knows better — **[S-ST: F-20]** |
| **AI SCORE ≠ HUMAN WORTH** | "AI may recommend; humans decide. AI cannot autonomously make consequential HR, wage, legal, safeguarding, safety, major fund or **leadership** decisions" **[S: Const. Art.12, APPROVED ARCHITECTURE]**; no secret ranking; every consequential recommendation carries the 17-field audit record | **Part 30**; **[S-A: A-21 permitted/prohibited maps, A-22 audit record]** | Part 30 | Rubber-stamping — **[S-ST: F-29]**; a black-box authority nobody can appeal |

**[A]** Note the strength of the source position on the sixth distinction: **[S: Const. Art.12]** is **APPROVED ARCHITECTURE**, not proposed policy. **The prohibition on AI making leadership decisions is already binding in the source hierarchy and this document has no authority to relax it.** Everything in Part 30 is therefore *implementation* of an existing rule, not a new one.

## 1.4 What the stress test already found, carried forward unchanged

**[S-ST]** The findings below are cited, not restated in full. Each is the *diagnosis* that a part of this document must answer.

| Stress-test item | Finding | v1.3-D response |
|---|---|---|
| **F-03** | Nobody wants the unpopular control roles; prohibition without pipeline produces hidden non-compliance | Part 13 (specialist track with real scope), Part 14 (development), Part 23 (compensation), Part 26 (city-shared control roles) |
| **F-11** | Founder concentration without mission lock or succession — **CRITICAL** | Part 27, integrating **[S-A: A-13, A-14, A-16]** |
| **F-14** | National leadership disconnects from the ground; no downward immersion mechanism | Part 32 §32.4 (ML-6), Part 17 §17.4 (skip-level, Rule D-51), Part 34 |
| **F-15** | Leader multiplier perceived as self-dealing | Part 23 §23.3 (responsibility-linked, bounded, published-as-proposed, never self-approved) |
| **F-19** | Leaderboards compare incomparable contexts — **HIGH** | Part 9 in full |
| **F-20** | Outcome lag forces the metric toward visible activity — **HIGH** | Part 8 in full |
| **F-21** | No protected channel to report your own leader — **HIGH** | Part 18 §18.2 (independent intake) |
| **F-22** | Weaponised allegations against leading teams | Part 18 §18.6 (interim measures instead of automatic voiding) |
| **F-23** | Removal is socially expensive, so underperformance persists | Part 19 §19.6 (non-social status transitions; out-of-team review) |
| **F-24** | High performers exit because the ladder is a lottery — **HIGH** | Part 13, Part 22, Part 10 §10.7 |
| **F-26** | Verification performed by the same social network that produces the claim | Part 17 §17.4 (Rule D-50), Part 15 §15.3 (out-of-team assessment, Rule D-45) |
| **F-29** | AI review fatigue converts "humans decide" into rubber-stamping | Part 30 §30.6 |
| **F-33** | Recognition becomes status; status becomes hierarchy; hierarchy becomes politics | Part 22, Part 21, **[S-C: §44]** |
| **M8** | Normalise and slow the performance system | Part 8, Part 9 — implemented as **L-05, L-06** |
| **M9** | Successor-before-transition and a horizontal ladder | Part 10, Part 13 — implemented as **L-09, L-11** |
| **M10** | Integrity Line and independent ombuds | Part 18 — implemented as **L-16** |
| **R5** | Whether the leaderboard should be public at all | Part 21 — **left open**, with the requirements under either answer specified |
| **§23.1 stage model** | Leadership is **○ informal at S0, ◐ at S1–S2, ● only from S3**; the binding constraint at S1 is "trained leaders and control-role holders (3 per team)" | Part 40 (MVLS), Part 32 (scale), Part 41 (pilot) |

## 1.5 What the prior instruments already decided, and what v1.3-D may not undo

**[A]** This is the compatibility contract. **v1.3-D must not create leadership obligations that contradict v1.3-B, and must not weaken any human-system protection in v1.3-C.**

| Constraint | Source | Effect on v1.3-D |
|---|---|---|
| **Leadership work has no revenue line** | **[S-B: §8.4]** — the waterfall funds venture work only; service, governance and training have no funding source | **Part 39**: every leadership duty must be assigned a funder or explicitly costed as volunteer burden. No mechanism may assume paid leadership capacity that the waterfall cannot produce |
| **Governance hours are subtracted *first* from the same pool as delivery and sales** | **[S-B: §17.2]** `H_deliver = H_pool − H_gov − H_svc − H_acq − H_train − H_idle` | **Part 24, Part 40**: any new leadership record, meeting, review or form increases `H_gov` and reduces `H_deliver`. Every L-series amendment carries a governance-burden field for this reason |
| **`σ_max` is derived, not chosen** | **[S-B: §26.1]** `σ_max = 1 − (H_deliver_required + H_svc_budget + H_acq_required + H_train_required)/(N_act × T_avail)` | **Part 40**: the leadership system's total burden must fit inside a ceiling the team's own economics set. If it does not fit, mechanisms must be removed, not people added |
| **Minimum viable control is eleven items** | **[S-B: §26.2 MVC-1…MVC-11]**; a control is in the minimum set **iff** its absence causes irreversible harm to money, safety, identity, privacy or public truth | **Part 40**: MVLS is derived by applying the same criterion to leadership. Anything else graduates in with maturity |
| **Control-budget rule** | **[S-B: §26.3]** any new mandatory record requires either automation or the retirement of an existing one; **"if an economic control cannot be automated from data the team already produces, it is not adopted at Stage 0–2"** | **Part 46**: every L-series amendment states whether it is automated from existing data. Those that are not, are not adopted at Stage 0–2 |
| **The nine functions cannot be removed by smallness** | **[S: Ch.10 State A]** "Small size never removes safety, HR verification, finance integrity or evidence duties" | **Part 40**: MVLS may reduce *instrument count* and *cadence*, never the four irreducible duties |
| **A sub-role is delegated operational authority, not automatic transfer of the primary role's full authority** | **[S: Ch.10]** verbatim | **Part 12**: every temporary-leadership instrument preserves this exactly |
| **One role → one primary holder; one designated sub-role holder where appropriate** | **[S: Ch.22]** software rule; "Multiple coordinators may exist only under defined workstreams, not as duplicate primary leaders" | **Part 26**: distributed leadership may not create duplicate primaries |
| **No forced progression; six legitimate endpoints; seven refusal rights** | **[S-C: H-07, §8.2, §8.3 H-17]** | **Parts 3, 10, 13, 25**: a person may refuse promotion, refuse leadership permanently, and be recorded as "not available for leadership" so they are not asked repeatedly |
| **Levels 0–4 are not ranked publicly; recognition below L5 is narrative, never ordinal** | **[S-C: §6.11 rule 3, §7.3 SR-2/SR-3]** | **Part 21, Part 22**: no leadership instrument may rank, badge or ordinalise anyone below L5 |
| **Six recognition instruments must never be collapsed into one leaderboard** | **[S-C: §23.1 H-08]** | **Part 22**: appreciation, proof, credential, responsibility, compensation and promotion remain separate systems with separate records |
| **The contribution record may never determine dignity, community access, personal worth, or external eligibility** | **[S-C: §24.2 CR-1…CR-4]** | **Part 31**: leadership and performance records inherit the same prohibition absolutely |
| **No compensation, benefit or eligibility may be calculated from any count of people** | **[S-C: §22.3 MLM-1…MLM-7]** | **Part 10, Part 13, Part 23**: team size may not create authority, income or eligibility. Verified against **Part 43** |
| **Elder/Mentor standing is excluded from RBAC command permissions and from scoring** | **[S-C: §6.10]** | **Part 13 §13.6**: advisory authority only, permanently |
| **AI may recommend; humans decide** | **[S: Const. Art.12 APPROVED]**; **[S-A: A-21, A-22]** | **Part 30**: implementation only; the prohibited list is preserved verbatim |
| **Political neutrality: no belief screening ever; nine organisational prohibitions** | **[S-A: A-01 N1…N9, A-02]** | **Part 35 §35.3, Part 36 §36.5**: leadership selection may not screen, infer or record belief or political identity |
| **Reserved matters may not be decided by an acting or interim authority** | **[S-A: A-14 §13.3 item 3]** | **Part 12, Part 27**: the reserved list applies at every level, not only the apex |
| **Protection may never become private enforcement authority** | **[S-A: A-08 entrenched DO-NOTs]**; **[S: Const. Art.9 APPROVED]** | **Part 36 §36.4**: protection leadership carries *additional* constraint, never additional power |

**[A]** Every one of the eighteen rows above is a **hard constraint on this document**, not a reference. Where a proposal in Parts 2–51 would breach one, the proposal is either modified or withdrawn, and the conflict is recorded in **Part 47**.

## 1.6 What "leadership system" means here — and what it does not

**[P]** Definition adopted for this instrument:

> A **leadership system** is the complete set of instruments by which an organisation (a) decides what leadership *is*, (b) discovers who can hold it, (c) prepares them, (d) delegates authority to them within stated limits, (e) observes how they use it, (f) corrects them when they misuse or underuse it, (g) replaces them when they leave or fail, and (h) remembers what it learned — **such that the loss of any one person is an inconvenience rather than an ending.**

**[A]** Clause (h) is the one most often omitted and it is the clause the brief's final objective turns on: *"without requiring a single irreplaceable person."* **[S-A: A-16 §15.3 test 1]** already states the standard — "If the founder were unavailable for twelve months, would an external observer notice a difference in what the organisation does? Target: no." **v1.3-D generalises that test from the founder to every covered role** (Part 38).

**[P]** What a leadership system is **not**:

| Not this | Because |
|---|---|
| A ranking | Ranking is a *measurement* instrument with a fixed supply. Leadership is a *responsibility* instrument with a supply set by need. **[S-C: §44.3]** "six of seven [recognition instruments] are absolute rather than comparative" |
| A reward | "Serve without expecting reward" **[S: Const. Art.2 APPROVED]**. Leadership carries **more** accountability, **more** compliance load **[S-B: §25.5]**, **more** scrutiny and **more** obligation to develop successors — and it may carry no additional money at all if the multiplier is never approved |
| A career | For most people it is a *period of service*. Part 13 exists so that a full, complete, respected organisational life can be lived without ever holding command |
| A status | "Not status-based" **[S: Ch.2]**. Part 2 §2.4 lists the eleven things leadership must never mean |
| An assessment of a person | **[S-C: §23.2 H-08]**: the performance system scores **teams**, never individuals, and is not applied to endpoints |
| A personality | **[S-A: A-16 §15.4]**: decisions are announced in the organisation's name with the deciding *role* identified; no portrait display; no founder-attribution requirement |

## 1.7 The one structural fact that shapes everything below

**[S-ST: §23.1]** The stress test's stage model places **Leadership** at **○ informal** in stage S0 (one team, 8–15 people), **◐ defined process** at S1 (5–15 teams) and S2 (50–300 teams), and **● institutional function** only from S3 (1k–10k teams). It also states the binding constraint at S1 as **"trained leaders and control-role holders (3 per team: HR/Funds/Safety)"**, and its kill condition as **"teams recognised before leaders are trained (F-25)"**.

**[A]** Three consequences follow, and they govern the whole of this document:

1. **The leadership system must be buildable by one team, manually, without software, without budget and without a governance layer.** If it cannot, it will not exist at S0–S1, which is when leadership failures are most damaging and least recoverable. **Part 40 (MVLS)** is therefore not an appendix to this instrument; it is its first deliverable.
2. **The leadership system must be *graduated*, not switched on.** A mechanism appropriate to 10,000 teams is a crushing burden on one. **[S-B: §26.2]** established the criterion — irreducibility — and Part 40 applies it to leadership.
3. **Leader supply is the binding constraint on growth, and growth decisions must be made against it, not against population.** **[S-B: §24.5]**: "plan team formation against leader supply, not against population … `N_leaders_available / leaders_per_team`." **Part 14 §14.7** makes this the expansion gate (XG-1…XG-8).

> **[I] The uncomfortable corollary:** an organisation that forms teams faster than it produces trusted leaders does not have a leadership *problem*; it has a leadership *deficit that it has chosen*. The architecture already forbids inventing minimum staffing numbers **[S: Ch.33]** — but it does not forbid forming a team whose control roles are vacant, and **[S-ST: F-25]** identifies exactly that as a kill condition. **Part 32's expansion gate is the correction.**

---

# PART 2 — LEADERSHIP PHILOSOPHY

## 2.1 What the source already says, verbatim

**[S]** The philosophy is not absent from v1.2. It is present, approved, and unusually clear:

| Source | Verbatim content | Status |
|---|---|---|
| **Const. Art.2 — Values** | "give **greater responsibility only to those who have earned greater trust**" | **APPROVED ARCHITECTURE** |
| **Const. Art.2 — Values** | "serve **without expecting reward**" | **APPROVED ARCHITECTURE** |
| **Const. Art.2 — Values** | "use **strength with discipline**" | **APPROVED ARCHITECTURE** |
| **Const. Art.4 — Leadership** | "**Leadership is earned through performance.**" | **APPROVED ARCHITECTURE** |
| **Const. Art.4 — Leadership** | "Leadership changes require eligibility checks, evidence review, appeals and transition safeguards." | PROPOSED POLICY |
| **Const. Art.7 — Responsibilities** | "**Greater responsibility requires greater trust.**" | **APPROVED ARCHITECTURE** |
| **Ch.2 — Principles** | "**Not status-based** — Leadership is earned through evidence, trust, performance, safety and conduct." | **[S]** |
| **Ch.2 — Principle table** | "**Earn greater responsibility** — Authority follows verified work, conduct, financial integrity, safety compliance and community trust." | **[S]** |
| **Ch.2 — Principle table** | "**Not micromanaged** — Central standards preserve mission and integrity while mature teams keep local autonomy." | **[S]** |
| **Ch.23 — Purpose** | "Make permission boundaries clear: **title does not equal unlimited access.**" | **[S]** |
| **Ch.9 — Role boundaries** | Team Leader "**Cannot** bypass verification, spend outside limits, hide incidents, **punish people** or change pay rules." | **[S]** |
| **App. A §15.3** | A leader differential "must be **transparent, capped or bounded** where appropriate, and **justified by verified leadership work rather than status alone**." | **[S]** |
| **App. A §16.1** | "**Autonomy is earned freedom inside central standards.**" | **[S]** |

**[A]** Read together, these produce a coherent doctrine that is *already approved at constitutional level*: **authority is a consequence of demonstrated trust, is bounded by role rather than by title, and carries no claim to status.** That is a stronger philosophical position than most large organisations can state. **v1.3-D does not replace it. It specifies it.**

## 2.2 The philosophy, formalised

**[P]** Seven propositions. Each is derived from §2.1 and each has an operational consequence — because a philosophy with no consequence is decoration.

| # | Proposition | Derived from | Operational consequence |
|---|---|---|---|
| **LP-1** | **Leadership is earned responsibility, not personal status.** | **[S: Const. Art.4; Ch.2 "Not status-based"]** | No ordinal display of leadership level below the role title; no courtesy precedence; ceremonies honour contribution and neighbourhood, never position **[S-A: A-16 §15.4]** |
| **LP-2** | **Trust is the precondition of authority, and trust is evidenced, not felt.** | **[S: Const. Art.2, Art.7]** | **LE-4 trust evidence** (Part 5) is a required class for every leadership appointment; a candidate with strong outcome evidence and no trust evidence is **not ready** |
| **LP-3** | **Authority is role-bounded. Title does not equal access.** | **[S: Ch.23; Ch.9]** | RBAC is granted per role and per delegation with start/end dates **[S: Ch.22]**; no leader holds a permission by virtue of seniority; Part 29 makes transition an access event |
| **LP-4** | **Greater responsibility brings greater accountability, scrutiny and duty of care — and does not bring greater human worth.** | **[S: Const. Art.7; S-C: §8.4 prohibition 1]** | No instrument may describe leadership as a higher form of service; leadership is a **different** form of contribution with more load **[S-B: §25.5]** |
| **LP-5** | **A leader's obligation includes producing their own replacement.** | **[S: Ch.9 Succession column; Ch.26; S-A: A-16 test 4; S-B: B-18(1)]** | **SS-0 (no successor identified)** is a *reported organisational risk* attached to the role, and successor development is a leadership-performance dimension (Part 11 §11.6) — with safeguards against artificial appointment |
| **LP-6** | **Autonomy is earned freedom inside central standards.** | **[S: App. A §16.1, §16.3]** | Local variation is permitted in *how* work is done; it is not permitted in money integrity, verification, safety, privacy, evidence or mission **[S: App. A §16.3 seven boundaries]** |
| **LP-7** | **The organisation is designed to remain healthy when its leaders are imperfect.** | **[P]** — the brief's absolute rule; consistent with **[S: Ch.14 support-first recovery]** | Every mechanism is tested against an ordinary, tired, ambitious, popular, wrong or absent person holding it (Part 42, Part 43) |

## 2.3 What a leader receives

**[P]** Derived from §2.1 and from the role architecture **[S: Ch.9, Ch.10, Ch.23]**. **Six increases, all of which are burdens:**

| Increase | Source anchor | What it actually costs the person |
|---|---|---|
| **Greater responsibility** | **[S: Ch.9 Team Leader "owns execution … carries leadership accountability"]** | The outcome of work they did not personally do |
| **Greater accountability** | **[S: App. E — Role promotion / Suspension / Removal rows]** | Being the named person when something goes wrong, in front of people they know |
| **Greater duty of care** | **[S: Ch.16; Ch.12 safeguarding; S-A: A-19, A-20]** | Carrying other people's safety and privacy in every decision |
| **Greater evidence requirements** | **[S: Ch.25 evidence links; App. F 14 record types; S-B: §25.5 `H_lead`]** | `g_lead_fix + g_dec × N_decisions + g_esc × N_escalations` hours per month — **coefficient [M], unknown** |
| **Greater scrutiny** | **[S: Ch.27 audit; Ch.24 monthly "performance and leadership" cadence]** | Their money handling, their appointments, their conflicts and their complaints are all inspectable |
| **Greater obligation to develop successors** | **[S: Ch.9 Succession; Ch.26; S-B: B-18(1)]** | Actively preparing the person who will replace them — the least naturally motivated duty in any organisation |

## 2.4 What leadership must never mean

**[P]** Eleven prohibitions. The brief specifies seven; four are added from the source hierarchy. Each carries its enforcement instrument, because a prohibition without an instrument is **[A]** — in the words of **[S-ST: F-03]** — "prohibition without pipeline".

| # | Leadership must NOT automatically mean | Enforcement instrument | Source of the prohibition |
|---|---|---|---|
| **1** | **Personal superiority** | No ordinal public display below role title; **[S-C: §8.4 prohibition 1]**; Part 22 §22.3 | **[S: Ch.2 "Not status-based"; S-C: SR-1]** |
| **2** | **Higher human value** | **[S-C: §24.2 CR-3]** — no record may determine a person's worth in any internal or public statement | **[S-C: CR-1…CR-4]** |
| **3** | **Unlimited authority** | RBAC per role and per delegation with dates **[S: Ch.22, Ch.23]**; reserved matters **[S-A: A-14]**; Part 29 | **[S: Ch.23 "title does not equal unlimited access"]** |
| **4** | **Permanent status** | `review_date` on every appointment **[S: Ch.22]**; RV-1…RV-4 reviews (Part 17); tenure question left **UNRESOLVED** (Part 34) | **[S: Ch.22 appointment_date/review_date]** |
| **5** | **Immunity from review** | Part 17 enhanced and triggered reviews apply **more** strongly to leaders; Part 18 complaints against leaders use independent intake | **[S: Ch.27; Const. Art.16]** |
| **6** | **Control over all information** | Data-minimisation and purpose limitation **[S-A: A-18]**; access separation matrix **[S-A: A-19 §18.2]**; sealed categories **[S-A: A-20]**; Part 31 | **[S: Ch.23; Const. Art.13]** |
| **7** | **Control over money** | Segregation: no one person may receive, approve, record and audit **[S: Ch.18]**; Funds Manager cannot self-approve, release reserves, change formula or audit own work **[S: Ch.18]**; leader cannot approve their own allocation (**[S-ST: F-15(7) iv]**) | **[S: Ch.18]** — **non-negotiable** |
| **8** | **Control over people** | Team Leader "**cannot … punish people**" **[S: Ch.9]**; removal requires HR + Team Leader with City HR on dispute **[S: App. E]**; serious misconduct requires a governance/HR panel **[S: App. E]** | **[S: Ch.9; App. E]** |
| **9** | **A financial premium by right** | The multiplier is `NOT FINAL` **[S: Ch.33]** and must be "justified by verified leadership **work** rather than status alone" **[S: App. A §15.3]**; **no number is proposed here** | **[S: App. A §15.3]** |
| **10** | **Exemption from the conduct rules** | **[S: Const. Art.8 APPROVED]** applies to every member; Part 19 makes leader removal *easier to initiate*, never harder | **[S: Const. Art.8]** |
| **11** | **A claim on personal loyalty** | **[S-A: A-01 N8]** no belief screening ever; **[S-C: AC-1…AC-11]**; Part 36 in full; belonging is to the mission and the team, never to a person **[S-C: §19.2]** | **[S-C: §20; S-A: A-16]** |

**[A]** Prohibitions 7, 8 and 10 are **already binding** in the source hierarchy. Prohibitions 1–6, 9 and 11 are **[P]** in their enforcement instruments but rest on **[S]** principles. **None of the eleven is new doctrine**; all eleven are new *enforcement*.

## 2.5 Leadership versus human worth

**[P]** Stated once, explicitly, and to be published wherever leadership levels are published — the same construction **[S-C: §7.3 SR-1]** uses for participation levels:

> **A person's leadership level does not determine their dignity, their value, their belonging, their right to participate, their right to leave, or the respect they are owed.**

**[A]** Supporting reasoning, all sourced:

1. **[S: Ch.25]** scores **teams**, and its own rule forbids raw counts determining leadership. **[S-C: §23.2]** scopes it: applies to teams, **not** to individuals at any level.
2. **[S-C: §8.2]** lists six legitimate endpoints plus Elder/Mentor, and observes: **"there is no 'top'. L8 is an endpoint, not a summit, and the Elder standing is available from L3 — which means the most socially respected position in the design can be reached without ever managing anyone."**
3. **[S-C: §8.4 prohibition 3]**: "The performance system may not be applied to endpoints."
4. **[S: Const. Art.6 PROPOSED POLICY]**: members "should receive fair process, clear role expectations, privacy protection, safe work boundaries, truthful compensation information, access to their own relevant records and appeal routes" — **without reference to role level**.

**[P] Rule D-1 (Human Worth Floor).** No leadership, performance, succession or recognition instrument may:
(a) reduce a person's access to help, on the basis that need priority uses "urgency, vulnerability, resources, expected impact, safety risk and feasibility" **[S: Ch.8 step 5]** and never the requester's record **[S-C: SR-5]**;
(b) make ordinary community participation conditional on role;
(c) appear in any public statement as a ranking of persons;
(d) be used to determine eligibility for anything outside the organisation **[S-C: CR-4]**.

## 2.6 Leadership versus membership

**[P]** Four propositions the brief requires, each with its instrument:

| Being a leader does not make someone… | Instrument |
|---|---|
| **More human** | Rule D-1 (§2.5) |
| **More worthy** | **[S-C: CR-3]**; Part 22 §22.3 |
| **Entitled to personal loyalty** | **[S-C: §19.2 BELONGING versus LOYALTY TO A PERSON]**; Part 36 AC-series checks |
| **Entitled to unrestricted data** | **[S-A: A-18]** four-branch necessity test applied field by field; **Part 31** — a leader's data access is the *narrowest* set sufficient for their decisions, and is reviewed at every transition |
| **Entitled to unrestricted money** | **[S: Ch.18]** segregation; **Part 23** |

**[A] The structural point:** authority is **role-based**, so it exists only while the role is held and only within the role's scope. **[S: Ch.22]** already implements this in the database: `delegated_authority` = "Scope, limits, start/end date, reason and reviewer"; `permission_profile`, `financial_permission_profile`, `data_access_profile` are separate fields. **A leadership philosophy of role-based authority is therefore not a new idea — it is already the data model.** Part 29 makes the transition an access event so that the data model is honoured in practice.

## 2.7 Leadership versus trust

**[P]** The distinction the brief requires, formalised:

| | **Trust as exemption** (prohibited) | **Trust as verification** (required) |
|---|---|---|
| Sentence | "Nobody checks me." | "I can be trusted inside a system that still checks important things." |
| Mechanism | Reduced scrutiny for high performers | **Increased** scrutiny for high responsibility |
| Source | — | **[S: Ch.27]**; **[S: Const. Art.16 APPROVED]** "Evidence, finance, HR, incidents, AI outputs and performance claims require auditability"; **[S: Ch.18]** segregation applies to *everyone* including the leader |
| Consequence | The most trusted person is the least examined — which is precisely where fraud, favouritism and burnout accumulate **[S-ST: F-16, F-23]** | The most responsible person is the most examined, and the examination is what makes the trust *credible to others* |

**[P] Rule D-2 (Trust-as-Verification Rule).** Scrutiny intensity is a **monotonically increasing function of authority**, never of performance. A leader with an excellent record receives *more* review, not less. Concretely:
- RV-2 **enhanced review** applies to every primary leadership role and every control role (Part 17);
- the four finance hands remain distinct at every level **[S: Ch.18]**, and a leader is never one of them for their own payment **[S-ST: F-15(7) iv]**;
- every delegation carries an end date and a reviewer **[S: Ch.22]**;
- conflict-of-interest declarations are required of leaders and recorded (Part 35 §35.2).

**[A]** This rule has a cost and the cost must be stated: **scrutiny that increases with authority makes leadership less attractive.** Combined with **[S-ST: F-03]** ("these roles say 'no' to friends and neighbours … with no stated reward, protection, or relief") and **[S-ST: F-24]** (the lottery), **[I]** a system that only adds scrutiny will fail to supply leaders. **Part 23 (compensation), Part 24 (workload), Part 25 (burnout) and Part 13 (specialist standing) exist to pay the other side of this account.** Rule D-2 must never be adopted alone.

## 2.8 Leadership versus autonomy, and versus control

**[S]** Both extremes are named and rejected in the source itself:

| **Central control** | **Central standards** |
|---|---|
| "Central decides every local schedule, task, member, post and opportunity." | "Central defines mission, safety, HR verification, finance controls, evidence, privacy and audits." |
| "Creates slow decisions and dependency." | "Creates trustworthy freedom and comparable evidence." |
| "Makes teams afraid to act or report problems." | "Allows local experimentation inside safety and accountability." |
| "Measures obedience even if outcomes are poor." | "Measures outcomes, integrity, compliance and learning." |
— **[S: Ch.13; App. A §16.2, reproduced verbatim in both places]**

**[S: App. A §16.3]** lists the seven autonomy boundaries: mission compliance · legal compliance · safety compliance · financial integrity · verified work · measurable outcomes ("teams must report results honestly, **including failures**") · organisational standards.

**[P] Rule D-3 (Minimum Central Standards for Leadership).** The centre defines, and local leadership may not vary: the seven autonomy boundaries **[S]**; the reserved matters **[S-A: A-14]**; the eligibility floor for leadership (Part 3); the performance gates PG-1…PG-12 (Part 7); the evidence classes admissible for appointment (Part 5); the prohibition list in §2.4; the segregation rules **[S: Ch.18]**; the protection DO-NOTs **[S-A: A-08]**; and the political neutrality code **[S-A: A-01…A-04]**.

**[P]** Everything else — how meetings are run, how tasks are allocated, how local relationships are cultivated, how the team structures its own workstreams, which legitimate ventures it pursues, how it solves local problems — remains local, per **[S: App. A §16.1]** "broad flexibility over how it operates, how it manages its area, how many members it takes, how it structures work, which legitimate business opportunities it pursues and how it solves local problems."

**[A]** Note the one boundary that is most often quietly dropped and must not be: **"teams must report results honestly, including failures"** **[S: App. A §16.3]**, reinforced by **[S: Ch.15]** "include failures and partial outcomes in reports". **Part 8 §8.6 makes honesty-of-reporting a scored element of execution quality**, because a leadership system that cannot see failure cannot correct it — and **[S-B: §23]** establishes that concealment is the actual failure mode when closure is feared.

## 2.9 Leadership culture — objectives, not claims

**[P]** Eight cultural design objectives, each with an **observable behaviour** and a **tripwire**. **[A]** These are stated as objectives, not as evidence of implementation, and **[S-ST: §15.4]** is explicit that culture is transmitted by what is rewarded and punished, not by what is written.

| Objective | Observable behaviour | Tripwire (the signal that it has failed) |
|---|---|---|
| **Responsibility over status** | People describe roles by what they carry, not by where they sit | Ordinal language about persons below L5 **[S-C: SR-2]** |
| **Evidence over ego** | Decisions cite records; a leader says "I don't know yet, here is what we will check" | A decision recorded without a reason (**[S-A: A-15 M1]** violation) |
| **Service over prestige** | Recognition stories are about the lane, the date and the group | Recognition requested rather than received (**[S-C: SA-5]**) |
| **Correction over concealment** | Failures and partial outcomes are published **[S: Ch.15]** | A city with zero recorded failures in a year |
| **Teaching over hoarding** | A leader can name the people who became capable because of them | Successor state SS-0 persisting across two review cycles |
| **Succession over dependency** | Handover completes inside the stated period, with gaps recorded | **LDI** rising (Part 38); a leader unavailable and no one able to act |
| **Cooperation over destructive competition** | Teams refer excess demand to the City pipeline **[S-B: B-10]** and support weaker teams **[S: Ch.14 step 4]** | Support requests never made; referrals recorded as failures |
| **Mission over personality** | Decisions announced in the organisation's name with the deciding role **[S-A: A-16 §15.4]** | Attribution test: decisions justified by reference to a person (**[S-A: A-16 test 2]**) |

**[A]** The tripwires are the useful half. **[S-A: A-16 §15.3 test 3]** establishes the principle: **"A zero count is a warning sign, not a clean bill of health."** A leadership culture in which nobody ever reports a failure, disputes a decision, declines a promotion or leaves a role is not healthy — it is silent.

## 2.10 The core principle, correctly labelled

**[P]** The brief offers this sentence and asks that it not be presented as source rule unless the source supports it:

> «Leadership is not the reward for being the best person. Leadership is the responsibility given to someone who has demonstrated that they can use authority without becoming dependent on it.»

**[A] Source analysis of the sentence, clause by clause:**

| Clause | Source support | Classification |
|---|---|---|
| "Leadership is not the reward for being the best person" | **Partially supported.** **[S: Ch.25]** forbids raw counts determining leadership; **[S: Ch.26]** says transition is "Not automatic status"; **[S: Ch.26]** "Opportunity not automatic personal entitlement"; **[S-C: §8.4 prohibition 1]** forbids describing leadership as a higher form of service. But **no source sentence states the negative formulation** | **[I]** — a correct inference from four source rules, not a source rule itself |
| "Leadership is the responsibility given to someone who has demonstrated…" | **Supported.** **[S: Const. Art.4]** "earned through performance"; **[S: Const. Art.7]** "Greater responsibility requires greater trust"; **[S: Ch.2 principle 6]** "Authority follows verified work, conduct, financial integrity, safety compliance and community trust" | **[S]** |
| "…they can use authority without becoming dependent on it" | **Not present in the source.** The nearest is **[S-A: A-16 test 1]** (absence test) and **[S-A: A-16 test 4]** (successor test), which test the *organisation's* dependence, not the *leader's*. The inversion — a leader who needs the role to matter — is nowhere addressed | **[P]** — a new principle proposed here, and the basis of the **LDI** in Part 38 |

> **[P] Adopted as the operating principle of v1.3-D, labelled [P], with the third clause flagged as new doctrine requiring approval.** It is *consistent* with the source and *extends* it. It is not source.

## 2.11 Symbols, titles and badges

**[P]** Rule D-4 (Symbol Subordination Rule). Symbols, uniforms, titles, badges, colours and insignia are **subordinate to the authority model** and may never create authority.

| Permitted | Prohibited |
|---|---|
| A role title that states function ("Mohalla Funds Manager") | A title that states rank over people ("Chief", "Supreme", "Head of all…") where the source does not use it |
| Identification that supports lawful first response and public clarity, per **[S-A: A-06]** visibility protocol — minimal data, revocable token, non-police visual design **[S: Ch.33 QR card CONCEPT APPROVED]** | Anything resembling police, military or private-security insignia **[S-A: A-06, A-08]** |
| A credential that certifies a demonstrated skill against a published standard **[S-C: H-10]** | A badge that certifies *level* in public **[S-C: SR-2]** |
| Team identity expressed as place and work ("the lane-4 clean-up team") | Personal branding of a leader as the face of the organisation **[S-A: A-16 §15.4; S-C: §45.2 rule 4]** |

**[A]** The reason this belongs in the philosophy part rather than in communications: **[I]** in a street-present, neighbourhood-embedded organisation, a symbol is read by the public as a claim to authority regardless of what the internal rule says — which is exactly the mechanism of **[S-ST: F-09 vigilante perception, CRITICAL]**. **Symbol discipline is therefore a leadership-authority control, not a branding preference.** **[S-A: A-06/A-07/A-08]** already govern it; Rule D-4 adds only that leadership instruments may not create new symbols without passing the same gate.

---

# PART 3 — ELIGIBILITY AND READINESS

## 3.1 Why these must be two systems

**[A]** The source has an eligibility engine and does not have a readiness engine.

**[S: Ch.11 step 2]** — "Eligibility defined: **Membership status, training, experience, conduct, availability, legal/age, conflicts, safety and data requirements.**"
**[S: Ch.22]** — `training_requirements / eligibility_requirements` = "Required modules, certifications, membership, conduct, experience, conflicts, availability and safety."
**[S: Ch.26 step 4]** — "Eligibility gates: Safety, finance, HR, training and evidence minimums required."

**[A]** Every one of those is a **binary check on a record**. It answers *may this person be considered?* It does not answer *should this person be given this authority?* **[I]** The gap between the two is where organisations appoint their worst leaders: a candidate who passes every record check — verified, trained, clean conduct, available, no conflict — and who nonetheless cannot hold a disagreement, cannot delegate, cannot admit a mistake, or cannot let someone else succeed.

**[P] Amendment L-01 — Eligibility and Readiness Separation.** Two gates, separately defined, separately evidenced, separately decided, separately recorded and separately appealable.

| | **GATE E — ELIGIBILITY** | **GATE R — READINESS** |
|---|---|---|
| **Question** | May this person be considered for this role? | Is this person prepared to hold this authority now? |
| **Nature** | Binary, record-based, objective, verifiable | Graded, evidence-based, assessed by another person, appealable |
| **Decided by** | HR & Verification against the published criteria **[S: Ch.11 step 5]** | An assessor **outside the candidate's team** (Part 15 §15.3, Rule D-45) plus the appointing authority |
| **Output** | `ELIGIBLE` / `NOT ELIGIBLE — reason` | `READY` / `READY WITH DEVELOPMENT (named gaps)` / `NOT READY (named gaps, named support, named review date)` |
| **Validity** | Point-in-time; re-checked at every vacancy | Time-bounded; expires if not used within a stated period — `PROPOSED` duration |
| **Cost** | Low; automated from existing records | Moderate; requires a person |
| **Appeal** | On the record: "the record is wrong" | On the assessment: "the judgement is wrong" — different route, different reviewer (Part 18) |
| **Source** | **[S: Ch.11 step 2, Ch.22, Ch.26 step 4]** | **[P]** — no equivalent exists in the source |

**[A] The critical rule: Gate E may never be satisfied by Gate R, and Gate R may never be waived because Gate E passed.** A person who is eligible but not ready is **not promoted**; a person who is ready but not eligible is **not promoted either** — the eligibility floor protects the institution from the organisation's own enthusiasm.

## 3.2 Gate E — eligibility criteria

**[S]** Items 1–9 are directly derived from **[S: Ch.11 step 2]**, **[S: Ch.22]**, **[S: Ch.26 step 4]** and **[S: Ch.12]**. Items 10–13 are **[P]**, added from v1.3-A and v1.3-C.

| # | Criterion | Record source | Status | Notes |
|---|---|---|---|---|
| **E-1** | **Membership state** — Verified Member (L5+) or above | **[S: Ch.12 step 7]**; **[S-C: §6.6]** | **[S]** | Levels 0–4 may not hold leadership roles; **[S-C: §6.11 rule 5]** — task responsibility always sits with a Verified Member |
| **E-2** | **Identity verification complete** | **[S: Ch.12 step 3; SOP-02]**; MVC-2 **[S-B: §26.2]** | **[S]** | Irreducible |
| **E-3** | **Required training completed** — organisation fundamentals, code of conduct, safeguarding, communication, financial integrity, data privacy, AI usage, plus role-specific | **[S: Ch.12 training categories; Ch.22 `training_requirements`]** | **[S]** | **Professional-validation boundary: "internal training is not automatically legally sufficient for first aid, emergency response, security, labour, child safeguarding, medical, counselling, legal or regulated activities"** **[S: Ch.12]** — **[V]** |
| **E-4** | **Probation completed and passed** | **[S: Ch.12 step 6; SOP-04]** | **[S]** | "Observed behaviour under supervision" |
| **E-5** | **Conduct state clear** — no unresolved serious-misconduct matter; no active suspension | **[S: Const. Art.8; Ch.12 conduct records "highly restricted"; App. E Suspension row]** | **[S]** | An unresolved matter is a **hold**, not a disqualification (Part 18 §18.6) |
| **E-6** | **Minimum experience in the function** | **[S: Ch.11 step 2 "experience"; Ch.9 Succession column]** | **[S]** principle, **[U]** quantity | **No time period is invented.** **[S: Ch.33]** "no final numbers invented". The source's own pathway — "Coordinator → Sub-Funds → Funds Manager"; "Sub-Leader → Team Leader → higher level" **[S: Ch.9]** — implies progression *through* the function, but sets no duration. **Duration is LDR-04 in Part 45: UNRESOLVED** |
| **E-7** | **Availability** — the person can actually carry the load | **[S: Ch.11 step 2 "availability"]** | **[S]** | Tested against **LLI** (Part 24), not against willingness. A person already at load ceiling is **not available** even if they say yes |
| **E-8** | **Conflict-of-interest position declared and manageable** | **[S: Ch.11 step 2 "conflicts"; Ch.28 conflict-of-interest risk; S-A: A-02 §B.4 disclosure/recusal]** | **[S]** | Family, close friendship, business relationship, financial interest, personal dispute, competing organisational interest (Part 35 §35.2) |
| **E-9** | **Safety and data requirements met** for the specific role | **[S: Ch.11 step 2; Ch.23 RBAC; Ch.22 `data_access_profile`]** | **[S]** | e.g. Safety Lead requires safety training; any role touching C3/C4 data requires the corresponding clearance **[S-A: A-17]** |
| **E-10** | **Legal/age position satisfied** | **[S: Ch.11 step 2 "legal/age"]** | **[S]** + **[V]** | **No legal age rule is invented.** Youth participation is governed by **[S-C: §48 Y-1…Y-10]** and remains `REQUIRES PROFESSIONAL VALIDATION` |
| **E-11** | **Political-neutrality position satisfied** for the role | **[S-A: A-02 graduated rule set, tiers T0–T5; A-02 §B.4 suspension rules]** | **[S-A]** | **A person is not disqualified for holding lawful personal political views.** **[S-A: A-01 N8]**: "no belief screening ever — no question, test, inference or record about what a person believes." Where the source's own tiers require disclosure, recusal or suspension for a *leadership* tier, that requirement applies — and **only** that requirement |
| **E-12** | **Not recorded as "declined leadership"** | **[S-C: H-17 Right of Refusal — "Refuse leadership … and be recorded as 'not available for leadership' so they are not asked repeatedly"]** | **[S-C]** | **This is an eligibility criterion in the negative direction: a person who has refused leadership may not be put forward again without a fresh, self-initiated opt-in.** It protects the refusal right from being eroded by repeated asking |
| **E-13** | **No active improvement plan or removal process** in respect of a comparable role | **[S: Ch.12 step 12; App. E]** | **[P]** | Prevents lateral movement as a way of escaping an unresolved performance matter (Part 19 §19.7) |

**[A]** Note what is **absent** from Gate E, deliberately:

| Absent criterion | Why it must be absent |
|---|---|
| **Wealth, income or financial contribution** | **[S: Const. Art.1]** "without discrimination"; **[S-C: §35.2]** participation matrix; no fee may ever be required **[S-C: MLM-3]** |
| **Education level or degree** | Not in the source's eligibility list **[S: Ch.11 step 2]**; adding it would create the structural barrier Part 3 §3.7 exists to remove |
| **Language fluency in English** | **[S-C: §30]** three-layer language architecture; **[S-ST: F-31]** vernacular AI quality and the language hierarchy |
| **Caste, religion, region, gender, family name** | **[S: Const. Art.1; Ch.2 principle 1]** "Service is not restricted by caste, religion, gender, economic status, politics, personal identity or popularity"; **[S-A: A-05]** Equal Treatment and Non-Alignment |
| **Number of people recruited** | **[S-C: MLM-1, MLM-4, MLM-6]** — no eligibility may be derived from any count of people |
| **Social-media following or visibility** | **[S: Ch.25]** "follower count, social-media views … cannot determine leadership" |
| **Team size** | **[S-C: MLM-1]**; **Part 26** — size may create *workload*, never *authority* |
| **Proximity to the founder or to current leadership** | **[S-A: A-16 test 2]** attribution test; **[S-C: AC-3]** "rank or access derived from proximity to a person rather than from role" |
| **Tenure alone** | §3.3 below |

## 3.3 Seniority: where tenure is and is not admissible

**[P]** Rule D-5 (Seniority Rule).

| Use of tenure | Permitted? | Reasoning |
|---|---|---|
| As a **floor** — "must have completed probation and served in the function" **[S: Ch.9 Succession pathway]** | ✅ Yes | The source's own pathways run through the function; a person who has never done the work cannot verify it |
| As a **tie-break** between two candidates assessed as equally ready | ⚠️ Only if published in advance, recorded, and appealable | An unpublished tie-break is favouritism with a spreadsheet |
| As a **criterion weighted against other candidates** | ❌ No | "Not status-based" **[S: Ch.2]**; and it produces **[S-ST: M9]**'s named risk — "elder status becomes gerontocracy" |
| As a **substitute for readiness assessment** | ❌ No | §3.1 — Gate E never satisfies Gate R |
| As a **basis for the Elder/Mentor standing** | ✅ Yes, and this is its proper home | **[S-C: §6.10]**: "Long-serving members, at any level from L3 upward, recognised by the team and recorded" — **excluded from RBAC command permissions and from scoring** |

**[A]** The Elder/Mentor standing is the architecturally correct place for seniority: it gives long service **real, recorded, socially meaningful standing** with **zero command authority and zero score weight** **[S-C: §6.10]**. **[I]** This is why it matters for leadership design and not only for human design: **it removes the pressure to promote long-serving people into roles they cannot perform**, which is one of the most common causes of leadership failure in volunteer organisations.

## 3.4 Gate R — readiness criteria

**[P]** Fourteen readiness dimensions. Each is: (a) **observable**, (b) **evidenced from a record the architecture already produces**, (c) **graded rather than binary**, and (d) **assessed by someone outside the candidate's team**. **No dimension is a personality test, a belief test, or a likability rating.**

| # | Readiness dimension | Observable evidence | Record source | Failure indicator |
|---|---|---|---|---|
| **R-1** | **Judgement under incomplete information** | Decisions made with stated reasons, including decisions later shown to be wrong and how they were handled | **[S-A: A-15 M1]** decision-rationale register; **[S: Ch.8 decision log "task/project/refer/escalate/decline"]** | Decisions with no recorded reason; a pattern of deferring everything upward |
| **R-2** | **Reliability** | Did what was committed, when it was committed; absence communicated in advance | **[S: Ch.24 daily "tasks, attendance"; Ch.25 volunteer reliability metric]** | Completed ÷ accepted falls; unannounced absence |
| **R-3** | **Communication** | Can explain a decision to someone who disagrees with it, in the other person's language | **[S: Ch.24 internal communication rule; S-C: §30 language architecture]** | Explanations require authority rather than reasoning |
| **R-4** | **Delegation** | Work actually assigned to others with recorded scope and dates; **not** retained | **[S: Ch.10 delegation; Ch.22 `delegated_authority`]** | Zero active delegations while carrying full load — the indispensability signature |
| **R-5** | **Conflict handling** | A disagreement occurred and was resolved without escalation to authority and without relationship damage | **[S: Const. Art.17 local resolution first; S-C: §42.1 eight ordinary conflicts]** | Every conflict escalated; or no conflict ever recorded (**[S-A: A-16 test 3]** zero-dissent warning) |
| **R-6** | **Safety discipline** | Stop-work used when warranted; incidents reported including own team's; DO-NOTs observed | **[S: Ch.16; Ch.9 Safety Lead "Stop-work/escalate within policy"; S-A: A-08, A-09]** | An incident discovered by someone other than the team |
| **R-7** | **Financial discipline** | Receipts, approvals, reconciliation clean; never self-approves; flags own errors | **[S: Ch.18; Ch.19 step 13; Ch.25 financial-discipline dimension]** | Unexplained variance; **[S-B: §27.2]** segregation status false |
| **R-8** | **Evidence discipline** | Outcome verification completed; **failures and partial outcomes reported** | **[S: Ch.15 steps 9–10; App. F; App. A §16.3]** | Activity counts rising while outcome-verification rate falls (**[S-C: SA-3]**) |
| **R-9** | **Ability to develop others** | Named people who took on more because of this person's action; training delivered; delegation that led to a role | **[S: Ch.25 member-development dimension "Training, retention and role growth"; Ch.12 step 10]** | Nobody in the team has progressed in a full cycle |
| **R-10** | **Emotional maturity under pressure** | Behaviour during an incident, a shortage, a complaint or a public accusation | **[S: Ch.16; S-A: A-09 incident protocol; S-C: §43 psychological safety]** | Retaliation, concealment, blame-shifting, or silence |
| **R-11** | **Ability to accept correction** | Received a finding and implemented it without contesting the messenger | **[S: Ch.27 audit; Ch.14 step 7 "process correction"]** | Audit findings appealed on personal grounds rather than factual grounds |
| **R-12** | **Ability to admit mistakes** | A self-reported error exists in the record | **[S-A: A-15 M5]** lessons register; **[S: Ch.15]** honesty rule | A record with no self-reported error across many cycles — **[A]** statistically implausible and a concealment signal |
| **R-13** | **Succession behaviour** | A named, developing successor exists; delegation is increasing, not hoarding; handover artifacts maintained | **[S: Ch.9 Succession; Ch.22 `succession_status`; S-B: B-18(1)]** | **SS-0** persisting (Part 11) |
| **R-14** | **Ability to operate within limits** | Did not exceed delegated authority, financial limit, safety boundary or data scope | **[S: Ch.23 RBAC; Ch.22 `delegated_authority`; App. E escalation column]** | Any recorded authority breach, however small |

**[A]** The grading is deliberately **not a score**. **[P] Rule D-6 (No Readiness Number).** Readiness output is a **statement of gaps**, not a number:

> `READY` — no material gap identified.
> `READY WITH DEVELOPMENT` — gaps: **R-4 delegation, R-13 succession**. Support: AP-2 supervised delegation, AP-4 project leadership. Review: next cycle.
> `NOT READY` — gaps: **R-6 safety discipline (unresolved incident finding), R-11 (contested two audit findings on personal grounds)**. Not eligible for this role at this time. Reassessment available on request after the stated development period, or on the next vacancy.

**[A]** Reasons for the prohibition on a readiness number:
1. A number invites comparison, and comparison of *readiness* across different roles and contexts is exactly the fairness problem Part 9 exists to solve — imported into the individual level, where **[S-C: §23.2]** forbids it.
2. A number is appealable only as a number ("why 62 and not 68?"), which produces argument about arithmetic instead of argument about evidence.
3. A gap statement is **actionable**: it tells the candidate and the organisation what to do next. A number tells them nothing.
4. **[S-C: §55.1]** established the principle for human metrics: **no composite human score**. Readiness inherits it.

## 3.5 Where eligibility and readiness interact with the vacancy lifecycle

**[S: Ch.11]** thirteen steps, preserved exactly, with the two gates mapped in:

| Step | Source content | v1.3-D addition |
|---|---|---|
| 1. Vacancy created | "Role, team, department, level and vacancy status are recorded" | + **succession state of the vacated role** (SS-0…SS-5) and whether the vacancy was *planned* (succession) or *unplanned* (exit, removal, death) |
| 2. Eligibility defined | "Membership status, training, experience, conduct, availability, legal/age, conflicts, safety and data requirements" | = **Gate E**, §3.2 |
| 3. Applications open | "Internal/external eligibility and application window defined" | + the window must be long enough for people who are **not** already close to leadership to apply (Part 25 §25.2 — opportunity fairness) |
| 4. Application | "Verified members may apply internally; applicants do not gain automatic appointment" | + **self-nomination and third-party nomination both permitted**; a person who does not nominate themselves may still be nominated, **with their consent recorded** (Part 33 §33.4) |
| 5. HR screening | "Eligibility and HR checks" | = **Gate E executed and recorded** |
| 6. Verification | "Identity/status/training/conduct checks as required" | + **out-of-team verification sampling** where the verifier is socially connected to the candidate (**[S-ST: F-26]**) |
| 7. Interview / assessment | "Role-specific suitability or scenario assessment" | = **Gate R**, with a **structured** scenario instrument, an out-of-team assessor, and a recorded decision with reasons (Part 15 §15.3) |
| 8. Training verification | "Required courses/certifications confirmed" | + certification is **observed capability**, not course completion alone (Part 16) |
| 9. Selection or alternate path | "Non-selected member remains in organisation and may apply for another suitable vacancy" | + **the non-selected candidate receives their gap statement** (R-6 output) and, where they want it, a development plan. **This is the single cheapest retention instrument available for the F-24 population** |
| 10. Probation | "Required where applicable" | + for leadership roles, probation is **delegation-bounded**: full role scope is granted progressively (Part 15 AP-2) |
| 11. Appointment | "Final approval according to role level" **[S: App. E — Role promotion: "Team Leader + HR", co-review "City/State role owner", escalate when "Leadership/finance/safety role"]** | + **the ten promotion readiness gates LG-1…LG-10** (Part 10) and a **Promotion Decision Record** (Part 10 §10.8) |
| 12. Permissions activated | "RBAC, financial and data access profiles applied" | + **narrowest-sufficient** profiles; explicit grant, never inheritance (Part 29) |
| 13. Performance monitoring | "Role-specific indicators and review dates" | + **RV-1…RV-4** review type assigned by role class (Part 17), and succession state opened for the newly filled role (Part 11) |

**[A]** The most important structural observation: **[S: Ch.11 step 9]** already contains the remedy for the lottery problem — "alternate path" — and **[S-ST: F-23(7) iii]** noted it is "currently applied only to non-selected vacancy applicants." **Extending it to role re-matching generally is a source-consistent, zero-authority, zero-cost intervention**, and it is adopted here as **L-17(4)**.

## 3.6 Eligibility for what? — the role-class dependency

**[P]** Rule D-7 (Role-Class Rule). Eligibility and readiness criteria are **role-class specific**, because the source's own architecture already differentiates authority limits by role **[S: Ch.9 authority-limits column]** and by level **[S: Ch.10 final role catalogue]**.

| Role class | Examples **[S: Ch.9, Ch.10]** | Additional Gate E items | Additional Gate R emphasis |
|---|---|---|---|
| **Control roles** | HR & Verification Manager, Funds Manager, Safety/Protection Lead, Auditor | E-5 (conduct) **hard**; segregation compatibility check — the person may not already hold a hand that conflicts **[S: Ch.18]**; fixed tenure and rotation eligibility (**[S-ST: F-03(7)]**) | R-6, R-7, R-8, R-14 weighted; **ability to say no to a friend is the core capability** |
| **Delivery roles** | Ground-Level Manager, Planner, Warehouse Manager, AI & Business Manager | E-3 role-specific training; venture category approval status where applicable **[S: Ch.33 POTENTIAL]** | R-2, R-8, R-9 |
| **Communication roles** | Social Media Manager, Editor | E-9 data scope; **[S: Ch.24]** authorised-spokesperson status | R-3, R-8, R-11 — and **the discipline to publish failures** **[S: Ch.15]** |
| **Team leadership** | Mohalla/City/State/National Team Leader; Sub-Leader | E-1…E-13 in full; **the nine functions must be coverable** **[S: Ch.10 State A]** | All fourteen, with R-4, R-9, R-13 decisive |
| **Institutional leadership** | National layer, Council-adjacent, Level 8 Builder | E-1…E-13 plus **[S-A: A-14 §13.5]** published eligibility criteria: "demonstrated conduct, verified record, financial integrity, safety compliance, understanding of the constitution, absence of unresolved conflict or misconduct" | R-1, R-5, R-10, R-13 plus the **level-specific capabilities** of Part 32 §32.2.5 |

**[A]** This matters because **[S-ST: §1.2 Finding 5]** and **[S-B: §24.2]** identify the promotion of a local operator into a coordination layer as a *category error*, not a stretch. **Different role classes require different evidence**, and Part 32 makes that explicit per level.

## 3.7 Structural fairness and accessibility of leadership

**[P]** The brief requires that leadership should not require wealth, elite education, perfect English, constant digital availability, or social-media popularity. **Below, each barrier is traced to a mechanism, and each mechanism to a remedy that does not lower any standard.**

| # | Structural barrier | Mechanism by which it excludes | Remedy | Does the remedy lower the standard? |
|---|---|---|---|---|
| **AF-1** | **Language** | Interview, forms, assessment and reporting default to the language of the most educated member **[S-ST: F-31]** | Assessment and interview conducted in the candidate's own language, per **[S-C: §30]** three-layer architecture; records translated for upward review; **language of assessment is recorded so bias can be audited** | **No** — capability is language-independent; only the instrument was language-dependent |
| **AF-2** | **Digital access** | A role that requires constant platform availability excludes people who share a device or have intermittent connectivity **[S-C: §29.3 "technology must not be mandatory where it excludes"]** | Manual-record equivalence for every leadership duty at Stage 0–2 (**[S-B: §40.2 "Technology: None required"]**); asynchronous participation permitted; no "always-on" expectation (Part 25) | **No** — the duty is unchanged, the channel is |
| **AF-3** | **Time poverty / family responsibility** | Meetings, cadences and emergency availability fall on those with slack; **[S-C: FR-09 family friction; AC-8 "organisation above family"]** | Meeting-load ceiling (Part 24 LLI); cadence reduction at low maturity (**[S-B: §25.2 lever 1]**); refusal rights preserved **[S-C: H-17]**; no availability test in Gate E beyond E-7 *actual capacity* | **No** — E-7 tests whether they can carry the load, which is a real requirement, not a bias |
| **AF-4** | **Education and articulateness** | Interview rewards fluency, vocabulary and confidence | **Structured scenario assessment** with published criteria and a scoring rubric attached to behaviours, not to expression (Part 15 §15.3); **evidence portfolio weighted above interview** (Part 5) | **No** — it replaces a proxy with the thing itself |
| **AF-5** | **Introversion and communication style** | Visibility is mistaken for capability; the loud are nominated | **No dimension of LC-1…LC-20 requires extraversion** (Part 4); nomination requires evidence, not impression; **Part 21** prohibits individual public ranking | **No** |
| **AF-6** | **Proximity to current leadership** | Those nearest the leader are seen most and nominated most | **Out-of-team assessment** (Part 15 §15.3); **conflict-of-interest declaration by the nominator** (Part 35 §35.2); **attribution audit** **[S-A: A-16 test 2]** | **No** |
| **AF-7** | **Wealth** | Unpaid governance burden falls on those who can afford it (**[S-B: §24.1 social cost; HC-22 opportunity cost of governance hours]**) | **L-21 Leadership Economics Rule** — every duty has a named funder or is explicitly costed; leadership may not require uncompensated availability beyond the stated ceiling (Part 39) | **No** — it removes a hidden wealth test |
| **AF-8** | **Disability and accessibility** | Physical presence at field sites, meetings and incidents assumed | **[S-C: HV-10 accessibility specialist; §29.3]**; role-class matching — many control, planning, editorial, finance and AI roles are fully accessible remotely **[S-C: §50.2]**; **what requires physical presence is defined absolutely** **[S-C: §50.3]** | **No** — the *role set* is broad enough that capability is not confined to one body type |
| **AF-9** | **Geography** | Rural, peri-urban and low-demand localities produce fewer leadership opportunities because they produce fewer teams and less revenue **[S-B: §26.5 `K_min`]** | **Cohort normalisation** (Part 9); **density-first growth** **[S-B: B-23]**; **city-shared control roles** **[S-ST: F-03(10)]** so a small team still exposes people to control work | **No** |
| **AF-10** | **Age** | Youth excluded from responsibility; elders excluded from relevance | **[S-C: §48 Y-1…Y-10]** age-appropriate responsibility with safeguarding **[V]**; **[S-C: §49]** elder participation; **§3.3** seniority rule | **No** — both directions are opened within legal limits |
| **AF-11** | **Caste, religion, region, gender** | Social composition of the locality reproduces itself in the leadership **[S-ST: F-26]** | **[S: Const. Art.1; Ch.2 principle 1; S-A: A-05]** Equal Treatment and Non-Alignment; **no demographic data collected for selection purposes** — the remedy is *structural* (out-of-team assessment, published criteria, recorded reasons, appeal), not demographic measurement (**[S-A: A-18]** prohibited collection) | **No** |
| **AF-12** | **Prior exit** | A person who left is treated as permanently inferior | **[S-C: §21.5 alumni welcome; CK-6]** "a person who left may return without penalty, and this is stated publicly"; Part 10 §10.9 leadership return | **No** |

**[P] Rule D-8 (Structural Fairness Rule).** Fairness is achieved by **changing the instrument**, never by (a) lowering the standard, (b) collecting demographic data, or (c) setting quotas. **[A]** This is the only fairness strategy compatible with **[S-A: A-18 §17.4 prohibited collection]** and with **[S: Const. Art.1]**'s non-discrimination principle. **Quotas, targets and demographic measurement are expressly not proposed**, and any future proposal to introduce them is a **reserved decision** requiring approval and **[V]** legal review.

## 3.8 The eligibility trap — an adversarial check on this Part

**[A]** Every eligibility system has a failure mode, and this one has three:

| Trap | Mechanism | Control |
|---|---|---|
| **ET-1 Credentialism** | Gate E grows until only people with time and education can pass; the organisation's leadership becomes a subset of its most privileged members | **[S-B: §26.3]** control-budget rule applied to eligibility: any new E-criterion must be automated from an existing record or replace one. **Part 40** fixes the MVLS eligibility set |
| **ET-2 Readiness inflation** | Gate R becomes a subjective veto used against people the assessor dislikes | Structured instrument with published criteria; **two assessors, at least one out-of-team**; recorded reasons; **appeal on assessment grounds** (Part 18 §18.5); assessor identity and conflict declaration recorded |
| **ET-3 Gate E satisfied by proxy** | "He's been here longest, he's trained, he's clean — he's eligible" → appointed without Gate R | **LG-1…LG-10** (Part 10) require both gates independently; a Promotion Decision Record (Part 10 §10.8) that lacks a Gate R output is **procedurally incomplete** and challengeable under **[S: Const. Art.17]** |

**[I]** ET-3 is the most likely, because it requires no bad faith — only haste. **[A]** The correction is procedural and cheap: **no appointment record is complete without both gate outputs.** That single rule converts the philosophy into an audit test.

---

# PART 4 — CAPABILITY FRAMEWORK

## 4.1 The twenty dimensions

**[P] Amendment L-02 — Leadership Capability Model (LC-1…LC-20).** The brief specifies twenty dimensions. Each is defined by an **observable behaviour**, an **evidence class** (Part 5), a **treatment** (§4.3), and a **failure signature** — because a dimension without a failure signature cannot be assessed, only admired.

| ID | Dimension | Observable behaviour | Evidence class | Failure signature |
|---|---|---|---|---|
| **LC-1** | **Mission alignment** | Decisions cite the mission and the four pillars **[S: Ch.3]**; service is not subordinated to revenue **[S: Ch.25 mission impact 20%]** | LE-3 behaviour | Service categories drift to those that generate revenue (**[S-ST: F-17]**) |
| **LC-2** | **Integrity** | Reports own errors; no undisclosed conflict; money handling clean; says the same thing in different rooms | LE-4 trust | A discrepancy between the internal record and the public statement |
| **LC-3** | **Reliability** | Commitments met on time; absence announced; response inside the stated window | LE-1 activity (verified) | Completed ÷ accepted falls **[S: App. A §18.3 volunteer reliability]** |
| **LC-4** | **Judgement** | Chooses correctly under incomplete information **and records why** | LE-3 behaviour + LE-2 outcome | Decisions with no recorded reason (**[S-A: A-15 M1]** violation) |
| **LC-5** | **Execution** | Converts a plan into completed, verified work | LE-2 outcome | High planning volume, low completion **[S: Ch.25 execution]** |
| **LC-6** | **Communication** | Explains a decision to a person who disagrees, in that person's language | LE-3 behaviour | Explanations require authority |
| **LC-7** | **Delegation** | Assigns real scope with recorded limits and dates; **lets the assignee own it** | LE-1 activity + LE-5 development | Zero active delegations under full load |
| **LC-8** | **Team development** | Named people progressed because of this leader's action | LE-5 development | Nobody progressed in a full cycle **[S: Ch.25 member development]** |
| **LC-9** | **Conflict management** | A disagreement resolved locally without escalation to authority and without retaliation | LE-3 behaviour + LE-4 trust | Every conflict escalated, or none recorded (**[S-A: A-16 test 3]**) |
| **LC-10** | **Safety discipline** | Stop-work used when warranted; DO-NOTs observed; incidents reported including own team's | LE-3 behaviour | An incident found by someone else **[S-A: A-08, A-09]** |
| **LC-11** | **Financial discipline** | Receipts, approvals, reconciliation, no self-approval, flags own anomalies | LE-2 outcome + LE-4 trust | Unexplained variance **[S: Ch.18]** |
| **LC-12** | **Evidence discipline** | Outcome verification completed; failures and partial outcomes published | LE-2 outcome | Activity rising while verification falls (**[S-C: SA-3]**) |
| **LC-13** | **Data and privacy discipline** | Collects the minimum; accesses only what the decision requires; reports breaches | LE-3 behaviour | Access beyond scope; **[S-A: A-18]** necessity test failed |
| **LC-14** | **Problem-solving** | Diagnoses root cause rather than treating symptom | LE-2 outcome | The same problem recurs unchanged (**[S-A: A-15 M5]** "did the change work" column) |
| **LC-15** | **Adaptability** | Changed approach when the evidence changed, and recorded the change | LE-3 behaviour | A plan pursued past the point where its premises failed |
| **LC-16** | **Learning ability** | Sought correction; attended development voluntarily; applied a lesson from another team | LE-5 development | No lesson adopted from outside the team across many cycles |
| **LC-17** | **Succession behaviour** | A named successor exists and is being given increasing real scope | LE-5 development | **SS-0** persisting across two review cycles (Part 11) |
| **LC-18** | **Community trust** | The locality treats the team as legitimate; feedback positive or issues addressed **without retaliation** | LE-4 trust | Complaints arrive only after resignation (**[S-ST: F-21]** early warning) |
| **LC-19** | **Long-term thinking** | Chose a worse short-term score for a better durable outcome, and can name it | LE-2 outcome (Sustainability window) | Every decision optimises the current period (Part 8) |
| **LC-20** | **Operating under uncertainty** | Acted, or deliberately did not act, inside an unresolved question — and said which | LE-3 behaviour | Either paralysis, or action presented as certainty when it was a guess |

**[A]** Note what is **not** in the model: charisma, articulateness in English, energy, availability, wealth, following, seniority, recruitment volume, or likeability. **[A]** Each of those is a **proxy** that correlates with capability in some contexts and with harm in others, and **[S: Ch.25]** already forbids the crude ones.

## 4.2 Mapping the twenty dimensions onto the existing eight performance dimensions

**[A]** The organisation already measures teams on eight dimensions **[S: Ch.25, App. A §18.2]** with proposed weights 20/15/15/15/10/10/10/5 — **PROPOSED, NOT FINAL, and not altered here.** The relationship between team performance dimensions and individual capability dimensions must be explicit, or the two will be confused.

| Team performance dimension **[S]** | Proposed weight **[S]** | Capability dimensions it *correlates with* | Capability dimensions it **does not** measure |
|---|---|---|---|
| **Mission impact** | 20% | LC-1, LC-19 | LC-2 integrity, LC-17 succession |
| **Execution** | 15% | LC-3, LC-5, LC-14 | LC-7 delegation (a leader can execute personally and delegate nothing — and score well) |
| **Business performance** | 15% | LC-5, LC-14 | LC-1 (revenue success may coexist with mission drift — **[S-ST: F-17]**) |
| **Financial discipline** | 15% | LC-11, LC-2 | LC-8 team development |
| **Member development** | 10% | LC-8, LC-16, LC-7 | LC-10 safety, LC-13 privacy |
| **Community trust** | 10% | LC-18, LC-6, LC-9 | LC-4 judgement — **and community trust is popularity-contaminated** (§4.5) |
| **Safety/compliance** | 10% | LC-10, LC-13, LC-14 | LC-19 long-term thinking |
| **Innovation** | 5% | LC-15, LC-16 | LC-2 integrity — **innovation is the dimension most easily faked** (Part 20) |

**[C] Coverage analysis:** the eight team dimensions touch **13 of 20** capability dimensions. **Seven are not measured by the team score at all: LC-2 (integrity), LC-7 (delegation), LC-12 (evidence discipline, only partially), LC-13 (data/privacy discipline), LC-17 (succession behaviour), LC-19 (long-term thinking, only via mission impact), LC-20 (uncertainty).**

> **[A] This is the single most important finding in Part 4.** The performance system, exactly as designed in the source, **cannot see the capabilities that most determine whether a leader will survive the next level.** Integrity, delegation, privacy discipline, succession behaviour and behaviour under uncertainty are precisely the capabilities that fail silently — they produce no metric until they produce a crisis. **This is the mechanical reason why "best team → City Head Team" **[S: Ch.26; Const. Art.15]** can select the wrong person while every rule is followed correctly.**

**[P] Consequence:** capability assessment for promotion **cannot be derived from the team score.** It requires the independent evidence of Part 5 and the assessment of Part 33. **L-02(3)** states this as a rule: *the team score may nominate; it may not assess.*

## 4.3 Treatment classes — not every dimension should be scored

**[P]** The brief requires that weighting models be tested and that illustrative weights not be presented as final. **[A]** The more fundamental question, which the source does not ask, is **whether a dimension should be scored at all.** Four treatment classes:

| Treatment | Meaning | Applied to | Why |
|---|---|---|---|
| **GATED** | Pass/fail. Failure blocks appointment regardless of everything else | **LC-2 integrity, LC-10 safety discipline, LC-11 financial discipline, LC-13 data/privacy discipline** | These are **irreversible-harm** capabilities, on the same criterion **[S-B: §26.2]** uses for minimum viable control: *absence causes irreversible harm to money, safety, identity, privacy or public truth.* A weighted score cannot trade them off — a leader with excellent execution and fabricated receipts must not average out to "acceptable" |
| **SCORED** | Graded, with a stated rubric, contributing to a readiness statement | **LC-3, LC-4, LC-5, LC-6, LC-7, LC-8, LC-9, LC-14, LC-15, LC-16, LC-19, LC-20** | These vary continuously and improve with development |
| **MONITORED** | Observed and reported, never scored | **LC-1 mission alignment, LC-18 community trust** | **LC-1** is better tested by the *pattern of decisions* than by a rating; **LC-18** is popularity-contaminated (§4.5) and must not become a target (**[S-ST: Goodhart]**, Part 20) |
| **NARRATIVE-ONLY** | Recorded as a written observation with an evidence link; no rating | **LC-12 evidence discipline** where it overlaps a gate; **LC-17 succession behaviour** in teams too small to have a successor pool | Prevents a small team's leader being scored down for a structural impossibility (Part 11 §11.7) |

**[A] Why gated rather than weighted for the four irreversible dimensions:** consider a weighted model in which integrity carries 15%. A candidate scoring 100% on execution, business, mission and community trust and **0% on integrity** still reaches roughly 85% — the highest score in most cohorts. **[C]** Any weighted model in which a fabrication can be averaged away is not a control; it is a discount. **This is why PG-1…PG-12 (Part 7) exist as gates and not as weights, and it is a *structural* argument, not a moral one.**

## 4.4 Testing the weighting question

**[P]** Three weighting models tested, as the brief requires. **No weights are proposed as final; the source's own remain `PROPOSED` and unaltered.**

| Model | Description | Strength | Fatal weakness | Verdict |
|---|---|---|---|---|
| **W-1 Equal weights** | All twenty dimensions weighted 5% | Simple; transparent; no dimension is privileged | **Treats fabrication of evidence as equal to occasional lateness.** Produces the averaging problem of §4.3 | ❌ Rejected |
| **W-2 Judgement-based weights** | Weights set by governance judgement (the source's own approach for the eight team dimensions **[S: Ch.25]**) | Reflects what the organisation cares about; already in use; approved process exists (**"FINAL WEIGHTS REQUIRE APPROVAL"**) | Weights are untestable until data exists; and **[A]** in a leadership context any weight attached to a *socially mediated* dimension (LC-18 community trust, LC-6 communication) becomes a popularity weight | ⚠️ **Retained for TEAMS, unchanged [S]**; **not extended to individuals** |
| **W-3 Treatment-class model (no individual weights)** | Gate the irreversible dimensions; grade the developmental ones; monitor the contaminable ones; narrate the structurally-constrained ones | Cannot be averaged away; produces an actionable gap statement; no number to argue about; compatible with **[S-C: §55.1]** no-composite-human-score | Requires assessors; slower; more expensive in people | ✅ **Adopted as [P] for individual capability** |

**[A] The reasoning for the split, stated plainly:** the source's weighted eight-dimension model is a **team diagnostic and support-allocation instrument** **[S: Ch.25 "identifies which teams are performing best … supports learning and enables earned leadership"; S-C: §23.2]**, and for that purpose a composite is appropriate — a team is a unit of work, not a person. **An individual is not.** **[S-C: §23.2]** already establishes that the performance system "does not apply to individuals at any level — a person is never scored." **L-02 implements that prohibition rather than contradicting it.**

**[P] Rule D-9 (No Individual Composite).** No composite score, index, rating, grade, star, badge or number may be produced for any individual in respect of leadership, performance, readiness, conduct, potential or worth. **This is proposed as a Tier-1 candidate under [S-A: A-13]** and inherits **[S-C: CR-1…CR-4]**.

## 4.5 The popularity contamination problem

**[A]** Two of the twenty dimensions are contaminated by likeability in a way the other eighteen are not:

| Dimension | Contamination mechanism | Control |
|---|---|---|
| **LC-6 Communication** | An assessor who enjoys the candidate's company rates their communication higher, regardless of whether the candidate can explain a decision to someone who disagrees | The rubric is **behavioural**: "explained a decision to a person who disagreed, without invoking authority, and the person could restate the reasoning" — evidenced from a **recorded instance**, not an impression |
| **LC-18 Community trust** | **[S: Ch.25]** sources it from "Verified feedback; detect mass fake reviews and pressure" — i.e. from people the leader can affect. In a neighbourhood, the most liked person scores highest and the most effective person may score lowest, because effectiveness often means saying no **[S-ST: F-03]** | **MONITORED, never scored** (§4.3); treated as **signal and input, never command** (Part 35 §35.4); paired with **LC-2 integrity** as a gate, so a liked person with a fabrication cannot pass; and the *negative* case is protected — a complaint route that does not pass through the leader (Part 18) |

**[I]** The uncomfortable corollary, and it is the same as ES.5: **the two dimensions a neighbourhood organisation most naturally uses to identify leaders are the two most corrupted by social position.** The remedy is not to remove them — community trust is genuinely a strategic asset **[S: Ch.25 "Local credibility is a strategic asset"]** — but to **prevent either from being decisive alone**, and to require the gated dimensions to be passed first.

## 4.6 Level-specific capability profiles

**[P]** The twenty dimensions are **not equally important at every level.** Profiles below; full treatment in Part 32.

| Dimension | Mohalla | City | State | National | Reasoning |
|---|---|---|---|---|---|
| LC-5 Execution | **Decisive** | High | Moderate | Low | Local leadership *is* execution **[S: Ch.8 10-step loop]** |
| LC-7 Delegation | High | **Decisive** | **Decisive** | **Decisive** | Span grows; a City head who executes personally blocks every team beneath |
| LC-9 Conflict management | High | **Decisive** | **Decisive** | **Decisive** | City adjudicates between teams that are socially separate **[S: Ch.7]** |
| LC-14 Problem-solving | High | High | **Decisive** | **Decisive** | State allocates scarce specialist resource **[S: Ch.6]** |
| LC-19 Long-term thinking | Moderate | High | **Decisive** | **Decisive** | Only the upper layers can see multi-cycle effects |
| LC-17 Succession behaviour | High | **Decisive** | **Decisive** | **Decisive** | At the top, absence of succession is institutional risk **[S-A: A-14]** |
| LC-18 Community trust | **Decisive** | High | Moderate | Low | Local legitimacy is produced at the mohalla **[S: Ch.8]** |
| LC-13 Data/privacy | Moderate | High | High | **Decisive** | Data estate and Significant Data Fiduciary exposure concentrate upward **[S-A: A-17; X-inherited: DPDP]** |
| LC-1 Mission alignment | High | High | High | **Decisive** | National sets standards **[S: Ch.5]** |
| LC-20 Uncertainty | Moderate | Moderate | High | **Decisive** | Crisis leadership and unresolved governance concentrate at the apex **[S-A: A-14 S8]** |

**[A]** Reading the table as a whole produces the level-transition finding: **the decisive capabilities change between levels, and the capability that is decisive at Mohalla (execution, community trust) is only moderate at National, while the capabilities decisive at National (long-term thinking, privacy, uncertainty, mission alignment) are only moderate at Mohalla.** **[I]** This is why "best Mohalla team → City Head Team" **[S: Const. Art.15 APPROVED]** is a **nomination mechanism and not a capability mechanism** — and why **LG-2 (capability gate)** in Part 10 must assess against the **destination level's profile**, never the origin level's score.

## 4.7 The capability model's own failure modes

**[A]** Adversarially tested, as required:

| Failure | Mechanism | Control |
|---|---|---|
| **CF-1 Rubric becomes a checklist theatre** | Candidates and assessors learn the rubric and produce evidence for it rather than capability | Rotate assessors; **require at least one unannounced observation** (AP-7 incident simulation, Part 15); sample reassessment by a second assessor |
| **CF-2 Gates become veto weapons** | A rival alleges an integrity or safety concern to gate a candidate out | **Part 18 §18.6** interim measures instead of automatic voiding; **hold, not disqualification**; graded consequence for proven-false allegations **[S-ST: F-22(7) ii]** |
| **CF-3 Twenty dimensions exceed assessor capacity** | An assessor cannot evaluate twenty things properly, so evaluates three and records twenty | **Role-class profiles (§3.6, §4.6) reduce the assessed set to the decisive subset per role**; the remainder is monitored or narrative |
| **CF-4 The model excludes the unconventional** | A person who is rude, awkward, part-time and brilliant fails LC-6 and LC-18 | LC-6 is behavioural, not stylistic (§4.5); LC-18 is monitored, not scored; **Part 3 §3.7 AF-5** protects introversion explicitly |
| **CF-5 Capability is confused with capacity** | A capable person with no time is rated ready | **E-7 availability tested against LLI (Part 24)**, not against willingness |
| **CF-6 The model becomes a personality instrument** | Assessors begin inferring traits | **Rule D-6**: output is a gap statement about *behaviours with evidence links*, never a character judgement; **[S-C: §24.2]** "no character field, no attitude field, no 'potential' score" |

---

# PART 5 — EVIDENCE ARCHITECTURE

## 5.1 The five evidence classes

**[P] Amendment L-03 — Leadership Evidence Model.** The brief requires activity, outcome, behaviour, trust and leadership-development evidence to be distinguished. **[A]** The distinction is not academic: **each class has a different fabrication cost, a different verification cost, and a different admissibility for different decisions.**

| Class | What it proves | Typical records | Fabrication cost | Verification cost | Admissible for |
|---|---|---|---|---|---|
| **LE-1 ACTIVITY** | That something was done | Task logs, attendance, requests logged, site visits, shifts completed, delegations issued **[S: Ch.24 daily]** | **Very low** — the actor records it | Low-medium | Monitoring; reliability (LC-3); **never sufficient for appointment alone** |
| **LE-2 OUTCOME** | That something resulted | Verified service outcomes, customer acceptance, reconciliation without variance, project completion with evidence, follow-up verification **[S: Ch.15 step 10; Ch.17 step 10; App. A §18.3]** | **Medium-high** — requires a third party to confirm | Medium-high | Performance scoring; LG-5; financial discipline gate |
| **LE-3 BEHAVIOUR** | How the person acted when it mattered | Decision records with reasons **[S-A: A-15 M1]**; incident reports **[S-A: A-09]**; stop-work use; corrections issued **[S: Ch.24]**; self-reported errors; refusals recorded | **High** — behaviour under stress is hard to stage repeatedly | Medium | **All four gates (LC-2, LC-10, LC-11, LC-13)**; readiness R-1, R-10, R-11, R-12, R-14 |
| **LE-4 TRUST** | That others relied on this person and were not harmed | Complaint records and their outcomes; beneficiary and community feedback collected independently **[S-C: HM-13]**; whether dissenters survived **[S-A: A-16 test 3]**; audit findings and their resolution; **absence of retaliation** | **Very high** — requires many independent people over time | High | LG-3 conduct; LC-18 monitoring; **mandatory for every leadership appointment** |
| **LE-5 LEADERSHIP-DEVELOPMENT** | That other people became more capable | Named individuals who progressed; training delivered and its effect; delegation that led to a role; successors developed; lessons adopted by other teams **[S-A: A-15 M5]** | **High** — requires another person's record to change | High | LG-6 team development; LG-7 succession; LC-8, LC-16, LC-17 |

**[P] Rule D-10 (Evidence Admissibility Rule).**

| Decision | Minimum admissible evidence |
|---|---|
| Confirm a completed task | LE-1 |
| Score a team's period performance | LE-1 **+** LE-2 |
| Recognise a contribution | LE-1 **+** LE-2, evidence-linked **[S-C: §23.3 rule 1]** |
| **Appoint to any leadership role** | LE-2 **+** LE-3 **+** LE-4 |
| **Promote to a higher level** | LE-2 **+** LE-3 **+** LE-4 **+** LE-5 |
| **Appoint to a control role (HR, Funds, Safety, Audit)** | LE-3 **+** LE-4, with LE-3 weighted — because the role is *defined* by behaviour under social pressure |
| Remove or suspend a leader | LE-3 **+** LE-4, per the misconduct procedure **[S: Ch.33 PROPOSED; App. E]** **[V]** |
| Declare a successor ready | LE-5 **+** LE-3 (observed acting in scope, AP-2/AP-3) |

**[A]** The rule's most consequential line is the fourth: **LE-1 activity evidence is inadmissible for appointment.** **[S: Ch.25]** already says raw activity count cannot determine leadership; **Rule D-10 makes it a procedural requirement rather than a warning**, so an appointment record with only activity evidence is incomplete and challengeable.

## 5.2 What the source already accepts as evidence

**[S: App. F]** fourteen evidence record types with sensitivity markings. **[S: Ch.15]** outcome verification and anti-fake-impact rules, including the express statement that counting planted saplings as long-term survival is unacceptable evidence, and that reports must "include failures and partial outcomes". **[S: App. A §18.3]** metric specification table with data source, calculation, frequency, evidence, reviewer and anti-gaming mechanism per metric.

**[A]** Extracting the leadership-relevant rows of **[S: App. A §18.3]** verbatim in substance:

| Metric **[S]** | Data source | Calculation | Frequency | Reviewer | Anti-gaming mechanism **[S]** |
|---|---|---|---|---|---|
| Verified service outcomes | Project records | Completed verified outcomes ÷ approved targets, **adjusted for difficulty** | Monthly | City/State review | Random beneficiary/partner checks; no double-counting |
| Need-response time | Request logs | Median time from request receipt to decision/action | Weekly/monthly | City Operations | Exclude duplicate/spam; audit unresolved queue |
| Project completion quality | Project files | Completed on time with required evidence and no unresolved safety/finance exception | Monthly | City Planner | **Quality threshold; not just count** |
| Volunteer reliability | Attendance/task logs | Completed assigned shifts/tasks ÷ accepted assignments | Monthly | Volunteer Manager / HR | No fake attendance; cross-check field lead |
| Revenue quality | Invoices/payment records | Collected legitimate revenue from approved ventures minus refunds/disputes | Weekly/monthly | Finance + Business | Customer confirmation; no circular/fake revenue |
| Delivery margin awareness | Finance ledger | Revenue minus approved direct costs; interpreted with stage of venture | Monthly | Finance | Do not reward underreported costs |
| Reconciliation accuracy | Finance records | Transactions reconciled without unexplained variance | Weekly/monthly | Finance reviewer | **Separation of duties; random audits** |

> **[A] One source detail of large consequence has been under-used by every prior instrument: "adjusted for difficulty" appears in the very first metric row of [S: App. A §18.3].** The source therefore **already contemplates difficulty adjustment** — it simply never defines it. **Part 9 (cohort normalisation) is not an external imposition on the performance system; it is the completion of a mechanism the source named and left empty.** This substantially strengthens the case for **L-06**, because it is not a change of principle — it is a specification of one.

## 5.3 The evidence hierarchy for a single leadership decision

**[P]** When evidence conflicts, this order governs. **Reasoning: the higher a class, the more independent parties were required to produce it, and the harder it is to fabricate.**

```
LE-4 TRUST   (many independent people, long period)     ← highest
LE-5 DEVELOPMENT (another person's record changed)
LE-3 BEHAVIOUR   (recorded at the moment, with reason)
LE-2 OUTCOME     (third-party confirmation)
LE-1 ACTIVITY    (self-recorded)                        ← lowest
```

**[P] Conflict rules:**

| Conflict | Resolution |
|---|---|
| Strong LE-1/LE-2, weak LE-4 | **Do not appoint.** High output with no trust evidence is the profile of the popular-but-unexamined leader and of the fabricator. **Gate the appointment and open a development plan** |
| Strong LE-4, weak LE-2 | **Do not appoint to an execution-heavy role**; may be ready for an advisory, Elder/Mentor or specialist standing **[S-C: §6.10]** where outcome production is not the function |
| Strong LE-2, absent LE-3 | **Investigate before appointing.** Outcomes with no decision record means either the record-keeping failed (**[S-A: A-15 M1]** violation — itself a finding) or the outcomes were not caused by decisions the leader made |
| LE-5 present but LE-4 contradicts | **Trust wins.** A leader who developed people but harmed others has produced capability at an unacceptable cost — **[S: Ch.2 principle 4]** "stand against injustice without becoming unjust" |
| Self-reported error (LE-3) present | **Treated as positive evidence**, not negative — subject to §5.5 |

## 5.4 What may not be used as leadership evidence

**[P]** Consolidated prohibition list. Every item is sourced.

| Prohibited evidence | Source |
|---|---|
| Raw revenue | **[S: Ch.25]** "Raw revenue … cannot determine leadership" |
| Follower count, social-media views | **[S: Ch.25]** |
| Volunteer count, application count | **[S: Ch.25]** |
| Raw activity count | **[S: Ch.25]** |
| Planned activities counted as completed impact | **[S: Ch.15]** |
| Saplings planted counted as survival | **[S: App. F]** |
| Anonymous unverifiable rumour treated as fact | **[S: App. F]** — but note **[S-ST: F-21(7) iv]**: anonymous reports are **investigable leads**, never **sufficient evidence**; the two rules are reconciled, not contradicted |
| Any count of people recruited, active, paused or in a downline | **[S-C: MLM-1]** |
| Referral or introduction counts | **[S-C: MLM-6]** — "Attribution of an introduction may be recorded for thanks, never for value" |
| Belief, political identity or its inference | **[S-A: A-01 N8]** |
| Demographic characteristics | **[S-A: A-18 §17.4 prohibited collection]**; Part 3 §3.8 Rule D-8 |
| A refusal, a pause, a reduction in hours, or an exit | **[S-C: H-17, §8.3]** — "refusal must be cheap, silent and non-recorded as a negative" |
| A composite individual score | **Rule D-9**; **[S-C: §55.1]** |
| AI output as a determination | **[S: Const. Art.12 APPROVED]**; **[S-A: A-21 §20.3]** |
| Attendance at a ceremony, ritual or event as loyalty evidence | **[S-C: AC-4 forced loyalty; H-13 six-test gate for rituals]** |
| Willingness to be available without limit | **Part 25** — availability expectation is a burnout mechanism, not a virtue |

## 5.5 The self-reported-error rule

**[P] Rule D-11 (Correction Credit).** A **self-reported** error, reported before detection by another party, and **corrected**, is recorded as **positive LE-3 evidence** of LC-2 integrity and R-12 — subject to three limits:

1. It may not offset a **gated** failure. Self-reporting a fabrication does not un-gate it; it changes the *response* (Part 19), not the *finding*.
2. It applies only where the report preceded detection. **[S-A: A-15 M5]** lessons register and **[S: Ch.15]** "report results honestly, including failures" are the source basis.
3. It must not create an incentive to generate reportable errors. **The credit is for the correction, not for the error** — recorded as "error self-reported and corrected", never as an achievement.

**[A]** Why this rule exists: **[I]** in any system where errors are punished and concealment is undetectable, the rational strategy is concealment — which is exactly **[S-ST: F-05]**'s predicted outcome ("a network that is *documentarily* perfect and *operationally* hollow — or the reverse") and **[S-B: §23]**'s finding that teams conceal weakness when closure is feared. **A leadership system that cannot see its own errors cannot correct them, and correction is the entire content of LC-14 and LC-16.**

**[A]** The empirical check on the rule is **R-12's failure indicator**: a record with **no** self-reported error across many cycles is statistically implausible and is itself treated as a concealment signal — not as excellence. This mirrors **[S-A: A-16 test 3]** ("a zero count is a warning") and **[S-C: §43.3]** the zero-count warning.

## 5.6 Evidence portfolio — the instrument that makes fairness possible

**[P] Amendment L-03(2) — Leadership Evidence Portfolio.** A candidate's own, self-assembled, record-linked set of evidence, drawn entirely from records the architecture already requires:

| Portfolio section | Contents | Source record | Class |
|---|---|---|---|
| **Decisions** | Five to ten decisions with the reason recorded at the time, including at least one that turned out wrong and what happened next | **[S-A: A-15 M1]**; **[S: Ch.8 decision log]** | LE-3 |
| **Outcomes** | Verified outcomes with follow-up status, **including failures and partial outcomes** | **[S: Ch.15 step 10; App. F]** | LE-2 |
| **Money** | Reconciliation record; a period with no unexplained variance; an instance of refusing an irregular request | **[S: Ch.18, Ch.19 step 13]** | LE-2, LE-3 |
| **Safety** | Incidents reported (including own team's); a stop-work instance; DO-NOT compliance | **[S-A: A-09; Ch.16; SOP-13]** | LE-3 |
| **People** | Named individuals who progressed, with their own record as evidence; training delivered; delegations issued with dates | **[S: Ch.25 member development; Ch.22 `delegated_authority`]** | LE-5 |
| **Disagreement** | An instance of being disagreed with, and what happened to the person who disagreed | **[S: Const. Art.17; S-A: A-16 test 3; S-C: §43.1]** | LE-4 |
| **Correction** | A self-reported error and its correction | **[S-A: A-15 M5]** | LE-3 |
| **Community** | Independently collected feedback, where it exists; complaint outcomes | **[S-C: HM-13; Ch.25 community trust]** | LE-4 |

**[P] Portfolio rules:**
1. **Every entry cites a record.** An uncited entry is not evidence (**[S-C: §23.3 rule 1]**).
2. **The candidate assembles it; the organisation verifies it.** This inverts the usual direction and is the point: a person who is not visible to leadership can still produce a case. **It is the primary remedy for AF-6 (proximity) and AF-4 (articulateness) in Part 3 §3.7.**
3. **It contains failures.** A portfolio with no failure is treated as incomplete (§5.5 reasoning).
4. **It is not public.** It is a C2/C3 internal document under **[S-A: A-17]** classification, visible to the candidate, the assessors, the appointing authority and audit — never published, never ranked, never shared outside (**[S-C: CR-4]**).
5. **It survives the decision.** Retained per the schedule; the candidate keeps a copy (**[S-C: §24.2 positive property 1]**).
6. **It is portable in the same sense as [S-C: H-10]** — the *facts* in it can be turned into a reference or credential; the *assessment* of it cannot.

**[A] Cost analysis, per [S-B: §26.3]:** the portfolio is **assembled from existing records** — no new data is collected, and no new form is required beyond an index. **It therefore satisfies the control-budget rule** and is adoptable at Stage 1. **[A]** Its real cost is assessor time, which Part 40 and Part 49 cost explicitly.

## 5.7 Evidence for teams versus evidence for leaders

**[P]** Rule D-12 (Attribution Separation). Team evidence and leader evidence are **separate objects**, because the inference between them is not valid in either direction.

| Situation | What it does **not** prove |
|---|---|
| A team performed well | That the leader caused it (the team may have carried the leader) |
| A team performed badly | That the leader failed (root cause may be resource, economics, external event, systems or workload — Part 19 §19.5) |
| A leader is excellent | That their team will remain excellent after they leave (**[S-B: §24.2]**) |
| A leader failed | That the team is unhealthy (Part 19 §19.5 case 1) |

**[A]** The practical consequence is that **Part 7 (team performance) and Part 4 (individual capability) must be measured with different instruments, on different windows, by different people, and reported separately.** Collapsing them produces both the injustice of blaming an individual for a structural failure (**[S-ST: F-23]**) and the injustice of promoting an individual for a team's success they did not cause (**ES.2 fault 1**).

---

# PART 6 — PERFORMANCE ARCHITECTURE

## 6.1 What exists, preserved exactly

**[S: Ch.25]** performance architecture, six steps, verbatim in substance:

```
1. EVIDENCE      Projects, finance, HR, training, safety, business, feedback, inventory and AI logs.
2. METRICS       Mission impact, execution, business, finance, member development, trust, safety/compliance, innovation.
3. EVALUATION    Monthly calculation with evidence links, exceptions and reviewer sign-off.
4. TEAM SCORE    Balanced score with proposed weights requiring approval.
5. LEADERBOARD   Published after anomaly review, corrections and appeals.
6. LEADERSHIP / SUPPORT / DEVELOPMENT
                 Leadership opportunity, support assignment, training, succession readiness or recovery.
```

**[S: Const. Art.14 APPROVED ARCHITECTURE]** — "Performance is monthly and multidimensional." **PROPOSED POLICY** — "weights, metrics, anti-gaming and appeals must be approved before leadership transfer."

**[A]** Two observations that govern everything in Parts 6–9:

1. **Step 6 is already broader than leadership.** The source's own terminal step lists *five* outputs: leadership opportunity, **support assignment**, **training**, **succession readiness**, or **recovery**. **[I]** The architecture never intended the score to be a promotion machine alone; it intended it as a **diagnostic router**. **v1.3-D's contribution is to make the routing explicit** — because in practice an organisation with a leaderboard and a prize will use it for the prize and forget the other four branches.
2. **Const. Art.14's "monthly" is APPROVED ARCHITECTURE.** **[P]** Therefore **Part 8 does not abolish monthly performance** — it separates *what* is measured monthly from *what* is measured on longer windows, and it keeps the monthly cadence for the content the source assigns to it. Any change to Art.14 itself is a **constitutional amendment** requiring the **[S-A: A-13]** process, and is recorded as **LDR-01: UNRESOLVED**.

## 6.2 The one-number question, decided with reasoning

**[P]** The brief requires a decision on whether to use one composite score, multiple independent dimensions, or a hybrid — **not decided silently.** Three options tested:

| Option | Description | Strengths | Weaknesses | Applies to |
|---|---|---|---|---|
| **O-1 Single composite** | One number per team per period, the source's step 4 | Comparable at a glance; simple to publish; drives a clear ordering; **already approved as architecture** **[S: Const. Art.14]** | **Averaging hides gates** (§4.3); invites gaming of whichever dimension is cheapest to move; makes an unfair comparison look precise (Part 9); reduces a team to a number, which reads as reducing its people to numbers | **Teams** — retained |
| **O-2 Multiple independent dimensions** | Eight dimensions reported separately, no composite | No averaging; gates visible; supports diagnosis and routing (step 6) | No ordering → no "best team" → **[S: Const. Art.15]** transition mechanism loses its input; harder to communicate; requires a decision rule anyway, which recreates weighting informally and opaquely | **Rejected as a replacement**; **adopted as the reporting layer beneath the composite** |
| **O-3 Hybrid: gated dimensions + composite + published decomposition** | Gates applied first; composite computed on the remainder; **both the composite and the per-dimension decomposition published to the team and to its cohort** | Preserves Art.14 and Art.15 exactly; prevents averaging away an irreversible failure; makes the score explicable; keeps the ordering the transition mechanism needs; supports all five branches of step 6 | More complex; a team may not understand its own score (**[S-ST: M8]** named this risk); requires a plain-language explanation per team | ✅ **Adopted [P]** |

**[P] Rule D-13 (Hybrid Performance Rule).** Order of operations, per period:

```
STEP 1 · GATES          Apply PG-1…PG-12 (Part 7). Any gate failure →
                        the period's score is recorded but CANNOT confer
                        top status, leadership eligibility, award, ranking
                        position, bonus or public recognition.
STEP 2 · DIMENSIONS     Compute the eight dimensions [S: Ch.25] on the
                        evidence, with the anti-gaming controls [S] applied.
STEP 3 · COMPOSITE      Apply the PROPOSED weights 20/15/15/15/10/10/10/5
                        [S: Ch.25] — UNCHANGED, still PROPOSED, still
                        requiring approval.
STEP 4 · CONTEXT        Attach cohort, maturity band, baseline and
                        confidence (Part 9). A composite without context is
                        not publishable.
STEP 5 · ANOMALY REVIEW "Published after anomaly review, corrections and
                        appeals" [S: Ch.25] — preserved verbatim.
STEP 6 · ROUTING        Route to one or more of the five branches of
                        [S: Ch.25] step 6. Leadership opportunity is ONE
                        branch, never the default.
```

**[A]** Step 4 is the change with the largest fairness effect and the smallest cost: **the same number, reported with its cohort, maturity band, baseline and confidence, means something completely different from the same number reported alone.**

## 6.3 Score confidence — a number should say how much it knows

**[P] Amendment L-05(4) — Confidence Attribute.** Every composite carries a confidence attribute derived from evidence sufficiency, not from opinion:

| Confidence | Condition | Permitted use |
|---|---|---|
| **HIGH** | All eight dimensions evidenced from LE-2 or better; outcome follow-ups complete; no unresolved gate; period length ≥ the maturity band's minimum | All uses, including leadership nomination |
| **MEDIUM** | One or two dimensions evidenced from LE-1 only; or an outcome follow-up outstanding; or the team is in its ramp-up period | Diagnosis, support allocation, development. **Not** leadership nomination |
| **LOW** | Evidence materially incomplete; a gate unresolved; the team is provisional (Part 8 §8.5); or the period contains a structural break (transition, relocation, disaster) | **Internal only.** Not published in any comparative form; not used for any decision affecting a person |

**[A]** Why this matters more than it appears: **[I]** the most common injustice in small-organisation performance systems is a **decision taken on thin evidence that looks like a decision on thick evidence**. A confidence attribute makes the thinness visible at the moment of decision rather than at the moment of appeal. It also directly serves **[S-ST: F-22]** — an allegation that drops a team's confidence does not void its score, it *qualifies* it, which is the interim-measure logic Part 18 adopts.

## 6.4 The performance data flow — and the flow that is prohibited

**[P]** The brief requires an explicit flow and an explicit prohibition.

**PERMITTED FLOW:**
```
ACTIVITY  →  EVIDENCE  →  VALIDATION  →  AGGREGATION  →  ANALYSIS
   ↓                                                        ↓
FEEDBACK ← DECISION ← REVIEW ←──────────────────────────────┘
   ↓
IMPROVEMENT
```

**PROHIBITED FLOW:**
```
ACTIVITY  →  AI SCORE  →  AUTOMATIC PROMOTION          ✗ PROHIBITED
```

**[S]** The prohibition is **APPROVED ARCHITECTURE**, not a proposal: **"AI may recommend; humans decide. AI cannot autonomously make consequential HR, wage, legal, safeguarding, safety, major fund or leadership decisions"** **[S: Const. Art.12]**. **[S-A: A-21 §20.3]** lists the decisions reserved to human authority; **[S-A: A-22]** specifies the 17-field consequential-recommendation record.

**[P]** Each stage of the permitted flow, with its owner and its record:

| Stage | What happens | Owner | Record | Source |
|---|---|---|---|---|
| **ACTIVITY** | Work performed inside role, safety, finance, privacy and AI limits | Assigned roles | Task/project log, field log | **[S: Ch.27 step 4; Ch.24 daily]** |
| **EVIDENCE** | Request, verification, receipts, training, logs, customer acceptance, incident facts, AI sources | Role-holder | App. F record types | **[S: Ch.27 step 2]** |
| **VALIDATION** | Independent check: outcome verification, customer confirmation, beneficiary sampling, reconciliation | Reviewer **outside** the producing hand | Verification note; reviewer sign-off | **[S: Ch.15 step 9; Ch.25 step 3; App. A §18.3]** |
| **AGGREGATION** | Dimension computation; **cohort, maturity band, baseline, confidence attached** | City Operations / performance function | Score file **[S: App. E "Leaderboard finalisation — Score file"]** | **[S: Ch.25 step 4]** |
| **ANALYSIS** | Anomaly detection; trend; gaming signals; **AI may assist here** | Performance function + AI, human-reviewed | Anomaly queue **[S: Ch.24 Auditor dashboard]** | **[S: Ch.25 step 5; Ch.21]** |
| **REVIEW** | Human assessment: exceptions, corrections, appeals | Reviewer with sign-off authority | Review record with reasons | **[S: Ch.25 step 3 "reviewer sign-off"]** |
| **DECISION** | Routing to leadership / support / training / succession / recovery | Appointing authority per **[S: App. E]** | **Promotion Decision Record** (Part 10 §10.8) or support assignment record | **[S: Ch.25 step 6]** |
| **FEEDBACK** | The team receives its decomposition, its gaps and its routing — **in its own language** | Reviewer | Feedback record | **[S-C: §30; S-A: A-15 memory rule 5]** |
| **IMPROVEMENT** | Support, training, resource, process correction | City/State per **[S: Ch.14 step 7]** | Improvement record; lessons entry | **[S: Ch.14; S-A: A-15 M5]** |

**[A]** The stage most often skipped in practice is **FEEDBACK**, and skipping it is what converts a performance system into a surveillance system. **[S-ST: F-14]** identified the same fault at the national level ("all of these pull data up; none push people down"). **[P] Rule D-14: no period's score is final until the team has received its decomposition and its routing.** A score a team has not seen is a score that cannot be corrected, and **[S: Ch.25]** requires corrections before publication.

## 6.5 Metric diversity — the balanced measurement architecture

**[P]** The brief requires leading, lagging, quality, safety, outcome, human, financial and governance indicators, with no single metric dominating. **[A]** Mapped to the source's own metric set **[S: App. A §18.3]** and extended where the source is silent:

| Indicator type | Purpose | Source-present metrics | Missing and proposed |
|---|---|---|---|
| **Leading** | Predicts future performance | Need-response time **[S]**; volunteer reliability **[S]** | **Delegation rate** (active delegations ÷ eligible tasks); **successor state** (Part 11); **`H_gov` trend** **[S-B: §27.2]** |
| **Lagging** | Confirms past performance | Verified service outcomes **[S]**; revenue quality **[S]**; project completion quality **[S]** | **Outcome follow-up completion rate** **[S-ST: F-20(7) ii]** |
| **Quality** | Prevents volume substituting for value | "Quality threshold; not just count" **[S]**; reconciliation accuracy **[S]** | **Revision rate** `h_rev` **[S-B: §27.4]**; **beneficiary-confirmed rate** |
| **Safety** | Non-negotiable | Incident records **[S: SOP-13]**; stop-work use | **Incident self-report rate** (a *high* rate is good evidence — Rule D-11); **DO-NOT compliance** **[S-A: A-08]** |
| **Outcome** | Mission substance | Verified outcomes adjusted for difficulty **[S]** | **Sustainability-window result** (Part 8); **resolved/reduced/unchanged/worsened** **[S-C: HM-8]** |
| **Human** | Whether people are alright | Member retention "healthy active retention, not inactive names" **[S]** | **`r_ret` by reason** **[S-B: §27.3]**; **dissent count** **[S-A: A-16 test 3]**; **refusal exercised without consequence** **[S-C: HM-12]**; **belonging** **[S-C: HM-3]** |
| **Financial** | Viability | Revenue quality; delivery margin awareness; reconciliation accuracy; reserve compliance **[S]** | **Solvency line reached** `S-1…S-6` **[S-B: §8.3]**; **accrued unpaid compensation** **[S-B: B-05]**; **`CM̄_j / h_proj`** **[S-B: §11.4]** |
| **Governance** | Whether the control system is real | Audit findings **[S: Ch.27]** | **`σ = H_gov/(N_act × T_avail)`** **[S-B: §25.1]**; **segregation status** **[S-B: §27.2]**; **decision-rationale completeness** **[S-A: A-15 M1]**; **vacancy ageing** **[S-ST: F-03(9)]** |

**[P] Rule D-15 (No Single Metric Dominance).** No one metric may:
(a) carry more than the source's largest proposed weight (**20%, mission impact** **[S: Ch.25]**) in any composite;
(b) be the sole basis of any decision affecting a person;
(c) be published as a rank without its cohort, maturity band and confidence (Rule D-13 step 4);
(d) become a **direct target** if it appears on the Goodhart Prohibition List (Part 20 §20.1).

## 6.6 The review architecture — daily, weekly, monthly, quarterly, annual

**[S: Ch.24]** five cadences, preserved exactly, with the leadership content mapped and the burden stated:

| Cadence | Source purpose | Source contents | v1.3-D leadership content | Burden classification **[S-B: §25.2]** |
|---|---|---|---|---|
| **Daily** | "Operational memory" | Tasks, attendance, field notes, requests, incidents, stock movement, customer delivery notes | **None added.** Daily is not a leadership-review instrument | **Deferrable to Stage 3** **[S-B: §26.2 deferred-control table]** |
| **Weekly** | "Money, work and immediate accountability" | Revenue, expenses, work verification, payments, allocations, projects, incidents, risks | Delegation status; open incidents; **LLI check** (Part 24) only where an alert fires | Fixed by cadence; **cadence reducible to monthly below contribution-positive** **[S-B: §25.2 lever 1]** |
| **Monthly** | **"Performance and leadership"** | Metric score, leaderboard evidence, finance, team health, HR, training, safety, business | **The primary leadership review**: RV-1 normal review; gates PG-1…PG-12; routing per step 6; succession state update | **This is where `H_lead` and `H_audit` concentrate** |
| **Quarterly** | "Strategic review" | Audit, safety trends, financial health, venture portfolio, social outcomes, expansion readiness | **RV-2 enhanced review** for primary leadership and control roles; **Gate R reassessment**; cohort and baseline review; **expansion gate** (Part 14 §14.7) | City/State-prepared; **team-level preparation deferred upward** **[S-B: §26.2]** |
| **Annual** | "Full organisational accountability" | Impact, finance, reserves, social funds, member growth, safety, business, governance, risk | **The four institutional tests** **[S-A: A-16 §15.3]**; **continuity test** **[S-A: A-14 §13.8]**; **LDI/LLI organisational report** (Part 38); certification renewal review | Institutional layer |

**[P] Rule D-16 (Cadence Proportionality).** Leadership review cadence scales with **role class and maturity**, not with ambition:

| Role class | Normal review | Enhanced review | Triggered review |
|---|---|---|---|
| Supporting Member, Coordinator | On task completion; no periodic leadership review | — | On complaint or finding |
| Sub-Role / Deputy | Monthly (within the team's monthly cycle, no separate report) | Quarterly where the sub-role holds a control function | On trigger |
| Primary Role — Mohalla | Monthly | Quarterly | On trigger |
| Primary Role — control function (HR, Funds, Safety, Audit) at any level | Monthly | **Quarterly, mandatory** | On trigger |
| City / State leadership | Monthly | Quarterly | On trigger |
| National leadership, Level 8 Builder, apex | Monthly | **Quarterly, mandatory, plus the four annual institutional tests** | On trigger |

**[A]** The burden statement, per **[S-B: §26.3]**: **Rule D-16 adds no new report.** It assigns *existing* cadences to *existing* roles, and its only cost is the quarterly enhanced review for control roles — which **[S-ST: F-03]** already identifies as the least supported people in the system, and which **[S-B: §25.5]** identifies as carrying the heaviest governance load. **The enhanced review is as much protection as scrutiny**: it is the forum in which a control role-holder's workload, retaliation exposure and relief are recorded. **A control role that is reviewed only when something goes wrong is a control role nobody is looking after.**

---

# PART 7 — TEAM PERFORMANCE

## 7.1 The thirteen candidate dimensions, and how each should be treated

**[P]** The brief lists thirteen team-level dimensions. **The source's approved dimension set is eight** **[S: Ch.25]**. The relationship below preserves the eight exactly and treats the additional five as **gates, monitors or narratives** — never as new weights, because adding a weight would alter a `PROPOSED / NOT FINAL` instrument **[S: Ch.33]**.

| Brief dimension | Source dimension it belongs to **[S: Ch.25]** | Treatment | Reasoning |
|---|---|---|---|
| **Mission Impact** | Mission impact (20%) | **SCORED** | Core purpose; "prevents money-only optimisation" **[S]** |
| **Execution** | Execution (15%) | **SCORED** | "Reliability, completion and quality" **[S]** |
| **Quality** | Within Execution and Business performance | **GATED + SCORED** | "Quality threshold; not just count" **[S: App. A §18.3]**; a serious quality failure (customer harm, safeguarding) is a gate, not a deduction |
| **Safety** | Safety/compliance (10%) | **GATED + SCORED** | "Unsafe success is not success" **[S]**; a serious unresolved safety failure **voids status**, per **[S: Ch.26]** "high score void if fraud/safety breach/manipulation" |
| **Financial discipline** | Financial discipline (15%) | **GATED + SCORED** | "Money integrity and worker payment trust" **[S]**; materially unreliable records are a gate |
| **Member development** | Member development (10%) | **SCORED** | "Training, retention and role growth" **[S]**; "Growth depends on trained people, not one heroic leader" **[S: App. A §18.2]** |
| **Team health** | Within Member development + Community trust | **MONITORED** | Health is observable but not reliably quantifiable at small N; scoring it invites a fabricated number |
| **Community trust** | Community trust (10%) | **SCORED (team) / MONITORED (individual)** | "Local credibility is a strategic asset" **[S]**; popularity contamination is an *individual-assessment* problem (§4.5), not a team-score problem |
| **Innovation** | Innovation (5%) | **SCORED** | "Useful improvements should be rewarded but not gamed" **[S]** — the lowest weight is itself the anti-gaming control |
| **Compliance** | Within Safety/compliance + Financial discipline | **GATED** | Compliance failures are binary and irreversible-harm-bearing |
| **Reliability** | Within Execution | **SCORED** | Volunteer reliability metric already specified **[S: App. A §18.3]** |
| **Documentation** | Within Execution / Financial discipline | **MONITORED at low maturity, GATED at high maturity** | **[S-B: §25.3]**: documentation burden is the largest `H_gov` component; gating it at Stage 0–2 would penalise a team for the minimum-viable-control decision the organisation itself made |
| **Succession readiness** | **Not in the source's eight** | **GATED (Part 11)** | **This is v1.3-D's principal addition to team performance.** It is gated, not weighted, so that a team cannot buy its way out of it with volume — and so that a small team is not punished numerically for a structural impossibility (§11.7) |

**[A]** The addition of **succession readiness** as a gate is the most consequential change in Part 7 and requires justification against the source-integrity rule:

| Test | Result |
|---|---|
| Does it contradict a FINAL/LOCKED/REQUIRED/PROHIBITED source item? | **No.** The eight weights are unchanged. **[S: Ch.25 step 6]** already lists "succession readiness" as an *output* of the performance system; **[S: Ch.26]** already requires transition safeguards; **[S: Ch.9]** already has a Succession column for every role; **[S: Ch.22]** already has a `succession_status` field |
| Does it silently resolve an UNRESOLVED item? | **No.** "Leadership transition rules — NOT FINAL" **[S: Ch.33]** remains not final; the gate is `PROPOSED` |
| Does it create new burden? | **Yes, and it is stated:** one field per covered role per review cycle, populated from the existing `succession_status` field. **Automated from an existing record → passes [S-B: §26.3]** |
| Does it create new risk? | **Yes:** artificial successor appointment (Part 11 §11.8, Part 42 P-11); unfair pressure on very small teams (§11.7). Both are addressed |

## 7.2 Performance gates PG-1 … PG-12

**[P] Amendment L-04 — Performance Gate Architecture.** A gate failure does not reduce a score. **It disables the *consequences* of the score.** This distinction is the whole design: the team's work is still recorded, still visible, still credited in the record — but it cannot confer status.

| Gate | Condition | What it disables | Source basis | Reinstatement |
|---|---|---|---|---|
| **PG-1** | Serious safety failure unresolved | Top status, leadership eligibility, award, ranking position, bonus, public recognition | **[S: Ch.26 "high score void if … safety breach"; Ch.14 safety failure "Immediate stop-work, safety review, retraining"]** | On closure of the safety review with corrective action verified |
| **PG-2** | Financial records materially unreliable | Same | **[S: Ch.26 "…fraud"; Ch.14 financial failure "Audit investigation; suspension if fraud suspected"]** | On reconciliation without unexplained variance for a stated period |
| **PG-3** | Serious misconduct concealed | Same, **plus** enhanced review of the concealing role | **[S: Ch.14 "incident concealment"; SOP-18; Const. Art.8]** | On completion of the misconduct process **[V]** |
| **PG-4** | Evidence fabricated | Same, **plus** mandatory re-verification of the prior two periods | **[S: App. F unacceptable evidence; Ch.25 anti-gaming]** | On re-verification clean |
| **PG-5** | Member exploitation occurred | Same | **[S: Ch.9 Volunteer Manager "Cannot … coerce participation"; S-C: HV-1 coercion veto gate]** | On independent review closure |
| **PG-6** | Successor development deliberately blocked | **Leadership eligibility and promotion only** — not the team's other recognition | **[S: Ch.9 Succession; Ch.26; S-B: B-18(1)]**; **[P]** extension | On SS-2 or better established |
| **PG-7** | Performance achieved through prohibited behaviour | Everything | **[S: Ch.2 principles; Const. Art.2, Art.9; S-A: A-08 entrenched DO-NOTs]** | Not reinstatable for that period; the period is recorded as void |
| **PG-8** | Beneficiary dignity breached | Public recognition and any publication naming the team | **[S-A: A-19; S-C: HV-2 veto gate]** | On independent review closure |
| **PG-9** | Recruitment pressure or coercion detected | Leadership eligibility, ranking | **[S-C: HV-1, MLM-1…MLM-7]** | On independent review closure |
| **PG-10** | Retaliation against a complainant or dissenter | Everything, **and** is itself serious misconduct | **[S-ST: M10 non-retaliation "classified as serious misconduct"; S-C: §21.3]** | On independent review closure **[V]** |
| **PG-11** | Worker compensation unlawfully or avoidably withheld while deferrable items were paid | Leadership eligibility, ranking, public recognition | **[S: Ch.18 priority order; Const. Art.10 APPROVED]** | On payment or approved accrual plan **[S-B: B-05, B-06]** |
| **PG-12** | Political or religious positioning by the team in the organisation's name | Public recognition, ranking, leadership eligibility | **[S-A: A-01 N1…N9; A-05]** | On correction published and neutrality review closed |

**[P] Gate rules:**

1. **A gate is triggered by a *finding*, not by an allegation.** **[S-ST: F-22]** identified the asymmetry: "an allegation costs nothing; the defence costs weeks." **An allegation produces a HOLD (Part 18 §18.6), which suspends promotion only; a substantiated finding produces a GATE.** This is a deliberate modification of the reading of **[S: Ch.26]**'s voiding rule — the voiding rule is preserved for substantiated cases exactly as written; only the *interim* handling changes. **[P]**, flagged in Part 47 as **C-D-11**.
2. **Gates attach to the period, not permanently to the team.** A gated period is recorded as gated; the next period is scored normally. Permanent consequence belongs to the conduct process, not to performance **[S: Const. Art.8]**.
3. **A gate never disables a person's dignity, participation, help, record or right to leave.** **[S-C: CR-1…CR-4]**; Rule D-1.
4. **A gate never disables payment for verified work.** **[S: Ch.18]** priority 1 is unaffected by any performance finding — performance is not a payment condition. **[A]** This is a hard separation: **the score governs status; the waterfall governs money.**
5. **Every gate activation is recorded with reason, evidence, activating authority and reinstatement condition** (**[S-A: A-15 M1]**).
6. **A gate may be appealed** (Part 18 §18.5), and the appeal does not reinstate status pending decision unless the reviewer orders interim relief.

## 7.3 The voiding rule, preserved and bounded

**[S: Ch.26]** verbatim: **"Same safeguards; high score void if fraud/safety breach/manipulation."**

**[P]** Interpretation adopted, so that the rule cannot be used as a weapon and cannot be quietly ignored:

| Term | Interpretation | Why |
|---|---|---|
| **"high score"** | The composite for the affected period | The rule attaches to a period's measurement |
| **"void"** | The score is recorded but confers no status, ranking position, eligibility, award or recognition | A score erased from the record would destroy the audit trail **[S: Ch.27]** and prevent learning **[S-A: A-15 M5]**. **Void ≠ deleted** |
| **"fraud"** | A substantiated finding of financial deception, per the finance-failure route **[S: Ch.14]** and the misconduct procedure **[S: Ch.33 PROPOSED]** **[V]** | Not an allegation; not an irregularity later corrected |
| **"safety breach"** | A substantiated serious safety failure, including any breach of **[S-A: A-08]** entrenched DO-NOTs | Not a minor near-miss self-reported and corrected (Rule D-11) |
| **"manipulation"** | A substantiated finding of metric manipulation, per the eight anti-gaming controls **[S: Ch.25]** | Not an aggressive-but-honest interpretation later corrected |
| **Who decides** | Performance/Audit, with Governance if appealed **[S: App. E "Leaderboard finalisation — Performance/Audit; Governance if appealed; escalate when Tie, anomaly, leadership transfer"]** | Source already assigns this |

## 7.4 Bounding the business dimension — revenue may not dominate

**[S]** Existing controls, preserved: **mission impact carries the highest proposed weight (20%)** and business performance 15% **[S: Ch.25]**; "Revenue alone is insufficient because it can push teams to neglect service, safety, member development or truth" **[S: App. A §18.1]**; "prevents business revenue from dominating" **[S: App. A §18.2]**; raw revenue cannot determine leadership **[S: Ch.25]**; "Collected legitimate customer revenue; exclude fake/circular/related-party manipulation" **[S: Ch.25]**; "Do not reward underreported costs" **[S: App. A §18.3]**.

**[P]** Four additional bounds, because **[S-ST: F-17]** rates business-overpowers-service as **HIGH with only detective control**:

| Bound | Mechanism | Source link |
|---|---|---|
| **BD-1 Service floor** | A team whose service-hour budget **[S-B: B-01]** is unmet cannot receive top status, regardless of business performance | **[S-B: B-01]**; **[S: Ch.25 mission impact]** |
| **BD-2 Mission-balance visibility** | The published **Mission Balance Statement** shows service and business side by side per team and per city | **[S-ST: §17.3 M14]**; **[S-C: HM-11]** |
| **BD-3 No conversion credit** | Beneficiary-to-participant conversion produces **no score, no compensation, no eligibility** | **[S-C: BS-3, MLM-1]** |
| **BD-4 Venture-leader evaluation is multi-dimensional** | A venture leader is assessed on delivery, quality, customer trust, financial discipline, worker compensation, survival, compliance, mission alignment and team development — **never on revenue alone** (Part 23 §23.4) | **[S: Ch.25]; [S-B: §29]** |

**[A]** BD-1 deserves a warning: **[I]** a service floor can be gamed by performing trivial service to clear the floor. **The floor is therefore expressed in verified outcomes, not hours alone**, and **[S: Ch.15]**'s outcome verification plus the follow-up obligation (Part 8) apply to it fully. **This is recorded as GF-14 in Part 20.**

## 7.5 What a team score may and may not be used for

**[P]** Rule D-17 (Score Use Rule), consolidating **[S-C: §23.2, §44.4]**:

| Use | Permitted | Condition |
|---|---|---|
| Learning and diagnosis | ✅ | Primary purpose **[S: App. A §18.1]** |
| Support allocation | ✅ | **[S: Ch.14 step 4; Ch.25 step 6]** — and this is the *most valuable* use at low scale |
| Training targeting | ✅ | **[S: Ch.25 step 6]** |
| Succession-readiness signalling | ✅ | Part 11 |
| Recovery initiation | ✅ | **[S: Ch.14]** |
| **Leadership nomination** | ✅ | **Nomination only** — LG-1…LG-10 still apply (Part 10) |
| Leadership appointment | ❌ | **Never on score alone** (Break 5, Part 1 §1.2) |
| Ranking individuals | ❌ | **[S-C: §23.2]**; Rule D-9 |
| Determining compensation | ❌ | **[S: Ch.18]** waterfall governs; performance is not a payment condition (§7.2 rule 4) |
| Determining a person's worth, dignity or access to help | ❌ | **[S-C: CR-1…CR-4]**; Rule D-1 |
| Publication for L0–L4 | ❌ | **[S-C: SR-3]** |
| Public individual naming | ❌ | **[S-ST: F-33(7) iii]** "no public ranking of individuals below leadership level" |
| Use as the sole input to an AI recommendation that a human then rubber-stamps | ❌ | Part 30 §30.6; **[S-ST: F-29]** |

---

# PART 8 — OUTCOME WINDOWS

## 8.1 The problem, stated precisely

**[S: Const. Art.14]** — performance is monthly. **[S: Ch.25 step 3]** — "Monthly calculation". **[S: Ch.26 step 2]** — "Monthly evaluation". **[S-ST: F-20]** — "Measurement window ≪ outcome window … teams optimise what is countable *now*: events held, packets distributed, sessions run, photos taken. Performative service replaces effective service."

**[A]** And the source **already forbids the result**: "do not count planned activities as completed impact" **[S: Ch.15]**; counting planted saplings as long-term survival is unacceptable evidence **[S: App. F]**; reports must "include failures and partial outcomes" **[S: Ch.15]**; "measures outcomes, integrity, compliance and learning" rather than "obedience to process even if local outcomes are poor" **[S: App. A §16.2]**.

> **[A] The contradiction is not between the rules and reality — it is between the rules and the cadence.** The architecture states the right principle and then builds an engine that makes the wrong behaviour rational. **[S-ST: F-20(6)]** verdict: "Directionally strong, temporally insufficient. The rules are right; the cadence undermines them."

## 8.2 The four windows

**[P] Amendment L-05 — Four-Window Performance Model.**

| Window | Question | Typical duration | What is measured | Evidence class | Who is judged on it |
|---|---|---|---|---|---|
| **W-A ACTIVITY** | What happened during the period? | Daily → monthly | Tasks completed, requests logged, response times, attendance, delegations issued, records filed, incidents reported | LE-1 | **Team hygiene**, and LC-3 reliability |
| **W-B OUTCOME** | What resulted? | Monthly → one local cycle (season, exam period, festival **[S-C: §57.3 rule 3]**) | Verified outcomes, customer acceptance, reconciliation without variance, quality thresholds met | LE-2 | **Team performance**, LG-5 |
| **W-C SUSTAINABILITY** | Did the result persist? | One cycle → one year | Follow-up verification status: resolved / reduced / unchanged / worsened / unknown **[S-C: HM-8]**; survival rates; repeat customers **[S-B: §27.4 `r_repeat`]**; retention **[S: Ch.25]** | LE-2 (later-dated) | **Team performance at higher maturity; LC-19 long-term thinking** |
| **W-D CORRECTION** | What did the team do when something went wrong? | Event-triggered, closed within a stated period | Time to detect, time to report, self-report vs external discovery, corrective action taken, whether the correction worked **[S-A: A-15 M5]** | LE-3 | **Individual capability (LC-2, LC-14, LC-16, R-11, R-12) and team execution quality** |

## 8.3 How the windows interact

**[P]** The interaction rule is the part that makes this work rather than merely adding complexity:

```
W-A ACTIVITY      → measured MONTHLY, reported to the team, low stakes.
                    Purpose: operational memory [S: Ch.24] and early warning.
                    Consequence: routing to support/training. NEVER to promotion.

W-B OUTCOME       → measured MONTHLY where the outcome is short-cycle
                    (a delivery, a reconciliation, a clean-up), and
                    PER-CYCLE where it is not (learning, health, stability,
                    survival). Claimed outcomes OPEN a follow-up obligation.

W-C SUSTAINABILITY→ measured at the follow-up date the claim itself specified.
                    An outcome claim with no scheduled follow-up is NOT an
                    outcome; it is an activity, and is scored as one.
                    Unverified follow-ups REDUCE score [S-ST: F-20(7) ii].

W-D CORRECTION    → measured on event. Independent of the other three.
                    A team that fails and corrects well can score HIGHER on
                    execution quality than a team that never reported a failure
                    (§8.6, Rule D-11).
```

**[P] Rule D-18 (Window Separation Rule).**
1. **Promotion and leadership eligibility are assessed on W-B and W-C, never on W-A alone.**
2. **A team is never penalised for an outcome that has not yet matured**, provided the follow-up is scheduled and the claim was made honestly. The claim sits in a **pending** state and is neither scored nor voided.
3. **A team is penalised for an outcome claim whose follow-up was not performed.** The penalty applies to the period in which the follow-up fell due — not retroactively to the period of the claim, because retroactivity destroys planning.
4. **W-D is assessed on the correction, never on the occurrence.** The occurrence is assessed under W-B and under the gates.

## 8.4 The activity cap

**[P]** **[S-ST: F-20(7) iv]** — "cap the score contribution of activity counts so volume can never carry a team." Implementation without altering the source's weights:

| Mechanism | Description | Effect on source weights |
|---|---|---|
| **AC-1 Outcome-verified proportion** | Within the **Execution (15%)** dimension, the activity-count component is admissible only up to a stated proportion; the remainder requires LE-2 outcome evidence | **None** — the weight is unchanged; the *admissible evidence* inside it is bounded |
| **AC-2 Splitting prohibition** | "no artificial splitting" **[S: Ch.25]** already applies to project counts; extended to tasks, sessions and beneficiaries | **None** — existing control, extended scope |
| **AC-3 Repeat-beneficiary rule** | A repeat beneficiary is not a new beneficiary; the record distinguishes them | **None** — evidence rule |
| **AC-4 Difficulty adjustment** | "adjusted for difficulty" **[S: App. A §18.3]** — defined in Part 9 | **None** — completes an existing source term |
| **AC-5 Awareness-category ceiling** | "Awareness" as a service category is capped in score contribution, because it is the cheapest to produce and the hardest to verify | **None** — evidence rule; **[S-ST: F-20(3)]** names it as an early warning |

**[A]** Every mechanism above operates on **evidence admissibility**, not on **weights**. **[P]** This is deliberate and is the key compatibility argument: **the weights are `PROPOSED — FINAL WEIGHTS REQUIRE APPROVAL` [S: Ch.25] and this document has no authority to change them; the evidence rules are the anti-gaming controls [S: Ch.25 step 5] and the source expressly invites their strengthening** ("Scores must use evidence and anti-gaming checks").

## 8.5 Performance baselines and new-team treatment

**[P] Amendment L-07 — Baseline, Maturity and Provisional Status.**

**[A]** Two opposite errors must be avoided simultaneously: punishing a new team for having no history, and letting "newness" become a permanent exemption.

| Instrument | Definition | Anti-abuse limit |
|---|---|---|
| **Baseline period** | The first *n* complete cycles during which a team's measurements are **recorded but not compared**. *n* is `PROPOSED — REQUIRES PILOT VALIDATION`; no number invented | Baseline ends automatically at *n*, or earlier on the team's request |
| **Maturity bands** | Bands defined by **observable structural facts**, not by self-declaration: roles filled / nine functions covered **[S: Ch.10; S-B: §27.2]**; first full project cycle completed **[S: Ch.13 gate 2]**; first reconciled period **[S: Ch.13 gate 3]**; first approved venture delivered **[S: Ch.17]**; autonomy-readiness gates passed **[S: Ch.13 gates 1–8]**; **[S-B: §31 Stage 0–5]** | A band is assigned by the City from records, and is appealable. **A team may not elect its band** (that is Part 9's cohort-gaming control applied to maturity) |
| **Ramp-up** | Within a band, score is reported **as improvement versus own baseline**, not as absolute level | Ramp-up has a hard end at band transition |
| **Minimum evidence threshold** | A dimension with insufficient evidence is reported **UNEVIDENCED**, not zero | **UNEVIDENCED ≠ 0.** Treating it as zero punishes newness; treating it as full marks rewards it. It is excluded from the composite and flagged |
| **Provisional status** | A team in baseline is `PROVISIONAL`: it appears in its cohort's data, receives support and training, and is **not ranked** | **Hard expiry** at the end of the baseline period; a team cannot re-enter provisional status except after a structural break (Part 9 §9.6) |

**[A]** Cross-reference: **[S-B: §26.2]** already defers **leaderboard participation** for Stage 0–2 teams on exactly this ground — "Comparative scoring requires cohorts; a single team has none (stress-test F-19 cohort normalisation)" — and defers **autonomy readiness audit** to Stage 3–4. **L-07 is therefore not a new idea; it is the generalisation of a decision v1.3-B already made for economic reasons, now made for fairness reasons.**

**[P] Rule D-19 (No Permanent Newness).** Provisional status expires on a date recorded at the time it is granted. The expiry may be extended **once**, by the City, with a recorded reason and a stated new expiry — and every extension is reported in the city's aggregate report so that a pattern of extensions is visible. **[A]** This mirrors **[S-ST: F-03(7)]**'s combined-role exception register "with expiry dates and City approval, so reality is recorded instead of hidden."

## 8.6 Honesty of reporting as a scored element

**[P] Amendment L-05(6).** **[S-ST: F-20(7) v]** — "publish failures and partial outcomes per Ch.15 — and score the honesty of reporting as part of execution quality."

| Element | Measurement | Direction |
|---|---|---|
| **Failure publication rate** | Failures and partial outcomes published ÷ failures that occurred (estimated from incident, complaint and follow-up records) | **Higher is better** |
| **Self-report rate** | Problems reported by the team before external discovery ÷ total problems discovered | **Higher is better** (Rule D-11) |
| **Correction speed** | Time from detection to report; time from report to corrective action | Lower is better |
| **Correction effectiveness** | "Did the change work?" checked later **[S-A: A-15 M5]** | Higher is better |

**[A]** The design intent, stated plainly: **the only way to make honesty rational in a scored system is to score honesty.** A team that reports a failed project and a worsened outcome should not finish behind a team that reported nothing and therefore has no failures on record. **[S: App. A §16.2]** already requires the system to measure "outcomes, integrity, compliance and **learning**" — and learning cannot exist without reported failure.

**[A]** The gaming risk of this rule is real and is recorded: **[I]** a team could manufacture trivial "failures" to score well on honesty. **Control:** failure publication is assessed against **materiality** — the failures that matter are those affecting money, safety, beneficiaries, customers or commitments — and a pattern of trivial-only failure reporting is itself an anomaly signal for review (Part 20 GF-19).

---

# PART 9 — COHORT NORMALISATION

## 9.1 The problem, in the source's own terms

**[S-ST: F-19]** — "Teams in difficult contexts are permanently ranked low; teams in easy contexts are permanently high. The low-ranked conclude the system is rigged; the high-ranked become complacent; leadership transitions repeatedly favour the same geographies." Early warnings: "score distributions clustered by city type; the same teams at the top for 6+ consecutive months; appeals arguing context rather than calculation; low-ranked teams reducing effort ('what's the point'); leaders avoiding hard areas."

**[S-ST: F-19(4)]** — "the leadership pipeline narrows to a few privileged teams — which contradicts 'earned leadership' **[S: Ch.2]** because **the earning is partly inherited from geography.**"

**[A]** And the economic mechanism is already quantified elsewhere: **[S-B: §26.5]** — `K_min = (C_city + C_L1_fixed_shared) / (CM̄_j × P_realistic − C_L1_local)`, with the finding that **"`K_min` rises sharply when the denominator is small, i.e. in poor neighbourhoods a city needs *more* teams to afford the shared layer, while being *less* able to form them."** **[S-B: §14.2]**: governance cost per team is roughly constant while revenue capacity varies by an order of magnitude.

> **[C] The compound inequality, stated once:** a team in a low-demand locality has (a) less revenue, (b) the same governance load, (c) fewer peers to share it with, (d) harder service cases, and (e) **a lower score on a board that does not know any of this** — and its leader therefore has a structurally lower chance of ever being nominated for anything. **That is not earned leadership. That is inherited position, measured.**

## 9.2 What the source already provides

**[S: App. A §18.3]** — verified service outcomes are calculated as "Completed verified outcomes divided by approved targets, **adjusted for difficulty**." **[S: Ch.25]** — anti-gaming controls; anomaly review; corrections; appeals. **[S: Ch.8 step 5]** — priority assessment criteria: "Urgency, vulnerability, resources, expected impact, safety risk and feasibility."

**[A]** Three usable assets:
1. **"Adjusted for difficulty" is already in the metric specification.** The source permits difficulty adjustment; it does not define it. **Defining it is completion, not modification.**
2. **The priority-assessment criteria of [S: Ch.8 step 5] are a difficulty vocabulary already approved for a different purpose.** Urgency, vulnerability, resource scarcity, expected impact, safety risk and feasibility are exactly the dimensions along which localities differ. **Reusing them for cohort definition avoids inventing a new classification and avoids the political risk of a new one.**
3. **Approved targets exist per project** **[S: App. A §18.3]** — so *improvement versus own target* is already computable without any new data.

## 9.3 The cohort normalisation architecture CN-1 … CN-7

**[P] Amendment L-06.** Seven instruments. **None requires new data collection; all are computed from records the architecture already produces.**

| ID | Instrument | Definition | Data source | Gaming risk | Control |
|---|---|---|---|---|---|
| **CN-1** | **Peer cohorts** | Teams are grouped by **objective, non-elective** attributes: area type (urban / peri-urban / rural); venture status (venture-active / service-only); team size band; maturity band (§8.5) | **[S: Ch.10 staffing states; Ch.13 gates; Ch.17 venture approval; S-B: §31 Stage]** | A team seeks an easier cohort | **Assignment is by record, not by election**; changes only when the underlying record changes; every assignment is published to the team with its basis |
| **CN-2** | **Baseline-adjusted improvement** | A stated share of the composite is computed as **change versus the team's own baseline**, not as absolute level | Existing period records | Sandbagging the baseline (deliberately poor first period) | Baseline is the **first *n* complete cycles under provisional status** (§8.5) during which the team is **not ranked**, so there is no incentive to sandbag; baseline is re-set on structural break (§9.6) |
| **CN-3** | **Per-capita and per-hour normalisation** | Outcomes expressed per active member and per available hour: `outcomes / N_act`, `outcomes / (N_act × T_avail)` | **[S: Ch.25 "attendance cross-checked"; S-B: §14.3 `r_act`, §25.1]** | Inflating `N_act` denominator by registering inactive members | Uses **`N_act` (contributed this period)**, not `N_ver` — **[S: Ch.25]** "healthy active retention, not inactive names"; **[S-B: §27.2]** |
| **CN-4** | **Resource-normalised efficiency** | Output per unit of resource actually available: contribution per delivery hour `CM̄_j / h_proj` **[S-B: §11.4]**; outcomes per rupee of direct cost; outcomes per governance hour | **[S-B: §27.1, §27.2]** | Underreporting cost or hours — **[S: App. A §18.3]** already names this: "Do not reward underreported costs" | Reconciliation gate PG-2; `H_gov` measured, not declared **[S-B: §25.1]** |
| **CN-5** | **Opportunity/difficulty adjustment** | The **"adjusted for difficulty"** term of **[S: App. A §18.3]**, defined using **[S: Ch.8 step 5]**'s own vocabulary: urgency, vulnerability, resource scarcity, expected impact, safety risk, feasibility — recorded **at request intake**, before the work is done | **[S: Ch.8 step 2 request log "urgency, risk"; step 5]** | Inflating declared difficulty at intake | Difficulty is recorded **at intake by the receiving role and confirmed at verification by a different role**; the distribution of declared difficulty per team is itself an anomaly signal; **random beneficiary/partner checks** **[S: Ch.25]** |
| **CN-6** | **Maturity-adjusted scoring** | Teams are compared only inside their maturity band; a Stage-1 team is not compared with a Stage-4 team | **[S-B: §31 Stage 0–5; §8.5]** | Staying in a low band | Bands are assigned from structural records and have hard transitions (§8.5) |
| **CN-7** | **Absolute and relative reporting together** | **Both** the raw composite **and** the cohort-normalised view are published to the team and to its cohort; the raw view is never suppressed | Rule D-13 step 4 | — | **[S-ST: F-19(7) iv]** "publish raw *and* cohort-normalised scores so no team is invisible" |

## 9.4 What each comparison type is for

**[P]** The brief requires absolute, relative-improvement, resource-efficiency and mission-effectiveness comparisons, with a rule for when each is used.

| Comparison | Question | Legitimate use | Illegitimate use |
|---|---|---|---|
| **ABSOLUTE** | Who produced the most? | Allocating a scarce opportunity that genuinely requires scale (a large venture, a city-wide project); reporting to funders and partners who ask for volume | **Determining leadership.** Volume is a function of context, and context is inherited |
| **RELATIVE IMPROVEMENT** | Who improved the most? | Support allocation; identifying teams worth learning from; the primary view for low-maturity teams | Comparing a team that improved from a very low base with one that sustained a very high base — **both matter, and the second is rarer** |
| **RESOURCE EFFICIENCY** | Who produced the most from what they had? | Identifying transferable practice; detecting under-use of available capacity | Ranking teams whose resource base is *itself* a product of past unfairness — efficiency normalises the denominator but not its history |
| **MISSION EFFECTIVENESS** | Who created the most meaningful outcome? | The primary basis for **leadership nomination**, because it is the only one of the four that measures what the organisation exists for **[S: Const. Art.1]** | Reducing "meaningful" to what is countable (Part 8) |

**[P] Rule D-20 (Comparison Purpose Rule).** Every published comparison states, on its face: **which of the four it is, what it is being used for, and what it is not being used for.** A comparison whose purpose is unstated will be read as a ranking of worth.

**[A]** The reasoning for placing **mission effectiveness** first for leadership nomination, and the honest caveat: **[I]** mission effectiveness is the hardest of the four to measure and the easiest to fake. **Its primacy is therefore conditional on W-C sustainability evidence existing** — a claim of meaningful outcome that has not been followed up is an activity claim (§8.3). **Where no W-C evidence exists, leadership nomination falls back to CN-2 relative improvement plus the capability assessment of Part 4, never to absolute volume.**

## 9.5 Does the formula create new gaming opportunities?

**[A]** Tested, as the brief requires — "Do not create a formula merely because it looks mathematically sophisticated."

| New gaming opportunity created by normalisation | Mechanism | Severity | Control | Residual |
|---|---|---|---|---|
| **Cohort shopping** | A team manoeuvres into an easier cohort — e.g. stays small to remain in a small-team band, or avoids venture approval to enter the service-only cohort | **High** | Cohorts assigned from records, not elected (CN-1); band transitions are automatic on structural fact; **the small-team and service-only cohorts are not systematically easier** — they are differently resourced, and CN-4 normalises for resource | **Medium** — a team can still slow its own growth. Recorded as **GF-20**; the counter is that growth is gated on contribution anyway **[S-B: B-07]** |
| **Baseline sandbagging** | Deliberately poor first periods to make improvement easy | **High** | Baseline is set during **provisional, unranked** status (§8.5), so there is no ranking to lose; baseline uses the first *n* *complete* cycles, not the worst | **Low** |
| **Difficulty inflation** | Declaring every request urgent and vulnerable | **High** | Recorded at intake by one role, confirmed at verification by another; distribution monitored per team; beneficiary/partner sampling **[S: Ch.25]** | **Medium** — recorded as **GF-21** |
| **Denominator management** | Suppressing `N_act` to raise per-capita figures, or inflating `H_gov` to raise per-hour figures | **Medium** | `N_act` is derived from contribution records, not declared; `H_gov` is **measured** in the pilot **[S-B: P-01]** and cross-checked against cadence obligations, which are fixed and known (§25.2 of v1.3-B) | **Medium** |
| **Normalisation opacity** | Teams cannot understand their own score, so cannot contest it — which removes the corrective pressure that keeps any measurement honest | **High** | **Plain-language score explanation per team** **[S-ST: M8 control]**; Rule D-14 (no score final until the team has seen its decomposition); appeals route preserved **[S: Ch.25]** | **Low** |
| **Fast feedback loss** | Longer windows reduce motivational immediacy **[S-ST: M8 named risk]** | **Medium** | W-A remains monthly and is reported to the team; the **non-scored** hygiene feedback loop stays fast | **Low** |

**[A] Verdict on the formula question:** normalisation is **worth its gaming risk**, because the unfairness it removes is *structural and certain* while the gaming it enables is *opportunistic and detectable*. **But it is only worth it if CN-7 (both views published) and the plain-language explanation are adopted together with it.** Normalisation without explanation is worse than no normalisation, because it makes an unfair number look like a technical one.

## 9.6 Structural breaks — when a baseline is invalid

**[P]** A baseline or cohort assignment is **reset** on a recorded structural break:

| Break | Why it invalidates comparison |
|---|---|
| Leadership transition (promotion, exit, removal, death) | **[S-B: §24.2]** — the team's capacity genuinely changes; **promotion-cohort reporting** **[S-B: B-18(4)]** applies for *n* periods |
| Relocation of the team's area of operation | Context changes entirely |
| Merger or split of teams | Denominator changes (**but see GF-22: splitting to improve ratios is a gaming vector — a split requires City approval with recorded reason**) |
| Declared emergency or disaster in the locality | **[S: Ch.16; S-A: A-09]** — the operating condition is not comparable |
| Loss or gain of a major revenue source | **[S-B: §10 scenarios]** — the economic base changes |
| Change of maturity band | §8.5 |
| A gate activation (PG-1…PG-12) | The period is not comparable; the gate is recorded and the next period re-baselines |

**[P] Rule D-21.** Every structural break is **recorded with a date and a reason**, is visible to the team, and is reported in aggregate at City level so that a pattern of conveniently-timed breaks becomes visible. **[A]** This is **[S-ST: F-22(7) iii]** "allegation-timing analytics as an audit signal" applied to baselines.

## 9.7 The single-city problem — when there is no cohort

**[A]** **[S-B: §26.2]** already deferred leaderboard participation for Stage 0–2 teams because "a single team has none [no cohort]." The general problem: at S0 and S1 **[S-ST: §23.1]** there are between one and fifteen teams. **Cohort normalisation is arithmetically impossible below a small number of comparable teams, and no number is invented here for what that minimum is.**

**[P] Rule D-22 (Small-N Rule).** Where the number of comparable teams is below the approved minimum:
1. **No ranking is published.** The score is used **only** for diagnosis, support allocation, training targeting and succession signalling — the four non-comparative branches of **[S: Ch.25 step 6]**.
2. **Comparison is with the team's own baseline**, not with other teams.
3. **Leadership nomination does not use rank at all.** It uses the capability assessment of Part 4, the evidence portfolio of Part 5, and the gates of Part 10 — which is what Part 33 §33.3 recommends for small *N* in any case.
4. **The organisation says so out loud.** A published statement that "we are too small to compare teams fairly, so we are not comparing them" is itself a trust instrument **[S-C: §40.2 promise ladder]** and prevents the speculation that a hidden ranking exists.

**[A]** This rule has a large and under-appreciated benefit: **it removes the prize from the pilot.** **[S-ST: F-19(7) v]** recommended "never rank teams publicly in the first two cycles — use the score diagnostically before using it as a prize." **Rule D-22 makes that automatic rather than discretionary**, and it means the pilot (Part 41) measures leadership capability without the contamination of a competition the pilot is too small to run fairly.

---

# PART 10 — PROMOTION

## 10.1 The source mechanism, preserved

**[S: Ch.26]** verbatim in substance:

| Current best team | Leadership opportunity | Safeguards **[S]** |
|---|---|---|
| **Best Mohalla Team** | City Head Team | "Minimum eligibility, evidence review, tie-breaks, correction window, appeals, transition." |
| **Best City Head Team** | State Head Team | "Same safeguards; **high score void if fraud/safety breach/manipulation**." |
| **Best State Head Team** | National Team opportunity | "**Opportunity not automatic personal entitlement; governance/CEO process applies.**" |

**[S: Const. Art.15 APPROVED ARCHITECTURE]** — "Best Mohalla Team can become City Head Team; best City Head Team can become State Head Team; best State Head Team can receive National Team opportunity. **Safeguards require approval.**"
**[S: Ch.26 step 5]** — "Performance-based leadership transition. **Not automatic status; transition requires rules and approval.**"
**[S: Ch.33]** — "Leadership transition rules — **NOT FINAL**. Monthly eligibility, evidence review, correction window, appeal and transition."
**[S: App. E]** — "Leadership transfer — Default authority: **CEO/governance process**; Co-review: Performance/Audit/HR; Escalate when: Dispute, misconduct, instability; Record required: **Handover record**."

**[A]** This is a **nomination** mechanism with real safeguards, and it is **APPROVED at constitutional level**. **v1.3-D does not replace it.** It does three things: (a) inserts the capability gate the source's own fault tree lacks (Break 5); (b) makes the transition non-destructive to the originating team (Break 7); and (c) supplies the horizontal alternatives without which the mechanism is a lottery (Break 1).

## 10.2 The ten promotion readiness gates

**[P] Amendment L-08(a) — LG-1 … LG-10.** The brief lists ten candidate gates and asks that they not be assumed mandatory until analysed. **Analysis below: nine are mandatory; one is conditional.**

| Gate | Name | Question | Mandatory? | Reasoning | Source |
|---|---|---|---|---|---|
| **LG-1** | **Eligibility** | Does the candidate pass Gate E (Part 3 §3.2)? | **YES** | Non-negotiable floor; the source already requires it **[S: Ch.26 step 4]** | **[S]** |
| **LG-2** | **Capability** | Does the candidate pass Gate R **against the destination level's profile** (Part 4 §4.6)? | **YES** | This is Break 5 and the whole reason for L-01. A gate that assessed against the origin level would be circular | **[P]**, from **[S: Ch.26 "evidence review"]** |
| **LG-3** | **Conduct** | No unresolved serious-misconduct matter; no gate PG-3, PG-5, PG-9, PG-10 active | **YES** | **[S: Const. Art.8]**; **[S: Ch.26]** voiding rule | **[S]** |
| **LG-4** | **Safety** | No unresolved serious safety failure attributable to the candidate's team or role; PG-1 not active | **YES** | "Unsafe success is not success" **[S: Ch.25]** | **[S]** |
| **LG-5** | **Governance / performance** | The team's score is HIGH or MEDIUM confidence, gates clear, and the routing branch selected is leadership opportunity | **YES** | **[S: Ch.25 step 6; Ch.26 steps 1–3]** | **[S]** |
| **LG-6** | **Team development** | LE-5 evidence exists: named people progressed; training delivered; delegation used | **YES** | **[S: Ch.25 member development — "Growth depends on trained people, not one heroic leader"]** | **[S]** principle, **[P]** as a gate |
| **LG-7** | **Succession** | The candidate's *current* role is at SS-2 or better, **or** a documented structural impossibility applies (§11.7) | **YES, with the small-team exception** | **[S: Ch.9 Succession; Ch.22 succession_status; S-B: B-18(1)]** | **[S]** + **[P]** |
| **LG-8** | **Economic feasibility** | The destination role is funded, or its volunteer burden is explicitly costed and accepted (Part 39) | **YES** | **[S-B: §24, §25.5, §39]** — no hidden assumption that leaders will just volunteer | **[S-B]** |
| **LG-9** | **Human-system compatibility** | The promotion breaches no refusal right, creates no dependency, requires no breach of the load ceiling, and the candidate has consented | **YES** | **[S-C: H-17, HV-1…HV-4, §26.3]** | **[S-C]** |
| **LG-10** | **Human decision approval** | A named human authority approves, with recorded reasons, conflicts declared, per **[S: App. E]** | **YES** | **[S: Const. Art.12]** AI may not decide leadership; **[S: App. E]** | **[S]** |
| **LG-X** | **Cohort fairness check** *(conditional)* | Is the nomination an artefact of incomparable context (Part 9)? | **CONDITIONAL — mandatory only where ranking is used** | Under Rule D-22 (small *N*) there is no ranking, so there is nothing to check | **[P]** |

**[A]** Why LG-8 (economic feasibility) is a promotion gate and not an afterthought: **[I]** promoting a person into an unfunded leadership role is a promise the organisation cannot keep, and **[S-B: §46.1]** establishes that a broken payment expectation is the earliest and most damaging failure in the whole model. **A promotion that cannot be paid for, or whose volunteer burden has not been costed and accepted, is not a promotion — it is an unpaid second job with a title** (Part 24 §24.4).

## 10.3 The promotion decision workflow

**[P]** Nine steps, integrating **[S: Ch.11]** vacancy lifecycle and **[S: Ch.26]** transition safeguards:

```
1. TRIGGER        Vacancy arises (planned succession, exit, removal, growth)
                  OR a routing decision from [S: Ch.25] step 6 selects
                  "leadership opportunity".
                     |
2. ROLE BRIEF     Destination role profile published: scope, authority
                  limits, load estimate, evidence requirements, review
                  cadence, funder-or-volunteer-burden statement (LG-8).
                     |
3. CANDIDATE SET  Applications open [S: Ch.11 step 3] + nominations with
                  consent (Part 33). Window long enough for people not
                  close to leadership to apply (Part 33 opportunity rule).
                     |
4. GATE E         HR screening against E-1...E-13. Recorded.
                     |
5. GATE R         Structured assessment by two assessors, at least one
                  OUT OF TEAM. Evidence portfolio reviewed. Gap statement
                  produced for EVERY candidate, selected or not.
                     |
6. GATES LG-1..10 Applied in order. Any failure -> recorded, with reason,
                  and the candidate receives the gap statement.
                     |
7. DECISION       Appointing authority per [S: App. E]. Reasons recorded
                  [S-A: A-15 M1]. Conflicts declared, recusals recorded.
                     |
8. TRANSITION     The nine-step Promotion Transition Protocol (10.5).
                     |
9. POST-TRANSITION REVIEW
                  At a stated interval: did the originating team survive?
                  Is the promoted person performing at the new level?
                  Recorded in the lessons register [S-A: A-15 M5].
```

**[A]** Step 9 is the one no organisation ever does and the one that makes the system learn. **[S-A: A-15 M5]** already requires the "did the change work" column; **applying it to promotions converts every transition into evidence about whether the selection model works** — which is the only way **LG-2** can ever be validated rather than assumed.

## 10.4 Tie-breaks

**[S: Ch.26]** requires tie-breaks; the source does not define them. **[P]** Order of tie-break, published in advance, recorded, appealable:

| Order | Tie-break | Why here |
|---|---|---|
| 1 | **Higher confidence** on the score (Part 6 §6.3) | A decision on thick evidence beats a decision on thin evidence |
| 2 | **Fewer unresolved gates or holds** | Risk-first |
| 3 | **Better LG-6 team-development evidence (LE-5)** | The dimension the score under-measures (Part 4 §4.2) and the one that predicts next-level success |
| 4 | **Better LG-7 succession state in the current role** | Rewards the person who prepared their own replacement |
| 5 | **Better W-D correction record** | Rewards honesty (Part 8 §8.6) |
| 6 | **Cohort-normalised improvement (CN-2)** | Fairness: the person who improved most from where they started |
| 7 | **Function experience inside the destination role's family** | **[S: Ch.9 Succession pathway]** |
| 8 | **Recorded assessor judgement, with reasons, by the out-of-team assessor** | Last, because it is the least auditable — and it must never be first |

**[P]** Prohibited tie-breaks: **absolute volume** (Part 9 §9.4); **seniority alone** (§3.3); **proximity to leadership** (AF-6); **visibility or following** **[S: Ch.25]**; **whoever asked first**; **whoever is easiest to appoint**.

**[A]** Tie-break 8 requires care: **[I]** in a small organisation the final tie-break is always human judgement, and pretending otherwise is dishonest. **The control is not to remove judgement but to require it to be recorded with reasons, made by a person with no conflict, and appealable** — which is precisely **[S-A: A-15 M1]** applied to a personnel decision.

## 10.5 Promotion Transition Protocol — nine steps

**[P] Amendment L-09.** The answer to Break 7 and to **[S-B: §24.2]**'s "success tax on success". **It integrates [S-B: B-18] in full and adds the four steps B-18 did not specify.**

| Step | Action | Record | Time | Source |
|---|---|---|---|---|
| **PT-1** | **Promotion decision recorded**, with reasons, gates, conflicts, and an explicit statement of **what the originating team gives up** | Promotion Decision Record (§10.8) | At decision | **[S-B: B-18(6)]** "promotion is recorded as a *cost* as well as an achievement"; **[S-A: A-15 M1]** |
| **PT-2** | **Successor identified and named** — from SS-2 or better where it exists; otherwise the vacancy lifecycle runs **[S: Ch.11]** and the promotion **waits** | Vacancy record; `succession_status` | **Before transition executes** | **[S-B: B-18(1)]**; **[S-ST: M9]**; **[S: Ch.9, Ch.22]** |
| **PT-3** | **Knowledge transfer** — the KT-1…KT-10 pack (Part 12 §12.8) | Handover pack, signed by both | Stated period | **[S-A: A-14 §13.7]** master handover checklist, applied at every level |
| **PT-4** | **Delegation transfer** — every active delegation the outgoing leader held is either transferred with a new recorded scope and dates, or allowed to expire. **No delegation survives by inertia** | Delegation records **[S: Ch.22]** | At transition | **[S: Ch.10; Ch.22]** |
| **PT-5** | **Authority transfer** — RBAC, financial permission profile and data-access profile re-granted to the incoming holder at **narrowest sufficient** scope; outgoing holder's access reviewed and closed (Part 29) | Access log **[S: App. E — "Platform permission change … Access log"]** | At transition | **[S: Ch.23; Ch.22]** |
| **PT-6** | **Records transfer** — ownership of open records, cases, incident files and commitments reassigned; **no record left ownerless** | Record-owner field | At transition | **[S-A: A-17 estate; A-15 M4]** |
| **PT-7** | **Stakeholder communication** — the team, the City, and (where relevant) beneficiaries, customers and partners are told: who now holds the role, what changes, what does not, and how to raise a concern. In the operating languages. **Announced in the organisation's name with the deciding role identified** | Communication record | At transition | **[S-A: A-16 §15.4]**; **[S: Ch.24]** |
| **PT-8** | **Overlap period where feasible** — outgoing and incoming both hold delegation for a stated period, so tacit knowledge transfers in the presence of the team | Delegation records with overlap dates | Stated period; duration `PROPOSED` | **[S-B: B-18(2)]** |
| **PT-9** | **Post-transition review** — at a stated interval: originating team's `P_max`, `r_close`, `H_gov` efficiency, retention and score **reported with and without** the promotion adjustment; the promoted person's performance at the new level; lessons entry | Review record; lessons register | Stated interval | **[S-B: B-18(4)]**; **[S-A: A-15 M5]** |

**[P]** Two further mechanisms from **[S-B: B-18]**, adopted:

- **PT-8a Bounded mentorship.** The promoted leader remains a mentor to the former team for a stated period **with a stated hour cap** — "enough to transfer, not enough to prevent the successor from owning the role" **[S-B: B-18(3)]**. **[A]** The cap exists because an uncapped mentor obligation is simultaneously how a successor is permanently undermined and how a promoted leader is permanently overloaded (Part 25).
- **PT-8b Support decision.** "**A promotion that is not accompanied by a support decision is a capacity destruction event disguised as a reward**" **[S-B: B-18(6)]**. The Promotion Decision Record must state what support the originating team receives: a City function, a support-team assignment **[S: Ch.14 step 4]**, a temporary delegation, a training allocation, or a recorded statement that no support is available and why.

## 10.6 When promotion should not happen

**[P]** Rule D-23 (Promotion Refusal Grounds). A promotion that satisfies every gate may still be **declined by the organisation**, on recorded grounds:

| Ground | Reasoning |
|---|---|
| **The originating team would not survive the transition** | **[S-B: §24.2; §29 Scenario 4]**. Where SS-2 or better cannot be reached, the correct response is **horizontal recognition** (Part 13, Part 22), not promotion |
| **The destination role is unfunded** | LG-8 |
| **The candidate is at load ceiling** | E-7; **LLI** (Part 24). Promoting an overloaded person is how organisations lose their best people |
| **A hold or investigation is open** | Part 18 §18.6 — a hold suspends promotion; it does not disqualify |
| **The candidate has refused** | **[S-C: H-17]**. A refusal is cheap, silent, and **not recorded as a negative** |
| **The cohort is too small for a fair ranking** | Rule D-22 — nomination may still occur on capability grounds, but **not on rank** |
| **The transition would concentrate authority** | Part 26 — where the promotion would place two segregated functions in one person or one family (**[S: Ch.18]**; Part 35 §35.2) |

**[A]** The first of these matters most. **[I]** An organisation that promotes its best local leader into a coordination layer, without a successor, does not gain a city head — **it loses a mohalla and gains an overstretched person.** Both **[S-B: §24.2]** and **[S-ST: §1.2 Finding 5]** say this. **The correction is not to stop promoting; it is to make promotion conditional on succession, and to make horizontal recognition a genuine alternative so that the best people are not lost when succession is impossible.**

## 10.7 The lottery problem, quantified structurally

**[S-ST: F-24]** states the arithmetic: "In a network of *N* teams there is one City Head Team per city … With 50 teams per city, the annual probability of any given leader reaching city leadership is a few percent even for excellent performers … **if promotion is the *only* reward, the model fails at any N above ~20; if there are parallel rewards (skill, income, credential, recognition, scope), the tournament can stay small and still work.**"

**[C]** Generalising without inventing numbers: let `K` = teams per city **[S-B: §26.5]** and let `L_pos` = leadership positions available above team level per city. The positional ladder's expected value for an individual leader falls roughly as `L_pos / K`. **[A]** The structural conclusion does not depend on the values:

| If… | Then… |
|---|---|
| Promotion is the only advancement | The system fails as `K` grows — **arithmetically, not behaviourally** |
| Parallel rewards exist (credential, scope, specialist standing, income for verified work, recognition, Elder/Mentor) | The tournament can remain small and the system remains attractive |

**[P]** Therefore **v1.3-D's answer to the lottery is not to make promotion more likely. It is to make promotion less necessary** — by building Part 13 (three tracks), Part 22 (separated recognition instruments) and **[S-C: H-10]** portable credentials into load-bearing alternatives. **[S-B: B-18(5)]** reached the same conclusion from the economic side: "**horizontal recognition as an alternative to vertical promotion … This is the cheapest capacity-preservation mechanism available and requires no new authority.**"

## 10.8 Promotion Decision Record

**[P] Amendment L-09(2).** Minimum fields. **Nothing sensitive is published; the record is C2/C3 under [S-A: A-17].**

| Field | Content | Visible to |
|---|---|---|
| **Role** | Title, level, team, `role_id` **[S: Ch.22]** | Internal |
| **Vacancy origin** | Planned succession / exit / removal / growth / death / suspension | Internal |
| **Candidate** | Identifier; **never published together with the reasons** | Internal |
| **Evidence** | Portfolio index; record citations (Part 5 §5.6) | Candidate, assessors |
| **Gate E result** | `ELIGIBLE` / `NOT ELIGIBLE — reason` | Candidate |
| **Gate R result** | `READY` / `READY WITH DEVELOPMENT (gaps)` / `NOT READY (gaps)` — **a gap statement, never a number** (Rule D-6) | Candidate |
| **LG-1…LG-10 results** | Pass / fail / exception per gate, with reason | Internal; summary to candidate |
| **Assessors** | Identity, team, conflict declarations | Internal |
| **Decision** | Appoint / not appoint / defer / develop | Candidate |
| **Reasons** | Recorded in full **[S-A: A-15 M1]** | Candidate; summary internal |
| **Decision-maker** | Named role and person, per **[S: App. E]** | Internal |
| **Conflicts and recusals** | Declared and recorded | Internal |
| **Delegation granted** | Scope, limits, start/end date, reviewer **[S: Ch.22]** | Internal; scope to the team |
| **Review date** | Next RV-1 / RV-2 date | Holder |
| **Succession state opened** | SS-0…SS-5 for the newly filled role | Internal |
| **Originating-team impact statement** | What the losing team gives up; what support it receives (PT-8b) | Both teams |
| **Appeal status** | Open / closed / waived; route | Candidate |

**[A]** The originating-team impact statement is the field that makes **PT-1** real. **[I]** A decision record that does not name the cost of the decision will be made as though the cost were zero — which is exactly how organisations hollow out their best teams while congratulating themselves.

## 10.9 Promotion, appointment, delegation, succession, recognition — never conflated

**[P]** Rule D-24. Five distinct acts:

| Act | Definition | Authority | Record | Reversible? |
|---|---|---|---|---|
| **PROMOTION** | Movement into a **higher responsibility level** | Per **[S: App. E]** Role promotion / Leadership transfer rows | Promotion Decision Record | Yes, by transition or demotion (§10.10) |
| **APPOINTMENT** | Selection for a **specific vacancy**, at any level | Per **[S: Ch.11 step 11]** | Appointment record | Yes |
| **DELEGATION** | **Temporary authority** within an existing role | Role-holder within limits; recorded scope and dates **[S: Ch.10, Ch.22]** | Delegation record with `delegation_start_date` / `delegation_end_date` | **Automatically, on expiry** |
| **SUCCESSION** | **Continuity preparation** — no authority changes hands | Role-holder + HR | `succession_status` **[S: Ch.22]** | Not applicable |
| **RECOGNITION** | **Acknowledgement without authority** | Per **[S-C: H-08]** instruments 1–3 | Contribution record / credential | Not applicable |

**[A]** The confusions this rule prevents, all of which occur in practice:
- **Delegation treated as promotion** → a person acts with authority nobody granted and nobody can revoke.
- **Appointment treated as promotion** → a lateral move is experienced as a demotion by the person and as a favour by the team.
- **Recognition treated as appointment** → "we honoured her, so she must be in charge" — the mechanism of **[S-C: AC-3]** and **[S-ST: F-33]**.
- **Succession treated as appointment** → naming a successor becomes an implicit promise, and the successor experiences the eventual vacancy decision as a betrayal. **[P] Rule D-25: naming a successor creates no entitlement to the role, and is communicated to the successor in those terms.**

## 10.10 Demotion, and dignified exit from leadership

**[P]** Rule D-26 (Non-Punitive Downward Movement). Four downward movements, distinguished:

| Movement | When | What it means | What it must never mean |
|---|---|---|---|
| **Leadership → Specialist** | The person prefers expertise to management | **A lateral move to a different track, standing preserved** | Failure. **[S-C: §8.2]** — the specialist endpoint is complete |
| **Leadership → Contributor** | The person wants to stop carrying accountability | **A legitimate endpoint** **[S-C: §8.2 — "VERIFIED MEMBER (L5, no role) … votes nothing, manages nobody"]** | Expulsion; loss of record; loss of credential |
| **Temporary step-out** | Illness, family, study, work, exhaustion | **A pause, record intact, defined return route** **[S-C: H-18]** | Removal |
| **Removal from role** | Conduct, capability or governance failure (Part 19) | A specific finding about a specific role | A judgement of the person's worth (Rule D-1); loss of membership unless separately decided under **[S: Const. Art.8]** |

**[P] Dignified exit protocol** — the brief's requirement that a leader be able to say "I cannot continue in this role" without being treated as a failure:

```
1. STATEMENT      The leader states they cannot continue. NO REASON REQUIRED.
                  [S-C: H-17 - refusal must be cheap, silent, and not
                  recorded as a negative]
2. HANDOVER       PT-3...PT-6 executed. Gaps recorded, not concealed
                  [S-A: A-14 13.7].
3. INTERIM        TL-1...TL-5 applied (Part 12). Service and payment continue.
4. ACCESS CLOSURE Part 29 - reviewed, not assumed; no unnecessary retention.
5. RECORD         "Stepped down from [role] on [date]. Handover completed /
                  gaps recorded."  NO evaluation, NO reason field, NO score.
6. FUTURE         The person retains: membership, contribution record,
                  credentials, appreciation, the right to apply for any
                  future vacancy, and Elder/Mentor eligibility [S-C: 6.10].
7. STATEMENT TO OTHERS
                  In the organisation's name, factually, without evaluation:
                  "[Name] has completed their period as [role]. [Name] is
                  thanked for [specific contribution]. [New holder] now
                  holds the role."  [S-A: A-16 15.4; S-C: 21.5]
```

**[A]** Step 5 is the load-bearing one. **[I]** If the record contains a reason field, the exit becomes an evaluation — and an exit that is an evaluation will be avoided, which means leaders stay past the point where they are effective. That is **[S-ST: F-23]** at leadership level. **[S-C: §21.5]** already requires the organisation to speak about people who left without stigma; **Rule D-26 applies the same discipline to people who stepped down.**

## 10.11 Leadership return

**[P]** Rule D-27 (Return Without Inferiority, Without Automatic Authority).

| Principle | Mechanism |
|---|---|
| **Leaving is not permanent inferiority** | **[S-C: CK-6 alumni welcome test]** — "a person who left may return without penalty, and this is stated publicly"; §21.5 |
| **Returning does not restore old authority** | A returning leader enters through the **normal vacancy lifecycle** **[S: Ch.11]**, with Gate E and Gate R applied fresh. Prior role is **evidence**, not entitlement |
| **The record survives** | Contribution record and credentials survive exit **[S-C: §21.2, §24.2]** |
| **The gap is examined, not punished** | Gate R assesses current readiness, including lapsed skills; certification currency is checked **[S: Ch.12; S-A: A-10 §9.5]** |
| **Re-entry at a different level is normal** | Many returning leaders are better suited to specialist, Elder/Mentor or advisory standing — a **complete** position, not a consolation **[S-C: §8.2]** |

---

# PART 11 — SUCCESSION

## 11.1 Pathway versus state — the core defect

**[A]** The source has **pathways** and a **status field**, and no **obligation**.

| What exists | Source | What it does | What it does not do |
|---|---|---|---|
| A `Succession` column for every role at every level | **[S: Ch.9 final role catalogue]** — e.g. "Sub-Leader → Team Leader → higher level"; "Coordinator → Sub-HR → HR Manager"; "Coordinator → Sub-Safety → Safety Lead" | Shows the *route* | Does not say whether anyone is *on* the route |
| `succession_status` field — "Metrics, review frequency, **ready/acting/nominated status and succession pathway**" | **[S: Ch.22]** | Provides the *values* | No rule requires the field to be populated; no report surfaces it; no consequence follows emptiness |
| "Deputies support continuity and succession" | **[S: Ch.13 step 6]** | States the *purpose* of sub-roles | Does not require a deputy to exist — **[S: Ch.10 State A]** says "Sub-Leader **if available**" |
| "Replacement/dynamic succession" as the escalation for leadership failure | **[S: Ch.14]** | Provides the *response* | Assumes a replacement exists |
| Succession readiness as an output of the performance system | **[S: Ch.25 step 6]** | Routes to succession | Does not define readiness |
| Apex succession S1–S8, reserved matters, Interim Authority Order, continuity test | **[S-A: A-14]** | **Solves the apex** | Explicitly does not solve Mohalla level — **[S-B: §24.4]**: "v1.3-A A-14 built succession for the apex (S1–S8). **Nothing equivalent exists at Mohalla level, where absence is far more frequent**" |
| Successor-before-transition | **[S-B: B-18(1)]** | Makes promotion non-destructive | Applies only at promotion, not as a standing state |
| The successor test | **[S-A: A-16 §15.3 test 4]** — "For every National-level role and every critical dependency, is there a named, trained, willing person who could act within a defined period?" | **States the standard** | Applies to National level and critical dependencies only |

> **[A] The defect in one sentence: the architecture knows what succession is for, has a field to record it, and has no rule that makes its absence visible.** **[I]** An unmeasured obligation is an optional one — and succession is the obligation every leader has the least natural incentive to fulfil, because fulfilling it means making yourself replaceable.

## 11.2 The succession state model SS-0 … SS-5

**[P] Amendment L-08 — Succession State Model.** Six states, extending the source's own "ready/acting/nominated" values **[S: Ch.22]** rather than replacing them:

| State | Name | Definition | Maps to source value | Organisational meaning |
|---|---|---|---|---|
| **SS-0** | **No successor identified** | No person named | *(absent from source values — this is the addition)* | **A reported organisational risk.** Not a criticism of the holder; a statement about the organisation's exposure |
| **SS-1** | **Candidate identified** | A person is named, willing, and eligible (Gate E), not yet assessed | ≈ "nominated" | Exposure reduced; development not started |
| **SS-2** | **Successor developing** | Named, eligible, in active development (SD-1…SD-6), with a recorded plan | *(new)* | **The state most roles should be in most of the time** |
| **SS-3** | **Successor ready** | Named, eligible, **Gate R = READY**, has acted in scope at least once | ≈ "ready" | Transition can occur without a gap |
| **SS-4** | **Interim coverage ready** | A person can act under TL-1…TL-5 within a stated period, whether or not they are a permanent candidate | ≈ "acting" | **Continuity assured even where permanent succession is not** |
| **SS-5** | **Emergency continuity ready** | The Local Interim Authority Order **[S-B: B-19]** is written, current, and its named sequence has been exercised | *(new; extends **[S-A: A-14 §13.3 item 2]** downward)* | The team survives an unannounced absence |

**[P] Rule D-28 (State Rules).**
1. **SS-4 and SS-5 are achievable by any team, at any size, at negligible cost** — they require a written order and a named sequence, not a trained person. **They are therefore mandatory from Stage 0** and form part of the MVLS (Part 40).
2. **SS-1…SS-3 are scale-dependent** and cannot be required of a team too small to contain a candidate (§11.7).
3. **State attaches to the ROLE, not to the person.** It travels with the vacancy record **[S: Ch.11 step 1]**.
4. **State is reported upward in aggregate** — City, State and National dashboards show the *distribution of states across covered roles*, never a named individual's readiness in comparative form.
5. **SS-0 is not a performance deduction for the holder.** It is an organisational exposure. Where it persists across two review cycles it becomes a **City obligation** to supply a candidate (§11.7), not a leader obligation.

## 11.3 Which roles require mandatory succession planning

**[P]** Applying **[S-B: §26.2]**'s irreducibility criterion — *a control is in the minimum set iff its absence causes irreversible harm to money, safety, identity, privacy or public truth* — to succession:

| Role | Mandatory state from Stage 0 | Reasoning | Source |
|---|---|---|---|
| **Mohalla Team Leader** | **SS-5 and SS-4 mandatory**; SS-1…SS-3 as scale permits | Decisions and payments stop without them — **[S-B: HC-02]**: "Payments and decisions stop … because Funds cannot self-approve **[S: Ch.18]**; float/reserve requests cannot be signed" | **[S: Ch.9; S-B: B-19]** |
| **Funds Manager** | **SS-5, SS-4** | Money integrity is irreversible-harm; the four hands must remain distinct even during absence | **[S: Ch.18]** |
| **HR & Verification Manager** | **SS-5, SS-4** | Verification is MVC-2, irreducible **[S-B: §26.2]** | **[S: Ch.12; SOP-02]** |
| **Safety / Protection Lead** | **SS-5, SS-4** | MVC-3; non-deferrable **[S-B: §26.2; S-A: A-08, A-09]**. **Stop-work authority must exist at all times** | **[S: Ch.16; Ch.9]** |
| **City Team Leader / City Head** | **SS-4, SS-5, and SS-2 or better** | City performs the shared functions on which small teams depend **[S-B: §26.4]**; a City gap stops `K` teams at once | **[S: Ch.7]** |
| **State Team Leader / State Head** | **SS-2 or better** | State holds the specialist pool **[S: Ch.6]** and the escalation filter | **[S: Ch.6]** |
| **National leadership** | **SS-3 or better for every role**; the successor test applies annually | **[S-A: A-16 §15.3 test 4]** verbatim | **[S-A]** |
| **Apex (CEO / founder)** | **S1–S8 scenarios, Interim Authority Order, dual custody, continuity test** | Fully specified already | **[S-A: A-14]** |
| **Auditor / Audit & Ethics** | **SS-4** | Audit independence must survive absence — "Review only; not operational commander" | **[S: Ch.23, Ch.27]** |
| **Data protection accountable officer** | **SS-4 mandatory** | "A named accountable officer for data protection at all times, including during a vacancy, with the ability to execute breach notification duties" **[S-A: A-14 §13.4]** **[V]** | **[S-A]** |
| **AI & Business Manager** | **SS-4** where a venture is live | Live customer commitments must not be orphaned **[S: Ch.17 steps 8–11]** | **[S]** |
| **Editor / Social Media Manager** | **SS-4** | MVC-9 public-statement control; a misstatement is irreversible | **[S: SOP-14; S-B: §26.2]** |
| **Ground-Level, Planner, Volunteer, Warehouse Managers** | **SS-4** where workload justifies; otherwise covered by role combination | State A permits combination; succession is achieved by cross-training rather than by a named deputy | **[S: Ch.10]** |

**[A]** The list is deliberately **shorter at the bottom and longer at the top** — the opposite of how most organisations do it — and follows directly from **[S-B: §26.2]**'s logic: a Mohalla team's irreducible succession need is *continuity of four capabilities* (decide, pay, verify, stop-work), not a bench of trained managers.

## 11.4 The successor requirement as a leadership duty

**[P]** The brief asks whether "a leader who refuses to develop a successor is creating organisational dependency" should be adopted, and what happens when no suitable successor exists.

| Question | Answer | Reasoning |
|---|---|---|
| Should successor development be part of leadership performance? | **Yes — as a GATE on promotion (LG-7) and as a GATED element of team performance (Part 7 §7.1), never as a weighted score** | **[S: Ch.25 step 6]** already routes performance to "succession readiness"; **[S-B: B-18(1)]** already requires successor-before-transition. Gating avoids the small-team arithmetic problem (§11.7) that weighting would create |
| What counts as successor development? | Six admissible forms, each requiring evidence — §11.5 | Prevents "I mentioned it in a meeting" from counting |
| What happens when no suitable successor exists? | **The obligation transfers to the City**, which must supply a candidate from the shared pool, or record why it cannot | **[S-ST: F-03(10)]** city-shared control roles; **[S-B: §26.4]**; **[S-ST: F-23(7) ii]** out-of-team review. **A leader cannot create a person who does not exist** |
| Does it affect promotion? | **Yes** — LG-7. A leader at SS-0 without a documented structural impossibility is **not promoted**; they are **supported** first | Otherwise promotion systematically rewards the leaders who hoarded |
| Does it affect performance? | **Yes, as a gate** — PG-6 fires only on **deliberate blocking**, never on absence. Absence is reported, not punished | The distinction between *cannot* and *will not* is the whole fairness of the rule |
| Does it create unfair pressure in very small teams? | **Yes, if designed carelessly** — hence §11.7 | **[S: Ch.10 State A]** "Sub-Leader **if available**" already acknowledges the constraint |

## 11.5 What counts as successor development — six admissible forms

**[P]** Each requires **LE-5 evidence** — another person's record must have changed:

| Form | Evidence | Source instrument |
|---|---|---|
| **SD-1 Delegation with real scope** | Active delegation records with scope, limits and dates; the delegate's own output | **[S: Ch.10; Ch.22 `delegated_authority`]** |
| **SD-2 Supervised acting** | The candidate acted in the role under TL-2 / TL-3, with a recorded observation | Part 12; AP-3 |
| **SD-3 Structured shadowing** | Recorded shadowing periods with a written observation from the candidate | AP-1 |
| **SD-4 Teaching** | The candidate delivered training to others, with attendance and effect recorded | **[S: Ch.12; S-C: §47.2 S5]** |
| **SD-5 Cross-team assignment** | The candidate worked in another team, producing a record there | AP-6; **[S: Ch.6 specialist deployment]** |
| **SD-6 Succession planning itself** | The candidate helped produce the Interim Authority Order, the handover pack or the role playbook | **[S-B: B-19]**; Part 12 §12.8 |

**[A]** What is **not** admissible: naming someone; expressing confidence in someone; recommending someone; the named person's length of service; or the named person's self-assessment. **[I]** All of these are cheap, and a cheap obligation is met nominally and fails actually — which is **GF-23 (artificial successor appointment)**, simulated in Part 42 as **P-11**.

## 11.6 Successor development as a performance dimension — unintended consequences

**[P]** Five consequences, each with a control:

| Consequence | Mechanism | Control |
|---|---|---|
| **UC-1 Artificial successor appointment** | A leader names a compliant person to clear the gate | Admissible forms require **LE-5 evidence** (§11.5); the named successor's actual acting performance is reviewed independently (AP-3); an artificial appointment is a form of evidence fabrication → **PG-4** |
| **UC-2 Favouritism** | The successor is a relative or friend | Conflict-of-interest declaration covers succession nomination (Part 35 §35.2); the successor's Gate R is assessed **out of team** (Part 15 §15.3, Rule D-45); **Rule D-25** — naming creates no entitlement, so favouritism buys nothing durable |
| **UC-3 Premature promotion of the successor** | The leader pushes the successor up to clear their own gate | SS-3 requires **Gate R = READY**, assessed by someone else; LG-2 applies to the successor's own promotion independently |
| **UC-4 Succession gaming across cycles** | A leader cycles nominal successors to keep the state green | State history is retained; **a state that repeatedly reverts to SS-0/SS-1 is an anomaly signal** for RV-2 review; the *person's* development record counts, not the state label |
| **UC-5 Creating successors merely to satisfy metrics** | Development activity that produces no capability | LE-5 requires an outcome in another person's record; **SD-1…SD-6 without resulting capability is unevidenced**, and the state stays at SS-1 |

**[A]** The deepest control is structural rather than procedural: **because the successor's own promotion is independently gated (LG-1…LG-10), and because readiness is assessed out of team, a leader gains nothing durable from a weak successor.** The gate rewards *real* development, because real development is the only thing that produces a person who passes an independent assessment.

## 11.7 The small-team exception — stated precisely

**[P]** Rule D-29 (Structural Impossibility). Where a team cannot contain a successor candidate:

| Condition | Test | Consequence |
|---|---|---|
| The team has fewer verified members than the role structure requires to produce a candidate | Computed from `N_ver`, roles filled, and the nine-function requirement **[S: Ch.10]** — **no numeric threshold invented** **[S: Ch.33]** | LG-7 satisfied by **SS-4/SS-5 only**, plus a City-supplied candidate or a recorded City obligation |
| No eligible member exists — all are L0–L4, all have refused leadership **[S-C: H-17]**, or all have unresolved conduct matters | From HR records | Same |
| The only candidate is the leader's close relation | Conflict register | Same, **and** out-of-team assessment is mandatory |
| The team is in provisional status (§8.5) | Maturity band | LG-7 deferred until baseline completes |

**[P]** The City obligation, made explicit:

> **Where a Mohalla team records SS-0 for two consecutive review cycles and Rule D-29 applies, the obligation to supply a successor candidate transfers to the City layer**, which may: (a) assign a candidate from another team under SD-5 cross-team assignment; (b) provide a City-shared control role **[S-ST: F-03(10); S-B: §26.4]**; (c) open a vacancy externally through the City **[S: Ch.11 step 3 — "Internal/external eligibility"]**; or (d) record that it cannot, with a reason and a review date. **Option (d) is reported in the City's aggregate report so that a pattern becomes visible.**

**[A]** This resolves the fairness problem the brief identifies — "whether it creates unfair pressure in very small teams" — by **moving the obligation to the layer that can actually discharge it**, which is the same logic **[S-B: §26.4]** applies to governance: "The Mohalla team does not need to *be* given shared services — it needs to be *allowed to use* the ones already designed."

## 11.8 The succession loop

**[P]** Per the brief's requirement:

```
ROLE -> SUCCESSOR IDENTIFICATION -> DEVELOPMENT -> SHADOWING
 ^                                                     |
 |                                                     v
REVIEW <- HANDOVER <- READINESS <- DELEGATION <---------+
```

| Stage | Actor | Output | Source |
|---|---|---|---|
| **Role** | — | Role brief: scope, authority limits, load, evidence requirements, review cadence, funder | **[S: Ch.9 role-family fields]** |
| **Successor identification** | Role-holder + HR | SS-1: a named, willing, eligible person | **[S: Ch.22 — "nominated"]** |
| **Development** | Role-holder + City training | A recorded plan using SD-1…SD-6 | **[S: Ch.12; S-B: §26.4]** |
| **Shadowing** | Role-holder | AP-1 observations | **[P]** |
| **Delegation** | Role-holder, within limits | AP-2: real scope, recorded dates | **[S: Ch.10, Ch.22]** |
| **Readiness** | **Out-of-team assessor** | SS-3: Gate R = READY | Part 3 §3.4 |
| **Handover** | Both | PT-3…PT-6 pack, signed, gaps recorded | **[S-A: A-14 §13.7]** |
| **Review** | Reviewer per Rule D-16 | Post-transition review; lessons entry | **[S-B: B-18; S-A: A-15 M5]** |

**[A]** The loop's weakest link is **Readiness**, because it is the only stage requiring a person from outside the team — and at S0–S1 there may be no outside **[S-ST: §23.1]**. **[P]** Where no out-of-team assessor exists, the City performs the assessment **[S: Ch.7]**; where no City exists, the State **[S: Ch.6]**; where neither exists, **the assessment is recorded as PROVISIONAL and the appointment is time-bounded with mandatory reassessment at the first available independence.** **[A]** That last clause matters: it is better to appoint provisionally and reassess than to appoint on self-assessment and never reassess.

## 11.9 Succession and the four annual institutional tests

**[S-A: A-16 §15.3]** four tests, generalised by v1.3-D from the apex to every covered role:

| Test | Apex form **[S-A]** | Generalised form **[P]** | Instrument |
|---|---|---|---|
| **1. Absence** | "If the founder were unavailable for twelve months, would an external observer notice a difference in what the organisation does?" | **If any covered role-holder were unavailable for a stated period, would the team's service, payment, verification and stop-work capability continue?** | Part 38 resilience test; **[S-A: A-14 §13.8]** continuity test |
| **2. Attribution** | "What share of recorded decisions were justified by reference to a person rather than to a rule, a record, or a reason?" | Same, sampled per team and per city | **[S-A: A-15 M1]** sampling by Audit & Ethics |
| **3. Dissent** | "Did any member successfully challenge a leader's decision through the formal route, and are they still a member in good standing? **A zero count is a warning sign, not a clean bill of health**" | Same, per city | Part 18; **[S-C: CK-1]** |
| **4. Successor** | "For every National-level role and every critical dependency, is there a named, trained, willing person who could act within a defined period?" | **For every covered role at every level, what is the succession state?** | **SS-0…SS-5 distribution report** |

**[P] Amendment L-08(4).** Test 4 becomes a **standing aggregate report** at City, State and National level showing the distribution of SS states across covered roles, with SS-0 and SS-1 counts highlighted. **No individual is named in the aggregate report.**

**[A]** Why the aggregate form matters: **[I]** a succession report that names individuals becomes a list of who is being groomed, which creates factions, resentment and speculation — exactly the dynamics **[S-C: AC-3]** and **[S-ST: F-13]** warn about. **A distribution report creates organisational pressure without creating personal politics.**

---

# PART 12 — CONTINUITY

## 12.1 The five temporary-leadership instruments

**[P] Amendment L-10 — TL-1 … TL-5.** Each carries the five attributes the brief requires: **scope, start date, end condition, authority limits, review requirement.**

**[S] Preserved verbatim throughout: "A Sub-Role is a delegated operational position, not an automatic transfer of all authority belonging to the Primary Role. Authority must be explicit, recorded, RBAC-limited and reviewed"** **[S: Ch.10]**.

| Instrument | Definition | Scope | Start | End condition | Authority limits | Review |
|---|---|---|---|---|---|---|
| **TL-1 ACTING LEADER** | The designated deputy performs the primary role during a **foreseen, short** absence | Full primary scope **except** reserved matters | Recorded date | Return of the holder, or expiry of the stated period | Reserved matters excluded; financial limits unchanged **[S: App. E]**; no power to appoint, remove, or change the pay formula | Recorded at start; reviewed if extended |
| **TL-2 INTERIM LEADER** | A person holds the role during a **vacancy**, pending appointment | Full primary scope except reserved matters and except decisions that would bind the permanent holder beyond a stated horizon | On vacancy | On permanent appointment, or expiry with one recorded extension | As TL-1, plus: **may not make irreversible structural commitments**; may not alter the succession state of other roles | **Mandatory midpoint review** and review at expiry |
| **TL-3 EMERGENCY LEADER** | A person holds **specific** authority during a declared emergency | **Only** what the emergency requires — life, safety, evidence, funds, continuity of committed service **[S-A: A-14 §13.6]** | On declaration, by whoever is empowered to declare | **Automatic expiry** at a stated short interval unless renewed by a recorded decision of a higher authority | Reserved matters absolutely excluded **[S-A: A-14 §13.3 item 3]**; no permanent appointments; no constitutional or policy change; no mission change | **Mandatory independent review after closure** (Part 37) |
| **TL-4 DELEGATED AUTHORITY** | A specific decision or function is delegated to a named person inside an existing role | Named function only | Recorded `delegation_start_date` | **Automatic expiry** at `delegation_end_date` **[S: Ch.22]** | Cannot exceed the delegator's own authority; cannot be sub-delegated without a fresh record | Reviewer named in the record **[S: Ch.22]** |
| **TL-5 PERMANENT APPOINTMENT** | The role is filled through the vacancy lifecycle | Full role scope per RBAC | Appointment date | Review date — not permanent in the sense of irrevocable | Per role authority limits **[S: Ch.9]** and RBAC **[S: Ch.23]** | RV-1 / RV-2 per Rule D-16 |

**[P] Rule D-30 (Temporary Authority Rules).**
1. **Every temporary instrument expires.** An instrument with no end condition is not temporary. **[S: Ch.22]** already provides `delegation_end_date` with "automatic expiry/review".
2. **An extension is a new decision**, recorded, with a reason — never a silence.
3. **Reserved matters are excluded from TL-1, TL-2 and TL-3 absolutely** **[S-A: A-14 §13.3 item 3]**: constitutional or Tier-1 amendment; change of mission, name, brand or entity structure; transfer or encumbrance of assets, reserves or the social-impact fund; dissolution, merger or restructuring; appointment of a permanent CEO; changes to the A-08 DO-NOT list; changes to the waterfall priority order.
4. **A temporary holder may not appoint their own permanent successor**, and may not alter the succession state of the role they temporarily hold — except to record SS-4/SS-5 coverage.
5. **A temporary holder's decisions are recorded in their own name as temporary holder**, so the record shows who actually decided.
6. **Continuity during dispute:** "where the apex is contested or a dispute is unresolved, **operations continue under the existing delegated authority** and no faction may interrupt service, payment, safety response or record-keeping" **[S-A: A-14 §13.6]** — **applied at every level, not only the apex.**

## 12.2 Leader absence — the eleven cases

**[P]** The brief lists nine; two are added from **[S-A: A-14 S6]** and **[S-B: §29]**.

| Case | Detection | Continuity | Authority position | Specific risk |
|---|---|---|---|---|
| **1. Illness (short)** | Self-report; absence from cadence | TL-1 Acting | Reserved matters excluded | Delegation renewed indefinitely without review |
| **2. Illness (long)** | Medical certification, or a determination by the body defined in the instrument **[V]** | TL-2 Interim; **SS-4 must already exist** | As TL-1, plus no irreversible commitments | The team waits for a return that will not happen |
| **3. Travel / planned absence** | Advance notice | TL-1, or TL-4 for specific functions | Scoped | "Available by phone" becomes an unrecorded shadow authority — **prohibited: authority must be recorded, not merely reachable** |
| **4. Resignation** | Written statement | **Rule D-26 dignified exit protocol**; TL-2 until appointment | Interim | Handover skipped because the departure is awkward; access not closed |
| **5. Disappearance / unreachable** | No contact beyond a stated period; automatic trigger | **TL-3 → TL-2**; emergency access procedure **[S-A: A-14 §13.4]** opened on a recorded trigger | Interim, with dual-custody confirmation | Two people claim authority simultaneously (**Scenario J**) |
| **6. Suspension** | Suspension order **[S: App. E]** | TL-2 | **The suspended person holds nothing** | The suspended person continues to act informally through allies |
| **7. Removal** | Removal decision **[S: App. E; Const. Art.8]** | TL-2 | None | Retaliation against complainants (**PG-10**); evidence destruction |
| **8. Loss of access** (credential, device, account) | Access log; failed authentication; report | TL-4 for the specific function; credential reissue under Part 29 | Scoped | **Account takeover** (§29.5) — loss of access and theft of access look identical from inside |
| **9. Death** | Certification | TL-2 immediately; **the master handover checklist and dual-custody arrangements are the only source of continuity** **[S-A: A-14 §13.7]** | Interim; reserved matters frozen | Bank-mandate freeze → **worker compensation cannot be paid** → priority 1 breached. **[S-A: A-14 §13.4]**: "Minimum of two authorised signatories with a defined continuity rule so that worker compensation can be paid during an apex vacancy" — **applied at every level** |
| **10. Unavailable during an emergency** | Incident report **[S-A: A-09]** | **TL-3 Emergency Leader**; the Safety Lead may act immediately **[S: App. E — "High-risk/emergency support: Safety Lead may act immediately"]** | Emergency scope only | Emergency authority persisting after the emergency (Part 37) |
| **11. Conflict of interest arises** | Declaration; discovery | **Recusal** on the conflicted matter only; TL-4 to another person for that matter **[S-A: A-14 S6]** | Only the conflicted matter is affected | The conflicted person decides the conflicted matter and records it as routine |

**[P] Rule D-31 (No Person May Be the Only Source).** "The organisation must not depend on one person remembering everything." Implemented as:
- **SS-5 emergency continuity ready** is mandatory for every covered role from Stage 0 (§11.3);
- the **Local Interim Authority Order [S-B: B-19]** is written, current, and names (i) who holds decision authority during absence, (ii) for how long, (iii) what they may **not** decide — reserve requests, venture approval, conduct outcomes, payment-formula changes — and (iv) the City fallback where no local deputy exists;
- **role playbooks** exist for every covered role (Part 28);
- **dual custody** of credentials applies at every level, not only at the apex **[S-A: A-14 §13.4]**;
- **the tiered redundancy rule** (§12.7) is applied where feasible, and its infeasibility is recorded rather than concealed.

## 12.3 Emergency succession without permanent power grabs

**[P]** The brief's seven requirements, implemented:

| Requirement | Mechanism |
|---|---|
| **Predefined order** | The Interim Authority Order names a **sequence by role**, with names appended in a separately maintained schedule **[S-A: A-14 §13.3 item 2]** — so the order survives personnel change without being rewritten |
| **Temporary authority** | TL-3, scope-limited to what the emergency requires |
| **Automatic expiry** | TL-3 expires at a stated short interval unless renewed by a recorded decision of a higher authority. **Renewal is a decision, not a continuation** |
| **Documentation** | Every act under TL-3 recorded with reason **[S-A: A-15 M1]**; both the declaration and its closure recorded |
| **Independent review** | Mandatory post-crisis review by Audit & Ethics or an out-of-line reviewer (Part 37) |
| **Handover** | On closure, PT-3…PT-6 executed in reverse: authority, access, records and delegations returned or transferred to the permanent holder |
| **Reappointment / confirmation** | Where the emergency produced a *de facto* permanent change, the normal vacancy lifecycle runs — **emergency service is evidence, not entitlement** (Rule D-24) |

**[P] Rule D-32 (Emergency Non-Conversion Rule).** Time served under TL-3 **may be cited as LE-3 behaviour evidence** in a later assessment — it shows how a person acted under pressure — **but may never be cited as tenure, seniority or entitlement**, and may never be used to argue that an emergency appointment should become permanent. **[A]** Without this rule, every emergency becomes a coup with paperwork.

## 12.4 Continuity of the four irreducible capabilities

**[A]** **[S-B: §26.2]** established four irreducible harm domains — money, safety, identity, privacy — plus public truth. **[P]** Continuity is therefore specified as **four capabilities that must never lapse**, whatever happens to any individual:

| Capability | Who holds it | Continuity requirement | Source |
|---|---|---|---|
| **DECIDE** | Team Leader | TL-1 / TL-2 / TL-3 sequence named; Interim Authority Order written | **[S: Ch.8 — "Decision: Team Leader within authority"; S-B: B-19]** |
| **PAY** | Funds Manager + approver | **Two signatories minimum, at every level**, so priority-1 worker compensation can be paid during any single absence | **[S: Ch.18 segregation; S-A: A-14 §13.4]** |
| **VERIFY** | HR & Verification | A verifier is available; where none exists locally, the City performs it | **[S-B: MVC-2; §26.4]** |
| **STOP** | Safety / Protection Lead | Stop-work authority exists at all times and does not depend on one person's presence | **[S: Ch.9 — "Stop-work/escalate within policy"; Ch.16; S-A: A-09]** |

**[P] Rule D-33 (Four-Capability Continuity Rule).** **A team may not be recognised as formed, and may not be permitted to operate, unless all four capabilities have a named continuity route.** Proposed as an **addition** to the **[S: Ch.13]** autonomy-readiness gate set and to the **[S: Ch.30]** Phase 2 entry conditions — not as a replacement for either.

**[A]** Note the interaction with **[S: Ch.10 State A]**: "Small size never removes safety, HR verification, finance integrity or evidence duties." **Rule D-33 does not require a small team to hold four people; it requires four routes.** A route may run to the City **[S-B: §26.4]** — and **[S-B: §3.3]** already proves the team cannot satisfy segregation of duties alone, **so the route must run outward in any case.**

## 12.5 The transition loop

**[P]** Per the brief's requirement:

```
DECISION -> ANNOUNCEMENT -> HANDOVER -> ACCESS CHANGE -> RESPONSIBILITY
   ^                                                       TRANSFER
   |                                                          |
   +---------------- MONITORING <- CLOSURE <------------------+
```

| Stage | Output | Failure mode if skipped |
|---|---|---|
| **Decision** | Promotion Decision Record (§10.8) with reasons and conflicts | An unexplainable appointment, which reads as favouritism regardless of merit |
| **Announcement** | PT-7: team, City, stakeholders; in the operating languages; in the organisation's name | Rumour fills the vacuum; the incoming holder's authority is contested |
| **Handover** | The KT pack, signed by both, **gaps recorded** | Tacit knowledge lost; the incoming holder discovers problems as crises |
| **Access change** | Part 29: authority review, access review, credential update, financial-permission review, data-access review, device/account review, delegation expiry, audit-log preservation | **The single most common real-world failure:** the outgoing holder retains access "because they might be needed" |
| **Responsibility transfer** | PT-4 delegations; PT-6 record ownership | Records left ownerless; decisions made by nobody |
| **Monitoring** | PT-9 post-transition review at a stated interval | The organisation never learns whether its selection model works |
| **Closure** | Lessons entry **[S-A: A-15 M5]** with the "did it work" column | The same transition failure recurs in the next city |

## 12.6 Continuity dashboard

**[P]** Internal only; **no sensitive information broadly exposed**; RBAC-scoped per **[S: Ch.23]**.

| Field | Visible to | Source |
|---|---|---|
| Role, level, team | All internal | **[S: Ch.22]** |
| Current holder (as a role, not personal data) | Team and upward | **[S: Ch.22 `assigned_member_id`]** |
| Vacancy status — Open / Filled / Reserved / Temporarily inactive / Suspended / Closed | Team and upward | **[S: Ch.11]** — **source values, unchanged** |
| **Succession state SS-0…SS-5** | City and upward **in aggregate**; holder and HR individually | **[S: Ch.22 `succession_status`]**, extended |
| **Readiness** (Gate R output for the named successor) | HR, assessors, appointing authority, audit — **not published** | Part 3 §3.4 |
| **Risk** (exposure class: critical / important / routine) | City and upward | Derived from §11.3 role class |
| **Review date** | Holder and upward | **[S: Ch.22 `review_date`]** |
| **Active delegations and expiry dates** | Holder, HR, audit | **[S: Ch.22]** |
| **Continuity status of DECIDE / PAY / VERIFY / STOP** | Team and upward | Rule D-33 |
| **Last continuity exercise date and findings** | City and upward | Part 38 §38.5 |

**[A]** Cross-reference: **[S-B: §27.3]** already lists "Leadership pipeline: named successor per role" as a Human-panel dashboard field sourced from **[S: Ch.9 succession column; Ch.26; B-18(1)]**, and **[S-B: §27.5]** lists "Dependency on one leader (functions held; successor named?)". **The continuity dashboard is therefore not a new data estate; it is the completion of two fields v1.3-B already specified.**

## 12.7 The three-person test

**[P]** The brief proposes: for every critical function — **one person knows it, two people can perform it, three people understand it** — and asks that it not be adopted automatically but tested against **[S-B]**'s control budget.

| Test | Result |
|---|---|
| Is it compatible with the source? | **Partially.** **[S: Ch.18]** requires the four finance hands to be *distinct* — a stronger version for money. **[S: Ch.10 State A]** permits role *combination* for small teams — a weaker version. **[S: Ch.13 step 6]** states that deputies support continuity. The three-person test sits between them |
| Is it feasible at State A? | **No, not universally.** A State A team has `⌈9/c⌉` role-holders **[S-B: §40.2]**, where `c` is the role-combination factor. Three people per critical function would require a team larger than State A contemplates |
| Does it breach the control budget? | **Yes, if applied to all functions.** **[S-B: §26.1]**: `σ_max` is derived from the team's own economics; a universal three-deep bench consumes hours the team does not have |
| Does it create a new risk? | **Yes:** a large bench of people who *can* perform a function but do not is a pool of unexercised authority — it decays, and it creates ambiguity about who actually decides, which **[S: Ch.22]** expressly guards against ("prevents ambiguous multiple heads") |

**[P] Rule D-34 (Tiered Redundancy Rule).** Adopted in **tiered** form, not universally:

| Function class | Redundancy requirement | Reasoning |
|---|---|---|
| **The four irreducible capabilities** (DECIDE, PAY, VERIFY, STOP) | **Two people can perform it; the route is documented and exercised** | Irreversible harm; Rule D-33 |
| **Finance segregation hands** | **Four distinct hands, at least one outside the team where necessary** | **[S: Ch.18]**; **[S-B: MVC-1, §3.3]** — already stronger than three-person |
| **Other primary roles** | **One can perform; one understands; the playbook exists** | A playbook substitutes for a third person at far lower cost (Part 28) |
| **Coordinator and supporting roles** | **Cross-training within the team; no numeric requirement** | **[S: Ch.10 State A]** combination is permitted |
| **City / State / National roles** | **Three-person test applied in full** | The layer has the population to support it, and the consequence of a gap is multiplied by `K` |

**[A]** Substituting a **playbook** for a **third person** at team level is the economically decisive move: **[C]** a document costs hours once; a redundant person costs hours continuously. **[S-B: §26.3]**'s rule — automate or retire — favours the document. **But a playbook is only a substitute if it is exercised**, which is why Part 38 §38.5 requires an unannounced continuity exercise.

## 12.8 Knowledge-transfer artifacts

**[P]** Ten standard transition artifacts, each with a data-minimisation rule:

| # | Artifact | Content | Minimisation rule |
|---|---|---|---|
| **KT-1** | **Role brief** | Purpose, authority, limits, inputs, outputs, metrics, training, reporting, succession **[S: Ch.9 role-family fields]** | Contains no personal data |
| **KT-2** | **Active projects** | Objective, status, roles, budget, evidence plan, outcome expectation, deadlines **[S: Ch.8 step 6]** | Beneficiary data at the minimum required to continue the work **[S-A: A-19]** |
| **KT-3** | **Unresolved problems** | What is wrong, what was tried, what is blocked, who owns it | Individuals named only where ownership requires it |
| **KT-4** | **Critical contacts** | Role, function, consent status | **Contact details of private individuals minimised**; institutional contacts preferred |
| **KT-5** | **Access list** | Systems, permissions, credential custody, delegation records | **Credential values never appear in the artifact** — custody location only **[S-A: A-14 §13.4]** |
| **KT-6** | **Financial status** | Ledger position, receivables, accruals **[S-B: B-05]**, reserves, float, pending approvals | Per **[S-A: A-17]** classification |
| **KT-7** | **Risks** | Open risks, incidents under review, safety concerns | Sealed categories handled per **[S-A: A-20]** case-scoped access |
| **KT-8** | **Upcoming deadlines** | Statutory, contractual, reporting, cadence | — |
| **KT-9** | **Successor status** | SS state, development plan, delegation history | The successor's own *assessment* is **not** in the handover pack — it belongs to the successor and to HR |
| **KT-10** | **Decisions pending** | What must be decided, by when, by whom, with what evidence | Includes the reason-record requirement **[S-A: A-15 M1]** |

**[P] Rules:** handover completed within a stated period and signed by both parties; **gaps recorded rather than concealed** **[S-A: A-14 §13.7]**; Audit & Ethics verifies completion; the outgoing person remains reachable for a defined advisory period; **the pack is retained as an institutional record, not a personal one** **[S-A: A-15 M4]**.

---

# PART 13 — SPECIALIST PATH

## 13.1 The problem the path solves

**[S-ST: F-24]** — "the most capable members … conclude that after three years of excellent work their expected reward is 'still Team Leader of the same mohalla', and leave for something that recognises them." **[S-ST: F-24(6)]** — "Role succession exists *within* a team and *within* a function — but a 10-person team has ~11 primary roles, so **intra-team progression saturates almost immediately. The only real upward path is positional, and it is scarce.**"

**[S-B: §24.5]** — "**Leader supply is a *stock* problem, not a *training-content* problem.**"
**[S-C: §47.1]** — "**A specialist path multiplies the useful population without multiplying the management population** — which is the only way to raise `P_max` without raising `H_gov`."

**[A]** Three separate problems, one instrument:
1. **Motivational:** capable people need a future that does not depend on someone else's vacancy.
2. **Economic:** delivery capacity `P_max` **[S-B: §17.2]** rises with skilled people, while `H_gov` rises with managers. **A specialist adds capacity without adding governance.**
3. **Governance:** the management population is the population that carries the compliance load **[S-B: §25.5]**. Keeping it small is a control-budget decision, not a snub.

## 13.2 The three tracks, plus two endpoints

**[P] Amendment L-11 — Triple Career Architecture.** The brief asks whether a third Builder/Venture track is needed "based on v1.3-C". **[A] It is needed, and v1.3-C already created it: [S-C: §6.9 LEVEL 8 — ORGANISATIONAL BUILDER]** — "Create new teams, ventures, systems and partnerships; sponsor others … **L8 is an endpoint, not a rung.**"

| Track | Path | What grows | What never grows | Source |
|---|---|---|---|---|
| **LEADERSHIP** | Supporting Member → Coordinator → Sub-Role → Primary Role → higher level | Responsibility, accountability, authority, scrutiny, duty of care | Human worth; unrestricted data; unrestricted money; any entitlement to personal loyalty | **[S: Ch.10 universal role ladder]** verbatim |
| **SPECIALIST** | Contributor → Specialist → Senior Specialist → Expert / Advisor → Institutional Specialist | Skill scope, verification authority within the skill, advisory standing, credential | **Command over people** | **[S-C: §47.2 H-11 S1…S6]** |
| **BUILDER** | Contributor → Builder → Sponsor of teams and ventures | Creation authority across teams, with charter limits | **Constitutional amendment authority** — reserved matters **[S-A: A-13/A-14]** | **[S-C: §6.9 L8]** |
| **CONTRIBUTOR (endpoint)** | — | Nothing. **It is complete** | — | **[S-C: §8.2 — "VERIFIED MEMBER (L5, no role): holds membership, takes tasks, is paid for venture work, votes nothing, manages nobody"]** |
| **ELDER / MENTOR (standing)** | Available from L3 upward | Respect, teaching role, memory, mediation, witnessing | **RBAC command permissions and scoring — excluded absolutely** | **[S-C: §6.10]** |

**[P] Rule D-35 (No Track Superiority).** No track, endpoint or standing may be described, displayed, ordered or rewarded as inherently superior to another. Concretely:
- **No ordinal numbering** of tracks, or of positions within the Specialist track, in any public medium **[S-C: SR-2]**;
- Recognition within the Specialist track uses **absolute** instruments — credential, milestone, story — never comparative **[S-C: §44.3]**;
- Compensation for specialist work follows the same waterfall as all verified work **[S: Ch.18]**: where a specialist performs venture work, priority 1 applies; where engaged as a supplier, priority 3 applies **[S-C: §47.4 condition 4]**;
- **A person who says "I want to remain an expert" is recorded as having made a complete choice, not a declined one** (Rule D-26).

## 13.3 The specialist ladder, extended from v1.3-C

**[P]** SP-1…SP-6 map **[S-C: §47.2]** onto the brief's specialist progression, with an **authority ceiling** stated at every stage — because a specialist ladder without an authority ceiling becomes a shadow hierarchy.

| Stage | v1.3-C equivalent | What the person may do | **Authority ceiling** | Evidence required | Standing expression |
|---|---|---|---|---|---|
| **SP-1 Demonstrated** | S1 | Perform the skill to a published standard | **None over people or money** | LE-2 | Contribution record entry |
| **SP-2 Trusted scope** | S2 | Take larger or harder scopes within the skill | Delegation scope only, recorded and bounded **[S: Ch.10]** | LE-2 + LE-1 | Milestone (absolute) |
| **SP-3 Verifier** | S3 | **Verify others' work in that skill** | Verification within the skill; **no general authority; the L4→L5 boundary is respected** | LE-2 + LE-3 | Credential **[S-C: H-10]** |
| **SP-4 Advisor** | S4 | Advise teams and the City; contribute to standards | **"Advises, never commands"** **[S-ST: §9.1]** | LE-2 + LE-3 + LE-4 | Credential + advisory record |
| **SP-5 Mentor / Elder** | S5 | Teach, witness, hold memory, mediate | **Excluded from RBAC command and from scoring** | LE-5 | Elder/Mentor standing **[S-C: §6.10]** |
| **SP-6 Standard-setter** | S6 | Own a standard or curriculum through the change-request route | **No line authority**; standard changes run through the versioned process **[S-A: A-15 M2/M3]** | LE-3 + LE-5 + published work | Institutional specialist record |

**[A]** SP-3 carries the most value and the most risk. **Value:** a verifier multiplies assurance capacity without adding a manager — exactly what **[S-ST: §23.1 S3]** identifies as the binding constraint at scale ("assurance capacity — audit at sampling scale, not case scale"). **Risk:** verification authority over another person's work is real power, and **[S-ST: F-26]** warns that verification performed inside the same social network is compromised. **[P] Control:** an SP-3 verifier may not verify work produced by a member of their own team where an out-of-team verifier is available; verifier assignment is recorded; verifier rotation applies to control functions **[S-ST: F-26(7) ii]**.

## 13.4 The specialist domains and their leadership-system relevance

**[S-C: §47.3]** twelve domains with hard limits, preserved. **v1.3-D adds why each matters to leadership supply** — because the specialist track is also the answer to **[S-ST: F-03]**, "nobody wants the unpopular control roles".

| Domain | Hard limit **[S-C]** | Leadership-system relevance |
|---|---|---|
| **Technology** | AI may recommend, humans decide **[S: Ch.21]** | Produces the platform capability the control budget depends on for automation **[S-B: §26.3]** |
| **Finance** | Cannot combine receive + approve + record + audit **[S: Ch.18]** | **The City-shared Funds reviewer serving several mohallas is a specialist role, not a management role** — **[S-ST: F-03(10)]**; **[S-B: §26.4]** |
| **Legal** | Internal training is not legally sufficient **[S: Ch.12]**; advice is not an organisational position **[V]** | Supplies the compliance capacity **[S-ST: Scenario C]** requires, without creating a management layer |
| **Design** | IP, consent, fact-check, content rights | Supports the Editor family without adding team leadership |
| **Medicine / health** | No diagnosis or treatment unless licensed **[V]** | Referral and awareness capability only |
| **Education** | Trainer competence; safeguarding for minors **[V]** | **The trainer cadre is the leadership pipeline's production capacity** — **[S-ST: Scenario B]**: trained-leader production is "limited by trainer supply, not by curriculum" |
| **Logistics** | Restricted goods and write-offs require approval | City warehouse and logistics sharing **[S-B: §26.4]** |
| **Media** | Verified facts only; authorised spokespersons **[S: Ch.24]** | **Many authorised spokespersons by domain and region**, so the public face is a set of people doing work **[S-A: A-16 §15.4]** |
| **AI** | Prohibited-decision list preserved verbatim; **[S-A: A-21, A-22]** | Supplies the human review capacity that prevents **[S-ST: F-29]** rubber-stamping |
| **Business** | Category approval required **[S: Ch.33 POTENTIAL]** | Venture capability without team command |
| **Field service** | Safety doctrine and the DO-NOT list bind at every level **[S-A: A-08]** | The deepest local capability — and the one most often held by people who will never want management |
| **Other verified skills** | The standard is published before the skill is recognised **[S-C: §25.3 condition 1]** | Keeps the ladder open |

## 13.5 High contribution without management

**[P]** Rule D-36 (Expert Retention Rule). A person may state, at any time, **"I want to remain an expert"**, and the organisation's response is:

| Response element | Content |
|---|---|
| **Recorded as** | A complete choice. **Not** "declined promotion"; **not** a negative mark; **not** a gap |
| **Effect on standing** | None negative. SP progression continues on its own merits |
| **Effect on being asked again** | The person is recorded as not seeking leadership and is **not repeatedly asked** — the same protection **[S-C: H-17]** gives to a leadership refusal |
| **Effect on recognition** | Full access to appreciation, proof and credential **[S-C: §23.1 instruments 1–3]**, and to Elder/Mentor standing **[S-C: §6.10]** |
| **Effect on compensation** | Unchanged: paid for verified work at priority 1 **[S: Ch.18]**; specialist supplier engagement at priority 3 where applicable **[S-C: §47.4]** |
| **Effect on scope** | **Scope rewards remain available** — leading a bigger project, a cross-mohalla initiative, a training cohort or a venture, **temporally bounded so that scope circulates** **[S-ST: F-24(7) iii]** |
| **Reversibility** | The person may later seek leadership through the normal vacancy lifecycle, with the prior choice carrying no penalty |

**[A]** Why scope rewards rather than rank rewards: **[C]** a rank reward is zero-sum and permanent; a scope reward is non-zero-sum and temporary. **In an organisation where positional prizes are arithmetically scarce (§10.7), scope is the only reward whose supply can be increased without creating losers.**

## 13.6 Elder / Mentor standing — wisdom without command

**[S-C: §6.10]** preserved exactly, with its leadership-system consequences drawn out:

| Attribute | Content **[S-C]** | Leadership-system consequence **[P]** |
|---|---|---|
| **Purpose** | "To keep long-serving members useful **without** giving them command — and to let knowledge survive turnover" | It is the **institutional-memory instrument with a human face** — the living counterpart to **[S-A: A-15 M7]** oral history |
| **Who** | Long-serving members, at any level from L3 upward, recognised by the team and recorded | Available to people who will never be Verified Members, making it the **broadest standing instrument in the design** |
| **Functions** | Teaches; verifies by witness; mediates; holds local memory; blesses new teams; sits with newcomers; contributes to oral history | **DV-3 delegated practice and DV-4 structured scenario** (Part 15) are delivered largely through this standing — at near-zero governance cost |
| **Explicit exclusions** | **Excluded from RBAC command permissions and from scoring**; may not approve money, appoint, discipline, publish or override a role-holder | **Absolute.** This is the guard against **[S-ST: M9]**'s named risk — "elder status becomes gerontocracy" |
| **Why it matters** | "It is the **lateral endpoint** that makes §8 credible: a sixty-year-old with no ambition to manage can hold real standing" | It is also **the release valve for the charismatic local leader** — **[S-C: §45.3]**: it "lets a locally prominent person hold real respect indefinitely **without** holding command, and therefore without becoming a bottleneck or a cult centre" |
| **Guard** | "Standing is **recognised, not ranked** — it confers no ordinal position and appears on no leaderboard" | Enforced by Rule D-35 and Part 21 |

**[P]** Two additional rules specific to the leadership system:
1. **An Elder/Mentor may be a source of LE-4 trust evidence** — a witnessed account of a person's behaviour over time is exactly the long-horizon, multi-observer evidence LE-4 requires — **but may not be the sole source**, and the relationship to the candidate must be declared.
2. **An Elder/Mentor may not assess Gate R** for a person they have mentored, because the mentor is a party to the development evidence. **They may provide evidence; they may not judge it.**

## 13.7 Does the specialist path risk status inflation?

**[A]** Tested, as the brief requires:

| Risk | Mechanism | Control |
|---|---|---|
| **SI-1 Title inflation** | Everyone becomes a "Senior Specialist" and the title means nothing | Titles are **absolute and evidence-linked** — a credential certifies a demonstrated skill against a published standard **[S-C: §25.3]**, not a rank. **No comparative title exists** |
| **SI-2 Shadow hierarchy** | Specialists begin issuing instructions | **Authority ceiling per stage (§13.3)**; "advises, never commands" **[S-ST: §9.1]**; RBAC grants no command permission on the specialist track |
| **SI-3 Paper mill** | Certificates issued without assessment | **[S-ST: M9 control]** — "certification requires evidence-linked assessment by an **out-of-team assessor**"; Part 16 |
| **SI-4 Consolation-prize perception** | The specialist track is read as "for people who couldn't be leaders" | **[S-C: §47.4]** four credibility conditions: real scope, outward recognition, inward recognition without ranking, **and it can be paid**. Plus Rule D-35. **And the Elder standing — the most socially respected position in the design — sits on this track, not on the leadership track** |
| **SI-5 Specialist capture** | A small group controls a standard and blocks others | SP-6 standard ownership runs through the **change-request route** **[S-ST: F-13, M23]** and the versioned library **[S-A: A-15 M2/M3]**, with reasons recorded and inspectable by any member **[S-A: A-15 memory rule 6]** |
| **SI-6 Verification monopoly** | SP-3 verifiers become gatekeepers of their own domain | Verifier rotation **[S-ST: F-26(7) ii]**; assignment recorded; out-of-team verification where available |

---

# PART 14 — LEADERSHIP PIPELINE

## 14.1 What the pipeline actually is

**[A]** The brief asks for a pipeline: stages, entry conditions, time in stage, throughput, bottleneck. **[A] The first finding is that Sewak Sathi's pipeline is not a training pipeline.** The source already supplies training — **[S: Ch.12]** specifies ten training categories and a twelve-step lifecycle. The constraint identified independently by both prior instruments is different:

> "**Leader supply is a *stock* problem, not a *training-content* problem.**" **[S-B: §24.5]**
> "Trained-leader production is limited by **trainer supply**, not by curriculum." **[S-ST: Scenario B]**

**[A]** And the deeper constraint, from the stress test: the organisation must produce **trusted** people, and trust is produced by *verified experience over time*, not by course completion. **[S-ST: F-03]** showed that the roles most needed — HR/Verification, Funds, Safety — are precisely the **unpopular control roles** **[S-B: §25.5]**. **A pipeline that produces willing helpers is easy. A pipeline that produces people who will deny a friend's claim is hard, and it cannot be trained; it can only be selected for and protected.**

**[P]** The pipeline is therefore specified as **six stages**, each with an entry condition, a *throughput constraint*, and a *named bottleneck* — not as six courses.

## 14.2 The six pipeline stages

| Stage | Name | Entry condition | What is produced | Throughput constraint | Named bottleneck |
|---|---|---|---|---|---|
| **PL-0** | **Presence** | Member joins a team; membership recorded **[S: Ch.12]** | A person with a role in the record | Recruitment is **prohibited at the moment of vulnerability** **[S-C: H-03]** | Trust-building time — cannot be compressed |
| **PL-1** | **Verified contribution** | Training complete; work verified **[S: Ch.25 step 2]** | LE-2 task evidence begins | Verification capacity | **The verifier** — a team that cannot verify cannot produce evidence, and without evidence nobody can ever be assessed |
| **PL-2** | **Trusted scope** | Gate E eligibility (Part 3 §3.2) + first LE-2 cycle | A person with a bounded delegation **[S: Ch.10]** | Delegation availability | **The primary role-holder's willingness to delegate** — and Rule D-36's scope circulation |
| **PL-3** | **Coordinated function** | Coordinator appointment **[S: Ch.10]**; SS-3 nominated | A person who runs a function | Functional complexity | **The number of distinct functions a team actually operates** — a 4-function team cannot produce 9 coordinators |
| **PL-4** | **Sub-Role / Deputy** | Gate R readiness begins; LE-3 behavioural evidence accumulates | A **named successor (SS-4)** | Time — LE-3 requires observation across situations | **The calendar.** Behavioural evidence cannot be manufactured faster than situations occur |
| **PL-5** | **Primary Role holder** | Gate E + Gate R + PG gates + vacancy **[S: Ch.11]** | A leader | **Positional scarcity** (§10.7) | **`L_pos / K`** — the arithmetic ceiling |
| **PL-6** | **Higher level** | Team readiness + LG-1…LG-10 + promotion decision | City / State / National capability | Team hollowing risk (Part 7, Rule D-17) | **Whether the winning team can survive losing its best people** |

**[A]** The critical structural observation: **PL-0 through PL-4 scale with population. PL-5 and PL-6 do not.** They scale with the number of positions, which scales with the number of teams, which scales with the number of teams that can be *sustained* — not merely formed. **[S-B: §17.2]** `P_max` and **[S-B: §26]** `σ_max` are the real governors of PL-5. **The pipeline's output is therefore capped by economics, and no amount of leadership development changes that.**

## 14.3 Leadership density

**[P]** The brief asks for density measures. **[A] Density must not be invented as a ratio target** — **[S-B]** established that numeric targets are **PROPOSED — REQUIRES PILOT VALIDATION**, and the brief forbids inventing ratios. Density is therefore specified **symbolically** and **directionally**, with the *measurement* defined and the *target* left open.

| Measure | Definition | Why it matters | What is NOT specified |
|---|---|---|---|
| **D-team** | Primary role-holders per team ÷ functions the team actually operates | **[S: Ch.10 State A]** = 9 functions; a team with `n` holders has a combination factor `c = 9/n`. **Density below 1.0 means functions are unheld** | The minimum acceptable `n` — **[S-B: §40.2]** leaves `c` to be measured in the pilot |
| **D-ready** | Roles at SS-4 or SS-5 ÷ covered roles | **This is the succession density that matters.** A team with leaders but no successors has a density of zero for continuity purposes | The target percentage — **UNKNOWN, MEASURE IN PILOT** |
| **D-control** | Teams holding all four irreducible capabilities with a named continuity route ÷ total teams | Rule D-33. **The only density measure with a hard floor: it must be 1.0 for any team permitted to operate** | — |
| **D-pipeline** | People at PL-2 or above ÷ total members | Measures whether the organisation is producing candidates at all, or merely members | Target — **UNKNOWN, MEASURE IN PILOT** |
| **D-city** | City-level specialists and control-role providers ÷ `K` teams | **[S-B: §26.4]** City shared services; **[S-ST: F-03(10)]** the out-of-team Funds reviewer | The divisor function `H_gov_per_team(K)` is **[S-B]**'s, and its shape is unresolved |

**[P] Rule D-37 (Density Is Reported, Never Targeted Publicly).** Density measures are **internal diagnostic instruments**. They may not be published as a league table of teams or cities, and no individual's standing may depend on a density figure. **[A]** Reason: a published density target immediately becomes a recruitment-quality target, and **[S-C: H-03]** prohibits recruitment at the moment of vulnerability. **A density target is a pressure to sign people up; a sign-up pressure in a service organisation operating among vulnerable people is a safeguarding risk, not a KPI.**

## 14.4 Span of control

**[A]** The source does **not** specify a span-of-control number. **[S: Ch.4]** specifies levels; **[S: Ch.10]** specifies role ladders; **[S: Ch.22]** specifies "one role has one primary holder". **No maximum number of direct reports appears anywhere in the 179 pages.** This is recorded as an **[X-absent]** fact and marked **UNRESOLVED — DO NOT INVENT.**

**[P]** What *can* be specified without inventing numbers:

| Principle | Content | Source |
|---|---|---|
| **SP-A Span is bounded by verification capacity, not by preference** | A leader who cannot review the evidence their team produces is not leading; they are counting. Span must be set so that the leader can perform **[S: Ch.25 step 2]** review at the cadence **[S: Ch.24]** requires | **[S: Ch.25; Ch.24]** |
| **SP-B Span is bounded by the control budget** | Every additional direct report adds `H_gov` — coordination, review, dispute, safeguarding. **[S-B: §25]** `H_gov` must fit inside `σ_max`. **Span is therefore an economic variable** | **[S-B: §25, §26.1]** |
| **SP-C Span is bounded by duty of care** | A leader carries **[S-C: SR-5]** duty-of-care obligations. Duty of care that cannot actually be discharged is a false promise | **[S-C: §7.3]** |
| **SP-D Asymmetric span is permitted and expected** | Control roles (HR/Verification, Funds, Safety) will have **fewer** reports and **more** authority; delivery roles will have more reports and less. **Uniform span is a corporate assumption with no basis here** | **[S-B: §25.5]**; **[S: Ch.9 "Cannot do" boundaries]** |
| **SP-E Span growth triggers a structure decision, not an automatic hire** | When span exceeds what the holder can verify, the options are: (i) add a coordinator **[S: Ch.10]**, (ii) split the team **[S: Ch.13 step 9]**, (iii) reduce scope. **A fourth option — tolerate it — is prohibited** | **[S: Ch.13]** |

**[P] Rule D-38 (Span Is Declared, Not Assumed).** Each role's authority record **[S: Ch.9]** gains one field: **`span_basis`** — the reason this role's span is what it is, expressed as verification capacity, control budget, or duty of care. **[A]** This converts span from an invisible convention into an inspectable decision, which is what makes it auditable under Part 37 and appealable under Part 18.

## 14.5 Layer explosion

**[A]** **[S-ST: F-21]** and **[S-B: §25]** both identify the mechanism: governance hours grow faster than delivery capacity as layers are added. **[S: Ch.4]** specifies four levels — Mohalla, City, State, National. **[A] The danger is not four levels; it is the *uncontrolled multiplication of roles within* four levels.**

**[S: Ch.10]** catalogues roles at all four levels; **[S: Ch.9]** specifies eleven role families. **[A]** Eleven families × four levels × sub-roles × coordinators × supporting roles produces a role catalogue whose **compliance surface** — every role requiring training, RBAC, evidence, review, succession — grows combinatorially while the population of people to fill it grows linearly.

| Explosion mode | Mechanism | Control |
|---|---|---|
| **E-1 Vertical** | Adding a level between Mohalla and City to "manage" growth | **Prohibited without a Tier-1 amendment.** **[S-A: A-14 §13.3 item 1]** reserves constitutional and Tier-1 change |
| **E-2 Horizontal** | Adding role families beyond the eleven | **Prohibited without a recorded decision.** New functions attach to existing families; a new family requires a published standard first **[S-C: §25.3 condition 1]** |
| **E-3 Sub-role proliferation** | Every task becomes a "Sub-Role" with its own record, RBAC profile and succession entry | **Rule D-39:** a Sub-Role is created only where a **delegation of authority** is required. Task allocation is not sub-role creation **[S: Ch.10]** |
| **E-4 Coordinator inflation** | Coordinators appointed to give status rather than to run a function | **Rule D-39:** a coordinator position exists only where a named function exists and is unheld |
| **E-5 Committee proliferation** | Governance bodies created "to appear democratic or aesthetic" — **expressly forbidden by the brief** | **Rule D-40:** every standing body must state the decision it makes, who would otherwise make it, and what happens if it is abolished. **A body that cannot answer is not created** |
| **E-6 Reporting inflation** | Dashboards and cadences added per level | **[S: Ch.24]** already fixes six dashboards × five cadences. **Additions require retirement of an existing one** — **[S-B: §26.3]** automate or retire |
| **E-7 Shadow layers** | Informal groups — WhatsApp circles, "senior people", founder's favourites — exercising real authority outside the record | **Rule D-41:** authority exercised without a record is authority exercised without legitimacy. Any person issuing binding instructions must hold a recorded role or delegation. **Detected shadow authority is an incident, not a culture** |

**[P] Rule D-39 (Position Justification Rule).** No position — Primary, Sub-Role, Coordinator or Supporting — may be created unless the creating authority records: (i) the **function** it performs; (ii) why the function is not already held; (iii) the **authority** it needs; (iv) its **succession state** obligation (§11.3); (v) its **cost** in `H_gov`. **[S: Ch.9]** already requires purpose, authority, limits, inputs, outputs, metrics, training, reporting and succession for every role family — **Rule D-39 extends the same discipline to individual positions.**

**[P] Rule D-40 (Body Justification Rule).** As E-5 above. **[A]** Applied reflexively: this document itself must satisfy Rule D-40 for every body it proposes. Part 48 performs that audit.

**[P] Rule D-41 (No Shadow Authority).** As E-7 above. **[A]** This rule has a founder consequence, addressed at Part 27: **the founder is the most likely source of shadow authority in any founder-led organisation**, and the rule therefore binds the founder first.

## 14.6 The trusted-people bottleneck

**[A]** The brief asks specifically: what limits the number of trusted people?

| Limiter | Mechanism | Can it be accelerated? | Minimum correction |
|---|---|---|---|
| **Time** | Trust requires observed behaviour across situations (LE-3) | **No.** Situations occur at their own rate | Start observing earlier — PL-2, not PL-4 |
| **Verification capacity** | Unverified work produces no evidence; no evidence, no assessment | **Yes** — via SP-3 verifiers and City-shared verification | **[S-ST: §23.1 S3]** assurance at sampling scale |
| **Trainer supply** | **[S-ST: Scenario B]** — the binding constraint on trained-leader production | **Yes, slowly** — trainers are themselves produced by the pipeline | Protect trainer time explicitly; **training is work, not volunteering** |
| **Willingness to hold unpopular roles** | **[S-ST: F-03]** — HR/Verification, Funds, Safety | **Partially** — by making them *respected* rather than *rewarded* | Part 21: recognition without ranking; Part 13: SP-3 verifier standing |
| **Positional scarcity** | `L_pos / K` (§10.7) | **No** | Rule D-36: scope rewards and the specialist track |
| **Founder concentration** | All trust routes through one person | **Yes — and must be** | Part 20: the four annual tests **[S-A: A-16]** |
| **Attrition of the already-trusted** | **[S-ST: F-24]** — capable people leave when the future is a saturated ladder | **Yes** | Part 13: three tracks, two endpoints |
| **Adverse selection** | People who *want* power disproportionately seek it | **No, only detected** | Part 3 §3.7: AF-1…AF-12 anti-favouritism; Part 18: appeals |

**[P] Rule D-42 (Trust Is Produced, Not Declared).** No person may be described as "trusted" in any record, dashboard or announcement except as the output of Gate R (Part 3 §3.4) supported by LE-3 and LE-4 evidence. **[A]** Reason: informal trust language is the mechanism by which favouritism becomes invisible. Once "he's a trusted guy" is a category, evidence is optional.

## 14.7 The expansion gate

**[A]** The brief requires that expansion be gated on leadership supply, and that **no second pilot be created** — the pilot is shared: **[S-B: §40]** one team, no technology, **P-01…P-14**; **[S-C: §57]** the same team, human measurements. **[P]** v1.3-D adds **no third pilot**. It adds **leadership measurements to the same pilot**, which is what Annexure I specifies.

**[P] Rule D-43 (Expansion Gate).** A new team, mohalla or city may be authorised only where all of the following are true. Each is a **gate**, not a preference; a gate never disables payment **[S-B: gate principle]**.

| Gate | Condition | Source |
|---|---|---|
| **XG-1** | The four irreducible capabilities (DECIDE, PAY, VERIFY, STOP) have named continuity routes | Rule D-33 |
| **XG-2** | A **named successor at SS-4** exists for the Team Leader role of the expanding unit's sponsor | §11.3; **[S-B: B-18(1)]** successor-before-transition |
| **XG-3** | At least one SP-3 verifier is available who is **outside** the new unit | Part 13 §13.3; **[S-ST: F-26]** |
| **XG-4** | The control-role supply (HR/Verification, Funds, Safety) for the new unit is identified — locally or via City shared services | **[S-B: §25.5, §26.4]**; **[S-B: B-21]** City Shared Services Contract |
| **XG-5** | The projected `H_gov` for the new unit fits inside the sponsor's `σ_max` **after** the expansion | **[S-B: §25, §26.1]** |
| **XG-6** | A trainer is available whose time is **protected and paid** | **[S-ST: Scenario B]**; **[S: Ch.12]** |
| **XG-7** | The Interim Authority Order for the new unit is written | **[S-B: B-19]**; Rule D-31 |
| **XG-8** | No existing team falls below D-control as a result of the expansion | Rule D-37; Rule D-33 |

**[A]** XG-8 is the gate that prevents the failure mode the brief fears most: **growth that hollows out the organisation that grew.** **[S-B: B-18(6)]** already requires promotion to be *recorded as a cost*. XG-8 makes it a **pre-condition**.

**[P] Rule D-44 (Expansion Is Recorded As A Cost).** Every authorised expansion carries a recorded cost entry: trainer time, verifier time, `H_gov` increment, successor development time, and the D-control delta of the sponsoring unit. **[A]** Without this, expansion appears free at the moment of decision and expensive afterwards — which is exactly **[S-B: §24.2]**'s "success tax on success" applied to growth rather than to promotion.

---

# PART 15 — DEVELOPMENT PROGRAMME

## 15.1 What the source already provides

**[S: Ch.12]** — twelve-step member lifecycle and **ten training categories**. **[S: Ch.13]** — nine-step team growth with an autonomy-readiness gate of eight rows. **[S: Ch.14]** — nine-step support-first failure recovery with six failure types, of which **Leadership failure = "fear, favouritism, missed targets" → coaching + deputy → "Replacement/dynamic succession"**. **[S-C: §25.3]** — AC-1…AC-11 and CK-1…CK-7. **[S-ST: M9]** — successor must complete one full cycle; graded certification; specialist tracks; scope rewards; auto-generated references.

**[A]** The source's development model is therefore: **train by category → grow by steps → recover by coaching → certify by grade.** What it does **not** provide is any mechanism that develops **leadership capability as distinct from role competence.** **[S: Ch.12]** trains a person to do a job. Nothing in the 179 pages trains a person to *hold authority over other human beings without abusing it.*

**[P] That gap is the entire justification for Part 15.**

## 15.2 The development architecture

**[P] Amendment L-12 — Development Programme.** Five components. **No training hours, module counts or durations are specified** — the brief forbids inventing them, and **[S: Ch.12]** does not fix any. All durations are **[P] UNKNOWN — MEASURE IN PILOT**.

| Component | Purpose | Delivered by | Evidence produced | Cost character |
|---|---|---|---|---|
| **DV-1 ROLE FORMATION** | Competence in the specific role — the existing ten categories **[S: Ch.12]** | Trainer cadre | Completion record **[S: Ch.12 HR record]** | **Existing** — no new cost |
| **DV-2 AUTHORITY FORMATION** | The capability to hold authority: limits, refusal, escalation, recording reasons, handling a grievance against oneself | Out-of-team assessor + Elder/Mentor **[S-C: §6.10]** | LE-3 behavioural evidence; **recorded refusal exercises** | **New** — the only genuinely new component |
| **DV-3 DELEGATED PRACTICE** | Real bounded authority, exercised, reviewed | Primary role-holder under **[S: Ch.10]** Sub-Role delegation | LE-2 task evidence at increasing scope | **Existing mechanism**, new intent |
| **DV-4 STRUCTURED SCENARIO** | Observation under pressure without real harm | Out-of-team assessor; **the founder may not assess** (Rule D-93, Part 27) | LE-3; scored against published criteria | **New** |
| **DV-5 REFLECTIVE RECORD** | The candidate's own account of decisions, including failures | Self, reviewed by the assessor | **LE-5 reflection** — Part 5 §5.1 | **New, near-zero cost** |

## 15.3 DV-2 Authority Formation — the missing component

**[A]** This is where the architecture earns its keep. **[P]** Twelve authority capabilities, each with a **demonstration method** — because a capability with no demonstration method is a slogan.

| # | Capability | Demonstration method | Fails if |
|---|---|---|---|
| **AF-C1** | Knowing the boundary of one's own authority | Read the role brief **[S: Ch.9]** aloud and state what one may **not** do | Cannot state the "Cannot do" list |
| **AF-C2** | Refusing a request from someone more powerful | Recorded refusal exercise: a superior asks for something outside limits | Complies, or complies and does not record |
| **AF-C3** | Refusing a request from someone one likes | Scenario: a friend's claim fails verification | Waives verification **[S-ST: F-26]** |
| **AF-C4** | Recording a reason | Produce a decision record **[S-A: A-15 M1]** with a reason a stranger could follow | Reason is "as discussed" |
| **AF-C5** | Escalating without self-protecting | Escalate a problem one caused | Escalates late, or escalates blaming others |
| **AF-C6** | Receiving a complaint against oneself | Complaint filed; observe response | Retaliates, delays, or contacts the complainant **[PG-10]** |
| **AF-C7** | Delivering bad news to the team | Announce a failed outcome honestly | Softens, hides, or blames **[S-A: A-16 §15.4]** |
| **AF-C8** | Distributing work fairly under scarcity | Allocation exercise with insufficient capacity | Allocates by favour or by loudness |
| **AF-C9** | Holding a control role against social pressure | Scenario: safety stop-work against a delivery deadline | Prioritises the deadline **[S: Ch.16; A-09]** |
| **AF-C10** | Handing over completely | KT-1…KT-10 pack with **gaps recorded** | Gaps concealed |
| **AF-C11** | Accepting a decision one disagrees with | Dissent route exercised **[S-A: A-16 test 3]** — dissent recorded, then compliance | Silent dissent, or public undermining |
| **AF-C12** | Recognising that one is the problem | Reflective record naming one's own contribution to a failure | Externalises entirely |

**[P] Rule D-45 (Authority Formation Is Assessed Out of Team).** DV-2 and DV-4 assessments are performed by an assessor **outside the candidate's team**, with the result recorded, reasoned and appealable. **[A]** Reason: this is the **only** mechanism in the entire design that can distinguish the *unpopular competent* person from the *popular incompetent* person — the weakness ES.5 names as the single biggest unresolved one. An in-team assessor is captured by the same social field that produces the popularity signal.

## 15.4 Apprenticeship

**[P]** The brief asks for an apprenticeship model. **[A]** The source has one, unnamed: **[S: Ch.14]** "coaching + deputy" and **[S: Ch.26]**'s transition steps, plus **[S-B: B-18(3)]** time-bounded mentorship.

| Element | Design | Constraint |
|---|---|---|
| **Structure** | A named apprentice works alongside a named primary role-holder under a **recorded delegation** **[S: Ch.22 `delegated_authority`]** with scope, limits, dates, reason, reviewer | **Not** an informal "shadow" — shadowing without a record is shadow authority (Rule D-41) |
| **Duration** | **[P] UNKNOWN — MEASURE IN PILOT.** Bounded at both ends: too short produces no LE-3; too long produces dependency and blocks the apprentice | Automatic expiry **[S: Ch.22]** |
| **Progression** | Scope widens in recorded steps, each with its own delegation record | Each widening is a decision, not a drift |
| **Assessment** | LE-2 for task performance; LE-3 for behaviour; **assessed by the out-of-team assessor, not by the mentor** | Prevents the mentor becoming the gatekeeper |
| **Mentor's incentive** | **Succession is a performance dimension** (Part 19): producing a ready successor counts | **[S-B: B-18(1)]** |
| **Mentor's disqualification** | A mentor may not assess their own apprentice's Gate R (Part 13 §13.6 rule 2) | Prevents self-validation |
| **Failure mode** | The apprentice becomes the mentor's executor — doing the mentor's work under the apprentice's development label | **Rule D-46:** apprenticeship delegations are for **the apprentice's development scope**, and the apprentice's task record must show work the apprentice decided, not work the mentor directed step by step |
| **Completion** | Recorded; contributes to SS-4; produces an **auto-generated reference** **[S-ST: M9]** | The reference is generated from the record, not written by the mentor — **so it cannot be inflated** |

**[P] Rule D-46 (Apprenticeship Is Development, Not Labour).** An apprenticeship delegation may not be used to fill a capacity gap. Where the organisation needs the work done, it is a **Sub-Role**, not an apprenticeship. **[A]** Reason: the moment apprenticeship becomes cheap labour, capable people learn to avoid it — and **[S-ST: F-24]**'s attrition mechanism reappears inside the development programme.

## 15.5 PT-8a bounded mentorship, restated as a cost

**[S-B: B-18(3)]** — time-bounded mentorship. **[S-B: B-18(6)]** — promotion recorded as a cost. **[P]** Combined:

**Rule D-47 (Mentorship Is Paid Time).** Time spent mentoring, training, verifying or assessing is **work**, recorded in the workload ledger (Part 24) and compensated within the existing waterfall **[S: Ch.18]**. It may not be treated as volunteering on top of a full role. **[A]** **[X]** External evidence supports this direction: recognition and support correlate with materially lower volunteer turnover, while **training alone did not improve retention** and was associated with higher exit for women in one sample — because training raises expectations the role must then meet. **[V] REQUIRES VALIDATION IN THE PILOT — this is directional external evidence, not Sewak Sathi policy.**

---

# PART 16 — CERTIFICATION & GRADING

## 16.1 Certification

**[S-ST: M9]** — "graded certification … certification requires evidence-linked assessment by an out-of-team assessor." **[S-C: H-10]** — credential as an absolute recognition instrument. **[P]** Implemented:

| Element | Design |
|---|---|
| **What is certified** | **A demonstrated skill against a published standard** — never a person's worth, never a rank, never a comparative position **[S-C: §25.3 condition 1; SR-2]** |
| **Standard** | Published **before** the skill is recognised **[S-C: §25.3]**; versioned in the institutional library **[S-A: A-15 M2/M3]** |
| **Assessor** | **Out of team** **[S-ST: M9]**; recorded; rotated for control functions **[S-ST: F-26(7) ii]** |
| **Evidence** | LE-2 minimum; LE-3 for any certification carrying authority over others |
| **Grades** | **[P] Graded, but the grades are *scope* grades, not *rank* grades** — SP-1…SP-6 (Part 13 §13.3). A grade states what scope a person may take, not how good a person is |
| **Expiry** | **A certification carrying authority has a review date** **[S: Ch.22 `review_date`]**. A certification of a *skill* does not expire — the skill is either demonstrated or not |
| **Revocation** | On fraud, safety breach or manipulation — the same grounds that void a high score **[S: Ch.26]** |
| **Display** | Absolute instruments only; **no ordinal numbering in any public medium** **[S-C: SR-2]** |
| **Appeal** | Part 18 |

**[P] Rule D-48 (No Certification Without A Standard).** No certificate may be issued where no published standard exists. **[A]** This prevents the paper-mill failure (SI-3) and, more importantly, prevents **certification from becoming a loyalty ritual** — the anti-cult concern Part 36 addresses.

## 16.2 What is NOT certified

**[P]** Deliberately excluded, with reasons:

| Not certified | Why |
|---|---|
| **"Leadership" as a general quality** | It is not a skill against a standard; it is an observed pattern across situations. Certifying it would create a credential that flatters and does not predict |
| **Trustworthiness** | Rule D-42: trust is produced by Gate R, not declared by a certificate |
| **Character** | Out of scope of any legitimate organisational instrument; and a character certificate is the instrument of a cult, not of a service organisation **[S-C: §45]** |
| **Seniority** | **[S]** and **[A]** both: seniority ≠ leadership. A tenure certificate is a queue ticket, not a capability statement |
| **Completion of training** | **[S: Ch.12]** already records training completion in the HR record. **A second certificate for the same fact adds burden and creates a status object with no informational content** — Rule D-40 logic |
| **Popularity, followers, engagement** | **[S: Ch.25]**: "Raw revenue, follower count, social-media views, volunteer count, application count or raw activity count cannot determine leadership." |

---


# PART 17 — REVIEW CYCLE

## 17.1 What the source already fixes

**[S: Ch.24]** — six dashboards across five cadences; the **monthly** cadence is explicitly "performance and leadership". **[S: Ch.25]** — a six-step monthly performance process. **[S: Ch.22]** — `appointment_date` and `review_date` per role assignment. **[S: Const. Art.14, APPROVED]** — "Performance is monthly and multidimensional." **[S: Ch.9]** — each role family specifies its own review frequency in the `succession_status` field: "Metrics, **review frequency**, ready/acting/nominated status and succession pathway" **[S: Ch.22]**.

**[A]** The source therefore fixes the **cadence** and leaves the **content, reviewer, and consequence** of a leadership review largely open. **[S: Ch.33]** records the leadership transition rules as `NOT FINAL`. **Part 17 supplies content and reviewer; it does not alter cadence.** Rule D-16 (Part 6 §6.6) already fixed the cadence set for this instrument and is not restated or changed here.

## 17.2 The four review types

**[P] Amendment L-13 — RV-1…RV-4.**

| Type | Name | Applies to | Trigger | Reviewer | Output | Consequence ceiling |
|---|---|---|---|---|---|---|
| **RV-1** | **PERFORMANCE REVIEW** | Every team, at the source cadence **[S: Ch.24 monthly]** | Cadence | The team's own leadership line + Performance function **[S: App. E]** | Multidimensional score with confidence rating (Part 6 §6.3) | **Score only.** No authority change. Feeds gates (Part 7) |
| **RV-2** | **ROLE REVIEW** | Every role assignment | `review_date` **[S: Ch.22]** | The appointing authority **[S: App. E]** with HR co-review | Continuation, scope change, development plan, or vacancy | Authority change; **never** a conduct finding |
| **RV-3** | **LEADERSHIP REVIEW** | Every leader, at a longer interval than RV-1 **[P] UNKNOWN — MEASURE IN PILOT** | Cadence + succession trigger | **Out-of-line reviewer** (Part 17 §17.4) | Gate R reassessment; SS state update; LDI update (Part 38) | Development obligation; succession state change; **referral** to RV-4 where grounds exist |
| **RV-4** | **CONDUCT REVIEW** | Any member, on a complaint or an incident | Event, not cadence | **A panel, never a single person** — Governance/HR for serious misconduct **[S: App. E]** | Warning, support plan, suspension, or removal **[S: Const. Art.8]** | The only review that may remove |

**[P] Rule D-49 (Review Type Separation).** The four review types are **never merged into one conversation, one record or one decision.** Specifically:
1. An RV-1 may not produce an authority change. **[A]** If a score could demote, every score becomes a threat, and **[S-ST: F-19]**'s fear-driven reporting mechanism activates.
2. An RV-2 may not produce a conduct finding. **[A]** Scope change and misconduct are different facts with different evidence standards and different appeal routes.
3. An RV-3 may not be conducted by the person whose succession the candidate would fill. **[A]** That person has a direct interest in the answer.
4. An RV-4 may not be triggered by a score. **[S: Ch.14]** requires support-first recovery; a low score triggers **coaching and a support plan**, not a conduct panel. **[S: Const. Art.8]** grounds are conduct grounds.
5. **All four are recorded, reasoned and appealable** (Part 18).

## 17.3 Review content — the RV-3 instrument

**[P]** The RV-3 leadership review asks nine questions, none of which is "what was your score". Each maps to a capability dimension (Part 4) and an evidence class (Part 5).

| # | Question | Capability | Evidence class | Fails if |
|---|---|---|---|---|
| **Q1** | What did this leader decide, and can a stranger reconstruct the reason? | LC-1, LC-9 | LE-1 decision record **[S-A: A-15 M1]** | Reasons absent, or reasons written after the fact to fit |
| **Q2** | What did this leader refuse, and to whom? | LC-3, LC-11 | LE-3 behaviour | **No refusals recorded at all** — a leader who never refused anything either had no authority or used none |
| **Q3** | Who is ready to hold this role, and on what evidence? | LC-19 | SS state + Gate R record | SS-0/SS-1 for a mandatory-SS-4 role (§11.3) |
| **Q4** | What did this leader's team learn that it did not know before? | LC-16 | LE-5 + playbook updates **[S-A: A-15 M5]** | Nothing; or knowledge held only in the leader's head |
| **Q5** | What failed, and how was it reported? | LC-7, LC-14 | LE-1 incident record **[S-A: A-09]** | Failure discovered by someone outside the team |
| **Q6** | Is this leader's absence survivable? | LC-20 | LDI (Part 38) | LDI in the critical band with no mitigation plan |
| **Q7** | Did any complaint arise against this leader, and how was it handled? | LC-5, LC-12 | Complaint record (Part 18) | Complaint handled by the respondent; or no complaints ever, in a team with active grievances |
| **Q8** | Did this leader's authority change anyone's standing who should not have been affected? | LC-4, LC-10 | AF-series check (Part 3 §3.7) | Pattern consistent with favouritism |
| **Q9** | What does this leader need that the organisation has not given? | LC-15 | RV-3 record | **[A]** A review that never asks this is an extraction instrument, not a development instrument |

**[A]** Q2 and Q7 are the two questions a conventional performance review never asks, and they are the two that detect the failure the brief fears most: **the leader who is excellent on every measured dimension and quietly unaccountable on every unmeasured one.**

## 17.4 Who reviews whom — the reviewer problem

**[A]** **[S: App. E]** already distributes review authority: role promotion = Team Leader + HR with City/State owner co-review; leaderboard finalisation = Performance/Audit with escalation on tie, anomaly or leadership transfer; leadership transfer = CEO/governance process; suspension = HR/Safety/Leader; serious-misconduct removal = Governance/HR panel. **[S: Ch.23]** gives the Auditor "Review only; not operational commander."

**[P]** v1.3-D adds four reviewer rules:

**Rule D-50 (Reviewer Independence).** A reviewer may not review: (i) a person they appointed; (ii) a person whose role they would inherit or whose vacancy would benefit them; (iii) a person to whom they are related or with whom they share a financial interest — declared per Part 35; (iv) a person they have coached or mentored **for Gate R purposes** (they may provide evidence; Part 13 §13.6). Where no independent reviewer exists locally, **the review moves up a level or out to the City** — the same resolution **[S-B: §26.4]** uses for control roles.

**Rule D-51 (Skip-Level Review).** At least one review per cycle for every leader is conducted by a reviewer **two levels above**, or by an out-of-line reviewer where two levels do not exist. **[S-ST: M10]** already proposed skip-level contact and field immersion. **[A]** Justification: the immediate superior is the person most likely to be the source of the problem, and is always the person most able to conceal it.

**Rule D-52 (Review Burden Is Declared).** Every review type carries a declared cost in hours, entered in the workload ledger (Part 24) and tested against `σ_max` (Part 40). **[A]** **[S-B: §26.3]**'s rule applies: a review that cannot be afforded is automated, simplified or retired — it is not performed badly.

**Rule D-53 (No Review Without A Consequence Route).** A review whose findings cannot change anything is not conducted. **[A]** This is Rule D-40 applied to reviews: the purpose of a review is a decision. A review that produces only a form produces cynicism at a measurable cost.

## 17.5 360-degree feedback — adversarially tested

**[A]** The brief requires 360 feedback to be adversarially tested, not adopted. **The source contains no 360 mechanism.** It contains something better and something worse: a **multidimensional score with defined metric owners** **[S: Ch.25, App. A §18.3]** and **eight anti-gaming controls** **[S: Ch.25]** — which is structured peer input with verification; and a **team score** — which is collective, not individual.

| Attack on 360 feedback | Mechanism | Verdict |
|---|---|---|
| **Popularity capture** | Raters reward the leader they like, not the leader who is competent. In a mohalla team, raters are neighbours, relatives and friends | **FATAL as designed.** This is precisely the substitution the brief forbids: LEADERSHIP ≠ POPULARITY |
| **Retaliation fear** | Raters who give a poor rating to a person with authority over their work, pay or task allocation are exposed | **FATAL** unless anonymity is real and the population is large enough to protect it. **[S-B: §3.3]** and **[S: Ch.10 State A]** put team size in single digits — **anonymity in a 9-person team is arithmetic, not policy: it does not exist** |
| **Reciprocity trading** | "Rate me well and I rate you well" | **HIGH** in small closed groups; undetectable from inside |
| **Central tendency** | Everyone rates everyone average to avoid conflict | **HIGH** in a community organisation where social harmony is a real value **[S-C]** |
| **Strategic sabotage** | A rival faction coordinates low ratings before a promotion cycle | **HIGH** — and it converts 360 into a weapon. **[S-ST: F-26]** identifies exactly this class of capture |
| **Rater incompetence** | Raters cannot observe the dimensions being rated — e.g. a supporting member cannot observe the leader's reconciliation accuracy | **HIGH** — and it produces confident noise |
| **Consolidation into a score** | 360 output is averaged into the leaderboard | **PROHIBITED** by **[S-C: §23.2]** — "a person is never scored" — and by Rule D-49(1) |
| **Burden** | `n` raters × `m` questions × cadence × teams | **[S-B: §25]** `H_gov` grows; **[S-B: §26.1]** `σ_max` does not |

**[P] Verdict: 360-degree feedback is REJECTED as a scored instrument in its conventional form, and ADOPTED in three decomposed forms.**

| Form | What it is | Why it survives the attacks |
|---|---|---|
| **F-360a STRUCTURED WITNESS STATEMENT** | A named person states, in writing, **specific observed events** — not ratings — against a published capability descriptor (LC-1…LC-20). No number is produced | Removes central tendency, removes averaging, removes anonymity-dependence. **Named** statements are accountable and appealable; anonymous ones are not, and in a small team anonymity is fake anyway. **Rule D-54:** a witness statement that contains no specific event is not admissible evidence |
| **F-360b FUNCTIONAL PEER INPUT** | The person who actually receives the leader's output — the verifier, the funds reviewer, the safety lead, the City coordinator — rates **the interface**, not the person: was the handover complete, was the evidence usable, were incidents reported on time | Rater competence is guaranteed because the rater observes the interface directly. This is **[S: App. A §18.3]**'s existing model extended, not a new instrument |
| **F-360c DOWNWARD EXPERIENCE SURVEY** | Team members answer **three** questions about their own experience — not about the leader's quality: *Did you know what was expected of you? Were you paid correctly and on time? Could you raise a problem without fear?* | These are **the leader's duties** under **[S-C: SR-5, SR-6]** and **[S: Ch.18]**, and they are answerable without expertise. The third question is the retaliation detector. **Aggregate only, never attributed to a named rater** |

**[P] Rule D-54 (No Rating Without An Observable Event).** No individual-level judgement enters any record unless it is attached to a specific, dated, observable event that the subject can respond to. **[A]** This single rule disposes of most of the 360 failure modes, because it makes vague malice inadmissible and vague praise worthless.

**[P] Rule D-55 (Small-Population Anonymity Prohibition).** Where a rating population is too small for anonymity to be arithmetically plausible, **anonymous instruments are not offered** — because offering an anonymity that does not exist is worse than offering none: it invites disclosure under a false promise. The named witness statement (F-360a) and the aggregate experience survey (F-360c) are used instead. **[V] The threshold at which anonymity becomes plausible is UNKNOWN — MEASURE IN PILOT.**

## 17.6 Review record

**[P]** Every review produces a record with these fields, extending **[S: Ch.22]**:

| Field | Content | Visibility |
|---|---|---|
| `review_id`, `review_type` (RV-1…RV-4), `date`, `cadence` | Identifier | Per RBAC **[S: Ch.23]** |
| `subject_role_id` — **not** `subject_person_id` where avoidable | The review is of a role-holder in a role **[S-C: §23.2]** | — |
| `reviewer_id`, `reviewer_basis` (line / out-of-line / skip-level / panel), `independence_declaration` | Rule D-50 | Audit |
| `evidence_refs` | LE-1…LE-5 items relied on | Subject + audit |
| `findings` | Against published criteria only | Subject + line |
| `reasons` | Why each finding was reached — a stranger must be able to follow **[S-A: A-15 M1]** | Subject + audit |
| `dissent` | Any reviewer's dissent, recorded in their own name | Audit **[S-A: A-16 test 3]** |
| `subject_response` | The subject's own account, attached unedited | Subject + audit |
| `consequence` | Development plan / scope change / SS state change / referral — **within the type's ceiling** (Rule D-49) | Per RBAC |
| `appeal_route`, `appeal_deadline` | Part 18 | Subject |
| `confidence` | HIGH / MEDIUM / LOW (Part 6 §6.3) | Subject + line |
| `burden_hours` | Rule D-52 | City aggregate |

**[A]** The `subject_response` field is the one most often omitted in real systems and the one that makes the difference between a review and an interrogation. **[S: Ch.11 step 9]** already establishes the principle that a non-selected member may apply again — a design that assumes people are treated as agents, not objects.

---

# PART 18 — COMPLAINTS, APPEALS, IMPROVEMENT & REMOVAL

## 18.1 The four separate routes

**[A]** The brief lists complaints, appeals, removal and improvement plans together. **[P] They must not be one route.** They differ in trigger, standard of proof, decision-maker, consequence and appeal. Merging them is how a person who disagrees with a score ends up in a disciplinary process.

| Route | Trigger | Question asked | Standard | Decision-maker | Consequence range | Appeal |
|---|---|---|---|---|---|---|
| **CR-1 PERFORMANCE CORRECTION** | A score or metric the subject believes is wrong | *Is the record accurate?* | Documentary | Performance function + Audit **[S: App. E]** | Score corrected | RV-1 record → escalation on anomaly **[S: App. E]** |
| **CR-2 APPEAL AGAINST A DECISION** | A promotion, appointment, gate failure or readiness finding | *Was the decision procedurally sound and reasoned?* | Procedural + evidential | **Out-of-line** appeal body | Decision upheld, remade, or set aside | One further level; then closed |
| **CR-3 COMPLAINT AGAINST CONDUCT** | Behaviour by any member, including a leader | *Did the conduct occur and does it breach a standard?* | Fair-process; **panel, never one person** | HR/Safety for suspension; Governance/HR panel for serious misconduct **[S: App. E]** | Warning → support → suspension → removal **[S: Const. Art.8]** | Independent review |
| **CR-4 INTEGRITY REPORT** | Fraud, manipulation, safety concealment, safeguarding, financial irregularity, coercion | *Is there a matter the normal line cannot be trusted with?* | Triage, then as CR-3 | **Integrity Line — outside the operational line** **[S-ST: M10]** | As CR-3, plus referral to authorities where law requires **[V]** | Ombuds route **[S-ST: M10]** |

**[P] Rule D-56 (No Route Substitution).** A matter raised under one route may not be re-characterised into another to obtain a different consequence or a different decision-maker. **In particular: a performance disagreement may not be treated as insubordination, and an integrity report may not be treated as a performance issue.** **[A]** Route substitution is the standard mechanism by which a whistleblower becomes a problem employee.

## 18.2 Complaints architecture

**[P]** Built on **[S-ST: M10]** (Integrity Line, ombuds, non-retaliation, skip-level, field immersion), **[S-A: A-09]** (incident reporting), **[S-A: A-20]** (case-scoped access to sealed categories), **[S-C: §44 SA-1…SA-7]** (safeguarding).

| Element | Design | Source / reason |
|---|---|---|
| **Intake channels** | Verbal to any role-holder (who must record it); written; **anonymous where the population makes anonymity plausible (Rule D-55)**; via the Integrity Line directly | **[S-ST: M10]**; a mohalla member who cannot write must still be able to complain |
| **Mandatory recording** | Every complaint recorded on receipt, whether or not it proceeds. **An unrecorded complaint is an incident** | **[S-A: A-09, A-15 M1]** |
| **Acknowledgement** | To the complainant, in their language, with the route and the expected next step | **[S-C: SR-6]** right to be informed |
| **Triage** | Four classes: (a) performance/record → CR-1; (b) decision → CR-2; (c) conduct → CR-3; (d) integrity/safeguarding → CR-4, **immediate** | Rule D-56 |
| **Interim protection** | Where the respondent holds authority over the complainant, **the authority is suspended for the matter** — not the person, the matter — via TL-4 recusal (Part 12 §12.2 case 11) | Prevents the respondent deciding the complaint |
| **Non-retaliation** | **Absolute.** Any adverse change to a complainant's tasks, pay, allocation, standing or role during or after a complaint is presumed retaliatory until the organisation shows otherwise | **[S-ST: M10]**; **[P] reversal of burden is deliberate** — retaliation is nearly impossible for a complainant to prove from inside |
| **Safeguarding** | SA-1…SA-7 apply; sealed categories under case-scoped access | **[S-C: §44; S-A: A-20]** |
| **Confidentiality vs secrecy** | The **existence** of a complaint and its **outcome class** are recorded and reportable in aggregate; the **content** is scoped. **Nothing is confidential from the complainant about their own complaint** | **[S-A: A-17]** classification |
| **Timeframe** | **[P] UNKNOWN — MEASURE IN PILOT.** **[X]** The DPDP Act 2023 requires grievances to be addressed within **90 days** where a data principal raises one — relevant to CR-4 privacy complaints **[V] REQUIRES LEGAL VALIDATION** | Sets an outer bound for privacy-class complaints |
| **Outcome record** | Finding, reasons, consequence, dissent, appeal route | Rule D-54 logic |
| **Aggregate reporting** | Counts by class, route, level and outcome, **with no small-cell disclosure** — a cell of one is a person | Part 31 privacy |

## 18.3 Appeals

**[S: Ch.26]** already provides a **correction window** and **appeals** among the transition safeguards. **[S: Ch.11 step 9]** provides that a non-selected member may apply again. **[P]** v1.3-D specifies the appeal:

| Element | Design |
|---|---|
| **Grounds** | (i) **Procedural** — a required step, gate, record, reason or declaration was omitted; (ii) **Evidential** — material evidence was not considered, or inadmissible evidence (Part 5 §5.4) was relied on; (iii) **Factual** — the underlying record is wrong; (iv) **Conflict** — an undeclared conflict affected the decision (Part 35). **Not a ground:** disagreement with the weight given to admissible evidence, absent (i)–(iv) |
| **Standing** | The affected person; **and, for a gate failure, the person's team** — because a team loses a leader when one member is wrongly excluded |
| **Body** | Out-of-line; **never** the original decision-maker or their line superior; Rule D-50 independence applies |
| **Standard** | Was the decision **procedurally sound, evidenced and reasoned** — not whether the appeal body would have decided differently |
| **Powers** | Uphold; **remit** with directions; **set aside**. **May not substitute its own merits judgement for a gate that was properly applied** — otherwise appeal becomes a second promotion process |
| **Effect pending** | **The decision stands pending appeal**, except where the consequence is removal or suspension, in which case the person's access is restricted but **payment for work already verified is never withheld** — the source's priority-1 obligation **[S: Ch.18]** is not suspended by a dispute **[S-A: A-14 §13.6 continuity during dispute]** |
| **Record** | Reasoned, retained, and **available to the appellant** |
| **Pattern detection** | Repeated successful appeals against one decision-maker are an **anomaly signal** escalated under **[S: App. E]** — this is how a biased assessor is found without anyone having to accuse them |
| **Cost** | Free to the appellant. **An appeal with a fee is not an appeal** |
| **Vexatious use** | Addressed by **grounds**, not by cost: an appeal with no admissible ground is declined with reasons |

**[P] Rule D-57 (Appeal Is Not Retaliation Evidence).** Filing an appeal may not be recorded, referenced or considered in any subsequent assessment of the appellant. **[A]** Without this, the appeal right exists on paper and dies in practice — the appellant knows that appealing marks them.

## 18.4 Improvement plans

**[S: Ch.14]** — nine-step, **support-first** recovery; six failure types; for **Leadership** failure the sequence is "fear, favouritism, missed targets" → **coaching + deputy** → "Replacement/dynamic succession". **[P]** This is already an improvement architecture, and it is better than a conventional performance-improvement plan because it begins with support. v1.3-D specifies it:

| Step | Content | Constraint |
|---|---|---|
| **IP-1 IDENTIFY** | The specific gap, expressed as a **capability dimension** (LC-n) and an **observable behaviour**, never as a trait | "Needs to be more committed" is not a gap; "did not record reasons for three allocation decisions" is |
| **IP-2 CLASSIFY** | Which of the six **[S: Ch.14]** failure types applies — **because the response differs by type** | A capacity failure gets support; a conduct failure gets CR-3. **Misclassification is the most common abuse** |
| **IP-3 SUPPORT FIRST** | Coaching, training **[S: Ch.12]**, tools, scope reduction, **deputy support** **[S: Ch.14]** | Support must be **real and resourced** — Rule D-47: mentoring and coaching time is paid work |
| **IP-4 AGREE** | A written plan with the person: what will change, what support is provided, what evidence will show it, over what period | **Period: [P] UNKNOWN — MEASURE IN PILOT.** Bounded at both ends |
| **IP-5 MONITOR** | At the normal cadence, by the normal reviewer, **with the plan visible to the person** | No secret monitoring |
| **IP-6 DECIDE** | Closed as resolved; extended once with reasons; or escalated | Escalation to **replacement/dynamic succession [S: Ch.14]**, not to punishment |
| **IP-7 RECORD** | The plan, the support given, and the outcome — **including where the organisation's support was inadequate** | **[A]** The support column is what makes the record honest: an improvement plan that records only the person's failures is a prosecution, not a plan |

**[P] Rule D-58 (An Improvement Plan Is Not A Pre-Removal Formality).** A plan may not be opened where the decision to remove has already been taken. Where removal is intended on conduct grounds, the route is CR-3, not IP. **[A]** Reason: a sham improvement plan destroys the credibility of every genuine one, and it is the single most recognisable unfair-process pattern in employment disputes **[V] REQUIRES LEGAL VALIDATION.**

**[P] Rule D-59 (Support Failure Is An Organisational Finding).** Where an improvement plan does not succeed and the record shows the support was not actually provided, the finding is against the organisation, not the person. The plan is void and a new one begins with the support in place. **[S-A: A-16 test 2 — the attribution test]** applies: an organisation that attributes all failure downward is not learning.

## 18.5 Suspension and removal

**[S: Const. Art.8]** — "Conduct warning→removal." **[S: App. E]** — Suspension: HR/Safety/Leader; serious-misconduct removal: **Governance/HR panel**; **[S: Ch.33]** records the serious-misconduct procedure as `PROPOSED`. **[S: Ch.11]** includes **Suspended** among the six vacancy statuses.

**[P]** Procedure:

| Step | Content | Source |
|---|---|---|
| **RM-1** | **Grounds stated in writing** against a published standard | **[S: Const. Art.8]** |
| **RM-2** | **Interim measures**: TL-4 recusal or TL-2 interim appointment; access restricted to what is necessary; **the person is not removed from the record** | **[S: Ch.11 Suspended status; Ch.22]** |
| **RM-3** | **Payment for verified work already performed is not withheld** | **[S: Ch.18]** priority 1 — absolute |
| **RM-4** | **Notice and representation**: the person sees the grounds and the evidence, and responds | Fair process **[V]** |
| **RM-5** | **Panel decision** — never a single individual, for serious misconduct | **[S: App. E]** |
| **RM-6** | **Reasoned outcome**, recorded with dissent | **[S-A: A-15 M1]** |
| **RM-7** | **Appeal** under §18.3 | **[S: Ch.26]** |
| **RM-8** | **Voiding of score**: "a high score is void if fraud, safety breach or manipulation is found" | **[S: Ch.26]** verbatim |
| **RM-9** | **Continuity executed**: KT-1…KT-10 handover where possible; access closed; credentials recovered; **audit log preserved** | Part 12; Part 29 |
| **RM-10** | **Dignified treatment**: where the removal is for capability rather than misconduct, Rule D-26's dignified exit protocol and Rule D-27's return route apply | Part 10 §10.10–10.11 |

**[P] Rule D-60 (Removal Is Never Automatic From A Score).** No score, gate, ranking, LDI, dependency measure or AI output may itself remove, suspend or demote a person. **[S: Const. Art.12, APPROVED]**: AI "cannot autonomously make consequential HR, wage, legal, safeguarding, safety, major fund or leadership decisions." **[A]** A score may **trigger** a review; only a human panel on stated grounds may decide.

## 18.6 Leader failure vs team failure

**[P]** Cross-reference to **Rule D-12** (Part 5 §5.7, attribution separation) and to **[S: Ch.14]**'s six failure types. The operational test:

| Observation | Presumption | Rebutted by |
|---|---|---|
| The team failed and **other teams in the same cohort with the same resources succeeded** | Leader-controllable | Evidence of a local shock: disaster, market collapse, partner failure, regulatory change |
| The team failed and **the cohort failed** | Environment-controllable | Evidence the leader concealed an early warning |
| The team failed on **verification, funds or safety** specifically | Leader-controllable — these are non-delegable duties **[S: Ch.10 State A]** | Nothing. **[A]** A leader may be forgiven a bad quarter; a leader may not be forgiven an unreconciled ledger |
| The team failed **after losing members to promotion** | Structural — the promotion cost | **[S-B: B-18(4)]** promotion-cohort reporting with/without adjustment |
| The team failed and **the leader's LDI was critical** | Leader-controllable **and** a succession failure | — |
| The team failed and **the leader reported it early, honestly and completely** | Mitigating — **honesty is scored** (Part 8 §8.6) | Evidence the report was honest but the underlying conduct was not |

**[A]** The last row is the one that determines whether the organisation ever learns anything. **[S-A: A-16 §15.4]** requires honest public representation; **[S: App. A §16.3]** requires members to "report results honestly, including failures". **An architecture that punishes the reporter and rewards the concealer will, within a few cycles, be run entirely by concealers.**

---

# PART 19 — LEADER-AS-TEACHER & SUCCESSION AS A PERFORMANCE DIMENSION

## 19.1 The proposition

**[P] Amendment L-14.** **Succession is a scored dimension of leadership performance, not a separate HR process.** Concretely: a leader who produces no ready successor has not fully performed the role, regardless of what the team delivered.

**[A]** Justification, from source:
- **[S: Ch.9]** gives **every** role family a `Succession` column — succession is already structurally part of the role, not adjacent to it.
- **[S: Ch.22]** stores `performance_requirements / succession_status` in **the same field group** — the source itself treats them as one object.
- **[S: Ch.14]** names "missed targets" and treats the response as "coaching + deputy" — the deputy **is** the succession instrument.
- **[S: Const. Art.15, APPROVED]** — "Best Mohalla Team can become City Head Team…" — **but a team that moves up wholly leaves a hole.** Article 15's own safeguard requirement is where succession lives.
- **[S-B: B-18(1)]** — successor-before-transition; **[S-B: B-18(6)]** — promotion recorded as a cost.

**[A]** The counter-argument, taken seriously: **scoring succession may produce fake successors** (GF-23, Part 11 §11.5). **[P]** This is why the dimension is scored on **the successor's demonstrated readiness** (Gate R output, assessed out-of-team) and **never on the act of naming someone**. Naming is free; readiness is not.

## 19.2 How the dimension is measured

| Component | Measure | Weight character | Anti-gaming |
|---|---|---|---|
| **SD-a COVERAGE** | Is the role at SS-4 or SS-5? (§11.3 mandatory-state table) | **Gate-like:** absence for a mandatory role is a gate failure (PG-series), not a low score | Cannot be gamed — it is a fact about the record |
| **SD-b READINESS** | Has the named successor passed Gate R, assessed out-of-team? | Scored | Out-of-team assessment; the leader cannot self-certify |
| **SD-c EXERCISE** | Has the successor actually exercised delegated authority (TL-4) at least once, with a record? | Scored | **[S-ST: M9]**: successor completed one full cycle |
| **SD-d TRANSFER QUALITY** | Where a transition occurred, was the KT pack complete and were gaps recorded? | Scored, retrospectively | Gaps recorded rather than concealed is itself the measure |
| **SD-e TEACHING OUTPUT** | Did the leader's team produce capability that outlives the leader — playbook updates, trained members, certified specialists? | Scored | **[S-A: A-15 M5]** lessons entry with a "did it work" column |

**[P] Rule D-61 (No Weights Invented).** The relative weight of SD-a…SD-e is **NOT SPECIFIED**. **[S: Ch.25]**'s existing weights `20/15/15/15/10/10/10/5` are **PROPOSED** and are **preserved verbatim and unaltered**; v1.3-D does not insert a ninth dimension into that set. **Instead, SD-a operates as a gate (Part 7) and SD-b…SD-e operate within the existing leadership-assessment route (RV-3), where no numeric weight is asserted.** **[A]** This is a deliberate architectural choice: adding a ninth weighted dimension would silently alter a PROPOSED source weighting, which Rule 3 forbids.

## 19.3 Leader-as-teacher

**[A]** The brief asks whether the leader is a teacher. **The source says yes, structurally, without using the word:** **[S: Ch.14]** coaching; **[S: Ch.13]** team growth steps; **[S: Ch.12]** training categories; **[S: Ch.10]** the ladder that requires someone to have prepared the next person; **[S-C: §6.10]** Elder/Mentor whose function is to teach and to let "knowledge survive turnover".

**[P]** Six teaching obligations, each with an artifact — because an obligation without an artifact is not auditable:

| # | Obligation | Artifact | Absence signals |
|---|---|---|---|
| **T-1** | Make the role learnable | **Role playbook** (Part 28) | Knowledge is personal property |
| **T-2** | Delegate real authority, not tasks | TL-4 records with scope and limits | The leader needs to be needed |
| **T-3** | Explain decisions | Decision records with reasons a stranger can follow **[S-A: A-15 M1]** | Authority is exercised, not taught |
| **T-4** | Report failures to the team | Incident and lessons entries **[S-A: A-09, M5]** | The team learns only what succeeds |
| **T-5** | Recognise others specifically | Contribution-record entries **[S-C: CR-1…CR-4]** | Recognition flows upward only |
| **T-6** | Make oneself replaceable | SS-4/SS-5 state; LDI mitigation plan | Indispensability is being cultivated |

**[P] Rule D-62 (Indispensability Is A Performance Defect).** A leader whose LDI (Part 38) remains in the critical band across successive review cycles, with no mitigation plan, has a **leadership performance finding** — not an achievement. **[A]** This is the inversion the brief demands: in most organisations, being irreplaceable is rewarded. **Here it must be the opposite, because an irreplaceable leader is a single point of institutional failure** **[S-ST: F-14, F-15]** and, at scale, the binding constraint on expansion (Rule D-43).

**[A]** The obvious objection: **this rule punishes the most committed people.** **[I]** Partly true — and the correction is not to weaken the rule but to make the *mitigation* cheap and supported: paid mentoring time (Rule D-47), City-supplied specialist cover **[S-B: §26.4]**, and playbooks that cost hours once rather than people continuously (Rule D-34). **A leader who cannot reduce their own dependency is usually a leader who was never given the resources to.** Rule D-59 applies: if the support was not provided, the finding is organisational.

## 19.4 The dependency index and the load index — definitions

**[P]** Full specification at **Part 38** (LDI) and **Part 24** (LLI). Definitions fixed here so that Part 19's rules are determinate:

- **LDI (Leadership Dependency Index)** — the degree to which a unit's continued operation depends on one specific person remaining in one specific role. Inputs: functions held by that person; SS state of each; whether a continuity route exists for DECIDE/PAY/VERIFY/STOP; whether the KT pack exists; time since last continuity exercise. **Output: a band, not a number** — CRITICAL / HIGH / MODERATE / LOW. **[A]** A band rather than an index because the inputs are heterogeneous and any weighting would be invented.
- **LLI (Leadership Load Index)** — the share of a role-holder's available hours consumed by leadership, governance and control duties rather than by delivery. Inputs: `H_gov` attributable to the role **[S-B: §25]**; cadence obligations **[S: Ch.24]**; span (§14.4); review obligations (Rule D-52); incident load. **Output: a band**, with the critical band defined against `σ_max` **[S-B: §26.1]**.

**[P] Rule D-63 (Bands, Not Scores, For Human Conditions).** LDI, LLI, burnout indicators and workload measures are expressed as **bands with defined consequences**, never as numeric scores, and never aggregated into any individual ranking. **[S-C: §23.2]** — "a person is never scored" — and **[S-C: SR-2]** no ordinal numbering. **[A]** Reason: a numeric dependency score of 0.73 invites comparison between two people's exhaustion, and comparison of exhaustion is how burnout becomes a competition.

---

# PART 20 — GAMING, GOODHART'S LAW & METRIC DIVERSITY

## 20.1 Goodhart's law, stated precisely for this architecture

> **"When a measure becomes a target, it ceases to be a good measure."**

**[A]** Applied here: the source's score **[S: Ch.25, App. A §18.2]** is a **measure** of team performance. **[S: Const. Art.15]** makes the **best** team eligible for the next level — which converts the measure into a **target**. **[S: Ch.25]**'s own prohibition is the source's acknowledgement of the danger: "Raw revenue, follower count, social-media views, volunteer count, application count or raw activity count **cannot determine leadership**."

**[P] The Goodhart Prohibition List (Amendment L-18).** The following may never be a direct target, a direct tie-break, or a direct gate input at any level:

| Prohibited as a target | Permitted use | Source |
|---|---|---|
| Raw revenue | As one input to **revenue quality** with margin awareness | **[S: App. A §18.3]** |
| Follower count / social-media views | Not used at all in leadership determination | **[S: Ch.25]** |
| Volunteer count | As **volunteer reliability**, not headcount | **[S: App. A §18.3]** |
| Application count | Not used at all | **[S: Ch.25]** |
| Raw activity count | Capped in score contribution (AC-1…AC-5, Part 8 §8.4) | **[S: Ch.25]**; **[S-ST: M8]** |
| Project count | As **project completion quality — "not just count"** | **[S: App. A §18.3]** |
| Number of successors named | As **successor readiness** (SD-b), assessed out-of-team | Rule D-61; GF-23 |
| Number of teams formed | As **teams that survived a full cycle** (Part 8 windows) | **[S-B: B-07]** |
| Complaint count | **Inverted:** a zero complaint count in a unit with active grievances is an anomaly signal, not a virtue | §17.3 Q7 |
| Training completion count | As training **applied**, evidenced in LE-2 | **[X]** training alone did not improve retention |
| LDI improvement | As LDI **band with a mitigation plan actually executed** | Rule D-62 |
| Honesty disclosures | As **material** disclosures; trivial-only disclosure is itself an anomaly | GF-19 |

## 20.2 The gaming register GF-1 … GF-30

**[P]** Every entry states: the **incentive**, the **gaming behaviour**, the **detection signal**, and the **minimum architectural correction**. Corrections are minimal by instruction — not redesigns.

| ID | Incentive | Gaming behaviour | Detection signal | Minimum correction |
|---|---|---|---|---|
| **GF-1** | Activity counts feed the score | Manufacture countable activities | Activity/verified-outcome ratio diverges from cohort | **AC-1…AC-5 activity cap** (Part 8 §8.4) **[S-ST: M8]** |
| **GF-2** | Outcomes are harder than outputs | Reclassify outputs as outcomes | Outcome claim with no follow-up record | Follow-up obligation; non-completion **reduces** score **[S: Ch.15]** |
| **GF-3** | Visibility beats verification | Perform service where it is seen | Geographic/social clustering of "difficult" cases | Verification by a different role from delivery **[S: Ch.18]** |
| **GF-4** | Urgency raises difficulty weighting | Label routine work urgent | Difficulty distribution vs cohort | **GF-21 control:** recorded at intake by one role, confirmed at verification by another |
| **GF-5** | Response time is scored | Triage the easy first; delay the hard | Time-to-first-response vs time-to-resolution divergence | Both recorded; the resolution time is the weighted one **[S: App. A §18.3]** |
| **GF-6** | Quality is judged by the recipient | Coach recipients to give positive feedback | Feedback uniformity; feedback collected by the delivering team | Feedback collected out-of-line; **sampling** **[S: Ch.25]** |
| **GF-7** | Revenue quality is scored | Underreport costs to inflate margin | Margin divergence from cohort; **"Do not reward underreported costs"** | Reconciliation accuracy + separation of duties + random audits **[S: App. A §18.3]** |
| **GF-8** | Reconciliation accuracy is scored | Reconcile by adjusting the record rather than the cash | Adjustment entries without counterpart evidence | Adjustments require dual approval; audit trail preserved |
| **GF-9** | Volunteer reliability is scored | Recruit nominal volunteers who never serve | Reliability high, retention near zero | Retention is a **separate** reported measure, never merged |
| **GF-10** | Team score depends on team size | Retain members who have left, on the record | Record vs attendance/participation divergence | Periodic confirmation of continued participation **[S-C: H-02 spectrum]** |
| **GF-11** | Gates must be passed | Pass the gate, then stop the behaviour | Post-gate decline at the next cycle | Gates are re-tested at each cycle, not once (Part 7 §7.2) |
| **GF-12** | Cohort normalisation rewards being behind | Suppress baseline to inflate improvement | Baseline set without evidence; baseline restated | **Rule D-19** baseline rules; baseline locked once recorded |
| **GF-13** | Promotion follows team success | Time the assessment window to the strongest period | Window selection not per cadence | Windows fixed by cadence, not chosen (Part 8) |
| **GF-14** | A service floor must be cleared | Perform trivial service to clear the floor | Floor cleared with no material outcomes | Floor expressed in **verified outcomes**, not hours (Part 7 §7.4 BD-1) |
| **GF-15** | A leader must appear decisive | Record decisions after the fact, dressed as reasons | Decision timestamp vs event timestamp; reasons uniform in style | Timestamped decision records; **contemporaneous** requirement **[S-A: A-15 M1]** |
| **GF-16** | Readiness must be shown | Nominate a compliant successor who is not ready | SS-4 named but Gate R not passed; no TL-4 exercise | **SD-b/SD-c:** readiness and exercised delegation, not naming |
| **GF-17** | Complaints damage the record | Discourage, delay or informally resolve complaints | Complaint volume falls while skip-level and Integrity Line volume rises | Dual-channel volume comparison; **non-retaliation with reversed burden** (§18.2) |
| **GF-18** | Appeals are costly to the decision-maker | Pre-empt appeals by softening decisions | Systematically lenient gate application in one unit | Gate application audited by sampling across units |
| **GF-19** | Honesty is scored | Report only trivial failures | Materiality distribution of reported failures | Materiality test (Part 8 §8.6) |
| **GF-20** | Cohorts differ in difficulty | Cohort shopping — stay small or avoid venture approval | Structural band changes without economic cause | Cohorts assigned from records (CN-1); band transitions automatic on structural fact |
| **GF-21** | Difficulty raises weighting | Difficulty inflation at intake | Distribution monitoring per team | Intake/verification separation; beneficiary and partner sampling |
| **GF-22** | Ratios improve when the denominator shrinks | Split a team to improve per-team ratios | Split without a **[S: Ch.13 step 9]** growth reason | Split requires City approval with recorded reason |
| **GF-23** | Succession is a scored dimension | Artificial successor appointment | Successor has no LE-2/LE-3 history; delegation never exercised | Out-of-team Gate R; SD-c exercise requirement |
| **GF-24** | The founder's approval matters most | Perform for the founder rather than for the community | Divergence between founder-visible activity and community-verified outcomes | **Rule D-41 no shadow authority; Part 27 founder recusal; the four annual tests [S-A: A-16]** |
| **GF-25** | Recognition is scarce and comparative | Campaign for recognition; lobby raters | Recognition nominations cluster socially rather than by contribution | **Absolute instruments only [S-C: §44.3]; H-08 six instruments never collapsed** |
| **GF-26** | A specialist credential confers standing | Credential pursuit without scope | Credentials held with no LE-2 in the domain | Certification requires evidence-linked assessment by an out-of-team assessor **[S-ST: M9]** |
| **GF-27** | Verification authority is power | SP-3 verifier passes friendly work | Verifier/pass-rate correlation with social proximity | Verifier rotation; out-of-team assignment; assignment recorded |
| **GF-28** | Emergency authority is broad | Manufacture or prolong an emergency | TL-3 renewals; emergency declarations vs incident records | **Rule D-30(2)** renewal is a decision; **Rule D-32** non-conversion; Part 37 post-crisis review |
| **GF-29** | Interim roles are comfortable | Prolong an interim appointment | TL-2 duration vs vacancy-lifecycle step timestamps | **[S: Ch.11]** 13-step lifecycle with time-in-status monitored; extension requires recorded reason |
| **GF-30** | The score is produced by an AI pipeline | Optimise the record rather than the work | Record completeness high, community-reported experience flat | **Const. Art.12:** AI recommends, humans decide; F-360c downward experience survey as an independent signal |

## 20.3 Metric diversity — why eight dimensions are not enough on their own

**[A]** **[S: Ch.25]**'s eight dimensions are already a diversity mechanism, and **[S-ST: M8]** added cohort stratification, improvement-vs-baseline, two-speed scoring, an activity cap, no public individual ranking and no prize in the first two cycles. **v1.3-D's finding is that dimension diversity protects against gaming a *metric*, but not against gaming the *measurement system*.**

| Diversity axis | What it protects against | Present in source? | v1.3-D addition |
|---|---|---|---|
| **Metric diversity** | Single-metric Goodhart | **Yes** — eight dimensions **[S: Ch.25]** | Preserved unchanged |
| **Method diversity** | A method that can be gamed uniformly | **Partially** — verification + sampling + random audits **[S: App. A §18.3]** | **F-360a/b/c** add witness, interface and experience methods |
| **Observer diversity** | Capture by one social field | **No** | **Out-of-team assessor (Rule D-45); verifier rotation; skip-level review (Rule D-51)** |
| **Time diversity** | Window selection | **Partially** — monthly cadence | **Outcome windows W-A…W-D (Part 8); post-decision lag checks** |
| **Direction diversity** | Upward-only reporting | **No** | **F-360c downward experience survey; Integrity Line [S-ST: M10]; dissent route [S-A: A-16 test 3]** |
| **Confidence diversity** | Treating thin evidence as strong | **No** | **HIGH/MEDIUM/LOW confidence rating (Part 6 §6.3) attached to every output** |
| **Negative diversity** | Only measuring what went well | **Partially** — failure types **[S: Ch.14]** | **Q2 refusals; Q7 complaints; GF-19 materiality; the "did it work" column [S-A: A-15 M5]** |

**[P] Rule D-64 (Two Independent Signals Minimum).** No consequential decision — promotion, gate pass, removal, readiness finding — may rest on a single measurement method. At least two **methodologically independent** signals must agree. Where they disagree, the output carries **LOW confidence** and the decision is deferred or escalated **[S: App. E — escalate on tie/anomaly/leadership transfer]**. **[A]** This is the cheapest anti-gaming control available, because it does not require better metrics — only that the metrics not share a failure mode.

## 20.4 What gaming analysis cannot fix

**[A]** Stated plainly, because the brief forbids softening:

1. **A determined clique in a small team is undetectable from inside that team.** Every correction above depends on an outside observer existing. **Where the City has no capacity to observe, the corrections are paper.** This is **[S-ST: F-26]** unresolved, and Rule D-43's XG-3/XG-4 gates are the only real answer — they refuse to create units that cannot be observed.
2. **Gaming controls cost hours.** Every control above is `H_gov`. **[S-B: §26.1]** caps `H_gov` at `σ_max`. **There is therefore a maximum number of gaming controls a mohalla team can afford, and this document has proposed more than that.** Part 40 resolves the conflict by tiering: a **minimum viable leadership system** for Stage 0–1, and the full register only from Stage 3 **[S-ST: §23.1]**.
3. **The best anti-gaming control is not a control.** It is a small enough unit, with enough real work, that gaming is more effort than serving. **[I]** Where that condition fails, no register will save the system — and the correct response is to reduce the unit's obligations, not to increase its surveillance.

---

# PART 21 — LEADERBOARD ARCHITECTURE & RECOGNITION

## 21.1 The instruction, taken literally

**The brief's absolute rule: "Do not design a leaderboard. Design a leadership system."** **[A]** This is not a stylistic preference. It is a statement that the organisation's existing leaderboard concept — **[S: Ch.25]** multidimensional score, **[S: App. E]** "Leaderboard finalisation: Performance/Audit, escalate on tie/anomaly/leadership transfer", **[S: Ch.33]** weights `NOT FINAL` — is a **measurement artifact** that has been allowed to stand in for a **leadership architecture**.

**[P]** v1.3-D therefore does not design a leaderboard. It does three things instead:
1. **States exactly what the existing instrument may and may not do** (§21.2–21.4).
2. **Leaves the open question open** — **[S-ST: R5]** whether the leaderboard should be public at all is an open reconsideration item and is **not resolved here** (Rule 2).
3. **Supplies the recognition architecture that makes a leaderboard unnecessary** for most of the purposes people want one for (§21.5–21.8).

## 21.2 What the existing instrument is permitted to do

| Permitted | Source | Condition |
|---|---|---|
| Compare **teams** within **cohorts** for learning and support allocation | **[S-C: §23.2]**; **[S-ST: M8]** | Cohort assignment from records (CN-1) |
| Feed the **eligibility engine** for the vacancy lifecycle | **[S: Ch.11]** | Gate E only — **not** Gate R |
| Trigger **support** where a team is behind | **[S: Ch.14]** | Support-first; Rule D-58 |
| Escalate on **tie, anomaly or leadership transfer** | **[S: App. E]** | Mandatory escalation |
| Be **voided** on fraud, safety breach or manipulation | **[S: Ch.26]** | Absolute |
| Carry a **confidence rating** | Part 6 §6.3 | LOW confidence outputs may not drive a consequential decision (Rule D-64) |

## 21.3 What it is prohibited from doing

| Prohibited | Source |
|---|---|
| Ranking **individuals** at any level | **[S-C: §23.2]** "a person is never scored"; **[S-ST: M8]** no public individual ranking |
| Determining leadership from raw revenue, followers, views, volunteer count, applications or raw activity | **[S: Ch.25]** verbatim |
| Ranking L0–L4 participants, who are never ranked | **[S-C: §7.3 SR-3]** |
| Comparing a Level-2 contributor with a Level-7 leader | **[S-C: §23.2]** |
| Collapsing the six instruments into one leaderboard | **[S-C: H-08]** |
| Publishing an ordinal position for a credential, appreciation, proof or compensation | **[S-C: §23.1]** "May it be ranked? **Never**" for instruments 1, 2, 3, 5 |
| Determining pay | **[S-C: §23.1]** instrument 5 — "pay is not a score" |
| Awarding a prize in the first two cycles | **[S-ST: M8]** |
| Becoming a **target** | Rule D-64, the Goodhart Prohibition List (§20.1) |
| Removing, suspending or demoting anyone | Rule D-60 |

## 21.4 Leaderboard fatigue

**[A]** The brief asks for this to be analysed. **[I]** Fatigue has four distinct mechanisms, and they need different corrections:

| Mechanism | What happens | Correction |
|---|---|---|
| **LF-1 Measurement fatigue** | The same eight dimensions, monthly, forever, with no visible consequence | **Rule D-53:** no review without a consequence route. Where a dimension has produced no decision in successive cycles, it is retired or automated **[S-B: §26.3]** |
| **LF-2 Futility fatigue** | Teams at the bottom conclude the top is unreachable and stop trying | **Cohort normalisation (Part 9)** plus **improvement-vs-baseline** **[S-ST: M8]**: a team competes against its own trajectory, not against a structurally advantaged peer |
| **LF-3 Surveillance fatigue** | Measurement is experienced as monitoring rather than as support | **Support-first sequencing [S: Ch.14]**: the first response to a low reading is resource, not review. And **the team sees its own data first**, always |
| **LF-4 Status fatigue** | The instrument that was meant to recognise work becomes the thing people work for | **Absolute recognition instruments (§21.6)** that do not depend on position. **And the Goodhart Prohibition List** |

**[P] Rule D-65 (Measurement Retirement).** Every measurement has a recorded purpose and a recorded consumer. A measurement with no consumer for two consecutive cycles is retired. **[A]** This is the only durable defence against fatigue, because fatigue is caused not by difficulty but by pointlessness.

## 21.5 The separation: recognition ≠ authority

**[P]** The brief requires recognition and authority to be separated. **[S-C: §23.1]** already does this — the six instruments are distinct, given by different actors, recorded in different places, with different ranking permissions. **v1.3-D adds the leadership-system consequence:**

| If recognition and authority are fused | Then |
|---|---|
| Recognition becomes a **queue position** | The person recognised is expected to be promoted; the person not promoted reads the absence of recognition as rejection |
| Authority becomes a **prize** | Leadership is competed for, not entrusted — which inverts **[S: Const. Art.7]** "greater responsibility requires greater trust" |
| Refusing promotion becomes an insult to the recogniser | Rule D-23's legitimate refusal grounds become unusable |
| Recognition inflates | Because it carries a material consequence, it must be rationed — and rationed recognition is recognition given for loyalty, not contribution |
| The specialist path dies | **[S-C: §47.4]** condition 3 — inward recognition without ranking — becomes meaningless if the only recognition that counts is the one that leads to a role |

**[P] Rule D-66 (Recognition Confers Nothing).** Appreciation, proof, credential and milestone recognition confer **no authority, no queue position, no expectation of promotion and no score**. They are records of fact and expressions of gratitude. **Where recognition is given in a way that creates an expectation of authority, that is a governance defect and is recorded as one.** **[A]** This is the operational form of the standing instruction that "recognition celebrates contribution, not loyalty".

## 21.6 Recognition instruments in the leadership system

| Instrument | Form | Public? | Ordinal? | Source |
|---|---|---|---|---|
| **Appreciation** | A person thanks a person. **Not recorded** | Optional, local | Never | **[S-C: §23.1 instrument 1]** |
| **Proof** | Evidence of what someone contributed, from records | With consent | Never | **[S-C: H-09 contribution record]** |
| **Credential** | "You demonstrated this skill", against a published standard | Portable, at the holder's choice | Never — absolute | **[S-C: H-10]**; Part 16 |
| **Milestone** | Absolute event recognition — first delivery, first team trained, first clean audit | Yes | Never | **[S-C: §44.3]** |
| **Story** | Narrative account of contribution | Yes, with consent | Never — **narrative, non-ordinal** | **[S-C: §23.3 rule 3]** |
| **Responsibility** | Appointment to a role | Internal | No — scoped, not ranked | **[S-C: §23.1 instrument 4]**; **[S: Ch.11]** |
| **Elder / Mentor standing** | Recognised, not ranked; confers no ordinal position | Yes | **Never** | **[S-C: §6.10]** |

**[P] Rule D-67 (Public Recognition Rules).**
1. Public recognition names **contribution**, never **comparative position**. "X led the water survey that reached 40 households" is admissible. "X is our #2 team leader" is not.
2. **No individual performance ranking is published.** **[S-ST: M8]**; **[S-C: §23.2]**.
3. Recognition is given **in the organisation's name**, not in a founder's or leader's name — **[S-A: A-16 §15.4]** public-representation rules; anti-cult control (Part 36).
4. Recognition of a **team** does not require recognition of its leader, and recognition of a leader does not imply the team's score.
5. **Consent is required** for any public naming, and consent may be withdrawn — **[S-A: A-18]** necessity test; **[S-C: SR-4]**.
6. Public recognition may not disclose the existence or content of any sealed-category record **[S-A: A-20]**.

## 21.7 Ceremonies and symbols — tested against Rule D-40

**[A]** The brief forbids creating ceremonies "merely to appear democratic or aesthetic". **[P]** Applied:

| Candidate ceremony | Passes Rule D-40? | Decision |
|---|---|---|
| Handover ceremony on leadership transition | **Yes** — it marks a real change of authority, makes it public, and creates a social cost for contesting it afterwards | **Retained**, minimal: the KT pack is signed in front of the team |
| Credential conferral | **Yes** — it publishes a standard and makes the assessment socially real, which deters SI-3 paper mills | **Retained** |
| Annual recognition gathering | **Conditionally** — only if it recognises absolute contributions and no ranking is announced | **Retained with the Rule D-67 constraint** |
| Leader oath or pledge | **No** — it creates a loyalty object attached to a person or to the organisation's leadership, which is the cult vector Part 36 addresses | **Rejected.** A role acceptance is a **record**, not a vow |
| Founder's address at every event | **No** — it makes the founder the source of legitimacy for every local achievement | **Rejected** — Part 27 |
| Titles, honorifics, insignia of rank | **No** — **[S-C: SR-2]** no ordinal numbering; **[S-C: §8.4]** "no instrument may describe leadership as a higher form of service" | **Rejected** |
| Memorial / legacy recognition of long service | **Yes** — Elder standing is already this, recognised not ranked | **Retained as Elder/Mentor** |

## 21.8 The open question, left open

**[S-ST: R5]** — whether the leaderboard should be public at all — remains **OPEN**. **[P]** v1.3-D records the argument on both sides and does not decide:

| For publication | Against publication |
|---|---|
| Transparency is a trust instrument **[S-A: A-17]**; a closed measurement system invites suspicion of favouritism | Publication converts a measure into a target (Goodhart) at the exact moment the organisation scales beyond direct observation |
| Teams learn from comparison **[S-C: §23.2]** permits cohort comparison | Small-cell disclosure risk: a cohort of three teams is three named teams (Part 31) |
| **[S: Const. Art.15]** implies the "best" team is identifiable | "Best" published is "best" contested; and the contest is exactly what hollows out the winning team |
| Public accountability for the use of funds | The published object would be a **team score**, and **[S-C: §23.2]** scopes performance measurement to instruments 4 and 6 only — publication sits uneasily with that scoping |

**[P] Recommendation, marked [P] and not a decision:** publish **cohort-level distributions and the fact of escalation**, not **unit-level rankings**, until the pilot (Part 41) has measured whether publication changes behaviour. **This is a recommendation for approval, not architecture.**

---

# PART 22 — AUTHORITY, RECOGNITION & STANDING

## 22.1 The six instruments, applied to leadership

**[S-C: §23.1]** verbatim structure, with the leadership-system reading added:

| Instrument | Sentence **[S-C]** | What it certifies | Who gives it | Recorded where | May it be ranked? | **Leadership-system consequence [P]** |
|---|---|---|---|---|---|---|
| **1. APPRECIATION** | "Thank you." | That someone noticed | A person, to a person | Nowhere — it is speech, not a record | **Never** | The cheapest retention instrument in the design and the only one with zero `H_gov`. **Rule D-68:** appreciation may not be replaced by a system |
| **2. PROOF** | "Here is evidence of what you contributed." | That a contribution happened and had an outcome | The organisation, from records | **H-09 contribution record** | Never | Proof is the **raw material of LE-2/LE-3**. Without it, Gate R cannot be passed by anyone outside the leader's social field |
| **3. CREDENTIAL** | "You demonstrated this skill." | Verified capability | The organisation, against a stated standard | **H-10 portable credential** | Never — absolute | The specialist track's economic expression (Part 13). **Portability is what makes it credible** — a credential that only means something inside the organisation is a loyalty token |
| **4. RESPONSIBILITY** | "You are trusted with this role." | That trust has been earned and delegated | Role appointment through the vacancy lifecycle **[S: Ch.11]** | Delegation record with dates **[S: Ch.10, Ch.22]** | No — scoped, not ranked | **This is leadership.** Not instruments 1–3, not 5, not 6 |
| **5. COMPENSATION** | "You were paid for this work." | That verified work was remunerated | Finance, at priority 1 **[S: Ch.18]** | Payment sheet with formula version **[S: Ch.19 step 13]** | **Never** — pay is not a score | Part 23. **Pay follows work, not rank** |
| **6. PROMOTION** | "You are entrusted with greater responsibility." | That scope has increased | Vacancy lifecycle + eligibility engine **[S: Ch.11]** | Appointment record | No | Part 10. **Scarce, positional, and not the main reward** |

## 22.2 The four distinctions, made structural

**[A]** The brief requires these to be architectural, not slogans. Each is given a **mechanism that fails visibly if the distinction is violated** — because a distinction with no failure mode is a slogan.

| Distinction | Mechanism that enforces it | How a violation becomes visible |
|---|---|---|
| **PERFORMANCE ≠ LEADERSHIP** | RV-1 produces a score and **nothing else** (Rule D-49(1)); leadership is assessed at RV-3 against LC-1…LC-20 with LE-3/LE-4 evidence and an out-of-team assessor | A promotion justified only by a score has no Gate R record — and the absence is an auditable gap |
| **LEADERSHIP ≠ POPULARITY** | F-360a named witness statements with specific events (Rule D-54); out-of-team assessment (Rule D-45); LC-6/LC-18 popularity-contamination controls (Part 4 §4.5) | A leadership case with no out-of-team evidence is incomplete on its face |
| **SENIORITY ≠ LEADERSHIP** | **D-5** seniority rule (Part 3 §3.3); tenure is inadmissible as readiness evidence (Part 5 §5.4) | A Gate R record citing tenure is procedurally defective and appealable under §18.3 ground (ii) |
| **REVENUE ≠ LEADERSHIP** | **[S: Ch.25]** verbatim prohibition; revenue appears only as **revenue quality** with margin awareness **[S: App. A §18.3]**; Goodhart Prohibition List | A high-revenue team with a failed gate stays failed — and the record shows why |
| **ACTIVITY VOLUME ≠ IMPACT** | AC-1…AC-5 activity cap (Part 8 §8.4); outcome windows W-A…W-D; follow-up obligation | An activity-heavy team's capped contribution is visible in the score breakdown |
| **AI SCORE ≠ HUMAN WORTH** | **[S: Const. Art.12]** verbatim; Rule D-60; Part 30 | Any consequential decision with no human decision-maker recorded is void |

**[P] Rule D-68 (The Appreciation Rule).** No system, dashboard, form or process may substitute for a person thanking a person. **[A]** Recorded because it is the one rule in this document that costs nothing and is the most likely to be forgotten once the others are built.

## 22.3 Standing without authority

**[P]** Five forms of standing that carry **no** command, no money and no rank — the answer to "what does a person get if they never lead?"

| Standing | Conferred by | Confers | Never confers |
|---|---|---|---|
| **Verified Member (L5, no role)** | Verification **[S: Ch.12]** | Membership, tasks, pay for venture work | Voting on nothing; managing nobody **[S-C: §8.2]** |
| **Credential holder** | Out-of-team assessment against a published standard | Portable proof of skill | Command; verification authority beyond the credential's stage |
| **Elder / Mentor** | Team recognition, recorded **[S-C: §6.10]** | Teaching, witnessing, mediating, memory, blessing new teams | **RBAC command; scoring** — excluded absolutely |
| **Specialist (SP-3…SP-6)** | Evidence-linked progression | Verification within a skill; advisory standing; standard ownership | Command; general authority |
| **Contributor of record** | The contribution record itself | A permanent, portable account of what one did | Nothing else. **And that is enough** |

**[A]** The last row is the design's real answer to the brief's central question. **An organisation in which "I helped, it worked, and it is written down that I helped" is a complete outcome — not a consolation — will not need to corrupt its leadership selection to keep people.** **[S-C: §8.4]**'s prohibition, "no instrument may describe leadership as a higher form of service", is what makes that possible.

---

# PART 23 — COMPENSATION FOR LEADERSHIP WORK

## 23.1 The source rule, preserved

**[S: App. A §15.3]** — the leader is paid **in the same framework** with a **higher allocation**; the source "does not invent the exact multiplier"; the allocation must be "**transparent, capped or bounded… justified by verified leadership work rather than status alone**." **[S: Ch.18]** — the waterfall priority order is the control: worker compensation → statutory → direct costs → founder compensation → organisation fee → reserves → social impact → residual, with strict segregation. **[S: Ch.33]** — leader multiplier `NOT FINAL`; worker classification `UNRESOLVED`. **[S-B: §24]** — `C_lead = C_wc_base × m_lead`, with `m_lead` unresolved.

**[P] v1.3-D does not propose a multiplier.** The brief forbids inventing salaries, and Rule 2 forbids closing a `NOT FINAL` item. What follows is the **stress test the brief requires** — "if existing architecture says leaders receive a slightly higher percentage for leadership work, preserve that source rule but stress-test its economic sustainability."

## 23.2 The stress test

| Test | Question | Finding |
|---|---|---|
| **CT-1 Affordability** | Can a team at `σ_max` **[S-B: §26.1]** pay a leadership premium at all? | **[A]** Only if `m_lead` is small **or** the leader's delivery contribution is separately paid. **[S-B: §24]** already models `C_lead = C_wc_base × m_lead` on the **worker-compensation base**, which means the premium is funded from priority 1, not from residual — **so it competes with the team's own delivery capacity** |
| **CT-2 The success tax** | Does promoting a leader make the sending team poorer? | **Yes.** **[S-B: §24.2]** names this the "**success tax on success**". The team loses the delivery hours **and** must pay the premium to a replacement or absorb the gap |
| **CT-3 Multiplication** | Does the premium scale linearly with leaders? | **Yes, and worse than linearly** — because every leader requires a successor in development (SD-b/SD-c), and development time is paid work (Rule D-47) |
| **CT-4 Incentive alignment** | Does a premium on **status** produce leadership? | **No.** **[S: App. A §15.3]** already requires justification "by verified leadership work rather than status alone". **A status premium attracts the wrong people** — and GF-24/GF-25 show how they then game the record |
| **CT-5 Incentive alignment, corrected** | Does a premium on **leadership work** produce leadership? | **Yes, if the work is separately identifiable.** Teaching, verifying, mentoring, handover, succession development, incident handling, review participation — all are recordable as work (Rule D-47) |
| **CT-6 Distributional effect** | Does the premium concentrate income? | **[I]** Yes, mildly, and this matters in a worker-first organisation. **[S-B]**'s worker-first rule may not be weakened to make the leadership numbers work — **so the premium must be bounded** |
| **CT-7 Founder comparison** | Is the leader premium consistent with founder compensation at priority 4? | **[A]** Any premium that approaches founder compensation inverts the waterfall's moral logic. **[S: Ch.33]** leaves founder compensation unresolved; **this comparison is therefore UNRESOLVED and is not decided here** |
| **CT-8 Sustainability at scale** | At `K` teams per city and four levels, does the leadership cost remain inside `σ_max`? | **[S-B: §25]**'s `H_gov_per_team(K)` City divisor is the mechanism; **its shape is unresolved**. Recorded as **[U]** |

## 23.3 The proposed structure — bounded, work-linked, no numbers

**[P] Amendment L-15 — Leadership Compensation Structure.** Five rules, no values:

**Rule D-69 (Leadership Work Is Itemised).** The leadership allocation is paid against **identified, recorded leadership work** — mentoring, verification, training delivery, handover, succession development, review participation, incident response, governance attendance — **not against the holding of a role.** **[A]** This is the only way to satisfy **[S: App. A §15.3]**'s "verified leadership work rather than status alone" with an auditable mechanism.

**Rule D-70 (Bounded and Capped).** `m_lead` is **bounded** — a stated maximum, approved as policy, recorded in the formula version **[S: Ch.19 step 13]**, and **not exceeded for any individual for any reason.** The bound value itself is **[P] UNKNOWN — REQUIRES APPROVAL AND PILOT MEASUREMENT.** **[S: App. A §15.3]** requires "capped or bounded"; this rule supplies the mechanism, not the number.

**Rule D-71 (Delivery Is Paid Separately).** Where a leader also performs delivery work, that work is paid at the normal worker-compensation rate at priority 1 **[S: Ch.18]**. **The leadership allocation does not replace delivery pay and delivery pay does not justify the leadership allocation.** **[A]** Prevents the two from being netted into an opaque total.

**Rule D-72 (No Premium For Indispensability).** A leader whose LDI is in the critical band with no mitigation plan receives **no leadership allocation increase** and may receive a **development obligation** instead (Rule D-62). **[A]** Paying more for being irreplaceable purchases the organisation's own fragility.

**Rule D-73 (Succession Development Is Paid Work).** Time spent developing a named successor is itemised under Rule D-69. **[S-B: B-18(6)]** requires promotion to be recorded as a cost; Rule D-73 ensures the cost is also **funded**, not merely recorded.

**Rule D-74 (Compensation Is Never A Score).** Pay may not be expressed, displayed, ordered or compared as a performance position. **[S-C: §23.1 instrument 5]** — "pay is not a score". Aggregate compensation disclosure follows **[S-A: A-17]** classification and Part 31.

## 23.4 What is NOT proposed

| Not proposed | Why |
|---|---|
| A multiplier value | **[S: Ch.33]** `NOT FINAL`; brief forbids invented salaries |
| Performance-linked variable pay for leaders | **[A]** It converts every leadership decision into a financial-interest decision, and Part 35's conflict-of-interest architecture would then have to disqualify leaders from most of their own decisions |
| Equity, profit share or ownership stakes for leaders | **[S-A]** reserves structural and asset matters as reserved **[A-14 §13.3]**; and a leader with an equity stake in a service organisation is a conflict that cannot be managed |
| Recruitment or retention bonuses | **[A]** They price loyalty, which is precisely what the standing instruction forbids rewarding |
| Referral fees for recruiting members or leaders | **MLM vector** — **[S-C: MLM-1…MLM-7]**; prohibited |
| Any payment tied to team growth or downline size | **MLM vector**; **[S-C: MLM-3]** |
| Allowances that are not itemised | Rule D-69; opaque allowances are how status premia reappear after being prohibited |

---

# PART 24 — WORKLOAD, BURNOUT & THE LOAD INDEX

## 24.1 The workload ledger

**[A]** **[S-B: §25]** established `H_gov` — governance hours per team per month — as a first-class cost, with the source's own range of **8–40 hours per team per month** described as "the single most important unknown". **[S-B: §26.1]** capped total control effort at `σ_max`, derived from the team's own economics. **[P]** v1.3-D adds the **per-role ledger** that makes `σ_max` operable at the level of a person's week.

| Ledger field | Content | Source |
|---|---|---|
| `role_id`, `period` | Which role, which cycle | **[S: Ch.22]** |
| `H_delivery` | Hours on verified delivery work | **[S: Ch.25]** |
| `H_gov_role` | Hours on governance, control, review, cadence for this role | **[S-B: §25]** |
| `H_lead` | Hours on leadership work itemised under Rule D-69 | Part 23 |
| `H_dev` | Hours on developing a named successor, mentoring, training delivery | Rule D-47, Rule D-73 |
| `H_incident` | Hours on incidents, complaints, appeals, emergencies | **[S-A: A-09]**; Part 18 |
| `H_unrecorded` | **Hours the holder reports as spent but not attributable** — the most important field in the ledger | **[P]** New |
| `H_available` | Hours the holder has declared available | **[S-C: H-02]** participation spectrum; **[S-C: SR-7]** |

**[P] Rule D-75 (Unrecorded Hours Are The Signal).** `H_unrecorded` is not a data-quality problem to be eliminated; it is the **primary early indicator of overload and of shadow work**. A rising `H_unrecorded` with flat `H_delivery` means the role is consuming the person. **[A]** Conventional time systems treat unattributed time as an error. **Here it is the measurement.**

## 24.2 The Leadership Load Index

**[P] LLI = `H_gov_role + H_lead + H_dev + H_incident` as a share of `H_available`**, expressed as a **band** (Rule D-63), never a score, never ranked, never published individually.

| Band | Meaning | Consequence |
|---|---|---|
| **L0 SUSTAINABLE** | Leadership load leaves adequate delivery and personal capacity | Normal |
| **L1 ELEVATED** | Load rising; delivery or rest being displaced | **Monitored at RV-2/RV-3**; mitigation considered |
| **L2 HIGH** | Load is displacing delivery or health; `H_unrecorded` rising | **Mandatory mitigation:** scope reduction, delegation (TL-4), City support **[S-B: §26.4]**, or span change (SP-E) |
| **L3 UNSUSTAINABLE** | Load exceeds what the role can carry | **Structural intervention required:** the role is re-scoped, the team is re-structured **[S: Ch.13 step 9]**, or the position is re-justified under Rule D-39. **The person is not expected to absorb it** |

**[P] Rule D-76 (Load Is A Structural Finding).** An L2 or L3 reading is a finding about **the role and the organisation**, recorded against the role — **not about the person**, and never entered in any individual assessment. **[A]** Reason: if load bands affect a person's standing, people will under-report load, and the index will read L0 everywhere while everyone drowns. **This is Goodhart's law applied to wellbeing measurement, and the only defence is to make the measurement consequence-free for the individual.**

## 24.3 Burnout — detection without surveillance

**[A]** The brief asks for burnout to be addressed. **[P]** The design constraint is severe: **burnout detection that requires monitoring a person's behaviour is surveillance, and surveillance of exhausted people by the organisation that exhausted them is not care.** Detection therefore uses **structural signals only** — things visible in the record without observing the person.

| Signal | What it indicates | Source of data | Individual-visible? |
|---|---|---|---|
| **BN-1** Rising `H_unrecorded` | Work exceeding the role's definition | Ledger | Aggregate to the holder; not published |
| **BN-2** Delegation refused or not used | A holder who cannot let go — either load or dependency | TL-4 records | Holder + line |
| **BN-3** Successor development stalled (SD-c) | No time to develop anyone | SS records | Aggregate |
| **BN-4** Decision records thinning or lagging (GF-15) | Cognitive overload shows up as administrative collapse first | **[S-A: A-15 M1]** | Line + audit |
| **BN-5** Incident reporting **falling** while incidents occur | Concealment capacity exhausted, or fear | **[S-A: A-09]** vs skip-level/Integrity Line volume | Aggregate |
| **BN-6** Cadence attendance pattern change | Disengagement | **[S: Ch.24]** | Holder + line |
| **BN-7** Complaints **by** the holder rising, or **against** the holder rising | Friction is a load symptom | Part 18 records | Aggregate, small-cell suppressed |
| **BN-8** LDI critical with no mitigation | The holder is carrying the unit | Part 38 | Line |
| **BN-9** Self-report | **The only reliable signal.** A person says they are exhausted | Direct | **The person's own** |

**[P] Rule D-77 (Self-Report Is Never Penalised).** A holder who reports exhaustion, overload or inability to continue receives: a load review; a mitigation plan; **no adverse mark of any kind**; and the option of a **dignified pause** under Rule D-26's exit logic and Rule D-27's return route. **[A]** BN-1…BN-8 exist to prompt the organisation to *ask*. **BN-9 is the answer, and the system must make giving it safe.**

**[P] Rule D-78 (No Wellness Instrument That Creates Work).** No survey, check-in, resilience module or wellbeing form may be introduced unless its burden is declared under Rule D-52 and it has a consequence route under Rule D-53. **[A]** **[X]** External evidence is directly relevant: in one large volunteer sample, **training alone did not improve retention** and was associated with higher exit for women — because training raises expectations the role must then meet. **[I]** The same mechanism applies to wellbeing training: **a resilience course delivered to people whose load is L3 teaches them that the organisation intends to keep the load and change them.** **[V] REQUIRES VALIDATION.**

## 24.4 Distribution of leadership work

**[P]** The brief asks about distribution. **[A]** Distribution failure has three forms:

| Form | Mechanism | Correction |
|---|---|---|
| **DF-1 Concentration** | The same person holds multiple functions because the team is small | **[S: Ch.10 State A]** permits combination — **but Rule D-33 requires four continuity routes**, and Rule D-34 tiers redundancy. Where combination produces L2/L3, XG-8 blocks expansion and City support is engaged **[S-B: §26.4]** |
| **DF-2 Invisible work** | Coordination, emotional labour, conflict handling, follow-up — work that is real, unrecorded and unequally distributed | **`H_unrecorded`** makes it visible; **Rule D-69** makes it payable where it is leadership work |
| **DF-3 Gendered and caste-patterned distribution** | **[I]** In any Indian mohalla, who makes tea, who takes notes, who is asked to speak, and who is asked to decide follows existing social patterns that the organisation will reproduce unless it does not | **[P] Rule D-79:** distribution of **functions** — not of tasks — is reported in aggregate at team and city level, with small-cell suppression, and an adverse pattern is a **governance finding**. **[V] REQUIRES PROFESSIONAL VALIDATION** on what may lawfully be collected and how it may be used. **No individual is profiled. No protected characteristic is inferred. Aggregate pattern only** |

**[A]** DF-3 is included because omitting it would be dishonest about the operating context, and because **[S-C]**'s entire architecture is built on the premise that an organisation operating among vulnerable people will otherwise reproduce the vulnerabilities around it. **It is marked [P] and [V] and proposes only aggregate reporting with suppression — never individual classification.**

## 24.5 Workload and the control budget

**[A]** The decisive relationship, stated once:

> **Every control in this document is hours. Every hour is money or delivery capacity. `σ_max` is the ceiling. Therefore the leadership system has a maximum affordable size, and this document has specified more than that maximum.**

**[P]** Resolution: **Part 40** specifies the **Minimum Viable Leadership System (MVLS)** — the subset of this document that a Stage 0–1 team must operate — and defers the remainder to Stage 2+ **[S-ST: §23.1]**. **Rule D-80 (Tiered Obligation):** no team is required to operate an instrument its stage and economics cannot support; **the four irreducible capabilities (Rule D-33) and the gates that prevent irreversible harm are never deferred.** Everything else is tiered.

---

# PART 25 — OPPORTUNITY FAIRNESS, ACCESS & INTERNAL APPLICATION

## 25.1 The question

**[A]** Eligibility (Part 3) answers *who may be considered*. It does not answer *who ever finds out that consideration is possible, and who can afford to put themselves forward*. **[I]** In a mohalla, the people who apply for leadership are systematically not a random sample of the people capable of it. They are the people who: can read the notice, have a phone with data, have time after work, are not caring for someone, are not afraid of being seen to want something, and are already known to the person deciding.

**[P]** Opportunity fairness is therefore specified as **the removal of seven access barriers**, each with a mechanism — not as a statement of intent.

## 25.2 The seven access barriers

| # | Barrier | Mechanism that reproduces it | Correction | Cost |
|---|---|---|---|---|
| **OB-1** | **Language** | Vacancy notices, role briefs and forms in one language | Every vacancy notice, role brief, gate criterion and appeal route published in **the operating languages of the unit**; **[X]** the DPDP Act's plain-language notice standard contemplates English or any of the 22 Eighth Schedule languages **[V]** | Low — translation once, versioned in the library **[S-A: A-15 M2]** |
| **OB-2** | **Literacy** | Written application as the only route | **Oral application recorded by a role-holder who is not the decision-maker**; the record is read back and confirmed | Low |
| **OB-3** | **Digital access** | Application only through the platform | **[X]** Rural–urban and gender digital divides persist; a significant share of rural women do not own a phone. **Offline route is mandatory, not a fallback** — and **[S-B: §40]**'s pilot runs with **no technology at all**, which proves the process is executable on paper | Medium |
| **OB-4** | **Time** | Application windows that assume discretionary time | Windows of stated minimum length; **notice given before the window opens**; no requirement to attend in person during working hours | Low |
| **OB-5** | **Social permission** | Applying is read as ambition, and ambition as a character defect in some groups | **Rule D-81:** an application is a **record**, not a claim, and may not be referenced in any subsequent assessment of the applicant. Refusal rights **[S-C: H-17]** are mirrored by application rights | Low |
| **OB-6** | **Knowledge of the route** | Only people close to the leader know a vacancy exists | **Every vacancy is announced to the whole unit and to the level above** (Part 12 §12.5 PT-7 logic applied downward); **[S: Ch.11]**'s lifecycle begins with a recorded vacancy, not with a private conversation | Low |
| **OB-7** | **Prior exclusion** | Gate E criteria that proxy for education, caste, gender, age or existing standing | Part 3 §3.2 already lists **nine deliberately-absent criteria**. **[P] Rule D-82:** any new Gate E criterion must state what capability it evidences and why no less exclusionary criterion would work | Low |

**[P] Rule D-83 (Access Corrections Are Not Favouritism).** Providing an oral application route, a translated notice or an offline process is **not** an adjustment to standards. **The standard is unchanged; the route to demonstrating it is widened.** Any record that treats an access correction as a concession creates the exact stigma it was meant to remove.

## 25.3 Internal application

**[S: Ch.11 step 9]** — a non-selected member **may apply again**. **[P]** Extended:

| Element | Design |
|---|---|
| **Who may apply** | Any member meeting Gate E for the role. **Not** restricted to the unit where the vacancy arises — a member of another team may apply, subject to their own unit's continuity (Rule D-33, XG-8) |
| **How** | Written, oral-recorded, or platform — all equivalent (OB-2, OB-3) |
| **What the applicant receives** | The role brief **[S: Ch.9]**, the gate criteria, the evidence classes required, and **the reason they were not selected** — recorded, appealable (§18.3) |
| **Reapplication** | Permitted; **no cooling-off period is specified** **[P] UNKNOWN — MEASURE IN PILOT**; a prior non-selection may not be cited as a reason for a later non-selection unless the underlying gap is unchanged and still unevidenced |
| **Feedback obligation** | Every non-selected applicant receives a **specific, evidence-linked reason**. A reason of "another candidate was stronger" is not a reason — it is a restatement of the outcome |
| **Record** | Applications, outcomes and reasons are retained as institutional records **[S-A: A-15 M4]**, not personal ones |
| **Pattern audit** | Applicant pools and selection outcomes reported in **aggregate with small-cell suppression**, to detect OB-7 proxies operating in practice |

**[A]** The feedback obligation is the single highest-value, lowest-cost item in this Part. **[I]** An organisation that never explains a non-selection teaches its members that selection is arbitrary — and once selection is believed to be arbitrary, the capable stop applying and the ambitious start lobbying. **That is the mechanism by which a merit architecture becomes a patronage architecture without anyone deciding it should.**

## 25.4 Youth leadership

**[A]** The source provides: **[S: Ch.12]** twelve-step member lifecycle and ten training categories, with no age rule stated; **[S-C: H-02]** the nine-level participation spectrum beginning at L0; **[S-C]**'s standing instruction that **no invented legal age rules** appear. **[X]** NSS reaches 3.8–3.9 million volunteers, roughly 5–6% of India's student population — evidence that mass youth service participation is achievable but reaches only a small share.

**[P]** Rules, without inventing ages:

| Rule | Content |
|---|---|
| **Rule D-84** | Participation levels, roles and authorities available to a person are determined by **the applicable law and by verified capability**, in that order. **Where law sets a minimum, law governs and this document does not restate it** **[V] REQUIRES LEGAL VALIDATION for every jurisdiction of operation** |
| **Rule D-85** | Where law permits, a younger member may hold **any** role for which they pass Gate E and Gate R. **There is no youth-only leadership track** — a parallel track is a lesser track, and Rule D-35 prohibits track hierarchy by implication |
| **Rule D-86** | Safeguarding obligations attach to the **role**, not to the age of its holder: a young person holding authority over others carries the same duty of care **[S-C: SR-5]** and the same support obligations are owed **to** them |
| **Rule D-87** | The **Elder/Mentor** standing **[S-C: §6.10]** is available from L3 upward and is explicitly intergenerational — it is the instrument by which a young leader acquires an advisor without acquiring a supervisor |
| **Rule D-88** | Youth participation is **never a recruitment target**. **[S-C: H-03]** prohibits recruitment at the moment of vulnerability, and Rule D-37 prohibits publishing density targets. **A quota for young leaders would produce recruited young leaders** |

## 25.5 Accessibility of the leadership system itself

**[P]** The system must be usable by the people it judges. Nine requirements:

| # | Requirement | Failure if absent |
|---|---|---|
| **AX-1** | Every criterion is published, in plain language, before it is applied | Retroactive standards — the definition of arbitrary power |
| **AX-2** | Every decision is reasoned in terms the subject can follow | Appeal becomes impossible in practice |
| **AX-3** | Every route has an offline equivalent | Digital exclusion becomes leadership exclusion |
| **AX-4** | Every timescale is stated | Uncertainty is itself a burden, borne unequally |
| **AX-5** | No route has a fee | Cost-based exclusion |
| **AX-6** | Assistance is available to complete any form or application, from someone who is not the decision-maker | The literate depend on the decision-maker for access to the decision-maker |
| **AX-7** | Records about a person are available to that person, subject to sealed-category rules **[S-A: A-20]** | A secret file is a weapon |
| **AX-8** | Refusal is as easy as acceptance — **[S-C: H-17]** seven refusal rights | Consent is not consent |
| **AX-9** | Nothing requires a person to disclose more than the purpose requires — **[S-A: A-18]** four-branch necessity test | Extraction disguised as process |

## 25.6 The fairness test

**[P]** Applied as the brief requires — a test, not an assertion. **Question: could a person with no relationship to the founder, no formal education, no smartphone, caring for a dependent, in the second mohalla ever become a City-level leader?**

| Test step | Answer | Basis |
|---|---|---|
| Can they find out a role exists? | **Yes, if OB-6 is implemented** | Vacancy announced to the unit and upward **[S: Ch.11]** |
| Can they apply? | **Yes, if OB-2/OB-3 are implemented** | Oral-recorded and offline routes |
| Can they meet Gate E? | **Yes — no education, age, tenure, income, caste, gender, locality or prior-standing criterion exists** | Part 3 §3.2, nine deliberately-absent criteria |
| Can they accumulate LE-2 evidence? | **Yes, if verification capacity exists** | Part 5; PL-1 bottleneck is the verifier |
| Can they accumulate LE-3 behavioural evidence? | **Conditionally — this is the weak point.** LE-3 requires observation across situations by people who are not their intimates. In a small unit, the observers are their intimates | Part 5 §5.1; **out-of-team assessor (Rule D-45) is the correction, and it requires City capacity** |
| Can they pass Gate R? | **Only if an out-of-team assessor exists** | Rule D-45 |
| Can they be selected over a popular local candidate? | **Only if Rule D-64 (two independent signals) and the F-360a event-evidence rule hold** | §17.5 |
| Can they survive the promotion economically? | **Uncertain — depends on `m_lead` and on `σ_max`** | Part 23 CT-1…CT-8; **[U]** |
| Can they appeal if wrongly rejected? | **Yes** — free, out-of-line, reasoned, with the team having standing too | §18.3 |

**[P] Verdict on the fairness test: PASS CONDITIONAL — the architecture does not exclude them, but three conditions must hold in practice: (i) verification capacity exists locally or at City; (ii) an out-of-team assessor exists; (iii) the economics of holding the role do not make it unaffordable to a poor person.** Condition (iii) is the one most likely to fail and the least visible: **a role whose unpaid or underpaid leadership burden exceeds a poor person's spare capacity is formally open and practically closed.** Rule D-47 and Rule D-69 exist precisely to prevent this, and their sufficiency is **UNKNOWN — MEASURE IN PILOT**.

---

# PART 26 — STAFFING, SPAN & MINIMUM VIABLE TEAM STRUCTURE

## 26.1 The unresolved staffing question

**[S: Ch.33]** — minimum staffing thresholds: **`NOT FINAL`**, "no final numbers invented". **[S: Ch.10 State A]** — nine functions, with role combination permitted and the explicit rule that "small size never removes safety, HR verification, finance integrity or evidence duties". **[S-B: §40.2]** — a State A team has `⌈9/c⌉` role-holders, where `c` is the role-combination factor, and `c` is to be measured in the pilot. **[S-B: §26]** — `K_min`, the City divisor `H_gov_per_team(K)`, and the **B-21 City Shared Services Contract**.

**[P] v1.3-D invents no staffing number.** It specifies **what determines** the number:

| Determinant | Relationship | Source |
|---|---|---|
| **Functions operated** | A team must hold or route all nine State A functions | **[S: Ch.10]** |
| **Segregation of duties** | Four finance hands must be distinct; a team alone cannot satisfy this | **[S: Ch.18; S-B: MVC-1, §3.3]** |
| **Four irreducible capabilities** | DECIDE, PAY, VERIFY, STOP each need a named continuity route | Rule D-33 |
| **Control budget** | `H_gov ≤ σ_max` | **[S-B: §26.1]** |
| **Span feasibility** | Span bounded by verification capacity, control budget and duty of care | §14.4 SP-A…SP-E |
| **Succession obligation** | Mandatory-SS-4 roles need a successor in development, which consumes the incumbent's time | §11.3; SD-c |
| **City divisor** | Some functions may be supplied by the City rather than held locally | **[S-B: §26.4, B-21]** |

**[C]** Therefore: **`n_min` = the smallest number of role-holders such that (a) all nine functions are held or routed, (b) four distinct finance hands exist including at least one outside the team where necessary, (c) all four irreducible capabilities have continuity routes, (d) `H_gov(n) ≤ σ_max`, and (e) every mandatory-SS-4 role has a development route that does not depend on the incumbent's spare time.** **The value of `n_min` is `UNKNOWN — MEASURE IN PILOT`.**

## 26.2 Held vs routed

**[P]** The distinction that makes small teams viable — and the one **[S-B: §26.4]** already implies:

| Function class | May be routed to City? | Condition | Source |
|---|---|---|---|
| **Safety / stop-work** | **No — the capability must be present, though the person may hold it jointly** | Rule D-33; **[S: Ch.10 State A]** | **[S-B: §23.2]** — Safety must be ● early |
| **Finance integrity** | **Partially** — recording locally; **approval and audit externally** | **[S-B: B-21]** City Shared Services Contract; **[S-ST: F-03(10)]** out-of-team Funds reviewer | **[S-B: §23.2]** — Finance must be ● early |
| **HR verification** | **Yes** — verification may be performed by the City where no local verifier exists | **[S-B: MVC-2]**; Rule D-43 XG-4 | — |
| **Evidence and record-keeping** | **No** — the record is made where the work happens | **[S: App. F]** | — |
| **Decision (DECIDE)** | **No** | Rule D-33 | **[S: Ch.8]** |
| **Training delivery** | **Yes** | Trainer cadre is a shared resource | **[S-ST: Scenario B]** |
| **Assessment (Gate R)** | **Yes — and preferably so** | Rule D-45 requires out-of-team | — |
| **Audit** | **Yes — necessarily** | Auditor is review-only, not operational **[S: Ch.23]** | **[S-B: §26.4]** |

**[P] Rule D-89 (Routing Is Recorded, Not Assumed).** Where a function is routed, the routing is recorded in the role brief with the receiving role, the response expectation and the fallback. **[A]** An unrouted assumption is how a small team discovers, during a crisis, that nobody was doing the thing everyone assumed the City was doing.

## 26.3 Span — the structural responses

**[A]** §14.4 fixed the principles; this section fixes the responses when span is exceeded. **SP-E** prohibited "tolerate it". The four permitted responses:

| Response | When appropriate | Consequence | Control |
|---|---|---|---|
| **R-1 Add a coordinator** | A named function exists and is unheld | +1 position; +`H_gov`; Rule D-39 justification required | Position justification record |
| **R-2 Split the team** | The unit has outgrown its geography or its social coherence | Two units, each needing its own four capabilities and its own `σ_max` | **[S: Ch.13 step 9]** growth logic; **GF-22 control** — split requires City approval with recorded reason |
| **R-3 Reduce scope** | The unit is carrying obligations it cannot verify | Fewer commitments; honest contraction | **[S: App. A §16.3]** report results honestly, including failures |
| **R-4 Route the function** | The function does not need local presence (§26.2) | City load increases; `H_gov_per_team(K)` changes | Rule D-89; **[S-B: B-21]** |

**[P] Rule D-90 (Span Findings Are Structural).** A span finding names the **structure**, not the **person**. "This leader manages too many people" is a structural statement about the unit; "this leader cannot cope" is a personal one and is inadmissible unless an RV-3 with LE-3 evidence supports it.

## 26.4 Layer economics at four levels

**[A]** **[S: Ch.4]** fixes Mohalla → City → State → National. The leadership cost of each layer:

| Layer | What it must supply | Leadership cost driver | Scaling character |
|---|---|---|---|
| **Mohalla** | Nine functions, four capabilities, a Team Leader, a successor in development | `H_gov` per team, 8–40 h/month **[S-B: §25]** — the single most important unknown | **Linear in teams** |
| **City** | Shared services: verification, funds review, audit, assessment, trainer supply, emergency cover | `H_gov_per_team(K)` — the divisor, whose **shape is unresolved** | **Sub-linear if the divisor works; super-linear if it does not** |
| **State** | Coordination across cities, standard-setting, escalation, cross-city succession | Fewer units, higher consequence per decision | **Stepwise** |
| **National** | Constitutional custody, reserved matters, apex continuity, institutional memory | **Not a per-unit cost — a fixed institutional cost** | **Constant, but non-deferrable** |

**[P] Rule D-91 (The City Divisor Must Be Measured Before Expansion).** No State-level structure may be created until the City divisor `H_gov_per_team(K)` has been measured across at least the pilot range of `K`. **[A]** Reason: if the divisor is not sub-linear, then adding cities adds governance faster than it adds capacity, and the State layer would be built on an arithmetic that does not hold. **[S-ST: F-21]** identified layer explosion as a failure mode; **this rule is the gate that prevents it from becoming a decision.**

**[U] UNRESOLVED — DO NOT INVENT:** the shape and value of `H_gov_per_team(K)`; `K_min`; `n_min`; the combination factor `c`; the leader multiplier `m_lead`; minimum staffing thresholds. **All five are carried to Part 45 unchanged.**

---

# PART 27 — FOUNDER CONCENTRATION & INSTITUTIONAL INDEPENDENCE

## 27.1 The facts, as sourced

**[S]** Founder and CEO: **Vasu**. Owner: **Krytos**. "Sewak Sathi Sanstha" is a **PROPOSED** public name. **[S: Const. Art.3]** — ownership by Krytos under founder/CEO Vasu. **[S: Ch.33]** — **CEO vs National Council authority: `UNRESOLVED`**; **legal structure under Krytos: `UNRESOLVED`**. **[S-A: A-14]** — apex Deputy, Interim Authority Order, seven reserved matters, dual-custody credentials, two bank signatories, emergency and continuity-during-dispute rules, sixteen-item handover checklist, annual unannounced 72-hour continuity test. **[S-A: A-16]** — seven conditions on founder influence, four annual institutional tests, public-representation rules. **[S-ST: F-14, F-15]** — founder concentration as a failure mode.

**[P] v1.3-D does not resolve CEO vs National Council. It does not name a successor to the founder. It does not propose a date for founder transition.** All three are outside its authority and are carried to Part 45.

## 27.2 The concentration problem, stated without flattery

**[A]** The architecture's own theory of leadership is **"earned through performance"** **[S: Const. Art.4]** and **"greater responsibility only to those who earned greater trust"** **[S: Const. Art.2]**. The founder's position does not rest on that theory. It rests on **having created the organisation** — which is a real and legitimate basis, and a **different** one.

**[I]** The consequence is structural, not personal: **every mechanism in this document that depends on being applied to the most powerful person will not be applied to the most powerful person unless the architecture compels it.** Specifically:

| Mechanism | Applies to a Team Leader? | Applies to the founder without compulsion? |
|---|---|---|
| Gate E / Gate R | Yes | **No** — the founder holds no vacancy-earned role |
| RV-3 out-of-line leadership review | Yes | **No** — there is no line above |
| LDI critical-band finding (Rule D-62) | Yes | **Yes in fact, no in practice** — nobody will record it |
| Decision record with reasons (Rule D-54 logic) | Yes | Only if compelled |
| Conflict-of-interest declaration (Part 35) | Yes | Only if compelled |
| Rule D-41 no shadow authority | Yes | **The founder is the most likely source of shadow authority** |
| Removal route | Yes | **No — and this is correct; but it means the only check is institutional, not personal** |

**[P] Rule D-92 (Founder Recusal Register).** A single register records every instance in which the founder: (i) made or influenced a leadership decision outside a formal process; (ii) expressed a preference about a named candidate; (iii) intervened in an assessment, gate or appeal; (iv) directed expenditure outside the waterfall; (v) caused a role, position or body to be created or abolished. **The register is retained, is auditable, and is reported in aggregate annually.** **[A]** It does not prohibit any of these acts — the founder's authority is what it is, and **[S: Const. Art.3]** is APPROVED. **It makes them visible.** Visibility is the only check available where removal is not.

**[P] Rule D-93 (The Founder May Not Assess).** The founder may not perform: a Gate R assessment; an RV-3 leadership review; an out-of-team assessment under Rule D-45; a certification assessment under Rule D-48; or a panel role in CR-3/CR-4 concerning a person the founder has publicly praised or criticised. **The founder may provide evidence, may be interviewed, and may express a view — recorded in the Founder Recusal Register — which the deciding body may then accept or reject with reasons.** **[A]** This is the minimum architectural correction for the ES.5 weakness: an assessment the founder performs is an assessment nobody can appeal against in practice.

## 27.3 The four annual tests, applied to the founder

**[S-A: A-16]** — four annual institutional tests: **absence, attribution, dissent, successor**, with the source's own warning that **"a zero count is a warning sign"**. Generalised at Part 11 §11.9; applied here specifically:

| Test | Founder-specific question | Healthy sign | Warning sign |
|---|---|---|---|
| **T1 ABSENCE** | Did the organisation operate correctly during a period when the founder was genuinely unreachable? | A recorded absence period with no reserved-matter decisions and no service interruption | **Zero absences.** The founder has never been unavailable, which means the continuity instruments have never been exercised |
| **T2 ATTRIBUTION** | Of the year's decisions, how many are attributed to roles rather than to the founder? | Most decisions attributed to roles, with reasons | **All significant decisions attributed to one person** — the organisation has no decision-making capacity, only a decision-maker |
| **T3 DISSENT** | How many recorded dissents against a founder preference occurred, and how many were followed by the dissenter's position being adopted? | Dissents recorded, some adopted, no adverse consequence to dissenters | **Zero dissents.** Not agreement — silence. **[S-A: A-16]** treats zero as the warning |
| **T4 SUCCESSOR** | For every role whose failure would end the organisation — including the apex — is there a named, developed, exercised successor? | SS-4/SS-5 at apex with an exercised Interim Authority Order **[S-A: A-14]** | **SS-0 at apex**, or a named successor who has never held delegated authority |

**[P] Rule D-94 (Test Results Are Published Internally).** The four counts are reported annually to the governance body and to all role-holders. **They are not scores and are not ranked; they are four integers with an interpretation.** **[A]** Publishing them is what converts a self-assessment into an accountability instrument — and it costs nothing.

## 27.4 Public representation

**[S-A: A-16 §15.4]** public-representation rules, applied to leadership:

| Rule | Content |
|---|---|
| **PR-1** | Public statements about performance, leadership or succession are made **in the organisation's name**, by **authorised spokespersons by domain and region** — a set of people doing work, not one face |
| **PR-2** | No public statement may attribute an organisational achievement **solely** to a leader where a team produced it |
| **PR-3** | No public statement may describe leadership as a higher form of service **[S-C: §8.4]** |
| **PR-4** | Failures are represented honestly, including where the failure was leadership failure **[S: App. A §16.3]** |
| **PR-5** | Public recognition follows Rule D-67 — contribution, never comparative position |
| **PR-6** | The founder's image, name or personal following may not be used as the organisation's primary public identity. **[A]** This is the anti-personality-cult control with the largest effect and the smallest cost — and the one most likely to be resisted, because it reduces short-run attention |

## 27.5 Institutional independence — the seven conditions

**[S-A: A-16]**'s seven conditions on founder influence are preserved and applied to the leadership system:

**[P] Rule D-95 (Independence Is Structural).** Independence from any single person is achieved by structure, not by intention. The seven structural requirements, as they bear on leadership:
1. **Reserved matters** cannot be decided by any one person, including the founder **[S-A: A-14 §13.3]**.
2. **Dual custody** of credentials and **two signatories** at every level **[S-A: A-14 §13.4]**.
3. **Decision records** with reasons, retained institutionally **[S-A: A-15 M1, M4]**.
4. **Dissent routes** that are recorded and safe **[S-A: A-16 test 3]**; **[S-ST: M10]** Integrity Line and ombuds.
5. **Assessment independence** — out-of-team assessors (Rule D-45), independent reviewers (Rule D-50), founder recusal (Rule D-93).
6. **Continuity instruments** that have been **exercised**, not merely written **[S-A: A-14 §13.8]** annual unannounced 72-hour test.
7. **Memory** held institutionally, not personally (Part 28).

**[A]** The honest finding: **requirements 1, 2, 3, 6 and 7 are architectural and can be built. Requirements 4 and 5 are behavioural and cannot be built — they can only be made cheap and safe, and then observed.** **Whether people actually dissent, and whether assessors actually dissent from the founder, is `EMPIRICALLY UNVALIDATED` and is the single largest uncertainty in this document.**

---

# PART 28 — INSTITUTIONAL MEMORY & ROLE PLAYBOOKS

## 28.1 The memory instruments, applied to leadership

**[S-A: A-15]** M1–M7, preserved and given their leadership-system function:

| Instrument | Content **[S-A]** | Leadership function **[P]** |
|---|---|---|
| **M1 DECISION RECORD** | What was decided, by whom, on what evidence, with what reason, and what was expected | The primary LE-1 evidence class; the RV-3 Q1 source; the anti-arbitrariness control. **Without M1 there is no appeal, because there is nothing to appeal against** |
| **M2 VERSIONED STANDARD LIBRARY** | Standards, SOPs and policies under version control | Certification standards (Rule D-48); SP-6 standard ownership; the **[S-ST: F-13/M23]** change-request route |
| **M3 CHANGE REQUEST ROUTE** | Any member may propose a change; reasons recorded; inspectable by any member | The mechanism by which a specialist or a junior member can change the system — **the only real alternative to exit** |
| **M4 INSTITUTIONAL RETENTION** | Records are institutional, not personal | Handover packs survive the person; the contribution record survives departure |
| **M5 LESSONS ENTRY** | After every incident and transition, with a **"did it work"** column | The learning loop; SD-d transfer quality; the anti-recurrence control |
| **M6 ROLE/PROCESS DOCUMENTATION** | What each role does | **The playbook (§28.2)** |
| **M7 ORAL HISTORY** | Recorded accounts from long-serving members | Elder/Mentor function **[S-C: §6.10]**; the only memory of *why* a rule exists, as distinct from *that* it exists |

## 28.2 The role playbook

**[P] Amendment L-16.** Every covered role has a playbook. **Rule D-34 relies on the playbook as the economic substitute for a third redundant person**, so its content is specified:

| Section | Content | Why it is in the playbook and not in the role brief |
|---|---|---|
| **PB-1 PURPOSE & BOUNDARY** | As **[S: Ch.9]** — purpose, authority, limits, "Cannot do" | Restated locally, in the operating language |
| **PB-2 THE WEEK** | What this role actually does, in what order, at what cadence **[S: Ch.24]** | The role brief says what the role is for; the playbook says what Tuesday looks like |
| **PB-3 THE DECISIONS** | The recurring decisions, the criteria, the evidence needed, and **two worked examples with reasons** | LE-1 quality depends on people knowing what a reason looks like |
| **PB-4 THE REFUSALS** | What this role must refuse, and the exact words and record for refusing | AF-C2/AF-C3 capability; **[S: Ch.9]** "Cannot" boundaries made usable |
| **PB-5 THE ESCALATIONS** | What must be escalated, to whom, within what time, and what to do while waiting | **[S-A: A-09]**; STOP capability |
| **PB-6 THE HANDOVER** | KT-1…KT-10 checklist, pre-filled with the role's specifics | Makes handover executable by someone who has never done one |
| **PB-7 THE FAILURES** | Known failure modes of this role, from M5 lessons entries — **including the failures of previous holders** | The most valuable section and the one most often omitted out of courtesy |
| **PB-8 THE CONTACTS** | Role-based contacts and the routing table (Rule D-89) | Continuity |
| **PB-9 THE BURDEN** | Declared `H_gov` for this role, and the LLI bands | Rule D-52; makes overload legible before it happens |
| **PB-10 THE VERSION** | Version, date, author role, last review, next review | M2 |

**[P] Rule D-96 (A Playbook Is Tested, Not Filed).** A playbook is **exercised** in the annual unannounced continuity test **[S-A: A-14 §13.8]**: a person who does not hold the role is given the playbook and asked to perform a defined function. **The result is recorded as a playbook finding, not as a person finding.** **[A]** An untested playbook is a document that describes what its author believes the role is — which is exactly what a departing leader believes, and exactly what may be wrong.

## 28.3 Memory across a leadership transition

**[A]** The specific failure: **[I]** when a leader leaves, three kinds of knowledge leave with them, and only one of them is in any record.

| Knowledge kind | Example | Recorded anywhere? | Instrument |
|---|---|---|---|
| **Explicit** | The ledger position, the deadlines, the access list | Yes, if KT-6/KT-8/KT-5 are completed | KT pack |
| **Procedural** | How to actually get the City to respond; which form works | **No** | **PB-2, PB-3, PB-5** — the playbook |
| **Relational** | Who in the mohalla will not speak to whom; which household must be approached through an elder; what was promised informally last year | **No** | **M7 oral history; KT-4 critical contacts; the F-360a witness record** |

**[P] Rule D-97 (Relational Memory Is Captured At Transition, With Consent).** The outgoing holder is asked, at handover, to record what they know about relationships, promises and local sensitivities — **in a form that names roles and situations, not vulnerabilities**, classified per **[S-A: A-17]** and accessible per **[S-A: A-19/A-20]**. **[A]** This is the highest-value, most-often-skipped item in any handover, because it feels like gossip. **It is not gossip; it is the operating map of a community, and the incoming leader will otherwise rebuild it by making mistakes on real people.**

**[P] Rule D-98 (Memory Is Not Surveillance).** Relational memory records may not contain: health information, financial information about private individuals, protected-characteristic inferences, safeguarding allegations, or anything a named individual would reasonably object to having recorded. **Where such a fact must be carried forward, it is carried as a sealed-category record under [S-A: A-20] with case-scoped access — not as a playbook note.**

## 28.4 What memory costs

**[A]** Honest accounting:

| Instrument | One-time cost | Recurring cost | Substitute if unaffordable |
|---|---|---|---|
| M1 decision record | Low | **Per decision** — the real cost | A single standard sentence: *what, why, who, when, expected* — Rule D-54 minimum |
| M2/M3 versioned library | Medium | Low | A single controlled document with a change log |
| M4 retention | Low | Storage | — |
| M5 lessons entry | Low | **Per incident** | Three lines: what happened, what we did, did it work |
| M6/PB playbook | **High** — the largest single item in this Part | Per review cycle | **PB-1…PB-6 only**, deferred PB-7…PB-9 to Stage 2+ (Rule D-80) |
| M7 oral history | Medium | Per departure | **One recorded conversation at every leadership transition** — which Rule D-97 already requires |

**[P] Rule D-99 (Memory Minimum).** At Stage 0–1, the mandatory memory instruments are **M1 (decision record), M4 (retention), M5 (lessons entry, three lines) and PB-1…PB-6 (playbook core)**. Everything else is tiered under Rule D-80. **[A]** These four are chosen because they are the four that make a decision **reviewable** and a role **transferable** — the two properties without which no other control in this document can operate.

---

# PART 29 — RBAC, SECURITY & TRANSITION ACCESS

## 29.1 What the source fixes

**[S: Ch.23]** — a per-role RBAC matrix including an **Auditor** row: "Review only; not operational commander." **[S: Ch.22]** — per-role fields `permission_profile`, `financial_permission_profile`, `data_access_profile`, `delegated_authority` (scope, limits, dates, reason, reviewer), `delegation_start_date`, `delegation_end_date` with automatic expiry, and the rule "one role has one primary holder". **[S: App. E]** — platform permission change: **Technology admin**. **[S: Ch.18]** — segregation of duties across four distinct finance hands. **[S-A: A-14 §13.4]** — dual custody of credentials. **[S-A: A-17/A-19/A-20]** — classification, access separation, sealed categories.

**[A]** The source's RBAC is **role-based and complete in structure**. What it does not address is **the transition moment** — the period in which two people, an outgoing and an incoming holder, both have a claim on the same permissions. **[I]** This is the highest-risk window in any access-control system, because it is the only window in which the correct behaviour (keep things running) and the dangerous behaviour (leave access in place) are indistinguishable from inside.

## 29.2 RBAC during transition

**[P] Amendment L-17 — Transition Access Protocol.**

| Phase | Outgoing holder | Incoming holder | Interim holder (TL-1/TL-2/TL-3) |
|---|---|---|---|
| **TA-0 Before decision** | Full role permissions | None | None |
| **TA-1 Decision recorded** | Full | **Read-only** on the role's records, granted for the handover period only | As scoped by the instrument |
| **TA-2 Handover** | Full, **with every action logged and reviewed** | Read-only + **write on KT artifacts only** | As scoped |
| **TA-3 Authority transfer** | **Reduced to advisory**: no approval, no spend, no appointment, no record alteration | Full role permissions per RBAC | Instrument expires automatically (Rule D-30) |
| **TA-4 Closure** | **Advisory access ends at a stated date**; residual access only where a specific, recorded, time-bounded reason exists | Full | Closed |

**[P] Rule D-100 (No Overlapping Command).** At no point may two people hold write authority over the same role's decisions, approvals or payments. **[S: Ch.22]**'s "one role has one primary holder" is enforced at the permission layer, not only at the record layer. **Read-only overlap is required for handover; write overlap is prohibited absolutely.**

**[P] Rule D-101 (Advisory Access Is Bounded).** Post-transition advisory access for an outgoing holder is granted only on a recorded TL-4 delegation with scope, limits, dates, reason and reviewer **[S: Ch.22]**, and expires automatically. **"They might be needed" is not a scope.**

**[P] Rule D-102 (The Suspended and Removed Hold Nothing).** On suspension or removal, the person's role permissions are withdrawn **at the moment of the decision**, not at the moment of the process's conclusion. Access needed for the person to answer the case is granted separately, read-only, scoped to the case **[S-A: A-20 case-scoped access]**. **[A]** The common failure — leaving access in place "until the process finishes" — hands a disciplinary subject the ability to alter the record of their own conduct.

## 29.3 The transition access checklist

**[P]** Eight mandatory steps, each recorded, each with a named performer who is **not** the outgoing holder:

| # | Step | Performer | Evidence |
|---|---|---|---|
| **TA-a** | **Authority review** — every delegation issued by the outgoing holder is listed and either confirmed, re-issued in the incoming holder's name, or expired | Incoming holder + HR | TL-4 records |
| **TA-b** | **Access review** — every system, module and record scope | Technology admin **[S: App. E]** | `permission_profile` diff |
| **TA-c** | **Credential update** — keys, tokens, devices, accounts, shared logins eliminated | Technology admin + **dual custody** **[S-A: A-14 §13.4]** | Custody record — **values never recorded** |
| **TA-d** | **Financial permission review** — signatory status, limits, approval thresholds | Finance function; **two signatories maintained throughout** | `financial_permission_profile`; **[S-A: A-14 §13.4]** |
| **TA-e** | **Data access review** — `data_access_profile` against the necessity test | Data function | **[S-A: A-18]** four-branch test |
| **TA-f** | **Device and account review** — organisation accounts on personal devices; personal accounts holding organisational data | Technology admin | Record of remediation |
| **TA-g** | **Delegation expiry sweep** — all `delegation_end_date` values in the past are closed | System, automatically **[S: Ch.22]** | Expiry log |
| **TA-h** | **Audit log preservation** — logs for the outgoing holder's tenure are sealed and retained, and are **not deletable by any role** | Auditor (review-only **[S: Ch.23]**) | Retention record **[S-A: A-17 P2]** |

**[A]** TA-h is the one that determines whether anything else is enforceable. **If a departing leader can delete their own audit trail, every other control in this document is retroactively optional.**

## 29.4 Least privilege and segregation, in a small unit

**[A]** **[S-B: §3.3]** established that a mohalla team **cannot** satisfy segregation of duties alone. **[S: Ch.18]** requires four distinct hands. **[P]** Resolution, already implied by **[S-B: B-21]** and made explicit:

| Duty | Held locally? | Routed? | Rule |
|---|---|---|---|
| **Receive** | Yes | — | Team member |
| **Record** | Yes | — | Different person from receiver where `n` permits; otherwise logged and sampled |
| **Approve** | **No, where the amount exceeds the local limit** | City / level above | **[S: App. E]**; **[S-B: §26.4]** |
| **Audit** | **Never** | Independent | **[S: Ch.23]** Auditor is review-only and not operational |

**[P] Rule D-103 (Segregation By Level, Not By Heroism).** Where a team cannot segregate, the duty moves up a level rather than being performed by the same person with extra care. **Extra care is not a control.**

## 29.5 Account takeover and identity

**[P]** The threat model for a leadership transition:

| Threat | Mechanism | Control |
|---|---|---|
| **SEC-1 Credential retention** | Outgoing holder keeps a shared login "for convenience" | TA-c: **shared logins eliminated**; individual credentials only |
| **SEC-2 Impersonation of a leader** | A message appears to come from a leader authorising payment or access | **Dual confirmation for any consequential instruction** — payment, permission change, record deletion — through a second recorded channel. **[S-A: A-14 §13.4]** dual custody applied to instructions, not only to keys |
| **SEC-3 Session survival** | An authenticated session outlives the authority | Session invalidation on any TA-b/TA-c change |
| **SEC-4 Authority by device** | A person holding a leader's phone is treated as the leader | **Authority attaches to the authenticated identity and the role record, never to the device.** A device is evidence of nothing |
| **SEC-5 Privilege creep** | Delegations accumulate and are never expired | TA-g automatic expiry **[S: Ch.22]**; periodic access recertification at RV-2 |
| **SEC-6 Insider record alteration** | A role-holder edits historical evidence to improve a score | Append-only records; alteration creates a new version with reason; audit log sealed (TA-h) |
| **SEC-7 Emergency-authority persistence** | TL-3 authority survives the emergency | Rule D-30 automatic expiry; Part 37 post-crisis review |
| **SEC-8 Orphaned authority** | A role is vacant and its permissions belong to nobody, so nobody can act | **[S: Ch.11]** vacancy statuses + TL-2; Rule D-33 continuity routes |
| **SEC-9 Exfiltration at departure** | A departing holder copies beneficiary, financial or member data | `data_access_profile` minimisation **[S-A: A-18]**; export logging; TA-e review; **prohibited uses [S-A: A-20 §19.5]** |
| **SEC-10 Coerced authority** | A role-holder is pressured by an external party — political, commercial or criminal | Integrity Line **[S-ST: M10]**; **anti-capture controls, Part 36**; the DO-NOT list **[S-A: A-08]** binds at every level |

**[P] Rule D-104 (Loss of Access and Theft of Access Are Investigated Differently).** A leader reporting lost access and an attacker using stolen access present identically in a log. **Both are treated as potential compromise until resolved**: credentials reissued under dual custody, sessions invalidated, recent actions reviewed. **The reporting person is not presumed to be the attacker, and is not presumed not to be.**

## 29.6 The audit log

| Property | Requirement |
|---|---|
| **Scope** | Every permission change, delegation, approval, payment instruction, record alteration, score finalisation, gate application, complaint, appeal and decision |
| **Immutability** | Append-only; no role may delete; correction is a new entry with reason |
| **Retention** | Per **[S-A: A-17 P2]**; **[S: Ch.33]** retention remains `UNRESOLVED` and is carried to Part 45. **[X]** DPDP Rules contemplate log/traffic-data retention of at least one year for specified purposes, then erasure **[V] REQUIRES LEGAL VALIDATION** |
| **Access** | Auditor review-only **[S: Ch.23]**; subject access to records about themselves **[S-A: A-20 §19.7; S: Const. Art.6]**; sealed categories case-scoped with the two-person rule **[S-A: A-20]** |
| **Use** | Anomaly detection **[S: App. E — escalate on anomaly]**; GF-series detection signals (Part 20); pattern audit (§25.3) |
| **Prohibition** | **The log may not be used to monitor individuals for productivity, sentiment or loyalty.** It records acts of authority, not behaviour |

---

# PART 30 — AI-ASSISTED LEADERSHIP

## 30.1 The source rule, verbatim and non-negotiable

**[S: Const. Art.12, APPROVED ARCHITECTURE]** — AI **may recommend**; **humans decide**; AI **cannot autonomously make consequential HR, wage, legal, safeguarding, safety, major fund or leadership decisions.**

**[A]** This is the strongest single sentence in the source hierarchy for the purposes of this document, and it is **APPROVED**, not PROPOSED. **v1.3-D does not extend it, qualify it or optimise around it.** Everything below is implementation.

## 30.2 What AI may and may not do in the leadership system

| Function | AI may | AI may not | Human who decides |
|---|---|---|---|
| **Score computation** | Aggregate, normalise within cohort, flag anomalies, attach a confidence rating | Finalise a score; determine a gate outcome | Performance function + Audit **[S: App. E]** |
| **Eligibility screening** | Check whether recorded facts meet published Gate E criteria | Decide eligibility where a criterion requires judgement; exclude anyone | Eligibility engine operator + HR **[S: Ch.11]** |
| **Readiness assessment** | Assemble the evidence portfolio; surface gaps; list which LC dimensions lack evidence | **Assess readiness.** Gate R is a human judgement on LE-3/LE-4 evidence | Out-of-team assessor (Rule D-45) |
| **Promotion recommendation** | Rank candidates **only against published criteria, with reasons and confidence, and only for a human reader** | Recommend a person; break a tie; decide | Appointing authority **[S: App. E]**; leadership transfer = CEO/governance process |
| **Succession planning** | Identify SS-0/SS-1 roles; compute LDI bands; flag unexercised delegations | Name a successor; declare readiness | Role-holder + line + HR |
| **Complaint triage** | Classify a complaint into CR-1…CR-4; flag urgency | Decide any complaint; assess credibility | Triage role-holder; panel for CR-3/CR-4 |
| **Anomaly and gaming detection** | Surface GF-series detection signals | Conclude that gaming occurred | Audit |
| **Workload and burnout** | Compute LLI bands from the ledger | Diagnose a person; recommend rest or removal | RV-2/RV-3 reviewer; **the person themselves (Rule D-77)** |
| **Training** | Deliver content; track completion; generate practice scenarios | Certify competence | Out-of-team assessor (Rule D-48) |
| **Records and memory** | Draft decision records from structured inputs; index the library; summarise lessons | Write the reason. **The reason is the human's** | The decision-maker |
| **Safeguarding** | Route a report immediately to a human | Assess risk to a child or vulnerable adult; close a case | Designated safeguarding role **[S-C: SA-1…SA-7]** **[V]** |
| **Payment** | Compute per the approved formula version | Approve or alter pay | Finance, per **[S: Ch.18]** segregation |

## 30.3 The eight AI fairness controls

**[P]** Each control names the failure it prevents:

| # | Control | Failure prevented |
|---|---|---|
| **AI-1** | **Every AI output carries a confidence rating and its input list.** No output without provenance | Unchallengeable recommendation |
| **AI-2** | **Every consequential decision records the human decision-maker, the AI input considered, and whether it was followed.** Deviation is normal and is not flagged as an error | **[S-ST: F-29]** rubber-stamping — the human deferring because disagreeing requires effort |
| **AI-3** | **No AI output may be the sole basis for a consequential decision** (Rule D-64: two independent signals) | Single-method capture |
| **AI-4** | **Human override is a single recorded step, requires no justification when it favours the subject, and requires justification only when it disadvantages them** | Asymmetric friction — overriding in someone's favour should be free |
| **AI-5** | **Prohibited inputs.** No model may use: protected characteristics or proxies; religion; political affiliation; caste; place of birth; family relationships; beneficiary status; complaint history as a negative; social-media following; or any sealed-category record **[S-A: A-17/A-20]** | Discrimination by proxy; **[S-C: CR-4]** no profiling for third parties |
| **AI-6** | **Cohort-relative outputs only where the cohort assignment is from records** (CN-1) — never from a model's clustering | Model-invented cohorts that encode existing disadvantage |
| **AI-7** | **Periodic disparity testing**: outcomes compared across units and cohorts in aggregate with small-cell suppression; a disparity is an investigation trigger, not a finding | Silent bias accumulation |
| **AI-8** | **Model changes are versioned and recorded** like any standard **[S-A: A-15 M2]**, with the change reason and the affected decisions identifiable | Undetectable drift; inability to appeal a decision made under a superseded model |

## 30.4 Explainability — the operational standard

**[P] Rule D-105 (The Stranger Test, Applied To Machines).** Any AI output used in a leadership process must be accompanied by an explanation that a **non-technical subject** can follow and can contest. **Where no such explanation exists, the output may not be used in a consequential process.** **[A]** This is not a transparency preference; it is the precondition of the appeal right (§18.3). **An unexplainable recommendation that a panel follows is an unreviewable decision, and Rule D-54 makes it inadmissible.**

**[P] Rule D-106 (No Black Box In A Consequential Path).** Where a capability cannot be explained — including any model whose behaviour its operators cannot describe — it is confined to **non-consequential** uses: drafting, summarising, indexing, scheduling, translation, aggregation for internal diagnosis. **[A]** These uses are genuinely valuable and should be pursued; the rule does not restrict them.

## 30.5 AI and the founder-concentration problem

**[A]** An uncomfortable interaction, stated because the brief forbids softening: **[I]** an AI system trained on this organisation's own records will learn **who the organisation has actually promoted**, and will recommend more of them. If past promotions were influenced by founder preference (Rule D-92 register), the model will encode that preference and present it as evidence. **The model then launders a personal pattern into an institutional one, with a confidence rating attached.**

**[P] Rule D-107 (Historical Bias Is Not A Baseline).** No model may treat historical promotion outcomes as ground truth for capability. Historical outcomes are **inputs to disparity testing (AI-7)**, never **labels for prediction**. **[A]** This is the single most important AI rule in this document, because it is the one most likely to be violated for ordinary engineering reasons: historical outcomes are the only labels available, and using them is the obvious design.

## 30.6 AI-assisted leadership development

**[P]** Permitted and useful, bounded:

| Use | Value | Boundary |
|---|---|---|
| Scenario generation for DV-4 | Cheap, repeatable, varied pressure situations | **The assessment is human**; the scenario is a stimulus |
| Drafting decision records | Reduces the burden that makes M1 fail in practice | **The reason is the human's** (§30.2) |
| Translating standards and notices | Directly serves OB-1 | Versioned in the library **[S-A: A-15 M2]** |
| Summarising lessons entries | Makes M5 searchable | Never replaces the "did it work" column |
| Practice refusal exercises (AF-C2/C3) | A person can practise refusing an AI without social cost | **Practice is not assessment** |
| Playbook drafting | Reduces the largest memory cost (§28.4) | **PB-7 known failures must be human-written** — a model cannot know what the last holder got wrong |

---

# PART 31 — PRIVACY & DATA IN THE LEADERSHIP SYSTEM

## 31.1 The governing instruments

**[S-A: A-17]** classification **C1–C4**, retention **P2**, plain-language notice **P3** (English or any Eighth Schedule language), breach response **P5**. **[S-A: A-18]** four-branch necessity test. **[S-A: A-19]** eight-function access matrix — a contributor's record is not a beneficiary's record. **[S-A: A-20]** sealed categories (conduct, safeguarding, incident) at C4, case-scoped, **two-person rule**; §19.5 prohibited uses including commercial; §19.7 subject rights. **[S: Const. Art.6]** subject rights. **[S: Ch.23]** RBAC. **[S: Ch.33]** data retention `UNRESOLVED`. **[S-C: CR-1…CR-4]** — the record may never determine dignity, ordinary community access, worth, or eligibility for anything outside the organisation.

**[P] v1.3-D adds no new data estate.** Every field proposed in this document is either an existing **[S: Ch.22]** field, an aggregate, or a record about a **role** rather than a **person**.

## 31.2 Classification of leadership data

| Data | Class | Who may see it | Prohibited use |
|---|---|---|---|
| Role assignment, vacancy status, delegation record | **C2 internal** | Team and upward per RBAC | Public ranking |
| Team score, cohort position, confidence rating | **C2 internal** | Team, line, Performance, Audit | Public individual ranking; pay determination |
| **Gate R readiness finding about a named person** | **C2/C3** | HR, assessors, appointing authority, audit, **the person** | **Publication**; disclosure to the person's peers; use in any recognition instrument |
| LE-3 behavioural evidence, witness statements | **C3** | Assessor, HR, audit, the person | General disclosure; **a named witness statement is disclosed to the subject before any adverse use** |
| LLI band, `H_unrecorded`, burnout signals | **C3** | The person; aggregate to line | **Individual ranking; any assessment consequence (Rule D-76)** |
| Complaint content | **C4 sealed** | Case-scoped, two-person rule | Any aggregate that permits identification |
| Conduct, suspension, removal findings | **C4 sealed** | Panel, HR, audit; **the person** | Public disclosure beyond the outcome class required for safety |
| Safeguarding records | **C4 sealed** | **[S-C: SA-1…SA-7]**; designated roles only | Any leadership-assessment use without a safeguarding decision |
| Founder Recusal Register | **C2, aggregate published** | Audit; governance body; annual aggregate to all role-holders | Individual targeting |
| Relational memory (Rule D-97) | **C3, minimised** | Incoming holder; audit | Rule D-98 exclusions are absolute |
| Aggregate density, distribution and disparity reports | **C1 publishable** with suppression | Anyone | Re-identification |

## 31.3 Small-cell suppression

**[P] Rule D-108 (No Cell Of One).** No aggregate report, dashboard, cohort comparison or disparity analysis may publish any cell whose population is small enough that an individual could be identified. **The suppression threshold is [P] UNKNOWN — MEASURE IN PILOT**, and until it is set, the conservative rule applies: **cells below a stated minimum are merged upward or suppressed, and suppression is itself reported so that the reader knows what is missing.**

**[A]** This is not a technicality. **[I]** In a cohort of three mohalla teams, a published "bottom team" is three named people in one neighbourhood, and the publication is a social fact about them that no appeal can undo.

## 31.4 The prohibitions, restated as privacy rules

| Prohibition | Rule |
|---|---|
| **No universal human score** | Rule D-63; **[S-C: §23.2]** — "a person is never scored" |
| **No merging of public recognition, internal performance, confidential conduct, financial and safeguarding records into one score** | Rule D-49 (review type separation); §31.2 classification |
| **No social credit system** | **[S-C: CR-1…CR-4]**; Rule D-109 below |
| **No inference of protected characteristics** | AI-5; Rule D-79 aggregate-only |
| **No sale, sharing or third-party profiling** | **[S-A: A-20 §19.5; S-C: CR-4; S-B: NM-4, NM-11]** |
| **No sensitive personal information exposed publicly** | Rule D-67(6); §31.2 |
| **No retention beyond purpose** | **[S-A: A-17 P2]**; **[S: Ch.33 UNRESOLVED]** carried to Part 45 |

**[P] Rule D-109 (No Social Credit System — The Operational Test).** The contribution record, the credential, the score and the leadership record are **not** a social credit system if and only if all of the following hold:
1. They are **never used outside the organisation** — no sale, no sharing, no inference, no third-party eligibility **[S-C: CR-4]**.
2. They **never determine access to ordinary community life** — the commons is not a reward **[S-C: CR-2]**.
3. They **never determine how a person is treated in a need assessment** — urgency, vulnerability, resources, expected impact, safety risk and feasibility only **[S: Ch.8 step 5; S-C: CR-1]**.
4. They **never determine worth, in any internal or public statement** **[S-C: CR-3; §8.4]**.
5. They are **correctable, appealable and erasable** per **[S-A: A-17/A-20]** and **[S: Const. Art.6]**.
6. They contain **no behavioural surveillance** — they record acts of work and acts of authority, not conduct of life (§29.6 prohibition).

**[A]** Condition 6 is the one that will be hardest to hold, because every control in this document creates a record, and records accumulate. **The test of a record is not whether it is accurate; it is whether a stranger reading it would learn something about the person that the person would not expect an employer-like body to know.** Where the answer is yes, the record is surveillance regardless of its purpose.

## 31.5 Breach and subject rights, applied

**[X]** DPDP Act 2023 and Rules 2025: breach notification to the Data Protection Board **without delay**, with a detailed report within **72 hours**, and notification to affected data principals; **no materiality threshold**; CERT-In separately requires incident reporting within **6 hours**; grievances addressed within **90 days**; **Significant Data Fiduciary** obligations include an India-based Data Protection Officer, a Data Protection Impact Assessment, an independent data auditor, and annual assessment with significant gaps reported to the Board; security safeguards including encryption, masking, access controls, monitoring and backups; penalties up to ₹200 crore for failure to notify and roughly ₹250 crore for inadequate safeguards. **[V] REQUIRES PROFESSIONAL LEGAL VALIDATION — these are external facts, not Sewak Sathi policy, and their application depends on the entity structure, which is [S: Ch.33] UNRESOLVED.**

**[P]** Leadership-system consequences:
- **A leadership transition is a breach-risk event.** TA-c, TA-e, TA-f and SEC-9 exist for this reason and are recorded as safeguards.
- **A complaint under CR-4 concerning privacy has a statutory-shaped timeframe**; **[S-A: A-17 P5]** and **[S-A: SOP-22]** govern.
- **Significant Data Fiduciary status, if it ever applies, would require an independent data auditor** — which is compatible with **[S: Ch.23]**'s review-only Auditor and with Part 37's independent review, and should be satisfied by the same function rather than by creating a second one (Rule D-40).

---

# PART 32 — MULTI-LEVEL LEADERSHIP

## 32.1 The four levels, as sourced

**[S: Ch.4]** — Mohalla → City → State → National. **[S: Ch.5]** National; **[S: Ch.6]** State; **[S: Ch.7]** City; **[S: Ch.8]** Mohalla, with a ten-step operating loop and a role/evidence table. **[S: Ch.10]** — a full four-level role catalogue with a Succession column at every level. **[S: Const. Art.15, APPROVED]** — "Best Mohalla Team can become City Head Team; best City Head Team can become State Head Team; best State Head Team can receive National Team opportunity. Safeguards require approval."

**[A]** Article 15 is the source of the entire promotion architecture — and of its central defect, which Part 10 §10.1 and Part 7 address: **it describes the movement of teams, and the organisation is composed of people.** A "best Mohalla Team" that becomes a City Head Team has either (i) moved its people up and left the mohalla without a team, or (ii) left its people in place and moved only its label. **Neither is what the Article intends, and the Article does not say which.** This is carried as **[U] UNRESOLVED** and is addressed by Rule D-17 and the LG-series, not by reinterpreting the Article.

## 32.2 What changes at each level

**[P]** Not a restatement of **[S: Ch.5–8]**, but the **leadership-system differences** — because a capability model that is identical at all four levels is either too vague at the top or too heavy at the bottom.

| Dimension | Mohalla | City | State | National |
|---|---|---|---|---|
| **Primary object of leadership** | People and delivery, directly observed | Teams and their leaders, indirectly observed | Cities and standards | The institution and its constitution |
| **Dominant evidence class** | **LE-2** verified task evidence; **LE-3** behavioural | **LE-1** decision records; **LE-4** trust across units | **LE-1**, **LE-4**, **LE-5** reflection | **LE-1**, **LE-5**, institutional outcomes |
| **Dominant capability** | LC-1 delivery judgement; LC-4 fairness in allocation; LC-7 honest reporting | LC-9 decision quality at distance; LC-13 developing leaders; LC-17 resource routing | LC-11 boundary-keeping against external pressure; LC-16 building capability that outlives | LC-10 constitutional custody; LC-14 institutional honesty; LC-20 survivability |
| **Failure consequence radius** | One mohalla | `K` teams | Several cities | The institution |
| **Assessment independence achievable?** | **No — requires City or above (Rule D-45)** | Yes, out-of-city | Yes, out-of-state | **Only by an external or constitutional body** **[U]** — CEO vs National Council is UNRESOLVED |
| **Succession obligation** | SS-4 for Team Leader (§11.3) | SS-4 + SS-5 for City roles | SS-4 + SS-5, exercised | **SS-5 mandatory, exercised annually** **[S-A: A-14 §13.8]** |
| **Span character** | Small, direct | Multiplicative | Structural | Fixed and non-delegable in reserved matters |
| **Public face** | The team | Authorised spokespersons by domain and region **[S-A: A-16 §15.4]** | As City | **The institution, not a person** (PR-1, PR-6) |
| **Compensation character** | Worker-first, leadership work itemised (Rule D-69) | Same framework, higher allocation bounded **[S: App. A §15.3]** | Same | **Reserved-matter territory; UNRESOLVED** |
| **What may never be delegated** | Verification of one's own work; safety stop-work | Gate R assessment of one's own successor candidate | Standards for one's own assessment | Reserved matters **[S-A: A-14 §13.3]** |

## 32.3 The scale transition

**[A]** **[S-ST: §23.1]** stage model: **Leadership is ○ (absent) at S0, ◐ (partial) at S1–S2, and ● (required) from S3.** **[S-ST: §23.2]** twenty-function table — only **Safety** and **Finance** must be ● early; the S1 constraint is "trained leaders + 3 control-role holders per team".

**[P]** The leadership-system obligations by stage, applying **Rule D-80 (tiered obligation)**:

| Stage | What the leadership system must operate | What is deferred | Trigger for the next stage |
|---|---|---|---|
| **S0 — one team, pre-pilot** | Rule D-33 four capabilities; **[S-B: §40]** pilot process; M1 decision record; honest reporting | Everything with an assessment independence requirement — **there is no outside** | Pilot measurement (Part 41) |
| **S1 — first teams** | Gate E; RV-1; SS states recorded; playbook core PB-1…PB-6; LLI bands; City routing identified | Gate R out-of-team assessment **where no outside assessor exists — recorded as a known gap, not concealed**; RV-3; LDI mitigation planning | Trained leaders + 3 control-role holders per team **[S-ST: §23.1]** |
| **S2 — a city forming** | Gate R with out-of-team assessor; RV-3; full KT pack; F-360a/b/c; disparity testing AI-7; Founder Recusal Register | State-level instruments | Measured City divisor `H_gov_per_team(K)` (Rule D-91) |
| **S3 — multiple cities** | Full GF register; SP-3…SP-6 specialist path; annual continuity test **[S-A: A-14 §13.8]**; four annual tests published (Rule D-94) | National constitutional instruments | State structure decision |
| **S4 — a state** | State assessment independence; cross-state succession; standards ownership (SP-6) | — | National formation |
| **S5 — national** | Reserved matters custody; apex continuity exercised annually; institutional memory complete | — | **[U]** — CEO vs National Council must be resolved **by the source hierarchy, not by this document** |

**[P] Rule D-110 (A Deferred Control Is A Recorded Risk).** Every control deferred under Rule D-80 is recorded in the risk register (Part 43) with its stage, its reason, and the harm it leaves unprevented. **Deferral without recording is how a temporary compromise becomes permanent architecture.**

## 32.4 Cross-level leadership failure modes

| Mode | Mechanism | Control |
|---|---|---|
| **ML-1 Level confusion** | A City leader manages a mohalla team directly, bypassing its Team Leader | Rule D-41 no shadow authority; RBAC **[S: Ch.23]** |
| **ML-2 Escalation dumping** | Every hard decision moves up, so the upper level decides and the lower level learns nothing | **PB-4 refusals and PB-5 escalations** define what *must* escalate; everything else stays |
| **ML-3 Standard drift** | Each city adapts standards until they are not comparable | M2 versioned library; **ADAPT-series (Part 51)** defines what may adapt |
| **ML-4 Promotion extraction** | Upper levels take the best people from lower levels repeatedly | **Rule D-17; XG-8; [S-B: B-18(4)]** promotion-cohort reporting; LG-series |
| **ML-5 Reporting theatre** | Each level produces reports for the level above, consuming the delivery time the report describes | **[S: Ch.24]** six dashboards × five cadences is the ceiling; Rule D-65 measurement retirement |
| **ML-6 Distance blindness** | A leader who has never done the work assesses those who do | **[S-ST: M10]** field immersion; Rule D-51 skip-level includes downward contact |
| **ML-7 Authority inversion** | A specialist at City level outranks a Team Leader at Mohalla in practice | **Rule D-35 no track superiority**; SP-series authority ceilings; "advises, never commands" |
| **ML-8 National abstraction** | National leadership becomes governance of documents rather than of service | **PR-4; the four annual tests**; National role-holders must have held a delivery role — recorded, not assumed |

---

# PART 33 — SELECTION METHODS & DEMOCRACY VS EFFICIENCY

## 33.1 Five different acts, routinely confused

**[A]** The brief requires these to be distinguished. **[P]** They are different acts with different authorities, different evidence and different reversibility. **Conflating them is how an organisation ends up believing it promoted someone when it actually only thanked them.**

| Act | Definition | Authority | Evidence required | Reversible? | Source |
|---|---|---|---|---|---|
| **RECOGNITION** | Acknowledging a contribution | Anyone, to anyone; the organisation for proof and credential | A record of the contribution | Trivially — it confers nothing (Rule D-66) | **[S-C: §23.1 instruments 1–3]** |
| **DELEGATION** | Granting a bounded authority inside an existing role | The role-holder who holds the authority, recorded | Scope, limits, dates, reason, reviewer | **Yes — automatic expiry** | **[S: Ch.10, Ch.22]** |
| **APPOINTMENT** | Filling a specific vacant role | The appointing authority for that role | Gate E; role criteria | Yes, via RV-2 and CR-3 | **[S: Ch.11; App. E]** |
| **SUCCESSION** | Ensuring a role can be filled without interruption | The role-holder, with line and HR | SS-4/SS-5 state; Gate R on the successor | N/A — it is a state, not an event | **[S: Ch.9, Ch.22, Ch.26]**; Part 11 |
| **PROMOTION** | Movement to a role of greater scope at a higher level | Appointing authority + LG-series gates + promotion decision | Gate E + Gate R + PG gates + team readiness | **Partially — Rule D-26 downward movement exists, and is rare** | **[S: Const. Art.15; Ch.26]**; Part 10 |

**[P] Rule D-111 (Act Typing Is Recorded).** Every leadership act is recorded with its type. **An act recorded without a type is treated as the least consequential type it could be** — recognition, not delegation; delegation, not appointment. **[A]** Reason: ambiguity about which act occurred is always resolved in favour of the person exercising power, unless the record forces the opposite.

## 33.2 The selection methods available, and their fitness

| Method | Where the source uses it | Fitness for this architecture | Failure mode |
|---|---|---|---|
| **Eligibility engine on recorded criteria** | **[S: Ch.11]** vacancy lifecycle | **High** — auditable, appealable, non-arbitrary | Reduces to Gate E only; says nothing about readiness |
| **Evidence review** | **[S: Ch.26]** safeguard | **High** | Requires verification capacity (PL-1 bottleneck) |
| **Appointing authority decision** | **[S: App. E]** | **High for speed; medium for legitimacy** | Favouritism — AF-series |
| **Tie-break sequence** | **[S: Ch.26]** | **Necessary** | Becomes the real decision rule if the primary criteria are vague |
| **Lottery among qualified** | Not in source; **[P]** Part 10 §10.7 `L_pos/K` | **Appropriate only where candidates are indistinguishable on admissible evidence** | Perceived as absurd unless the equivalence is real and shown |
| **Election by the team** | Not in source for leadership; **[S-C: §8.2]** L5 "votes nothing" | **Low for leadership; high for legitimacy of specific questions** | Popularity substitution — the exact prohibition |
| **Election by the level above** | Implied by **[S: Const. Art.15]** | **Medium** | Distance blindness (ML-6); extraction (ML-4) |
| **Co-option by the incumbent** | Not permitted | **Prohibited** | Self-replication; GF-23 |
| **Seniority queue** | Not in source | **Prohibited** — D-5 | Tenure ≠ capability |
| **Competitive application** | **[S: Ch.11 step 9]** reapplication permitted | **High, if OB-1…OB-7 are removed** | Access exclusion |
| **Structured scenario assessment** | **[P]** DV-4 | **High** — the only method that observes judgement directly | Cost; requires an out-of-team assessor |

## 33.3 Democracy vs efficiency

**[A]** The brief asks whether the system is democratic or efficient, and the honest answer is that **the source has already chosen, and the choice is neither.**

**[S: Ch.11]** selects by **eligibility and evidence**, not by vote. **[S: App. E]** assigns appointment authority to **roles**, not to constituencies. **[S: Const. Art.15]** moves teams up by being **best**, not by being elected. **[S-C: §8.2]** gives a Verified Member with no role the right to hold membership, take tasks and be paid — and **"votes nothing, manages nobody"**. **[A]** The source's model is therefore **meritocratic-delegative with accountability instruments**, not democratic. **v1.3-D does not change this; Rule 3 forbids it.**

**[P]** What the source's model lacks, and what v1.3-D supplies instead of elections:

| Democratic function | Electoral mechanism (not adopted) | Substitute adopted here |
|---|---|---|
| **Consent of the governed** | Vote on the leader | **Rule D-23** legitimate grounds to refuse a promotion; **[S-C: H-17]** seven refusal rights; **the team's standing to appeal a gate failure (§18.3)** |
| **Accountability** | Vote out | **RV-3; RV-4 conduct route; CR-3/CR-4 complaints; Rule D-26 downward movement; Rule D-60 no automatic removal** |
| **Voice** | Campaign | **M3 change-request route — any member may propose a change, reasons recorded, inspectable by any member [S-A: A-15]**; **M10 Integrity Line, ombuds, skip-level [S-ST]**; **dissent route [S-A: A-16 test 3]** |
| **Information symmetry** | Public debate | **Rule D-94** four test counts published internally; **Rule D-67** public recognition rules; **§31.2** subject access to own records |
| **Contestability** | Competing candidates | **§25.3** internal application with a feedback obligation; **Part 10 §10.4** tie-breaks with prohibited tie-breaks |
| **Legitimacy of standards** | Ratification | **M2/M3** versioned standards with a change route open to any member |
| **Protection of the minority** | Constitutional limits | **Reserved matters [S-A: A-14 §13.3]**; **Constitution Arts. 1–19**; **INV-series (Part 51)** |

**[P] Rule D-112 (Democracy Of Voice, Not Of Selection).** Members have **strong voice rights and weak selection rights**, deliberately. **[A]** Justification: selection by vote in a small community selects for popularity, which is the substitution the brief prohibits absolutely; voice by route is cheap, safe and does not have that property. **The efficiency cost of this choice is real and is recorded: leaders selected by evidence rather than by vote have less initial legitimacy, and must earn it in office.** That earning is what RV-3, the appeals route and the four annual tests are for.

## 33.4 The efficiency account

| Efficiency question | Answer |
|---|---|
| Is evidence-based selection slower than appointment? | **Yes.** Gate R requires LE-3, which requires time |
| Is it slower than election? | **Sometimes faster** — no campaign period, no contested result, no runoff |
| What does it cost? | `H_gov`: assessment, review, appeal handling, record-keeping. Bounded by `σ_max` and tiered by Rule D-80 |
| What does it buy? | **A decision that can be explained to the person it went against.** That is the whole purchase. An unexplainable selection produces either silence or exit, and **[S-ST: F-24]** prices exit |
| When should speed override process? | **TL-3 emergency only**, with automatic expiry, non-conversion (Rule D-32) and mandatory post-crisis review |
| When should process override speed? | **Always for reserved matters, for removal, and for any decision that changes a person's pay or standing** |

---

# PART 34 — GOVERNANCE BODIES & DECISION AUTHORITY

## 34.1 The authority map — with the unresolved marked

**[A]** The brief requires an authority map and instructs: **mark UNRESOLVED — DO NOT INVENT.** The following map reproduces **[S: App. E]**'s Approval & Delegation Matrix and **[S: Ch.23]**'s RBAC, and marks every point the source hierarchy has not decided.

| Decision | Authority | Source | Status |
|---|---|---|---|
| Role promotion / appointment | **Team Leader + HR**, with City/State owner co-review | **[S: App. E]** | **APPROVED process; leadership transition rules `NOT FINAL` [S: Ch.33]** |
| Suspension | **HR / Safety / Leader** | **[S: App. E]** | APPROVED |
| Serious-misconduct removal | **Governance / HR panel** | **[S: App. E]** | Procedure `PROPOSED` **[S: Ch.33]** |
| Leaderboard finalisation | **Performance / Audit**; escalate on tie, anomaly or leadership transfer | **[S: App. E]** | Weights `PROPOSED`; finalisation process APPROVED |
| **Leadership transfer** | **CEO / governance process** | **[S: App. E]** | **`NOT FINAL` [S: Ch.33]** |
| Platform permission change | **Technology admin** | **[S: App. E]** | APPROVED |
| Constitutional / Tier-1 amendment | Reserved matter | **[S-A: A-14 §13.3]** | Reserved — **not delegable to any interim holder** |
| Mission, name, brand, entity structure change | Reserved matter | **[S-A: A-14 §13.3]** | Reserved |
| Asset, reserve or social-impact fund transfer or encumbrance | Reserved matter | **[S-A: A-14 §13.3]** | Reserved |
| Dissolution, merger, restructuring | Reserved matter | **[S-A: A-14 §13.3]** | Reserved |
| **Appointment of a permanent CEO** | Reserved matter | **[S-A: A-14 §13.3]** | Reserved |
| A-08 DO-NOT list change | Reserved matter | **[S-A: A-14 §13.3]** | Reserved |
| Waterfall priority-order change | Reserved matter | **[S-A: A-14 §13.3]** | Reserved |
| Apex selection | **[S-A: A-14 §13.5]** | **[S-A]** | Specified; **the person is never named here** |
| Audit review | **Auditor — review only; not operational commander** | **[S: Ch.23]** | APPROVED |
| **CEO vs National Council authority** | — | **[S: Ch.33; Ch.4]** | **`UNRESOLVED` — DO NOT INVENT** |
| **National Council charter (N19)** | — | **[S-A: A-23]** | **`PROPOSED — REQUIRES FINAL APPROVAL`** |
| **Legal structure under Krytos** | — | **[S: Ch.33]** | **`UNRESOLVED`** |
| **Who holds the reserved matters in practice** | Depends on the two rows above | — | **`UNRESOLVED` — the single largest governance gap in the architecture** |

**[A]** The last row is the finding. **[I]** Seven reserved matters exist and are well specified. **The body that holds them is not determined**, because CEO-vs-Council is unresolved and the legal structure is unresolved. **A reserved matter that nobody can decide is not protected; it is frozen.** In a crisis requiring one of the seven, the organisation would face either paralysis or an unlawful act.

**[P] Rule D-113 (Interim Reserved-Matter Procedure).** Until the source hierarchy resolves CEO-vs-Council: (i) no reserved matter may be decided by a single person; (ii) any reserved matter requiring decision is recorded, with the reason urgency cannot wait; (iii) the decision requires **the concurrence of at least two independent bodies or roles that already exist** — CEO and Audit, or Governance panel and HR, as the matter's class indicates; (iv) the decision is **provisional**, reported to the body that will eventually hold the authority, and reversible; (v) **the Founder Recusal Register records the founder's role, if any.** **[A]** This rule does not resolve the UNRESOLVED item. It prevents the unresolved item from becoming an emergency in which someone resolves it unilaterally.

## 34.2 RACI for the leadership lifecycle

**[P]** R = responsible, A = accountable (one only), C = consulted, I = informed.

| Activity | Team Leader | HR / Verification | Performance | Audit | Safety | Funds | City owner | Governance panel | CEO / apex |
|---|---|---|---|---|---|---|---|---|---|
| Declare a vacancy | R | C | I | I | I | I | A | I | I |
| Publish the vacancy (OB-6) | R | A | I | I | — | — | C | — | — |
| Screen Gate E | C | R/A | C | I | — | — | I | — | — |
| Assess Gate R | C | R | C | C | C | — | **A** | I | — |
| Apply PG gates | C | C | R | C | C | C | **A** | — | — |
| Decide appointment | R | C | C | I | — | — | **A** | I | I |
| Record the promotion decision (§10.8) | R | R | C | **A** | — | — | C | I | I |
| Execute transition access (TA-a…TA-h) | R | C | — | **A** | C | C | I | — | I |
| Conduct RV-1 | C | C | **R/A** | C | — | — | I | — | — |
| Conduct RV-2 | R | C | I | C | — | — | **A** | I | — |
| Conduct RV-3 | — | R | C | C | C | — | **A** | I | — |
| Conduct RV-4 | C | R | — | C | C | — | C | **A** | I |
| Hear an appeal | — | C | C | **R** | — | — | C | **A** | I |
| Decide a reserved matter | — | — | — | C | — | — | — | C | **A** (Rule D-113) |
| Publish the four annual test counts | — | R | R | **A** | — | — | C | C | I |

**[A]** Two properties of this RACI are deliberate. **First, the Team Leader is never A for a decision about their own successor's readiness** — the City owner is. **Second, Audit is A for the decision record and for appeals**, because Audit is review-only **[S: Ch.23]** and therefore structurally unable to benefit from the outcome.

## 34.3 The succession authority matrix

**[P]** Who may do what, by succession state:

| Act | SS-0/SS-1 | SS-2 identified | SS-3 nominated | SS-4 ready | SS-5 exercised |
|---|---|---|---|---|---|
| Name a successor | Role-holder + HR | — | — | — | — |
| Delegate authority to the successor (TL-4) | **Prohibited** | Permitted, narrow | Permitted, widening | Permitted, substantial | Permitted, full dry-run |
| Assess the successor's Gate R | **Out-of-team only, at every state** | Same | Same | Same | Same |
| Appoint the successor on a vacancy | **Not possible — nobody is ready; TL-2 interim + City cover** | Not possible | Conditional, with support | Yes | Yes |
| Permit the unit to expand (XG-2) | **No** | No | No | Yes | Yes |
| Permit the role-holder's promotion (LG-series) | **No** | No | Conditional | Yes | Yes |
| Record an LDI mitigation plan | **Mandatory** | Mandatory | Mandatory | Satisfied by the successor | Satisfied |

## 34.4 Bodies — created only where Rule D-40 is satisfied

| Body | Decision it makes | Who would otherwise make it | If abolished | Verdict |
|---|---|---|---|---|
| **Governance / HR panel** | Serious-misconduct removal | A single leader | One person could remove another — unacceptable | **Retained** **[S: App. E]** |
| **Performance / Audit finalisation** | Score finalisation and escalation | The team's own line | The measured would finalise the measurement | **Retained** **[S: App. E]** |
| **Appeal body (out-of-line)** | CR-2 appeals | The original decision-maker | No appeal in substance | **Retained** |
| **Integrity Line / ombuds** | CR-4 intake and route | The operational line | A complaint against the line goes to the line | **Retained** **[S-ST: M10]** |
| **Assessment panel (out-of-team)** | Gate R | The candidate's own leader | Popularity capture | **Retained** (Rule D-45) |
| **National Council** | **[U]** | **[U]** | **[U]** | **Not created here — UNRESOLVED, carried to Part 45** |
| **Leadership development committee** | Would "oversee development" | RV-3 reviewer + trainer cadre | Nothing — development is a line duty | **NOT CREATED** |
| **Succession committee** | Would "oversee succession" | Role-holder + HR + City owner | Nothing — succession is already a role duty **[S: Ch.9]** | **NOT CREATED** |
| **Recognition committee** | Would decide recognition | Anyone may appreciate; the organisation issues proof and credential from records | Nothing | **NOT CREATED** — a committee would ration what Rule D-66 makes free |
| **Ethics board** | Would decide ethics | Conduct route CR-3/CR-4; conflict declarations Part 35 | Nothing | **NOT CREATED** |

**[A]** Five bodies retained, five refused, one left unresolved. **The refusals are the substance of this section.** An organisation that creates a committee for every value it holds ends up with committees instead of values.

---

# PART 35 — ETHICS, CONFLICT OF INTEREST & ANTI-FAVOURITISM

## 35.1 The source's ethical floor

**[S: Ch.9]** — every role family has explicit **"Cannot do"** boundaries; the Team Leader "cannot bypass verification, spend outside limits, hide incidents, punish people or change pay rules". **[S: Const. Art.8]** — conduct warning→removal. **[S: Const. Art.2]** — "serve without expecting reward". **[S: Ch.25]** — the raw-count prohibition. **[S: Ch.26]** — "Opportunity is not an automatic personal entitlement"; high score void on fraud, safety breach or manipulation. **[S: App. A §16.3]** — seven autonomy boundaries including "report results honestly, including failures". **[S-A: A-08]** — the protection DO-NOT list. **[S-C: AC-1…AC-11, CK-1…CK-7]** — anti-coercion and consent.

**[A]** The source's ethics are **boundary-based, not virtue-based**: they say what a role may not do, and they do not attempt to make people good. **[P]** v1.3-D maintains that character. **A virtue-based ethics clause is unenforceable and, worse, is usable — "not committed enough" is a virtue judgement, and virtue judgements are how favouritism is expressed.**

## 35.2 Conflict of interest — the operating architecture

| Element | Design |
|---|---|
| **Duty to declare** | Every person participating in a Gate E screen, Gate R assessment, appointment, promotion, gate application, complaint, appeal, review, certification or payment decision declares: relationships (family, household, close friendship, enmity), financial interests, prior advocacy for or against a candidate, and any interest in the outcome |
| **When** | **Before** participation, not after; and **on discovery**, immediately |
| **Form** | A recorded declaration attached to the decision record (M1) |
| **Effect** | **Recusal** on the specific matter — TL-4 delegation to another person for that matter (Part 12 §12.2 case 11). **Not** removal from the role |
| **Where no recusal is possible** | The matter moves up or out a level — the same resolution as Rule D-50 and Rule D-103 |
| **Register** | Declarations retained; aggregate patterns reported (e.g. one assessor recusing repeatedly for the same candidate is a signal about the assessor **or** about the candidate, and either is worth knowing) |
| **Undeclared conflict discovered later** | Ground (iv) for appeal (§18.3); a conduct matter under CR-3 where deliberate |

**[P] Rule D-114 (Recusal Is Not Suspicion).** A declaration is a normal administrative act. **A person who declares is not thereby suspected of anything, and the declaration may not be used adversely against them.** **[A]** Without this rule, declarations stop happening — which is the universal failure of conflict-of-interest systems.

**[P] Rule D-115 (The Founder Declares Too).** Rule D-92's Founder Recusal Register and Rule D-93's assessment prohibition are the founder-specific forms of this architecture. **The founder's preference about a named candidate is a declarable interest and is recorded.**

## 35.3 Anti-favouritism — the twelve controls, operationalised

**[A]** Part 3 §3.7 specified **AF-1…AF-12** as admissibility controls on evidence. **[P]** Here they are given their operating mechanisms:

| Control family | Mechanism | Detection of failure |
|---|---|---|
| **Evidence admissibility** | Prohibited evidence list (Part 5 §5.4): tenure, popularity, loyalty, family, locality, religion, politics, caste, prior standing, self-assessment alone | A decision record citing prohibited evidence is defective on its face and appealable |
| **Assessor independence** | Rule D-45 out-of-team; Rule D-50 reviewer independence; Rule D-93 founder recusal | Pattern audit: one assessor's outcomes diverging systematically from cohort |
| **Reason requirement** | Rule D-54: no judgement without a specific, dated, observable event | Reasons absent or generic → procedurally defective |
| **Two-signal rule** | Rule D-64 | A single-method decision is void |
| **Publication of criteria** | AX-1; Gate E/R criteria published before application | Criteria changed after applications received → void |
| **Feedback obligation** | §25.3: specific, evidence-linked reasons to every non-selected applicant | Non-selection without a reason → governance finding |
| **Application access** | OB-1…OB-7 | Applicant pool composition vs unit composition, aggregate, suppressed |
| **Delegation transparency** | Every TL-4 recorded with scope, limits, dates, reason, reviewer | Delegations concentrated on one person → signal |
| **Recognition neutrality** | Rule D-66; absolute instruments only | Recognition correlated with proximity to a leader rather than with contribution records |
| **Rotation for control functions** | Verifier rotation **[S-ST: F-26(7) ii]**; assessor rotation | Long-standing assessor–unit pairs |
| **Skip-level and Integrity Line** | Rule D-51; **[S-ST: M10]** | Divergence between line reports and skip-level reports |
| **Appeal pattern detection** | §18.3: repeated successful appeals against one decision-maker escalate | The escalation itself |

## 35.4 The favouritism that cannot be controlled

**[A]** Stated without softening, because the brief requires it:

**[I]** Every control above detects favouritism that leaves a record. **The favouritism that does not leave a record is the allocation of opportunity itself** — who is asked to take on the visible project, who is mentioned in a meeting, who is introduced to the City coordinator, who is given the task that generates LE-2 evidence. **None of these is a decision; all of them determine who later has evidence.**

**[P] Rule D-116 (Opportunity Allocation Is Recorded).** Allocation of **evidence-generating opportunities** — visible projects, cross-unit assignments, training places, delegated authority, external representation — is recorded at team level with the reason, and reported in aggregate per team with small-cell suppression. **[A]** This does not prevent favouritism in allocation. **It makes the pattern visible to the team itself**, which is the only actor with enough local knowledge to know whether the pattern is fair. **The correction is social, not procedural — and that is an honest statement of the limit of procedural design.**

**[P] Rule D-117 (The Unpopular Competent Person Has A Route).** Because the ES.5 weakness cannot be closed procedurally, it is closed by **four independent affordances**, all of which must exist for the route to be real:
1. **An out-of-team assessor** who is not in the candidate's social field (Rule D-45).
2. **A blind portfolio review** — LE-2 and LE-1 evidence assessed with identity and locality redacted where the evidence permits it (Part 5 §5.6).
3. **A structured scenario** (DV-4) that observes judgement directly rather than through reputation.
4. **A recorded, appealable reason** for any adverse decision, plus a **dissent route** for any assessor who disagrees with the panel (§18.3; **[S-A: A-16 test 3]**).

**[A]** Where **all four** exist, an unpopular competent person can be selected. **Where any one is missing, they cannot — and the organisation will not notice, because the people it selects will be competent-looking and popular, and the people it never sees will not be there to complain.** This is the single biggest unresolved weakness named at ES.5, and Rule D-117 is its minimum architectural correction. **Whether it works in practice is `EMPIRICALLY UNVALIDATED`.**

---

# PART 36 — ANTI-PERSONALITY-CULT & ANTI-CAPTURE

## 36.1 The four capture vectors

**[A]** A service organisation with a hierarchical structure, a charismatic founder, money flows, local presence and community trust is attractive to four kinds of captor. Each is addressed with a structural control, not a statement of values.

| Vector | What the captor wants | Entry point | Primary control |
|---|---|---|---|
| **Personality cult** | Devotion to a person, which converts into unaccountability | Recognition, symbolism, public identity, the founder's image | §36.2 |
| **MLM / recruitment pyramid** | Income from downline growth | Compensation design, recognition of recruitment, team-formation incentives | §36.3 |
| **Vigilante capture** | Coercive authority over a neighbourhood | The Protection pillar; local legitimacy; grievance against outsiders | **[S-A: A-08]** DO-NOT list; §36.4 |
| **Political capture** | An organisational machine for electoral or party purposes | Local leaders' political ambitions; funding; 12A restrictions | §36.5 |

## 36.2 Anti-personality-cult

**[S-C: §45]** — the local-hero problem and four charismatic-leader guards. **[S-A: A-16 §15.4]** — public-representation rules. **[S-C: §8.4]** — "no instrument may describe leadership as a higher form of service." **[S-C: SR-2]** — no ordinal numbering. **[S-C: §6.10]** — Elder standing is recognised, not ranked.

**[P] Amendment L-19 — Cult Resistance Controls.**

| # | Control | Mechanism | Test |
|---|---|---|---|
| **CU-1** | **No person is the organisation's identity** | PR-1, PR-6: statements in the organisation's name; many authorised spokespersons by domain and region | Count distinct public spokespersons over a year. **One is a failure** |
| **CU-2** | **No loyalty object** | §21.7: oaths, pledges, insignia of rank and titles rejected; a role acceptance is a record | Search all instruments for any vow-like language. **Any found is removed** |
| **CU-3** | **Attribution discipline** | PR-2: no achievement attributed solely to a leader where a team produced it; **T2 attribution test** counts role-attributed decisions | Annual test count (Rule D-94). **A low count is the warning** |
| **CU-4** | **Dissent is safe and counted** | **T3 dissent test**; **[S-A: A-16 test 3]**; Integrity Line; Rule D-57 appeal is not retaliation evidence | **Zero dissents is a warning sign, not harmony** **[S-A: A-16]** |
| **CU-5** | **The leader is replaceable and says so** | Rule D-62: indispensability is a performance defect; T4 successor test | LDI critical band with no mitigation across cycles |
| **CU-6** | **Recognition is absolute** | Rule D-66; **[S-C: §44.3]**; no ordinal position anywhere public | Any published ranking of a person is a breach |
| **CU-7** | **The founder is bound** | Rule D-92 register; Rule D-93 assessment prohibition; Rule D-115 declaration | Register exists, is audited, and is non-empty in a way that shows real constraint |
| **CU-8** | **No higher form of service** | **[S-C: §8.4]** absolute; the Contributor endpoint is complete **[S-C: §8.2]** | Any instrument implying hierarchy of worth is removed |
| **CU-9** | **Grief and exit are dignified** | Rule D-26 dignified exit; Rule D-27 return; **[S-C: H-17]** refusal rights | A departing member is not described as a loss of loyalty |
| **CU-10** | **Symbols belong to the work** | Imagery, ceremonies and language reference service and community, not persons | §21.7 test applied to every symbol |

**[A]** The honest limit: **CU-1…CU-10 constrain the organisation's instruments. They do not constrain a community's feelings.** **[I]** If a local leader becomes genuinely beloved, no rule prevents that, and attempting to prevent it would be both futile and cruel. **What the rules prevent is the conversion of affection into unaccountable authority** — and that conversion happens through instruments: recognition, attribution, symbolism, exemption from assessment. **Remove the instruments and the affection remains harmless.**

## 36.3 Anti-MLM

**[S-C: MLM-1…MLM-7]** preserved. **[P]** Applied to the leadership and compensation architecture specifically:

| Vector | Why the leadership system is exposed | Control |
|---|---|---|
| **Recruitment-linked reward** | A leader who benefits from headcount will recruit | **[S: Ch.25]**: volunteer count and application count cannot determine leadership. **No payment, recognition or promotion criterion may reference the number of people recruited** |
| **Downline-based advancement** | Team size becomes a promotion argument | Part 7's PG gates do not include team size; **[S: Ch.25]** prohibition; **the largest team is expressly listed in the brief as proving nothing** |
| **Multi-level commission** | A leader earning from subordinate earnings is a pyramid | Rule D-71: delivery paid separately; Rule D-69: leadership work itemised. **No instrument pays a person a share of another person's earnings** |
| **Entry fee or purchase requirement** | Membership or role requiring payment | **[S-C: AC-series]**; membership is free of purchase requirements |
| **Inventory or venture loading** | Pressure on members to buy into ventures | **[S-B: B-07]** venture approval gating; **[S-C: MLM-4]** |
| **Recruitment at vulnerability** | The service context creates moments of acute need | **[S-C: H-03]** absolute prohibition; AF-series excludes need-status from evidence |
| **Testimonial and income-claim culture** | Success stories that imply earnings | PR-2, PR-4; **no income claim may be published**; **[S-C: MLM-6]** |

**[P] Rule D-118 (No Compensation Depends On Another Person's Participation).** No payment, allocation, credential or promotion criterion may be a function of how many people a person has recruited, retained, managed or earned through. **[A]** This is the single test that separates a service organisation from a pyramid, and it is cheap to apply because it is a property of formulas, not of intentions.

## 36.4 Anti-vigilante

**[S-A: A-08]** — the protection DO-NOT list, reserved and not amendable by any interim holder. **[S: Ch.16]** Protection pillar. **[X]** BNSS 2023 s.40 permits a private person to arrest someone committing a non-bailable cognizable offence in their presence, with handover to police within six hours; s.31 binds every person to assist a Magistrate or police officer reasonably demanding aid; s.43 limits use of force. **[V] REQUIRES PROFESSIONAL LEGAL VALIDATION for every jurisdiction of operation.**

**[P]** Leadership-system controls:

| # | Control | Content |
|---|---|---|
| **VG-1** | **Stop-work and escalate, never enforce** | **[S: Ch.9]** role boundary; the STOP capability (Rule D-33) is a capability to halt, not to compel |
| **VG-2** | **Local authority is not legal authority** | A leader's standing in a mohalla confers no enforcement power. **Any instruction to detain, search, confiscate, interrogate or expel a person is outside every role's authority and is a conduct matter under CR-3** |
| **VG-3** | **The DO-NOT list binds at every level and is a reserved matter** | **[S-A: A-08; A-14 §13.3]** |
| **VG-4** | **Popular pressure is not a mandate** | A crowd's demand is recorded as a **community concern**, routed to the appropriate authority, and **never acted on directly**. **[A]** This is the specific mechanism by which a protection pillar becomes a vigilante one: the leader who is locally legitimate finds it impossible to refuse a locally popular demand |
| **VG-5** | **Any use-of-force or detention incident is an immediate CR-4 integrity matter** | Sealed category **[S-A: A-20]**; independent review; mandatory reporting where law requires **[V]** |
| **VG-6** | **No leader may hold protection authority without a completed legal-basis briefing** | **[S: Ch.12]** training; "internal training is not legally sufficient" **[S-C: §47.3]**; **[V]** |

## 36.5 Anti-political-capture

**[X]** Indian not-for-profit structures: **12A** income-tax exemption is conditional on applying at least 85% of income to charitable purposes **and on no political activity and no support to any party or candidate**, with cancellation risk; **80G** donor deduction; **FCRA** required for any foreign contribution, generally with a track-record requirement and a dedicated bank account. **[V] REQUIRES PROFESSIONAL LEGAL AND TAX VALIDATION — the entity structure is [S: Ch.33] UNRESOLVED, so the applicable regime is not determined here.**

**[P]** Controls, drafted to survive whichever structure is eventually chosen:

| # | Control | Content |
|---|---|---|
| **PC-1** | **The organisation takes no political position and supports no party or candidate** | Absolute; a reserved matter class |
| **PC-2** | **Members retain their civic rights** | **[S-A]** standing instruction: do not assume members lose civic rights. **A member may campaign, vote and hold party office in their personal capacity** |
| **PC-3** | **The two capacities are separated on the record** | Where a role-holder is politically active, they declare it (Part 35), and **no organisational resource, platform, list, record, symbol or event may be used for political purposes** |
| **PC-4** | **Recusal on matters affecting a political interest** | Part 35 architecture |
| **PC-5** | **No political test in any gate** | Part 3 §3.2's nine deliberately-absent criteria include political affiliation; AI-5 prohibits it as a model input |
| **PC-6** | **Funding-source transparency** | Donor and contribution records under **[S-A: A-17]**; **no foreign contribution without FCRA compliance [V]** |
| **PC-7** | **Local capture detection** | A unit whose leadership, beneficiary selection or resource allocation correlates systematically with a political pattern is an **audit matter**, detected by aggregate disparity testing (AI-7), never by individual profiling |
| **PC-8** | **The 85% application requirement is a financial-architecture constraint** | **[S: Ch.18]**'s waterfall — worker compensation first, reserves and social impact later — must be tested against any applicable application-of-income requirement. **[V] REQUIRES TAX VALIDATION; no numeric conclusion is drawn here** |

**[A]** The hardest case, stated honestly: **[I]** a mohalla leader with genuine local political influence is often the most effective person the organisation could have — they can get things done that no apolitical person can. **PC-2 protects their right to be that person. PC-3 protects the organisation from becoming their instrument.** The tension between those two is real, cannot be resolved by rule, and is therefore **recorded as an open question in Annexure J rather than papered over.**

---

# PART 37 — CRISIS LEADERSHIP, INCIDENT REVIEW & RESILIENCE

## 37.1 What crisis leadership is, in this architecture

**[A]** Not heroism. **[S: App. A §16.3]** already defines the boundary: autonomy is "earned freedom inside central standards", and one of the seven boundaries is "report results honestly, including failures". **[S-A: A-08]**'s DO-NOT list binds at every level, including during emergencies. **[S: Ch.16]** governs protection. **[S: Const. Art.12]** prohibits AI from making autonomous safety decisions.

**[P] Rule D-119 (Crisis Does Not Suspend Standards; It Suspends Procedure).** In a declared emergency: **the DO-NOT list, the waterfall priority order, the segregation of duties, the safeguarding obligations, the privacy classification and the duty to record all remain in force.** What may be suspended is **the ordinary sequence** — approval before action becomes action then immediate recorded approval. **[A]** This distinction is the whole of crisis governance. An organisation that suspends standards in a crisis will not recover them afterwards; an organisation that suspends sequence recovers by construction, because the sequence is written down.

## 37.2 Crisis decision-making

| Element | Design | Source |
|---|---|---|
| **Who decides** | The person holding **STOP** (Safety/Protection Lead) may act immediately; **DECIDE** under TL-3 where the leader is absent | **[S: App. E]** "High-risk/emergency support: Safety Lead may act immediately"; Rule D-33 |
| **On what information** | Best available, explicitly incomplete. **The record states what was not known** | **[P]** — an unstated gap becomes a reconstructed certainty later |
| **Recorded how** | M1 decision record, contemporaneous, with: the situation, the options considered, the option chosen, the reason, **the information missing**, and the expected consequence | **[S-A: A-15 M1]** |
| **Reserved matters** | **Never decidable in a crisis by any holder of temporary authority** | Rule D-30(3) |
| **Communication** | In the organisation's name, by an authorised spokesperson, honestly, including failure | PR-1, PR-4 |
| **Duration** | TL-3 expires automatically; renewal is a recorded decision of a higher authority | Rule D-30(2) |
| **Conversion** | Prohibited — emergency service is evidence, not entitlement | Rule D-32 |
| **Review** | Mandatory independent post-crisis review | §37.4 |

**[P] Rule D-120 (The Missing-Information Field).** No crisis decision record is complete without an explicit statement of what was not known at the time. **[A]** Reason: crisis decisions are judged afterwards by people who know the outcome. **Without a recorded statement of the information state, every reasonable crisis decision looks negligent in hindsight, and the organisation will learn to decide nothing.** This is hindsight bias operating as an institutional selection pressure against decisive leaders.

## 37.3 The incident and failure loop

**[S: Ch.14]** — nine-step, support-first, six failure types. **[P]** Preserved exactly, with the leadership-system reading:

| Failure type **[S: Ch.14]** | Response **[S: Ch.14]** | Leadership-system consequence |
|---|---|---|
| **Capacity** | Support, training, resources | LLI review; Rule D-59 support-failure finding |
| **Skill** | Training **[S: Ch.12]** | DV-1/DV-2 development plan |
| **Leadership** — "fear, favouritism, missed targets" | **Coaching + deputy → Replacement/dynamic succession** | **This is the source's own improvement-then-succession sequence, and it is the model Rule D-58 and IP-1…IP-7 implement** |
| **Team conflict** | Mediation | Elder/Mentor mediation **[S-C: §6.10]**; CR-3 where conduct is involved |
| **External / environment** | Adaptation, escalation | Cohort reassignment (CN-series); baseline rules (Rule D-19) |
| **System / process** | Process correction | **M3 change request; M5 lessons entry with the "did it work" column** |

**[P] Rule D-121 (Blameless By Default, Accountable By Record).** An incident review begins from the presumption that the people involved acted on the information they had. **Accountability attaches to the record, not to the person's character**: did the decision get recorded, was the standard known, was the support provided, was the escalation available. Where the answer to all four is yes and the outcome was still bad, **the finding is against the system** and is routed to M3. **[A]** This is not leniency. **It is the only review posture that produces honest incident reports, and honest incident reports are the only source of real safety learning.**

## 37.4 Independent post-crisis review

**[P]** Mandatory after every TL-3 period, every VG-5 event, every serious incident, and every continuity-test failure.

| Element | Design |
|---|---|
| **Reviewer** | Out-of-line; Audit is review-only **[S: Ch.23]** and therefore structurally suited; **where the matter concerns Audit, an external reviewer is required [V]** |
| **Scope** | The declaration's necessity; the acts performed; the reserved-matter boundary; the expiry and renewal; the handover back; the communications; the record quality |
| **Standard** | Was the authority **necessary, proportionate, recorded, time-bounded and returned** |
| **Output** | Findings, reasons, M5 lessons entry, M3 change requests where systemic, and a statement of **whether emergency authority persisted beyond the emergency** (SEC-7) |
| **Publication** | Internal, to all role-holders; **aggregate externally** where the matter affects the public |
| **Protection** | Participants in the review are protected by the non-retaliation rule (§18.2) |

## 37.5 Resilience

**[A]** Resilience is not a property of leaders. It is a property of **structures that continue when leaders fail.** Six structural sources:

| Source | Instrument | Test |
|---|---|---|
| **R-A Redundancy of capability** | Rule D-33 four capabilities; Rule D-34 tiered redundancy | Annual continuity exercise (§38.5) |
| **R-B Redundancy of knowledge** | Playbooks PB-1…PB-10; Rule D-96 tested not filed; Rule D-97 relational memory | Playbook exercise result |
| **R-C Redundancy of authority** | SS-4/SS-5; Interim Authority Order; TL-1…TL-5 with automatic expiry | **T4 successor test**; **[S-A: A-14 §13.8]** 72-hour test |
| **R-D Redundancy of funds** | Two signatories at every level; reserves per the waterfall | Bank-mandate continuity check **[S-A: A-14 §13.4]** |
| **R-E Redundancy of legitimacy** | Many authorised spokespersons (CU-1); recognition in the organisation's name (PR-1); no person as identity (CU-1) | Spokesperson count; attribution test T2 |
| **R-F Learning speed** | M5 lessons with "did it work"; M3 change route open to any member | Time from incident to standard change |

**[P] Rule D-122 (Resilience Is Measured By Exercise, Not By Document).** A continuity instrument that has not been exercised in the current annual cycle counts as **absent** for LDI and Rule D-33 purposes. **[A]** **[S-A: A-14 §13.8]** already requires an annual **unannounced 72-hour** continuity test at apex. Rule D-122 generalises the principle: **written and unexercised is the same as unwritten, because the failure it prevents will occur under conditions nobody has rehearsed.**

---

# PART 38 — DEPENDENCY INDEX & CONTINUITY TESTING

## 38.1 Definition

**[P] LDI (Leadership Dependency Index)** — the degree to which a unit's continued correct operation depends on one specific person remaining in one specific role. **A band, not a number** (Rule D-63). **A property of a role in a unit, never of a person.**

## 38.2 Inputs

| Input | Measurement | Source |
|---|---|---|
| **I-1 Functions held** | How many of the nine State A functions this person holds, alone | **[S: Ch.10]**; combination factor `c` **[S-B: §40.2]** |
| **I-2 Capabilities at risk** | Which of DECIDE / PAY / VERIFY / STOP have no route except this person | Rule D-33 |
| **I-3 Succession state** | SS-0…SS-5 for each role held | §11.2 |
| **I-4 Delegation exercised** | Whether any TL-4 delegation to another person has actually been used, with a record | SD-c; **[S-ST: M9]** |
| **I-5 Knowledge externalised** | Playbook exists, is current, and has been exercised | PB-1…PB-10; Rule D-96 |
| **I-6 Handover readiness** | KT pack exists and is current | §12.8 |
| **I-7 Continuity route tested** | Date and result of the last continuity exercise | §38.5 |
| **I-8 Load state** | LLI band — an overloaded sole holder is more fragile than a rested one | §24.2 |
| **I-9 Substitution lead time** | How long it would take to make someone else able to perform the function | **[P] UNKNOWN — MEASURE IN PILOT** |
| **I-10 Consequence radius** | What stops if the person is unavailable for one day / one week / permanently | Part 32 §32.2 |

## 38.3 Bands

| Band | Condition | Consequence |
|---|---|---|
| **DEP-C CRITICAL** | Any one of: a capability in I-2 has no route except this person; **or** SS-0/SS-1 on a mandatory-SS-4 role; **or** I-5 and I-6 both absent | **Unit may not be authorised to expand (XG-8); the role-holder may not be promoted (LG-series); a mitigation plan is mandatory within the current cycle; no leadership allocation increase (Rule D-72)** |
| **DEP-H HIGH** | Two or more functions held alone, with SS-2 or SS-3 and no exercised delegation | Mitigation plan required; monitored at RV-3 |
| **DEP-M MODERATE** | SS-3 or SS-4 with delegation exercised but knowledge not externalised | Playbook obligation |
| **DEP-L LOW** | SS-4 or SS-5, delegation exercised, playbook current and tested, KT pack current | Normal |

**[P] Rule D-123 (Dependency Is A Property Of The Organisation).** A DEP-C band is recorded against the **role and the unit**, and creates an obligation on the **organisation** to supply mitigation — a successor in development, City routing, a playbook, a delegation. **It never creates an adverse finding about the person.** **[A]** The person holding three functions alone in a nine-function team is not the problem; **the team's structure is.** Recording it against them would guarantee that nobody reports it (Rule D-76 logic).

## 38.4 Mitigation

| Mitigation | Cost | Time to effect | When appropriate |
|---|---|---|---|
| **M-a Nominate and develop a successor (SS-2→SS-4)** | High — paid development time (Rule D-73) | Long | The default for DEP-C |
| **M-b Exercise a delegation (TL-4)** | Low | Immediate | The fastest real reduction; also SD-c evidence |
| **M-c Route a function to City** | Medium — City load | Short | Where §26.2 permits |
| **M-d Write and test a playbook** | Medium once | Short | Substitutes for a third person (Rule D-34) |
| **M-e Reduce scope** | Low, but a real loss | Immediate | Where the unit is carrying more than it can hold (R-3) |
| **M-f Split or restructure the unit** | High | Long | Where the unit has outgrown its structure (R-2) |
| **M-g Refuse expansion** | Zero | Immediate | XG-8 — the cheapest mitigation of all, and the one most often resisted |

## 38.5 Continuity testing

**[P] Amendment L-20.** Three tests, tiered:

| Test | Level | Method | Frequency | Pass condition |
|---|---|---|---|---|
| **CT-A DELEGATION EXERCISE** | Team | A named person performs a defined function under a real TL-4 delegation, with the record completed | At least once per successor-development cycle | The function was performed correctly **and** the record is complete |
| **CT-B PLAYBOOK EXERCISE** | Team / City | A person who does **not** hold the role is given the playbook and asked to perform a defined function | Per playbook review cycle | Performed to standard, **or** a playbook finding is recorded (Rule D-96) |
| **CT-C UNANNOUNCED CONTINUITY TEST** | City / State / National apex | **Unannounced 72-hour** test: the holder is treated as unavailable; the named continuity route must operate | **Annually** **[S-A: A-14 §13.8]** | DECIDE, PAY, VERIFY and STOP all functioned; no reserved matter was decided; a report with findings is produced |

**[A]** CT-C is the source's own instrument and the most valuable in this document, because it is the only test that discovers **false continuity** — a named route that does not work. **[I]** The three most common false-continuity findings in real organisations are: the named deputy does not have the system permissions; the bank mandate does not actually permit the second signatory to act alone; and the person who knows the password is the person being tested. **All three are invisible until exercised.**

**[P] Rule D-124 (A Failed Continuity Test Is A Governance Finding, Not A Person Finding).** The output of a failed CT-A/B/C is: an M5 lessons entry, an M3 change request where systemic, a mitigation plan under §38.4, and a record against the **unit**. **No participant is penalised.** **[A]** If failing a continuity test carries a personal cost, the test will be scheduled, rehearsed and passed — and it will measure nothing.

## 38.6 Dependency versus indispensability

**[A]** The distinction the brief demands:

| | Dependency | Indispensability |
|---|---|---|
| **What it is** | A **structural fact** about a unit: this function has one route | A **cultivated position**: a person has arranged that the function has one route, and that route is them |
| **How it arises** | Small teams, early stages, unfilled vacancies, growth faster than development | Incentives that reward being needed; absence of a mitigation obligation; a culture that reads replaceability as disloyalty |
| **How it is detected** | LDI inputs I-1…I-10 | **The pattern over time:** DEP-C persisting across cycles **with mitigation available and not taken**; delegation offered and declined; playbook requested and not written; successor named and not developed |
| **Response** | Organisational mitigation (§38.4) | **Rule D-62 performance defect; Rule D-72 no allocation increase; and, if persistent, an RV-3 finding** |
| **Moral status** | Neutral — often unavoidable | **A leadership failure**, because making oneself replaceable is T-6, the sixth teaching obligation |

**[P] Rule D-125 (Replaceability Is A Leadership Duty).** A leader who has not made their role transferable has not completed the role. **[S: Ch.9]**'s Succession column, **[S: Ch.22]**'s `succession_status`, **[S-B: B-18(1)]**'s successor-before-transition and **[S-C: §6.10]**'s "let knowledge survive turnover" all point the same way. **[A]** The reason this must be stated as a duty rather than a virtue is that **virtues are optional and duties are reviewed.**

## 38.7 Aggregate dependency

**[P]** Reported at City, State and National level, with small-cell suppression (Rule D-108):

| Aggregate | Definition | Why it matters |
|---|---|---|
| **% of covered roles at SS-4 or SS-5** | D-ready (§14.3) | The organisation's real continuity position |
| **% of teams with all four capabilities routed** | D-control | The operating floor |
| **Count of DEP-C roles** | Absolute, not percentage — a percentage conceals a single catastrophic exposure | Reserved-matter and apex exposure |
| **Mean functions held alone per team** | Concentration measure | The combination factor `c` in practice |
| **% of playbooks exercised in the cycle** | Rule D-122 | Documented versus real |
| **Continuity-test failure count and findings** | CT-A/B/C | False continuity |
| **Time-to-substitute distribution** | I-9 | How long the organisation is exposed |

---

# PART 39 — ECONOMIC FEASIBILITY OF THE LEADERSHIP SYSTEM

## 39.1 The rule about numbers

**No rupee value, salary, multiplier, percentage or ratio is invented in this Part.** **[S-B]**'s formulas are used symbolically. **[S: Ch.33]**'s `NOT FINAL` items remain `NOT FINAL`. Where a value would be needed, the text reads `UNKNOWN — MEASURE IN PILOT`.

## 39.2 The cost structure of the leadership system

**[A]** Every component in this document has a cost in hours, and hours are the binding currency because **[S: Ch.18]**'s waterfall places **worker compensation first** and there is **no revenue line for governance or training** **[S-B]**. Governance hours are therefore paid out of the same pool as delivery.

| Component | Cost type | Formula character | Bounded by | Deferrable? |
|---|---|---|---|---|
| **Gate E screening** | Recurring, low | Per vacancy | Vacancy rate | No — but automatable |
| **Gate R assessment** | Recurring, **high** | Per candidate × out-of-team assessor time | Assessor supply | **Partially** — Stage 1 records the gap (Rule D-110) |
| **RV-1 score production** | Recurring | Per team per cadence | **[S: Ch.24]** cadence fixed | No |
| **RV-2 role review** | Recurring | Per role per review date | `review_date` interval | No |
| **RV-3 leadership review** | Recurring, medium | Per leader per cycle | Cycle length **[P] UNKNOWN** | **Yes** to Stage 2 |
| **RV-4 conduct review** | Event-driven, **high** | Per complaint | Complaint rate | No |
| **F-360a/b/c** | Recurring, medium | Per leader per cycle | Rule D-52 | **Yes** to Stage 2 |
| **Successor development (SD-c)** | Recurring, **high** | Per mandatory-SS-4 role | §11.3 role classes | No for mandatory roles |
| **Playbooks PB-1…PB-10** | One-time high, recurring low | Per covered role | Rule D-99 core-only at Stage 0–1 | **Partially** |
| **KT handover packs** | Event-driven | Per transition | Transition rate | No |
| **Continuity tests CT-A/B/C** | Recurring | Per unit per cycle; CT-C annual | Rule D-80 tiering | **CT-A/B yes; CT-C no at apex** |
| **Complaints and appeals** | Event-driven, **high** | Per matter | Matter rate | No |
| **Decision records M1** | Recurring, per decision | Per consequential decision | Rule D-99 minimum form | No |
| **Audits** | Recurring | Per cycle; sampling scale **[S-ST: §23.1 S3]** | Sampling rate | No |
| **Leadership allocation `m_lead`** | Recurring | `C_lead = C_wc_base × m_lead` **[S-B: §24]** | **Rule D-70 bounded; value `[U]`** | No — but the bound is unknown |
| **Training and trainer time** | Recurring, **high** | Per cohort × trainer supply | **[S-ST: Scenario B]** trainer bottleneck | No |
| **Governance bodies** | Recurring | Five retained bodies (§34.4) | Rule D-40 | No |
| **Aggregate reporting and disparity testing** | Recurring, low | Per cycle | Automation | **Yes** |

## 39.3 The five economic findings

**[P] Finding EF-1 — The leadership system's cost is dominated by three items, and none of them is measurement.**
**Gate R out-of-team assessment, successor development, and trainer time.** Together these are the *people-producing* costs. **Score production, dashboards and reporting — the items an organisation usually worries about — are comparatively cheap.** **[A]** The policy consequence is that budget pressure will naturally fall on assessment and development, because they are the largest and the least visible to outsiders. **That is precisely backwards: they are the only costs that produce the thing the architecture claims to produce.**

**[P] Finding EF-2 — Every control has a price, and `σ_max` is the price ceiling.**
**[S-B: §26.1]** caps total control effort at `σ_max`, derived from the team's own economics. **This document has specified controls whose total exceeds `σ_max` for a Stage 0–1 team.** This is acknowledged, not concealed, and is resolved by Rule D-80 tiering and the MVLS (Part 40).

**[P] Finding EF-3 — Promotion is a cost, not a reward, at the moment it happens.**
**[S-B: §24.2]** "success tax on success"; **[S-B: B-18(6)]** promotion recorded as a cost. **[A]** The full cost of one promotion is: the sending unit's lost delivery hours + the successor's development time already spent + the overlap period **[S-B: B-18(2)]** + the bounded mentorship period **[S-B: B-18(3)]** + the transition access work + the vacancy process for the role below + the risk that the promoted person fails and returns. **None of this appears in the moment of celebration, and all of it appears in the following quarter.**

**[P] Finding EF-4 — The specialist track is the only instrument that adds capacity without adding governance cost.**
**[S-C: §47.1]**: "A specialist path multiplies the useful population without multiplying the management population — which is the only way to raise `P_max` without raising `H_gov`." **[A]** Every SP-3 verifier produced reduces the cost of Gate R and of verification generally, and requires no management layer. **The specialist track is therefore not a courtesy to people who do not want to lead; it is the cheapest capacity instrument in the design.**

**[P] Finding EF-5 — The affordability of leadership for a poor person is unresolved.**
§25.6's fairness test found that condition (iii) — the economics of holding the role — is the most likely to fail. **[A]** If leadership work is itemised and paid (Rules D-69, D-47) but the itemisation is incomplete, or the payment is bounded low, or the hours are unpaid in practice because the team cannot afford them, **then the leadership system selects for people who can afford to work for less.** That is a class filter operating without anyone intending it, and it is invisible in every record this document specifies.

**[P] Rule D-126 (Unpaid Leadership Work Is A Recorded Deficit).** Where leadership work is itemised under Rule D-69 but not actually paid — because the unit cannot afford it — the shortfall is **recorded as an organisational deficit against the unit**, reported in aggregate, and treated as an LDI input (I-8) and a Rule D-59 support-failure signal. **[A]** Recording the deficit does not pay it. **But an unpaid obligation that is not recorded is an unpaid obligation that is assumed to be a personal choice — and that assumption is the mechanism of EF-5.**

## 39.4 Sustainability test

| Test | Question | Result |
|---|---|---|
| **S-1** | Can one team afford the MVLS? | **Unknown.** Depends on `c`, `H_gov` (8–40 h/month range **[S-B]**) and `σ_max`. **MEASURE IN PILOT** |
| **S-2** | Does the City divisor make governance sub-linear in `K`? | **UNRESOLVED** **[S-B: §26]** — Rule D-91 gates State formation on measuring it |
| **S-3** | Does the leader premium survive the success tax? | **Conditionally** — only if bounded (Rule D-70) and work-linked (Rule D-69). **[U]** on the value |
| **S-4** | Can the specialist track be produced at the rate verification demand grows? | **Unknown** — SP-3 production depends on SP-4/SP-5 assessors, which is a stock problem **[S-B: §24.5]** |
| **S-5** | Does the system cost less than the failure it prevents? | **The only test that matters, and it cannot be answered before the pilot.** **[A]** A continuity test costs hours; an unrecovered bank mandate during an apex vacancy stops worker compensation, which breaches priority 1 of **[S: Ch.18]**. The comparison is between a small certain cost and a large uncertain one |
| **S-6** | Is any component unfundable at every stage? | **Gate R out-of-team assessment at S0** — there is no outside. **Recorded as a known gap (Rule D-110), not solved by pretending the inside is outside** |

---

# PART 40 — CONTROL BUDGET, MINIMUM VIABLE LEADERSHIP SYSTEM & MATURITY MODEL

## 40.1 The control-budget test

**[A]** **[S-B: §26]** established the control-budget rule: total control and governance effort must fit inside `σ_max`, and **[S-B: §26.3]** established the discipline — **automate, simplify or retire.** The brief requires every added control to justify its burden.

**[P]** Applied to every control this document proposes. The test has four questions:

| Q | Question | Fails if |
|---|---|---|
| **CB-1** | What specific harm does this control prevent? | The harm cannot be named |
| **CB-2** | Is the harm irreversible, or costly to reverse? | The harm is merely inconvenient **and** a cheaper control exists |
| **CB-3** | What does it cost, in hours, per cycle? | The cost is undeclared (Rule D-52) |
| **CB-4** | Is there a cheaper control with the same effect? | A document substitutes for a person (Rule D-34); an aggregate substitutes for an individual record; a gate substitutes for a score |

**[A]** Result of applying CB-1…CB-4 to this document's own proposals: **the controls that survive are the ones that prevent irreversible harm or that make a decision explainable to the person it went against.** The controls that fail are the ones that produce information nobody consumes — which Rule D-65 retires automatically.

## 40.2 The Minimum Viable Leadership System

**[P] Amendment L-21 — MVLS.** The subset that a **Stage 0–1** team must operate. **Twelve items. Everything else in this document is tiered under Rule D-80.**

| # | MVLS item | Why it cannot be deferred | Source |
|---|---|---|---|
| **MVLS-1** | **Four irreducible capabilities with named continuity routes (DECIDE, PAY, VERIFY, STOP)** | Without them the unit cannot operate safely at all | Rule D-33 |
| **MVLS-2** | **Two bank signatories at every level** | Without them worker compensation stops during any single absence — priority 1 breached | **[S-A: A-14 §13.4; S: Ch.18]** |
| **MVLS-3** | **Decision record: what, why, who, when, expected — one standard sentence** | Without it there is no appeal, no audit and no memory | Rule D-99; **[S-A: A-15 M1]** |
| **MVLS-4** | **Incident reporting, immediate, non-punitive** | Safety and safeguarding cannot wait for a stage | **[S-A: A-09]**; **[S-B: §23.2]** Safety ● early |
| **MVLS-5** | **Gate E screening on published criteria, with prohibited evidence excluded** | Without it selection is arbitrary | Part 3 §3.2 |
| **MVLS-6** | **Succession state recorded for every covered role (SS-0…SS-5)** | Recording is nearly free; not recording makes every other control blind | §11.2 |
| **MVLS-7** | **Interim Authority Order, written and current** | The cheapest continuity instrument that exists | **[S-B: B-19]**; Rule D-31 |
| **MVLS-8** | **Playbook core PB-1…PB-6** | Substitutes for a redundant person | Rule D-99 |
| **MVLS-9** | **Complaint route with non-retaliation, reaching outside the unit** | Without it the only exit is exit | §18.2; **[S-ST: M10]** |
| **MVLS-10** | **Honest reporting of failure, including one's own** | Everything else depends on the record being true | **[S: App. A §16.3]**; Part 8 §8.6 |
| **MVLS-11** | **Access revocation on role change, same day** | The cheapest security control, and the one whose absence is unrecoverable | TA-b, TA-c; Rule D-102 |
| **MVLS-12** | **Refusal rights and a dignified exit route** | Without them consent is not consent and departure is hostile | **[S-C: H-17]**; Rule D-26 |

**[P] Rule D-127 (MVLS Is Not Optional At Any Stage).** No unit at any stage may operate below MVLS. **A unit that cannot operate MVLS is not a unit; it is a group of people, and the organisation must either support it to MVLS or not authorise it.** **[A]** This is the operational form of **[S: Ch.10 State A]**: "small size never removes safety, HR verification, finance integrity or evidence duties."

## 40.3 What is deferred, and to when

| Deferred to Stage 2 | Deferred to Stage 3+ | Never required at team level |
|---|---|---|
| Gate R out-of-team assessment *(where no outside exists, recorded as a gap)* | Full GF-1…GF-30 register | Founder Recusal Register *(apex-level)* |
| RV-3 leadership review | SP-4…SP-6 specialist stages | Reserved-matter procedure *(Rule D-113)* |
| F-360a/b/c | AI-7 disparity testing | CT-C unannounced 72-hour test *(City/State/National)* |
| LDI mitigation planning | Rule D-116 opportunity-allocation reporting | Four annual tests published *(Rule D-94)* |
| Full KT-1…KT-10 pack | PB-7…PB-10 | Council instruments **[U]** |
| Structured scenario DV-4 | Aggregate density reporting | — |

## 40.4 The maturity model (MAT-0 … MAT-5)

**[P]** Six levels. **The level is a property of a unit, determined by what it actually operates — not by what it has documented.**

| Level | Name | Determined by | Leadership-system property |
|---|---|---|---|
| **MAT-0 INFORMAL** | People doing good work | No MVLS items | Leadership is whoever steps up; no record; no continuity |
| **MAT-1 RECORDED** | MVLS-1…MVLS-12 operating | All twelve items present **and exercised** | Decisions are written; roles are named; absence is survivable for a short period |
| **MAT-2 ASSESSED** | Gate R operating with an outside assessor; RV-3 running; SS-4 achieved on mandatory roles | Out-of-team assessment actually occurring | **Leadership selection is independent of local popularity for the first time** |
| **MAT-3 TESTED** | Continuity tests passing; playbooks exercised; LDI in DEP-M or better across covered roles; lessons entries closing the loop | CT-A/B results; Rule D-122 | The unit can lose any one person and continue |
| **MAT-4 REPRODUCING** | The unit has produced a leader who now leads elsewhere; trainer capacity exists; specialist track operating | Promotion-cohort reporting **[S-B: B-18(4)]**; SP-3 verifiers available | **The unit adds capacity to the organisation rather than consuming it** |
| **MAT-5 SELF-CORRECTING** | Change requests from within the unit have altered standards; disparity testing runs; appeals succeed sometimes and are not resented | M3 outcomes; AI-7; appeal pattern data | The unit improves its own governance without external direction |

**[A]** **[S-ST: §23.1]**'s stage model maps onto this: **Leadership is ○ at S0 (MAT-0/MAT-1), ◐ at S1–S2 (MAT-2), and ● from S3 (MAT-3 and above).** The two models are consistent and the mapping is recorded so that neither is used to override the other.

## 40.5 The simplicity test

**[A]** The brief requires it. **[P] Applied as a question with a numeric answer: how many distinct obligations does a Mohalla Team Leader carry under this document?**

| Category | Count |
|---|---|
| MVLS items the leader personally performs | **7 of 12** (MVLS-1, 3, 4, 6, 7, 10, 11) |
| Recurring reviews | **2** (RV-1 at cadence; RV-2 at review date) |
| Records produced per decision | **1** (M1) |
| Succession obligations | **3** (record SS state; develop; exercise delegation) |
| Handover obligations | **1 pack** (KT-1…KT-10), only on transition |
| Declarations | **1** (conflict, only when a matter arises) |
| Playbook maintenance | **1**, periodic |
| Continuity participation | **1** (CT-A or CT-B), periodic |

**[P] Verdict: PASS AT STAGE 0–1, FAIL AT STAGE 2+ WITHOUT AUTOMATION.** **[A]** At Stage 0–1 the obligation set is small enough that one person can hold it alongside delivery. **At Stage 2 the addition of RV-3, F-360a/b/c, LDI planning and full KT pushes the count beyond what `H_gov` inside `σ_max` can carry**, unless the record-keeping is automated. **This is the concrete form of [S-B: §26.3]'s automate-or-retire rule, and it means the platform is not a convenience for the leadership system — it is a precondition of it at scale.** **[S-B: §40]**'s pilot deliberately runs with no technology, which is correct for validating the *process* and which means the pilot **cannot** validate the *burden at scale*. **That limitation is recorded here rather than left for someone to discover.**

**[P] Rule D-128 (The Simplification Obligation).** Before any new control is added at any stage, the adding authority must identify one existing control to automate, simplify or retire. **[A]** This is the only mechanism that prevents monotonic growth of obligation, which is the actual failure mode of every governance system that has ever been written — including this one.

---

# PART 41 — PILOT

## 41.1 One pilot, three instruments

**[A]** The brief is absolute: **do not create a second independent pilot.** The source architecture requires a shared pilot.

| Instrument | Pilot specification | Status |
|---|---|---|
| **[S-B: §40]** | **One mohalla team, no technology, operating the real process.** Measurements **B-P-01 … B-P-14** | PRIMARY |
| **[S-C: §57]** | **The same team**, human-system measurements | SAME PILOT |
| **v1.3-D** | **The same team again**, leadership measurements **LM-1 … LM-15** (Part 44, Annexure I) | SAME PILOT |

**[P] Rule D-129 (No Namespace Collision).** `P-nn` in **Part 42** denotes a **performance adversarial simulation**, as the brief mandates. `[S-B: §40]`'s pilot measurements are cited throughout this document as **`B-P-nn`**. **The two series are unrelated and must never be cross-referenced by number.**

**[P] Rule D-130 (No Second Pilot).** v1.3-D creates no new pilot, no new site, no new cohort and no new timeline. **It adds fifteen measurements to the existing one.** Where an LM measurement requires a population the single team cannot supply, the measurement is recorded as **NOT TESTABLE AT PILOT SCALE** and deferred — it is not satisfied by inventing a second pilot.

## 41.2 What one team can and cannot test

| Can be tested with one team | Cannot be tested with one team |
|---|---|
| Whether MVLS-1…MVLS-12 can be operated at all, on paper, by real people | Cohort normalisation (Part 9) — **a cohort of one is not a cohort** |
| Whether the decision record (M1) survives contact with a real week | Relative performance across contexts |
| Whether a succession state can be recorded and a delegation actually exercised (CT-A) | Promotion (Part 10) — **there is nowhere to promote to** |
| Whether a playbook (PB-1…PB-6) lets a non-holder perform a function (CT-B) | Cross-level leadership (Part 32) |
| Whether `H_gov` falls inside the 8–40 h/month range and what it actually is | The City divisor `H_gov_per_team(K)` — **Rule D-91 requires a range of `K`** |
| Whether the four irreducible capabilities have real routes | Out-of-team assessment (Rule D-45) — **there is no outside** (EF-6, S-6) |
| Whether a complaint reaches outside the unit and returns an answer | Disparity testing (AI-7) — insufficient population; Rule D-108 suppression would suppress everything |
| Whether honest failure reporting actually happens when it costs something | Leaderboard fatigue (LF-1…LF-4) — needs repeated cycles across units |
| Whether the leadership allocation is affordable at `σ_max` | The success tax **[S-B: §24.2]** in practice — needs a promotion to have occurred |
| Whether refusal rights are exercised without social cost | Multi-city continuity (CT-C at scale) |

**[P] Rule D-131 (Untestable Is Recorded, Not Fudged).** Every LM measurement that a single team cannot produce is recorded in Annexure I with the status **NOT TESTABLE AT PILOT SCALE** and a stated minimum population. **[A]** This is more useful than a pilot that pretends to have validated succession, because **the architecture's leadership claims are precisely the ones a single team cannot test** — and knowing that before scaling is the entire value of the exercise.

## 41.3 Pilot success conditions

**[P]** A condition is a success condition only if it is **falsifiable** and **observable without technology**.

| # | Success condition | Falsified by |
|---|---|---|
| **PS-1** | All twelve MVLS items operate for a full cycle | Any item not operated, or operated only on paper |
| **PS-2** | `H_gov` per team per month is measured and falls inside a band the team can sustain against `σ_max` | `H_gov > σ_max` with no identified reduction |
| **PS-3** | Every consequential decision in the cycle has an M1 record with a reason a stranger could follow | Records missing, or reasons of the "as discussed" class |
| **PS-4** | At least one **real** TL-4 delegation was issued, exercised, recorded and reviewed | No delegation exercised — succession is then documentary only |
| **PS-5** | At least one CT-B playbook exercise was performed by a non-holder, with the result recorded | No exercise, or the holder performed it |
| **PS-6** | At least one failure was reported by the team **before** anyone outside discovered it | All failures discovered externally |
| **PS-7** | At least one complaint or concern reached a route outside the unit and produced a recorded answer | Zero complaints **and** zero concerns raised — which is a warning, not a success |
| **PS-8** | At least one person exercised a refusal right **[S-C: H-17]** with no adverse consequence | Refusals not exercised, or exercised with consequence |
| **PS-9** | The leadership allocation, if any, was itemised against actual leadership work (Rule D-69) | A premium paid for holding a role |
| **PS-10** | The team can state, unprompted, who would decide and who would pay if the leader were unavailable for 72 hours | Inability to answer, or an answer that differs from the written Interim Authority Order |
| **PS-11** | No prohibited evidence (Part 5 §5.4) was used in any recorded judgement | Any use — a single instance falsifies |
| **PS-12** | The team reports that the process was **worth its cost** | A negative judgement by the people who operated it. **[A]** This is the only subjective condition, and it is included because a process the operators resent will be complied with nominally and fail actually |

## 41.4 Pilot failure conditions

**[P]** Any of the following is a **failure**, requiring redesign before expansion — not a "learning":

| # | Failure condition | Why it is fatal |
|---|---|---|
| **PF-1** | `H_gov` exceeds `σ_max` with no reduction path | The system is unaffordable at the smallest possible scale, so it is unaffordable everywhere |
| **PF-2** | Worker compensation (priority 1) was delayed by a governance or leadership obligation | **The waterfall was inverted.** No leadership system justifies this |
| **PF-3** | A decision affecting a person's standing was made without a recorded reason | The appeal right is void; everything downstream of it is void |
| **PF-4** | A complaint was handled by the person complained about | Non-retaliation is void |
| **PF-5** | Access was not revoked on a role change within the cycle | TA-b/TA-c are not real |
| **PF-6** | Prohibited evidence determined an outcome | Gate E/R are not real |
| **PF-7** | The team produced records that were not true | Everything is void |
| **PF-8** | The four irreducible capabilities had no actual route during any period | Rule D-33 was not met; the unit should not have been authorised |
| **PF-9** | Recruitment occurred at a moment of vulnerability | **[S-C: H-03]** breached |
| **PF-10** | A person was treated as a score | **[S-C: §23.2]** breached |

## 41.5 What the pilot cannot tell anyone

**[A]** Recorded here so that the pilot's result is not over-read:

1. **It cannot validate succession.** One team, one cycle, no promotion, no vacancy at scale. **Succession remains `ARCHITECTURALLY SPECIFIED — EMPIRICALLY UNVALIDATED` after the pilot.**
2. **It cannot validate promotion.** Same reason.
3. **It cannot validate assessment independence.** There is no outside assessor.
4. **It cannot validate cohort normalisation, relative performance, or the leaderboard's public/private question (R5).**
5. **It cannot validate burden at scale**, because it runs without technology (§40.5) and without a range of `K`.
6. **It cannot validate the economics of the leader multiplier**, because `m_lead` is `NOT FINAL` and no value is tested.
7. **It cannot validate anti-favouritism controls** in a unit where everyone is in everyone's social field — which is the condition the controls exist for.

**[P] Rule D-132 (Pilot Scope Statement).** Every claim made about the leadership system after the pilot must state which of the seven limits above applies to it. **[A]** This rule exists because the most likely failure after a successful pilot is not that the pilot was wrong; it is that a **narrow** success is reported as a **general** one, and expansion follows on the strength of a validation that never happened.

---

# PART 42 — SIMULATIONS

## 42.1 Succession simulations — Scenario A … Scenario L

**[P]** Twelve scenarios. Each states: the **trigger**, the **path through the architecture**, the **outcome**, and the **residual weakness exposed**. Scenarios are **not forecasts** — **[S-B]** standing instruction.

| ID | Trigger | Path | Outcome | Residual weakness |
|---|---|---|---|---|
| **A** | **Team Leader resigns with notice** | Rule D-26 dignified exit; SS state checked; if SS-4, promotion-ready successor appointed via **[S: Ch.11]**; KT-1…KT-10; TA-0…TA-4; RV-2 | Clean transition | **If SS-0/SS-1:** TL-2 interim + City cover; the unit operates degraded for an unmeasured period |
| **B** | **Team Leader dies suddenly** | TL-2 immediately; two signatories keep PAY alive **[S-A: A-14 §13.4]**; master handover checklist is the only continuity source **[S-A: A-14 §13.7]**; Rule D-97 relational memory is **absent** | Service continues; **local relational knowledge is permanently lost** | The KT pack and playbook are the whole of what survives. **If PB-7 known-failures was never written, the unit repeats the dead leader's mistakes** |
| **C** | **Team Leader promoted to City** | LG-1…LG-10; XG-2/XG-8 checked; **[S-B: B-18(1)]** successor-before-transition; overlap **[B-18(2)]**; bounded mentorship **[B-18(3)]**; promotion recorded as a cost **[B-18(6)]** | Transition occurs **only if** the successor was ready | **Rule D-17 hollowing:** the mohalla loses its most capable person and gains an inexperienced one, and its cohort position falls. **[S-B: B-18(4)]** reports this with and without adjustment — reporting is not prevention |
| **D** | **Whole City team lost** (resignation, relocation, disqualification) | City-level TL-2; State cover; reserved matters frozen; Interim Authority Order at City level | **Severe degradation.** City shared services **[S-B: §26.4]** stop, which stops verification and funds review for `K` mohallas | **The dependency is inverted:** the mohallas were routed to the City for segregation of duties (Rule D-103), so losing the City loses the control. **This is the architecture's largest single-point exposure below the apex** |
| **E** | **Founder incapacitated** | **[S-A: A-14]** apex Deputy; Interim Authority Order; seven reserved matters frozen; T1 absence test becomes real | Operations continue under existing delegated authority **[S-A: A-14 §13.6]** | **Reserved matters are frozen, not decided.** A crisis requiring one invokes Rule D-113's provisional two-body procedure — which has never been exercised, and whose legality depends on the **UNRESOLVED** entity structure |
| **F** | **Founder wishes to appoint a preferred person against the evidence** | Rule D-92 register; Rule D-93 prohibition on assessing; Rule D-115 declaration; the appointing authority decides with recorded reasons; dissent route **[S-A: A-16 test 3]** | **The architecture permits the preference to be recorded and rejected — but does not prevent it being accepted** | **This is the honest limit.** No procedural control binds a person who holds constitutional authority **[S: Const. Art.3 APPROVED]**. Visibility is the only available check |
| **G** | **Two people claim the same role** | **[S: Ch.22]** "one role has one primary holder"; Rule D-100 no overlapping write authority; the appointment record decides; TA-phase determines who is in TA-3 | Resolved by record, quickly, **if** the record is current | Where both claim a **delegation**, and delegations were not swept (TA-g), the record may genuinely support both. **Automatic expiry is the only real control** |
| **H** | **Successor named but not ready** (GF-23) | SD-a satisfied, **SD-b fails** (Gate R not passed out-of-team), **SD-c fails** (no exercised delegation) | Promotion blocked by LG-series; LDI stays DEP-C | **Detection depends entirely on the out-of-team assessor existing.** At Stage 1 it does not (EF-6) |
| **I** | **Leader refuses promotion** | Rule D-23 legitimate refusal grounds; recorded as a complete choice; no adverse mark; not repeatedly asked | Refusal honoured | **If refusals cluster in one unit, the unit has a problem nobody has named** — and the cluster is only visible in aggregate, which Rule D-108 may suppress |
| **J** | **Leader disappears** (unreachable beyond the stated period) | Automatic trigger; TL-3 → TL-2; dual-custody credential procedure **[S-A: A-14 §13.4]**; **loss of access and theft of access look identical** (Rule D-104) | Continuity achieved; security treated as potential compromise | **The waiting period is `[P] UNKNOWN`.** Too short and a person on a train loses their role; too long and the unit is leaderless for a week |
| **K** | **Emergency: leader acts beyond authority, correctly** | TL-3 scope; Rule D-30(3) reserved matters excluded; §37.4 mandatory independent review; Rule D-32 non-conversion; **PT-series transition does not apply because there was no transition** | The act stands; the review determines whether the scope was exceeded | **A correct act beyond authority has no clean path.** The review can ratify or censure, but the architecture has no instrument for "**retrospective authorisation**" — and creating one would create a loophole |
| **L** | **Leader removed for serious misconduct** | CR-3; Rule D-102 access withdrawn at the decision moment; Governance/HR panel **[S: App. E]**; score voided **[S: Ch.26]**; KT pack **unavailable** — the removed person will not cooperate | Removal achieved; **handover fails by design** | **The unit inherits the role with no relational memory, no KT pack, and possibly a hostile former holder who retains social influence in the mohalla.** Rule D-97 cannot operate. **This is the hardest succession case in the architecture and it has no good answer — only a playbook (PB-1…PB-6) and a City route** |

## 42.2 Performance adversarial simulations — P-01 … P-20

**[P]** Twenty attacks on the performance architecture. Each states the **attack**, the **defence that exists**, and whether the defence **holds**.

| ID | Attack | Defence | Holds? |
|---|---|---|---|
| **P-01** | A team inflates activity counts | AC-1…AC-5 cap; GF-1 | **Yes** |
| **P-02** | A team reclassifies outputs as outcomes | Follow-up obligation; non-completion reduces score **[S: Ch.15]**; GF-2 | **Yes** |
| **P-03** | A team underreports costs to inflate margin | Reconciliation accuracy; separation of duties; random audits **[S: App. A §18.3]**; GF-7 | **Yes, if audit sampling is real** |
| **P-04** | A team shops for an easier cohort | CN-1 records-based assignment; GF-20 | **Yes** |
| **P-05** | A team splits to improve ratios | GF-22; split requires City approval with reason | **Yes** |
| **P-06** | A team inflates difficulty at intake | Intake/verification separation; distribution monitoring; GF-21 | **Partly** — the verifier is the same small social field |
| **P-07** | A leader times the assessment window | Windows fixed by cadence, not chosen; GF-13 | **Yes** |
| **P-08** | A leader suppresses their own baseline to inflate improvement | Rule D-19 baseline locked once recorded; GF-12 | **Yes** |
| **P-09** | A leader clears a service floor with trivial service | Floor in verified outcomes, not hours; GF-14 | **Yes** |
| **P-10** | A leader backdates decision records | Timestamped M1; append-only; GF-15 | **Yes** |
| **P-11** | A leader appoints an artificial successor to satisfy the succession dimension | SD-b out-of-team Gate R; SD-c exercised delegation; GF-23 | **No, at Stage 1** — no outside assessor exists |
| **P-12** | A leader discourages complaints to keep the record clean | Dual-channel volume comparison; zero-complaint anomaly (§17.3 Q7); GF-17 | **Partly** — depends on the Integrity Line being reachable and trusted |
| **P-13** | A leader reports only trivial failures to score well on honesty | Materiality test; GF-19 | **Yes** |
| **P-14** | A popular incompetent person outperforms an unpopular competent one on every recorded dimension | Rule D-117's four affordances: out-of-team assessor, blind portfolio, structured scenario, recorded appealable reason + dissent route | **Only if all four exist.** At Stage 1, **two of the four do not** |
| **P-15** | A clique captures a small team's verification | Out-of-team verifier where available; rotation **[S-ST: F-26(7) ii]**; SP-3 assignment recorded | **No, where no outside verifier exists** |
| **P-16** | A leader prolongs an emergency to hold TL-3 authority | Rule D-30(2) renewal is a decision; Rule D-32; §37.4 review; GF-28 | **Yes** |
| **P-17** | An interim holder prolongs TL-2 indefinitely | **[S: Ch.11]** time-in-status monitored; extension requires recorded reason; GF-29 | **Yes** |
| **P-18** | An AI recommendation is followed without thought | AI-2 records whether the human followed it and why; AI-4 makes favourable override free; Rule D-105 stranger test; GF-30 | **Partly** — **[S-ST: F-29]** rubber-stamping is a behavioural failure and no record control eliminates it |
| **P-19** | A high scorer commits fraud | Score void **[S: Ch.26]**; CR-4; Rule D-60 no automatic effect in the other direction | **Yes** |
| **P-20** | The whole measurement system is complied with nominally and fails actually | **No control in this document detects it.** The only detectors are F-360c downward experience, the Integrity Line, skip-level review, field immersion **[S-ST: M10]** and PS-12's operator judgement | **NO — this is the terminal weakness of any measurement architecture, and it is recorded rather than solved** |

**[A]** Score: **13 hold, 4 partly hold, 3 do not hold.** The three that do not — **P-11, P-15, P-20** — share one cause: **they all require an observer from outside the unit's social field, and at the smallest scale there is no outside.** **[P] This is not fixable by better metrics. It is fixable only by (i) City capacity to observe, (ii) refusing to authorise units that cannot be observed (XG-3, XG-4), and (iii) accepting that at Stage 0–1 the leadership system is partly unenforceable and saying so.**

---

# PART 43 — RED-TEAM & FAILURE-MODE REGISTER

## 43.1 Red-team attacks ATK-01 … ATK-20

**[P]** Each attack assumes an actor who is **intelligent, patient, inside the system, and not a cartoon villain** — a person pursuing a legitimate interest by illegitimate means.

| ID | Attacker | Attack | Detection | Residual risk |
|---|---|---|---|---|
| **ATK-01** | An ambitious coordinator | Accumulates all evidence-generating opportunities (Rule D-116 pattern), then presents an unbeatable portfolio | Aggregate opportunity-allocation report | **Medium** — the report shows the pattern only after it has worked |
| **ATK-02** | A popular leader | Converts social capital into witness statements; F-360a statements are numerous but thin | Rule D-54: a statement with no specific event is inadmissible | **Low** |
| **ATK-03** | A departing leader | Exfiltrates beneficiary and member data on the way out (SEC-9) | `data_access_profile` minimisation; export logging; TA-e | **Medium** — data already seen cannot be unseen |
| **ATK-04** | A suspended leader | Continues to direct the team through allies | Rule D-102 access withdrawn; Rule D-41 shadow authority is an incident | **High** — social influence is not an access right |
| **ATK-05** | An interim holder | Converts TL-2 into permanence by making the vacancy awkward to fill | GF-29; time-in-status monitoring | **Medium** |
| **ATK-06** | A City official | Routes all assessment to a compliant assessor | Assessor rotation; pattern audit; Rule D-50 | **Medium** |
| **ATK-07** | A founder-adjacent person | Uses proximity as an implicit instruction, never recorded | Rule D-41; Rule D-92 register | **High** — proximity is the hardest authority to detect |
| **ATK-08** | A faction | Coordinates low F-360a statements against a rival before a promotion cycle | Named statements are accountable; appeal; Rule D-64 two-signal requirement | **Medium** — naming raises the cost but does not remove the incentive |
| **ATK-09** | A verifier | Passes friendly work (GF-27) | Verifier/pass-rate correlation with social proximity; rotation | **Medium** |
| **ATK-10** | A treasurer | Reconciles by adjusting records rather than cash (GF-8) | Dual approval on adjustments; audit trail; random audits **[S: App. A §18.3]** | **Low** |
| **ATK-11** | A team | Retains departed members on the record (GF-10) | Periodic participation confirmation **[S-C: H-02]** | **Low** |
| **ATK-12** | A trainer | Issues certifications without assessment (SI-3) | Out-of-team assessor requirement **[S-ST: M9]**; Rule D-48 | **Medium** — trainer supply is the bottleneck, so there is pressure to be lenient |
| **ATK-13** | A complainant's adversary | Files a counter-complaint to muddy the record | Rule D-56 no route substitution; triage; panel | **Medium** |
| **ATK-14** | A leader under investigation | Alters historical evidence (SEC-6) | Append-only records; sealed audit log (TA-h) | **Low, if TA-h is real** |
| **ATK-15** | An external political actor | Places a member in a local leadership role to access the organisation's reach | PC-1…PC-7; declaration; AI-7 aggregate disparity | **High** — detection is slow and the actor is patient |
| **ATK-16** | A commercial actor | Seeks to use the member list or the trust of the brand | **[S-A: A-20 §19.5]** prohibited uses; **[S-C: CR-4]**; **[S-B: NM-4, NM-11]** | **Low** |
| **ATK-17** | An AI system operator | Uses historical promotions as prediction labels (Rule D-107 violation) | AI-8 model versioning; disparity testing | **Medium** — it is the obvious engineering choice and will be proposed in good faith |
| **ATK-18** | A leader | Cultivates indispensability and presents it as dedication | Rule D-62; LDI persistence across cycles with mitigation available and not taken | **Medium** — the detection lag is measured in cycles |
| **ATK-19** | A beneficiary-adjacent person | Presents as a contributor to access standing | **[S-A: A-19]** access separation; a contributor's record is not a beneficiary's record | **Low** |
| **ATK-20** | Nobody | **The system is complied with nominally and fails actually (P-20)** | **None available from inside** | **CRITICAL — the terminal weakness** |

## 43.2 Failure-mode register LF-01 … LF-30

**[P]** Each entry: failure mode, cause, effect, likelihood, impact, control, residual.

| ID | Failure mode | Cause | Effect | L | I | Control | Residual |
|---|---|---|---|---|---|---|---|
| **LF-01** | No successor exists when a leader leaves | Succession treated as an HR process, not a role duty | Unit degraded or closed | High | High | §11.3 mandatory SS states; SD-a gate; XG-2 | Medium |
| **LF-02** | A named successor is not actually ready | GF-23; naming is free | False continuity | High | High | SD-b/SD-c; out-of-team Gate R | **High at S1** |
| **LF-03** | Promotion hollows out the winning team | **[S: Const. Art.15]** moves teams, not people | The best unit becomes the worst | High | High | Rule D-17; XG-8; LG-series; **[S-B: B-18]** | Medium |
| **LF-04** | The popular incompetent are selected | Popularity substituting for capability | Systemic capability decline | High | **Critical** | Rule D-117 four affordances | **High at S1** |
| **LF-05** | The unpopular competent never apply | OB-5, OB-6; prior non-selection without explanation | Capability excluded | High | High | §25.3 feedback obligation; Rule D-81 | Medium |
| **LF-06** | Favouritism operates through opportunity allocation | Invisible, unrecorded decisions | Systemic unfairness with clean records | High | High | Rule D-116 aggregate reporting | **High** |
| **LF-07** | Founder preference becomes institutional | Rule D-92 register not maintained, or maintained but ignored | Personal pattern laundered as evidence | Medium | **Critical** | Rule D-92/93/115; T2/T3 tests; AI-7; Rule D-107 | Medium |
| **LF-08** | Emergency authority persists | TL-3 not expired | De facto authoritarianism | Medium | High | Rule D-30(2); Rule D-32; §37.4 | Low |
| **LF-09** | Interim appointments become permanent | TL-2 prolonged | Structural stagnation | Medium | Medium | GF-29; **[S: Ch.11]** time-in-status | Low |
| **LF-10** | Access not revoked on transition | "They might be needed" | Unauthorised acts; data loss | Medium | **Critical** | TA-b/TA-c; Rule D-101/102 | Low |
| **LF-11** | Audit log deletable | No immutability requirement | Every control retroactively optional | Low | **Critical** | TA-h; append-only | Low |
| **LF-12** | Payment of worker compensation interrupted by a leadership vacancy | Single signatory | **Priority 1 breached** | Low | **Critical** | Two signatories at every level **[S-A: A-14 §13.4]** | Low |
| **LF-13** | Governance hours exceed `σ_max` | Control accumulation | Delivery collapses; burnout | **High** | High | Rule D-80 tiering; MVLS; Rule D-128 | Medium |
| **LF-14** | Leadership work unpaid because the unit cannot afford it | `σ_max`; `m_lead` `NOT FINAL` | Class filter on leadership (EF-5) | High | High | Rule D-126 deficit recorded | **High** |
| **LF-15** | Burnout undetected until exit | Structural signals ignored; self-report penalised | Loss of the most committed | High | High | BN-1…BN-9; Rule D-77 | Medium |
| **LF-16** | Measurement fatigue | Pointless measurement | Cynicism; nominal compliance | High | Medium | Rule D-53; Rule D-65 retirement | Medium |
| **LF-17** | Nominal compliance system-wide | Nothing detects it (P-20, ATK-20) | **The architecture exists and does not operate** | Medium | **Critical** | F-360c; Integrity Line; skip-level; field immersion; PS-12 | **High — unresolved** |
| **LF-18** | Complaints suppressed | Retaliation fear | Harm continues invisibly | Medium | **Critical** | Non-retaliation with reversed burden; dual-channel volume comparison | Medium |
| **LF-19** | Appeals unused because they mark the appellant | Rule D-57 not honoured in practice | Decisions unreviewable in substance | Medium | High | Rule D-57; appeal pattern detection | Medium |
| **LF-20** | Improvement plans used as pre-removal formalities | Sham process | Unfair removal; destruction of genuine plans' credibility | Medium | High | Rule D-58; Rule D-59 | Low |
| **LF-21** | Personality cult forms around a local leader | Affection converted into unaccountability | Capture; succession impossibility | Medium | High | CU-1…CU-10 | Medium |
| **LF-22** | Recruitment-pyramid dynamics emerge | Any compensation linked to participation | MLM character; legal and reputational exposure | Low | **Critical** | Rule D-118; **[S-C: MLM-1…MLM-7]** | Low |
| **LF-23** | Protection function becomes coercive | Local legitimacy + popular demand | Vigilante character; criminal exposure | Low | **Critical** | VG-1…VG-6; **[S-A: A-08]** reserved | Low |
| **LF-24** | Political capture | A role-holder's political use of organisational reach | 12A/registration exposure; mission distortion | Medium | **Critical** | PC-1…PC-8 | Medium |
| **LF-25** | AI recommendation rubber-stamped | Asymmetric friction on override | Human accountability hollowed; **Art.12** breached in substance | High | High | AI-2/AI-4; Rule D-105 | Medium |
| **LF-26** | Historical bias encoded as prediction | Historical outcomes used as labels | Past favouritism becomes future policy | Medium | High | Rule D-107 | Medium |
| **LF-27** | Small-cell disclosure identifies individuals | Aggregates published without suppression | Privacy harm; chilling of participation | Medium | High | Rule D-108 | Low |
| **LF-28** | Playbooks written and never exercised | Rule D-96 not honoured | False knowledge redundancy | High | Medium | Rule D-122 unexercised = absent | Medium |
| **LF-29** | City layer becomes a bottleneck | All routing goes to one city function | Every routed control fails simultaneously (Scenario D) | Medium | **Critical** | Rule D-91 divisor measurement; XG-4; tiered routing | **High — unresolved** |
| **LF-30** | Layer explosion | Roles, bodies and reports multiplied | Governance consumes delivery | Medium | High | Rules D-38/39/40/41/128; E-1…E-7 | Medium |

## 43.3 The five unresolved failure modes

**[A]** LF-04 (at Stage 1), LF-06, LF-14, LF-17 and LF-29 are recorded as **UNRESOLVED**. They share a property: **each requires an external observer, an external payer, or an external capacity that the organisation does not yet have.** No further architectural elaboration closes them. **They close only with scale, money, or honesty about the stage the organisation is actually at.**

---

# PART 44 — THE FIFTEEN LEADERSHIP MEASUREMENTS

## 44.1 Constraints on the fifteen

**[P]** The brief requires **exactly fifteen** leadership measurements. Four constraints govern their selection:
1. **No invented numbers.** Every threshold is `PROPOSED — REQUIRES PILOT VALIDATION` or `UNKNOWN — MEASURE IN PILOT`.
2. **Every measurement must have a named consumer and a consequence route** (Rule D-53). A measurement nobody acts on is retired (Rule D-65).
3. **No measurement may rank an individual** (**[S-C: §23.2]**; Rule D-63).
4. **Every measurement must be producible on paper by one team without technology** (**[S-B: §40]**), or be marked `NOT TESTABLE AT PILOT SCALE` (Rule D-131).

## 44.2 LM-1 … LM-15

| ID | Measurement | Definition / method | Data source | Cadence | Owner | Threshold | Must never be used to |
|---|---|---|---|---|---|---|---|
| **LM-1** | **Succession coverage** | Covered roles at SS-4 or SS-5 ÷ covered roles, per unit and in aggregate | SS state records §11.2 | Per RV-3 cycle | HR + City owner | `PROPOSED — REQUIRES PILOT VALIDATION`; **100% for mandatory-SS-4 roles is a gate, not a target** | Rank a leader; compare units publicly |
| **LM-2** | **Continuity exercise rate** | Covered roles whose continuity route was **actually exercised** in the cycle ÷ covered roles | CT-A/CT-B records §38.5; Rule D-122 | Annual | Audit | `UNKNOWN — MEASURE IN PILOT` | Assess an individual |
| **LM-3** | **Decision-record completeness** | Consequential decisions with a complete M1 record (what, why, who, when, expected) ÷ consequential decisions | M1 register **[S-A: A-15]** | Monthly | Audit | `PROPOSED`; **incompleteness above a stated level voids the decision's appeal-resistance, not the decision** | Punish a leader for recording honestly |
| **LM-4** | **Time-to-fill a vacancy** | Days from vacancy declaration to appointment, by role class and level | **[S: Ch.11]** lifecycle timestamps | Per vacancy | HR | `UNKNOWN — MEASURE IN PILOT` | Pressure a selection — **speed is never a tie-break (§10.4 prohibited tie-breaks)** |
| **LM-5** | **Interim duration** | Days a role is held under TL-1/TL-2/TL-3, and count of extensions | Delegation records **[S: Ch.22]** | Monthly | HR + Audit | `UNKNOWN`; extensions require recorded reason (GF-29) | Justify converting an interim to permanent (Rule D-32) |
| **LM-6** | **Leadership load distribution** | Share of role-holders in each LLI band, per unit, aggregate only | Workload ledger §24.1 | Per RV-2 cycle | City owner | Bands, not targets (Rule D-63) | Assess, rank or penalise any individual (Rule D-76) |
| **LM-7** | **Dependency exposure** | Count of DEP-C roles, absolute; and share of covered roles in each LDI band | LDI inputs §38.2 | Per RV-3 cycle | City owner + Audit | **DEP-C count is reported absolutely, never as a percentage** | Assess the person holding the role (Rule D-123) |
| **LM-8** | **Opportunity-allocation pattern** | Distribution of evidence-generating opportunities (visible projects, delegations, training places, external representation) within a unit, aggregate | Rule D-116 record | Per cycle | Audit | No target — **a pattern-detection instrument only** | Identify or profile an individual |
| **LM-9** | **Complaint and appeal volume, by channel and outcome** | Counts by CR-1…CR-4 channel, by level, and by outcome class; **including zero-count units flagged as anomalous** | Part 18 records | Monthly aggregate | Audit + Integrity Line | **Zero is a warning sign, not a success** (§17.3 Q7) | Assess a leader negatively for having complaints, or positively for having none |
| **LM-10** | **Appeal outcome rate** | Successful appeals ÷ appeals decided, **by original decision-maker**, aggregate with suppression | §18.3 records | Annual | Audit | A high rate against one decision-maker escalates **[S: App. E]** | Penalise an appellant (Rule D-57) |
| **LM-11** | **Honest-reporting latency** | Interval between a failure occurring and the unit reporting it, and the share of failures reported by the unit **before** external discovery | Incident records **[S-A: A-09]**; Part 8 §8.6 | Monthly | Safety + Audit | `UNKNOWN — MEASURE IN PILOT` | Punish the reporter — **latency is an organisational measure** |
| **LM-12** | **Governance-hour load** | `H_gov` per team per month, against `σ_max` | **[S-B: §25, §26.1]**; workload ledger | Monthly | City owner | The source range **8–40 h/team/month** is the observation window, not a target; **`σ_max` is the ceiling** | Compare teams punitively |
| **LM-13** | **Leadership-cost ratio** | Itemised leadership allocation (Rule D-69) as a share of the unit's worker-compensation total | Payment records **[S: Ch.19 step 13]**; **[S-B: §24]** | Quarterly | Funds + Audit | **`m_lead` is `NOT FINAL`; no value asserted** | Determine any individual's pay |
| **LM-14** | **Pipeline throughput** | Count of members at each PL-0…PL-6 stage, per unit and aggregate; and count of Gate R passes | Part 14 records | Per cycle | HR | No target (Rule D-37: density is reported, never targeted publicly) | Set a recruitment quota — **[S-C: H-03]** |
| **LM-15** | **Institutional independence counts** | The four annual test integers: **absence, attribution, dissent, successor** | **[S-A: A-16]**; Rule D-94 | Annual | Audit + governance body | **"A zero count is a warning sign"** **[S-A: A-16]** — verbatim | Rank units; assess individuals |

## 44.3 What the fifteen deliberately exclude

| Excluded | Why |
|---|---|
| Any individual performance score | **[S-C: §23.2]** — a person is never scored |
| Follower counts, views, engagement | **[S: Ch.25]** prohibition |
| Volunteer headcount | **[S: Ch.25]** prohibition; volunteer **reliability** is an existing team metric, not a leadership measurement |
| Team size | The brief: the largest team proves nothing |
| Revenue | The brief: the highest-revenue person proves nothing; revenue **quality** is an existing team metric **[S: App. A §18.3]** |
| Training completion counts | **[X]** training alone did not improve retention; completion is not capability |
| Certification counts | Rule D-66 — credentials confer nothing; counting them creates a paper mill incentive (SI-3) |
| Any wellbeing or burnout score | Rule D-63 bands only; Rule D-76 no individual consequence |
| Any measure of loyalty, commitment or attitude | Virtue judgements are how favouritism is expressed (§35.1) |
| Founder-approval frequency | GF-24 |

## 44.4 Pilot testability

| Testable by one team on paper | Not testable at pilot scale |
|---|---|
| LM-3, LM-4, LM-5, LM-6, LM-7, LM-11, LM-12, LM-13, LM-15 (partially) | **LM-1** (needs covered roles at scale), **LM-2** (CT-C needs a City), **LM-8** (needs a population for aggregate pattern), **LM-9/LM-10** (needs volume and suppression-safe cells), **LM-14** (needs multiple units), **LM-15** absence/attribution tests (need an apex) |

**[P]** Per Rule D-131, the not-testable items are recorded in **Annexure I** with `NOT TESTABLE AT PILOT SCALE` and a stated minimum population. **They are not satisfied by approximation.**

---

# PART 45 — LEADERSHIP DECISION REGISTER & UNRESOLVED ITEMS

## 45.1 Carried decisions — LDR-C

**[A]** Every leadership-relevant decision already taken in the source hierarchy, reproduced with its status. **Nothing here is reopened.**

| ID | Decision | Status | Source |
|---|---|---|---|
| **LDR-C01** | "Leadership is earned through performance" | **APPROVED ARCHITECTURE** | **[S: Const. Art.4]** |
| **LDR-C02** | "Give greater responsibility only to those who have earned greater trust"; "serve without expecting reward" | **APPROVED** | **[S: Const. Art.2]** |
| **LDR-C03** | "Greater responsibility requires greater trust" | **APPROVED** | **[S: Const. Art.7]** |
| **LDR-C04** | Conduct: warning → removal | **APPROVED** | **[S: Const. Art.8]** |
| **LDR-C05** | AI may recommend; humans decide; AI cannot autonomously make consequential HR, wage, legal, safeguarding, safety, major fund or leadership decisions | **APPROVED** | **[S: Const. Art.12]** |
| **LDR-C06** | "Performance is monthly and multidimensional" | **APPROVED** | **[S: Const. Art.14]** |
| **LDR-C07** | "Best Mohalla Team can become City Head Team; best City Head Team can become State Head Team; best State Head Team can receive National Team opportunity. Safeguards require approval" | **APPROVED** | **[S: Const. Art.15]** |
| **LDR-C08** | Audit is a standing function; the Auditor is "review only; not operational commander" | **APPROVED** | **[S: Const. Art.16; Ch.23]** |
| **LDR-C09** | Eleven role families, each with purpose, authority, limits, inputs, outputs, metrics, training, reporting and **succession** | **APPROVED** | **[S: Ch.9]** |
| **LDR-C10** | Universal role ladder: Primary → Sub-Role → Coordinator → Supporting; "a Sub-Role is a delegated operational position, not an automatic transfer of all authority" | **APPROVED** | **[S: Ch.10]** |
| **LDR-C11** | State A = nine functions; "small size never removes safety, HR verification, finance integrity or evidence duties" | **APPROVED** | **[S: Ch.10]** |
| **LDR-C12** | 13-step vacancy lifecycle; six statuses; non-selected member may apply again | **APPROVED** | **[S: Ch.11]** |
| **LDR-C13** | 12-step member lifecycle; HR record; ten training categories | **APPROVED** | **[S: Ch.12]** |
| **LDR-C14** | 9-step team growth with an autonomy-readiness gate | **APPROVED** | **[S: Ch.13]** |
| **LDR-C15** | Support-first failure recovery; six failure types; leadership failure → coaching + deputy → replacement/dynamic succession | **APPROVED** | **[S: Ch.14]** |
| **LDR-C16** | Waterfall priority order: worker compensation → statutory → direct costs → founder compensation → organisation fee → reserves → social impact → residual; strict segregation | **APPROVED — THE CONTROL** | **[S: Ch.18]** |
| **LDR-C17** | Four distinct finance hands | **APPROVED** | **[S: Ch.18]** |
| **LDR-C18** | Database fields including `designated_sub_role_id`, `delegated_authority`, `permission_profile`, `financial_permission_profile`, `data_access_profile`, `performance_requirements / succession_status`, `appointment_date / review_date`, `delegation_start_date / delegation_end_date`; "one role has one primary holder" | **APPROVED** | **[S: Ch.22]** |
| **LDR-C19** | Six dashboards × five cadences; monthly = performance and leadership | **APPROVED** | **[S: Ch.24]** |
| **LDR-C20** | Six-step performance process; eight anti-gaming controls; "raw revenue, follower count, social-media views, volunteer count, application count or raw activity count cannot determine leadership" | **APPROVED** (weights PROPOSED) | **[S: Ch.25]** |
| **LDR-C21** | Six-step dynamic leadership transition; safeguards; "a high score is void if fraud, safety breach or manipulation is found"; "opportunity is not an automatic personal entitlement" | **APPROVED** | **[S: Ch.26]** |
| **LDR-C22** | Approval & delegation matrix: role promotion, suspension, serious-misconduct removal, leaderboard finalisation, leadership transfer, platform permission change | **APPROVED** (serious-misconduct procedure PROPOSED) | **[S: App. E]** |
| **LDR-C23** | Leader paid in the same framework with a higher allocation; "does not invent the exact multiplier"; must be transparent, capped or bounded, justified by verified leadership work rather than status alone | **APPROVED principle** | **[S: App. A §15.3]** |
| **LDR-C24** | Autonomy is "earned freedom inside central standards"; seven boundaries including honest reporting of failures | **APPROVED** | **[S: App. A §16]** |
| **LDR-C25** | Metric specifications including "adjusted for difficulty", project completion quality "not just count", delivery margin awareness "do not reward underreported costs", reconciliation accuracy with separation of duties and random audits | **APPROVED** | **[S: App. A §18.3]** |
| **LDR-C26** | Reserved matters: constitutional/Tier-1 amendment; mission, name, brand, entity structure; assets, reserves, social-impact fund; dissolution, merger, restructuring; permanent CEO appointment; A-08 DO-NOT list; waterfall priority order | **v1.3-A** | **[S-A: A-14 §13.3]** |
| **LDR-C27** | Dual custody of credentials; minimum two authorised signatories so worker compensation can be paid during an apex vacancy | **v1.3-A** | **[S-A: A-14 §13.4]** |
| **LDR-C28** | Annual unannounced 72-hour continuity test at apex | **v1.3-A** | **[S-A: A-14 §13.8]** |
| **LDR-C29** | Seven memory instruments M1–M7 | **v1.3-A** | **[S-A: A-15]** |
| **LDR-C30** | Four annual institutional tests: absence, attribution, dissent, successor; "a zero count is a warning sign" | **v1.3-A** | **[S-A: A-16]** |
| **LDR-C31** | Protection DO-NOT list; binds at every level | **v1.3-A** | **[S-A: A-08]** |
| **LDR-C32** | Data classification C1–C4; necessity test; access separation; sealed categories with case-scoped access and the two-person rule; prohibited uses | **v1.3-A** | **[S-A: A-17…A-20]** |
| **LDR-C33** | `C_lead = C_wc_base × m_lead` with `m_lead` unresolved; "success tax on success"; B-18 six mechanisms; B-19 Local Interim Authority Order | **v1.3-B** | **[S-B: §24]** |
| **LDR-C34** | `H_gov` governance hours; GB-1…GB-6; "HR/Verification, Funds, Safety — exactly the three unpopular control roles" | **v1.3-B** | **[S-B: §25]** |
| **LDR-C35** | `σ_max` control budget; MVC-1…MVC-11; control-budget rule; City divisor `H_gov_per_team(K)`; B-21 City Shared Services Contract; `K_min` | **v1.3-B** | **[S-B: §26]** |
| **LDR-C36** | One pilot: one mohalla team, no technology, B-P-01…B-P-14 | **v1.3-B** | **[S-B: §40]** |
| **LDR-C37** | Nine-level participation spectrum; recruitment never at the moment of vulnerability; seven refusal rights; six endpoints | **v1.3-C** | **[S-C: H-02, H-03, H-17, §8.2]** |
| **LDR-C38** | Six recognition instruments, never collapsed into one leaderboard; performance measurement scoped to teams/cohorts and instruments 4 and 6 only; "a person is never scored" | **v1.3-C** | **[S-C: H-08, §23.1, §23.2]** |
| **LDR-C39** | Contribution record CR-1…CR-4 limits; AC-1…AC-11; CK-1…CK-7; MLM-1…MLM-7; SA-1…SA-7 | **v1.3-C** | **[S-C: §24, §25, §44]** |
| **LDR-C40** | "No instrument may describe leadership as a higher form of service" | **v1.3-C** | **[S-C: §8.4]** |
| **LDR-C41** | Specialist ladder H-11 S1…S6; twelve domains with hard limits; "a path with no economic expression is a hobby"; Elder/Mentor excluded from RBAC command and from scoring, available from L3 upward; Level 7 Leader, Level 8 Builder endpoint | **v1.3-C** | **[S-C: §6.9, §6.10, §47]** |
| **LDR-C42** | Local-hero problem and four charismatic-leader guards | **v1.3-C** | **[S-C: §45]** |
| **LDR-C43** | Stage model: Leadership ○ at S0, ◐ at S1–S2, ● from S3; twenty-function table — only Safety and Finance must be ● early | **Stress test** | **[S-ST: §23.1, §23.2]** |
| **LDR-C44** | M8 cohort and measurement controls; M9 succession and certification controls; M10 Integrity Line, ombuds, non-retaliation, skip-level, field immersion | **Stress test** | **[S-ST: §9]** |

## 45.2 Unresolved items carried forward — unchanged

**[A]** Rule 2 requires these to be carried unresolved. **This document resolves none of them.**

| ID | Item | Source status | Carried to | Note |
|---|---|---|---|---|
| **LDR-U01** | **CEO vs National Council authority** | `UNRESOLVED` **[S: Ch.33; Ch.4]** | Part 34, Part 52, Annexure J | **The largest governance gap.** Seven reserved matters exist; the body holding them is undetermined. Rule D-113 provides an interim procedure only |
| **LDR-U02** | **Leader multiplier `m_lead`** | `NOT FINAL` **[S: Ch.33; App. A §15.3]** | Part 23, Part 39 | **No value proposed.** Rule D-70 supplies the bounding mechanism |
| **LDR-U03** | **Leaderboard weights 20/15/15/15/10/10/10/5** | `PROPOSED` **[S: Ch.25; Ch.33]** | Part 6, Part 7 | **Preserved verbatim, unaltered.** Rule D-61 declines to add a ninth weighted dimension |
| **LDR-U04** | **Leadership transition rules** | `NOT FINAL` **[S: Ch.33]** | Part 10, Part 11, Part 12 | LG-series, PT-series and TL-series are **proposals**, not resolutions |
| **LDR-U05** | **Team readiness threshold** | `NOT FINAL` **[S: Ch.33]** | Part 3, Part 7, Part 40 | PG gates are structural, not numeric |
| **LDR-U06** | **Minimum staffing thresholds** | `NOT FINAL` — "no final numbers invented" **[S: Ch.33]** | Part 26 | `n_min` specified as a condition set, not a number |
| **LDR-U07** | **Serious-misconduct procedure** | `PROPOSED` **[S: Ch.33]** | Part 18 §18.5 | RM-1…RM-10 is a proposal |
| **LDR-U08** | **Legal structure under Krytos** | `UNRESOLVED` **[S: Ch.33]** | Part 34, Part 36 | Determines 12A/80G/FCRA applicability **[V]** |
| **LDR-U09** | **Worker classification** | `UNRESOLVED` **[S: Ch.33]** | Part 23, Part 39 | Determines employment-law obligations on removal, improvement plans and pay **[V]** |
| **LDR-U10** | **Data retention** | `UNRESOLVED` **[S: Ch.33; S-A: A-17 P2]** | Part 29, Part 31 | Affects TA-h audit-log retention **[V]** |
| **LDR-U11** | **Whether the leaderboard should be public at all** | Open reconsideration **[S-ST: R5]** | Part 21 §21.8 | **Left open.** A `[P]` recommendation is recorded, not a decision |
| **LDR-U12** | **National Council charter and authority (N19)** | `PROPOSED — REQUIRES FINAL APPROVAL` **[S-A: A-23]** | Part 34 | **Not created here** |
| **LDR-U13** | **Role combination factor `c` and `⌈9/c⌉`** | To be measured **[S-B: §40.2]** | Part 26, Part 38 | `UNKNOWN — MEASURE IN PILOT` |
| **LDR-U14** | **City divisor `H_gov_per_team(K)` shape** | Unresolved **[S-B: §26]** | Part 26, Part 39 | Rule D-91 gates State formation on measuring it |
| **LDR-U15** | **`K_min`** | Unresolved **[S-B: §26]** | Part 26 | — |
| **LDR-U16** | **Founder compensation** | Unresolved **[S: Ch.33]** | Part 23 CT-7 | **The leader-premium comparison is therefore also unresolved** |
| **LDR-U17** | **Economic blueprint** | **Never attached** **[S: App. A §1.1]** | Part 39 | All rupee questions remain open |
| **LDR-U18** | **The 37.5 / 17 / 12 percentages** | **Illustrative only**; "the priority order is the control" **[S: Ch.18]** | Part 23, Part 39 | Never treated as policy |
| **LDR-U19** | **Successor to the founder** | Not named anywhere in the source hierarchy | Part 27 | **This document names no successor** |
| **LDR-U20** | **Apostille of "Sewak Sathi Sanstha" as public name** | `PROPOSED` **[S]** | Part 36 CU-1 | Affects PR-1/PR-6 identity rules |

## 45.3 New decisions proposed by this instrument — LDR-01 … LDR-20

**[P]** All are **PROPOSED** and require approval. Each is separately mergeable.

| ID | Decision proposed | Rule(s) | Reversibility |
|---|---|---|---|
| **LDR-01** | Eligibility and readiness are separate gates with separate evidence, decisions, records and appeals | Part 3 §3.1 | High |
| **LDR-02** | Twenty capability dimensions with gated/scored/monitored/narrative treatment, not one composite | Part 4 §4.3 | High |
| **LDR-03** | Five evidence classes with an admissibility rule per decision type; nine prohibited evidence types | Part 5 | High |
| **LDR-04** | Gates disable the consequences of a score, never payment and never dignity | Part 7 §7.2 | High |
| **LDR-05** | Four performance windows; two-speed scoring; activity cap | Part 8 | High |
| **LDR-06** | Cohorts assigned from records, never elected; four comparison types | Part 9 | High |
| **LDR-07** | Baselines locked once recorded; new-team provisional status with hard expiry | Part 8 §8.5 | Medium |
| **LDR-08** | Six succession states; mandatory states by role class; succession loop | Part 11 | High |
| **LDR-09** | Nine-step promotion transition protocol; Promotion Decision Record; eight tie-breaks and prohibited tie-breaks | Part 10 | High |
| **LDR-10** | Five temporary-leadership instruments, all with automatic expiry; reserved matters excluded absolutely | Part 12 §12.1 | High |
| **LDR-11** | Three tracks plus two endpoints; no track superiority | Part 13 | Medium |
| **LDR-12** | Authority Formation (DV-2) as a distinct development component, assessed out of team | Part 15 §15.3 | High |
| **LDR-13** | Four review types, never merged; 360 rejected as scored, adopted as three decomposed instruments | Part 17 | High |
| **LDR-14** | Succession is a scored dimension via gate plus RV-3, with **no new weight added to the PROPOSED source weighting** | Part 19 §19.2 | High |
| **LDR-15** | Leadership allocation itemised against recorded leadership work; bounded; delivery paid separately | Part 23 §23.3 | Medium |
| **LDR-16** | Playbooks tested, not filed; relational memory captured at transition with consent and minimisation | Part 28 | High |
| **LDR-17** | Transition Access Protocol TA-0…TA-4 and TA-a…TA-h; no overlapping write authority | Part 29 | High |
| **LDR-18** | Goodhart Prohibition List; GF-1…GF-30; two-independent-signal rule | Part 20 | High |
| **LDR-19** | Twelve MVLS items, non-deferrable at any stage; everything else tiered | Part 40 §40.2 | Medium |
| **LDR-20** | Expansion gate XG-1…XG-8; expansion recorded as a cost | Part 14 §14.7 | Medium |

---

# PART 46 — AMENDMENT PACK L-01 … L-40

## 46.1 How to read the register

**[P]** Forty amendments. **The count is a consequence of the Part count, not a target** — the brief forbids creating amendments merely to increase the number, and no amendment here exists without a distinct problem, a distinct affected architecture and a distinct test. **Each is separately mergeable**: adopting L-08 does not require adopting L-26.

**Every amendment carries all twenty mandated fields.**

| # | Field | # | Field |
|---|---|---|---|
| 1 | ID | 11 | Economic burden |
| 2 | Title | 12 | Human burden |
| 3 | Problem | 13 | Data burden |
| 4 | Existing source | 14 | Governance burden |
| 5 | Proposed change | 15 | Dependencies |
| 6 | Exact affected architecture | 16 | Validation required |
| 7 | Reason | 17 | Implementation stage |
| 8 | Benefit | 18 | Reversibility |
| 9 | Risk (NEW risk created) | 19 | Test method |
| 10 | Operational burden | 20 | Status |

**Status vocabulary:** `PROPOSED — REQUIRES APPROVAL` / `PROPOSED — PILOT FIRST` / `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` / `PROPOSED — DEFERRED TO STAGE n`.

## 46.2 Register, part 1 of 2 — L-01 … L-20

| 1 ID | 2 Title | 3 Problem | 4 Existing source | 5 Proposed change | 6 Exact affected architecture | 7 Reason | 8 Benefit | 9 Risk (NEW) | 10 Operational burden | 11 Economic burden | 12 Human burden | 13 Data burden | 14 Governance burden | 15 Dependencies | 16 Validation required | 17 Implementation stage | 18 Reversibility | 19 Test method | 20 Status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **L-01** | Eligibility and Readiness Separation | A person can be legitimately eligible and still be wrong for the role; the source has one 13-step lifecycle and no readiness construct | **[S: Ch.11]**; **[S: Ch.26]** safeguards; **[S: Const. Art.4]** | Two gates: Gate E (may be considered) and Gate R (is ready now), separately evidenced, decided, recorded, appealed | Part 3 §3.1–§3.8; **[S: Ch.11]** steps 3–7; **[S: Ch.22]** `succession_status`; **[S: Ch.26]** safeguard 1 | Eligibility is a fact about records; readiness is a judgement about capability under conditions. Conflating them promotes the qualified and unready | Prevents the most common promotion failure; makes refusal explainable | A second gate can be used to block someone eligible on unstated grounds | +1 assessment per candidate | Assessor time; no new headcount | Candidate faces two processes, not one | Readiness finding is C2/C3, subject-accessible | One additional decision record per candidate | Out-of-team assessor must exist | Organisational-psychology review of the LC model **[V]** | Stage 2 (Stage 1 records the gap) | High — the gates can be merged back | Compare promotion outcomes of Gate-E-only versus Gate-E+R decisions over successive cycles | `PROPOSED — PILOT FIRST` |
| **L-02** | Leadership Capability Model | Seven of twenty capabilities the brief requires are invisible to the existing team score | **[S: Ch.25]**; **[S: App. A §18.3]**; **[S: Ch.9]** metrics column | LC-1…LC-20, each with observable behaviour, evidence class, treatment (GATED / SCORED / MONITORED / NARRATIVE) and failure signature | Part 4 §4.1–§4.7; **[S: Ch.9]** metrics; RV-3 content | A team score measures production; leadership capability is a property of a person under conditions | Makes capability assessable without reducing a person to a number | Twenty dimensions may be applied inconsistently, creating arbitrary outcomes | Assessor training; one rubric per dimension | Rubric authorship, once | Assessors must learn to observe behaviour, not outputs | 20 descriptors stored per role class | Rubric governance and versioning | L-03 evidence classes | Capability-model validation **[V]** | Stage 2 | Medium — dimensions can be retired individually | Inter-rater agreement on a shared evidence set; divergence above a stated level voids the rubric | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **L-03** | Leadership Evidence Model | All evidence is treated alike, so cheap evidence crowds out expensive evidence | **[S: App. F]**; **[S: Ch.25]**; **[S-A: A-15 M1]** | Five classes LE-1…LE-5 with an admissibility rule per decision type, nine prohibited evidence types, correction credit, and a self-assembled portfolio | Part 5 §5.1–§5.7; **[S: App. F]**; **[S: Ch.26]** safeguard 2 | Evidence classes differ in fabrication cost, verification cost and probative value for different decisions | Makes the basis of a decision inspectable and appealable | A candidate with thin records is disadvantaged even where capability is real | Portfolio assembly per candidate | Verification time for LE-3/LE-4 | The candidate must maintain their own portfolio | Portfolio stored per candidate, C2/C3 | Admissibility rulings | L-01; verification capacity | Privacy review of portfolio contents **[V]** | Stage 2 | High | Audit a sample of decisions for use of prohibited evidence; any use falsifies | `PROPOSED — PILOT FIRST` |
| **L-04** | Performance Gate Architecture | A high score confers status even where a non-negotiable obligation was breached | **[S: Ch.25]**; **[S: Ch.26]** voiding rule | PG-1…PG-12 hard gates that disable the consequences of a score, never payment and never dignity | Part 7 §7.1–§7.5; **[S: Ch.26]** transition safeguards; **[S: Ch.25]** step 6 | Some obligations are not tradeable against output | Preserves the source's voiding principle while making it granular and explainable | Gates can be applied selectively to favoured or disfavoured units | One gate check per cycle, mostly automatable | Negligible if automated | A gated team may feel punished; the rule that payment is never disabled mitigates this | Gate outcomes stored per team per cycle | Gate application must be audited by sampling | L-05 windows; L-06 cohorts | None beyond internal audit design | Stage 1 (core gates); Stage 2 (full set) | High — gates can be retired individually | Sample gate applications across units for consistency | `PROPOSED — REQUIRES APPROVAL` |
| **L-05** | Outcome Windows, Confidence and Honesty Scoring | Impact and activity are measured on one monthly clock, so slow outcomes are invisible and fast activity dominates | **[S: Const. Art.14]** monthly; **[S: Ch.24]**; **[S: Ch.15]**; **[S-ST: F-20, M8]** | Four windows W-A activity, W-B outcome, W-C sustainability, W-D correction; two-speed scoring; activity cap AC-1…AC-5; confidence HIGH/MEDIUM/LOW; honesty of failure reporting scored | Part 8 §8.1–§8.6; Part 6 §6.3; **[S: Ch.24]** cadences | Different consequences mature at different rates | Slow outcomes become visible; performative activity is capped | Longer windows delay recognition and may demotivate | Two cadences instead of one for part of the score | None | Waiting for an outcome window is psychologically costly | Window-tagged metrics | Cadence governance | L-06; **[S: Ch.24]** fixed cadences | None | Stage 2 | Medium — windows can be collapsed back | Compare activity-only versus windowed scoring on the same historical data | `PROPOSED — REQUIRES APPROVAL` |
| **L-06** | Cohort Normalisation Architecture | Teams in different conditions are compared directly, so structural advantage reads as capability | **[S: Ch.25]**; **[S-ST: F-19, M8]** | CN-1…CN-7: cohorts assigned from records, never elected; four comparison types; raw and normalised views both retained | Part 9 §9.1–§9.7; **[S: Ch.25]** step 4 | Comparison without normalisation measures context | Makes relative performance meaningful | Normalisation can conceal real failure inside a hard cohort | Computation only | None | Cohort membership may be resented | Cohort assignment stored per team | Cohort definition governance | L-05; L-07 | None | Stage 2 | High | Cohort-shopping detection (GF-20) across cycles | `PROPOSED — REQUIRES APPROVAL` |
| **L-07** | Baseline, Maturity and Provisional Status | A new team is either punished for having no history or permanently excused for having none | **[S: Ch.13]** growth steps; **[S-ST: M8]** improvement-vs-baseline | Baselines locked once recorded; maturity bands; provisional status with a hard expiry on newness | Part 8 §8.5; Part 9 §9.6 | Improvement cannot be measured without a fixed starting point | New teams are neither punished nor excused indefinitely | A team may delay recording a baseline to choose a favourable one | One baseline event per team | None | Provisional status must be explained to the team | Baseline record, immutable | Baseline disputes route to CR-1 | L-05; L-06 | None | Stage 2 | High | Count of baseline restatements; any restatement is an anomaly | `PROPOSED — REQUIRES APPROVAL` |
| **L-08** | Succession State Model | The source stores a succession pathway, which is a description, not a state; nobody knows today whether a role is coverable | **[S: Ch.22]** `succession_status` "ready/acting/nominated"; **[S: Ch.9]** succession column; **[S-A: A-16 test 4]**; **[S-B: B-18]** | SS-0…SS-5 states; mandatory state by role class; succession as a standing loop; four institutional tests generalised to every level | Part 11 §11.1–§11.9; **[S: Ch.22]**; **[S: Ch.9]**; continuity dashboard §12.6 | A pathway cannot be audited; a state can | Makes institutional fragility visible before it becomes a crisis | SS states can be recorded optimistically to satisfy a report | One state field per covered role | None | Being recorded as SS-0 may feel like a personal criticism; Rule D-123 forbids that reading | One enum per role | Aggregate reporting and Rule D-108 suppression | L-01 Gate R; L-20 testing | None | Stage 1 | High | CT-A/CT-B exercise results versus recorded state; divergence is the finding | `PROPOSED — REQUIRES APPROVAL` |
| **L-09** | Promotion Transition Protocol and Decision Record | The source's six-step transition does not protect the sending team and produces no reasoned record | **[S: Ch.26]**; **[S: Const. Art.15]**; **[S-B: B-18, §24.2]**; **[S-ST: F-24]** | PT-1…PT-9 including successor-before-transition, bounded overlap, bounded mentorship, promotion-cohort reporting; Promotion Decision Record with mandatory fields; eight tie-breaks and a prohibited-tie-break list; downward movement and dignified exit; return route | Part 10 §10.1–§10.11; **[S: Ch.26]** steps; **[S-B: B-18]** | Promotion currently transfers a person and destroys a team | The winning team survives winning; the decision becomes explainable and appealable | Overlap and mentorship cost real hours at the worst moment | Overlap period; mentorship period | **[S-B: B-18(6)]** promotion recorded as a cost — the cost is now visible and unfunded | The outgoing leader carries two roles during overlap | Decision record per promotion | Transition governance | L-01; L-08; L-17; **[S-B: B-18]** | Employment-law review of downward movement **[V]** | Stage 2 | Medium | Count of sending units below D-control 2 cycles after a promotion | `PROPOSED — REQUIRES APPROVAL` |
| **L-10** | Temporary Leadership Instruments | Interim and emergency authority exist in the source only at apex and only implicitly | **[S-A: A-14 §13.3–§13.6]**; **[S-B: B-19]**; **[S: Ch.22]** delegation dates | TL-1…TL-5 with scope, start, end condition, authority limits and review requirement; reserved matters excluded absolutely; emergency non-conversion; four irreducible capabilities with tiered redundancy | Part 12 §12.1–§12.8; every level's authority record | Undocumented interim authority is the mechanism by which emergencies become coups | Any absence is survivable; no temporary authority becomes permanent | A named deputy may be treated socially as the permanent holder, and TL-1 renewals may drift into an unwritten standing arrangement | Writing and maintaining an Interim Authority Order per unit | Playbook and order authorship | A named deputy carries a standing obligation | Delegation records with dates | Renewal decisions are governance acts | L-08; **[S-A: A-14]**; **[S-B: B-19]** | Legal review of authority during incapacity **[V]** | Stage 1 (MVLS-7) | High | CT-C unannounced test; renewal counts (GF-28, GF-29) | `PROPOSED — REQUIRES APPROVAL` |
| **L-11** | Triple Career Architecture | The only upward path is positional and arithmetically scarce, so the most capable leave | **[S-ST: F-24]**; **[S-C: §6.9 L8, §6.10, §47, §8.2]**; **[S: Ch.10]** | Three tracks (Leadership, Specialist, Builder) plus two endpoints (Contributor, Elder/Mentor); no-track-superiority rule; SP-1…SP-6 with authority ceilings; expert-retention rule | Part 13 §13.1–§13.7; **[S-C: H-11]** extended; RBAC **[S: Ch.23]** | A ladder with `L_pos/K` prizes cannot retain people; scope and skill can | Useful population grows without management population growing | A specialist ladder can become a shadow hierarchy | Authority ceilings must be enforced in RBAC | Specialist engagement may need priority-3 supplier treatment | People who wanted leadership may read the specialist track as rejection | Credential records | SP-3 verifier assignment governance | **[S-C: §47]**; RBAC changes | None | Stage 3 (SP-1/SP-2 from Stage 2) | Medium | Attrition of high-LE-2 members before and after the track exists | `PROPOSED — REQUIRES APPROVAL` |
| **L-12** | Development Programme and Authority Formation | The source trains role competence but never trains the holding of authority over people | **[S: Ch.12]** ten categories; **[S: Ch.14]** coaching + deputy; **[S-B: B-18(3)]**; **[S-ST: M9]** | DV-1…DV-5, of which DV-2 Authority Formation and DV-4 Structured Scenario are new; twelve authority capabilities AF-C1…AF-C12 with demonstration methods; apprenticeship rules; mentorship as paid work | Part 15 §15.1–§15.5; **[S: Ch.12]** extended; workload ledger | Capability to decide, refuse and record is not a by-product of role training | Produces people who can hold authority without abusing it | Scenario assessment can feel artificial and can be performed rather than lived | Assessor time per candidate | Paid mentoring and assessment time | Being assessed on refusals is uncomfortable | Scenario records, C3 | Out-of-team assessment governance | L-01; L-03; assessor supply | Organisational-psychology validation of the twelve capabilities **[V]** | Stage 2 | High | Predictive validity: do DV-2 outcomes correlate with later RV-3 findings | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **L-13** | Review Types and Decomposed 360 | One monthly process is asked to do measurement, development, authority change and discipline; conventional 360 fails in small teams | **[S: Ch.24]**; **[S: Ch.25]**; **[S: App. E]**; **[S: Ch.22]** `review_date` | RV-1…RV-4 never merged; reviewer independence, skip-level review, declared burden, consequence-route requirement; 360 rejected as scored and adopted as F-360a named witness statements, F-360b functional peer input, F-360c downward experience survey | Part 17 §17.1–§17.6; **[S: Ch.24]** cadences; **[S: App. E]** review authorities | Merging review types makes a score a threat and a complaint a performance issue | Each review has one job, one standard and one appeal route | A named witness statement creates real social exposure for the witness inside a small unit | Four review types is more scheduling than one | Reviewer hours, declared under Rule D-52 | Being asked for a named witness statement is socially costly | Review records with subject response | Reviewer-independence governance | L-02; L-03; L-23 | Privacy review of witness statements **[V]** | Stage 2 | High | Count of review findings that changed a decision (Rule D-53 test) | `PROPOSED — REQUIRES APPROVAL` |
| **L-14** | Succession as a Performance Dimension | A leader who delivers everything and leaves nothing behind is currently recorded as excellent | **[S: Ch.9]** succession column; **[S: Ch.22]** combined field; **[S: Ch.14]**; **[S-B: B-18]** | SD-a coverage operates as a gate; SD-b readiness, SD-c exercised delegation, SD-d transfer quality and SD-e teaching output are assessed at RV-3. **No new weight is added to the PROPOSED source weighting** | Part 19 §19.1–§19.4; Part 7 gates; Part 17 RV-3 | If succession is not part of performance, it is nobody's job | Makes replaceability a duty rather than a virtue | Fake successors (GF-23) | One gate check plus RV-3 content | Paid development time (Rule D-73) | A leader may resent being measured on someone else's readiness | SS state and delegation records | Gate application audit | L-01; L-08; L-20 | None | Stage 2 | High | Correlation between SD-a gate failures and later continuity-test failures | `PROPOSED — REQUIRES APPROVAL` |
| **L-15** | Leadership Compensation Structure | The source requires a bounded, work-justified leader allocation but supplies no mechanism, so a status premium is the default | **[S: App. A §15.3]**; **[S: Ch.18]**; **[S-B: §24]**; **[S: Ch.33]** `NOT FINAL` | Leadership work itemised and paid; allocation bounded and capped; delivery paid separately; no premium for indispensability; succession development paid; compensation never a score. **No value proposed** | Part 23 §23.1–§23.4; payment sheet **[S: Ch.19 step 13]**; formula versioning | "Justified by verified leadership work rather than status alone" requires itemisation to be auditable | The premium becomes defensible, bounded and inspectable | Itemisation creates an incentive to inflate leadership-work claims | One itemisation per payment cycle | The bounded premium itself; **[U]** on value | A leader may feel their real burden is not itemisable | Itemised hours in the ledger | Audit of itemisation against records | L-22 ledger; **[S-B: §24]**; formula approval | Tax and employment-law review **[V]**; **`m_lead` requires source-hierarchy approval** | Stage 2 | Medium | Compare itemised leadership hours against observed leadership activity | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **L-16** | Role Playbook and Relational Memory | Tacit and relational knowledge leaves with the leader and is in no record | **[S-A: A-15 M5, M6, M7]**; **[S: Ch.9]**; Rule D-34 substitution logic | PB-1…PB-10 for every covered role, tested not filed; relational memory captured at transition with consent and minimisation; memory minimum at Stage 0–1 | Part 28 §28.1–§28.4; Rule D-34; KT pack §12.8 | A playbook costs hours once; a redundant person costs hours continuously | Small teams get knowledge redundancy they cannot staff | A playbook describes what its author believes, which may be wrong | Authorship, once per role; periodic review | Authorship hours — the largest single memory cost | Writing down one's own role feels like making oneself disposable | Playbook under version control (M2) | Playbook review governance | L-10; L-08; Rule D-96 testing | Privacy review of relational-memory contents **[V]** | Stage 1 (PB-1…PB-6); Stage 2 (PB-7…PB-10) | High | CT-B: a non-holder performs a function from the playbook alone | `PROPOSED — REQUIRES APPROVAL` |
| **L-17** | Transition Access Protocol | The transition window is the only period in which keeping things running and leaving access in place are indistinguishable | **[S: Ch.23]**; **[S: Ch.22]** profiles and delegation dates; **[S: App. E]** technology admin; **[S-A: A-14 §13.4]** | TA-0…TA-4 phases; TA-a…TA-h checklist; no overlapping write authority; bounded advisory access; suspended and removed holders hold nothing; dual confirmation for consequential instructions; sealed audit log | Part 29 §29.1–§29.6; RBAC **[S: Ch.23]**; **[S: Ch.22]** | Access that survives authority is unaccountable authority | Every transition becomes secure without slowing handover | Dual confirmation adds friction to urgent payments | One checklist per transition | Technology-admin time | An outgoing holder may experience revocation as distrust; TA-1 read-only access mitigates | Permission diffs and logs | Audit owns TA-h | L-10; **[S-A: A-14]**; platform capability | Security review **[V]** | Stage 1 (MVLS-11) | High | Count of post-transition access anomalies | `PROPOSED — REQUIRES APPROVAL` |
| **L-18** | Anti-Gaming Register and Goodhart Prohibition List | The source prohibits raw counts from determining leadership but does not enumerate the gaming vectors those prohibitions imply | **[S: Ch.25]** eight anti-gaming controls; **[S: App. A §18.3]**; **[S-ST: M8]** | GF-1…GF-30 with incentive, behaviour, detection signal and minimum correction; a Goodhart Prohibition List of measures that may never be a target, tie-break or gate input; the two-independent-signal rule | Part 20 §20.1–§20.4; **[S: Ch.25]**; Part 10 tie-breaks; Part 7 gates | Every measure that becomes a target stops being a measure | Gaming is named, detected and corrected minimally rather than redesigned around | Detection signals themselves become targets | Anomaly monitoring per cycle | Computation only | Being monitored for gaming is demoralising for honest teams; the register is applied to patterns, not to people | Anomaly flags | Audit sampling governance | L-05; L-06; L-04 | None | Stage 3 for the full register; Stage 1 for GF-1, GF-2, GF-11 | Medium | Count of confirmed gaming events and of false positives | `PROPOSED — REQUIRES APPROVAL` |
| **L-19** | Cult Resistance Controls | Affection for a leader converts into unaccountable authority through instruments: recognition, attribution, symbolism, exemption from assessment | **[S-C: §45, §8.4, SR-2, §6.10]**; **[S-A: A-16 §15.4]** | CU-1…CU-10: no person as organisational identity; no loyalty object; attribution discipline; dissent safe and counted; replaceability as a duty; absolute recognition; founder bound; no higher form of service; dignified exit; symbols belong to the work | Part 36 §36.2; Part 21 §21.7; Part 27 §27.4 | Cults form through instruments, not through feelings; remove the instruments and affection remains harmless | The organisation can be loved without being captured | Controls may read as coldness to a genuinely admired leader | Counting spokespersons and attributions | Negligible | Refusing an oath or a title may disappoint people | Attribution and spokesperson records | Annual test reporting (Rule D-94) | L-24; **[S-A: A-16]** | None | Stage 2 | Medium | The four annual test counts, especially dissent: zero is a warning | `PROPOSED — REQUIRES APPROVAL` |
| **L-20** | Continuity Testing | Written continuity instruments are assumed to work; false continuity is invisible until exercised | **[S-A: A-14 §13.8]** 72-hour apex test; **[S-A: A-15 M5]** | CT-A delegation exercise, CT-B playbook exercise, CT-C unannounced 72-hour test; unexercised counts as absent; a failed test is a governance finding, not a person finding | Part 38 §38.5; Rule D-122; LDI input I-7; LM-2 | The three commonest false-continuity failures are permission, mandate and credential — all invisible on paper | Continuity becomes a measured property rather than a documented hope | Unannounced testing can disrupt real service | One exercise per unit per cycle | Exercise hours | Being tested without warning is stressful; the no-person-finding rule mitigates it | Exercise results | Audit owns CT-C | L-08; L-10; L-16 | None | Stage 2 (CT-A/B); Stage 3 (CT-C below apex); apex annually from Stage 1 | High | Pass rate and findings per test | `PROPOSED — REQUIRES APPROVAL` |

## 46.3 Register, part 2 of 2 — L-21 … L-40

| 1 ID | 2 Title | 3 Problem | 4 Existing source | 5 Proposed change | 6 Exact affected architecture | 7 Reason | 8 Benefit | 9 Risk (NEW) | 10 Operational burden | 11 Economic burden | 12 Human burden | 13 Data burden | 14 Governance burden | 15 Dependencies | 16 Validation required | 17 Implementation stage | 18 Reversibility | 19 Test method | 20 Status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **L-21** | Minimum Viable Leadership System | This document specifies more controls than a Stage 0–1 team can afford inside `σ_max` | **[S-B: §26.1, §26.3, B-20 MVC-1…MVC-11]**; **[S: Ch.10 State A]** | MVLS-1…MVLS-12, non-deferrable at any stage; everything else tiered; a deferral is a recorded risk; a simplification obligation on every addition | Part 40 §40.2–§40.3; Rule D-80; Rule D-110; Rule D-128 | A control that cannot be afforded is not a control; it is a debt | The smallest safe leadership system is explicit and achievable | MVLS may be treated as sufficient at higher stages, freezing maturity | Twelve items, all cheap by design | Within `σ_max` by construction | A team must actually operate twelve things | None new | Tier governance | L-08; L-10; L-16; L-17; **[S-B: §26]** | None | Stage 0–1 immediately | Medium — items can be added, never removed below twelve | PS-1: all twelve operate for a full cycle | `PROPOSED — REQUIRES APPROVAL` |
| **L-22** | Pipeline and Expansion Gate | Growth is authorised on demand, not on leadership supply, so expansion hollows out the organisation that expands | **[S-B: §24.5, §17.2, §26]**; **[S-ST: §23.1]**; **[S: Ch.13]** | PL-0…PL-6 pipeline stages with named bottlenecks; five density measures reported but never publicly targeted; span principles SP-A…SP-E with a declared `span_basis`; expansion gate XG-1…XG-8; expansion recorded as a cost | Part 14 §14.1–§14.7; **[S: Ch.9]** role records; Part 26 | Leader supply is a stock problem; a gate converts it from a hope into a precondition | No unit is authorised that cannot be led, verified, paid or stopped | A gate can be used to refuse growth for reasons unrelated to capability | One gate check per expansion authorisation | Expansion cost entry | A community wanting a team may be told not yet — this must be explained | Density aggregates with suppression | Gate application audit | L-08; L-20; L-28; **[S-B: §26]** | None | Stage 2 | High | Count of expansions followed by a D-control failure in the sponsoring unit | `PROPOSED — REQUIRES APPROVAL` |
| **L-23** | Complaints, Appeals, Improvement and Removal | Four different questions are routinely handled by one route, so a performance disagreement becomes a disciplinary matter | **[S: Const. Art.8]**; **[S: App. E]**; **[S: Ch.14]**; **[S: Ch.11 step 9]**; **[S: Ch.26]** correction window; **[S-ST: M10]**; **[S-C: §44 SA-1…SA-7]** | Four routes CR-1…CR-4 with no route substitution; non-retaliation with reversed burden; interim protection by recusal not suspension; appeal grounds, standing, powers and pending effect; IP-1…IP-7 support-first plans; RM-1…RM-10 removal procedure; no removal from a score | Part 18 §18.1–§18.6; **[S: App. E]**; **[S: Ch.14]** | Each route has a different standard, decision-maker and consequence | A person knows which door to use, and the doors do not merge | A reversed burden of proof on retaliation may produce defensive record-keeping | Intake, triage, panel time | Panel time is the real cost | Complaining is frightening; acknowledgement and protection are what make it possible | Complaint records C4 sealed | Panel governance; Integrity Line independence | L-13; **[S-A: A-20]**; **[S-ST: M10]** | Employment and safeguarding law review **[V]** | Stage 1 (MVLS-9); Stage 2 (full) | Medium | LM-9 volume by channel; LM-10 appeal outcome rate by decision-maker | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **L-24** | Leaderboard Scope and Recognition–Authority Separation | The leaderboard is asked to carry recognition, motivation and selection, and collapses six instruments into one ranking | **[S: Ch.25]**; **[S: App. E]**; **[S-C: H-08, §23.1, §44.3]**; **[S-ST: R5, M8]** | Permitted and prohibited uses enumerated; fatigue mechanisms LF-1…LF-4 with corrections; measurement retirement; recognition confers nothing; six instruments applied to leadership; standing without authority; ceremonies tested against Rule D-40; **R5 left open** | Part 21 §21.1–§21.8; Part 22 §22.1–§22.3; **[S: Ch.25]** | Fusing recognition with authority turns leadership into a prize and recognition into a queue | People can be highly trusted without becoming managers | Removing ranking may reduce short-run motivation | None — this amendment removes work | None | Losing a ranking can feel like losing recognition; absolute instruments replace it | None new | Recognition governance is deliberately minimal | L-18; **[S-C: H-08]** | None | Stage 1 | Medium | Retention of high-LE-2 members; PS-12 operator judgement | `PROPOSED — REQUIRES APPROVAL` |
| **L-25** | Load and Dependency Indices | Overload and single-point dependency are felt but never measured, so both are discovered at exit or at crisis | **[S-B: §25, §26.1, §27.3, §27.5]**; **[S: Ch.22]** | Workload ledger with `H_unrecorded` as the primary signal; LLI in four bands with structural consequences; nine burnout signals, structural only; self-report never penalised; LDI in four bands from ten inputs; mitigation ladder; dependency distinguished from cultivated indispensability | Part 24 §24.1–§24.5; Part 38 §38.1–§38.7 | A band with a consequence is a control; a score with a ranking is a competition | Overload becomes an organisational finding rather than a personal failing | Bands may be under-reported if any individual consequence attaches — hence Rule D-76 forbids it | One ledger entry per role per cycle | Mitigation cost when a band is breached | Declaring exhaustion is difficult; Rule D-77 makes it safe | Ledger fields, C3 | Aggregate reporting with suppression | L-08; L-22; **[S-B: §25]** | Occupational-health review **[V]** | Stage 2 | High | Correlation between L2/L3 readings and subsequent exits or incidents | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **L-26** | AI-Assisted Leadership Boundary | AI outputs will be used in leadership processes, and deferral to a confident output is the predictable failure | **[S: Const. Art.12 APPROVED]**; **[S: Ch.21]**; **[S-A: A-21, A-22]**; **[S-ST: F-29]** | A permitted and prohibited function table; AI-1…AI-8 fairness controls; the stranger test for explainability; no black box in a consequential path; historical bias is never a baseline; bounded development uses | Part 30 §30.1–§30.6 | Art.12 is APPROVED and non-negotiable; everything else is implementation | AI reduces burden without acquiring authority | Recording whether a human followed the AI creates a compliance performance | Provenance capture per output | Model development and versioning | A person judged partly by a machine deserves an explanation they can contest | Input lists and confidence ratings | Model-change governance (M2) | L-02; L-13; platform capability | Algorithmic-audit and data-protection review; DPIA if Significant Data Fiduciary obligations apply **[V]** | Stage 2 | High | AI-7 disparity testing; rate of recorded human deviation from AI input | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **L-27** | Opportunity Fairness and Access | Eligibility is fair on paper and unequal in practice: notice, language, literacy, digital access, time, social permission and knowledge of the route all filter who applies | **[S: Ch.11]**; **[S-C: H-02, H-03, H-17, SR-1…SR-7]**; **[S-A: A-18]** | OB-1…OB-7 access barriers with corrections; access corrections are not favouritism; internal application with a mandatory specific feedback obligation; youth rules without invented ages; AX-1…AX-9 system accessibility; opportunity-allocation recording; the four-affordance route for the unpopular competent person | Part 25 §25.1–§25.6; Part 35 §35.4; **[S: Ch.11]** steps 1–3 | Capability is distributed far more evenly than opportunity to demonstrate it | The pool of applicants stops being a function of social position | Recording opportunity allocation may chill informal mentoring | Translation; oral-intake time | Translation once; offline process | Applying is socially risky; Rule D-81 protects it | Application and outcome records, aggregate | Pattern-audit governance | L-01; L-03; L-13 | Privacy and equality-law review of aggregate reporting **[V]** | Stage 1 (OB-1, OB-2, OB-6); Stage 2 (rest) | High | Applicant-pool composition versus unit composition, aggregate and suppressed | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **L-28** | Staffing, Span and Function Routing | Minimum staffing is `NOT FINAL` and no span-of-control figure exists anywhere in the source | **[S: Ch.10 State A]**; **[S: Ch.33]**; **[S-B: §3.3, §26.4, §40.2, B-21]**; **[S: Ch.18]** | `n_min` specified as a five-condition set with no number; held-versus-routed function table; four permitted span responses with "tolerate it" prohibited; span findings are structural; layer economics by level; the City divisor must be measured before State formation | Part 26 §26.1–§26.4; Part 14 §14.4–§14.5 | Inventing a number would close a `NOT FINAL` item and would probably be wrong | Small teams become viable by routing, not by heroism | Routing creates City dependency, which is LF-29 | Routing agreements per function | City shared-services cost **[S-B: B-21]** | A team may feel it has lost a function it should hold | Routing records (Rule D-89) | Shared-services contract governance | **[S-B: §26.4, B-21]**; L-22 | None | Stage 1 | High | Count of routed functions with no recorded receiver or fallback | `PROPOSED — REQUIRES APPROVAL` |
| **L-29** | Founder Concentration and Institutional Independence | Every control that depends on being applied to the most powerful person will not be, unless the architecture compels it | **[S: Const. Art.3]**; **[S: Ch.33 CEO vs Council UNRESOLVED]**; **[S-A: A-14, A-16]**; **[S-ST: F-14, F-15]** | Founder Recusal Register; the founder may not assess; the four annual tests applied to the founder with counts published internally; public-representation rules PR-1…PR-6; independence as seven structural requirements; interim reserved-matter procedure pending resolution of the UNRESOLVED item | Part 27 §27.1–§27.5; Part 34 §34.1 | Visibility is the only check available where removal is not | The organisation can outlive its founder without a constitutional crisis | The register may be maintained nominally | One register entry per event | Negligible | Being recorded may feel like distrust; the register records acts, not motives | Register, C2 with aggregate publication | Audit owns the register | **[S-A: A-14, A-16]**; L-19 | Corporate-governance and legal review **[V]**; **CEO vs Council must be resolved by the source hierarchy, not here** | Stage 2 | Medium | The four test counts; **zero dissent is the warning** | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **L-30** | Privacy and Data Classification for Leadership Records | Leadership assessment creates new personal data — readiness findings, witness statements, load bands — with no classification | **[S-A: A-17…A-20]**; **[S: Const. Art.6]**; **[S: Ch.23]**; **[S-C: CR-1…CR-4]**; **[X]** DPDP Act 2023 and Rules 2025 | A classification table for every leadership data type; small-cell suppression with the suppression itself reported; the six-condition social-credit test; breach and subject-rights application to transitions | Part 31 §31.1–§31.5; Part 29 §29.6 | A readiness finding about a named person is more sensitive than a team score | The system can assess people without surveilling them | Suppression reduces the information value of small aggregates | Classification work, once | Negligible after authorship | Knowing a readiness finding exists about you is uncomfortable; subject access mitigates it | Field-level classification | Data-governance function | **[S-A: A-17…A-20]**; L-13; L-25 | **Data-protection legal review; DPIA if applicable [V]** | Stage 1 (classification); Stage 2 (disparity reporting) | High | Count of disclosures outside the classification; any is a breach | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **L-31** | Multi-Level Leadership Differentiation | One capability model applied identically at four levels is too vague at the top and too heavy at the bottom | **[S: Ch.4–Ch.8]**; **[S: Ch.10]** four-level catalogue; **[S: Const. Art.15]**; **[S-ST: §23.1]** | Per-level evidence, capability, assessment-independence and succession obligations; staged obligations S0…S5; a deferred control is a recorded risk; ML-1…ML-8 cross-level failure modes | Part 32 §32.1–§32.4; Part 40 §40.3 | Assessment independence is impossible where there is no outside | Each level carries the controls it can actually support | Staged obligations may become permanent deferrals | Per-level configuration | Tiered | A mohalla leader is not asked to do a City leader's paperwork | Stage-tagged obligations | Stage-gate governance | L-02; L-21; **[S-ST: §23.1]** | None | Stage 0–1 onward, tiered | High | Count of deferred controls still deferred two stages later (Rule D-110) | `PROPOSED — REQUIRES APPROVAL` |
| **L-32** | Selection Typology and Democracy of Voice | Promotion, appointment, delegation, succession and recognition are used interchangeably, so nobody knows which act occurred | **[S: Ch.10, Ch.11]**; **[S: App. E]**; **[S: Const. Art.15]**; **[S-C: §8.2, H-17]** | Five acts distinguished by authority, evidence and reversibility; act typing recorded, with ambiguity resolved to the least consequential type; eleven selection methods assessed for fitness; voice rights substituted for selection rights; the efficiency account stated | Part 33 §33.1–§33.4 | An untyped act is always read as the more powerful one | Members get strong voice and the architecture avoids popularity selection | Leaders selected without a vote start with less legitimacy and must earn it | One type field per act | Negligible | Not voting for one's leader may feel undemocratic; §33.3 substitutes real voice | Act-type records | None new | L-01; L-09; **[S-C: H-17]** | None | Stage 1 | High | Count of untyped leadership acts; any is a defect | `PROPOSED — REQUIRES APPROVAL` |
| **L-33** | Governance Bodies, RACI and Interim Reserved-Matter Procedure | Seven reserved matters are specified but the body holding them is undetermined, so a reserved matter in a crisis is either frozen or decided unilaterally | **[S: App. E]**; **[S: Ch.23]**; **[S-A: A-14 §13.3, A-23]**; **[S: Ch.33 UNRESOLVED]** | A full authority map with every unresolved point marked; RACI for sixteen lifecycle activities; a succession authority matrix by SS state; five bodies retained and five refused under Rule D-40; an interim reserved-matter procedure requiring two independent bodies, provisionality and reversibility | Part 34 §34.1–§34.4 | A reserved matter nobody can decide is not protected, it is frozen | Crises do not force unilateral constitutional acts | The interim procedure could be used to avoid resolving the underlying question | One RACI per activity, once | Negligible | Two-body concurrence slows urgent decisions | Decision records | Body governance | **[S-A: A-14]**; **LDR-U01 must eventually be resolved by the source hierarchy** | Corporate-governance and legal review **[V]** | Stage 2 | Medium | Count of reserved matters decided under the interim procedure; a rising count is a finding | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **L-34** | Conflict of Interest and Anti-Favouritism | Favouritism that leaves a record can be controlled; favouritism in the allocation of opportunity cannot, and it determines who later has evidence | **[S: Ch.9]** "Cannot do" boundaries; **[S: Const. Art.2, Art.8]**; **[S-A: A-16]** | A declaration duty before participation, not after; recusal on the matter, not removal from the role; recusal is not suspicion; the founder declares too; twelve anti-favouritism mechanisms operationalised; opportunity-allocation recording; the four-affordance route for the unpopular competent person | Part 35 §35.1–§35.4; Part 3 §3.7 AF-1…AF-12 | Virtue-based ethics clauses are unenforceable and usable; boundary-based ones are not | Favouritism becomes visible to the only actor who can judge it — the team itself | Declaration may be avoided if it is socially costly, hence Rule D-114 | One declaration per matter | Negligible | Declaring a friendship feels like an accusation against it | Declaration records | Register governance and aggregate reporting | L-01; L-13; L-27 | None | Stage 2 | High | Count of decisions with an undeclared conflict discovered later; any is a finding | `PROPOSED — REQUIRES APPROVAL` |
| **L-35** | Anti-Capture Controls | A hierarchical service organisation with local legitimacy, money flows and community trust is attractive to four kinds of captor | **[S-C: MLM-1…MLM-7, AC-1…AC-11, CK-1…CK-7]**; **[S-A: A-08]**; **[S: Ch.16]**; **[X]** BNSS 2023 s.40/s.31/s.43; **[X]** 12A/80G/FCRA conditions | No compensation may depend on another person's participation; VG-1…VG-6 anti-vigilante controls including popular-pressure routing; PC-1…PC-8 anti-political controls preserving members' civic rights while separating capacities | Part 36 §36.3–§36.5 | Each vector has a distinct entry point and needs a distinct structural control | The organisation cannot be converted into a pyramid, a militia or a party machine | Separating personal political activity from organisational role is difficult in a small locality | Declaration and routing | Negligible | A politically active member may feel distrusted; PC-2 protects their rights | Declaration records | Reserved-matter class governance | **[S-A: A-08]**; L-15; L-34 | **Legal, tax and FCRA review [V]; entity structure UNRESOLVED** | Stage 1 (Rule D-118, VG-1…VG-3); Stage 2 (rest) | Low — these should not be reversible | Absence of any participation-linked compensation term; zero VG-5 events | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **L-36** | Crisis Leadership and Incident Review | Crisis is when procedure is most needed and most likely to be abandoned, and hindsight bias then punishes the decisive | **[S-A: A-08, A-09, A-14 §13.6]**; **[S: Ch.14, Ch.16]**; **[S: App. A §16.3]**; **[S: App. E]** Safety Lead immediate action | Standards are not suspended in a crisis, only sequence; a mandatory missing-information field in every crisis decision record; the six failure types mapped to leadership consequences; blameless by default and accountable by record; mandatory independent post-crisis review; six structural sources of resilience | Part 37 §37.1–§37.5 | Without a recorded information state, every reasonable crisis decision looks negligent afterwards | Decisive leaders are protected from hindsight, and the organisation still learns | The missing-information field can be read retrospectively as a self-incrimination, which is why Rule D-121 makes the review blameless by default | One extra field per crisis record | Negligible | Recording what you did not know feels like building a case against yourself | Crisis decision records | Independent reviewer governance | L-10; **[S-A: A-09, A-15 M1]** | None | Stage 1 | High | Count of crisis records with a completed missing-information field | `PROPOSED — REQUIRES APPROVAL` |
| **L-37** | Leadership Economics and Feasibility | The cost of the leadership system is dominated by assessment, development and trainer time — and budget pressure naturally falls on exactly those | **[S-B: §24, §25, §26, §40]**; **[S: Ch.18]**; **[S-C: §47.1]**; **[S: Ch.33]** `NOT FINAL` items | An eighteen-component cost structure; five economic findings EF-1…EF-5; six sustainability tests; unpaid leadership work recorded as an organisational deficit | Part 39 §39.1–§39.4; Part 24 ledger | There is no revenue line for governance or training, so governance is paid from the worker-compensation pool | The system's real cost is visible before it is committed to | Recording a deficit does not pay it, and may institutionalise non-payment | Cost attribution per component | The deficit itself | A leader working unpaid may read the deficit record as an accusation | Itemised hours | Audit of itemisation | L-15; L-22; L-25; **[S-B: §24–§26]** | Tax, employment and accounting review **[V]**; **`m_lead` approval required** | Stage 2 | Medium | EF-5 test: is leadership affordable for a person with no spare capacity | `PROPOSED — REQUIRES PROFESSIONAL VALIDATION` |
| **L-38** | Maturity Model and Simplification Obligation | A maturity claim based on documentation rather than operation is unfalsifiable, and obligation grows monotonically in every governance system | **[S-ST: §23.1, §23.2]**; **[S-B: §26.3]**; **[S-B: B-20]** | MAT-0…MAT-5 maturity levels determined by what a unit actually operates; mapping to the stress-test stage model; the four-question control-budget test; a simplification obligation requiring one retirement for every addition | Part 40 §40.1, §40.4–§40.5 | A level you can claim without operating is not a level | Obligation growth is bounded by construction | The retirement requirement may retire a control that is quietly load-bearing | One maturity assessment per unit per stage | Negligible | Being told your unit is MAT-1 when you feel MAT-3 is deflating; the criteria are operational and inspectable | Maturity assessment records | Stage-gate governance | L-21; L-31; **[S-ST: §23.1]** | None | Stage 1 | Medium | Whether the retirement that funded an addition later correlated with a failure | `PROPOSED — REQUIRES APPROVAL` |
| **L-39** | Pilot Integration and Scope Statement | The leadership claims are precisely the ones a single team cannot test, and a narrow success will be reported as a general one | **[S-B: §40 B-P-01…B-P-14]**; **[S-C: §57]**; brief prohibition on a second pilot | LM-1…LM-15 added to the existing single pilot; a namespace rule separating `P-nn` simulations from `B-P-nn` pilot measurements; twelve falsifiable success conditions; ten fatal failure conditions; seven explicit limits on what the pilot can prove; every claim must state which limit applies | Part 41 §41.1–§41.5; Part 44; Annexure I | No second pilot may be created; the honest alternative is to state what is untestable | Succession, promotion and assessment independence are not falsely validated | Deferring the untestable may postpone learning indefinitely | Fifteen measurements on paper | None — no new site, cohort or timeline | Operating a measurement regime without technology is laborious | Paper records | Pilot governance shared with **[S-B]** and **[S-C]** | **[S-B: §40]**; **[S-C: §57]**; L-01…L-38 | None | Stage 0–1 | High | PS-1…PS-12 and PF-1…PF-10 evaluated at pilot close | `PROPOSED — PILOT FIRST` |
| **L-40** | Leadership Invariants, Local Adaptation and Final Architecture | A national system must hold some things constant and let other things vary, and the boundary between them is not drawn anywhere in the source | **[S: Ch.4]**; **[S-A: A-15 M2, M3]**; **[S-C]** local adaptation; **[S-B: B-21]** | INV-series invariants that may never be adapted; ADAPT-series items that may vary locally through the versioned change-request route; the final architecture assembled as one system with four loops and a master data flow | Part 51 | Without an explicit boundary, local adaptation either ossifies or fragments | A national system that is locally intelligible | The invariant list may be drawn too tightly, preventing legitimate local variation | One change-request route, already existing | Negligible | Local leaders may resent a list of things they cannot change | Versioned standards (M2) | M3 change-request governance | **[S-A: A-15 M2, M3]**; all prior L amendments | None | Stage 2 | Medium | Count of adaptation requests refused on invariant grounds, and whether the refusal was correct | `PROPOSED — REQUIRES APPROVAL` |

## 46.4 Mergeability and sequencing

**[P]** Adoption order, by dependency:

| Wave | Amendments | Precondition |
|---|---|---|
| **W1 — Stage 0–1, immediate** | L-21 (MVLS), L-08 (SS states), L-10 (TL instruments), L-17 (transition access), L-36 (crisis record), L-32 (act typing), L-24 (leaderboard scope) | None. All are paper-executable |
| **W2 — Stage 1–2** | L-01 (two gates), L-03 (evidence), L-04 (gates), L-23 (complaints), L-27 (access), L-28 (routing), L-16 (playbooks), L-39 (pilot) | W1 operating for one full cycle |
| **W3 — Stage 2** | L-02 (capabilities), L-12 (development), L-13 (reviews), L-14 (succession dimension), L-05 (windows), L-06 (cohorts), L-07 (baselines), L-20 (continuity testing), L-25 (LLI/LDI), L-29 (founder), L-30 (privacy), L-33 (governance), L-34 (conflicts) | Out-of-team assessor capacity exists; City routing operational |
| **W4 — Stage 3+** | L-09 (promotion transition), L-11 (three tracks), L-15 (compensation), L-18 (full gaming register), L-19 (cult resistance), L-22 (expansion gate), L-26 (AI boundary), L-31 (multi-level), L-35 (anti-capture), L-37 (economics), L-38 (maturity), L-40 (invariants) | W3 validated; **`m_lead` and CEO-vs-Council resolved by the source hierarchy** |

**[A]** L-09 sits in W4 despite being load-bearing, because a promotion transition protocol cannot be exercised until there is somewhere to promote to — which is §41.2's structural limit, not a prioritisation choice.

---

# PART 47 — CONTRADICTION AUDIT C-D-01 … C-D-20

## 47.1 Method

**[P]** Each item states the two source positions, classifies the relationship as a **TRUE CONTRADICTION** (both cannot hold), a **TENSION** (both can hold but pull apart), or an **APPARENT CONFLICT** (resolvable by reading), and gives the treatment. **No item is resolved by silently preferring one source.** Where a contradiction is real and cannot be resolved within this document's authority, it is carried to Part 45 and Annexure J.

## 47.2 The audit

| ID | Position A | Position B | Class | Treatment |
|---|---|---|---|---|
| **C-D-01** | "Best Mohalla Team can become City Head Team" **[S: Const. Art.15, APPROVED]** | A team is composed of people who have lives, families and locality; moving the team moves the people out of the mohalla | **TRUE CONTRADICTION at the operational level.** The Article is APPROVED and cannot be altered here | **Not resolved.** Part 7 Rule D-17, Part 10 LG-series and Part 14 XG-8 specify what must be true for the Article to be executed without destroying the unit. The interpretive question — does the team move, or does its label move? — is carried to Part 45 as **[U]** |
| **C-D-02** | "Serve without expecting reward" **[S: Const. Art.2, APPROVED]** | The leader is paid in the same framework with a higher allocation **[S: App. A §15.3]** | **APPARENT CONFLICT.** Art.2 addresses motive; §15.3 addresses remuneration for verified work | Both preserved. Rule D-69 ties the allocation to **itemised work**, which is the reading that makes both true: the person does not serve *for* reward, and is *paid for* work |
| **C-D-03** | "Volunteer count … cannot determine leadership" **[S: Ch.25]** | "Volunteer reliability" is a specified metric **[S: App. A §18.3]** | **APPARENT CONFLICT.** Headcount versus reliability are different objects | Both preserved verbatim. GF-9 detects the gaming vector that sits between them |
| **C-D-04** | "Performance is monthly" **[S: Const. Art.14, APPROVED]** | Service outcomes, sustainability and correction mature over quarters and years **[S: Ch.15; S-ST: F-20, M8]** | **TENSION.** Monthly cadence and slow outcomes are compatible only if the monthly process reports on multiple windows | Part 8 four-window model: the **cadence stays monthly** (Art.14 preserved), the **windows differ**. Two-speed scoring **[S-ST: M8]** |
| **C-D-05** | "One role has one primary holder" **[S: Ch.22]** | State A permits role combination; small size never removes duties **[S: Ch.10]** | **APPARENT CONFLICT.** Combination means one person holds several roles, each with one primary holder | Both preserved. LM-7 and LDI input I-1 measure how many functions one person holds alone |
| **C-D-06** | Four distinct finance hands **[S: Ch.18, APPROVED]** | A State A team may have fewer than four holders **[S-B: §3.3]** | **TRUE CONTRADICTION at team scale.** It cannot be satisfied internally | **Resolved by routing, not by weakening:** Rule D-103 — the duty moves up a level rather than being performed by the same person with extra care. **[S-B: B-21]** City Shared Services Contract |
| **C-D-07** | "Leadership is earned through performance" **[S: Const. Art.4, APPROVED]** | "Opportunity is not an automatic personal entitlement" **[S: Ch.26]** | **APPARENT CONFLICT.** Earning creates a claim on consideration, not on appointment | Both preserved verbatim. Part 3 §3.1 separates Gate E (earned consideration) from Gate R (present readiness); Part 10 §10.7 records the positional scarcity `L_pos/K` |
| **C-D-08** | CEO holds executive authority **[S: Ch.4, Ch.5]** | A National Council is contemplated **[S: Ch.5; S-A: A-23 N19 PROPOSED]** | **TRUE CONTRADICTION — UNRESOLVED IN SOURCE** **[S: Ch.33]** | **Not resolved. Explicitly refused.** Rule D-113 supplies an interim procedure so the unresolved item cannot force a unilateral act in a crisis. Carried as LDR-U01 |
| **C-D-09** | "Leadership transfer: CEO / governance process" **[S: App. E]** | "Leadership transition rules: NOT FINAL" **[S: Ch.33]** | **TENSION.** An authority is named for a process that is not final | Both preserved. Part 10's PT-series and Part 12's TL-series are **proposals** for the NOT FINAL rules; the named authority is unchanged |
| **C-D-10** | "A person is never scored" **[S-C: §23.2]** | `succession_status` stores "ready/acting/nominated status" **about a person** **[S: Ch.22]** | **TENSION.** A state is not a score, but it is a judgement about a person | Both preserved. Part 11 §11.2 makes SS a state of **the role's coverage**, not a grade of the person; Rule D-123 records dependency against the role and unit |
| **C-D-11** | A Team Leader "cannot … punish people" **[S: Ch.9]** | Leadership failure leads to "Replacement/dynamic succession" **[S: Ch.14]** | **APPARENT CONFLICT.** The leader cannot punish; the organisation can replace | Both preserved. Part 18: replacement is an organisational act through CR-3/RM-1…RM-10 or IP-1…IP-7, never a leader's act |
| **C-D-12** | AI "cannot autonomously make consequential … leadership decisions" **[S: Const. Art.12, APPROVED]** | An eligibility engine and a scoring pipeline determine who is considered **[S: Ch.11, Ch.25]** | **TENSION.** Automating a criterion is not deciding, unless the criterion is discretionary | Both preserved. Part 30 §30.2: AI may check recorded facts against published criteria; it may not decide eligibility where judgement is required, and may not assess readiness at all |
| **C-D-13** | Worker compensation is priority 1 **[S: Ch.18, APPROVED — THE CONTROL]** | A leader allocation is drawn from the worker-compensation base **[S-B: §24]** | **TENSION, and economically live.** The premium competes with delivery capacity inside the same pool | Both preserved. Rule D-70 bounds it; Rule D-71 separates delivery pay; Part 39 EF-3 and CT-1…CT-8 stress-test it. **The value remains `NOT FINAL`** |
| **C-D-14** | "No ordinal numbering" in any public medium **[S-C: SR-2]** | A leaderboard ranks teams **[S: Ch.25; App. E]** | **TENSION.** Teams are not persons, but a team ranking is socially read as a ranking of its members | Both preserved. Part 21: team ranking is internal, cohort-bounded, never individual, and **[S-ST: R5]** — whether it should be public at all — is **left open** |
| **C-D-15** | A non-selected member "may apply again" **[S: Ch.11 step 9]** | No interval, limit or feedback obligation is stated | **GAP, not contradiction** | Part 25 §25.3 supplies the feedback obligation and declines to invent a cooling-off period — **`UNKNOWN — MEASURE IN PILOT`** |
| **C-D-16** | Autonomy is "earned freedom inside central standards" **[S: App. A §16.1]** | Safety, HR verification, finance integrity and evidence duties are never removed **[S: Ch.10 State A]** | **APPARENT CONFLICT.** Autonomy over method, not over duty | Both preserved verbatim. Rule D-33 makes the four irreducible capabilities a formation condition, not an autonomy reward |
| **C-D-17** | Appointment of a permanent CEO is a **reserved matter** **[S-A: A-14 §13.3]** | "Leadership transfer: CEO / governance process" **[S: App. E]** | **TENSION.** The CEO participates in transfers but cannot be appointed by the process the CEO runs | Both preserved. Rule D-113's two-independent-body requirement applies to the apex appointment with the founder recused from assessment (Rule D-93). **Who holds the reserved matter remains [U]** |
| **C-D-18** | The Auditor is "review only; not operational commander" **[S: Ch.23]** | Leaderboard finalisation is "Performance / Audit" **[S: App. E]** | **APPARENT CONFLICT.** Finalising a measurement is a review act, not a command act | Both preserved. Part 34 RACI makes Audit **A** for the decision record and for appeals precisely because it cannot benefit from the outcome |
| **C-D-19** | "Serve without expecting reward" **[S: Const. Art.2]** | Mentoring, training, verifying and assessing are paid work (Rule D-47) | **APPARENT CONFLICT** | Both preserved. Payment is for **verified work performed**, at priority 1 or priority 3 as applicable — not a reward for service, and not a substitute for appreciation (Rule D-68) |
| **C-D-20** | Elder/Mentor is "excluded from RBAC command and from scoring" **[S-C: §6.10]** | An Elder may be a source of LE-4 trust evidence (Part 13 §13.6) | **TENSION.** Providing evidence is not scoring, but an Elder who knows their evidence decides outcomes holds informal power | Both preserved with a control: **an Elder may provide evidence but may not assess Gate R for a person they have mentored**, and the relationship must be declared under Part 35 |

## 47.3 Summary

| Class | Count | Items |
|---|---|---|
| **TRUE CONTRADICTION — resolved by routing or specification** | 1 | C-D-06 |
| **TRUE CONTRADICTION — NOT RESOLVED, carried forward** | 2 | **C-D-01**, **C-D-08** |
| **TENSION — both preserved with a control** | 8 | C-D-04, C-D-09, C-D-10, C-D-12, C-D-13, C-D-14, C-D-17, C-D-20 |
| **APPARENT CONFLICT — resolved by reading** | 8 | C-D-02, C-D-03, C-D-05, C-D-07, C-D-11, C-D-16, C-D-18, C-D-19 |
| **GAP** | 1 | C-D-15 |

**[A]** Two true contradictions survive. **C-D-08 is unresolvable here** because it is `UNRESOLVED` in the source and Rule 2 forbids closing it. **C-D-01 is unresolvable here** because **[S: Const. Art.15]** is APPROVED architecture and the interpretive question — whether a team's people move or its label moves — is a constitutional reading, not a design choice. **Both are recorded in Annexure J as the two questions the source hierarchy must answer before the promotion architecture can be executed at scale.**

---

# PART 48 — BURDEN AUDIT BY LEVEL

## 48.1 Method

**[P]** Every instrument this document adds is assigned to the level that must operate it, with its burden class. **Burden classes: `T` trivial (minutes, per event), `L` light (under an hour, per cycle), `M` moderate (hours, per cycle), `H` heavy (recurring hours that compete with delivery), `X` requires a person who does not currently exist.**

**[A]** The audit's purpose is the brief's requirement that **every added control justify its burden** — and that the justification be inspected at the level that pays it, not at the level that designed it.

## 48.2 Mohalla level

| Instrument | Burden | Who carries it | Justification | Deferrable? |
|---|---|---|---|---|
| MVLS-1 four capability routes | **L** once | Team Leader | Prevents total failure on any single absence | **No** |
| MVLS-2 two signatories | **L** once | Funds Manager + City | Priority 1 of the waterfall **[S: Ch.18]** | **No** |
| MVLS-3 decision record | **T** per decision | Whoever decides | Without it there is no appeal, audit or memory | **No** |
| MVLS-4 incident reporting | **T** per event | Anyone | Safety and safeguarding | **No** |
| MVLS-6 SS state recording | **T** per role | Team Leader + HR | Nearly free; makes fragility visible | **No** |
| MVLS-7 Interim Authority Order | **L** once, periodic refresh | Team Leader | Cheapest continuity instrument available | **No** |
| MVLS-8 playbook core PB-1…PB-6 | **M** once | Role-holder | Substitutes for a redundant person (Rule D-34) | **No** |
| MVLS-9 complaint route outward | **T** per event | Any member | The only exit that is not exit | **No** |
| MVLS-11 same-day access revocation | **T** per transition | City technology admin | Unrecoverable if missed | **No** |
| Gate E screening | **L** per vacancy | HR | Prevents arbitrary selection | **No** |
| Gate R assessment | **X** | **Out-of-team assessor — does not exist at Stage 0–1** | The only defence against popularity capture | **Yes — recorded as a gap (Rule D-110)** |
| RV-1 score production | **L** per cadence | Performance function | Existing **[S: Ch.24]** | **No** |
| RV-2 role review | **L** per review date | Appointing authority | Existing **[S: Ch.22]** | **No** |
| RV-3 leadership review | **M** per cycle | Out-of-line reviewer | Leadership ≠ performance | **Yes — Stage 2** |
| F-360a witness statements | **M** per cycle | Several members | Independence from the team's social field | **Yes — Stage 2** |
| F-360c experience survey | **L** per cycle | All members | The retaliation detector | **Yes — Stage 2** |
| Successor development (SD-c) | **H** ongoing | Team Leader | Succession is the whole point | **No for mandatory roles** |
| Workload ledger | **T** per cycle | Each role-holder | Makes overload visible before exit | **Yes — Stage 2** |
| KT handover pack | **M** per transition | Both holders | Only at transition | **Yes — core only at Stage 1** |
| CT-A/CT-B continuity exercise | **M** per cycle | Team + City | Written ≠ working (Rule D-122) | **Yes — Stage 2** |
| Conflict declarations | **T** per matter | Any participant | Anti-favouritism | **No** |
| Rule D-116 opportunity-allocation record | **T** per allocation | Team Leader | The only detector of invisible favouritism | **Yes — Stage 3** |

**[A] Mohalla finding:** the non-deferrable set is **light**. The heavy items — Gate R assessment, successor development, RV-3, F-360a, continuity exercises — are **exactly the items that require an outside person**. **The mohalla's burden problem is not paperwork; it is the absence of anyone outside.** That is a City-capacity problem and no amount of simplification at team level solves it.

## 48.3 City level

| Instrument | Burden | Who carries it | Justification | Deferrable? |
|---|---|---|---|---|
| Out-of-team assessment supply | **X → H** | City assessment function | Rule D-45; the ES.5 correction | **No from Stage 2** |
| Verifier supply (SP-3) | **H** | City specialist pool | GF-27; **[S-ST: F-26]** | **No from Stage 2** |
| Shared funds review | **H** | City funds reviewer | Rule D-103; **[S-B: B-21]** | **No** |
| Shared HR verification | **H** | City HR | **[S-B: MVC-2]** | **No** |
| Audit sampling | **M** | City auditor (review-only) | **[S: Ch.23]** | **No** |
| Trainer supply | **X → H** | Trainer cadre | **[S-ST: Scenario B]** binding constraint | **No** |
| Emergency cover | **M** standby | City | TL-3; Rule D-33 | **No** |
| Aggregate reporting with suppression | **L** per cycle | City | Rule D-108 | **Yes — Stage 3** |
| Disparity testing AI-7 | **M** per cycle | City + Audit | Silent bias accumulation | **Yes — Stage 3** |
| Continuity test CT-C | **H** annual | City + State | False continuity | **Yes — Stage 3** |
| Expansion gate XG-1…XG-8 | **M** per expansion | City owner | Prevents hollowing growth | **No from Stage 2** |
| City divisor measurement | **M** | City | Rule D-91 gates State formation | **No** |

**[A] City finding:** the City is where every mohalla-level `X` becomes an `H`. **The City's burden is therefore super-linear in `K` unless the divisor `H_gov_per_team(K)` is genuinely sub-linear — and that shape is `UNRESOLVED` (LDR-U14).** This is LF-29, and it is the largest structural risk in the leadership architecture below the apex.

## 48.4 State and National levels

| Level | Instrument | Burden | Justification | Deferrable? |
|---|---|---|---|---|
| **State** | Cross-city assessment independence | **M** | Rule D-50 at scale | No from Stage 4 |
| **State** | Standards ownership and versioning (M2/M3) | **M** | Prevents ML-3 standard drift | No |
| **State** | Escalation and appeals above City | **M** | §18.3 one further level | No |
| **State** | Aggregate density and dependency reporting | **L** | §38.7 | Yes |
| **National** | Reserved-matter custody | **M** | **[S-A: A-14 §13.3]** — **but the holder is [U]** | No |
| **National** | Annual unannounced 72-hour continuity test | **H** annual | **[S-A: A-14 §13.8]** | No |
| **National** | Four annual tests, published internally | **L** | **[S-A: A-16]**; Rule D-94 | No |
| **National** | Institutional memory completeness | **M** | **[S-A: A-15]** | No |
| **National** | Constitutional amendment process | **M** per event | Reserved | No |
| **National** | Founder Recusal Register custody | **L** | Rule D-92 | No |

**[A] State and National finding:** the burden is **low in hours and very high in consequence**. **A national-level failure is not a bad quarter; it is an institutional event.** The correct burden discipline at these levels is therefore not minimisation but **redundancy and independence** — which is why CT-C, the four tests and the reserved-matter procedure are non-deferrable while aggregate reporting is not.

## 48.5 The burden verdict

**[P]** Three findings, stated plainly:

1. **The mohalla's burden is light and its gap is people.** Twelve MVLS items are all `T` or `L`. The `X` items are not simplifiable — they require an outside observer who does not exist at Stage 0–1.
2. **The City carries the entire independence requirement of the architecture.** Every fairness control that matters — out-of-team assessment, verifier rotation, shared funds review, appeals, disparity testing — is a City burden. **If the City cannot carry it, the fairness controls do not exist, and the architecture reverts to popularity selection with better paperwork.**
3. **This document's total specified burden exceeds `σ_max` at Stage 0–1 and is unmeasured at Stage 2+.** Rule D-80 tiering and Rule D-128's simplification obligation are the only available responses. **Whether they are sufficient is `UNKNOWN — MEASURE IN PILOT`, and the pilot cannot measure burden at scale because it runs without technology (§40.5).**

---

# PART 49 — ECONOMIC AUDIT & CONTROL-BUDGET AUDIT

## 49.1 The rule about money

**No rupee value appears in this Part.** **[S: App. A §1.1]** records that the economic blueprint was never attached. **[S: Ch.18]**'s waterfall is the control. The only percentages in 179 pages — 37.5 / 17 / 12 — are **illustrative**. **[S: Ch.33]** leaves the leader multiplier, founder compensation, worker classification and legal structure unresolved. **Every unknown below reads `UNKNOWN — MEASURE IN PILOT.`**

## 49.2 Economic audit

| Item | Question | Answer | Status |
|---|---|---|---|
| **EA-1** | What is the cost of one leader? | `C_lead = C_wc_base × m_lead` **[S-B: §24]** | `m_lead` **NOT FINAL** — `UNKNOWN` |
| **EA-2** | Is the premium funded from priority 1? | **Yes** — it is built on the worker-compensation base | Competes with delivery capacity |
| **EA-3** | What does one promotion cost in total? | Lost delivery hours at the sending unit + development time already spent + overlap **[S-B: B-18(2)]** + bounded mentorship **[B-18(3)]** + transition access work + the vacancy process below + failure risk | **[S-B: B-18(6)]** requires it recorded as a cost; **the value is `UNKNOWN`** |
| **EA-4** | What does an out-of-team assessment cost? | Assessor hours × candidates per cycle | **`UNKNOWN`; and the assessor does not exist at Stage 0–1** |
| **EA-5** | What does successor development cost? | Paid mentoring and delegation time (Rule D-73) per mandatory-SS-4 role | **`UNKNOWN`** |
| **EA-6** | What does trainer supply cost? | Trainer hours × cohorts; trainer time is paid work (Rule D-47) | **`UNKNOWN`; [S-ST: Scenario B] identifies this as the binding constraint** |
| **EA-7** | What does the playbook programme cost? | Authorship once per covered role + periodic review | **`UNKNOWN`; largest single memory cost (§28.4)** |
| **EA-8** | What does continuity testing cost? | CT-A/B per unit per cycle; CT-C annually | **`UNKNOWN`** |
| **EA-9** | What does the City shared-services layer cost? | `H_gov_per_team(K)` × `K` | **Divisor shape `UNRESOLVED` (LDR-U14)** |
| **EA-10** | Is there a revenue line for any of it? | **No.** The source has no revenue line for service, governance or training **[S-B]** | **The structural constraint on the entire leadership system** |
| **EA-11** | Does the specialist track pay for itself? | **Directionally yes** — it adds `P_max` without adding `H_gov` **[S-C: §47.1]**, and SP-3 verifiers reduce assessment cost | **`UNKNOWN`; EF-4** |
| **EA-12** | Is leadership affordable for a person with no spare capacity? | **Unknown, and the most consequential unknown in this document** | **EF-5; Rule D-126 records the deficit** |
| **EA-13** | What does a leadership failure cost? | Unit degradation or closure; loss of verified members; loss of community trust; possible safeguarding or legal exposure | **Not quantifiable here; [V] insurance and legal review required** |
| **EA-14** | Does any component create revenue? | Only venture work, at priority 1/priority 3 per **[S: Ch.18]** and **[S-C: §47.4]** | **No leadership component creates revenue** |

## 49.3 Control-budget audit

**[S-B: §26.1]** — `σ_max` is the ceiling on total control and governance effort, derived from the team's own economics. **[S-B: §26.3]** — automate, simplify or retire. **[S-B: B-20 MVC-1…MVC-11]** — the minimum viable control set.

| Control cluster | Estimated burden class (§48) | Inside `σ_max` at Stage 0–1? | Treatment |
|---|---|---|---|
| MVLS-1…MVLS-12 | `T`–`L`, one `M` | **Presumed yes — `UNKNOWN — MEASURE IN PILOT.`** | Mandatory at every stage |
| Gate E + Gate R | `L` + `X` | **No — Gate R requires an outside person** | Gate R deferred with a recorded gap (Rule D-110) |
| RV-1 + RV-2 | `L` + `L` | **Yes** — both are existing source obligations | Mandatory |
| RV-3 + F-360a/b/c | `M` + `M` | **No** | Stage 2 |
| GF-1…GF-30 detection | `M` at full register | **No** | Stage 1 subset only (GF-1, GF-2, GF-11); full at Stage 3 |
| LDI + LLI | `T` per cycle | **Yes** | Stage 2 for mitigation planning |
| Playbooks PB-1…PB-6 | `M` once | **Yes, if amortised** | Stage 1 |
| Playbooks PB-7…PB-10 | `L` once | Marginal | Stage 2 |
| KT-1…KT-10 | `M` per transition | Event-driven; **yes** | Core only at Stage 1 |
| CT-A/CT-B | `M` per cycle | **No** | Stage 2 |
| CT-C | `H` annual | **Not a team obligation** | City/State/National |
| Complaints + appeals | `T`–`M` event-driven | Event-driven; **yes** | MVLS-9 at Stage 1 |
| Aggregate + disparity reporting | `L` + `M` | **No** | Stage 3 |
| Founder Recusal Register | `L` | **Not a team obligation** | Stage 2, apex |

**[P] Control-budget verdict:** **`σ_max` is exceeded at Stage 0–1 by the full specification and satisfied by MVLS plus RV-1/RV-2 plus Gate E plus playbook core.** The margin between those two sets **is** Rule D-80's tiering. **The exact margin is `UNKNOWN — MEASURE IN PILOT.`**

## 49.4 The three economic rules that follow

**[P] Rule D-133 (No Control Without A Funder).** Every control has a named funder — a role, a level, or the City shared-services contract **[S-B: B-21]** — or it is explicitly recorded as volunteer burden with its cost declared (Rule D-126). **This is the operational form of L-21 and the answer to the standing assumption that "leaders will just volunteer".**

**[P] Rule D-134 (The Cheapest Control Is Preferred Where Effects Are Equal).** Under CB-4, a document substitutes for a person, an aggregate substitutes for an individual record, a gate substitutes for a score, and an existing source obligation substitutes for a new one. **Where two controls prevent the same harm, the cheaper is adopted and the more expensive is recorded as considered-and-declined.**

**[P] Rule D-135 (Economic Infeasibility Is A Design Defect, Not A Resourcing Problem).** Where a control cannot be funded at the level that must operate it, the control is redesigned or retired — **it is not left in the architecture as an aspiration.** **[A]** An unfunded control is worse than no control, because it creates a documented standard that is systematically not met, which normalises non-compliance across the whole system.

---

# PART 50 — HUMAN-SYSTEM AND GOVERNANCE-RISK AUDITS

## 50.1 Human-system audit

**[A]** Tested against **[S-C]**'s protections, which this document may **convert into constraints** but may **not rewrite**.

| Protection **[S-C]** | Is it preserved here? | Where it binds the leadership system |
|---|---|---|
| **H-02 nine-level participation spectrum** | **Yes** | PL-0 entry; LM-14 pipeline counts; no level is a failure to advance |
| **H-03 never recruit at the moment of vulnerability** | **Yes — strengthened** | Rule D-37 prohibits publishing density targets; Rule D-88 prohibits youth quotas; PF-9 makes it a pilot failure |
| **H-08 six recognition instruments never collapsed** | **Yes** | Part 22 §22.1 reproduced with leadership consequences; Rule D-66 recognition confers nothing |
| **H-10 portable credential** | **Yes** | Part 16; SP-series; portability is what makes it credible |
| **H-11 specialist ladder S1…S6** | **Yes — extended to SP-1…SP-6 with authority ceilings** | Part 13 §13.3 |
| **H-17 seven refusal rights** | **Yes — mirrored** | Rule D-23 promotion refusal; Rule D-26 dignified exit; AX-8; MVLS-12 |
| **SR-1…SR-7 member rights** | **Yes** | SR-5 duty of care bounds span (SP-C); SR-6 informs F-360c and complaint acknowledgement; SR-7 informs `H_available` |
| **§8.2 six endpoints; L5 Verified Member votes nothing, manages nobody** | **Yes** | Part 22 §22.3 standing without authority |
| **§8.4 no instrument may describe leadership as a higher form of service** | **Yes — absolute** | PR-3; CU-8; Rule D-35 |
| **§23.2 a person is never scored** | **Yes — absolute** | Rule D-63 bands not scores; Rule D-76 load is a structural finding; C-D-10 |
| **CR-1…CR-4 record limits** | **Yes** | Rule D-109 six-condition social-credit test |
| **§45 local hero and charismatic-leader guards** | **Yes** | CU-1…CU-10; Elder standing as the release valve |
| **§6.10 Elder/Mentor excluded from command and scoring** | **Yes — absolute** | Part 13 §13.6; C-D-20 control |

**[P] Human-system verdict: PASS WITH ONE QUALIFICATION.** The qualification is EF-5 / EA-12: **if holding a leadership role costs a poor person more than they can afford, the human system's promise of equal standing is formally intact and practically false.** Rule D-126 records the deficit; recording is not paying. **This is the human-system audit's single unresolved finding.**

## 50.2 Anti-personality-cult audit

| Test | Result | Evidence |
|---|---|---|
| Is any person the organisation's identity? | **No, by rule** | PR-1, PR-6, CU-1 |
| Does any instrument create a loyalty object? | **No** | §21.7 rejects oaths, pledges, insignia and titles; CU-2 |
| Is attribution disciplined? | **Yes** | PR-2; T2 attribution test |
| Is dissent safe and counted? | **Yes by design — `UNVALIDATED` in practice** | T3; **[S-A: A-16 test 3]**; Rule D-57; **ES.5-class uncertainty: whether people actually dissent is behavioural, not architectural** |
| Is replaceability a duty? | **Yes** | Rule D-62; T-6; Rule D-125 |
| Is recognition absolute? | **Yes** | Rule D-66; **[S-C: §44.3]** |
| Is the founder bound? | **Partially** | Rule D-92/93/115 exist; **but [S: Const. Art.3] is APPROVED and no procedural control binds a person with constitutional authority. Visibility is the only check** |
| Is leadership described as a higher form of service anywhere? | **No** | **[S-C: §8.4]**; CU-8 |
| Is exit dignified? | **Yes** | Rule D-26; Rule D-27; CU-9 |
| Do symbols belong to the work? | **Yes** | CU-10; §21.7 |

**[P] Verdict: PASS ON INSTRUMENTS, `UNVALIDATED` ON BEHAVIOUR.** **[A]** The honest statement: **an architecture can prevent a cult from being built with organisational tools. It cannot prevent one from forming around a person people love.** CU-1…CU-10 remove the tools; the four annual tests detect the drift; **nothing here guarantees the tests will be acted on.**

## 50.3 Anti-MLM audit

| Test | Result |
|---|---|
| Does any payment depend on another person's participation? | **No — Rule D-118 prohibits it absolutely** |
| Does any promotion criterion reference headcount, recruitment or downline size? | **No — [S: Ch.25]** prohibits volunteer count and application count; Part 7's gates exclude team size |
| Is there an entry fee, purchase requirement or inventory loading? | **No — [S-C: AC-series]; [S-B: B-07]** venture gating |
| Is there multi-level commission? | **No — Rule D-71 separates delivery pay; no instrument pays a share of another's earnings** |
| Are income claims or earnings testimonials published? | **Prohibited — PR-2, PR-4; [S-C: MLM-6]** |
| Is recruitment ever permitted at a moment of vulnerability? | **Prohibited absolutely — [S-C: H-03]; PF-9** |
| Does team formation create a sponsor income stream? | **No — expansion is recorded as a COST (Rule D-44), not as a reward** |
| Is the specialist/builder track a recruiting incentive? | **No — Rule D-35 prohibits track superiority and the Builder track carries charter limits, not commission** |

**[P] Verdict: PASS.** **[A]** The one vector to watch: **[I]** Rule D-44 records expansion as a cost, but a culture that celebrates team formation as the highest achievement — without recording its cost visibly — recreates the growth incentive socially even where it does not exist financially. **CU-3 attribution discipline and LM-14's no-target rule are the controls.**

## 50.4 Anti-vigilante audit

| Test | Result |
|---|---|
| Does any role confer enforcement power? | **No — [S: Ch.9]** boundaries; STOP is a capability to halt, not to compel (VG-1) |
| Is the DO-NOT list binding at every level and reserved? | **Yes — [S-A: A-08; A-14 §13.3]**; Rule D-30(3) excludes it from all temporary authority |
| Can a leader act on popular demand? | **No — VG-4:** a crowd's demand is recorded as a community concern and routed, never acted on directly |
| Is any detention, search, confiscation, interrogation or expulsion within authority? | **No — VG-2:** any such instruction is outside every role's authority and is a CR-3 conduct matter |
| Is a use-of-force or detention event escalated? | **Yes — VG-5:** immediate CR-4, sealed category, independent review, mandatory reporting where law requires **[V]** |
| Is legal basis briefed before protection authority is held? | **Yes — VG-6**, with the source's own caveat that internal training is not legally sufficient **[S-C: §47.3]** |
| Does the architecture rely on private-arrest powers? | **No. [X]** BNSS 2023 s.40 permits private arrest in narrow circumstances with handover within six hours, and s.31 binds persons to assist a Magistrate or police officer reasonably demanding aid — **these are external legal facts, marked [V], and are not incorporated as organisational authority** |

**[P] Verdict: PASS ON ARCHITECTURE, `REQUIRES PROFESSIONAL VALIDATION` ON LAW.** **[A]** The residual risk is VG-4: **a locally legitimate leader facing a locally popular demand will find refusal socially very expensive.** The control is real but its effectiveness is behavioural. **LF-23 is rated low-likelihood, critical-impact, and is the item most dependent on training and on the Elder/Mentor mediation route.**

## 50.5 Anti-political-capture audit

| Test | Result |
|---|---|
| Does the organisation take political positions or support parties or candidates? | **Prohibited — PC-1**, reserved-matter class |
| Do members retain civic rights? | **Yes — PC-2**, per the standing instruction not to assume members lose civic rights |
| Are personal political activity and organisational role separated on the record? | **Yes — PC-3:** declaration, and no organisational resource, platform, list, record, symbol or event for political purposes |
| Is there a political test in any gate? | **No — Part 3 §3.2** nine deliberately-absent criteria; AI-5 prohibits it as a model input |
| Is funding-source transparency provided? | **Yes — PC-6**, under **[S-A: A-17]** |
| Is local capture detectable? | **Partially — PC-7:** aggregate disparity testing only, never individual profiling. **Detection is slow** |
| Is the applicable tax and foreign-contribution regime determined? | **NO — the entity structure is `UNRESOLVED` (LDR-U08)**, so 12A's political-activity condition, 80G and FCRA applicability cannot be assessed. **[X]** 12A exemption is conditional on applying at least 85% of income to charitable purposes and on no political activity or support to any party or candidate, with cancellation risk. **[V] REQUIRES PROFESSIONAL TAX AND LEGAL VALIDATION** |
| Does the waterfall conflict with any application-of-income requirement? | **`CANNOT BE ASSESSED` — no rupee values exist and the economic blueprint was never attached [S: App. A §1.1]. PC-8 records the constraint without drawing a numeric conclusion** |

**[P] Verdict: PASS ON ARCHITECTURE, `BLOCKED` ON LEGAL ASSESSMENT.** The blocker is not this document's — it is LDR-U08.

## 50.6 Data and AI audit

| Test | Result |
|---|---|
| Is any new data estate created? | **Minimal — Part 31 §31.1:** every field is an existing **[S: Ch.22]** field, an aggregate, or a record about a role |
| Is every leadership data type classified? | **Yes — §31.2**, against **[S-A: A-17]** C1–C4 |
| Is minimisation applied? | **Yes — [S-A: A-18]** four-branch necessity test; AX-9 |
| Is access separated? | **Yes — [S-A: A-19]** eight-function matrix; a contributor's record is not a beneficiary's record |
| Are sealed categories protected? | **Yes — [S-A: A-20]** C4, case-scoped, two-person rule |
| Is small-cell disclosure prevented? | **Yes — Rule D-108**, with suppression itself reported. **Threshold `UNKNOWN — MEASURE IN PILOT`** |
| Are subject rights provided? | **Yes — [S: Const. Art.6; S-A: A-20 §19.7]**; AX-7 |
| Is there a universal human score? | **No — Rule D-109** six-condition test; **[S-C: CR-1…CR-4]** |
| Is retention determined? | **NO — `UNRESOLVED` (LDR-U10)**, affecting TA-h audit-log retention. **[X]** DPDP Rules contemplate log retention of at least one year for specified purposes, then erasure **[V]** |
| Does AI decide anything consequential? | **No — [S: Const. Art.12 APPROVED]**; Rule D-60; Part 30 §30.2 |
| Is AI output explainable to the subject? | **Required — Rule D-105** stranger test; Rule D-106 no black box in a consequential path |
| Is human override free? | **Yes in the favourable direction — AI-4**; justification required only when override disadvantages the subject |
| Are prohibited model inputs enumerated? | **Yes — AI-5** |
| Is historical bias prevented from becoming prediction? | **Required — Rule D-107.** **This is the rule most likely to be violated for ordinary engineering reasons (ATK-17)** |
| Is model change governed? | **Yes — AI-8**, versioned like any standard under **[S-A: A-15 M2]** |
| Is disparity tested? | **Yes — AI-7**, from Stage 3; aggregate with suppression only |
| Is the audit log used to monitor people? | **Prohibited — §29.6:** it records acts of authority, not behaviour |
| Is a DPIA required? | **`CANNOT BE DETERMINED`** — depends on Significant Data Fiduciary status, which depends on scale and on the unresolved entity structure **[V]** |

**[P] Verdict: PASS ON ARCHITECTURE, TWO ITEMS BLOCKED BY SOURCE UNRESOLVED ITEMS** (retention, entity structure), **ONE ITEM `UNVALIDATED`** (whether Rule D-107 survives engineering pressure).

## 50.7 Audit summary

| Audit | Verdict | Blocking item |
|---|---|---|
| Human system | **PASS WITH QUALIFICATION** | EF-5 / EA-12 — affordability of leadership for a poor person |
| Anti-personality-cult | **PASS ON INSTRUMENTS; `UNVALIDATED` ON BEHAVIOUR** | Whether dissent actually occurs (T3) |
| Anti-MLM | **PASS** | Cultural celebration of growth (monitored, not blocked) |
| Anti-vigilante | **PASS ON ARCHITECTURE; `[V]` ON LAW** | VG-4 social cost of refusal; legal validation |
| Anti-political-capture | **PASS ON ARCHITECTURE; `BLOCKED`** | **LDR-U08 entity structure** |
| Data and AI | **PASS ON ARCHITECTURE; TWO BLOCKED, ONE `UNVALIDATED`** | **LDR-U10 retention; LDR-U08; Rule D-107 in practice** |

---

# PART 51 — INVARIANTS, LOCAL ADAPTATION & FINAL ARCHITECTURE

## 51.1 Invariants — INV-1 … INV-20

**[P]** These may **never** be adapted, waived, tiered, deferred or traded, at any level, at any stage, in any locality, under any pressure including emergency. **Rule D-30(3) already places several of them beyond temporary authority.**

| ID | Invariant | Source |
|---|---|---|
| **INV-1** | Leadership is earned, never inherited, purchased, ranked into or awarded for loyalty | **[S: Const. Art.4; Art.2]** |
| **INV-2** | Worker compensation is priority 1 and is never suspended by a dispute, a process, a gate or a score | **[S: Ch.18]**; **[S-A: A-14 §13.6]** |
| **INV-3** | The waterfall priority order is unchanged | **[S: Ch.18]**; reserved **[S-A: A-14 §13.3]** |
| **INV-4** | AI may recommend; humans decide; AI never autonomously makes a consequential HR, wage, legal, safeguarding, safety, major fund or leadership decision | **[S: Const. Art.12 APPROVED]** |
| **INV-5** | A person is never scored | **[S-C: §23.2]** |
| **INV-6** | No instrument describes leadership as a higher form of service | **[S-C: §8.4]** |
| **INV-7** | No universal human score; no social credit system | **[S-C: CR-1…CR-4]**; Rule D-109 |
| **INV-8** | Raw revenue, follower count, social-media views, volunteer count, application count and raw activity count never determine leadership | **[S: Ch.25]** |
| **INV-9** | A high score is void on fraud, safety breach or manipulation | **[S: Ch.26]** |
| **INV-10** | Opportunity is not an automatic personal entitlement | **[S: Ch.26]** |
| **INV-11** | Small size never removes safety, HR verification, finance integrity or evidence duties | **[S: Ch.10 State A]** |
| **INV-12** | The protection DO-NOT list binds at every level and is a reserved matter | **[S-A: A-08; A-14 §13.3]** |
| **INV-13** | A Sub-Role is a delegated operational position, never an automatic transfer of all authority | **[S: Ch.10]** |
| **INV-14** | One role has one primary holder; no two people hold write authority over the same role's decisions | **[S: Ch.22]**; Rule D-100 |
| **INV-15** | The Auditor is review-only and never an operational commander | **[S: Ch.23]** |
| **INV-16** | No member is recruited at a moment of vulnerability | **[S-C: H-03]** |
| **INV-17** | Refusal rights are absolute and carry no adverse consequence | **[S-C: H-17]**; Rule D-23; Rule D-77 |
| **INV-18** | Non-retaliation against a complainant or appellant is absolute | **[S-ST: M10]**; Rule D-57 |
| **INV-19** | Elder/Mentor standing confers no command and carries no scoring weight | **[S-C: §6.10]** |
| **INV-20** | No successor is named, implied or hinted at by any planning instrument | **[S-A: A-14]**; this document's own refusal |

## 51.2 What may adapt locally — ADAPT-1 … ADAPT-12

**[P]** Adaptable **only** through the versioned change-request route **[S-A: A-15 M2/M3]**, with reasons recorded and inspectable by any member.

| ID | May adapt | Constraint |
|---|---|---|
| **ADAPT-1** | Language of every instrument, notice, criterion and record | OB-1; meaning unchanged |
| **ADAPT-2** | Role titles and local naming | **No ordinal numbering; no honorifics of rank** **[S-C: SR-2]**; CU-2 |
| **ADAPT-3** | Cadence timing within the source's five cadences | **[S: Ch.24]** cadence set is fixed |
| **ADAPT-4** | Which of the nine State A functions are combined, given `c` | Rule D-33 four capabilities and Rule D-103 segregation are **not** adaptable |
| **ADAPT-5** | Playbook content PB-2, PB-3, PB-5, PB-7, PB-8 | PB-1 boundary and PB-4 refusals are **not** adaptable |
| **ADAPT-6** | Cohort definition boundaries within CN-1's records-based rule | Cohorts may never be elected (GF-20) |
| **ADAPT-7** | Recognition forms and ceremonies | Rule D-66 and Rule D-67 are **not** adaptable |
| **ADAPT-8** | Specialist domains beyond the twelve | A published standard must exist first **[S-C: §25.3 condition 1]** |
| **ADAPT-9** | Complaint intake channels | The outward-reaching channel (MVLS-9) is **not** removable |
| **ADAPT-10** | Continuity-exercise method | Rule D-122 (unexercised = absent) is **not** adaptable |
| **ADAPT-11** | Local leadership vocabulary and metaphors | INV-6 and CU-8 bind |
| **ADAPT-12** | Which MVLS-adjacent instruments graduate in at which stage | **MVLS-1…MVLS-12 themselves are not adaptable** (Rule D-127) |

## 51.3 Leadership against the five things it must never become

| Question | Answer |
|---|---|
| **Leadership vs human worth** | Leadership is a **scope of responsibility**, held for a period, over a defined set of functions. Human worth is not a variable in this architecture and no instrument measures it. **[S-C: §8.4; §7.3 SR-1]**; INV-5, INV-6 |
| **Leadership vs membership** | Membership is the primary status and is complete at L5 without a role **[S-C: §8.2]**. Leadership is an **addition to** membership, never a **promotion out of** it. A leader who leaves the role remains a member in full standing — Rule D-26, Rule D-27 |
| **Leadership vs trust** | Trust is the **precondition** of leadership **[S: Const. Art.7]** and is produced by Gate R on LE-3/LE-4 evidence. Trust is not a feeling recorded informally (Rule D-42) and is not a reward for loyalty (INV-1) |
| **Leadership vs autonomy** | Autonomy is "earned freedom inside central standards" **[S: App. A §16.1]** and grows with the **[S: Ch.13]** readiness gate. Leadership **increases** autonomy over method and **decreases** it over duty: a leader is more constrained than a member, not less (INV-11, INV-12, INV-13) |
| **Leadership vs control** | Leadership is **not** control. Control is a set of functions — verification, funds, safety, audit — that leadership must **enable and never bypass** **[S: Ch.9 "Cannot bypass verification"]**. A leader who controls the controls has failed INV-14 and INV-15 |

## 51.4 The four loops

**[P]** The complete leadership system operates as four interlocking loops. Each has a cadence, an owner, an entry, an exit and a learning artifact.

```
                    +-----------------------------------------------+
                    |        LOOP 4  ACCOUNTABILITY & CORRECTION    |
                    |  complain -> investigate -> decide -> appeal  |
                    |              -> learn (M5, M3)                |
                    +-----------------------+-----------------------+
                                            |
                                            v
 +----------------------------+    +-----------------------------+
 | LOOP 1  DELIVERY &         |    | LOOP 2  DEVELOPMENT &       |
 |         PERFORMANCE        |--->|         PIPELINE            |
 | work -> verify -> measure  |    | observe -> delegate ->      |
 | -> review -> support       |    | assess -> certify           |
 +-------------+--------------+    +--------------+--------------+
               |                                  |
               v                                  v
 +--------------------------------------------------------------+
 |           LOOP 3  SUCCESSION & CONTINUITY                    |
 |  state -> develop -> exercise -> transition -> test -> state  |
 +--------------------------------------------------------------+
```

| Loop | Entry | Steps | Exit | Learning artifact | Owner | Cadence |
|---|---|---|---|---|---|---|
| **LOOP 1 — DELIVERY & PERFORMANCE** | Work performed | Verify **[S: Ch.25 step 2]** → measure across four windows → RV-1 → gate check → support where behind **[S: Ch.14]** | A team score with a confidence rating; a support decision | M5 lessons entry | Performance function; team | **[S: Ch.24]** monthly + window cadences |
| **LOOP 2 — DEVELOPMENT & PIPELINE** | A member at PL-1 | Observe LE-2/LE-3 → delegate TL-4 → develop DV-1…DV-5 → assess Gate R out-of-team → certify SP-series | A person at SS-4; a credential | The credential record; the auto-generated reference **[S-ST: M9]** | HR; out-of-team assessor; trainer cadre | Continuous |
| **LOOP 3 — SUCCESSION & CONTINUITY** | A covered role | Record SS state → nominate → develop → exercise delegation → transition PT-1…PT-9 → test CT-A/B/C → re-record | A role that survives its holder | KT pack; playbook; M5 "did it work" | Role-holder; line; City owner | Per RV-3 cycle; CT-C annual |
| **LOOP 4 — ACCOUNTABILITY & CORRECTION** | A complaint, incident, anomaly or appeal | Triage CR-1…CR-4 → interim protection → investigate → decide with reasons → appeal → review | A corrected record; a changed standard; a support plan | **M3 change request; M5 lessons entry** | Audit; panels; Integrity Line | Event-driven; aggregate monthly |

**[A]** The loops interlock at four points, and those points are where the system either works or fails:
- **Loop 1 → Loop 2:** a score identifies where development is needed. **If the score is gamed, the development is misdirected.**
- **Loop 2 → Loop 3:** readiness is the input to succession. **If Gate R is captured, succession produces the wrong people.**
- **Loop 3 → Loop 1:** a transition changes who performs and who verifies. **If the transition is unmanaged, delivery collapses (Scenario C).**
- **Loop 4 → all:** correction is the only route by which the other three loops change. **If Loop 4 is not independent, nothing is ever corrected (P-20).**

## 51.5 Master data flow

**[P]** One page, from event to decision:

```
EVENT (service, delivery, incident, complaint, decision)
   |
   v
RECORD  -- M1 decision record / evidence record / incident record
   |      classification C1-C4 [S-A: A-17]
   v
VERIFICATION  -- by a role other than the performer [S: Ch.18]
   |             out-of-team where available (SP-3)
   v
EVIDENCE CLASSIFICATION  -- LE-1 ... LE-5 ; admissibility check
   |                        prohibited evidence excluded
   v
MEASUREMENT  -- team score, four windows, cohort-normalised,
   |            confidence-rated, activity-capped
   v
GATE CHECK  -- PG-1 ... PG-12 ; gate disables status, never payment
   |
   v
REVIEW  -- RV-1 performance / RV-2 role / RV-3 leadership / RV-4 conduct
   |        reviewer independence (Rule D-50) ; skip-level (Rule D-51)
   v
DECISION  -- appointment / delegation / development / support /
   |          succession state change / removal
   |        RECORDED WITH REASONS a stranger can follow (Rule D-54)
   v
APPEAL  -- CR-2 ; out-of-line ; free ; no retaliation (Rule D-57)
   |
   v
LEARNING  -- M5 lessons ("did it work") -> M3 change request
             -> M2 versioned standard -> back to RECORD
```

**[A]** Two properties of this flow are deliberate and non-negotiable: **verification precedes measurement** (so a score is a fact about verified work, not about reported work), and **learning returns to the standard** (so the system changes itself rather than accumulating exceptions).

## 51.6 The final architecture in one statement

> **[A]** Sewak Sathi's leadership system is: **a set of roles with published boundaries** **[S: Ch.9]**, **filled through a vacancy lifecycle on published criteria** **[S: Ch.11]**, **by people whose capability is evidenced across five classes and assessed independently of their social position** (L-01, L-03), **whose authority is explicit, recorded, RBAC-limited, reviewed and always expiring** **[S: Ch.10, Ch.22]**, **who are paid for itemised leadership work inside a bounded allocation** **[S: App. A §15.3]**, **who are reviewed in four separate types that never merge** (L-13), **who must make their own role transferable and are defective if they do not** (L-14, Rule D-62), **who can be complained about through a route that reaches outside their unit** (L-23), **who can be replaced without destroying the team that produced them** (L-09), **who may leave with dignity and return without penalty** (Rules D-26, D-27), **and whose organisation continues to decide, pay, verify and stop when any one of them is gone** (Rule D-33, L-20) — **all of it inside a control budget the unit can actually afford** (L-21, L-38), **and none of it producing a number that describes a human being** (INV-5, INV-7).

---

# PART 52 — FINAL VERDICT

## 52.1 The verdict

> # **D — LEADERSHIP SYSTEM NOT YET PROVEN**
> ### with a defined, testable path to **B — LEADERSHIP SYSTEM VIABLE WITH TESTING**

| Grade | Meaning | Applies? |
|---|---|---|
| **A — LEADERSHIP SYSTEM PROVEN** | Operated, measured, corrected and observed working across at least one full succession cycle at more than one level | **NO** |
| **B — LEADERSHIP SYSTEM VIABLE WITH TESTING** | Architecturally complete, economically bounded, independently assessable, and scheduled for validation | **NO — but reachable; §52.3 gives the path** |
| **C — REQUIRES MAJOR REDESIGN** | The concept is wrong or the mechanisms are mutually incompatible | **NO — and saying so would be dishonest in the other direction. [S: Const. Art.4], [S: Ch.9], [S: Ch.10], [S: Ch.11], [S: Ch.14], [S: Ch.25], [S: Ch.26] together are a better starting point than most organisations of any size possess** |
| **D — NOT YET PROVEN** | The architecture is specified, coherent and bounded, and **nothing in it has been observed operating on real people** | **YES** |

## 52.2 The eight requirements for B, assessed

| # | Requirement for B | Status today | What closes it |
|---|---|---|---|
| **1** | Cohort definitions exist and are objective | **NOT SATISFIED** — none exist **[S-ST: F-19]** | L-06 CN-1…CN-7 adopted; cohorts assigned from records |
| **2** | Two-speed scoring decided and implemented | **NOT SATISFIED** — **[S: Const. Art.14]** says monthly; weights `PROPOSED`; **[S-ST: M8]** unadopted | L-05 four-window model adopted **without altering the PROPOSED weights** |
| **3** | Successor state recorded for every covered role | **NOT SATISFIED** — the field exists **[S: Ch.22]**; no obligation, no measurement, no report | L-08 SS-0…SS-5 adopted; §11.3 mandatory states; LM-1 measured |
| **4** | Promotion transition protocol exists | **NOT SATISFIED** — **[S-B: B-18]** proposed, unadopted | L-09 PT-1…PT-9 adopted; Promotion Decision Record in use |
| **5** | Specialist track exists with real scope and real pay expression | **NOT SATISFIED** — **[S-C: H-11]** proposed, unadopted | L-11 adopted with SP-series authority ceilings and **[S-C: §47.4]**'s four credibility conditions met |
| **6** | Independent complaint route exists | **NOT SATISFIED** — **[S-ST: M10]**, **[S-A]**, **[S-C: CK-1]** all proposed, none operational | L-23 CR-1…CR-4 adopted; Integrity Line reachable from a mohalla |
| **7** | Leadership workload measured | **NOT SATISFIED** — the `H_lead` coefficient is **[M]** unknown **[S-B: §25.1]** | L-25 workload ledger operating; `H_gov` measured against the 8–40 h/month observation window |
| **8** | Any of it observed working on real people | **NOT SATISFIED — and this is the requirement the other seven exist to serve** | **The single shared pilot** **[S-B: §40; S-C: §57]** operating MVLS-1…MVLS-12 for a full cycle, with LM-1…LM-15 recorded and PS-1…PS-12 evaluated |

**[A] Eight requirements, zero satisfied.** The same arithmetic that produced **D** in v1.3-B and **D** in v1.3-C produces **D** here, for the same underlying reason: **the organisation has designed four interlocking systems and has not yet operated one team.**

## 52.3 The path from D to B

**[P]** Six steps, in order. **Each is a decision, not a project.**

| Step | Action | Amendment | Precondition | Evidence of completion |
|---|---|---|---|---|
| **1** | Approve **MVLS-1…MVLS-12** and Rule D-127 (non-optional at any stage) | L-21 | None | The twelve items written down for one team |
| **2** | Run the **single shared pilot** with LM-1…LM-15 added, no technology, one team | L-39 | Step 1 | PS-1…PS-12 evaluated; PF-1…PF-10 checked; `H_gov` measured |
| **3** | Adopt **L-08 succession states** and record SS state for every covered role in the pilot and its sponsor | L-08 | Step 1 | LM-1 has a real denominator |
| **4** | Adopt **L-06 cohorts** and **L-05 windows** without altering the PROPOSED weights | L-05, L-06 | Step 2 data | Two-speed scoring operating on real records |
| **5** | Build **one out-of-team assessment capability** at City level — one assessor, one verifier, one funds reviewer | L-01, L-12, L-27 | Step 2; **[S-B: B-21]** | **The first Gate R ever performed by someone outside the candidate's social field. This is the single event that moves the grade** |
| **6** | Adopt **L-23 complaints and appeals** with a route that reaches outside the unit, and **L-09 promotion transition** | L-23, L-09 | Step 5 | One appeal heard; one transition executed with a KT pack |

**[A]** Step 5 is the pivot. **Requirements 1–4 and 6–7 can be satisfied with paper, discipline and one team. Requirement 8's most important component — whether the system can select the unpopular competent person — cannot be satisfied without an outside observer, and an outside observer requires a City.** Until step 5, the honest description of the leadership system is: **a well-specified selection process that will reproduce the social hierarchy of its locality and call the result earned** (ES.5).

## 52.4 What B would not mean

**[A]** Stated in advance, so that reaching B is not over-read:

| B does not mean | Because |
|---|---|
| The system selects capable leaders | B means it is **testable**, not that it passed |
| Succession works | **§41.5 limit 1:** one team cannot validate succession |
| Promotion works | **§41.5 limit 2:** one team has nowhere to promote to |
| The economics are sustainable | `m_lead`, `σ_max`, `c`, `H_gov_per_team(K)`, `K_min` all remain `UNKNOWN` or `UNRESOLVED` |
| The burden at scale is affordable | **§40.5:** the pilot runs without technology and cannot measure burden at scale |
| Favouritism is prevented | **LF-06 is unresolved:** opportunity allocation is only partially visible |
| Nominal compliance is detected | **LF-17 is unresolved:** no internal control detects a system complied with nominally and failed actually |
| The founder's influence is bounded | **[S: Const. Art.3]** is APPROVED; visibility is the only check |
| CEO vs National Council is resolved | **LDR-U01 — refused absolutely** |

## 52.5 What A would require

**[P]** Grade **A** requires all of the following, none of which is available before scale:

1. **At least one complete leadership cycle observed end to end** — a person developed, assessed independently, appointed, reviewed, replaced by a successor they developed, and exited with dignity.
2. **At least one City with `K` teams** across a measured range, so that `H_gov_per_team(K)` has a shape (Rule D-91).
3. **At least one successful appeal** against a leadership decision — proving Loop 4 is real rather than documented.
4. **At least one continuity test failed and then fixed** — proving Rule D-122 operates against the organisation's own comfort.
5. **At least one unpopular competent person selected over a popular alternative, with the reasons recorded and the decision surviving appeal** — closing ES.5 empirically rather than architecturally.
6. **The four annual tests reported at least twice**, with a non-zero dissent count and a non-zero absence count **[S-A: A-16]**.
7. **At least one leader removed for cause through the panel route**, and at least one leader who refused promotion with no adverse consequence — proving both directions of the accountability architecture.
8. **`m_lead`, the weights, the staffing thresholds and the entity structure all resolved by the source hierarchy**, so that the economics and the legality stop being conditional.

**[A]** Items 1–7 are events, not documents. **No further architectural work brings A closer.** The document is complete; the organisation is not yet begun.

## 52.6 The closing finding

**[A]** This instrument was asked to answer one question: *how can Sewak Sathi systematically develop trustworthy people into capable leaders without allowing performance measurement, competition, money, popularity, seniority, founder influence, AI scoring, or personality cults to become substitutes for genuine leadership capability?*

**The answer is: it can, if and only if four things are true.**

| Condition | Why it is decisive |
|---|---|
| **1. Someone outside the candidate's social field assesses capability** | Without it, every signal is socially mediated and popularity wins by default. This is Rule D-45, L-01, L-12, and it requires a City |
| **2. Every decision about a person is reasoned in terms they can read and contest** | Without it, there is no appeal in substance, and selection becomes unreviewable power. This is Rule D-54, L-03, L-23 |
| **3. Replaceability is a duty, exercised and tested, not a document** | Without it, the organisation's continuity is a hope and its best leaders are its largest risks. This is Rule D-62, L-08, L-20 |
| **4. The whole thing fits inside what the smallest unit can actually afford** | Without it, the architecture is complied with nominally and fails actually — the one failure no internal control detects. This is L-21, L-38, Rule D-128 |

**[A]** Conditions 2, 3 and 4 can be built with paper, discipline and one team. **Condition 1 cannot.** It requires a second unit, a City, and a person whose livelihood does not depend on the candidate's locality. **That is why the grade is D, why the path to B runs through step 5 of §52.3, and why no amount of additional design work — including this document — can substitute for it.**

**[A]** And one final finding, offered without softening because the brief requires it: **the most likely way this architecture fails is not through any mechanism in it being wrong.** It is through all of it being adopted on paper, reported favourably, and never exercised — because exercise is expensive, because the people who would exercise it are the people it constrains, and because a documented control that is not operated produces the same institutional outcome as no control at all, **with the additional harm of a record claiming otherwise.** Rule D-122 exists for exactly this reason: **unexercised counts as absent.** If that single rule is honoured, the architecture has a chance. If it is not, nothing else in these fifty-two parts matters.

---

# THE REQUIRED ONE-PAGE ANSWER

> ## **"How can Sewak Sathi systematically develop trustworthy people into capable leaders without allowing performance measurement, competition, money, popularity, seniority, founder influence, AI scoring, or personality cults to become substitutes for genuine leadership capability?"**
>
> **[A] Every answer below is `ARCHITECTURALLY SPECIFIED — EMPIRICALLY UNVALIDATED` until the single shared pilot observes it. Nothing here is a promise.**

| # | Question | Answer | Where |
|---|---|---|---|
| **1** | **How does a person become eligible for leadership?** | By meeting **Gate E** — published, records-based criteria with **nine deliberately-absent criteria** (tenure, popularity, revenue, locality, education, family, prior standing, religion, politics). Eligibility is a fact about records, decided by an engine, appealable. | Part 3 §3.2 |
| **2** | **How does a person become ready?** | By passing **Gate R** — a judgement on LE-3 behavioural and LE-4 trust evidence, made by an **assessor from outside the candidate's team**. Readiness is not eligibility, not seniority, and not a score. | Part 3 §3.4; Rule D-45 |
| **3** | **What is the difference between performance and leadership here?** | Performance is what a **team** produced inside a **window** under **conditions**. Leadership is what a **person** can be **trusted with**. Four review types (RV-1…RV-4) are never merged, and **a score may never change anyone's authority**. | Part 1; Rule D-49 |
| **4** | **How is capability measured without reducing a person to a score?** | Twenty capability dimensions (LC-1…LC-20) with four treatments — **GATED, SCORED, MONITORED, NARRATIVE**. Seven of the twenty are invisible to the existing team score. **A person is never scored**; load and dependency are **bands with consequences, not numbers with ranks**. | Part 4; Rule D-63 |
| **5** | **What evidence may be used, and what may never?** | Five classes: **LE-1 decisions, LE-2 verified tasks, LE-3 behaviour, LE-4 trust, LE-5 reflection.** Prohibited: tenure, popularity, loyalty, family, locality, religion, politics, caste, self-assessment alone. **No judgement without a specific, dated, observable event.** | Part 5; Rule D-54 |
| **6** | **How can a high-scoring team be refused?** | Through **PG-1…PG-12 hard gates**. A gate **disables the consequences of a score — never payment, never dignity**. The work is still recorded and still credited; it simply cannot confer status. | Part 7; L-04 |
| **7** | **What happens when a leader leaves, dies, disappears or is removed?** | One of **eleven absence cases** runs: a **TL-1…TL-5** instrument with scope, start, end condition, authority limits and review. **All expire automatically. Reserved matters are excluded absolutely. Emergency service is evidence, never entitlement.** Payment of worker compensation continues through **two signatories at every level**. | Part 12; Rules D-30, D-32 |
| **8** | **How is a successor produced, and who is responsible?** | The **role-holder**, as a scored dimension of their own leadership performance. Six succession states **SS-0…SS-5**; mandatory states by role class; readiness assessed out-of-team; **the delegation must have been actually exercised**. **Naming someone is free and counts for nothing.** | Part 11; Part 19 |
| **9** | **How is promotion stopped from destroying the team that earned it?** | **Successor-before-transition**, bounded overlap, bounded mentorship, promotion-cohort reporting with and without adjustment, **promotion recorded as a cost**, and **expansion gate XG-8** refusing any growth that drops an existing unit below continuity cover. | Part 10; Part 14 §14.7 |
| **10** | **What stops popularity, seniority, revenue, activity, money, AI or the founder substituting for capability?** | A **Goodhart Prohibition List**; **GF-1…GF-30** with detection signals; the **two-independent-signal rule**; **Const. Art.12** preserved verbatim (AI recommends, humans decide); a **Founder Recusal Register** and a prohibition on the founder assessing; **four annual tests where a zero count is a warning sign**. | Parts 20, 27, 30 |
| **11** | **What can a person become if they never want to lead?** | **A great deal.** Three tracks (Leadership, Specialist, Builder) plus two endpoints (Contributor, Elder/Mentor), with **no track superior to another**. SP-1…SP-6 with authority ceilings. "I want to remain an expert" is recorded as a **complete choice**, and the person is not repeatedly asked. | Part 13; Rules D-35, D-36 |
| **12** | **What does leadership cost, and who pays?** | Leadership work is **itemised and paid**, the allocation is **bounded and capped**, delivery is **paid separately**, and **no premium is paid for indispensability**. **No multiplier is invented — `m_lead` remains `NOT FINAL`.** Unpaid leadership work is recorded as an **organisational deficit**, not as a personal choice. | Part 23; Part 39 |
| **13** | **How is a leader held accountable, and how do they leave with dignity?** | Four separate routes — **performance correction, appeal, conduct complaint, integrity report** — that may never be substituted for one another. **Non-retaliation with the burden reversed.** Support-first improvement plans. Panel-only removal. **No score may remove anyone.** Dignified exit and an open return route. | Part 18; Rules D-26, D-27, D-60 |
| **14** | **What is the smallest leadership system that can safely run one mohalla?** | **Twelve items — MVLS-1…MVLS-12**: four capability routes, two signatories, a decision record, incident reporting, Gate E, succession state, an Interim Authority Order, a playbook core, an outward complaint route, honest failure reporting, same-day access revocation, and refusal rights. **Non-deferrable at any stage. Everything else is tiered.** | Part 40 §40.2 |
| **15** | **What is the verdict, and what would change it?** | **D — LEADERSHIP SYSTEM NOT YET PROVEN.** Eight requirements for B, zero satisfied. The path runs through six steps, and **step 5 — building one out-of-team assessment capability at City level — is the pivot**, because it is the only step that paper and discipline cannot substitute for. | Part 52 |

## The single biggest unresolved weakness in Sewak Sathi's leadership system

> ### **[A] The system has no working mechanism to select the unpopular competent person over the popular incompetent one — and at the scale at which the organisation will actually begin, it cannot have one.**
>
> Every selection signal the architecture produces is **socially mediated**. The score depends on evidence the team generates and the City reviews. The vacancy depends on interview and assessment. The community-trust dimension depends on verified feedback. The promotion decision sits with "Team Leader + HR", co-reviewed by the City/State role owner. **In a mohalla, the selectors, the selected and the reviewers are neighbours, relatives and friends.** The architecture forbids the crude proxies — raw revenue, followers, views, volunteer count, applications, activity — but forbidding crude proxies does not remove the subtle one: **likability, proximity, articulateness, and the social fluency that comes from caste, class and language position.**
>
> The correction is specified and is genuinely minimal: **an out-of-team assessor, a blind evidence portfolio, a structured scenario, and a recorded appealable reason with a dissent route** (Rule D-117). **All four must exist.** Two of the four require a person from outside the unit's social field.
>
> **At Stage 0–1 there is no outside.** One team, one mohalla, no City. So the correction cannot operate at the point where the organisation will start, and the honest prediction is that **the first leaders selected will be the locally popular, and the record will describe the result as earned.**
>
> This is not fixable by weights, formulas, dashboards, additional criteria or better training. **It is fixable only by paying for independence — one assessor, one verifier, one funds reviewer at City level — and until that is paid for, the leadership system is a well-specified process for reproducing the social hierarchy of the locality it operates in.**

---

# ANNEXURE A — SOURCE CONSISTENCY MATRIX

**[P]** Every source instrument this document touches, and what was done to it. **Legend: `P` preserved verbatim · `E` extended (added to, not altered) · `C` carried forward unresolved · `T` tested and found defective · `N` not touched.**

| Source instrument | Treatment | v1.3-D location | Note |
|---|---|---|---|
| **[S: Const. Art.2]** greater responsibility to those who earned greater trust; serve without expecting reward | **P** | Part 2; C-D-02; C-D-19 | Reward question resolved by itemisation, not by altering the Article |
| **[S: Const. Art.3]** Krytos ownership under founder/CEO Vasu | **P** | Part 27 | **Not amended. Not questioned.** |
| **[S: Const. Art.4]** leadership earned through performance | **P** | Part 1; Part 3; C-D-07 | The document's foundational premise |
| **[S: Const. Art.7]** greater responsibility requires greater trust | **P** | Part 2; §51.3 | — |
| **[S: Const. Art.8]** conduct warning → removal | **P** | Part 18 §18.5 | Procedure remains `PROPOSED` |
| **[S: Const. Art.12]** AI recommends, humans decide | **P** | Part 30; INV-4; Rule D-60 | **The strongest constraint in the hierarchy for this document** |
| **[S: Const. Art.14]** performance monthly and multidimensional | **P** | Part 6; Part 8; C-D-04 | Cadence unchanged; windows added |
| **[S: Const. Art.15]** best team advances | **P** | Part 10; Part 32; **C-D-01** | **TRUE CONTRADICTION at operational level — NOT RESOLVED** |
| **[S: Const. Art.16]** audit | **P** | Part 34; Part 37 §37.4 | — |
| **[S: Ch.2]** not status-based | **P** | Part 2 | — |
| **[S: Ch.3]** four pillars | **N** | — | Out of scope |
| **[S: Ch.4]** four levels | **P** | Part 32 | — |
| **[S: Ch.5–7]** National / State / City | **E** | Part 32 §32.2 | Per-level leadership obligations added |
| **[S: Ch.8]** mohalla 10-step loop | **P** | Part 6; Part 32 | — |
| **[S: Ch.9]** eleven role families with a Succession column; "Cannot do" boundaries | **P/E** | Part 11; Part 19; Part 35; PB-1 | `span_basis` field added (Rule D-38) |
| **[S: Ch.10]** Primary → Sub-Role → Coordinator → Supporting; State A nine functions; delegation is explicit, recorded, RBAC-limited, reviewed | **P/E** | Part 12; Part 26; INV-11, INV-13 | Held-versus-routed table added |
| **[S: Ch.11]** 13-step vacancy lifecycle; six statuses; step 9 reapplication | **P/E** | Part 3; Part 25 §25.3 | Gate E/R inserted at steps 3–7; feedback obligation added |
| **[S: Ch.12]** 12-step member lifecycle; HR record; ten training categories | **P/E** | Part 15 DV-1 | DV-2 Authority Formation is new |
| **[S: Ch.13]** 9-step team growth; autonomy-readiness gate | **P/E** | Part 26; Rule D-33 | Four-capability continuity added as a formation condition |
| **[S: Ch.14]** support-first recovery; six failure types; leadership failure → coaching + deputy → replacement | **P** | Part 18 §18.4; Part 37 §37.3 | **The source's own improvement architecture, implemented not replaced** |
| **[S: Ch.15]** service; outcome verification; do not count planned activities as completed impact | **P** | Part 8 §8.4 | Activity cap AC-1…AC-5 |
| **[S: Ch.16]** protection | **P** | Part 36 §36.4 | VG-1…VG-6 |
| **[S: Ch.18]** waterfall priority order; four distinct finance hands | **P** | INV-2, INV-3; C-D-06; Rule D-103 | **Segregation resolved by routing, never by weakening** |
| **[S: Ch.19 step 13]** payment sheet with formula version | **P** | Part 23; LM-13 | — |
| **[S: Ch.21]** AI | **P** | Part 30 | — |
| **[S: Ch.22]** role/sub-role/vacancy fields; `delegated_authority`; `succession_status`; delegation dates; one primary holder | **P/E** | Parts 11, 12, 29 | SS-0…SS-5 extends "ready/acting/nominated" |
| **[S: Ch.23]** RBAC; Auditor review-only | **P** | Part 29; INV-15 | — |
| **[S: Ch.24]** six dashboards × five cadences | **P** | Part 6 §6.6; Rule D-16 | **Ceiling, not floor** |
| **[S: Ch.25]** six-step performance; weights `PROPOSED`; eight anti-gaming controls; raw-count prohibition | **P/T** | Parts 6, 7, 20 | Weights **preserved verbatim and unaltered**; the raw-count prohibition is extended into the Goodhart Prohibition List |
| **[S: Ch.26]** six-step transition; safeguards; voiding rule; opportunity is not an entitlement | **P/E** | Part 10; Part 18 §18.3 | PT-1…PT-9 and the Decision Record extend the six steps |
| **[S: Ch.27]** audit | **P** | Part 34; Part 37 | — |
| **[S: Ch.30]** roadmap; Phase 2 entry conditions | **P/E** | Rule D-33 | Four-capability condition proposed as an addition |
| **[S: Ch.33]** decision register — `NOT FINAL` and `UNRESOLVED` items | **C** | Part 45 §45.2 | **Twenty items carried forward unchanged. None resolved.** |
| **[S: App. A §1.1]** economic blueprint never attached | **C** | Part 49 §49.1 | All rupee questions remain open |
| **[S: App. A §15.3]** leader allocation | **P/E** | Part 23 | Bounding and itemisation mechanisms added; **no multiplier proposed** |
| **[S: App. A §16]** autonomy; seven boundaries | **P** | Part 37 §37.1; C-D-16 | — |
| **[S: App. A §18.2–§18.3]** scoring formula; metric spec including "adjusted for difficulty" | **P/E** | Part 5 §5.2; Part 8 | The under-used "adjusted for difficulty" clause is operationalised |
| **[S: App. E]** approval and delegation matrix | **P/E** | Part 34 §34.1–§34.2 | RACI added; authorities unchanged |
| **[S: App. F]** evidence standards | **P/E** | Part 5 | Five evidence classes mapped onto it |
| **[S-A: A-08]** protection DO-NOT list | **P** | INV-12; Part 36 §36.4 | — |
| **[S-A: A-09]** incident reporting | **P** | Part 37; MVLS-4 | — |
| **[S-A: A-13/A-14]** reserved matters; apex Deputy; Interim Authority Order; dual custody; §13.5–§13.8 | **P/E** | Part 12; Part 27 | **Carried downward from apex to every level** |
| **[S-A: A-15]** M1–M7 memory instruments | **P/E** | Part 28 | Playbook PB-1…PB-10 extends M6 |
| **[S-A: A-16]** seven founder conditions; four annual tests; §15.4 public representation | **P/E** | Part 27; Rule D-94 | Tests generalised to every level (Part 11 §11.9) |
| **[S-A: A-17…A-20]** classification; necessity test; access separation; sealed categories | **P** | Part 31 | Applied to leadership data types |
| **[S-A: A-21, A-22]** AI | **P** | Part 30 | — |
| **[S-A: A-23 N19]** Council charter | **C** | Part 45 LDR-U12 | **Not created** |
| **[S-B: §17.2]** `P_max` | **P** | Part 14 §14.2 | — |
| **[S-B: §24]** `C_lead`; success tax; B-18 six mechanisms; B-19 Interim Authority Order; §24.5 stock problem | **P/E** | Parts 12, 19, 23, 39 | B-18 implemented in full and extended |
| **[S-B: §25]** `H_gov`; GB-1…GB-6; three unpopular control roles | **P/E** | Parts 24, 48 | Per-role workload ledger added |
| **[S-B: §26]** `σ_max`; MVC-1…MVC-11; control-budget rule; City divisor; B-21; `K_min` | **P/E** | Parts 40, 49 | MVLS is the leadership-system counterpart of MVC |
| **[S-B: §27.3, §27.5]** dashboard fields | **P** | Part 12 §12.6 | **The continuity dashboard completes two fields v1.3-B already specified** |
| **[S-B: §40]** one pilot, no technology, B-P-01…B-P-14 | **P/E** | Part 41 | **LM-1…LM-15 added to the same pilot. No second pilot created.** |
| **[S-C: H-02, H-03, H-17]** spectrum; no recruitment at vulnerability; refusal rights | **P** | Parts 25, 50; INV-16, INV-17 | — |
| **[S-C: H-08, H-09, H-10, §23.1–§23.3]** six instruments; contribution record; credential | **P** | Part 22; Part 21 §21.6 | Leadership consequences drawn out |
| **[S-C: §6.9, §6.10]** L7 Leader, L8 Builder endpoint, Elder/Mentor | **P/E** | Part 13 | SP-1…SP-6 extends H-11 |
| **[S-C: §8.2, §8.4]** six endpoints; no higher form of service | **P** | Part 22 §22.3; INV-6 | — |
| **[S-C: §24.2 CR-1…CR-4; §25.3 AC/CK; MLM-1…MLM-7; §44 SA-1…SA-7]** | **P** | Parts 31, 36, 18 | — |
| **[S-C: §45]** local hero; four charismatic-leader guards | **P/E** | Part 36 §36.2 | CU-1…CU-10 |
| **[S-C: §47]** specialist path; twelve domains; "a path with no economic expression is a hobby" | **P/E** | Part 13 | Authority ceilings added |
| **[S-C: §57]** human pilot, same team | **P/E** | Part 41 | Same pilot |
| **[S-ST: F-03, F-11, F-14, F-15, F-19…F-26, F-29, F-33]** | **T** | Throughout | Each failure mode given a minimum correction |
| **[S-ST: M8, M9, M10]** | **P** | Parts 9, 16, 18 | Adopted |
| **[S-ST: R5]** leaderboard-public | **C** | Part 21 §21.8; LDR-U11 | **Left open** |
| **[S-ST: §23.1, §23.2]** stage model; twenty-function table | **P/E** | Part 32 §32.3; Part 40 §40.4 | Mapped to MAT-0…MAT-5 |

---

# ANNEXURE B — LEADERSHIP DECISION REGISTER

**[P]** Consolidated index. Full content at **Part 45**.

| Series | Count | Content | Location |
|---|---|---|---|
| **LDR-C01 … LDR-C44** | 44 | Decisions already taken in the source hierarchy, reproduced with status. **None reopened** | Part 45 §45.1 |
| **LDR-U01 … LDR-U20** | 20 | Unresolved / `NOT FINAL` / `PROPOSED` items carried forward **unchanged** | Part 45 §45.2 |
| **LDR-01 … LDR-20** | 20 | New decisions **proposed** by this instrument, each separately mergeable | Part 45 §45.3 |
| **Rules D-1 … D-135** | 135 | Operating rules issued inline across Parts 1–52 | Throughout |

**[A]** The two registers that matter most for approval are **LDR-U** (what this document refused to decide) and **L-01…L-40** (what it proposes). **No item in LDR-U may be closed by adopting any item in L.**

---

# ANNEXURE C — PROFESSIONAL VALIDATION REGISTER

**[P]** Every item in this document marked **[V]**. **None may be adopted before the corresponding validation is obtained.**

| ID | Subject | Why validation is required | Discipline | Blocking? |
|---|---|---|---|---|
| **LV-1** | Gate R readiness assessment methodology | Judging a person's capability to hold authority over others is an organisational-psychology instrument with real consequences | Organisational psychology | **Yes** — L-01, L-12 |
| **LV-2** | The twelve authority capabilities AF-C1…AF-C12 | Construct validity of behavioural capability descriptors | Organisational psychology | **Yes** — L-12 |
| **LV-3** | Downward movement and dignified exit (Rule D-26) | Whether demotion or role reduction is lawful and how it must be conducted depends on worker classification, which is `UNRESOLVED` | Employment law | **Yes** — L-09 |
| **LV-4** | Improvement plans and removal (IP-1…IP-7; RM-1…RM-10) | Procedural fairness requirements; sham-plan risk | Employment law | **Yes** — L-23 |
| **LV-5** | Non-retaliation with reversed burden of proof | Whether the burden may lawfully be reversed | Employment / civil law | **Yes** — L-23 |
| **LV-6** | Suspension and payment during suspension | Priority-1 obligation versus statutory and contractual constraints | Employment and accounting | **Yes** — L-23 |
| **LV-7** | Leadership allocation, `m_lead`, itemisation and bounding | Tax treatment, worker classification, and any applicable application-of-income requirement | Tax and accounting | **Yes** — L-15 |
| **LV-8** | Entity structure and its governance consequences | Determines who may hold reserved matters, board composition, and 12A/80G/FCRA applicability | Corporate and tax law | **Yes** — LDR-U08, L-33 |
| **LV-9** | Interim reserved-matter procedure (Rule D-113) | Whether a two-body provisional decision is valid depends on the entity structure | Corporate law | **Yes** — L-33 |
| **LV-10** | Authority during incapacity or death of a leader | Continuity of bank mandates, contract authority and platform credentials | Corporate and banking law | **Yes** — L-10 |
| **LV-11** | Data classification and retention for leadership records | DPDP Act 2023 and Rules 2025; retention is `UNRESOLVED` in the source | Data protection law | **Yes** — L-30 |
| **LV-12** | DPIA and Significant Data Fiduciary obligations | Whether obligations apply depends on scale and entity structure | Data protection law | Conditional — L-26, L-30 |
| **LV-13** | Aggregate distribution and disparity reporting (Rule D-79, AI-7) | What may lawfully be collected and used, and whether aggregate pattern reporting creates liability | Data protection and equality law | **Yes** — L-27, L-26 |
| **LV-14** | Witness statements (F-360a) as personal data | Named statements about a person's behaviour are sensitive personal data in substance | Data protection law | **Yes** — L-13 |
| **LV-15** | AI fairness controls, explainability and prohibited inputs | Algorithmic-audit expectations; Art.12 compliance in substance | Data protection and technology law | **Yes** — L-26 |
| **LV-16** | Rule D-107 — historical bias not used as prediction labels | Whether this is technically achievable with available data | Machine-learning engineering | **Yes** — L-26 |
| **LV-17** | Safeguarding procedures for complaints involving minors or vulnerable adults | Statutory obligations; designated-role requirements | Safeguarding law | **Yes** — L-23 |
| **LV-18** | Protection pillar legal basis; private-arrest and assistance provisions | BNSS 2023 ss.31, 40, 43 and state variations | Criminal law | **Yes** — L-35 |
| **LV-19** | Political activity, civic rights and 12A conditions | 12A exemption is conditional on no political activity or support to any party or candidate | Tax and regulatory law | **Yes** — L-35 |
| **LV-20** | Foreign contribution, if any | FCRA requirements, track record and dedicated account | Regulatory law | Conditional — L-35 |
| **LV-21** | Occupational health: LLI bands and burnout signals | Whether structural-only detection is adequate and what duties arise | Occupational health | **Yes** — L-25 |
| **LV-22** | Insurance and liability for leaders acting under TL-3 | Cover for acts performed under emergency authority | Insurance | **Yes** — L-10, L-36 |
| **LV-23** | Youth participation and role-holding | Age-related legal constraints differ by jurisdiction and role | Employment and safeguarding law | **Yes** — Rules D-84…D-88 |
| **LV-24** | Portable credentials (H-10 / SP-series) | Whether a credential creates any representation, warranty or professional-liability exposure | Legal | Conditional — L-11 |
| **LV-25** | Audit-log retention and immutability (TA-h) | Retention period is `UNRESOLVED`; **[X]** DPDP Rules contemplate at least one year for specified purposes | Data protection and accounting law | **Yes** — L-17 |

---

# ANNEXURE D — LEADERSHIP FAILURE-MODE REGISTER

**[P]** Consolidated index. Full content at **Part 43**; gaming-specific modes at **Part 20**.

| Series | Count | Content | Location |
|---|---|---|---|
| **LF-01 … LF-30** | 30 | Leadership failure modes with cause, effect, likelihood, impact, control and residual risk | Part 43 §43.2 |
| **GF-1 … GF-30** | 30 | Gaming failure modes with incentive, behaviour, detection signal and minimum correction | Part 20 §20.2 |
| **ATK-01 … ATK-20** | 20 | Red-team attacks with detection and residual risk | Part 43 §43.1 |
| **SEC-1 … SEC-10** | 10 | Security and access threats | Part 29 §29.5 |
| **E-1 … E-7** | 7 | Layer-explosion modes | Part 14 §14.5 |
| **UC-1 … UC-5** | 5 | Unintended consequences of the successor duty | Part 11 §11.6 |
| **SI-1 … SI-6** | 6 | Specialist-path status-inflation risks | Part 13 §13.7 |
| **LF-1 … LF-4** (fatigue) | 4 | Leaderboard fatigue mechanisms | Part 21 §21.4 |
| **OB-1 … OB-7** | 7 | Opportunity access barriers | Part 25 §25.2 |
| **ML-1 … ML-8** | 8 | Cross-level leadership failure modes | Part 32 §32.4 |
| **DF-1 … DF-3** | 3 | Workload distribution failures | Part 24 §24.4 |
| **BN-1 … BN-9** | 9 | Burnout signals, structural only | Part 24 §24.3 |

**[A] The five unresolved failure modes: LF-04 (at Stage 1), LF-06, LF-14, LF-17, LF-29.** Each requires an external observer, an external payer or an external capacity the organisation does not yet have. **No further architectural work closes them.**

---

# ANNEXURE E — LEADERSHIP METRICS DICTIONARY

**[P]** Every measure this document defines, with its object, unit, owner and prohibited use.

| Metric | Object | Unit | Owner | Cadence | Prohibited use |
|---|---|---|---|---|---|
| **LM-1 … LM-15** | As Part 44 §44.2 | As specified | As specified | As specified | As specified — **none may rank an individual** |
| **LLI (L0…L3)** | A role-holder's leadership load share | Band | City owner | Per RV-2 cycle | Individual ranking; any assessment consequence (Rule D-76) |
| **LDI (DEP-C/H/M/L)** | A role in a unit | Band | City owner + Audit | Per RV-3 cycle | Any finding about the person (Rule D-123) |
| **D-team** | A team | Ratio | City owner | Per cycle | Public targeting (Rule D-37) |
| **D-ready** | Covered roles | Ratio | HR | Per cycle | Public targeting |
| **D-control** | Teams | Ratio, **floor = 1.0 for operating units** | City owner | Continuous | — |
| **D-pipeline** | Members | Ratio | HR | Per cycle | Recruitment quota (Rule D-88) |
| **D-city** | City | Ratio | State | Per cycle | — |
| **SS-0 … SS-5** | A covered role | State | Role-holder + HR | Continuous | A grade of the named person (C-D-10) |
| **PG-1 … PG-12** | A team | Pass / fail | Performance + Audit | Per cycle | Disabling payment; disabling dignity |
| **Gate E** | A person | Pass / fail | Eligibility engine + HR | Per vacancy | Anything beyond consideration |
| **Gate R** | A person | Ready / not ready now | Out-of-team assessor | Per candidate | Public disclosure |
| **Confidence (HIGH/MEDIUM/LOW)** | A composite output | Attribute | Performance | Per output | Treating LOW as a pass |
| **`H_gov`** | A team | Hours per month | City owner | Monthly | Cross-team punitive comparison |
| **`H_lead`, `H_dev`, `H_incident`, `H_unrecorded`** | A role | Hours | Role-holder | Per cycle | Individual ranking |
| **`σ_max`** | A team | Hours ceiling | Derived from unit economics **[S-B: §26.1]** | Per period | — |
| **`m_lead`** | A role | Multiplier | **`NOT FINAL` — source hierarchy** | — | **Any value asserted by this document** |
| **`c`, `n_min`, `K_min`, `H_gov_per_team(K)`** | A team / a city | Coefficient / count / function | **`UNRESOLVED` or `UNKNOWN — MEASURE IN PILOT`** | — | **Any value asserted** |
| **Maturity MAT-0 … MAT-5** | A unit | Level, determined by operation not documentation | Stage-gate governance | Per stage | Public league table |
| **Four annual test counts** | The institution | Four integers | Audit + governance body | Annual | Ranking; individual assessment |

---

# ANNEXURE F — ROLE & AUTHORITY MATRIX (MOHALLA → CITY → STATE → NATIONAL)

**[P]** Built on **[S: Ch.9]**'s eleven role families, **[S: Ch.10]**'s four-level catalogue, **[S: Ch.23]**'s RBAC and **[S: App. E]**'s approval matrix. **No authority is invented. Where the source is silent, the cell reads `[U]`.**

## F.1 Authority by level — what each level may decide

| Authority | Mohalla | City | State | National |
|---|---|---|---|---|
| Allocate tasks within a team | **Yes** **[S: Ch.8]** | Oversight | — | — |
| Approve expenditure within local limit | **Yes, within limit** **[S: App. E]** | Above local limit | Above City limit | **[U]** — reserved matters frozen |
| Approve expenditure above limit | **No** | **Yes** | **Yes** | **[U]** |
| Verify one's own work | **No — INV-11, [S: Ch.18]** | No | No | No |
| Appoint to a team role | Team Leader + HR **[S: App. E]** | Co-review | Co-review | — |
| Appoint to a City role | — | City owner + HR | Co-review | — |
| Appoint to a State role | — | — | State owner + HR | Co-review |
| **Leadership transfer** | — | — | — | **CEO / governance process [S: App. E] — rules `NOT FINAL`** |
| Suspend | HR / Safety / Leader **[S: App. E]** | Same | Same | Same |
| Remove for serious misconduct | **Governance/HR panel — never local** **[S: App. E]** | Panel | Panel | Panel |
| Assess Gate R | **No — requires out-of-team (Rule D-45)** | **Yes** | **Yes** | **Yes** |
| Finalise a score | Performance / Audit **[S: App. E]** | Escalation on tie/anomaly/transfer | — | — |
| Change platform permissions | **No** | Technology admin **[S: App. E]** | Technology admin | Technology admin |
| Stop work on safety grounds | **Yes — any holder of STOP (Rule D-33)** | Yes | Yes | Yes |
| Declare an emergency (TL-3) | **Yes, locally, with automatic expiry** | Yes | Yes | Yes |
| Renew an emergency | **No — a higher authority renews (Rule D-30(2))** | Yes, for its level | Yes | **[U]** |
| Decide a reserved matter | **No — absolutely (Rule D-30(3))** | **No** | **No** | **Reserved; holder `[U]` — Rule D-113 interim procedure applies** |
| Authorise a new team / expansion | **No** | **Yes, subject to XG-1…XG-8** | Yes | Yes |
| Change a standard | **No — may request via M3** | **No — may request** | Versioned change (M2/M3) | Versioned change |
| Publish externally | **No** | Authorised spokesperson by domain and region **[S-A: A-16 §15.4]** | Same | **In the organisation's name (PR-1)** |

## F.2 The eleven role families and their leadership-system obligations

**[S: Ch.9]** role families, each already carrying purpose, authority, limits, inputs, outputs, metrics, training, reporting and **succession**. v1.3-D obligations added:

| Role family | SS obligation (§11.3) | Gate R required? | Playbook | LDI relevance | Specific "Cannot do" **[S: Ch.9]** |
|---|---|---|---|---|---|
| **Team Leader** | **SS-4 mandatory** | **Yes** | PB-1…PB-10 | **DECIDE** | Cannot bypass verification, spend outside limits, hide incidents, punish people or change pay rules |
| **Sub-Leader / Deputy** | SS-4 for the role they deputise | Yes | PB-1…PB-6 | Reduces LDI | Cannot exceed the delegation's scope |
| **HR & Verification** | SS-4 mandatory | Yes | PB-1…PB-10 | **VERIFY** | Cannot verify one's own work; cannot disclose sealed categories |
| **Funds / Finance** | SS-4 mandatory | Yes | PB-1…PB-10 | **PAY** | Cannot combine receive + record + approve + audit **[S: Ch.18]** |
| **Safety / Protection** | SS-4 mandatory | Yes | PB-1…PB-10 | **STOP** | Cannot exceed the DO-NOT list **[S-A: A-08]**; cannot act on popular demand (VG-4) |
| **Service delivery** | SS-3 minimum | Where a primary role | PB-1…PB-6 | Moderate | Cannot count planned activity as completed impact **[S: Ch.15]** |
| **Business / venture** | SS-3 minimum | Where a primary role | PB-1…PB-6 | Moderate | Cannot self-approve a venture category **[S: Ch.33 POTENTIAL]** |
| **Media / Editor** | SS-3 minimum | Where a primary role | PB-1…PB-6 | Low | Cannot publish unverified facts; cannot speak for the organisation without authorisation **[S: Ch.24]** |
| **Technology / platform** | SS-4 mandatory where credential custody is held | Yes | PB-1…PB-10 | **Access continuity** | Cannot alter permissions without a record; cannot hold operational command |
| **Audit** | SS-4 mandatory | Yes | PB-1…PB-10 | Independence | **Review only; not operational commander [S: Ch.23]** |
| **Training** | SS-3 minimum | Where a primary role | PB-1…PB-6 | Pipeline capacity | Cannot certify without an out-of-team assessment (Rule D-48) |

## F.3 Authority ceilings on the specialist track

**[P]** SP-1…SP-6 confer **no command at any stage** (Part 13 §13.3). Reproduced here for the matrix's completeness:

| Stage | Verification authority | Advisory authority | Standard ownership | Command |
|---|---|---|---|---|
| SP-1 | None | None | None | **None** |
| SP-2 | Within delegated scope | None | None | **None** |
| SP-3 | **Within the skill** | None | None | **None** |
| SP-4 | Within the skill | **Yes — advises, never commands** | None | **None** |
| SP-5 | By witness only | Yes | None | **None — excluded from RBAC command and scoring [S-C: §6.10]** |
| SP-6 | Within the skill | Yes | **Yes, via M2/M3** | **None** |

---

# ANNEXURE G — SUCCESSION MATRIX

**[P]** Every covered role class, its mandatory succession state, its continuity route, and its failure consequence.

## G.1 Mandatory succession state by role class

| Role class | Level | Mandatory state | Continuity route if unmet | Consequence of SS-0/SS-1 |
|---|---|---|---|---|
| **Team Leader** | Mohalla | **SS-4** | TL-2 + City cover | Expansion blocked (XG-8); promotion blocked (LG-series); LDI DEP-C |
| **HR & Verification** | Mohalla | **SS-4** | City performs verification **[S-B: MVC-2]** | Verification stops → evidence stops → Gate R impossible |
| **Funds** | Mohalla | **SS-4** | City shared funds review **[S-B: B-21]** | **Worker compensation at risk — priority 1 breached** |
| **Safety / Protection** | Mohalla | **SS-4** | STOP capability must be present in the team | Stop-work authority lapses |
| **Technology / credential custody** | Mohalla/City | **SS-4** | Dual custody **[S-A: A-14 §13.4]** | Access loss or takeover |
| **City owner / City Head Team** | City | **SS-4 + SS-5 exercised** | State cover | **`K` mohallas lose verification, funds review and assessment simultaneously (Scenario D)** |
| **City assessor (out-of-team)** | City | **SS-4** | State or another city | **Gate R cannot be performed — the ES.5 correction fails** |
| **City funds reviewer** | City | **SS-4** | State | Approval capacity above local limits lapses |
| **State owner** | State | **SS-4 + SS-5** | National cover | Multi-city degradation |
| **Apex (CEO / equivalent)** | National | **SS-5, exercised annually [S-A: A-14 §13.8]** | Apex Deputy + Interim Authority Order **[S-A: A-14]** | Reserved matters frozen; institutional continuity at risk |
| **Audit** | City and above | **SS-4** | External reviewer **[V]** | Independence lapses |
| **Coordinator / Supporting roles** | Mohalla | **SS-2 minimum** | Cross-training within the team | Localised function gap |
| **Specialist SP-3 verifier** | City | **SS-3** | Another verifier; rotation | Verification monopoly risk (GF-27) |
| **Elder / Mentor** | Any | **Not applicable — standing, not a role** | Another Elder | Memory gap; M7 oral history mitigates |

## G.2 Succession state definitions and transitions

| State | Definition | Entry condition | Exit condition |
|---|---|---|---|
| **SS-0 NONE** | No successor considered | Default | A person is identified → SS-1 |
| **SS-1 IDENTIFIED** | A person is named but nothing is known about readiness | Nomination recorded | Assessment begins → SS-2 |
| **SS-2 IN DEVELOPMENT** | Delegated practice under way; LE-2/LE-3 accumulating | TL-4 delegation issued | Gate R assessment → SS-3 |
| **SS-3 NOMINATED** | Assessed, not yet ready | Gate R attempted | Gate R passed → SS-4 |
| **SS-4 READY** | Gate R passed by an out-of-team assessor; delegation exercised at least once | Gate R pass + SD-c | Dry-run completed → SS-5 |
| **SS-5 EXERCISED** | The successor has held the role under TL-1/TL-2/TL-3 or a full dry-run, with a review | CT-A or CT-C pass | Transition, or reversion to SS-4 on review |

**[A]** The distinction between SS-4 and SS-5 is the distinction the source's own field values — "ready / acting / nominated" **[S: Ch.22]** — already imply but do not operationalise. **SS-5 is the only state that has been tested, and Rule D-122 makes an untested SS-4 worth less than a tested one.**

## G.3 The succession loop

```
RECORD STATE -> IDENTIFY -> DEVELOP (DV-1..DV-5, TL-4 delegation)
     ^                                    |
     |                                    v
  RE-RECORD  <-  TRANSITION (PT-1..PT-9)  <-  ASSESS (Gate R, out-of-team)
     ^                 |                          |
     |                 v                          v
     +--- TEST (CT-A/B/C) <--- REVIEW (RV-3) <--- SS-4 / SS-5
```

---

# ANNEXURE H — AMENDMENT REGISTER

**[P]** Index to **Part 46**. All forty amendments carry the twenty mandated fields there.

| ID | Title | Part | Stage | Status |
|---|---|---|---|---|
| **L-01** | Eligibility and Readiness Separation | 3 | 2 | PROPOSED — PILOT FIRST |
| **L-02** | Leadership Capability Model LC-1…LC-20 | 4 | 2 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **L-03** | Leadership Evidence Model LE-1…LE-5 and portfolio | 5 | 2 | PROPOSED — PILOT FIRST |
| **L-04** | Performance Gate Architecture PG-1…PG-12 | 7 | 1 core / 2 full | PROPOSED — REQUIRES APPROVAL |
| **L-05** | Outcome Windows, Confidence and Honesty Scoring | 8 | 2 | PROPOSED — REQUIRES APPROVAL |
| **L-06** | Cohort Normalisation CN-1…CN-7 | 9 | 2 | PROPOSED — REQUIRES APPROVAL |
| **L-07** | Baseline, Maturity and Provisional Status | 8, 9 | 2 | PROPOSED — REQUIRES APPROVAL |
| **L-08** | Succession State Model SS-0…SS-5 | 11 | 1 | PROPOSED — REQUIRES APPROVAL |
| **L-09** | Promotion Transition Protocol and Decision Record | 10 | 4 | PROPOSED — REQUIRES APPROVAL |
| **L-10** | Temporary Leadership Instruments TL-1…TL-5 | 12 | 1 | PROPOSED — REQUIRES APPROVAL |
| **L-11** | Triple Career Architecture | 13 | 3 | PROPOSED — REQUIRES APPROVAL |
| **L-12** | Development Programme and Authority Formation | 15 | 2 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **L-13** | Review Types RV-1…RV-4 and Decomposed 360 | 17 | 2 | PROPOSED — REQUIRES APPROVAL |
| **L-14** | Succession as a Performance Dimension | 19 | 2 | PROPOSED — REQUIRES APPROVAL |
| **L-15** | Leadership Compensation Structure | 23 | 4 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **L-16** | Role Playbook and Relational Memory | 28 | 1 / 2 | PROPOSED — REQUIRES APPROVAL |
| **L-17** | Transition Access Protocol | 29 | 1 | PROPOSED — REQUIRES APPROVAL |
| **L-18** | Anti-Gaming Register and Goodhart Prohibition List | 20 | 1 subset / 3 full | PROPOSED — REQUIRES APPROVAL |
| **L-19** | Cult Resistance Controls CU-1…CU-10 | 36 | 2 | PROPOSED — REQUIRES APPROVAL |
| **L-20** | Continuity Testing CT-A/B/C | 38 | 2 / 3 | PROPOSED — REQUIRES APPROVAL |
| **L-21** | Minimum Viable Leadership System MVLS-1…MVLS-12 | 40 | 0–1 | PROPOSED — REQUIRES APPROVAL |
| **L-22** | Pipeline and Expansion Gate XG-1…XG-8 | 14 | 2 | PROPOSED — REQUIRES APPROVAL |
| **L-23** | Complaints, Appeals, Improvement and Removal | 18 | 1 / 2 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **L-24** | Leaderboard Scope and Recognition–Authority Separation | 21, 22 | 1 | PROPOSED — REQUIRES APPROVAL |
| **L-25** | Load and Dependency Indices LLI / LDI | 24, 38 | 2 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **L-26** | AI-Assisted Leadership Boundary AI-1…AI-8 | 30 | 2 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **L-27** | Opportunity Fairness and Access OB-1…OB-7 | 25 | 1 / 2 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **L-28** | Staffing, Span and Function Routing | 26 | 1 | PROPOSED — REQUIRES APPROVAL |
| **L-29** | Founder Concentration and Institutional Independence | 27 | 2 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **L-30** | Privacy and Data Classification for Leadership Records | 31 | 1 / 2 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **L-31** | Multi-Level Leadership Differentiation | 32 | 0–1 onward | PROPOSED — REQUIRES APPROVAL |
| **L-32** | Selection Typology and Democracy of Voice | 33 | 1 | PROPOSED — REQUIRES APPROVAL |
| **L-33** | Governance Bodies, RACI and Interim Reserved-Matter Procedure | 34 | 2 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **L-34** | Conflict of Interest and Anti-Favouritism | 35 | 2 | PROPOSED — REQUIRES APPROVAL |
| **L-35** | Anti-Capture Controls — MLM, Vigilante, Political | 36 | 1 / 2 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **L-36** | Crisis Leadership and Incident Review | 37 | 1 | PROPOSED — REQUIRES APPROVAL |
| **L-37** | Leadership Economics and Feasibility | 39 | 2 | PROPOSED — REQUIRES PROFESSIONAL VALIDATION |
| **L-38** | Maturity Model and Simplification Obligation | 40 | 1 | PROPOSED — REQUIRES APPROVAL |
| **L-39** | Pilot Integration and Scope Statement | 41 | 0–1 | PROPOSED — PILOT FIRST |
| **L-40** | Leadership Invariants, Local Adaptation and Final Architecture | 51 | 2 | PROPOSED — REQUIRES APPROVAL |

**Merge waves:** **W1 (Stage 0–1):** L-21, L-08, L-10, L-17, L-36, L-32, L-24. **W2 (Stage 1–2):** L-01, L-03, L-04, L-23, L-27, L-28, L-16, L-39. **W3 (Stage 2):** L-02, L-12, L-13, L-14, L-05, L-06, L-07, L-20, L-25, L-29, L-30, L-33, L-34. **W4 (Stage 3+):** L-09, L-11, L-15, L-18, L-19, L-22, L-26, L-31, L-35, L-37, L-38, L-40.

---

# ANNEXURE I — PILOT MEASUREMENT PLAN (THE FIFTEEN MEASUREMENTS)

**[P]** The single shared pilot: **one mohalla team, no technology** **[S-B: §40]**, the same team as **[S-C: §57]**. **No second pilot is created (Rule D-130).** `B-P-01…B-P-14` **[S-B]** and the human-system measurements **[S-C]** run alongside; **LM-1…LM-15 are added.**

**Namespace rule (Rule D-129):** `P-nn` in Part 42 = performance adversarial simulation. `B-P-nn` = **[S-B: §40]** pilot measurement. **The two are unrelated.**

| ID | Measurement | Method on paper | Source of truth | Testable by one team? | Minimum population if not | Threshold |
|---|---|---|---|---|---|---|
| **LM-1** | Succession coverage | Count covered roles; count those at SS-4/SS-5 | SS state record | **PARTIAL** — one team has few covered roles | ≥ 5 covered roles across ≥ 2 units | `PROPOSED`; 100% for mandatory-SS-4 is a gate |
| **LM-2** | Continuity exercise rate | Count CT-A/CT-B exercises performed and passed | Exercise record | **YES** for CT-A/CT-B | CT-C needs a City | `UNKNOWN — MEASURE IN PILOT` |
| **LM-3** | Decision-record completeness | Count consequential decisions; count complete M1 records | M1 register | **YES** | — | `PROPOSED` |
| **LM-4** | Time-to-fill a vacancy | Date declared → date appointed | **[S: Ch.11]** lifecycle record | **PARTIAL** — needs a vacancy to occur | ≥ 3 vacancies | `UNKNOWN — MEASURE IN PILOT` |
| **LM-5** | Interim duration | Days under TL-1/2/3; count extensions | Delegation records | **YES** | — | `UNKNOWN` |
| **LM-6** | Leadership load distribution | Ledger entries; LLI band per role | Workload ledger | **YES** | — | Bands, not targets |
| **LM-7** | Dependency exposure | LDI band per covered role; count DEP-C | LDI inputs | **YES** | — | DEP-C reported absolutely |
| **LM-8** | Opportunity-allocation pattern | Count allocations of visible projects, delegations, training places | Rule D-116 record | **NO** — one team has no internal distribution to analyse | ≥ 8 members across ≥ 3 teams | No target |
| **LM-9** | Complaint and appeal volume | Count by channel and outcome class | Part 18 records | **PARTIAL** — volume will be near zero; **zero is a warning, not a success** | ≥ 3 units for suppression-safe reporting | Zero flagged anomalous |
| **LM-10** | Appeal outcome rate | Successful ÷ decided, by decision-maker | §18.3 records | **NO** — needs volume and suppression | ≥ 20 appeals | Escalation on a high rate |
| **LM-11** | Honest-reporting latency | Date of failure → date of report; internal-first share | Incident records | **YES** | — | `UNKNOWN — MEASURE IN PILOT` |
| **LM-12** | Governance-hour load | Hours logged per role per month; total `H_gov` | Workload ledger | **YES — this is the single most valuable measurement in the plan** | — | Against the **8–40 h/team/month** observation window and `σ_max` |
| **LM-13** | Leadership-cost ratio | Itemised leadership hours ÷ total worker-compensation hours | Payment records | **PARTIAL** — `m_lead` is `NOT FINAL`, so no allocation may exist to measure | Approval of `m_lead` | **No value asserted** |
| **LM-14** | Pipeline throughput | Count members at each PL-0…PL-6 stage | Part 14 records | **PARTIAL** — one team shows PL-0…PL-4 only | ≥ 3 units | No target |
| **LM-15** | Institutional independence counts | The four annual integers: absence, attribution, dissent, successor | **[S-A: A-16]**; Rule D-94 | **PARTIAL** — dissent and attribution measurable locally; absence and successor need an apex | An apex body for T1/T4 | **Zero is a warning sign** |

## I.1 Pilot testability summary

| Category | Count | Items |
|---|---|---|
| **Fully testable by one team on paper** | 6 | LM-2 (CT-A/B), LM-3, LM-5, LM-6, LM-7, LM-11, LM-12 |
| **Partially testable** | 6 | LM-1, LM-4, LM-9, LM-13, LM-14, LM-15 |
| **NOT TESTABLE AT PILOT SCALE** | 2 | **LM-8, LM-10** |

**[P]** Per Rule D-131, LM-8 and LM-10 are recorded as **`NOT TESTABLE AT PILOT SCALE`** with their minimum populations stated. **They are not approximated, estimated or inferred from a single team.**

## I.2 What the pilot will and will not prove about leadership

| Will prove | Will not prove |
|---|---|
| Whether MVLS is operable by real people without technology | Whether succession works at scale |
| What `H_gov` actually is | Whether promotion is safe for the sending team |
| Whether decision records survive a real week | Whether out-of-team assessment works — **there is no outside** |
| Whether a delegation can be issued, exercised and reviewed | Whether cohort normalisation is fair |
| Whether honest failure reporting happens when it costs something | Whether the burden is affordable at scale — **no technology, no range of `K`** |
| Whether refusal rights are exercised without social cost | Whether favouritism is prevented |
| Whether four capability routes actually exist | Whether `m_lead` is sustainable — **no value is tested** |

---

# ANNEXURE J — OPEN QUESTIONS

**[P]** Questions this document **refuses to answer**, with the reason and the authority that must answer.

| ID | Open question | Why it is open | Who must answer | Consequence if unanswered |
|---|---|---|---|---|
| **OQ-01** | **Does the CEO or a National Council hold executive authority?** | `UNRESOLVED` **[S: Ch.33; Ch.4]**; Rule 2 forbids closing it | The source hierarchy / founder | Seven reserved matters have no holder. Rule D-113 is a stopgap, not an answer |
| **OQ-02** | **When Const. Art.15 says the best Mohalla Team becomes the City Head Team, do the people move or does the label move?** | **C-D-01 — TRUE CONTRADICTION** at the operational level; Art.15 is APPROVED and cannot be reinterpreted here | Constitutional reading by the source hierarchy | Promotion cannot be executed at scale without hollowing out the sending unit |
| **OQ-03** | **What is `m_lead`?** | `NOT FINAL` **[S: Ch.33; App. A §15.3]**; the brief forbids inventing salaries | Source hierarchy, after pilot measurement of `H_gov` and leadership hours | The leadership allocation cannot be paid lawfully or defensibly |
| **OQ-04** | **What are the performance weights?** | `PROPOSED` **[S: Ch.25]**; Rule D-61 declines to add a ninth dimension | Source hierarchy | Two-speed scoring operates on unapproved weights |
| **OQ-05** | **What is the legal entity structure under Krytos?** | `UNRESOLVED` **[S: Ch.33]** | Legal and tax advisors **[LV-8]** | 12A political-activity conditions, 80G, FCRA, board composition and reserved-matter validity all undetermined |
| **OQ-06** | **How are workers classified?** | `UNRESOLVED` **[S: Ch.33]** | Employment-law advisors **[LV-3, LV-4, LV-6]** | Improvement plans, removal, suspension, pay and demotion all carry unassessed legal risk |
| **OQ-07** | **What is the data retention period?** | `UNRESOLVED` **[S: Ch.33; S-A: A-17 P2]** | Data-protection advisors **[LV-11, LV-25]** | TA-h audit-log retention, contribution-record retention and erasure rights undetermined |
| **OQ-08** | **Should the leaderboard be public at all?** | **[S-ST: R5]** open reconsideration; **[S-C: §44.4]** | Source hierarchy, after pilot measurement | Part 21 §21.8 specifies what must be true under either answer, but the answer is not given |
| **OQ-09** | **What are the minimum staffing thresholds, `n_min`, `c` and `K_min`?** | `NOT FINAL` — "no final numbers invented" **[S: Ch.33]**; **[S-B: §26, §40.2]** | Pilot measurement | A team may be authorised below the point at which it can hold its duties |
| **OQ-10** | **What is the shape of the City divisor `H_gov_per_team(K)`?** | Unresolved **[S-B: §26]** | Measurement across a range of `K`; Rule D-91 gates State formation on it | If super-linear, adding cities adds governance faster than capacity |
| **OQ-11** | **What is the team readiness threshold?** | `NOT FINAL` **[S: Ch.33]** | Source hierarchy, after pilot | PG gates operate structurally but not numerically |
| **OQ-12** | **What is the serious-misconduct procedure?** | `PROPOSED` **[S: Ch.33]** | Source hierarchy with legal validation **[LV-4]** | RM-1…RM-10 is a proposal with no approved status |
| **OQ-13** | **Who succeeds the founder?** | **No instrument in the source hierarchy names anyone, and this document refuses to (INV-20)** | The founder and the body that will hold reserved matters | T4 successor test cannot be satisfied at apex |
| **OQ-14** | **At what population does anonymity become arithmetically plausible?** | Rule D-55's threshold is `UNKNOWN` | Pilot and scale measurement | Anonymous instruments may be offered where anonymity does not exist — worse than offering none |
| **OQ-15** | **What is the small-cell suppression threshold?** | Rule D-108's threshold is `UNKNOWN` | Data-protection advice **[LV-13]** plus scale measurement | Aggregate reports may identify individuals in small cohorts |
| **OQ-16** | **How long is the unreachability period before a disappearance triggers continuity?** | Scenario J's period is `[P] UNKNOWN` | Operational judgement plus legal advice **[LV-10]** | Too short: a person on a train loses their role. Too long: the unit is leaderless for a week |
| **OQ-17** | **What are the apprenticeship, improvement-plan and RV-3 cycle durations?** | All `[P] UNKNOWN — MEASURE IN PILOT`; the brief forbids inventing time requirements | Pilot measurement | Durations are set informally, which means they are set by whoever is in a hurry |
| **OQ-18** | **May a political role-holder continue to hold organisational leadership?** | PC-2 protects civic rights; PC-3 separates capacities; **the tension is real and cannot be resolved by rule (§36.5)** | Source hierarchy with legal advice **[LV-19]** | Local capture risk (LF-24) versus exclusion of capable local leaders |
| **OQ-19** | **Who holds the reserved matters if the apex is contested?** | Depends on OQ-01 and OQ-05 | Source hierarchy | **[S-A: A-14 §13.6]** keeps operations running, but a contested reserved matter has no resolution route |
| **OQ-20** | **Can the leadership system be made affordable for a person with no spare capacity?** | **EF-5 / EA-12 — the most consequential unknown in this document** | Source hierarchy, after `m_lead` and `H_gov` are known | A formal open ladder that is practically closed to poor people, with no record showing it |
| **OQ-21** | **Is there a route to retrospectively authorise a correct act performed beyond emergency authority?** | Scenario K found none, and creating one would create a loophole | Source hierarchy with legal advice **[LV-22]** | Leaders must choose between doing the right thing and staying inside authority |
| **OQ-22** | **How is nominal compliance detected?** | **LF-17 / P-20 / ATK-20 — no internal control detects it** | Nobody, from inside. Only F-360c, the Integrity Line, skip-level contact, field immersion and operator judgement | The architecture exists, is reported favourably, and does not operate |

---

## END OF INSTRUMENT

**v1.3-D — Leadership, Succession & Performance Architecture.**
**52 Parts · 10 Annexures · 40 Amendments (L-01…L-40) · 135 Rules (D-1…D-135) · 20 Invariants (INV-1…INV-20) · 15 Measurements (LM-1…LM-15) · 22 Open Questions (OQ-01…OQ-22).**
**Status: `LEADERSHIP-SYSTEM DESIGN — PROPOSED`. Verdict: `D — LEADERSHIP SYSTEM NOT YET PROVEN`, with a six-step path to `B`.**
**Nothing in this document is policy, rule or promise until approved. No successor is named. No rupee value, multiplier, term length, span ratio or training-hour count is invented. No `UNRESOLVED` source item is closed.**

**Prepared 5 October 2026.**
