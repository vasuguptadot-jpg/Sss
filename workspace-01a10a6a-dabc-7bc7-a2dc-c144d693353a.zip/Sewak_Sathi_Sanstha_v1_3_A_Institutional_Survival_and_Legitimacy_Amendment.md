# SEWAK SATHI SANSTHA v1.3-A
# INSTITUTIONAL SURVIVAL & LEGITIMACY AMENDMENT

| | |
|---|---|
| **Amendment pack version** | v1.3-A — Institutional Survival & Legitimacy Upgrade (first implementation stage following the strategic stress test) |
| **Base architecture** | `KRYTOS_SEWAK_SATHI_SANSTHA_VISUAL_MASTER_ARCHITECTURE_CONSTITUTION_LAUNCH_SPECIFICATION_v1_2.pdf` (179 pp.), including Appendix A preservation of the v1.1 source (81 pp.) |
| **Analytical source** | `Sewak_Sathi_Strategic_Stress_Test.md` (36 failure modes F-01…F-36; §25 KEEP/MODIFY/RECONSIDER; §26 pre-launch changes) |
| **Scope** | Five CRITICAL institutional failure areas only: (1) political capture/perception, (2) vigilante perception & protection visibility, (3) protection liability/insurance/legal support, (4) founder concentration/mission lock/succession, (5) data estate/privacy/AI governance |
| **Explicitly out of scope** | Redesign of hierarchy, pillars, roles, waterfall, performance system, launch roadmap. No element of v1.2 is removed, replaced or reinterpreted. |
| **Document status** | **AMENDMENT PACK — PROPOSED.** Nothing in this document is organisational policy until approved by the Founder/CEO through the amendment process in Constitution Article 18 **[S]**, and where marked, validated by a qualified professional. |
| **Prepared** | 4 October 2026 |

---

## HOW TO READ THIS AMENDMENT PACK

### Evidence and status labelling (carried forward unchanged from v1.2 and the stress test)

| Tag | Meaning |
|---|---|
| **[S]** | **SOURCE-DERIVED** — stated in v1.2 or the preserved v1.1 source. Referenced by chapter, article, SOP or appendix. |
| **[A]** | **ANALYSIS** — reasoning applied to source facts. |
| **[I]** | **INFERENCE** — probable consequence derived from analysis and general real-world behaviour. |
| **[P]** | **PROPOSAL** — recommended here. Not architecture. Requires approval before it binds anyone. |
| **[V]** | **REQUIRES PROFESSIONAL VALIDATION** — legal, tax, employment, insurance, safeguarding, privacy or regulatory advice required before reliance. |
| **[X]** | **EXTERNAL FACT** — published source outside your documents; cited in full at Annexure C. |

### v1.2 status labels used in this pack **[S: v1.2 front matter]**

`LOCKED / APPROVED ARCHITECTURE` · `PROPOSED — REQUIRES FINAL APPROVAL` · `REQUIRES PROFESSIONAL VALIDATION` · `UNRESOLVED` · `FUTURE IMPLEMENTATION`

### Two separations maintained throughout, as required

**Separation 1 — ORGANISATIONAL POLICY vs. LEGAL / TAX REQUIREMENT.**
Many items in this pack look similar but are fundamentally different in kind. A rule such as *"no partisan use of the organisational brand"* is **organisational policy**: the organisation may adopt it by its own authority. A statement such as *"a tax-exempt charitable entity must not support parties or candidates"* is a **legal/tax proposition** that this document does **not** assert as settled law — it is flagged **[V]** and must be confirmed by counsel before being relied upon or repeated publicly. Wherever both appear together they are printed in separate rows and never merged.

**Separation 2 — CONSTITUTIONAL PRINCIPLE vs. LEGAL ENFORCEABILITY.**
Declaring a principle "foundational" inside the organisation's own constitution is an act of self-binding. Whether that self-binding is *legally* enforceable, against whom, and through what instrument depends entirely on the entity form — which is **UNRESOLVED** in your own register **[S: Ch.33]**. This pack therefore never claims that any principle is legally immutable. It proposes organisational immutability and marks legal enforceability **[V]**.

### The absolute rule applied to this pack

Every safeguard below was tested against one question before inclusion: **"Does this make it harder for an ordinary person to help their neighbour?"** If the answer was yes, the safeguard was moved upward — onto role-holders, onto the City/National layers, or onto the platform — rather than left on the volunteer. §24.9 publishes the resulting burden table so the trade-off is visible rather than assumed.

---

# 1. EXECUTIVE SUMMARY

## 1.1 What this pack does

It converts the five CRITICAL failure modes identified in the stress test — **F-08 political capture, F-09 vigilante perception, F-10 protection liability gap, F-11 founder concentration, F-27 data estate** — into **23 discrete, mergeable amendments (A-01 … A-23)** that sit *alongside* the v1.2 architecture without altering it.

**[S]** v1.2 already contains the correct doctrine in each of the five areas:
- non-discrimination and the six principles **[S: Ch.2]**;
- the protection sequence and the six DO-NOTs **[S: Ch.16]**;
- safety-role boundaries prohibiting weapons, retaliation, unlawful detention/search and police impersonation **[S: Ch.9]**;
- ownership by Krytos under the Founder/CEO with the Council explicitly not above the CEO **[S: Const. Art.3]**;
- AI may recommend, humans decide, with ten prohibited autonomous decisions **[S: Ch.21]**;
- least-privilege data flow with upward minimisation **[S: Ch.6, Ch.22, Ch.23]**.

**[A]** What v1.2 does not contain is the **wrapper**: the instruments that make those doctrines visible to outsiders, enforceable against insiders, survivable after a leadership change, and defensible before a regulator, an insurer, a court or a journalist. This pack supplies only the wrapper.

## 1.2 The one-sentence purpose

> **Make Sewak Sathi institutionally trustworthy before making it nationally attractive.**

**[A]** The reasoning is sequential, not stylistic. Trust failures in the five areas covered here are *irreversible* — a filmed intervention, a leaked conduct record, a politicised distribution event, a succession vacuum, an uncovered injury. Attraction failures are *recoverable* — a slow quarter of recruitment can be repeated. It is therefore rational to buy down irreversible risk first, even at the cost of slower early growth. This pack deliberately slows nothing that a volunteer does; it constrains only role-holders, public representation, money, force and data.

## 1.3 The 23 amendments at a glance

| ID | Amendment | Risk addressed | Status | Merge target |
|---|---|---|---|---|
| A-01 | Political Neutrality Code — organisational neutrality | F-08 | PROPOSED — REQUIRES FINAL APPROVAL; legal/tax items **[V]** | New Ch. 29A + Const. Art. 20 |
| A-02 | Member political activity & conflict-of-interest rules | F-08 | PROPOSED **[V]** (employment/labour) | New Ch. 29A.2 |
| A-03 | Election-Period Operating Protocol | F-08 | PROPOSED **[V]** | New Ch. 29A.3 + SOP-23 |
| A-04 | Political Approach Response Workflow | F-08 | PROPOSED | New Ch. 29A.4 + SOP-24 |
| A-05 | Non-Alignment & Equal Treatment Principle (religion, caste, ethnicity, language, region, status) | F-08, F-31, F-36 | PROPOSED — extends **[S: Ch.2]** without altering it | Const. Art. 21 + Ch. 2A |
| A-06 | Protection Visibility & Public Conduct Protocol | F-09 | PROPOSED **[V]** | New Ch. 16A |
| A-07 | Public Protection Statement | F-09, F-36 | PROPOSED (draft text for approval) | Public document + Ch. 24 |
| A-08 | Protection DO-NOT List — constitutional entrenchment | F-09 | **Restates [S: Ch.16] verbatim**, adds entrenchment | Const. Art. 9 expansion |
| A-09 | Protection Incident Protocol (extended workflow) | F-09, F-10 | PROPOSED — extends **[S: Ch.16, SOP-13]** | Ch. 16B + SOP-13 revision |
| A-10 | Protection Liability Framework (requirements, not coverage) | F-10 | PROPOSED **[V]** throughout | New Ch. 16C |
| A-11 | Protection Activation Gate | F-10, F-25 | PROPOSED — REQUIRES FINAL APPROVAL | New Ch. 16D + Ch. 31 checklist |
| A-12 | Founder Concentration Analysis (no decisions taken) | F-11 | **ANALYSIS ONLY** — unresolved items preserved | Ch. 4A (analytical annex) |
| A-13 | Mission Lock Framework | F-11 | PROPOSED **[V]**; reduces founder flexibility by design — flagged | Const. Art. 22 + Art. 18 procedure |
| A-14 | Succession Architecture | F-11 | PROPOSED **[V]**; **does not name a successor** | Const. Art. 23 + Ch. 26A |
| A-15 | Institutional Memory System | F-11, F-14 | PROPOSED | New Ch. 27A |
| A-16 | Founder vs Institution — durability instruments | F-11 | PROPOSED | New Ch. 4B |
| A-17 | Data Estate Map & Security Classification | F-27 | PROPOSED **[V]** | New Ch. 22A |
| A-18 | Data Minimisation Doctrine & Field Justification Gate | F-27 | PROPOSED **[V]** | New Ch. 22B |
| A-19 | Beneficiary Privacy & Dignity Code | F-27, F-15 §stress | PROPOSED **[V]** | New Ch. 15A + Const. Art. 24 |
| A-20 | Sensitive Incident & Safeguarding Data Model | F-27 | PROPOSED **[V]** | New Ch. 22C |
| A-21 | AI Governance Extension (prohibitions preserved verbatim) | F-29, F-31 | PROPOSED — extends **[S: Ch.21]** | Ch. 21A |
| A-22 | AI Auditability Standard & Review Capacity Governance | F-29 | PROPOSED **[V]** (retention) | Ch. 21B + App. C extension |
| A-23 | Critical Decision Register & Launch Blocker Taxonomy | all | PROPOSED — carries forward **[S: Ch.33]** unchanged | Ch. 33A |

## 1.4 What this pack deliberately does NOT do

1. **It does not resolve any UNRESOLVED item in your register** **[S: Ch.33]**. Legal structure, CEO-vs-Council authority, public name, worker classification, data retention and AI model policy all remain UNRESOLVED and are carried into §22 with their status intact.
2. **It does not name a successor to the founder.** A-14 builds a *mechanism*; the mechanism's first use is a decision for the Founder/CEO and the governance process.
3. **It does not state any legal conclusion.** Where a legal proposition is needed, the pack poses it as a question for counsel and marks it **[V]**.
4. **It does not invent insurance coverage, thresholds or numbers.** A-10 lists *requirements to be validated*; A-11 defines *categories of prerequisite* and marks any proposed threshold `PROPOSED — REQUIRES FINAL APPROVAL`.
5. **It does not add work for ordinary volunteers.** §24.9 publishes the burden table: 17 of 23 amendments place zero new obligation on a member below Coordinator level.
6. **It does not restrict any member's personal civic rights.** A-02 governs *organisational* attribution and resources, never belief, opinion, voting or lawful personal expression (§25 contradiction C-01 records the risk and its guard).

---

# 2. THE FIVE CRITICAL RISKS — RESTATED WITH SOURCE ANCHORS

| # | Critical risk | Stress-test ID | What v1.2 already provides **[S]** | What is missing **[A]** | Amendment(s) |
|---|---|---|---|---|---|
| **1** | **Political capture / political perception** | F-08 | Non-discrimination in service **[Ch.2]**; authorised spokespersons and sensitive-statement approval **[Ch.24]**; partnership due diligence **[Ch.29]**; risks "mission drift", "conflict of interest", "reputational/safeguarding failure" **[Ch.28]**; National Legal & Compliance and Communications departments **[Ch.5]** | Nothing governs: partisan use of brand/resources/records/member lists/events; party office-holding by role-holders; election-period conduct; political approaches and refusals; symbols/dress adjacency; recruitment screening for or against political belief; tax-exempt-status exposure **[V: X]** | A-01 … A-04 |
| **2** | **Vigilante perception / protection visibility** | F-09 | Nine-step intervention sequence **[Ch.16]**; four-tier risk matrix **[Ch.16]**; six DO-NOTs **[Ch.16]**; safety-role boundary **[Ch.9]**; SOP-13 **[App. D]**; "authorities first, no obstruction" **[Ch.15]**; QR concept constrained to "non-police visual design" **[Ch.33]** | No dress/symbol/insignia rule; no group-movement rule; no filming/photography rule at incidents; no do-not-attend list; no public statement of what the organisation is not; no rule on visible presence at crowd events; no authenticity-verification channel for the public | A-06 … A-09 |
| **3** | **Protection liability / legal support / insurance gap** | F-10 | Insurance appears as a launch-checklist blocker **[Ch.31]** and in the decision register as unresolved **[Ch.33]**; incident response "suspend, authority contact" **[Ch.28]**; National Legal & Compliance **[Ch.5]**; caveat that internal training is not legally sufficient **[Ch.12]** | No insurance requirement tied to activation; no legal-support protocol (who instructs counsel, within what time, at whose cost); no injury/property/third-party claim procedure; no member notification of what is and is not covered; no training/authorisation evidence standard supporting any future claim; no review of the intervention boundary against applicable criminal procedure **[V]** | A-10, A-11 |
| **4** | **Founder concentration / mission lock / succession** | F-11 | Ownership by Krytos under Founder/CEO; Council not above CEO unless a charter changes it **[Const. Art.3]**; versioned amendments **[Const. Art.18]**; dissolution/restructuring requires professional validation **[Const. Art.19]**; team-level dynamic leadership and succession **[Ch.26]**; CEO-vs-Council authority **UNRESOLVED** **[Ch.33]** | No founder-succession or incapacity provision; no interim authority order; no mission lock or reserved matters; no apex dispute-resolution mechanism (Art.17 covers *member* disputes only); no institutional archive or decision-rationale record; no continuity test; no rule separating the person from the institution in public representation | A-12 … A-16 |
| **5** | **Data estate / privacy / AI governance** | F-27 (with F-28, F-29, F-31) | Least privilege and upward minimisation **[Ch.6, Ch.22, Ch.23]**; RBAC matrix **[Ch.23]**; privacy-controlled HR content **[Ch.12]**; "avoid unnecessary beneficiary data", "personal recipient lists restricted", "highly restricted" incident evidence **[Ch.15, App. F]**; SOP-22 data breach **[App. D]**; AI doctrine and ten prohibitions **[Ch.21]**; AI audit fields **[Ch.21, Ch.22]**; retention and AI model policy **UNRESOLVED** **[Ch.33]**; DPDP obligations live **[V: X]** | No data classification scheme; no retention schedule or erasure rule; no named privacy owner; no DPIA trigger; no breach-notification timeline or runbook; no privacy notice; no processor/vendor standard; no survivor-centred case handling; no consent architecture separating help from story; no QR use restriction; no AI review capacity model; no language-access rule for legally significant documents | A-17 … A-22 |

**[A] Cross-cutting observation:** in all five areas the missing element is the same *type* of thing — an instrument that operates on **outsiders, time and authority** (perception, continuity, liability, regulator) rather than on **insider behaviour**. v1.2 is exceptionally well-designed for the second and nearly silent on the first. That is why this pack adds almost no new rules about how members should behave, and many new rules about how the *institution* must be able to prove, protect and continue itself.

---

# 3. POLITICAL NEUTRALITY CODE (A-01 … A-04)

**Proposed placement:** new Chapter 29A (after Partnerships and Public Trust), plus Constitution Article 20.
**Status of the whole code:** `PROPOSED — REQUIRES FINAL APPROVAL`. Items marked **[V]** additionally require legal/tax validation before being relied upon or published.

## 3.1 Part A — Organisational neutrality

### A.1 The principle

**[P]** Sewak Sathi Sanstha takes no side in electoral or partisan politics. Its position toward every political party, candidate, movement and ideology is identical: **cooperate on lawful civic issues, align with none.**

**[A]** This is a *structural* rule, not a moral judgement about politics. It exists because the organisation's value proposition — help without discrimination, verified by evidence **[S: Ch.2, Ch.15]** — is not divisible. The first partisan act does not reduce trust by a fraction; it reclassifies the institution permanently for everyone who disagrees.

### A.2 Organisational prohibitions (nine rules)

| # | Prohibition **[P]** | Applies to | Notes |
|---|---|---|---|
| **N1** | No endorsement, support, opposition, praise or criticism of any political party, candidate, coalition or partisan movement by the organisation, any team, any role-holder acting in role, or any organisational channel | All levels | Includes implicit endorsement (hosting, sharing a stage, photo adjacency used organisationally) |
| **N2** | No use of the organisation's name, marks, colours, dress, documents, photographs, member lists, attendance records, distribution capacity, events, vehicles, premises, funds, payment channels or communication channels for any partisan purpose | All levels | The strongest and most testable rule; audit can verify it from records alone |
| **N3** | No organisational participation in political fundraising, political campaigning, election work, poll activity, voter mobilisation for a party or candidate, or crowd mobilisation capable of being read as political | All levels | Distinguish from lawful *civic* activity — see A.4 |
| **N4** | No adoption of political symbols, slogans, flags, colours, insignia, gestures, songs, portraits or dress that identifies the organisation with a party, ideology, caste, community or movement | All levels, plus A-06 | Interlocks with the Protection Visibility Protocol |
| **N5** | No political content in organisational communications, training, dashboards, publications, ceremonies or recognition — including content that is favourable | Comms, Editor, Social Media **[S: Ch.9]** | Extends the existing rule against unverified claims **[S: Ch.24]** |
| **N6** | No acceptance of money, materials, premises, media, transport, publicity or volunteers from a political actor where the offer carries, or could be read as carrying, partisan expectation | Finance, Partnerships **[S: Ch.29]** | Refusals are logged (A.4) |
| **N7** | No use of organisational data — member records, beneficiary records, attendance, contact lists, service records, grievance records — for any political purpose, by anyone, ever | All levels; enforced through A-17…A-20 | The single most serious category; treat breach as serious misconduct **[S: SOP-18]** |
| **N8** | No screening of applicants, members, volunteers, beneficiaries, partners or customers by political belief, affiliation, voting intention or family political history | HR & Verification **[S: Ch.12]** | **Anti-loyalty-test guard** — see §25 C-01. Neutrality must never become a political test |
| **N9** | No representation of the organisation, in any medium, as being affiliated with, sponsored by, opposed to, or in conversation with a political actor — including by omission where omission would mislead | Comms, spokespersons **[S: Ch.24]** | Covers "why didn't you deny it?" situations |

### A.3 Separation: organisational policy vs. legal/tax requirement

**[A]** The nine prohibitions above are organisational policy and may be adopted by the organisation's own authority. The following are **legal/tax propositions that this document does not assert as settled and which must be confirmed by qualified counsel before reliance or public repetition**:

| Legal/tax question — **REQUIRES PROFESSIONAL VALIDATION** **[V]** | Why it matters |
|---|---|
| Whether the chosen entity form may engage in, or is restricted from, political activity — and what "political activity" means for that form | Determines whether N1–N3 are merely prudent or legally mandatory |
| Whether income-tax exemption for a charitable entity is conditional on absence of political activity or support to parties/candidates, and the consequence of breach | Published practitioner guidance indicates such a condition exists and that registration can be jeopardised **[X]** — must be confirmed for the actual entity and circumstances |
| Whether donation/deduction eligibility for donors is affected by any political adjacency | Affects fundraising design (see stress-test F-32) |
| Whether foreign contribution may be received at all, on what conditions, and after what track record, and whether any political adjacency is disqualifying | Practitioner guidance indicates a multi-year track record and dedicated account are generally required **[X]** |
| Whether election-period activity by a non-governmental organisation attracts any notification, permission, expenditure, or model-code-type obligation in a given jurisdiction | Determines whether A-03 is voluntary restraint or legal duty |
| Whether distribution of material near an election could be treated as an electoral offence, an inducement, or expenditure by a third party | Highest-consequence operational question in this code |
| Whether a member's personal political activity can, in any circumstances, be attributed to the organisation legally (agency, vicarious liability, common intent) | Determines how strict A-02 must be |
| Whether restrictions attached to organisational *roles* (A-02) are lawful in the relevant employment/volunteer classification | Employment-law question; classification itself is UNRESOLVED **[S: Ch.33]** |

**[P] Drafting rule:** no public document, training slide or member communication may state a legal or tax conclusion drawn from this table. Only counsel-approved wording may be used, and only after review.

### A.4 What is permitted — the civic/political boundary

**[A]** A neutrality code that cannot distinguish *civic* from *partisan* activity will either be ignored (because it forbids legitimate work) or abused (because it forbids whatever a leader dislikes). The distinction must be written down.

| Permitted: **issue-based civic activity** **[P]** | Prohibited: **partisan activity** |
|---|---|
| Identifying a local problem with evidence (a drain, a school, a water supply) and requesting action from the responsible authority **[S: Ch.8, Ch.15]** | Asking anyone to vote for or against anyone |
| Publishing verified facts about a civic issue, with sources, without attributing blame to a party | Publishing facts selectively to damage or assist a party or candidate |
| Meeting an official in their official capacity about a service issue, with a written record and two members present | Meeting a candidate in their electoral capacity, or hosting them |
| Submitting a representation, petition or public-interest request through lawful channels | Organising or supplying crowds to any political event |
| Encouraging lawful civic participation in general (e.g. "know your entitlements", "use the official helpline") without naming any party | Encouraging participation framed around any party, leader or symbol |
| Responding to a disaster or emergency during an election period under the emergency exception (A-03 §E.9) | Using emergency visibility for organisational promotion during an election period |
| Refusing a political request, politely, in writing, and logging it | Refusing it informally and saying nothing (which allows the approach to be repeated and misreported) |

**[P] The one-line test for any borderline case:** *"Could this activity be reported accurately in a newspaper with the headline 'Sewak Sathi supports X'?"* If yes, it requires National Legal review before proceeding. If the honest headline would be *"Sewak Sathi asked the municipality to fix a drain"*, it is civic.

## 3.2 Part B — Individual member political activity (A-02)

### B.1 The starting premise

**[P]** Membership of Sewak Sathi Sanstha does not diminish any person's rights as a citizen. Members may hold any lawful political belief, join any lawful party, campaign, stand for election, and vote as they choose. **The organisation does not monitor, record, ask about, or act upon members' personal political beliefs** (prohibition N8).

**[V]** The precise content and limits of citizens' political rights and expression, and the extent to which any organisation may lawfully attach conditions to *roles* (as distinct from beliefs), are legal questions requiring validation — particularly while worker/member classification remains UNRESOLVED **[S: Ch.33]**.

**[A]** What the organisation legitimately regulates is not belief but **attribution, resources and conflict**. That is a narrower and more defensible basis, and it is sufficient.

### B.2 The graduated rule set

| Tier | Who | Personal political activity | Organisational constraints **[P]** |
|---|---|---|---|
| **T0** | Observer, Community Participant, Contributor, Volunteer, Specialist (spectrum Levels 0–4) | Unrestricted | None beyond the universal rules below. These tiers hold no organisational authority, so no conflict can arise |
| **T1** | Verified Member without a role (Level 5, no appointment) | Unrestricted | Universal rules only |
| **T2** | Role-holder: Coordinator, Supporting Member in a workstream, any Sub-Role | Unrestricted in private | Universal rules + must not use role or workstream for partisan purposes + should avoid publicly pairing their role title with partisan activity in a way that implies organisational alignment |
| **T3** | Primary role-holders: Team Leader, HR, Funds, Safety Lead, AI & Business, Editor, Social Media, Planner, Warehouse, Ground, Volunteer Manager | Unrestricted in private | T2 rules + **disclosure duty** + **recusal duty** + restriction on public partisan activity that identifies them as an organisational leader in the same locality |
| **T4** | Public-facing and gatekeeping roles: any Communications/Social Media/Editor role at any level; any HR & Verification role at any level; any Safety/Protection role at any level; Team Leader at City level or above | Unrestricted belief and vote | T3 rules + **role suspension** on accepting party office, a candidacy, or a formal campaign role, for the duration (see B.4) |
| **T5** | National Team, National department heads, proposed Council members, CEO | Unrestricted belief and vote | T4 rules + published declaration of any party office, candidacy or formal political role; Council members additionally subject to the reserved-matters conflict rules in A-13/A-14 |

### B.3 Universal rules (apply to every tier, including T0)

**[P]**
1. No member may use any organisational asset — name, mark, dress, record, list, channel, event, premises, vehicle, money, data — for a partisan purpose (N2, N7).
2. No member may state or imply that the organisation supports, opposes, or has a view on any party, candidate or movement (N9).
3. No member may recruit, mobilise, or pressure other members on a partisan basis, inside or outside organisational channels.
4. No member may present organisational service activity as a political achievement, or a political achievement as organisational service activity.
5. Where a member's personal political activity is likely to be attributed to the organisation in their locality (e.g. they are visibly a candidate in the same ward where they lead a team), they must declare it so that the organisation can protect *them* and itself — see B.4.
6. Breach of rules 1–4 by a role-holder is treated under **[S: SOP-17]** (ordinary violation) on first occurrence and **[S: SOP-18]** (serious misconduct) where organisational resources, data or a vulnerable person were involved, or on repetition — consistent with **[S: Const. Art.8]**.

### B.4 Disclosure, recusal and suspension

**[P] Disclosure.** A T3–T5 role-holder must declare to their reporting line and to HR (recorded, restricted-access): acceptance of party office; a candidacy or nomination; a formal role in a campaign; a family relationship with a candidate in their operating area; any paid engagement with a political actor. Declaration is **not** an inquiry into belief; it is a record of a *position that could create conflict*. Declarations are held under the restricted classification in A-17 and are never used for screening (N8).

**[P] Recusal.** A role-holder with a declared interest must not participate in: allocations of resources, materials, venues, volunteers or service activity affecting the relevant area or person; partnership or donation decisions involving a connected actor; recruitment, verification, promotion, discipline or vacancy decisions affecting a connected person; publication decisions with political adjacency. Recusal is recorded with reason, consistent with the conflict-of-interest risk control already in **[S: Ch.28]** ("disclosure, recusal; review/void decision").

**[P] Suspension of role (not of membership).** For T4 and T5 only: accepting party office, candidacy, or a formal campaign role suspends the *organisational role* for its duration, with an automatic end date and a defined handover, using the delegation machinery already present in **[S: Ch.10]** (delegation scope, permissions, start/end date, reviewer recorded) and the vacancy statuses in **[S: Ch.11]** (`Temporarily inactive`). Membership, service record and earned recognition are unaffected. The person may return to the role at the end of the political engagement following the standard review.

**[A]** This design is deliberately narrow. It removes the *conflict*, not the *citizen*. It uses instruments the architecture already has (delegation, vacancy status, recusal, conflict disclosure), so it adds no new machinery — only a new trigger.

**[V]** Whether role suspension in these circumstances is lawful and correctly characterised depends on the member's classification (employee / contract labour / volunteer / business participant) — itself **UNRESOLVED** **[S: Ch.33]**. Counsel must review before adoption.

### B.5 What must never happen (anti-abuse guards)

**[P]** Because a neutrality code concentrates interpretive power in whoever enforces it, four guards are attached:
1. **No belief screening, ever.** No question about political belief may appear in any application, interview, verification, training, promotion, discipline or exit process (N8).
2. **Written reasons.** Any finding under this code must be recorded with the specific rule breached and the evidence, reviewable under **[S: Ch.27]** and appealable under **[S: Const. Art.17]**.
3. **Symmetry.** The code applies identically to all parties and movements. An enforcement pattern that falls unevenly across political lines is itself an audit finding.
4. **Independent review.** Findings under this code against a City-level or above role-holder are reviewed by Audit & Ethics with the proposed Council informed, not by the line alone — extending **[S: Ch.5, Ch.27]**.

## 3.3 Part C — Election-Period Operating Protocol (A-03)

**[P] Definition of the period.** The "election period" runs from a defined pre-notification point before polling in the relevant jurisdiction until results are declared. **[V]** The exact legal window, and whether any code of conduct or notification obligation applies to the organisation, must be confirmed by counsel for each jurisdiction; until then, the organisation adopts a **conservative internal window** as organisational policy (not as a legal claim).

| Ref | Domain | Rule during the election period **[P]** | Reasoning |
|---|---|---|---|
| **E1** | Organisational events | No mass gatherings, rallies, camps, distribution events, foundation ceremonies or public felicitation functions. Small, routine, non-public team working meetings continue normally | Mass events near elections are the highest-risk adjacency; routine work is not |
| **E2** | Service activities | Continuing service projects proceed where already committed and non-public. **New** mass-distribution activity is deferred unless authorised under the emergency exception (E9). Individual household-level help continues uninterrupted | Deferring *distribution* protects legitimacy; deferring *help* would punish the people served — which the mission forbids **[S: Ch.2]** |
| **E3** | Communications | No new public campaigns. Routine factual reporting continues. No content mentioning any party, candidate, symbol, slogan, alliance or result — including congratulatory or critical content | See N5 |
| **E4** | Social media | Team and role accounts: no political content, no sharing, no liking, no commenting on political matters, no reposting of political material. Personal accounts of T4/T5 role-holders should not pair their organisational title with partisan content | Attribution risk is highest on channels the organisation controls |
| **E5** | Uniforms / badges / identification | No visible organisational dress, insignia, flags, banners, stalls or vehicle marking at any public or crowded place, except where required for safety identification at a genuine emergency under E9 | Interlocks with A-06; removes the visual adjacency that produces misclassification |
| **E6** | Public statements | Only authorised spokespersons **[S: Ch.24]** may speak; any election-adjacent query is answered with the standing non-alignment statement (A-01 §A.5) and logged | Prevents improvised local answers becoming organisational positions |
| **E7** | Candidate contact | No candidate, agent or party representative may be hosted, addressed, accompanied, photographed with, or given any organisational platform, at any level. Requests are handled under A-04 | The single most common real-world approach |
| **E8** | Political requests for support | Every request — for crowds, materials, venues, volunteers, data, publicity, endorsements, "blessings", or presence — is refused in writing using the approved refusal script, logged, and reported upward | A logged refusal is the organisation's evidence of neutrality; an informal refusal leaves no trace and invites repetition |
| **E9** | **Emergency exception** | Genuine emergencies (disaster, fire, flood, accident, epidemic, immediate risk to life) are responded to under the normal protection and service doctrine **[S: Ch.15, Ch.16]**. Where an emergency response requires public visibility, mass distribution, or organisational identification during the election period, it proceeds with **dual authorisation** (National Safety or National Operations **and** National Legal) and is **published with its reasons** within a defined short period | Prevents the protocol from becoming a rule that stops help. See §25 C-02 |
| **E10** | Use of organisational resources | Absolute: no resource of any kind for any partisan purpose, in any period — heightened scrutiny during elections | N2 |
| **E11** | Use of organisational data | Absolute prohibition, heightened audit sampling of access logs during the election period | N7; interlocks with A-17/A-20 |
| **E12** | Member representation | No member may be presented, or present themselves, as speaking for the organisation on any electoral matter. Members' personal activity continues under B.2 | Protects members from being used as proxies |
| **E13** | Donations and materials | No acceptance of money, materials, transport, media or volunteers from any political actor during the period; anything offered is refused and logged | N6 |
| **E14** | Post-period review | Within a defined short period after results, Audit & Ethics reviews the refusal log, event calendar, communications and access logs for the period, and publishes a summary (counts and categories, no personal political data) | Makes the protocol verifiable rather than declaratory |

**[P] Standing non-alignment statement (draft for approval, all operating languages):**
> *"Sewak Sathi Sanstha is not aligned with any political party, candidate, movement or ideology. We do not endorse, oppose, campaign, mobilise or accept political support. We work with whichever authority is lawfully responsible for a local problem, and we serve every resident of a locality without distinction. If anyone claims our support, that claim is false, and we will say so publicly."*

## 3.4 Part D — Political Approach Response Workflow (A-04)

**[P]** Exactly as required, with owners and records. The purpose is that **no local team ever has to improvise an answer to a powerful person.**

```
1. POLITICAL ACTOR APPROACHES TEAM
   Any request from a party, candidate, agent, movement, or person acting
   politically — for crowds, materials, venues, volunteers, data, publicity,
   presence, endorsement, photographs, or "support".
        ↓
2. TEAM DOES NOT MAKE AN AD-HOC COMMITMENT
   Local rule: receive politely, commit to nothing, promise no answer on the spot.
   Approved holding line: "We are not a political organisation. I must put this
   to our legal/compliance team, and we will answer you in writing."
        ↓
3. ESCALATE THROUGH DEFINED CHANNEL
   Recorded the same day → City Team Leader → National Legal & Compliance
   (with National Communications copied where publicity is involved).
   During an election period, escalation is immediate and bypasses the State
   filter if the State level is itself the source of the approach.
        ↓
4. CHECK AGAINST POLITICAL-NEUTRALITY POLICY
   National Legal tests the request against N1–N9, the civic/partisan boundary
   (A.4), the election protocol (A-03), and any counsel-validated legal duty [V].
        ↓
5. AUTHORISED HUMAN DECISION
   Only National Legal & Compliance (with CEO for exceptional cases) may decide.
   No local, city or state leader may approve any political-adjacent request.
   Decision is a named human decision with written reasons — consistent with the
   organisation's own doctrine that humans decide, not systems [S: Ch.21].
        ↓
6. DOCUMENT
   Refusal log entry: date, requester, capacity, request, channel, who received it,
   decision, decision-maker, reasons, wording of the written reply, date sent.
   Retained under the audit domain [S: Ch.27] and the classification in A-17.
        ↓
7. AUDIT
   Audit & Ethics samples the refusal log periodically and always after an
   election period (E14); tests for unlogged approaches, inconsistent decisions,
   and any resource movement without a matching approval.
```

**Supporting instruments [P]:**
- **Approved refusal script** (polite, short, non-argumentative, in every operating language) so a 22-year-old Team Leader can decline a senior politician without either rudeness or capitulation.
- **Written-reply template** on organisational letterhead, signed at National level, so the refusal is institutional rather than personal — protecting the local member from local consequences.
- **Approach register** with a published annual count ("we received N political approaches and declined N"). Publishing refusals is more credible than declaring neutrality.
- **Support duty:** where a member faces pressure or consequence for a logged refusal, the organisation provides backing through National Legal, and any retaliation against them is treated as serious misconduct **[S: SOP-18]**.

**[S] Compatibility:** this workflow extends the existing escalation architecture **[S: Ch.7 lane 6; Ch.5 Legal & Compliance; Ch.28 conflict-of-interest response]** and the existing approval-and-delegation principle that risk, money, data sensitivity, safety and public impact determine approval level **[S: App. E]**. It does not create a parallel chain of command.

---

# 4. RELIGIOUS / COMMUNITY NEUTRALITY (A-05)

**Proposed placement:** Constitution Article 21, plus a short Chapter 2A beside Mission and Principles.
**Status:** `PROPOSED — REQUIRES FINAL APPROVAL`.

## 4.1 Does the organisation need an explicit neutrality principle? — the analysis

**[S]** v1.2 already states: service "is not restricted by caste, religion, gender, economic status, politics, personal identity or popularity, subject to lawful eligibility and safeguards" **[Ch.2]**; social-impact funds may not support "political or religious activity" **[Ch.20]**; risk includes "reputational/safeguarding failure" and "conflict of interest" **[Ch.28]**.

**[A]** That covers **non-discrimination in service delivery**, which is the *output* side. It does not cover the *identity* side: whether the organisation itself may be associated with a faith, caste, ethnicity, language, region or social group — through its composition, its calendar, its venues, its partners, its symbols, its leadership, or its public language.

**[I]** In India this gap is not theoretical. Local teams will inevitably reflect local demographics; service will inevitably be scheduled around local festivals; partnerships will inevitably include faith-based service bodies that already run kitchens, clinics and schools; and observers will inevitably read pattern as preference. A team that is 90% one community, or that only ever works near one place of worship, will be classified as that community's organisation **even if every individual decision was neutral.**

**[P] Conclusion: yes — an explicit principle is required.** Not because the current text is wrong, but because *pattern-level* neutrality cannot be inferred from *act-level* non-discrimination. The principle below is additive and changes nothing in Ch.2.

## 4.2 The Equal Treatment & Non-Alignment Principle (draft)

**[P]**
1. **Service without distinction.** Help is determined by verified need, urgency, vulnerability and feasibility **[S: Ch.8, Ch.15]** — never by religion, caste, ethnicity, language, region, gender, age, disability, economic status, political affiliation, social standing, or whether the person is a member.
2. **Institutional non-alignment.** The organisation is not affiliated with, an instrument of, or identified with any religion, caste, ethnicity, linguistic group, region or social group. It has no theological, caste, ethnic or regional position and expresses none.
3. **Cultural respect without alignment.** The organisation respects and works within local culture, language, calendar, food practice, dress norm and social custom — as matters of *practical effectiveness and courtesy*, not as endorsement of any belief system. Respecting a locality's festival calendar is not adopting its faith.
4. **Composition is monitored, never engineered.** Team, leadership and specialist composition is recorded and reviewed for *exclusion patterns* (is any group systematically absent, or systematically doing only the low-status work?). It is never used to select, exclude, or quota any individual. Composition data is aggregate and restricted (A-17); individual belief, faith and caste are **not collected at all** (A-18).
5. **Faith-based partners are activity-scoped.** Cooperation with any faith-based body is permitted for a defined humanitarian activity (a kitchen, a shelter, a distribution, a medical camp) under the partnership flow **[S: Ch.29]**, with: separate branding, no religious content in the joint activity, no religious condition on receipt of help, no proselytisation in either direction, and a written scope. Cooperation is never with a faith body *as a faith body* on matters of belief, and never exclusive where alternatives exist.
6. **No religious or caste framing in organisational expression.** Not in communications, training, ceremonies, recognition, recruitment, or public statements — including favourable framing. Members' personal faith is their own and is neither recorded nor referenced.
7. **Symbols, names and dress carry no communal identification.** Interlocks with A-06.
8. **Language is not identity-ranking.** Every operating language is equal in status for member-facing purposes (see stress-test §13 **[P]**; language architecture is outside this pack's scope but the principle is recorded here because linguistic exclusion is a form of the discrimination Article 2 forbids).

## 4.3 What this principle must NOT become

**[P]** Four explicit guards, because neutrality instruments drift toward erasure:
- **Not cultural erasure.** Local expression — language, food, timing, venue, forms of courtesy, local recognition rituals — is *required* for the organisation to belong anywhere (stress-test §12). Neutrality governs *alignment and treatment*, not *culture*.
- **Not a ban on faith-motivated people.** A person may join because their faith commands service. That is a legitimate motivation (stress-test §6.2 item 13: accepted individually, never invoked institutionally). The organisation simply never speaks in that register itself.
- **Not a composition quota.** Guard 4 above forbids both exclusion *and* engineering. Composition is a diagnostic about the organisation, never a criterion about a person.
- **Not silence in the face of communal harm.** Where a community is being harmed, the organisation's response is the *protection and service* doctrine already in v1.2 — protect, de-escalate, contact authorities, help the vulnerable, document, review **[S: Ch.16]** — applied without distinction. Neutrality between *parties to a conflict* is not neutrality about *harm*.

**[V]** Any statement about the legal treatment of religious or caste matters — including whether certain activities attract regulation, or whether particular data may lawfully be collected — requires professional validation. This pack takes no position and collects no such data (A-18).

---

# 5. PROTECTION VISIBILITY & PUBLIC CONDUCT PROTOCOL (A-06)

**Proposed placement:** new Chapter 16A, immediately after Protection / First Response Architecture.
**Status:** `PROPOSED — REQUIRES FINAL APPROVAL`; several items **[V]**.
**Governing objective:** make it *visually obvious*, to a stranger, in under ten seconds, that this is not a private security force and not a vigilante organisation.

**[S]** The doctrine this protocol protects is unchanged: protect → de-escalate → contact authorities → first aid if trained → physical intervention only when reasonably necessary to protect someone from immediate harm and within applicable law → document → review; and the six DO-NOTs **[Ch.16]**.

## 5.1 Identification and dress

| Ref | Rule **[P]** | Reasoning |
|---|---|---|
| **V1** | **No uniform.** No shirt, jacket, cap, armband, sash, belt, boot, vest or any garment issued or encouraged by the organisation that identifies members as a body in public | Uniforms are the primary visual signal of a security or enforcement organisation; removing the signal removes most of the misclassification risk |
| **V2** | **No uniform-like garments.** No khaki/olive/high-visibility-combination styling, no epaulettes, no rank-like markings, no tactical or paramilitary cut, no garments resembling police, military, or private-security dress | Adjacency is read as equivalence by observers and by cameras |
| **V3** | **No insignia of authority.** No badges, shields, stars, stripes, crests worn on the body, no lanyards suggesting official status, no ID displayed outward in public | The QR card concept is already constrained to "non-police visual design" **[S: Ch.33]**; V3 generalises that constraint to everything worn |
| **V4** | **Identification is carried, not worn.** Member identification is kept in a pocket or bag and shown only to a person who needs to verify a *role claim* (see A-20/QR rule and stress-test F-28), never displayed to the public, never worn, never used to gain compliance | Converts an identity instrument from a credential into a record |
| **V5** | **Activity identification is task-scoped and removable.** For a specific authorised activity where visibility aids safety (e.g. a sanitation drive near a road, a flood-relief counter), a plain high-visibility vest or a table banner may be used, bearing only the organisation's name and the activity, and is removed at the end of the task. It confers no authority and may not be worn while travelling to or from the activity | Balances legitimate operational need against the visual-authority problem |
| **V6** | **No weapons, weapon-like objects, or protective equipment suggesting force.** No lathi, baton, chain, pepper spray, knife, firearm, tactical torch, shield, helmet-with-visor, or body armour in organisational capacity. This restates and generalises **[S: Ch.16 DO-NOT: Weapons; Ch.9 Safety boundary]** | The rule already exists; V6 makes it *visible* and enumerates the objects that would otherwise be rationalised as "not weapons" |
| **V7** | **Personal protective equipment is task-specific and plainly functional** — gloves for cleaning, masks for sanitation, life jackets for water rescue, helmets for two-wheeler travel — and is never styled, branded or worn as identity | Prevents safety equipment from drifting into uniform |

## 5.2 Symbols, marks and public representation

**[P]**
- **V8** The organisational mark may appear on documents, banners at authorised service activities, digital channels and task-scoped identification (V5). It may **not** appear on worn garments, vehicles used for crowd-facing activity, or any object suggesting rank or authority.
- **V9** No mark, colour combination, symbol, slogan, song, gesture or portrait may be adopted that identifies the organisation with a party, ideology, caste, community, region or movement (interlocks with A-01 N4 and A-05 §4.2 item 7).
- **V10** No organisational flag, banner or stall at any crowd event, procession, rally, religious congregation, political gathering, or site of communal, political or labour tension.
- **V11** The mark must never be used in a way that implies authority the organisation does not have — including alongside words such as "force", "squad", "patrol", "vigil", "command", "unit", "senā", "dal" in any language, or any term suggesting enforcement capacity. **[V]** Terminology review by counsel and by a linguistically competent communications reviewer in each operating language.

## 5.3 Group movement and public presence

**[P]**
- **V12** **No patrolling.** Members do not patrol, walk rounds, keep watch, maintain a "presence", monitor streets, or stand guard, in organisational capacity, at any time. Safety observation is *incidental to service activity*, never an activity in itself.
- **V13** **Maximum of two members respond to an incident.** Where an incident is reported or observed, no more than two members proceed, and they proceed to *help and to call authorities*, never to confront, control a scene, or detain. Additional members stay away and support through documentation and escalation.
- **V14** **No organised group movement in public.** Members do not move as a body through public space except for a pre-authorised, permissioned service activity (a clean-up, a plantation drive, a relief distribution) where the group's purpose is visibly service.
- **V15** **No convoys, motorcades, processions or vehicle columns** bearing organisational identification.
- **V16** **No occupation of public space** — no blocking a road, gating a lane, standing at an entrance, controlling access, checking people, or asking anyone to stop, wait, show anything, or explain themselves.
- **V17** **Members do not gather at a scene out of curiosity or solidarity.** Only the two assigned responders attend. A crowd of concerned members is itself a public-order problem and will be read as a mob.

## 5.4 Public behaviour

**[P]**
- **V18** **De-escalation is the default posture** in speech and body: distance, open hands, lowered volume, no pointing, no posturing, no surrounding, no sustained eye-contact challenge, no touching. This operationalises **[S: Ch.16 "De-escalate: reduce tension; avoid threats and group pressure"]**.
- **V19** **No shouted instructions, orders, commands or warnings to members of the public.** Members may request, inform, warn of a hazard, and call for help. They may not direct the public.
- **V20** **No assertion of authority.** Prohibited phrasings include any claim of power to permit, forbid, inspect, verify a citizen, clear an area, take charge, or act on behalf of the state. Restates **[S: Ch.16 DO-NOT: Police impersonation; Ch.9]**.
- **V21** **No confrontation with critics.** Where the organisation or a member is criticised, shouted at, or filmed aggressively, the response is withdrawal and reporting, never engagement. Extends **[S: Ch.16 DO-NOT: Intimidation]** and **[S: Ch.24 misinformation rule — correct calmly with verifiable facts]**.
- **V22** **No pursuit.** Members do not chase, follow, or pursue any person, for any reason, including a fleeing wrongdoer. The permitted actions are: protect those at risk, call authorities, describe accurately to authorities, preserve evidence safely, document.
- **V23** **Alcohol, substances and fatigue.** No member participates in any organisational activity while affected by alcohol or any intoxicating substance; Safety Leads may stand down any member whose condition or fatigue impairs judgement, using the fatigue-tracking responsibility already assigned to the Volunteer Manager **[S: Ch.9]**.

## 5.5 Filming, photography and social media

**[P]** This is the highest-consequence area, because perception is formed by footage, not by doctrine.

| Ref | Rule | Reasoning |
|---|---|---|
| **V24** | **Members do not film or photograph an incident, a confrontation, an injured person, a crime scene, a person in distress, or any police/authority interaction** — except where a designated documentation role has been assigned in advance for a *pre-authorised service activity*, and then only within that scope | Footage of an intervention is the mechanism by which a service organisation becomes, permanently, a "vigilante organisation" |
| **V25** | **A designated Documentation Officer** (already present as *Incident Documentation Officer* in the Safety sub-role family **[S: Ch.10]**) records facts **in writing**; photographic evidence of an *incident* is taken only where the Safety Lead determines it is necessary for the record, is privacy-protective, excludes identifiable victims and minors, and is stored under the sealed classification (A-20) | Aligns with **[S: App. F]** ("Safety incident — facts, category, actions, authorities, review; not acceptable: speculation, accusations without facts; highly restricted") |
| **V26** | **No publication of any incident material** — no incident photographs, video, names, locations, injuries, allegations, or authority interactions — on any organisational or personal channel. Incidents are internal records, reported to authorities and reviewed internally **[S: Ch.24 emergency/incident rule: "fast and factual; no speculation; sensitive statements require safety/legal/communications approval"]** | Publication converts an internal safety matter into a public identity event |
| **V27** | **Service photography** is permitted only with informed consent, never of minors without guardian consent (already required **[S: Ch.15, App. F, Scenario B]**), never of beneficiaries as proof of receipt, never in a way that shows distress, poverty or dependency as spectacle, and always with a right of withdrawal (A-19) | Interlocks with the Beneficiary Privacy & Dignity Code |
| **V28** | **If a member is filmed by a third party**, the member does not interfere with filming, does not demand deletion, does not mask or obstruct a camera, and does not leave the scene to avoid being recorded unless safety requires withdrawal. The member reports the filming in the incident record | Interference with a citizen recording is itself the viral event |
| **V29** | **Media present at a scene:** no member speaks. A single named contact is provided and the matter is escalated to authorised spokespersons **[S: Ch.24]** | Existing rule, made operational at scene level |
| **V30** | **Social-media conduct for role-holders** in Communications, Social Media and Editor roles is governed by **[S: Ch.9 boundaries]** and by A-01 N5; no member may post incident content, and no member may post content implying enforcement capacity | Existing boundaries, extended to the visibility problem |

## 5.6 Interaction with authorities

**[P]**
- **V31** **Authorities are contacted, not competed with.** The organisation's role begins where a citizen's role begins — call for help — and ends where an authority's role begins.
- **V32** **On arrival of police or emergency services, members step back, identify themselves by name if asked, state plainly what they observed and what they did, hand over any person or scene, and withdraw.** No member remains at a scene to "assist" unless specifically requested by an authority, and any such request is recorded.
- **V33** **Assistance to authorities.** Where a police officer or magistrate lawfully demands aid from the public, members respond as *citizens* under the applicable law, not as an organisational unit, and record what was asked and done. **[V]** The applicable provision and its limits require legal review — the stress test noted that Indian criminal procedure contains both a private-person arrest provision with a handover requirement and a general duty to assist police when lawfully demanded **[X]**. **No operational instruction is issued here; counsel must define the boundary before it is trained.**
- **V34** **No member obstructs, argues with, films, or directs an authority**, and no member uses organisational identity to obtain access, information, or favourable treatment from an authority.
- **V35** **A single authority-liaison contact per city** is published internally, so that police and municipal officials have one legitimate number to call rather than receiving calls from ten members. **[V]** Relationship protocols with local police and municipal bodies require legal review.

## 5.7 Emergency scenes, crowds, and vulnerable people

**[P]**
- **V36** **Emergency scenes:** members do not enter a scene that is unsafe, that is under authority control, or where their presence adds risk. Assistance is from a safe position: call, warn, guide, first aid where trained and where it can be given safely, comfort, water, shade, crowd-space creation by *request*, not by force.
- **V37** **Crowd situations:** members do not enter, address, calm, direct, divide, or stand within a crowd in organisational capacity. Crowd tension is a **do-not-attend** category (see A-09 §8.4). If already present, members withdraw.
- **V38** **Children:** the two-adult rule applies to every interaction; no member is alone with a minor; no physical contact beyond what is immediately necessary to prevent harm; no photograph; no personal details recorded beyond what safeguarding requires; guardian or authority contact as early as safety permits. **[V]** Certified child-safeguarding training is a precondition (stress-test §16.3).
- **V39** **Victims and witnesses:** treated with dignity and privacy; not questioned as an investigation; not asked to repeat a traumatic account more than is necessary for the record and for authorities; not photographed; not named in any organisational communication; offered referral to competent support rather than counsel from an unqualified member.
- **V40** **Vulnerable persons** (a person in crisis, intoxicated, mentally unwell, disabled, elderly, or a survivor of violence): no restraint, no isolation, no movement of the person unless immediate danger requires it, and always with the least restrictive action that a trained person would take, documented with reasons. **[V]** Requires review against applicable mental-healthcare and disability law.
- **V41** **No entry into private property** without permission, except where immediately necessary to prevent serious harm and lawful to do so **[V]**; entry is always recorded with reasons and reported the same day.

## 5.8 Incident documentation (visibility-specific)

**[P]** In addition to A-09's documentation requirements:
- **V42** Every incident record must state, as separate fields: whether any member wore organisational identification; whether any photograph or recording was made and by whom; whether any third party filmed; whether media were present; whether any authority was contacted and when; whether any physical intervention occurred and by whom; and whether any person withdrew from the scene.
- **V43** These fields exist because **visibility is now an auditable property**. Audit & Ethics **[S: Ch.5, Ch.27]** can test whether the protocol is being followed without interviewing anyone — from records alone.

---

# 6. PUBLIC PROTECTION STATEMENT (A-07)

**Proposed placement:** a public document, reproduced in every operating language, referenced from the member card, the local team page, the onboarding pack and the media kit. Approved through **[S: Ch.24]** communications rules.
**Status:** `PROPOSED — draft text requiring approval`; wording to be reviewed by counsel **[V]** and by a native-language reviewer in each operating language before publication.

## 6.1 Draft public statement

> ### What we do when someone is in danger
>
> Sewak Sathi Sanstha members are ordinary residents of the neighbourhood you live in. They are trained to help in the first minutes of a problem — the minutes before professional help arrives.
>
> **When something happens, a member is trained to:**
> 1. **Assess the risk** — is this a routine hazard, an escalating argument, a serious danger, or a life-threatening emergency?
> 2. **Protect people** — create safety and distance where that is reasonably possible.
> 3. **Calm the situation** — reduce tension; never add to it.
> 4. **Call the authorities** — police, ambulance, fire, or the responsible official. This is not optional. It is the first thing we are trained to do.
> 5. **Give first aid** — only if they are trained to, and only as far as their training allows.
> 6. **Intervene physically** — only when it is reasonably necessary to protect someone from immediate harm, and only within the law.
> 7. **Record what happened** — the facts, what was done, who was called.
> 8. **Withdraw and hand over** — when the authorities arrive, our members step back.
>
> Afterwards, every incident is reviewed internally, and corrective action is taken where something was done wrongly.
>
> ### What we are not
>
> **We are not a security agency.** We do not guard, patrol, watch, or protect property for anyone. We are not for hire.
>
> **We are not a police force.** We have no authority to stop, search, question, detain, arrest, fine, or punish anyone. We do not claim any official power. If anyone wearing our name claims such power, that person is acting against our rules — please report it to us and to the police.
>
> **We are not a vigilante group.** We do not take revenge. We do not form squads. We do not chase anyone. We do not use our numbers to intimidate anyone. We do not decide anyone's guilt.
>
> **We carry no weapons.** None. Not in any circumstance, in any role, at any level. A member carrying anything weapon-like in our name is immediately removed.
>
> **We are not a mob.** Our members do not gather at a scene. At most two members respond to any incident, and they go to help and to call for help — not to confront.
>
> **We are not a political organisation.** We do not support or oppose any party, candidate, movement or ideology. We work with whichever authority is lawfully responsible, whoever that is.
>
> **We do not film people in distress, and we do not publicise victims.** If we help you, your story is not ours to tell.
>
> ### What you can expect from us
>
> Help without discrimination. Honest records of what we did. A named person to complain to. And a clear answer when the honest answer is *"this is not something we can do — here is who can."*
>
> ### If you have a concern about our conduct
>
> Contact: [published local contact] · [published non-local contact] · [published integrity line]
> We log every complaint, we act on it, and we publish how many we received and how many were upheld — without naming the people involved.

## 6.2 Design notes on the statement **[A]**

1. **It states limits more loudly than capabilities.** That is deliberate: the misclassification risk is that the public over-reads the organisation's authority **[stress-test F-09, F-36]**. Under-claiming is the only safe posture, and it is also what makes the claimed part believable.
2. **It contains no exaggeration of authority** — no claim to protect, guard, secure, clear, control, respond officially, or represent anyone.
3. **It is consistent word-for-word with the doctrine in [S: Ch.16]** and the safety-role boundary in **[S: Ch.9]**. Nothing new is asserted; the existing rules are simply made public.
4. **It includes a reporting invitation**, which converts the statement from a defence into a trust instrument (see stress-test §14.2).
5. **It must be published *before* any protection activity is publicised** — see the Activation Gate, A-11.
6. **[V]** Counsel review required: the statement is a public representation and creates expectations. Any wording that could be read as a promise of response, a warranty of safety, or an assumption of duty must be reviewed, because such wording can create liability.
7. **Language rule:** published simultaneously in all operating languages, not translated after the fact (stress-test §13.3).

---

# 7. PROTECTION DO-NOT LIST (A-08)

**Proposed placement:** entrenchment of **[S: Ch.16]** within Constitution Article 9, plus a permanent visual panel reproduced in every team space, training pack, onboarding document and public page.
**Status:** the seven prohibitions below **restate the source verbatim in substance [S: Ch.16]** and add three items marked **[P]**. Entrenchment is `PROPOSED — REQUIRES FINAL APPROVAL`.

## 7.1 The permanent list

> ## SEWAK SATHI DOES NOT — AND NEVER WILL
>
> **1. RETALIATION FORCE.** No revenge. No "teaching a lesson". No response to a wrong that is designed to hurt rather than to stop harm.
> **2. PUNISHMENT SQUADS.** No group formed to confront, discipline, warn or punish any person. No independent punishment of anyone, for anything, ever.
> **3. MOB.** No crowd intimidation. No public shaming as punishment. No group coercion. No gathering of members at a scene out of anger, curiosity or solidarity.
> **4. VIGILANTE GROUP.** No taking the law into our own hands. No deciding guilt. No enforcing anything. No pursuit.
> **5. UNLAWFUL DETENTION FORCE.** No detaining, holding, blocking, cornering, searching, seizing property from, or forcing statements from any person.
> **6. POLICE IMPERSONATION GROUP.** No claiming police, government, municipal, medical, judicial or emergency authority. No wearing or carrying anything that suggests such authority. No demanding that any citizen identify themselves to us.
> **7. INTIMIDATION GROUP.** Our name, numbers, records, presence or reputation are never used to threaten, pressure, silence or frighten anyone — including critics, residents, officials, competitors or former members.
>
> **[P] 8. NO WEAPONS.** Nothing weapon-like, in any role, at any level, in any circumstance, including for "self-defence of the team". (Restates **[S: Ch.16, Ch.9]** in absolute terms.)
> **[P] 9. NO PATROLLING OR WATCHING.** We do not patrol, keep watch, monitor streets, or maintain a "presence". Observation is incidental to service, never an activity.
> **[P] 10. NO FILMING OR PUBLICISING VICTIMS.** We do not record people in distress for organisational purposes, and we do not publish incident material.

## 7.2 Why entrenchment, and what it means

**[S]** v1.2 already states these as DO-NOTs in Ch.16 and as role boundaries in Ch.9, and Constitution Article 9 already records: "Protection is defensive and de-escalatory. No weapons in organisational capacity. No retaliation, mob justice, intimidation, unlawful detention/search or police impersonation."

**[A]** So this amendment does not create the rules — it changes their **amendment status**. The purpose of entrenchment is that these ten lines must not be soften-able by a future leader under operational pressure ("just this once", "the situation required it", "only for night work").

**[P] Entrenchment mechanism (proposed):**
1. The list is recorded in the Constitution (Art. 9 as expanded) as a **Tier-1 Immutable Principle** under the Mission Lock (A-13), meaning it may not be amended, suspended, narrowed, reinterpreted or granted exception by any level of the organisation.
2. **No local, city, state or national leader may reinterpret, qualify, or grant an exception.** The words "do not allow local teams to reinterpret these rules" are implemented by removing interpretation authority entirely: the list is reproduced verbatim, in all operating languages, and any question about its application in a specific situation is escalated to National Safety and National Legal **before** action, not after.
3. **The only permitted "exception" is the one already in the source**: lawful, reasonably necessary physical intervention to protect a person from immediate harm **[S: Ch.16]** — which is *not* an exception to any of the ten items, because none of them describes protective intervention. This distinction must be trained explicitly, because it is the point at which well-intentioned members confuse the two.
4. Breach is **serious misconduct** under **[S: SOP-18]** with immediate safety action and suspension where needed — not an ordinary violation under SOP-17, regardless of whether harm resulted.
5. The list is displayed physically in every team space and digitally in every member channel, and is recited in every safeguarding and safety training session.

**[V]** Legal enforceability of constitutional entrenchment depends on entity form and governing documents — see A-13 §12.4.

---

# 8. PROTECTION INCIDENT PROTOCOL (A-09)

**Proposed placement:** new Chapter 16B, revising and extending **[S: SOP-13]** (which currently reads: *trigger — incident or threat occurs; minimum steps — protect, de-escalate, authorities, first aid if trained, document, review; stop/escalate if — high/emergency category; owner — Safety Lead*).
**Status:** `PROPOSED — REQUIRES FINAL APPROVAL`. **This protocol contains no tactical instruction for the use of force and is not to be read as one.**

## 8.1 The eleven-step workflow

```
1. INCIDENT IDENTIFIED
   A member observes, is told, or receives a report of risk or harm.
   → Record the time and the source. Do not investigate the source's motive.

2. RISK ASSESSMENT  (Low / Medium / High / Emergency — as defined in [S: Ch.16])
   Ask four questions only: Is anyone in immediate danger? Are minors or
   vulnerable people involved? Are weapons involved? Is this a crowd, communal,
   political or authority-sensitive situation?
   → Category determines authority and escalation (§8.3, §8.4).

3. PROTECT PEOPLE
   Create safety and distance where reasonably possible: move people away from
   danger, close a door, stop a vehicle, keep a child away, warn others of a hazard.
   → Protection of persons only. Never protection of property by force.

4. DE-ESCALATE
   Reduce tension. Distance, calm voice, no threats, no group pressure, no
   audience, no pursuit of the argument. Follow A-06 §5.4 (V18–V22).
   → If de-escalation is not working, withdraw. Withdrawal is a success, not a failure.

5. CONTACT APPROPRIATE AUTHORITIES
   Police / ambulance / fire / women-helpline / child-line / municipal / the
   lawful responsible authority. Any member may do this at any category [S: Ch.16].
   → Record: who was called, when, by whom, what was said, what response was given.

6. FIRST AID IF TRAINED
   Only within training and circumstances [S: Ch.16]. Only by a member holding
   current certification where certification is required [S: Ch.12 caveat].
   → Record: what was done, by whom, certification reference, condition before/after.
   → Never diagnose, never advise treatment beyond training, never administer
     anything to anyone.

7. NECESSARY INTERVENTION ONLY
   Only when reasonably necessary to protect someone from immediate harm, and only
   within applicable law [S: Ch.16]. The minimum action that stops the harm, for the
   shortest time, followed immediately by steps 5 and 8.
   → This step is never an authority to restrain, search, detain, question, recover
     property, or pursue (A-08 items 4–6).
   → [V] The legal boundary of this step must be defined by counsel BEFORE it is
     trained. Until counsel has defined it, training covers only steps 1–6 and 8–11.

8. SAFE EXIT / HANDOVER
   On arrival of authorities: step back, give name if asked, state plainly what was
   observed and what was done, hand over the person or the scene, provide the record,
   and withdraw (A-06 §5.6). Where no authority attends, withdraw to a safe position
   and escalate to the next level.
   → Record: handover time, to whom, what was handed over.

9. DOCUMENTATION
   Written incident record the same day (see §8.5). Facts only: what was observed,
   what was done, who was contacted, who was present, what was the outcome.
   No speculation, no accusation, no conclusion about anyone's guilt [S: App. F].
   No photography except under A-06 §5.5. Stored under the sealed classification (A-20).

10. INTERNAL REVIEW
    Post-incident review by Safety Lead + Team Leader, and by City/State/National
    Safety as category requires [S: Ch.16]. Review questions: Was the category right?
    Was the response within doctrine? Was escalation timely? Was documentation
    complete? Was any member or any other person harmed? Was any rule of A-06 or
    A-08 breached? Did the organisation's presence make things better or worse?

11. CORRECTIVE ACTION IF REQUIRED
    Training, process change, supervision change, member support, suspension, or
    serious-misconduct procedure [S: SOP-18]. Recorded, tracked to closure, and
    fed into the institutional lessons register (A-15).
```

## 8.2 Who may authorise what — the incident authority matrix

**[S]** v1.2 already assigns decision-makers by risk category **[Ch.16]** and gives Safety Leads stop-work and escalation authority within policy **[Ch.4, Ch.5]**, and App. E provides that in high-risk/emergency support the Safety Lead may act immediately with City/State/National Safety escalation. **[P]** The matrix below makes that operational without changing it.

| Category **[S: Ch.16]** | Ordinary member / Volunteer (Levels 0–4) | Verified Member without safety role | Trained member (certified first aid / safety training) | Safety Lead / Sub-Safety | City–State–National Safety |
|---|---|---|---|---|---|
| **Low** | May report; may help as any citizen would; must record if in organisational activity | Steps 1, 3, 4, 5, 9 | Steps 1–6, 8–9 | Authorises response; conducts review (step 10) | Informed by exception report |
| **Medium** | Report and withdraw | Steps 1, 3, 4, 5, 9 (no step 6 unless certified, no step 7) | Steps 1–6, 8–9 | Authorises; contacts guardian/authority/partner as required **[S: Ch.16]**; reviews | Informed same day |
| **High** | Report and withdraw | Steps 1, 3, 5, 9 only — **no de-escalation engagement, no intervention** | Steps 1, 3, 5, 6 if certified, 9 — **no step 7 without Safety Lead present** | **Mandatory escalation** to higher safety **and** authorities **[S: Ch.16]**; preserves evidence safely; does not investigate or punish | Authorises; may direct stand-down |
| **Emergency** | **Any member may call emergency authorities** **[S: Ch.16]** | Steps 3, 5, 9 | Steps 3, 5, 6 if certified, 9 | Coordinates **[S: Ch.16]**; authorises step 7 where reasonably necessary and lawful | Authorises; directs; reviews |

**[P] Three absolute limits cutting across every cell:**
1. **No person below Coordinator level, and no member without current safety training, may perform step 7** (physical intervention) except in an Emergency to protect life, in which case the action is judged afterwards against **[S: Ch.16]** and applicable law **[V]** — not pre-authorised by this table.
2. **No one at any level may authorise any item on the A-08 DO-NOT list.** No authority exists to do so.
3. **A Safety Lead may always order a stand-down or a withdrawal**, and no other role may override that order except a higher Safety authority or National Legal on legal grounds. This extends the stop-work authority already in **[S: Ch.4, Ch.5]**.

## 8.3 Mandatory escalation triggers

**[P]** Escalation to City Safety (and onward as category requires) **and** contact with the appropriate authority is mandatory — not discretionary — whenever any of the following is present. Local teams may not handle these at team level.

| Trigger | Why mandatory **[A]** |
|---|---|
| A minor is involved in any way — as victim, witness, subject of allegation, or participant | Safeguarding; legal reporting duties **[V]**; highest reputational consequence |
| A vulnerable adult is involved (disability, mental-health crisis, extreme old age, unconsciousness) | Capacity to consent uncertain; legal framework **[V]** |
| Any allegation or indication of sexual offence, domestic violence, abuse, trafficking, or exploitation | Legal reporting duties and survivor-protection duties **[V]**; not investigable by volunteers |
| Any weapon present, or any reference to a weapon | Immediate danger; authority matter |
| Any serious injury, death, or loss of consciousness | Emergency; medico-legal consequences **[V]** |
| Any use of physical force by a member (step 7) | Must be reviewed at City level or above, always — no self-review |
| Any communal, caste, religious, political or labour tension, or any crowd | Do-not-attend category (§8.4); misclassification risk (F-08/F-09) |
| Any involvement of a public official, police personnel, elected representative, or political actor | Conflict and attribution risk; National Legal must be informed |
| Any member of the organisation is a party to the incident, on either side | Conflict of interest **[S: Ch.28]**; independent review required |
| Media present, or any third party filming | Perception risk; spokesperson rule **[S: Ch.24]** |
| Any complaint alleging organisational misconduct in the response | Integrity line (stress-test M10); cannot be handled by the accused chain |
| Any incident occurring during an election period | A-03 E9/E14 |
| Any incident where the organisation's presence arguably worsened the situation | Institutional learning; must reach National |

## 8.4 Do-not-attend categories

**[P]** In these situations the organisational response is **do not attend**: contact the appropriate authority, provide information, and support from a distance. Members who happen to be present act as citizens under the law, not as an organisational response.

1. Communal, religious, caste or ethnic tension of any kind.
2. Political processions, rallies, demonstrations, counter-demonstrations, election events.
3. Labour disputes, strikes, pickets, employer–worker confrontations.
4. Any situation where weapons are present or being used.
5. Any organised crowd, whatever its purpose.
6. Any situation where the member would be acting against, or in place of, an authority.
7. Any property dispute, land dispute, family dispute or inheritance dispute — these are referred, never mediated by force.
8. Any situation involving a person in a mental-health crisis where restraint is contemplated **[V]**.
9. Any request to "come and talk to someone" — i.e. any invitation to apply social pressure to an individual.

**[A]** This list is the operational implementation of the six DO-NOTs. It is deliberately long, because the failure mode it defends against is not malice — it is a well-intentioned member reasoning that *this particular* situation is different.

## 8.5 Documentation requirements

**[S]** v1.2 already requires incident records with "facts, category, actions, authorities, review" and marks speculation/accusation as unacceptable evidence **[App. F]**, with SOP-13 requiring documentation. **[P]** Minimum fields, extending App. F and the record-keeping requirement in **[S: Ch.39.2 incident record minimum fields]**:

**Core:** incident reference · date/time reported and time of incident · location (general area sufficient where precision endangers anyone) · category (Low/Medium/High/Emergency) · source of information · who attended (max two, per V13) · what was observed (facts) · actions taken and by whom · authorities contacted (which, when, by whom, response) · first aid given (what, by whom, certification reference) · whether step 7 occurred and why it was reasonably necessary · handover (to whom, when) · outcome · persons affected (pseudonymised per A-20, never named in the operational copy) · members present and their training status · reviewer and review date · corrective action and closure.

**Visibility fields (from A-06 §5.8 V42):** organisational identification worn? · any photograph/recording made by us, by whom, stored where? · any third-party filming? · media present? · any person withdrawn from the scene?

**Timing [P]:** record opened the same day; completed within a defined short period; reviewed within a defined period for High/Emergency and at the next scheduled review for Low/Medium. **[A]** Exact time limits should be set from pilot evidence, not invented here — the source deliberately avoids inventing thresholds **[S: Ch.33]**.

**Classification:** stored under **SEALED** (A-17/A-20). Not visible to the general team membership. Not usable in reports, dashboards, publications or performance scoring except as an anonymised count and category.

## 8.6 Post-incident review

**[P]**
- **Who reviews:** Safety Lead + Team Leader for Low/Medium; City Safety (or an out-of-team reviewer) for High; State/National Safety for Emergency, for any incident involving a member's use of force, and for any incident in the mandatory-escalation list.
- **Independence rule:** no person reviews an incident in which they participated, and no leader reviews an incident involving their own relative or close associate — extends the conflict-of-interest control **[S: Ch.28]** to safety review.
- **Standard questions:** the eleven review questions in step 10 above.
- **Outputs:** corrective action with an owner and a due date; a training need; a process change; a lessons-register entry (A-15); and, where a rule was breached, referral to **[S: SOP-17]** or **[S: SOP-18]**.
- **Member support:** any member involved in a High or Emergency incident is offered a welfare check, is not blamed before review, and is supported (including legal support per A-10) where they acted within doctrine. This matters for retention of Safety Leads — the stress test found these roles are socially costly and unsupported **[F-03]**.
- **Publication:** incidents are published only as aggregate counts and categories in periodic reports, never individually, never with identifying detail (V26, A-19, A-20).

## 8.7 Explicit prohibition

**[P]** This protocol authorises no offensive action, no search, no detention, no pursuit, no property recovery, no questioning of any person about any offence, and no use of any object as a weapon. It contains no tactical instruction and must not be supplemented by any local training material that does. Any training content on the use of force beyond "protect, de-escalate, call, withdraw" requires National Safety **and** National Legal approval **[V]** — and the default answer should be no.

---

# 9. PROTECTION LIABILITY FRAMEWORK (A-10)

**Proposed placement:** new Chapter 16C, referenced from **[S: Ch.31 launch checklist — audit/risk/insurance]** and **[S: Ch.33 decision register — insurance]**.
**Status:** `PROPOSED — REQUIRES FINAL APPROVAL`. **Every coverage, liability and employment question in this chapter is `REQUIRES PROFESSIONAL VALIDATION`.**

**[A] Framing rule for this chapter:** this document **does not state what insurance the organisation has, needs, or can obtain.** It states what must be *established in writing, by a qualified professional, before protection activity is activated or publicised*. The distinction matters: an architecture that assumes cover exists will act as though it does.

## 9.1 The requirement-to-validate register

Each row is a **question that must be answered in writing by a qualified professional**, with the answer retained as a governance record under **[S: Ch.27]**.

| # | Requirement / question | Professional to answer | Why it is on the list **[A]** |
|---|---|---|---|
| **L1** | What insurance products are available and appropriate for a mass-membership voluntary organisation performing community service and emergency first response in India? What are their standard exclusions? | Insurance broker / adviser **[V]** | The organisation cannot design its protocol around cover it cannot obtain |
| **L2** | What personal accident or medical-expense cover can be provided for members acting in organisational capacity, at what cost per member, and what activities are excluded? | Broker **[V]** | A member injured while helping is the most morally urgent liability the organisation has |
| **L3** | What public/third-party liability cover is available for service activities, events, distributions, and emergency assistance — including injury to a person being helped and damage to property? | Broker **[V]** | Third-party claims arise from ordinary service, not only from protection activity |
| **L4** | Is any cover available at all for acts of "protection" or "first response"? If not, what is the consequence for the pillar's design? | Broker + counsel **[V]** | If this class of activity is uninsurable, the activity must be redesigned or not activated (A-11) |
| **L5** | What professional indemnity is required where members give advice (legal, tax, medical-adjacent, technical, engineering, safeguarding)? | Broker + counsel **[V]** | The Specialist tier (stress-test §9) will include professionals; their advice creates exposure |
| **L6** | What cover is required for officers, governors and the founder personally, given that the Council structure is not yet constituted **[S: Ch.33]**? | Broker + counsel **[V]** | Personal exposure deters capable people from governance roles |
| **L7** | What is the organisation's potential liability for a member's acts — vicarious, principal, or otherwise — and how does that change with member classification (volunteer / stipend / contract / employee)? | Counsel **[V]** | Classification is UNRESOLVED **[S: Ch.33]**, so liability is currently indeterminate |
| **L8** | What is the legal boundary of the intervention step (**[S: Ch.16 step 7]**)? What does applicable criminal procedure permit a private person to do, and what are the consequences of exceeding it? | Counsel **[V]** | Stress test noted private-person arrest provisions with a handover requirement, and a general duty to assist police when lawfully demanded **[X]** — the operational boundary must be defined by counsel, not by this document |
| **L9** | What protections, if any, apply to a layperson giving emergency first aid in good faith, and what conditions attach? | Counsel **[V]** | Determines what first-aid training may lawfully cover and what members may be told |
| **L10** | What mandatory reporting duties arise on learning of offences against children, women, or vulnerable persons — who must report, to whom, within what time? | Counsel + safeguarding professional **[V]** | The protocol in A-09 escalates these but does not state the legal duty |
| **L11** | What permissions, notifications or registrations are required for: food distribution, health camps, ambulance-like transport, disaster response, animal handling, use of public space, and collection of donations or materials? | Counsel + sector regulators **[V]** | **[S: Ch.15]** already names category controls; the permissions themselves are unspecified |
| **L12** | What must a member be told, in writing and in their language, about what is and is not covered, before they take a safety role? | Counsel + HR **[V]** | A member who believes they are covered and is not has been misled by the organisation |
| **L13** | What records must exist to support a claim, a defence, or a regulatory question — training certificates, authorisation records, incident reports, supervision records? | Counsel + broker **[V]** | Cover is only as good as the evidence that the organisation acted properly |
| **L14** | What is the incident-notification obligation to an insurer, and within what time? | Broker **[V]** | Late notification commonly voids cover |
| **L15** | Does any activity contemplated (e.g. transporting an injured person, administering anything, moving a person in crisis) create liability that protocol should simply prohibit? | Counsel **[V]** | The cheapest risk control is the activity not performed |

## 9.2 Coverage confirmation rule

**[P]**
1. **No written confirmation, no activation.** Protection activity may not be activated, trained for operationally, publicised, or represented to any external party until the relevant items in §9.1 are answered in writing and the answers are recorded as governance evidence.
2. **The Public Protection Statement (A-07) may not be published before the answers to L2, L3, L4, L8 and L12 exist.** Publishing a description of protective activity without cover converts an internal doctrine into a public representation.
3. **Every member taking a safety role receives a written cover statement** in their own language: what is covered, what is not, what they must do if something happens, and whom to call. Signed acknowledgement retained.
4. **Nothing in this framework may be represented to a member, partner, authority or the public as insurance cover** unless it is confirmed in writing by the insurer.

## 9.3 Legal support protocol

**[P]** The stress test found that no protocol exists for supporting a member who acted in good faith and faces legal consequence **[F-10]**. Abandoning such a member is the single most damaging possible internal event.

| Stage | Action | Owner | Time |
|---|---|---|---|
| **0. Immediate** | Member contacts the published safety/legal number. Organisation acknowledges, tells the member what to do and what not to do (do not sign anything, do not give a statement without advice where advice is available, preserve the record) | Safety Lead + National Legal | Same hour |
| **1. Triage** | National Legal determines: is this within doctrine? Is cover available? Is external counsel required? Is the organisation a party or a witness? | National Legal **[S: Ch.5]** | Same day |
| **2. Support decision** | Where the member acted within doctrine and in good faith: the organisation provides support as determined by counsel and by the approval matrix **[S: App. E]**, and says so to the member in writing | National Legal + CEO | Within a defined short period |
| **3. Where conduct is in question** | Support is provided for the person's basic rights while the matter is reviewed under **[S: SOP-18]**; support does not imply endorsement of conduct, and withdrawal of support is a decision of National Legal recorded with reasons | National Legal + Audit & Ethics | Per review |
| **4. Records** | Everything preserved: incident record, training certificates, authorisation records, supervision records, communications. Legal hold applied; retention suspended for the affected records (A-17) | AI & Data + Legal | Immediately |
| **5. Notification** | Insurer notified per L14; authorities as required; Council informed where the matter is serious or public | National Legal | Per obligations |
| **6. Communication** | Single authorised spokesperson **[S: Ch.24]**. No local comment. No member named publicly without legal advice and, where applicable, the person's consent | Communications + Legal | As required |
| **7. After** | Institutional review, lessons-register entry (A-15), protocol/training correction, member welfare check | Safety + HR | Within a defined period |

**[V]** The extent of the organisation's obligation or discretion to fund a member's legal defence, and the conditions on which it may do so, require counsel review and depend on entity form, classification and available cover. This protocol defines the *process*, not the *entitlement*.

## 9.4 Injury, damage and third-party claims procedure

**[P]**
1. **Any injury to any person** — member, beneficiary, bystander, or otherwise — connected to organisational activity is recorded as an incident under A-09 regardless of severity, and escalated to City level.
2. **Any property damage** connected to organisational activity is recorded, photographed only where required for a claim and privacy-permitting, and reported to the owner and to Finance.
3. **Any third-party claim, demand, notice, complaint or threat of legal action** is routed to National Legal the same day, acknowledged in writing, and never answered substantively by a local leader. Extends **[S: Ch.5 escalation — legal notices]**.
4. **No local settlement, payment or admission** by any team. Payment authority follows **[S: Ch.18]** and **[S: App. E]**; admissions are a legal matter.
5. **Claims register** maintained by National Legal with status, reviewed periodically by Audit & Ethics.
6. **Members are told the procedure before they take a role**, not after an incident.

## 9.5 Training and authorisation evidence standard

**[A]** Cover, defence and public credibility all depend on being able to prove that a person was trained and authorised. **[S: Ch.12]** already warns that internal training is not automatically legally sufficient; **[S: Ch.11]** requires training verification before appointment; **[S: Ch.23]** restricts assignment of untrained people to restricted tasks.

**[P]** For every safety-restricted role, the following must exist and be retrievable on demand:
- current certification reference and expiry, with the certifying body named where the domain is regulated **[V]**;
- the training curriculum version actually delivered (so that "trained" means something specific);
- the authorisation record — who authorised this person for which restricted tasks, with start and end dates, using the delegation machinery in **[S: Ch.10, Ch.11]**;
- the supervision arrangement — who is responsible for this person's conduct in the role;
- the incident history in which the person participated (accessible only under the sealed classification);
- an annual re-confirmation that the person remains authorised.

**Rule:** *no authorisation record, no restricted task.* This is already implied by **[S: Ch.23]** and is restated because it is the evidentiary foundation of everything else in this chapter.

---

# 10. PROTECTION ACTIVATION GATE (A-11)

**Proposed placement:** new Chapter 16D, cross-referenced from **[S: Ch.31 launch checklist]** and **[S: Ch.30 Phase 0/1 exit gates]**.
**Status:** `PROPOSED — REQUIRES FINAL APPROVAL`. **No numeric threshold is invented.** Where a threshold is unavoidable it is marked as a proposal requiring approval.

## 10.1 Why a gate is needed

**[A]** In v1.2, protection capability comes into existence *incidentally*: a team appoints a Safety / Protection Lead **[S: Ch.9, Ch.11]**, and the doctrine in **[S: Ch.16]** applies from that moment. There is no point at which anyone decides whether the organisation is *ready to be doing this in public*. The result is that the most externally dangerous capability activates as a side-effect of filling a vacancy.

**[P]** The gate inverts this. Protection activity is treated as a **capability that is switched on deliberately**, at three levels, by named people, against evidence — using the same pattern the architecture already applies to autonomy readiness **[S: Ch.13]** and to launch phases **[S: Ch.30]**.

## 10.2 The three gate levels

| Level | What is being activated | Who decides | Effect of passing |
|---|---|---|---|
| **G-N (National)** | The organisation may describe itself publicly as having a protection / first-response function at all; the Public Protection Statement may be published; training curricula may be issued | CEO + National Safety + National Legal, with the proposed Council informed **[S: Ch.4, Ch.5]** | Publication permitted; G-C may begin |
| **G-C (City)** | A city may run safety training, appoint Safety Leads, and respond to High-category incidents with city coordination | City Team Leader + City Safety + National Safety delegate | Teams in that city may apply for G-T |
| **G-T (Team)** | A specific Mohalla/City team may hold a filled Safety Lead role, respond to incidents in its area beyond Low category, and be listed as safety-capable | City Team Leader on National Safety criteria | The team is safety-active |

## 10.3 Prerequisite categories (the gate checklist)

**[P]** Twelve categories. Each requires a **named artefact**, a **named confirmer**, and a **recorded evidence reference**. A category is `PASS`, `PASS WITH CONDITION` (with a written condition and an expiry), or `FAIL`. **Any FAIL at G-N blocks everything below it.**

| # | Category | Required artefact | Confirmer | Evidence recorded |
|---|---|---|---|---|
| **1** | **Approved SOP** | A-09 protocol adopted, versioned, translated into all operating languages, and consistent with **[S: Ch.16, SOP-13]** | National Safety + National Legal | Version, language list, approval record |
| **2** | **Legal review of the intervention boundary** | Written counsel opinion on L8, L9, L10, L15 defining what step 7 may and may not include, and the mandatory reporting duties | National Legal **[V]** | Opinion reference, date, scope, restrictions adopted into training |
| **3** | **Insurance** | Written answers to L1–L7 and L14, and confirmation of cover in force (or a written decision, by the CEO, to proceed with a specified activity *without* cover and with the consequences recorded) | CEO + National Legal + Finance **[V]** | Policy references, exclusions, member cover statement template |
| **4** | **Training** | Curriculum version; certified training for the regulated domains **[S: Ch.12 caveat]**; trainer qualification; assessment method; refresher interval (**PROPOSED — REQUIRES FINAL APPROVAL**) | National HR + National Safety | Curriculum, certification register, trainer list |
| **5** | **Member eligibility** | Eligibility criteria for safety-restricted roles: age/legal, conduct clear, safeguarding training current, no relevant adverse record, suitability assessment (**criteria PROPOSED — thresholds require approval**) | National HR | Criteria document; per-person eligibility record **[S: Ch.11]** |
| **6** | **Authorisation records** | Every safety-active person has an authorisation record with scope, start/end date and supervisor, per A-10 §9.5 | City HR + National HR | Authorisation register |
| **7** | **Supervision** | A named supervisor for every safety-active person; maximum supervised-to-supervisor ratio (**PROPOSED — REQUIRES FINAL APPROVAL**); rules for absence | City Team Leader | Supervision map |
| **8** | **Incident reporting** | Incident record form (A-09 §8.5) in use; sealed storage configured (A-20); escalation contacts published; 24×7 or defined-hours contact route established | National Safety + AI & Data | Form version; storage configuration; contact directory |
| **9** | **Emergency communication** | Published internal emergency numbers; authority contact directory per locality (police, ambulance, fire, women's helpline, child line, hospital, municipal); tested within a defined period | City Team Leader + National Safety | Directory; test record |
| **10** | **Documentation & review mechanism** | Post-incident review process, independence rule, corrective-action tracking, lessons-register linkage (A-15) | National Safety + Audit & Ethics | Review procedure; first review records |
| **11** | **Safeguarding** | Certified child-protection and vulnerable-adult training; two-adult rule; image/consent absolutes; mandatory reporting protocol per L10 **[V]** | National HR + National Legal | Certifications; protocol; acknowledgement records |
| **12** | **Public representation** | Public Protection Statement (A-07) approved and published in all operating languages; DO-NOT list (A-08) published; visibility protocol (A-06) trained; public complaint route live; authenticity-verification route live | National Communications + National Legal | Publication references per language; complaint route details |

## 10.4 Gate rules

**[P]**
1. **Binary and evidence-based.** A gate is passed on recorded artefacts, not on assurance. This mirrors the autonomy-readiness gate pattern **[S: Ch.13]**.
2. **Scoped, not general.** A gate is passed for a *defined scope of activity* — e.g. "Low and Medium category response, first aid by certified members, within X city". Scope expansion requires a fresh gate. This prevents a single approval from silently authorising everything.
3. **Time-limited and renewable.** Each gate pass has a review date (**interval PROPOSED — REQUIRES FINAL APPROVAL**). Lapsed gate = capability suspended, not merely flagged.
4. **Revocable immediately.** National Safety may suspend any gate on a single serious incident, pending review — extending the stop-work authority already in **[S: Ch.4, Ch.5]**.
5. **Support-first on failure.** A team that fails a gate receives support and a defined improvement period under **[S: Ch.14]** before any consequence. Failing a gate is not misconduct.
6. **No retroactive activation.** Activity performed before a gate is passed is recorded as an exception, reviewed, and reported — not quietly normalised.
7. **Public honesty.** Until G-N is passed, the organisation does not describe itself as having a protection function in any public material. It may describe *emergency support and community safety awareness*, which is what it can actually stand behind.

## 10.5 What the gate does not do

**[A]** It does not prohibit a member from acting as a citizen. **[S: Ch.16]** already provides that at Emergency category "any member may call emergency authorities", and the risk matrix permits trained first aid within training. The gate governs **organisational activation, public representation, training and role authorisation** — not an individual's lawful conduct at an emergency they happen to witness. That distinction must be trained explicitly, because members will otherwise believe either that they may do nothing (bad) or that the gate authorises everything (worse).

---

# 11. FOUNDER CONCENTRATION ANALYSIS (A-12)

**Placement:** analytical annex to **[S: Ch.4]** — new Chapter 4A.
**Status:** `ANALYSIS ONLY`. **This chapter takes no decision, resolves nothing, and closes nothing.** Every UNRESOLVED item in **[S: Ch.33]** remains UNRESOLVED.

## 11.1 Current relationships, as stated in the source

| Relationship | What v1.2 says | Tag |
|---|---|---|
| Krytos → Sewak Sathi Sanstha | Krytos is the "parent/company context and ownership ecosystem"; Sewak Sathi Sanstha is the "proposed/public operating name for the Krytos-owned organisation; final legal/name validation required" | **[S: v1.2 p.1, Ch.1]** |
| Krytos → CEO | "KRYTOS / Founder-CEO — ownership and broad executive flexibility within final legal structure. CEO may work operationally" | **[S: Ch.4]** |
| CEO → organisation | Ownership: "Property, brand, strategy and ultimate founder-level control. Subject to law, contracts and approved governance" | **[S: Ch.4 authority table]** |
| Council → CEO | "PROPOSED / REQUIRES FINAL APPROVAL: standards, ethics, audit, dispute review and governance; **not owner above CEO unless legal charter says so**" | **[S: Ch.4]** |
| Council authority | UNRESOLVED — "CEO retains ownership/executive authority; Council provides delegated standards/audit/dispute oversight" | **[S: Ch.33]** |
| Legal structure | UNRESOLVED — "Review internal division, subsidiary, nonprofit/social arm or hybrid" | **[S: Ch.33]** |
| Public name | PROPOSED — "use as public operating name while preserving Krytos parent context"; legal/name validation required | **[S: Ch.33]** |
| National Team → CEO | National departments report to CEO / National Governance / National Team **[S: Ch.15 role catalogue]**; executive authority is "CEO and delegated executives" **[S: Ch.4]** | **[S]** |
| Reserves | "National Funds Manager manages; release requires approval matrix" | **[S: Ch.18]** |
| Social-impact fund | "Restricted mission fund; not slush fund or venture bailout"; approval tier by amount, risk, beneficiary and geography | **[S: Ch.18, Ch.20]** |
| Dissolution | "REQUIRES PROFESSIONAL VALIDATION: Dissolution, merger, restructuring, transfer of assets, reserve use and social-impact fund handling must follow legal structure, donor restrictions, contracts and statutory obligations" | **[S: Const. Art.19]** |
| Amendments | "PROPOSED POLICY: Constitutional amendments should be versioned, approved by CEO/governance process, communicated to members and legally reviewed where necessary" | **[S: Const. Art.18]** |
| Succession (teams) | Best Mohalla Team → City Head Team → State Head Team → National Team opportunity, with safeguards | **[S: Ch.26, Const. Art.15]** |
| Succession (apex) | **Not addressed anywhere in v1.2** | **[A]** |

## 11.2 Asset-by-asset concentration map

**[A]** For each asset, the question is: *if the founder were unavailable tomorrow, who could lawfully and practically control this, and is that person bound by the constitution?*

| Asset | Current control per source | Concentration | Continuity risk if founder unavailable | Status |
|---|---|---|---|---|
| **Legal entity / entity structure** | Depends on the UNRESOLVED legal structure **[S: Ch.33]**; ownership sits with Krytos **[S: Art.3]** | **Absolute** | The entity's control follows Krytos's own succession, which is outside this architecture entirely | **UNRESOLVED** |
| **Brand and name** | "Property, brand, strategy" held under ownership **[S: Ch.4]**; public name PROPOSED and unvalidated **[S: Ch.33]** | **Absolute** | Unclear who could authorise use, licence it, or defend it; teams using the name locally have no documented right to do so | **UNRESOLVED** |
| **Mission / constitution** | Amendable per Art.18 by "CEO/governance process"; no reserved matters; no supermajority; no lock | **Absolute in practice** | A successor could amend the mission using the ordinary process | **PROPOSED for change (A-13)** |
| **Organisational funds & bank mandates** | Finance department; National Funds Manager records and prepares; segregation of duties; release via approval matrix **[S: Ch.18, Ch.23]** | **Moderate** — operational control is distributed, but mandate authority follows the entity | Signatory vacancy can freeze payments, including worker compensation — the highest-priority obligation **[S: Ch.18]** | **PROPOSED for change (A-14)** |
| **Reserves** | National Funds Manager manages; release requires approval matrix **[S: Ch.18]** | Moderate | Same as funds, plus: no rule for who authorises release during an apex vacancy | **UNRESOLVED (A-14)** |
| **Social-impact fund** | Restricted ledger, approval tiers **[S: Ch.20]** | Moderate | Restricted purpose survives in policy but not in any instrument; a successor could redefine "restricted" | **PROPOSED for change (A-13)** |
| **Data estate** | Data fiduciary identity unstated; AI & Data department operates the platform; RBAC administered **[S: Ch.22, Ch.23]**; retention UNRESOLVED **[S: Ch.33]** | **High** — the legal data fiduciary is presumably the entity, i.e. ultimately Krytos | Breach notification duties, data-principal rights and regulator contact all require a named accountable person **[V: X]** | **UNRESOLVED (A-17)** |
| **Intellectual property** (this architecture, SOPs, curricula, software, brand assets) | Not addressed in v1.2 | **Absolute by default** | Whoever owns Krytos owns the operating system of the institution; a licensor could withdraw it | **UNRESOLVED — new item for the register (§22)** |
| **Technology platform & credentials** | AI & Data department; no escrow, dual custody or emergency-access procedure stated | High | Domain, code repository, cloud, payment gateway, communication channels and admin credentials could be locked to one person | **PROPOSED for change (A-14)** |
| **Contracts and partnerships** | Legal & Compliance **[S: Ch.5, Ch.29]** | Moderate | Counterparties may have change-of-control or key-person clauses; unknown until reviewed | **UNRESOLVED — requires contract review [V]** |
| **Leadership cadre** | Dynamic leadership and succession for teams **[S: Ch.26]**; role succession paths per role **[S: Ch.9, Ch.15]** | **Low** — this is well designed below the apex | Team and role continuity is genuinely addressed | **KEEP** |
| **Institutional memory** | Not addressed: no archive, no decision-rationale record, no lessons register | **Absolute** | Everything known but unwritten leaves with the person | **PROPOSED for change (A-15)** |

## 11.3 Exactly what remains unresolved (no resolution offered here)

**[P — for the decision register in §22, all carried as UNRESOLVED]**

1. **Legal structure** — internal division, subsidiary, nonprofit/social arm, hybrid, or two-entity separation **[S: Ch.33, unchanged]**.
2. **CEO vs National Council authority** — the precise reserved matters, veto scope, appointment power and dispute mechanism **[S: Ch.33, unchanged]**.
3. **Public name validation** — availability, registration, branding, tax/accounting treatment **[S: Ch.33, unchanged]**.
4. **Brand ownership and licensing** — who owns the mark, on what terms teams may use it, what happens on exit or dissolution. **New item.**
5. **IP ownership** — of this architecture, the SOPs, curricula, software, data models and brand assets; whether any of it is licensed to the operating organisation and on what terms; what happens if the licence ends. **New item.**
6. **Data fiduciary identity and accountable officer** — which legal entity is the fiduciary for each data category, and who is the named accountable individual **[V: X]**. **New item.**
7. **Custody of reserves and the social-impact fund** — in whose name, under what instrument, with what restrictions surviving a change of control. **New item.**
8. **Bank mandate and signatory continuity** — minimum signatories, what happens on death/incapacity of a signatory, and how worker compensation continues during a vacancy. **New item.**
9. **Apex succession mechanism** — A-14 proposes a mechanism; its adoption, and the identity of the first people in any sequence, remain decisions for the Founder/CEO and the governance process. **New item.**
10. **Apex dispute resolution** — how a CEO–Council deadlock is settled. **New item** (Art.17 covers member disputes only **[S]**).
11. **Key-person dependencies generally** — a register of individuals whose unavailability would halt a critical function, with a mitigation per name. **New item.**
12. **Whether mission-lock instruments are legally enforceable in the chosen entity form** **[V]**. **New item.**

**[A]** Items 1–3 are already in your register and are **not touched**. Items 4–12 are *newly identified* by this analysis and are added to the register in §22 as UNRESOLVED, with proposed owners and no proposed answers where an answer would pre-empt a decision.

## 11.4 The structural observation (analysis, not recommendation)

**[A]** The architecture distinguishes carefully between **ownership**, **executive**, **governance**, **management**, **operations**, **audit**, **safety** and **finance** authority **[S: Ch.4]** — and then places the first two, plus brand, strategy, mission amendment and (by default) IP and data, in the same pair of hands. That is a legitimate design for a founder-led organisation and v1.2 says so honestly.

**[I]** The institutional consequence is that **every long-duration promise the organisation makes rests on a continuity assumption it has not instrumented**: members are asked to commit years; partners are asked to sign MOUs; beneficiaries are asked to trust records about themselves; professionals are asked to volunteer expertise; authorities are asked to recognise the body. Each of those counterparties will, at some point, ask "what happens if Vasu is not there?" — and v1.2 has no answer to give them.

**[P]** The answer does not require reducing the founder's authority over *operations*. It requires separating **operational authority** (which should remain concentrated, fast and personal — that is a founder's legitimate advantage) from **constitutional authority** (which should be slow, shared, documented and hard to change). A-13 and A-14 do exactly that and nothing more.

---

# 12. MISSION LOCK FRAMEWORK (A-13)

**Proposed placement:** Constitution Article 22, plus an amendment procedure attached to **[S: Const. Art.18]**.
**Status:** `PROPOSED — REQUIRES FINAL APPROVAL`; enforceability **[V]**. **This amendment reduces founder flexibility by design — that trade-off is stated openly in §12.6 and is a decision, not an analysis.**

## 12.1 The two tiers

**[P]** Every principle, rule and policy in the architecture is assigned to one of two tiers.

### TIER 1 — FOUNDATIONAL PRINCIPLES (constitutionally entrenched)

Derived from the source, not invented. Each row cites where the principle already lives.

| # | Tier-1 principle | Source **[S]** |
|---|---|---|
| **T1.1** | **Service without discrimination** — help determined by verified need, never by caste, religion, gender, economic status, politics, personal identity or popularity | Ch.2 principle 1; Const. Art.1–2 |
| **T1.2** | **Lawful, defensive, non-vigilante protection** — the intervention sequence and the DO-NOT list, including no weapons, no retaliation, no mob justice, no unlawful detention or search, no impersonation of authority, no intimidation | Ch.16; Ch.9 safety boundary; Const. Art.9 |
| **T1.3** | **Human accountability over automated decision-making** — AI may recommend; humans decide; the ten prohibited autonomous decisions | Ch.21; Const. Art.12 |
| **T1.4** | **Worker compensation first in the financial priority order** — verified work protected ahead of deferrable organisational fees and social contributions, subject to law and final structure | Ch.18; Const. Art.10 |
| **T1.5** | **Financial integrity** — segregation of duties; no self-approval; receipts and reconciliation; reserves released only by approval matrix; social-impact fund restricted | Ch.18; Ch.20 |
| **T1.6** | **Evidence over assertion** — outcomes verified, no counting plans as impact, failures and partial outcomes included in reports, unacceptable evidence defined | Ch.15; App. F |
| **T1.7** | **Political and religious non-alignment** — as defined in A-01 and A-05 | A-01/A-05 (PROPOSED); grounded in Ch.2 and Ch.20 |
| **T1.8** | **Dignity and privacy of the person helped** — no exposure, no spectacle, no recruitment at the moment of need, help is not consent to publication | Ch.15; App. F; A-19 (PROPOSED); grounded in Const. Art.6 rights |
| **T1.9** | **Earned responsibility and fair process** — leadership earned through evidence and conduct; membership not automatic; warning then removal; appeal routes; privacy protection | Const. Art.4–8; Ch.2 principle 6 |

### TIER 2 — OPERATING POLICY (amendable by the normal process)

Everything else: weights and their values, reporting cadences, SOP detail, forms, role catalogues, vacancy taxonomy, staffing states, module design, dashboard contents, tier thresholds, language of a document, category lists, and any numeric parameter. **[S: Ch.33]** already marks most of these NOT FINAL or PROPOSED, which is consistent with Tier 2.

**[A]** The tiering test: *a Tier-1 item is one whose reversal would make the organisation a different kind of organisation.* A Tier-2 item is one whose reversal would make it work differently.

## 12.2 Constitutional principle vs. legal enforceability — kept separate

| Dimension | Tier-1 principle as **organisational constitutional rule** | Tier-1 principle as **legally enforceable restriction** |
|---|---|---|
| What it is | A self-imposed limit recorded in the constitution, binding on all levels through internal process, audit and removal sanctions | A restriction enforceable against the entity or its owners by a court, regulator, or under a governing instrument |
| How created | Amendment process in §12.3 | Depends entirely on entity form: objects clause, articles/charter, trust deed, irrevocable purpose clause, protective/special-resolution requirement, brand-licence terms, fund-restriction instruments, donor-restriction deeds **[V]** |
| Who can be bound | Every member, role-holder, leader, department, team | The entity, its directors/trustees/owners, and possibly successor entities — but *not* an unrelated owner of the parent unless instrumented |
| Current state | Achievable immediately by adoption under **[S: Const. Art.18]** | **Unknown — the legal structure is UNRESOLVED [S: Ch.33]** |
| Status in this pack | `PROPOSED — REQUIRES FINAL APPROVAL` | `REQUIRES PROFESSIONAL VALIDATION` |

**[P] Rule:** no public statement, member document or partner agreement may describe a Tier-1 principle as *legally* irrevocable until counsel confirms the instrument that makes it so. Until then the honest formulation is: *"This principle may only be changed by the special amendment process in our constitution."*

## 12.3 The special amendment process for Tier 1

**[P]** Extends **[S: Const. Art.18]** (versioned, approved, communicated, legally reviewed) with six additional requirements, applying **only** to Tier-1 items:

1. **Written proposal with reasons**, stating the problem the change solves and the alternatives considered — using the decision-rationale format of A-15.
2. **Mandatory publication period** before any vote or decision, during which the proposal is visible to all members and any member may submit a written objection (**period PROPOSED — REQUIRES FINAL APPROVAL**; a cooling-off interval is the mechanism, the length is a decision).
3. **Professional review** — legal, and where relevant tax, safeguarding, privacy or regulatory **[V]**.
4. **Reserved-matter consent** — the proposed Council's consent where the item falls within its reserved matters (see A-14 §13.4 and §11.3 item 2). **This is the point at which the UNRESOLVED CEO/Council question must be answered; this pack does not answer it.**
5. **Enhanced majority or unanimity of the deciding body** (**level PROPOSED — REQUIRES FINAL APPROVAL**).
6. **Two-decision rule** — the change is approved in principle, then confirmed at a second sitting after the publication period and reviews, so that no Tier-1 change can be made quickly, in anger, or in a crisis.

**Plus:** every Tier-1 proposal, whether adopted or rejected, is recorded permanently in the institutional archive (A-15) with its reasons — so that a future generation can see that the question was asked and why the answer was what it was.

## 12.4 What a mission lock can and cannot achieve

**[A]** Honest assessment, because over-claiming here would itself be a governance failure.

| A mission lock CAN | A mission lock CANNOT |
|---|---|
| Make reversal slow, public, documented and politically expensive | Prevent a determined owner with legal control from restructuring around it **[V]** |
| Give members, partners and regulators something to point to | Create rights in third parties unless an instrument does so **[V]** |
| Force a public conversation before a change | Guarantee that the conversation ends well |
| Preserve the *words* of the mission | Preserve the *behaviour* — culture is transmitted by what is rewarded and tolerated (stress-test §15.4), not by articles |
| Bind successors who accept the constitution | Bind a successor who controls the entity and rejects it, absent an enforceable instrument |

**[P] Therefore the mission lock must be paired with two things that do real work:** (i) the succession and reserved-matters architecture in A-14, and (ii) the transparency instruments in A-15 and stress-test §14 — because where legal enforceability is uncertain, *public visibility* is the enforcement mechanism that always works.

## 12.5 Foundational principles that are deliberately NOT locked

**[P]** Listed so that the lock is not over-broad:
- The four-pillar structure itself **[S: Ch.3]** — the *composition* of the pillars is an operating design question (see stress-test R1 on the protection pillar's public naming); what is locked is the *conduct* rules within protection (T1.2).
- The hierarchy levels **[S: Ch.4]** — federation, zoning or flattening may be necessary at scale (stress-test §5 Scenario D–E) and must not be constitutionally forbidden.
- Any percentage, weight, threshold, cadence, headcount or ratio — all already NOT FINAL **[S: Ch.33]**.
- The specific venture categories **[S: Ch.17]** — market reality changes.
- The technology design **[S: Ch.22]** — must remain free to evolve.
- Role titles and catalogues **[S: Ch.9, Ch.10]** — language must be localisable (stress-test §13).

**[A]** Locking these would convert the constitution into a straitjacket and would guarantee that the organisation either breaks the lock or breaks itself.

## 12.6 The trade-off, stated openly

**[A]** v1.2 grants the CEO "broad executive flexibility within final legal structure" **[S: Ch.4]**. A Tier-1 lock constrains *constitutional* change and therefore reduces that flexibility in one specific dimension: the founder could no longer change a foundational principle quickly, alone, or privately.

**Arguments for accepting the constraint [I]:** it is what makes long-duration promises credible to members, partners, professionals and regulators; it protects the founder from their own future pressure (a bad quarter, a persuasive partner, a political approach); it is far cheaper to adopt voluntarily now than to be forced into later; and it is the only mechanism identified in the stress test that answers "what happens if the founder changes their mind".

**Arguments against [I]:** it slows response to genuine strategic insight; it may entrench a principle that later proves wrong; it requires a governance body that does not yet exist to operate the reserved matters; and it transfers real power from a person who built the thing to a process that has not yet been tested.

**[P] Recommendation, offered as a decision not a conclusion:** adopt Tier 1 with the special amendment process, and simultaneously make the process *usable* — short reserved-matters list, defined timelines, a rule that operations continue during any dispute (A-14 §13.6) — so the lock constrains the constitution without paralysing the organisation.

---

# 13. SUCCESSION ARCHITECTURE (A-14)

**Proposed placement:** Constitution Article 23, plus new Chapter 26A beside Dynamic Leadership and Succession.
**Status:** `PROPOSED — REQUIRES FINAL APPROVAL`; **[V]** throughout. **This chapter does not name, select, rank or imply any successor.**

## 13.1 The question it answers

**"What happens if the founder disappears tomorrow?"**

**[A]** v1.2's honest answer today: operations continue under delegated executives **[S: Ch.4]**; team-level leadership succession works **[S: Ch.26]**; constitutional and ownership questions are unresolved **[S: Ch.33, Art.3, Art.19]**. **[I]** In practice, a sudden apex vacancy would produce: frozen bank mandates, an unauthorised spokesperson vacuum, a Council with no defined role, teams unsure whether standards still apply, partners invoking review clauses, and every UNRESOLVED item in the register becoming urgent simultaneously.

## 13.2 The eight scenarios

| Scenario | Trigger | Interim authority **[P]** | Time limit | Decisions permitted | Decisions prohibited | Confirmation route |
|---|---|---|---|---|---|---|
| **S1 Temporary absence** (days–weeks; travel, illness) | Written notice, or automatic on unavailability beyond a defined short period | A pre-designated **Acting CEO** (see §13.3) | Defined short period, extendable once in writing | Routine executive decisions; urgent safety, finance and legal matters | Constitutional amendment; Tier-1 change; structural change; large commitments beyond a delegated limit **[S: App. E]** | CEO resumes; handover note recorded |
| **S2 Long-term incapacity** (months; medical) | Written medical certification, or a determination by the body defined in the instrument **[V]** | Acting CEO, with the proposed Council exercising reserved-matter oversight | Until recovery, or until S5 process completes | S1 scope + continuity decisions (contracts, signatories, staffing at National level) | Same as S1, plus no mission or structure change | Council confirms; CEO may resume on certification |
| **S3 Resignation** | Written resignation | Acting CEO immediately; transition period with the outgoing founder in an advisory, non-executive capacity if they accept | Defined transition period | Full continuity scope; preparation of the selection process | Tier-1 change during the transition | Selection process (§13.5) begins immediately |
| **S4 Removal** | Only by the mechanism defined in the governing instrument **[V]** — this pack does not create one | Acting CEO; Council (or the body named in the instrument) conducts the process | Per instrument | Continuity only | Nothing touching the removal itself may be decided by the person being removed | Instrument-defined |
| **S5 Death** | Certification | Acting CEO immediately; the entity's own succession law and Krytos's governing documents take effect in parallel **[V]** | Until permanent appointment | Continuity; protection of members, funds, data and brand | Tier-1 change; asset transfer; mission change; dissolution or restructuring (**[S: Art.19]** requires professional validation) | Selection process; legal review of ownership consequences |
| **S6 Conflict of interest** | A situation where the CEO's personal, family, financial or other interest conflicts with the organisation's | The CEO **recuses**; the matter goes to the Council or an independent reviewer; Acting CEO handles only the conflicted matter | Until resolved | Only the conflicted matter is affected | The conflicted decision by the conflicted person | Recorded recusal; Audit & Ethics review **[S: Ch.28 conflict-of-interest control]** |
| **S7 Loss of trust** | Sustained, evidenced loss of confidence by governance bodies, or a serious integrity finding | This is the hardest scenario and **the pack does not resolve it**. It requires the instrument defined in S4 plus an independent review route | Per instrument | Continuity | Any self-dealing decision | Independent review; Council; external mediator (stress-test M10/M12) |
| **S8 Organisational crisis** (fraud, incident, breach, public controversy, financial collapse) | Declared by CEO or Acting CEO or Council | Crisis authority: a small named crisis group with defined scope, per **[S: Ch.5 escalation triggers — serious safety, fraud, data breach, controversy, legal notices, media crisis, collapse]** | Until the crisis is closed by recorded decision | Only decisions necessary to preserve life, safety, legal compliance, evidence, funds and continuity | Constitutional change; Tier-1 change; restructuring; permanent leadership change | Post-crisis review published internally; lessons register (A-15) |

## 13.3 The mechanism, built from instruments the architecture already has

**[A]** The stress test noted that the architecture already contains a complete deputy/delegation machine **[S: Ch.10]** — Primary Role → Sub-Role/Deputy, with delegation scope, permissions, start/end date and reviewer recorded — and vacancy statuses including `Temporarily inactive` **[S: Ch.11]**. Applying it to the apex requires no new concept.

**[P]**
1. **A designated Deputy at the apex** — the CEO's sub-role in the architecture's own terms: one named person, one designated deputy, authority explicit, recorded, RBAC-limited, time-bound and reviewed. **[S: Ch.10, Ch.22 "one role has one designated sub-role holder"]**.
2. **A written Interim Authority Order** — a short sealed document stating: the sequence of who acts if the CEO is unavailable (by role, not by name, with names appended in a separately maintained schedule); the scope of acting authority; the time limits; the prohibited decisions; and the confirmation route. Maintained by the CEO, countersigned and held in dual custody (§13.7), reviewed at a defined interval.
3. **Reserved matters** — a short list of decisions that may **not** be taken by an acting or interim authority under any scenario: constitutional or Tier-1 amendment; change of mission, name, brand or entity structure; transfer or encumbrance of assets, reserves or the social-impact fund; dissolution, merger or restructuring **[S: Const. Art.19]**; appointment of a permanent CEO; changes to the A-08 DO-NOT list; changes to the priority order of the financial waterfall **[S: Ch.18]**. **This list is the true content of the mission lock in operational terms.**
4. **Council's role during a vacancy** — oversight of the interim, custodianship of the reserved matters, and initiation of the selection process. **Because CEO-vs-Council authority is UNRESOLVED [S: Ch.33], this pack states the Council's role during a vacancy as a *proposal contingent on* that decision, and does not pre-empt it.**
5. **Nothing here creates an unaccountable body.** Interim authority is time-limited, scope-limited, recorded, reviewed by Audit & Ethics **[S: Ch.5, Ch.27]**, and reported to members in summary at the next reporting cycle **[S: Ch.24]**.

## 13.4 Access, financial and data continuity

| Domain | Requirement **[P]** | Notes |
|---|---|---|
| **Credential custody** | No single person holds all administrative credentials. Platform, cloud, code repository, domain, payment gateway, communication channels, social accounts and statutory portals are held under **dual custody** with a documented emergency-access procedure | Uses the segregation principle already applied to money **[S: Ch.18]** and extends it to authority |
| **Emergency access** | A sealed access procedure, held by two custodians who are not the CEO and not each other's subordinates, openable only on a recorded trigger (S2, S4, S5) with after-the-fact review and logging | Prevents both lockout and opportunistic access |
| **Bank mandates** | Minimum of two authorised signatories with a defined continuity rule so that **worker compensation can be paid during an apex vacancy** — the priority-1 obligation **[S: Ch.18]** must not depend on one person's availability | **[V]** Banking and entity law |
| **Reserve release during vacancy** | Requires the normal approval matrix **[S: Ch.18]** plus one additional independent confirmer (proposed Council member or external adviser) | Raises the bar exactly when oversight is weakest |
| **Data authority** | A named accountable officer for data protection at all times, including during a vacancy, with the ability to execute breach notification duties **[V: X]** | Regulators require a contactable accountable person |
| **Statutory registers and seals** | Custody, location and access defined; handover logged | **[V]** Entity-form dependent |
| **Contracts** | A register of agreements containing change-of-control, key-person or termination-on-death provisions, reviewed by counsel **[V]** | Currently unknown — see §11.3 item 9 |

## 13.5 Leadership selection at the apex (mechanism only)

**[P]** The pack specifies the *machine*, not the output:
1. **Eligibility criteria** published in advance: demonstrated conduct, verified record, financial integrity, safety compliance, understanding of the constitution, absence of unresolved conflict or misconduct, and — consistent with **[S: Ch.2 principle 6]** — earned trust rather than status or proximity.
2. **Nominating body** defined by the governing instrument; nominations may come from National, State, City level and from the Council.
3. **Assessment** against published criteria, with evidence — the same discipline the architecture applies to every other appointment **[S: Ch.11]**.
4. **Appointment and ratification** recorded, with reasons, in the decision-rationale register (A-15).
5. **Transition** with a handover checklist (§13.8), a defined overlap period, and a published transition note to members.
6. **Consistent with [S: Ch.26]**: opportunity, not automatic entitlement; governance process applies.

**[A]** Deliberately absent: any named individual, any seniority rule, any family provision, any founder prerogative to appoint a successor unilaterally. Those are decisions for the founder and the governance process — and the *absence* of a unilateral appointment power is itself the point of the mechanism.

## 13.6 Emergency decision rule

**[P]** During any apex vacancy or crisis, the following decisions may be taken by the interim authority without waiting for confirmation, and must be recorded and reported afterwards:
- anything necessary to protect life or safety **[S: Ch.16]**;
- anything necessary to comply with a legal or regulatory obligation **[V]**;
- anything necessary to preserve evidence, funds, data or the brand;
- anything necessary to keep paying workers for verified work **[S: Ch.18]**;
- anything necessary to keep delivering committed service to beneficiaries.

And the following may **not** be taken at all during a vacancy: any reserved matter (§13.3 item 3).

**[P] Continuity-during-dispute rule:** where the apex is contested or a dispute is unresolved, **operations continue under the existing delegated authority** and no faction may interrupt service, payment, safety response or record-keeping. This is the single most important line in this chapter: governance disputes must never be paid for by beneficiaries or workers.

## 13.7 Documentation and handover

**[P] Master handover checklist** (used for S1–S5 and for every National-level role transition):
constitutional and policy documents with versions · decision-rationale register · pending decisions and their deadlines **[S: Ch.33]** · bank mandates and signatory list · statutory registers, filings calendar and compliance status · contracts and partnership register **[S: Ch.29]** · credential inventory and custody arrangements · insurance policies and claims register (A-10) · pending litigation, notices and complaints · open incidents under review · reserve and social-impact fund position · key-person register · ongoing recruitment and vacancy state **[S: Ch.11]** · outstanding professional-validation items · media and spokesperson arrangements **[S: Ch.24]** · archive location and access (A-15).

**Rules:** handover completed within a defined period and signed by both parties; gaps recorded rather than concealed; Audit & Ethics verifies completion; the outgoing person remains reachable for a defined advisory period.

## 13.8 The continuity test

**[P]** An annual, unannounced exercise: the organisation operates for a defined period (proposed: 72 hours) *as though the CEO were unavailable*, using only the Interim Authority Order, the dual-custody arrangements and the documented handover state. Findings are recorded, published internally, and entered in the lessons register (A-15).

**[A]** This is the only instrument in the pack that converts succession from a document into a capability. Untested continuity plans fail; the failure is discovered at the worst possible moment. The test is cheap, mildly embarrassing, and decisive.

---

# 14. INSTITUTIONAL MEMORY SYSTEM (A-15)

**Proposed placement:** new Chapter 27A, beside Audit and Accountability.
**Status:** `PROPOSED — REQUIRES FINAL APPROVAL`.

## 14.1 The principle

**The organisation must remember WHY a rule exists, not merely WHAT the rule says.**

**[A]** v1.2 is unusually good at the second and silent on the first. Its own status labels **[S: front matter]** and decision register **[S: Ch.33]** are memory instruments — but they record *state*, not *reasoning*. A rule whose reason is forgotten will be deleted by the first person who finds it inconvenient, and the failure it was created to prevent will return.

## 14.2 The seven memory instruments

| # | Instrument | Content | Owner | Access |
|---|---|---|---|---|
| **M1** | **Decision Rationale Register** | For every constitutional, policy, SOP, financial-rule, safety-rule, privacy-rule or structural decision: the decision; date; decider; **the problem it addressed**; options considered; why this option; what it was expected to prevent; who was consulted; professional validation obtained; **review trigger** (what event or date should cause it to be re-examined) | National Operations + Editor function | Read: all members. Write: authorised only. Append-only **[S: Ch.27]** |
| **M2** | **Versioned Constitution & Policy Library** | Every version of the constitution, codes, protocols and policies, with change notes stating *why* each change was made — implementing **[S: Const. Art.18]** | National Legal + Operations | All members |
| **M3** | **SOP Library with change reasons** | All SOPs **[S: App. D]** versioned, with the incident, audit finding or lesson that caused each revision | National Operations | All role-holders |
| **M4** | **Institutional Archive** | Dated service records and outcomes; project records **[S: Ch.39.1]**; incident records (sealed); audit reports **[S: Ch.27]**; annual reports; assembly and governance minutes; corrections issued **[S: Ch.24]**; failures and partial outcomes **[S: Ch.15]**; published accounts; recognition records; partnership agreements | Editor/Archive function (proposed) | Tiered: public summaries, member-level detail, sealed categories per A-20 |
| **M5** | **Lessons Register** | Every incident review, audit finding, failed project, closed venture, rejected proposal, public correction and complaint outcome produces one entry: what happened → why → what changed → **did the change work** (checked later) | Audit & Ethics + Safety + Operations | All members; the "did it work" column is the point |
| **M6** | **Key-Person & Dependency Register** | Every function whose failure would halt a critical process, the person(s) it depends on, and the mitigation — extending the succession paths already recorded per role **[S: Ch.9, Ch.15]** | National HR | Restricted |
| **M7** | **Oral history and local record** | Short recorded or written accounts from long-serving and retiring members, in their own language, with consent: how the team started, what went wrong, what worked, what the neighbourhood was like | Communications + local teams | Public or member-level with consent; never contains restricted personal data |

## 14.3 Memory rules

**[P]**
1. **No decision without a reason recorded.** A constitutional, policy or SOP change with no M1/M2/M3 entry is procedurally incomplete and may be challenged under **[S: Const. Art.17]**.
2. **No deletion of history.** Records are superseded, not erased. Retention and erasure apply to *personal data* under A-17/A-18, not to institutional decision history — and where the two collide, the personal data is redacted and the decision record survives.
3. **Failures are archived with the same status as successes.** This implements **[S: Ch.15 "include failures and partial outcomes in reports"]** as an archival rule, not just a reporting rule.
4. **Corrections are permanent.** Every public correction **[S: Ch.24]** stays attached to the original claim in the archive.
5. **Memory is multilingual.** M1–M5 summaries and all member-facing archive content exist in the operating languages of the teams concerned (stress-test §13; A-17 classification applies).
6. **Memory is inspectable.** Any member may read the reason for any rule that binds them. This is the practical content of the right to "access to their own relevant records" **[S: Const. Art.6]** extended to organisational rules.
7. **Memory has an owner and a budget.** An archive without an owner decays. The function is small; the role can be combined with the Editor family **[S: Ch.9, Ch.10]** at low scale and separated later.

## 14.4 Why this is a survival instrument, not a nicety

**[A]** Three specific failures it prevents:
- **Rule deletion by convenience** — a future leader removes the DO-NOT entrenchment or the waterfall priority because it is inconvenient, and nobody can say why it existed. M1 makes the reason retrievable and the deletion conspicuous.
- **Repeated mistakes** — the same incident, the same failed venture category, the same recruitment error recurs in a different city five years later because the people who learned it have left. M5 with its "did the change work" column is the defence.
- **Succession amnesia** — a new leader inherits rules without context and either over-enforces them (bureaucracy) or under-enforces them (drift). M1–M3 are the onboarding document for institutional leadership.

---

# 15. FOUNDER VS INSTITUTION (A-16)

**Proposed placement:** new Chapter 4B, beside the Complete Hierarchy and Governance Map.
**Status:** `PROPOSED — REQUIRES FINAL APPROVAL`.

## 15.1 The distinction

| | **FOUNDER** | **INSTITUTION** |
|---|---|---|
| Source of authority | Ownership, vision, personal credibility, risk taken **[S: Ch.4 ownership row]** | Constitution, standards, records, processes, accumulated trust |
| Time horizon | A person's active years | Generations |
| Failure mode | Concentration: everything depends on one judgement (F-11) | Bureaucracy: everything depends on process (F-05, stress-test risk "centralisation/bureaucracy" **[S: Ch.28]**) |
| Legitimate strength | Speed, coherence, accountability, willingness to decide the undecidable | Continuity, fairness, memory, resistance to capture |
| What it must not become | "Whatever the founder says is the organisation" | A machine that has forgotten why the rules exist |

**[A]** The failure the stress test identified is not founder leadership — it is founder **synonymity**: the state in which the organisation has no existence independent of one person in the eyes of its own members, its partners, the public, or the law. Synonymity is comfortable while the founder is present and catastrophic the day they are not.

## 15.2 The healthy model — seven conditions

**[P]**
1. **Defined authority.** The founder's authority is written down: what they decide alone, what they decide with governance, what they may not decide (reserved matters, A-13/A-14). Defined authority is *stronger* than undefined authority, because it cannot be quietly contested.
2. **Institutional rules constrain abuse, not initiative.** Constraints attach to constitutional change, money movement, force, data, brand use, political activity and personnel justice. Operations remain fast and founder-led — that is the founder's legitimate advantage and should not be bureaucratized.
3. **Leadership can evolve.** Team-level dynamic leadership **[S: Ch.26]** already provides this below the apex; A-14 provides the mechanism at the apex; the horizontal ladder (stress-test M9) provides it for people who will never hold command.
4. **Mission survives leadership change.** A-13 Tier 1 plus A-14 reserved matters plus A-15 memory.
5. **Members can raise legitimate concerns.** A route that does not pass through the person complained about: the Integrity Line and ombuds proposed in stress-test M10, plus **[S: Const. Art.17]** dispute routes, plus the published external routes (§14.2 of the stress test). **An institution is one where a member can be right against a leader and survive.**
6. **Governance has defined responsibilities.** Reserved matters, audit independence, ethics oversight, dispute review — all recorded, all with named owners, all reported.
7. **No individual is legally or culturally synonymous with the institution.** Tested by the four questions below.

## 15.3 The four institutional tests (run annually)

**[P]**
1. **The absence test:** *If the founder were unavailable for twelve months, would an external observer notice a difference in what the organisation does?* Target: no. Instrument: A-14 §13.8 continuity test.
2. **The attribution test:** *In the last quarter, what share of recorded decisions were justified by reference to a person rather than to a rule, a record, or a reason?* Target: low and falling. Instrument: M1 decision-rationale register sampling by Audit & Ethics.
3. **The dissent test:** *In the last year, did any member successfully challenge a leader's decision through the formal route, and are they still a member in good standing?* Target: at least one, yes. Instrument: dispute and integrity-line records. **A zero count is a warning sign, not a clean bill of health.**
4. **The successor test:** *For every National-level role and every critical dependency, is there a named, trained, willing person who could act within a defined period?* Instrument: M6 key-person register.

## 15.4 Public representation rules

**[P]** Small, cheap, and disproportionately powerful:
- Organisational decisions are announced in the organisation's name, with the deciding role identified — not in a person's name.
- Publications, reports and accounts carry the institution as author; individuals are credited for work, not for the existence of the institution.
- Ceremonies and recognition honour **contribution and the neighbourhood**, never a person's position (stress-test F-33).
- No portrait as an object of display in organisational spaces; no founder-attribution requirement in decisions; no observance of any individual's personal dates as organisational festivals (stress-test §16.1 item 7).
- Many authorised spokespersons by domain and region **[S: Ch.24]**, so the public face is a set of people doing work.
- The founder may of course speak, lead, decide and be credited. The rule is about **dependence**, not about visibility.

## 15.5 What this does not do

**[A]** It does not diminish the founder. It does not create a body that can override operational decisions. It does not slow routine work. It does not require the founder to give up ownership — the ownership question is UNRESOLVED **[S: Ch.33]** and remains so.

**[P]** It asks for three things only: **write down the authority that already exists; make the mission harder to change than the operations; and ensure that one person's unavailability is an inconvenience rather than an ending.**

---

# 16. DATA ESTATE MAP & SECURITY CLASSIFICATION (A-17)

**Proposed placement:** new Chapter 22A, beside Data Architecture and Software Platform.
**Status:** `PROPOSED — REQUIRES FINAL APPROVAL`; privacy obligations **[V]**; specific statutory duties **[X]**.

**[S] What v1.2 already provides and this chapter does not alter:** least-privilege access by role, geography, case assignment, sensitivity and audit purpose **[Ch.22]**; upward data movement only where needed for HR, finance, safeguarding, investigation, statutory obligation, audit or approved analytics **[Ch.6]**; the RBAC matrix and its N/V/C/U/A/R/X legend **[Ch.23]**; privacy-controlled HR record content **[Ch.12]**; restricted personal recipient lists and highly restricted incident and conduct records **[Ch.15, App. F]**; data access profiles as a database field **[Ch.22]**; SOP-22 data breach response **[App. D]**.

**[A] What is missing and supplied here:** a classification scheme, a category-by-category map with ten attributes, a named human owner per category, retention and deletion as decided fields rather than UNRESOLVED placeholders, breach response per category, and the privacy-programme instruments (notice, DPIA trigger, processor standard, grievance route).

## 16.1 Security classification (four levels)

| Class | Definition | Access rule | Examples |
|---|---|---|---|
| **C1 PUBLIC** | May be published without harm to any person | Anyone, including non-members | Published accounts summaries, service outcomes with consent, correction notices, the Public Protection Statement, organisational rules |
| **C2 INTERNAL** | Ordinary operational data; disclosure causes administrative harm, not personal harm | Members with a role need, by level and geography per **[S: Ch.23]** | Task assignments, schedules, project plans, inventory, non-sensitive aggregate metrics, training completion |
| **C3 RESTRICTED** | Personal data whose disclosure could cause real harm to an identifiable person | Named role-holders with a recorded purpose; case-scoped; reason code on access | Identity verification data, contact and emergency contacts, pay records, vacancy and appointment records, member service records, customer and contract data, AI logs containing personal data |
| **C4 SEALED** | Data whose disclosure could endanger a person physically, legally or socially | Access only under the A-20 regime: named individuals, case scope, two-person rule for opening, reason code, time-limited, logged, audited | Conduct and investigation records; safeguarding and protection incident records; allegations and complaints; grievance and integrity-line records; anything identifying a victim, survivor, whistleblower, or minor; sensitive personal circumstances; political-declaration records under A-02 |

**Rules [P]:** classification is a property of the *field*, not only the record — a project record may be C2 while a beneficiary name inside it is C4. **Default upward:** where a record contains mixed classes, the highest class governs access until fields are separated. **Classification is decided once, centrally, and published internally** so that no local role-holder improvises.

## 16.2 The data estate map

Ten attributes per category, as required. Retention entries state the **decision rule**, not an invented period — periods are set by counsel and recorded in the retention schedule **[V]**.

| # | Category | 1. Why it exists | 2. Who needs access | 3. Who must NOT | 4. Retention rule | 5. Deletion rule | 6. Legal / policy basis | 7. Class | 8. Audit requirement | 9. Breach response | 10. Human owner |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **D1** | Member identity (name, verified identity reference/status/date/verifier) **[S: Ch.12]** | To know who a member is and prevent fake members **[S: Ch.12]** | HR & Verification at the member's level; Audit (review); the member themselves | Other members; business/customers; public; AI training use; any political purpose (A-01 N7) | Active membership + a defined period after exit, set by counsel **[V]**; verification artefacts (copies of documents) destroyed once verification is confirmed unless law requires **[S: Ch.12 "ID evidence restricted"]** | Erase identity artefacts at the earliest defensible point; retain only the verification *fact*, not the *document* | Membership verification **[S: Ch.12]**; lawful basis and minimisation **[V: X]** | **C3** | Access log; verification-decision audit; annual minimisation review | Notify affected person and regulator per applicable timeline **[V: X]**; suspend the affected verification process | National HR & Verification Manager (accountable) + privacy officer |
| **D2** | Contact and emergency contact **[S: Ch.12]** | Operational contact; safety response | Team Leader, Volunteer Manager, Safety Lead when needed; HR | General membership; other teams; partners; customers | Duration of membership + defined period; emergency contact data deleted on request of that third party | On member exit or on emergency contact's request | **[S: Ch.12 "access limited to HR, safety and leadership when needed"]** | **C3** | Access log with reason; periodic review of who holds it | Notify member and emergency contact; treat as high-severity | City/National HR + Safety |
| **D3** | Verification process data (interview notes, suitability assessment, references, screening outcomes) **[S: Ch.11–12]** | To evidence that verification happened and was fair | HR at the member's level; reviewer; Audit; the member (own record) | The applicant's future teammates; anyone outside HR chain; AI as sole decision-maker **[S: Ch.11 "AI cannot appoint, reject or remove"]** | Defined period after decision, longer where an appeal or complaint is live | Erase on expiry unless under legal hold; unsuccessful applicant data erased sooner than successful | Fair process **[S: Const. Art.6]**; **[S: Ch.11]** | **C3** | Decision audit; appeal records; sampling for bias | Notify applicant; review the verification process | National HR |
| **D4** | Skills and training records **[S: Ch.12]** | Role matching; restricted-task authorisation (A-10 §9.5) | Role owner, HR, Volunteer Manager, the member; verifier for certification | Public (except the member's own published credential, with consent) | Duration of membership + defined period; certifications retained while they support a claim or credential | On member request where no legal/claim dependency | **[S: Ch.12]**; evidence standard **[S: App. F]** | **C2/C3** | Certification authenticity audit | Notify member; re-verify affected certifications | National HR |
| **D5** | Team, role and membership status **[S: Ch.12]** | Operation of the hierarchy, vacancies, RBAC | Team and level per **[S: Ch.23]**; HR; Audit | Public beyond a status confirmation; other teams' detail | Current + defined history period | Status history retained (institutional memory) but personal identifiers minimised | **[S: Ch.11–12, Ch.22]** | **C2** | Status-change audit trail | Notify member; correct status | National HR |
| **D6** | **Conduct records** — warnings, complaints, investigations, outcomes, appeals **[S: Ch.12]** | Fair process, conduct rule **[S: Const. Art.8]**, safety of others | HR at the level of the case; independent reviewer; Audit & Ethics; the member (own record, subject to third-party protection) | The member's own team leader where they are the subject of the allegation; other members; AI for decision-making; anyone without a recorded case purpose | Defined period after closure with a right to seek expungement of minor matters; serious-matter retention set by counsel **[V]** | Expungement on approved request; erasure on expiry; **never** deletion while under legal hold | **[S: Ch.12 "highly restricted"; Const. Art.6, Art.8; SOP-17/18]** | **C4 SEALED** | Every access logged with reason code; independent review of access patterns; two-person rule to open | Treat as highest severity: notify affected person, contain, investigate, regulator notification per **[V: X]**; external review of the affected process | National HR + Audit & Ethics (dual ownership) |
| **D7** | **Incident records** — protection, safety, safeguarding **[S: Ch.8, Ch.16, App. F]** | Doctrinal compliance, review, corrective action, liability defence | Safety chain by category (A-09 §8.2); National Legal; Audit & Ethics; reviewer | General team membership; other teams; public; media; performance scoring beyond anonymised counts; AI without human review | Defined period set by counsel considering liability and limitation periods **[V]** | Erase identifiers of uninvolved third parties early; retain the fact pattern for lessons (A-15) in anonymised form | **[S: Ch.16, Ch.27, App. F "highly restricted"]** | **C4 SEALED** | Access log; mandatory review of every High/Emergency record; independent sample audit | Highest severity; notify affected persons where required **[V: X]**; legal hold; insurer notification (A-10 §9.3) | National Safety Lead + National Legal |
| **D8** | **Beneficiary / requester information** **[S: Ch.8, Ch.15, App. F]** | Verify need, deliver help, verify outcome | The delivering team's named roles; safeguarding where relevant; Audit on sample | Public; other teams; business functions; AI matching without human review; anyone for storytelling without consent (A-19) | **Shortest of all categories**: need-verification data erased once the outcome is verified, retaining only anonymised outcome statistics; a defined minimum retention for audit | Erase on outcome verification unless safeguarding or legal duty requires otherwise; erase on request where no duty survives | **[S: Ch.15 "avoid unnecessary beneficiary data"; App. F "personal recipient lists restricted"; Ch.8 privacy check]** | **C3, or C4 where the need is sensitive** | Access log; periodic minimisation audit; verification that lists were destroyed | Notify affected persons; suspend the service line concerned; external review where vulnerable persons are involved | City Team Leader (operational) + privacy officer (accountable) |
| **D9** | Service records and outcomes **[S: Ch.15, Ch.39.1]** | Evidence, impact measurement, reporting, member credential | Team, City, State, National aggregate; the contributing member (own record); Audit | Public beyond consented, privacy-protected summaries | Long-term for the *anonymised outcome* and the *member's own contribution record*; short for identifiers of persons helped | De-identify on a defined schedule; retain institutional memory (A-15) | **[S: Ch.15, Ch.25, App. F]** | **C2** (record) / **C3–C4** (embedded identifiers) | Evidence audit; outcome follow-up verification | Notify contributors; correct the record | National Operations |
| **D10** | Financial information — revenue, expenses, receipts, payment sheets, formula versions, reserves **[S: Ch.18–19]** | Waterfall operation, worker compensation, audit | Finance chain per **[S: Ch.23]**; Audit; the member (own pay) | Other members' pay details; public beyond published aggregates; business customers | Statutory minimum plus a defined period **[V]** | Erase personal pay detail after the statutory period, retain aggregates | **[S: Ch.18–19, Ch.27, App. F]** | **C3** | Reconciliation audit; segregation test; payment-confirmation check | Notify affected payees; freeze the process; forensic review | National Funds Manager + Audit & Ethics |
| **D11** | Worker / personnel information (classification, contracts, statutory records, tax references) **[S: Ch.33 UNRESOLVED classification]** | Lawful engagement and payment | HR, Finance, Legal; the individual | Team members; public | Statutory minimum **[V]** | Per statute; never earlier | Employment/labour/tax law **[V]** | **C3** | Payroll audit; classification review | Notify individual and adviser; regulator notification per **[V]** | National HR + National Legal |
| **D12** | Customer and contract information **[S: Ch.17, App. F]** | Deliver venture work, invoice, prove acceptance | Business chain, Finance, Legal; the assigned delivery members on a need basis | Other customers; the service side of the organisation; public | Contract duration plus limitation period **[V]** | Erase on expiry; honour customer deletion requests and contractual confidentiality | **[S: Ch.17 "customer confidentiality applies"; App. F]** | **C3** | Contract and QA audit; confidentiality test | Notify customer; contain; legal review | National AI & Business Manager + Legal |
| **D13** | Business/venture information (proposals, economics, pricing, supplier data) **[S: Ch.17]** | Venture governance | Business chain, Finance, Audit | Members without business role; competitors via any channel; public beyond aggregate | Defined business period | Archive or erase at venture closure per A-15 | **[S: Ch.17, Ch.27]** | **C2** | Venture audit; fake-revenue detection **[S: Ch.28]** | Contain; legal review | National AI & Business Manager |
| **D14** | AI-generated records — prompts, context, model/version, outputs, confidence, sources, reviewer, decision **[S: Ch.21, Ch.22]** | Human accountability for machine assistance (A-22) | The named reviewer; AI & Data; Audit; the affected person (where a decision concerns them) | Unrestricted internal access; use as training data without review; public | Defined period; **note that applicable rules may require retention of processing logs for a minimum period [X]** | Erase personal data embedded in prompts/outputs on schedule; retain the decision record | **[S: Ch.21 audit layer; Ch.22 AI logs; SOP-21]** | **C3–C4** depending on embedded content | Review-quality audit (A-22); access log | Contain; suspend the AI function; notify where personal data is involved | National AI & Data + privacy officer |
| **D15** | Performance records — scores, metrics, evidence links, exceptions, appeals **[S: Ch.25–26]** | Earned leadership, development, anti-gaming | The team concerned; City/State/National review; Audit; the individual member (own record) | Other teams' detail; public beyond published aggregates and cohort results; AI without human sign-off **[S: Ch.25]** | Defined period; appeals extend retention | Erase individual-level detail after the period; retain aggregate history | **[S: Ch.25–26, Ch.27]** | **C2/C3** | Metric-calculation audit; anomaly review; appeal records | Notify affected teams; correct scores **[S: Ch.28]** | National Operations + Audit & Ethics |
| **D16** | Leadership and governance records — appointments, delegations, declarations, recusals, Council minutes, succession instruments **[S: Ch.10–11, Ch.26; A-02, A-14]** | Accountability, continuity, conflict management | Governance bodies; Audit; the individual (own record) | General membership beyond published appointment facts; public | Long-term for institutional memory (A-15) | Redact personal identifiers on a schedule; retain the decision and its reason | **[S: Ch.10, Ch.26, Ch.27; Const. Art.4]** | **C3**, with A-02 declarations at **C4** | Delegation-expiry audit; conflict-declaration review | Notify affected persons; governance review | National HR + proposed Council |
| **D17** | Communications — internal messages, public statements, media interactions, correction logs **[S: Ch.24]** | Accuracy, approval evidence, misinformation correction | Communications chain; Audit; Legal where sensitive | Public beyond what was published; unrestricted internal access | Defined period; correction logs retained permanently (A-15) | Erase routine internal messages on schedule; retain approvals and corrections | **[S: Ch.24; App. F "correction history retained"]** | **C2/C3** | Approval-chain audit; correction-log review | Contain; correct publicly per **[S: Ch.24]** | National Communications + Editor |
| **D18** | Audit records — logs, append-only trails, access logs, review findings **[S: Ch.27, Ch.22]** | Accountability of everything above | Audit & Ethics; governance; regulator on lawful request | Operational commanders by default **[S: Ch.23 "reviewers are not operational commanders"]**; subjects of an audit cannot alter their own audit trail | Long — this is the memory of the institution; minimum periods may be prescribed for processing logs **[X]** | Append-only: supersede, never delete; erasure of embedded personal data by redaction under legal review | **[S: Ch.27, Ch.22, Ch.23]** | **C3** | Meta-audit: audit the audit function annually, externally where possible | Highest severity — a compromised audit trail destroys provability | Head of Audit & Ethics |

## 16.3 The privacy-programme instruments (missing from v1.2)

**[P, V]** Six instruments, each with a named owner. These operationalise **[S: Const. Art.13 — PROPOSED POLICY / REQUIRES PROFESSIONAL VALIDATION]** and the UNRESOLVED retention item **[S: Ch.33]**.

| Instrument | Content | Owner |
|---|---|---|
| **P1 Data classification & field register** | Every field in every module classified C1–C4 with a purpose, a legal/policy basis, a retention rule and an owner. The platform enforces class-based access; no field may be added without classification | AI & Data + privacy officer |
| **P2 Retention & erasure schedule** | A single schedule with periods set by counsel **[V]**; automated purge; legal-hold exception with logging; erasure-request handling within a defined period | privacy officer + Legal |
| **P3 Privacy notice** | Plain-language, itemised, per applicable requirements — what is collected, why, who may access, how long, what rights exist, how to complain, how to withdraw consent — in English and every operating language **[X]**; issued also retrospectively for data already held **[X]** | Legal + Communications |
| **P4 DPIA trigger list** | A data-protection impact assessment is mandatory **before** deploying: AI matching or shortlisting of people; QR/identity verification; any profiling; any new sensitive-data category; any new third-party processor; any cross-border processing. Applicable rules require periodic assessment and audit for significant fiduciaries **[X]** | privacy officer + AI & Data |
| **P5 Breach response runbook** | Hour-zero actions; containment; evidence preservation per **[S: SOP-22]**; assessment; notification to the regulator **without delay** with a detailed report within the prescribed window (72 hours under the applicable rules) and to affected individuals in plain language; CERT-In reporting within its separate prescribed window for cybersecurity incidents **[X]**; remediation; published summary | privacy officer + AI & Data + Legal + Communications |
| **P6 Processor & vendor standard** | Written contract terms extending the organisation's safeguards to every processor, cloud provider, payment provider, SMS/WhatsApp provider, verification vendor and AI model provider; security requirements; breach notification duty; no secondary use of member or beneficiary data; audit rights; exit and data-return provisions **[X]** | Legal + AI & Data |

**Plus [P]:** a **named privacy officer** (a role, not necessarily a new hire at low scale — it may be held within National Legal & Compliance **[S: Ch.5]** with a recorded conflict check), an **India-based accountable officer** if the organisation is ever designated a significant data fiduciary **[X]**, a **grievance route** with the applicable response window **[X]**, an **annual privacy report** published in summary, and **annual independent privacy review** **[V]**.

## 16.4 QR / member-identification use rule

**[P]** Implements stress-test F-28 within the already-approved concept **[S: Ch.33 "minimal data, revocable token, non-police visual design"]**:
1. Scanning is permitted only by an authorised verifier, of a person **voluntarily claiming** a role or entitlement, for a **recorded purpose**, within their scope.
2. **Never** as a condition of receiving help. **Never** of a member by another member except at role-restricted task assignment. **Never** at an entrance, in a queue, or in any public place. **Never** to establish that a person *is not* a member.
3. Every scan is logged with verifier, subject reference (pseudonymised), purpose code, time and location; anomalous scan volume is an audit trigger.
4. The card and token carry no authority implication; the wording describes a **service record**, not a credential.
5. Token revocation on exit, suspension or role change, with immediate effect **[S: Ch.11 permissions activation/revocation]**.

---

# 17. DATA MINIMISATION DOCTRINE (A-18)

**Proposed placement:** new Chapter 22B.
**Status:** `PROPOSED — REQUIRES FINAL APPROVAL`; **[V]** for legal bases.

## 17.1 The doctrine

> **COLLECT WHAT IS NEEDED. PROTECT WHAT IS COLLECTED. DELETE WHAT IS NO LONGER NEEDED.**

**[S]** This is not new to your architecture — it is already implied by "privacy check / minimum-data checklist" **[Ch.8 step 3]**, "avoid unnecessary beneficiary data" **[Ch.15]**, "personal recipient lists restricted" **[App. F]**, "ID evidence restricted" **[Ch.12]** and least privilege **[Ch.22, Ch.23]**. A-18 converts those scattered rules into a single testable doctrine with an owner and a gate.

**[A]** The risk it defends against is stated plainly: *technology makes collection nearly free, so organisations collect by default and discover the liability later.* For this organisation the liability is not abstract — the estate includes conduct records, safeguarding records and beneficiary identities, i.e. precisely the data whose exposure harms the people the organisation exists to protect.

## 17.2 The necessity test (applied field by field)

**For every sensitive field, answer in writing, before collection:**

> **"If we did not collect this, could the organisation still perform the required function?"**

| Answer | Consequence **[P]** |
|---|---|
| **Yes, fully** | **Do not collect.** Record the decision and the reason in the field register (P1) |
| **Yes, with reasonable additional effort** | Do not collect by default; collect on demand, per case, with a recorded reason |
| **Partially — the function degrades** | Collect the minimum sufficient form (e.g. a *reference* to a verified identity rather than a *copy* of the document; an age *band* rather than a date of birth; a *locality* rather than an address; a *category* of recipient rather than a name list **[S: App. F "category of recipients"]**) |
| **No — the function is impossible** | Collect, classify, justify the legal basis **[V]**, set retention, assign an owner, and record the decision permanently |

**Worked applications [A]:**
- *Identity documents.* The function is "know who the person is; prevent fake members" **[S: Ch.12]**. A copy of a document is not required for that function once verification is complete — the *fact* of verification with a verifier, date and reference is. **[S: Ch.12]** already restricts ID evidence; A-18 makes destruction of the copy the default.
- *Beneficiary names.* The function is "verify need and outcome" **[S: Ch.15]**. A name is required at verification and not after outcome confirmation. Retention beyond that point must be justified case by case.
- *Emergency contacts.* Required for safety roles and for members in restricted activities; **not** required for a Community Participant who attends one clean-up. Collection is tier-linked (§17.3).
- *Conduct detail.* The function is fair process **[S: Const. Art.6, Art.8]**. The *minimum* is the rule breached, the evidence reference, the decision, the date, the decider, the appeal status — not a narrative about a person's life.
- *Political declarations (A-02).* The function is conflict management. The minimum is the existence and scope of a role that could conflict — **never** belief, opinion, voting intention or family history (A-01 N8).

## 17.3 Tier-linked collection (joins to the participation spectrum)

**[P]** Data collected must be proportionate to responsibility, per stress-test §9:

| Participation tier | Data collected | Data expressly NOT collected |
|---|---|---|
| Level 0 Observer | Nothing beyond what they volunteer (e.g. an email for public updates) | Identity, contact beyond the channel used, location |
| Level 1 Community Participant | Name or pseudonym, contact channel, consent to be contacted about the activity, attendance fact | Identity documents, address, emergency contact, demographics |
| Level 2 Contributor | As Level 1, plus the contribution record | As above |
| Level 3 Volunteer | As Level 2, plus verification appropriate to the task, task-relevant training status, emergency contact where the task warrants | Full HR record, conduct history, financial data |
| Level 4 Specialist | As Level 3, plus professional credential verification and conflict declaration | Belief, caste, religion, political affiliation, family data |
| **Level 5 Verified Member** | The full HR record per **[S: Ch.12]**, classified per A-17 | Anything without a recorded purpose |
| Level 6–8 | As Level 5, plus role-specific eligibility, authorisation, financial permission and declaration records | — |

**Rule [P]:** upgrading tiers requires **fresh, specific consent** for the additional data — consent does not cascade upward automatically. Applicable law requires consent to be free, specific, informed, unconditional and unambiguous, limited to data necessary for the specified purpose **[X]**.

## 17.4 Prohibited collection (never, at any tier, for any purpose)

**[P]**
1. Religion, faith practice, caste, ethnicity, sect, or sub-community identity of any member, volunteer, beneficiary or applicant.
2. Political belief, party affiliation (other than the narrow A-02 role-conflict declaration), voting behaviour, or political opinion.
3. Health diagnoses, medical history, disability detail beyond what an accommodation or a safeguarding duty requires, or mental-health status.
4. Sexual orientation, marital status detail, family-planning information, or pregnancy status beyond a legal entitlement process.
5. Biometric data, unless a lawful verification method requires it and counsel has approved **[V]**.
6. Financial position, debts, or assets of members, except where a declared conflict of interest or a financial-authorisation rule requires it.
7. Location tracking or movement data of members, beyond task check-in where a task requires it and the member is informed.
8. Private communications between members.
9. Any data about a person collected *because* they received help, beyond what verification and outcome confirmation require.
10. Any data collected "in case it is useful later".

**[A]** Note the interaction with A-05 §4.2 item 4: **composition** monitoring is done in *aggregate, self-declared, optional, restricted* form for the purpose of detecting exclusion patterns — and only where counsel confirms it is lawful and the collection is genuinely minimal **[V]**. Individual-level collection of the categories above remains prohibited.

## 17.5 The minimisation gate and the annual purge

**[P]**
- **Gate:** no new field, form, report, dashboard widget, AI feature or integration may be deployed without a classification and a necessity-test entry in P1. This is the data equivalent of the architecture's own approval discipline **[S: App. E]**.
- **Control-budget interaction:** consistent with stress-test M6, any new mandatory record must be justified against the compliance-hour budget; automation is preferred to collection.
- **Annual purge:** a scheduled, logged, verified destruction of data past its retention rule, with a purge certificate retained. Purge failures are audit findings.
- **Annual minimisation report:** fields added, fields retired, volume by class, purge performance, erasure requests received and honoured, exceptions granted. Published internally in summary.
- **Owner:** the privacy officer, with Audit & Ethics verifying — **the people who want the data may not be the people who approve it.**

---

# 18. BENEFICIARY PRIVACY & DIGNITY CODE (A-19)

**Proposed placement:** new Chapter 15A, beside the Social Service Engine; plus Constitution Article 24.
**Status:** `PROPOSED — REQUIRES FINAL APPROVAL`; **[V]** where legal duties arise (minors, survivors, medical context).

## 18.1 The founding rule

> **"We helped them" is never "we may tell their story."**

**[S]** Grounded in: "use privacy-protective evidence and avoid unnecessary beneficiary data" **[Ch.15]**; "mask sensitive identities where possible", "avoid unnecessary beneficiary documents", "personal recipient lists restricted", "publishing minors' identities without consent" listed as unacceptable **[App. F]**; "protect privacy" in public communication **[Ch.24]**; "no exposure of minors" in the education category **[Ch.15]**.

**[A]** A-19 does one thing the source does not: it makes the separation of **service** from **story** an architectural rule with distinct owners, distinct access, and distinct consents — because in practice the same person performs both, and the incentive to publish is strong while the incentive to protect is diffuse.

## 18.2 Access separation matrix

| Function | What it may access about a person helped | What it may never access | Permitted output |
|---|---|---|---|
| **Service delivery** (the team delivering help) | The minimum needed to verify the need and deliver: nature of need, general location, contact route, urgency, risk flags, consent status | Full identity documents; other cases; household composition beyond necessity; anything sealed | Task record; verification note; outcome note |
| **Safeguarding** | Whatever the safeguarding duty requires, case-scoped, sealed class, named individuals only | — (this function has the widest need and the tightest logging) | Safeguarding record; authority referral; protective action |
| **Finance** | Aggregate counts and categories for reconciliation; **no identities** where a category count suffices **[S: App. F "category of recipients"]** | Named recipient lists; personal circumstances | Reconciliation entry; stock/expense record |
| **Leadership** (Team/City/State/National) | Anonymised and aggregate need, outcome and trend data; escalated cases only where a decision requires it | Individual case detail by default; curiosity access | Decision; resource allocation; escalation |
| **Public storytelling / Communications** | **Only what the person has consented to, in the form consented to, for the period consented to** — held separately from the service record | The service record itself; identifiers; case history | Consented story, or nothing |
| **Analytics** | De-identified, aggregated data under an approved analytics purpose **[S: Ch.6]** | Re-identifiable data; free-text narratives | Insight, not individual profiles |
| **AI** | De-identified data for a defined, DPIA-assessed purpose with human review **[S: Ch.21; A-21]** | Sealed-class data; identifiers of vulnerable persons; anything for a prohibited decision class | A recommendation to a named human, never a decision |
| **Audit** | Scoped review access with reason codes; may inspect any class for verification **[S: Ch.23, Ch.27]** | Retention of copies beyond the audit; onward disclosure | Finding; correction; report |

**Structural rule [P]:** the **storytelling channel has no read access to the service channel.** A story is produced only from a separate, consented, self-contained record created *with* the person, not extracted *from* their case. This single separation prevents most dignity failures, because it makes the easy path (pull a moving detail from the case file) technically unavailable.

## 18.3 Consent architecture

**[P]**
1. **Consent to help is not consent to anything else.** Receiving assistance creates no obligation, expectation or implied licence regarding recording, photographing, naming, storytelling, research, or future contact.
2. **Consent is separate, specific, informed, reversible and recorded** — in the person's language, in plain words, with a copy given to them **[X: consent standards]**.
3. **Timing.** Consent for any story or image is sought **at least one full day after** the help was completed, by a person **not involved in delivering it**, so that agreement cannot be read as gratitude under pressure.
4. **No consent from a person in crisis, in distress, in debt to the organisation, or in a dependent relationship** at the time of asking.
5. **Minors:** guardian consent plus, where the minor is capable of understanding, the minor's own assent; no image of a minor in any organisational publication without both; no naming ever; safeguarding review before use **[V]**.
6. **Withdrawal is honoured absolutely and quickly**, including removal from already-published material, with a correction log entry **[S: Ch.24]**. No consequence may follow withdrawal — including for future help.
7. **Right to be invisible.** Any person may request that their case be recorded in pseudonymised form only. The organisation accommodates this wherever a legal or safeguarding duty does not require otherwise.

## 18.4 Dignity rules in service delivery

**[P]**
1. No queue, list, token, roll-call or public announcement that identifies who is receiving help.
2. No photograph of distribution to individuals; where stock evidence is required, photograph the *stock and the process*, not the *recipients* **[S: App. F evidence requirement satisfied without exposure]**.
3. No public reading of names, no display of beneficiary lists, no publication of recipient counts in a form that identifies households.
4. No religious, caste, political or membership condition, question, or implication attached to receiving help (A-05 §4.2 item 1).
5. No recruitment, membership invitation, donation request, data-collection request or survey at the moment of help, or by the person who delivered it (stress-test §22.2 guard rails).
6. Help is delivered in the least visible manner consistent with effectiveness and safety — where a person asks for discretion, discretion is the default.
7. Language discipline: the words "beneficiary", "needy", "poor", "victim" do not appear in any public material; people are described by what happened and what was done, not by what they lack.

## 18.5 Enforcement

**[P]** Breach of this Code — publishing an image, naming a person, or using case material without valid consent — is **serious misconduct** under **[S: SOP-18]** regardless of intent and regardless of whether the person complained, because the harm is the exposure, not the reaction to it. Remedies: immediate takedown, published correction without re-exposing the person, review of the process, support to the affected person, and a lessons-register entry (A-15).

---

# 19. SENSITIVE INCIDENT & SAFEGUARDING DATA MODEL (A-20)

**Proposed placement:** new Chapter 22C; extends **[S: Ch.23 RBAC]** and **[S: App. F]**.
**Status:** `PROPOSED — REQUIRES FINAL APPROVAL`; **[V]** for legal duties.

## 19.1 The rule

**Sensitive incident information is not team-level data.** It is case-level data, held at the level where it can be protected, accessed by named individuals for a recorded purpose, for a limited time.

**[A]** This is the operational meaning of "strict least privilege" for the highest-harm category. A protection or safeguarding record visible to a ten-person neighbourhood team is a record visible to the subject's neighbours — including, potentially, to the person the record is about protecting them from.

## 19.2 Case-scoped access model

| Element | Rule **[P]** |
|---|---|
| **Case identifier** | Every sensitive matter gets a pseudonymised case reference. The link between the case reference and the person's identity is held **separately**, at City level or above, in a sealed identity index — so that most people working the case never hold the identity |
| **Access grant** | By **named individual**, not by role or team. Grant specifies: case reference, purpose, scope (which fields), duration, and approver |
| **Two-person rule** | Opening a new sealed case at local level requires two authorised people acting together; a single person may work an already-opened case within their grant |
| **Reason code** | Every access event carries a reason code from a fixed list (response, review, legal, audit, safeguarding duty, statutory request, subject's own request) |
| **Level of holding** | Sealed records are held at City level or above by default; Mohalla teams hold only the operational minimum needed to act safely, which in most cases is a *flag* ("this household requires safeguarding care") and not the *content* |
| **Logging** | Append-only access log **[S: Ch.22, Ch.27]**, reviewed periodically by Audit & Ethics for pattern anomalies (one person accessing many unrelated cases; access outside a granted scope; access by someone connected to the subject) |
| **Time limit** | Grants expire automatically, using the delegation-expiry mechanism already in **[S: Ch.10, Ch.22 "delegation_start_date / delegation_end_date"]** |
| **Emergency access** | Where immediate safety requires access outside a grant: a defined break-glass procedure — two named senior people, action first where life is at risk, log immediately, mandatory after-the-fact review within a defined short period, and a published count of break-glass uses |

## 19.3 What is sealed (C4)

**[P]** Protection incidents **[S: Ch.16]**; safeguarding matters involving minors or vulnerable adults; allegations of abuse, harassment, exploitation or violence; complaints and grievance cases; integrity-line reports and the identity of reporters; conduct investigations and outcomes **[S: Ch.12]**; anything identifying a victim, survivor, witness or whistleblower; sensitive personal circumstances disclosed in the course of help (domestic situation, health crisis, debt, displacement, custody dispute); A-02 political-conflict declarations; and any record whose publication could reasonably endanger a person.

## 19.4 Prohibited uses

**[P]** Sealed data may **never** be used for: performance scoring or leaderboards **[S: Ch.25]** (only anonymised counts and categories may flow into safety metrics); recruitment, promotion, vacancy eligibility beyond a lawful conduct check with fair-process rights **[S: Ch.11]**; storytelling, publication, training material or ceremony (A-19); commercial or business purposes of any kind; political purposes (A-01 N7); AI training or profiling without a DPIA and human review (A-21); disclosure to family, community members, employers, partners, media or authorities except where a legal duty exists or the subject consents **[V]**.

## 19.5 The subject's rights

**[P]** Extends **[S: Const. Art.6 — fair process, privacy, access to relevant own records, appeals]**:
1. Right to know what is held about them, in plain language, in their language **[X: data-principal rights]**.
2. Right to correction of inaccurate records.
3. Right to request restriction of processing or erasure where no legal or safeguarding duty requires retention **[V]**.
4. Right to know who has accessed their sealed record, subject to protection of third parties and ongoing investigations.
5. Right to complain internally **and** to be told the external route (regulator, police, consumer forum, court) — the organisation does not present itself as the only avenue **[X: grievance mechanisms]**.
6. Right to a supporter or representative in any process concerning them.
7. **Where the subject is a member accused of misconduct, the fair-process protections of [S: SOP-17/18, Const. Art.6, Art.8] apply in full** — sealing protects people from disclosure, not from due process.

---

# 20. AI GOVERNANCE EXTENSION (A-21)

**Proposed placement:** new Chapter 21A, extending **[S: Ch.21]**.
**Status:** `PROPOSED — REQUIRES FINAL APPROVAL`. **The source's doctrine and its ten prohibitions are preserved verbatim and are not amended.**

## 20.1 Preserved verbatim **[S: Ch.21]**

> **AI MAY RECOMMEND. HUMANS DECIDE.**

**AI may:** "Recommend, analyse, match, forecast, detect anomalies, generate reports, assist planning and operations."

**AI may not:** "Terminate workers, deny applications, set wages, adjudicate safeguarding, make legal conclusions, authorise serious safety actions, move significant funds or manipulate leaderboards."

**Human reviewer:** "Every medium/high-risk recommendation needs a named human decision and audit trail."

Also preserved: the eight-layer AI architecture **[S: Ch.21]**; "AI may match or shortlist; AI cannot appoint, reject or remove" **[S: Ch.11]**; "AI drafts must link evidence and human sign-off" **[S: Ch.25]**; AI training as a member competency covering "limitations, prompts, source checks, audit logs and human decisions" **[S: Ch.12]**; "no unlawful data processing or autonomous consequential decisions" in the AI-automation venture category **[S: Ch.17]**; SOP-21 **[S: App. D]**.

**[A]** These are among the strongest provisions in v1.2 and this amendment adds nothing to them and takes nothing away. What follows addresses the two failure modes the stress test identified: **review-capacity collapse (F-29)** and **uneven language capability (F-31)**.

## 20.2 Permitted-use map (where AI assists)

| AI function | Permitted use **[P]** | Risk tier | Human authority required |
|---|---|---|---|
| **Summarise** | Summarise a project record, a report, a long complaint, a training text, a meeting note | Low | Author adopts, edits or rejects; authorship is attributed to the human who publishes |
| **Classify** | Suggest a category for a request (service type, urgency band), an expense type, a document type | Low | A human confirms the category before it has any consequence; misclassification is expected and tolerated at this tier |
| **Pattern identification** | Surface duplicate evidence, repeated photos, unusual payment patterns, cluster of complaints, attendance anomalies **[S: Ch.25, Ch.28]** | Medium | A human investigates; the pattern is a *lead*, never a finding |
| **Recommend** | Suggest a candidate for a vacancy, a resource allocation, a schedule, a venture category, a corrective action | **Medium/High** | Named human decision with reason, per **[S: Ch.21]**; AI may match or shortlist only **[S: Ch.11]** |
| **Forecast** | Project demand, revenue, member availability, risk trends | Low/Medium | Used for planning only; never to determine a person's pay, status or eligibility |
| **Anomaly detection** | Financial, evidentiary, metric, access-log anomalies **[S: Ch.25, Ch.28]** | Medium | Human triage; a flagged item is not a finding; false positives are expected and must not carry consequence for the flagged person until reviewed |
| **Assist planning** | Draft a project plan, a training schedule, a route, a budget outline | Low | A human owns the plan |
| **Translate / draft in a language** | Draft or translate member-facing and public text | **High where it affects a person's rights, money, status or safety** | A named, fluent human reviewer approves before publication or before the text has any consequence (A-01 §3.3 rule 3; stress-test F-31) |
| **Answer member questions** | Explain a rule, a process, an entitlement from approved sources | Medium | Must cite the approved source; must escalate to a human on anything about money, conduct, safety, grievance or status |

## 20.3 Decisions reserved to human authority (complete list)

**[P]** Restating and extending the source's prohibitions into a decision-class register, so that a developer, a manager or an auditor can test any feature against it:

| Decision class | Human authority required | Source |
|---|---|---|
| Termination, removal, suspension, demotion of any person | Named human, with fair process | **[S: Ch.21, SOP-17/18, Const. Art.8]** |
| Denial or approval of any application, membership, vacancy, appointment or promotion | Named human; AI may shortlist only | **[S: Ch.11, Ch.21]** |
| Setting or altering compensation, rates, multipliers, or any payment amount | Named human within the finance framework | **[S: Ch.9, Ch.18, Ch.21]** |
| Any safeguarding determination or action | Named human, trained, with legal/safeguarding escalation | **[S: Ch.21, Ch.16]** |
| Any legal conclusion, including whether conduct was unlawful | Counsel only | **[S: Ch.21]** |
| Authorising any serious safety action, intervention, stand-down or activation | Named human in the safety chain | **[S: Ch.21, Ch.16, A-09]** |
| Moving significant funds, releasing reserves, or approving exceptions to the waterfall | Named humans per the approval matrix | **[S: Ch.18, Ch.21, App. E]** |
| Any change to a performance score, ranking, cohort or leaderboard | Named human with anomaly review and appeal rights | **[S: Ch.21, Ch.25–26]** |
| Publishing anything in the organisation's name | Named human author and approver | **[S: Ch.24, Ch.9]** |
| Granting, altering or revoking any permission, RBAC profile or data access | Named human administrator within policy | **[S: Ch.22, Ch.23, App. E]** |
| Classifying data, setting retention, or authorising erasure | Named privacy officer | A-17, A-18 |
| Responding to any political approach | National Legal only | A-01 §3.4 |
| Any decision affecting a person's dignity, privacy or public identity | Named human, with A-19/A-20 compliance | A-19, A-20 |

## 20.4 Review-capacity governance (the fix for F-29)

**[P]**
1. **Published risk tiers.** Every AI use is assigned a tier (Low / Medium / High) at design time and recorded in the field register. Tier determines the review requirement.
2. **Low tier** may proceed without individual pre-approval, with **post-hoc sampling** at a published rate. This preserves AI's operational value without pretending that every summary needs a signature.
3. **Medium/High tier** requires a named human decision before effect **[S: Ch.21]** — with a **per-reviewer daily cap** enforced by the platform, so that review volume cannot exceed review capacity. Queues are visible; when a queue grows, the *scope of AI use is reduced*, not the review standard.
4. **Friction by design.** For High-tier decisions the reviewer must state a reason **in their own words** — not select from a dropdown. Rubber-stamping is made slower than thinking.
5. **Review-quality audit.** Audit & Ethics samples approved recommendations and tests whether the reviewer can justify the decision from the recorded context. Approval rates near 100% and median review times near zero are audit triggers.
6. **Kill-switch and rollback.** Every AI-assisted process can be suspended and its recent effects reversed or re-reviewed. Suspension is a normal operational act, not a failure.
7. **Model and prompt versioning, source tracking, and confidence/limitation disclosure** — all already required **[S: Ch.21 orchestration layer]** — are enforced by the platform, not by convention.
8. **Language guard.** AI output in a language the reviewer is not fluent in may not be approved by that reviewer. Where no fluent reviewer exists, the output may not be used in a Medium/High-tier context. This is the concrete control that prevents F-31 from becoming a rights violation.
9. **Annual AI governance report:** uses deployed by tier, recommendation volumes, approval/modify/reject rates, review times, sampling findings, suspensions, rollbacks, incidents, language coverage. Published internally; summary published publicly.

---

# 21. AI AUDITABILITY STANDARD (A-22)

**Proposed placement:** new Chapter 21B, extending the AI audit fields in **[S: Ch.21 audit layer]**, **[S: Ch.22 AI logs]** and **[S: App. C data dictionary and audit events]**.
**Status:** `PROPOSED — REQUIRES FINAL APPROVAL`; retention **[V]**.

## 21.1 The purpose, stated exactly

> **HUMAN ACCOUNTABILITY + MACHINE ASSISTANCE**
> **not**
> **MACHINE ACCOUNTABILITY + HUMAN SIGNATURE**

**[A]** The distinction is testable. In the first, a human being had enough information, enough time and enough authority to reach a different conclusion, and can explain the one they reached. In the second, a human being clicked a button next to a machine's output. Both produce an identical audit log entry unless the log is designed to tell them apart. **This standard exists to make them distinguishable.**

## 21.2 The consequential-recommendation record

**[S]** v1.2 already requires append-only records of "prompt, output, model, sources, user, reviewer and final decision" **[Ch.21]**. **[P]** The following field set completes it. Fields marked ◆ are the ones that distinguish accountability from signature.

| # | Field | Why it exists |
|---|---|---|
| 1 | Recommendation ID and timestamp | Traceability |
| 2 | Decision class (from §20.3) and risk tier | Determines the review requirement |
| 3 | **Input context reference** ◆ | A *pointer* to the data used, not a copy — so the log itself does not become a duplicate data estate (A-18) |
| 4 | Model and version; prompt/instruction version | **[S: Ch.21]** — reproducibility |
| 5 | Output as produced | **[S: Ch.21]** |
| 6 | Confidence or uncertainty, **and stated limitations** where the system provides them | **[S: Ch.21 orchestration "confidence/limitations"]**; a reviewer who cannot see uncertainty cannot weigh it |
| 7 | Sources relied upon, with retrieval references | **[S: Ch.21]**; prevents unverifiable claims |
| 8 | Personal-data flag and classification of any embedded personal data (A-17) | Prevents C3/C4 content sitting unclassified in a log |
| 9 | **Reviewer identity, role and authority scope** ◆ | A named human with the *authority* to decide, not merely the access |
| 10 | **What the reviewer was shown** ◆ | Whether the reviewer saw the sources, the limitations and the alternatives — accountability requires the ability to have decided otherwise |
| 11 | Decision: accept / modify / reject / defer ◆ | **[S: Ch.21]** |
| 12 | **Where modified or rejected: the free-text reason in the reviewer's own words** ◆ | The single strongest anti-rubber-stamp instrument available |
| 13 | **Time spent on the review** ◆ | A four-second approval of a High-tier recommendation is a finding |
| 14 | Action taken as a result, with a link to the operational record | Closes the loop from recommendation to consequence |
| 15 | Person affected (pseudonymised), and whether they were informed where a right to know applies | Fair process **[S: Const. Art.6]**; data-principal rights **[X]** |
| 16 | Appeal or correction, if any, and its outcome | **[S: Ch.25 appeals; Const. Art.17]** |
| 17 | Retention period and purge rule for this record | **[V]**; note that applicable rules may require retention of processing logs for a minimum period **[X]** |

## 21.3 What is auditable about AI, by whom

| Audit question | Tested by | Method |
|---|---|---|
| Was a named human with authority responsible for every Medium/High-tier decision? | Audit & Ethics **[S: Ch.5, Ch.27]** | Log completeness sampling |
| Could that human have decided differently, on the information shown? | Audit & Ethics | Field 10 review; interview sample |
| Are approval rates, review times and modify-rates consistent with genuine review? | Audit & Ethics + AI & Data | Distribution analysis; triggers at near-100% approval or near-zero review time |
| Did any AI output influence a prohibited decision class? | Audit & Ethics + National Legal | Decision-class register cross-check (§20.3) |
| Were AI outputs in a language the reviewer could actually read? | Audit & Ethics | Field 4/10 cross-check against reviewer language competence |
| Did AI drafts published externally carry human authorship and evidence links? | Editor + Communications **[S: Ch.9, Ch.24, Ch.25]** | Publication sampling |
| Is the log itself protected from alteration by the people it records? | AI & Data + external reviewer **[V]** | Append-only verification; access-log review |
| Are embedded personal data classified and retained correctly? | Privacy officer | Field 8 sampling against A-17 |

## 21.4 Retention and minimisation of AI records

**[P, V]** AI logs are a data estate in their own right and are treated as one:
- Context is **referenced, not copied** (field 3) — the largest single minimisation gain available.
- Logs containing C3/C4 content inherit that classification and its access regime (A-17, A-20).
- Retention is set by counsel; applicable rules may prescribe a minimum retention for processing logs **[X]**, and any longer retention must be justified.
- AI logs are **never** used as a training corpus without a DPIA, a lawful basis and human review (A-21 §20.4; P4).
- Purge is scheduled, logged and verified (A-18 §17.5).

---

# 22. CRITICAL DECISION REGISTER (A-23, part 1)

**Proposed placement:** extension of **[S: Ch.33 Final Decision Register]** as Chapter 33A.
**Rule applied:** **no unresolved question is closed here.** Items already UNRESOLVED in v1.2 are carried forward with their status unchanged and are marked ⟨carried⟩. Items newly identified are marked ⟨new⟩. Deadlines are expressed as **gates** ("before X") rather than invented dates, because the source deliberately avoids inventing numbers **[S: Ch.33]**.

## 22.1 Carried forward, unchanged **[S: Ch.33]**

| Decision | Current state | Risk | Proposed direction | Decision owner | Professional validation? | Deadline (gate) |
|---|---|---|---|---|---|---|
| Legal structure under Krytos ⟨carried⟩ | **UNRESOLVED** | Existential: entity, tax, liability, continuity and political-neutrality obligations all depend on it | Review internal division, subsidiary, nonprofit/social arm, hybrid, or two-entity separation (stress-test R4) | Founder/CEO | **Yes — corporate, tax, regulatory** | Before Phase 0 exit **[S: Ch.30]** |
| CEO vs National Council authority ⟨carried⟩ | **UNRESOLVED** | Apex deadlock; reserved matters cannot be defined; succession mechanism cannot operate | CEO retains ownership/executive authority; Council holds delegated standards/audit/dispute oversight; a short reserved-matters list (A-13/A-14) | Founder/CEO + governance process | Yes — governance charter, legal | Before the Council is constituted |
| Public name: Sewak Sathi Sanstha ⟨carried⟩ | **PROPOSED** | Name unavailable, conflicting or unregistrable after investment | Use as public operating name while preserving Krytos parent context; validate availability, registration, branding, tax treatment | Founder/CEO | Yes — legal/name, IP | Before any public use of the name at scale |
| Worker classification ⟨carried⟩ | **UNRESOLVED** | Payment legality, liability, enforceability of role restrictions (A-02), statutory duties | Determine employee / contract labour / volunteer / stipend / business-participant categories | Founder/CEO + HR | **Yes — employment, tax** | Before the first paid engagement |
| Data retention and AI model policy ⟨carried⟩ | **UNRESOLVED / PROPOSED** | Regulatory exposure; harm to vulnerable people | Adopt the A-17/A-18 schedule once periods are set by counsel; AI model policy per A-21/A-22 | National AI & Data + Legal | **Yes — privacy, IT** | Before the first 1,000 personal records |
| Insurance ⟨carried⟩ | **UNRESOLVED** | Uncovered injury, claim or defence | Answer A-10 §9.1 items L1–L7 and L14 in writing | National Legal + Finance | **Yes — insurance broker, counsel** | Before protection activation (A-11) |
| Partnerships approval matrix ⟨carried⟩ | **UNRESOLVED / PROPOSED** | Funder capture; political adjacency | Adopt per **[S: Ch.29]** plus the funding doctrine (stress-test M19) and A-01 N6 | CEO + Legal | Yes | Before the first formal partnership |
| Weekly revenue percentages; leader multiplier; social-impact formula; reserve release rules; team readiness threshold; minimum staffing thresholds; leaderboard weights; leadership transition rules; venture categories; sub-role policy; vacancy taxonomy; delegation expiry and RBAC profiles; protection curriculum; QR ID card; serious misconduct procedure ⟨carried⟩ | As stated in **[S: Ch.33]** (NOT FINAL / PROPOSED / CONCEPT APPROVED) | Each carries an operational or fairness risk in its own right | **Unchanged by this pack.** Note only: A-17 §16.4 and A-20 add *use restrictions* to the already-approved QR concept; A-10 §9.5 and A-11 category 4 make the protection curriculum conditional on certified training where the domain is regulated | Founder/CEO with the relevant national function | As stated in **[S: Ch.33]** | As stated; none accelerated or delayed by this pack |

## 22.2 Newly identified by this amendment pack

| ID | Decision | Current state | Risk if undecided | Proposed direction | Decision owner | Prof. validation | Deadline (gate) |
|---|---|---|---|---|---|---|---|
| **N1** ⟨new⟩ | Adopt the Political Neutrality Code (A-01) | PROPOSED | Political capture and perception; tax-exempt exposure | Adopt Part A prohibitions N1–N9 and the civic/partisan boundary | CEO + Council | **Yes** for all §3.1 A.3 legal/tax questions | Before the first public activity |
| **N2** ⟨new⟩ | Election-period protocol and internal window (A-03) | PROPOSED | Distribution adjacency; misclassification | Adopt E1–E14 including the emergency exception E9 | CEO + National Legal | **Yes** — jurisdiction-specific duties | Before the first election in any operating area |
| **N3** ⟨new⟩ | Member political activity rules and tier restrictions (A-02) | PROPOSED | Conflict, attribution, or over-restriction of citizens' rights | Adopt B.2–B.5 with the anti-screening guard N8 | CEO + HR + Legal | **Yes** — employment/labour, classification | Before the first appointment above Coordinator |
| **N4** ⟨new⟩ | Equal Treatment & Non-Alignment Principle (A-05) | PROPOSED | Communal or caste classification of the organisation | Adopt as a Constitution article; keep the four guards in §4.3 | CEO + Council | Yes — where composition data is contemplated | Before expansion beyond one cultural region |
| **N5** ⟨new⟩ | Whether composition monitoring is undertaken at all, and in what form | **UNRESOLVED — deliberately** | Exclusion patterns invisible **or** an identity database is created | Aggregate, optional, self-declared, restricted, purpose-limited — or not at all | CEO + Council + privacy officer | **Yes** | Before any collection |
| **N6** ⟨new⟩ | Protection Visibility Protocol (A-06) | PROPOSED | Vigilante perception formed by a single image | Adopt V1–V43 | National Safety + Legal + Communications | Yes — terminology and authority-implication review per language | Before any public protection activity |
| **N7** ⟨new⟩ | Public Protection Statement wording (A-07) | PROPOSED draft | Over-claiming creates duty and liability; under-publishing leaves misclassification | Approve wording; publish in all operating languages simultaneously | CEO + Communications + Legal | **Yes** — representations create expectations | Before any protection publicity (A-11 G-N) |
| **N8** ⟨new⟩ | Entrenchment of the DO-NOT list (A-08) | PROPOSED | Future softening under operational pressure | Entrench as Tier-1; remove local interpretation authority | CEO + Council | Yes — enforceability | Before national expansion |
| **N9** ⟨new⟩ | Incident protocol authority matrix, mandatory triggers, do-not-attend list (A-09) | PROPOSED | Improvised local response to high-risk situations | Adopt §8.2–§8.6; revise SOP-13 by appendment | National Safety + Legal | **Yes** — intervention boundary, reporting duties | Before any safety-role authorisation |
| **N10** ⟨new⟩ | Written answers to L1–L15 (A-10) | **UNRESOLVED — questions posed, not answered** | Uncovered injury; unsupported member; unanswerable regulator | Commission written answers; hold as governance evidence | National Legal + Finance + CEO | **Yes — broker, counsel, tax** | Before protection activation |
| **N11** ⟨new⟩ | Activation Gate adoption, scope definition, renewal interval (A-11) | PROPOSED — intervals REQUIRE APPROVAL | Capability activates as a side-effect of filling a vacancy | Adopt G-N / G-C / G-T with the twelve prerequisite categories | CEO + National Safety + Legal | Yes | Before the first Safety Lead appointment |
| **N12** ⟨new⟩ | Brand ownership and licensing terms | **UNRESOLVED** | Teams hold no documented right to the name; exit and dissolution become chaotic | Determine owner, licence terms, use conditions, post-exit restrictions | Founder/CEO + Legal | **Yes** — IP | Before multi-city expansion |
| **N13** ⟨new⟩ | IP ownership of architecture, SOPs, curricula, software and data models | **UNRESOLVED** | The institution's operating system could be withdrawn by a licensor | Determine ownership and any licence to the operating entity | Founder/CEO + Legal | **Yes** — IP, tax | Before national expansion |
| **N14** ⟨new⟩ | Data fiduciary identity and named accountable officer | **UNRESOLVED** | Regulator has no contactable person; duties unassigned | Assign per entity and per data category | CEO + Legal + AI & Data | **Yes** | Before the first 1,000 personal records |
| **N15** ⟨new⟩ | Custody of reserves and the social-impact fund | **UNRESOLVED** | Restricted purpose survives in policy but in no instrument | Determine holding entity, instrument and change-of-control protections | CEO + Finance + Council | **Yes** | Before reserves accumulate materially |
| **N16** ⟨new⟩ | Bank mandate continuity and minimum signatories | **UNRESOLVED** | Worker compensation could stop on one person's unavailability | Two or more signatories with a continuity rule | Finance + CEO | **Yes** — banking, entity | Before the first external payment |
| **N17** ⟨new⟩ | Apex succession mechanism adoption (A-14) | PROPOSED | Collapse or capture on a vacancy | Adopt scenarios S1–S8, the Interim Authority Order, reserved matters and the selection mechanism | Founder/CEO + Council | **Yes** | Before national expansion; preferably before the first hire |
| **N18** ⟨new⟩ | Reserved-matters list | PROPOSED (§13.3 item 3) | Interim authority could take irreversible decisions | Adopt the seven-item list | CEO + Council | Yes | With N17 |
| **N19** ⟨new⟩ | Apex dispute-resolution mechanism | **UNRESOLVED** | Deadlock settled by power rather than procedure | Ladder: written positions → cooling period → joint session → external mediator; operations continue throughout | CEO + Council | **Yes** | Before constituting the Council |
| **N20** ⟨new⟩ | Key-person dependency register and mitigations | Not present in v1.2 | Silent single points of failure | Create and maintain (A-15 M6) | National HR + Operations | No | Before national expansion |
| **N21** ⟨new⟩ | Mission Lock Tier-1 list adoption | PROPOSED (§12.1) | Foundational principles amendable by ordinary process | Adopt T1.1–T1.9 and the special amendment process | Founder/CEO + Council | **Yes** — enforceability | Before national expansion |
| **N22** ⟨new⟩ | Publication period, majority level and deciding body for Tier-1 amendment | PROPOSED — values REQUIRING APPROVAL | Process exists but is not operable | Set the three values | CEO + Council | Yes | With N21 |
| **N23** ⟨new⟩ | Institutional memory instruments, archive ownership and budget (A-15) | PROPOSED | Rules survive without reasons; mistakes repeat | Adopt M1–M7 with a named owner | National Operations + Editor | No | Before the second city |
| **N24** ⟨new⟩ | Founder-vs-institution representation rules and the four annual tests (A-16) | PROPOSED | Personality dependence becomes structural | Adopt §15.4 rules; run the tests annually | CEO + Council | No | Before national expansion |
| **N25** ⟨new⟩ | Data classification scheme and field register (A-17 P1) | PROPOSED | No consistent protection; local improvisation | Adopt C1–C4 and complete the field register | AI & Data + privacy officer | Yes | Before platform build |
| **N26** ⟨new⟩ | Retention and erasure schedule with actual periods (A-17 P2) | **UNRESOLVED — periods deliberately not invented** | Over-retention liability or unlawful under-retention | Counsel sets periods per category | Legal + privacy officer | **Yes** | Before the first 1,000 records |
| **N27** ⟨new⟩ | Privacy notice content and languages (A-17 P3) | PROPOSED | Non-compliance; members cannot exercise rights | Draft; publish in all operating languages; issue retrospectively where required | Legal + Communications | **Yes** | Before collecting personal data at scale |
| **N28** ⟨new⟩ | DPIA trigger list (A-17 P4) | PROPOSED | High-risk processing deployed unassessed | Adopt the trigger list | privacy officer + AI & Data | **Yes** | Before any AI matching, QR verification or profiling |
| **N29** ⟨new⟩ | Breach runbook and external notification (A-17 P5) | PROPOSED | Missed statutory windows | Adopt; rehearse annually | privacy officer + Legal | **Yes** | Before holding C3/C4 data |
| **N30** ⟨new⟩ | Processor and vendor standard (A-17 P6) | PROPOSED | A third-party breach becomes the organisation's breach | Adopt contract terms | Legal + AI & Data | **Yes** | Before appointing any processor |
| **N31** ⟨new⟩ | QR and member-identification use restriction (A-17 §16.4) | PROPOSED — underlying concept already CONCEPT APPROVED **[S: Ch.33]** | Private-checkpoint perception | Adopt the five use rules | HR + Safety + Legal | **Yes** — privacy | Before issuing any card or token |
| **N32** ⟨new⟩ | Prohibited-collection list (A-18 §17.4) | PROPOSED | An identity database forms by default | Adopt the ten prohibitions | CEO + privacy officer | Yes | Before platform build |
| **N33** ⟨new⟩ | Tier-linked data collection (A-18 §17.3) | PROPOSED — contingent on the participation spectrum (stress-test M1) | Over-collection from people carrying no responsibility | Adopt with the spectrum | HR + privacy officer | Yes | With the spectrum decision |
| **N34** ⟨new⟩ | Beneficiary Privacy & Dignity Code (A-19) | PROPOSED | Dignity harm; publication without consent | Adopt §18.2–§18.5 including the storytelling/service separation | CEO + National Operations + Legal | **Yes** — minors, survivors | Before the first public story |
| **N35** ⟨new⟩ | Sealed-case model, break-glass procedure, subject rights (A-20) | PROPOSED | Sensitive data held as ordinary team data | Adopt §19.2–§19.5 | Legal + privacy officer + Safety | **Yes** | Before the first incident record |
| **N36** ⟨new⟩ | AI risk tiers, review caps and language guard (A-21 §20.4) | PROPOSED | Review fatigue voids the human-decides doctrine | Adopt tiers and caps; publish approval rates | AI & Data + Audit | Yes | Before deploying any Medium/High-tier AI use |
| **N37** ⟨new⟩ | AI auditability field set and log retention (A-22) | PROPOSED | Accountability indistinguishable from signature | Adopt the 17-field record; set retention with counsel | AI & Data + Legal | **Yes** — retention | Before deploying any consequential AI use |
| **N38** ⟨new⟩ | Amendment adoption sequencing (§24.10) | PROPOSED | Amendment fatigue; nothing implemented | Adopt in three stages | CEO + Council | No | Immediately |

---

# 23. INSTITUTIONAL LAUNCH BLOCKERS (A-23, part 2)

**Proposed placement:** extension of **[S: Ch.31 Launch Checklist Visual Control Board]** as Chapter 31A.

## 23.1 Classification test (why an item sits where it sits)

| Class | Test applied | Meaning |
|---|---|---|
| **BLOCKER** | *If this is absent, the capability either cannot lawfully or ethically operate, or its failure causes harm that cannot be reversed.* | The **relevant capability** must not be activated or publicised. This is not a statement about the whole organisation |
| **HIGH PRIORITY** | *Harm is likely and material within the pilot, but is detectable and correctable.* | Must be in place before first public use or first significant volume |
| **IMPORTANT** | *Harm emerges with scale rather than with the pilot.* | Must be in place before major scaling |
| **LATER** | *Value is real but the correct design depends on pilot evidence.* | Build after evidence; designing it now would be guesswork |

**[A]** Note what this taxonomy deliberately avoids: nothing is a blocker merely because it would be *good*. Software completeness, badges, ceremonies, the state layer, the leaderboard, national branding and the full 14-module platform are **not** in the blocker list — consistent with stress-test §26.

## 23.2 BLOCKER — the capability may not activate until resolved

| # | Item | Capability blocked | Reasoning |
|---|---|---|---|
| **B1** | Legal entity structure, tax position and worker classification ⟨carried UNRESOLVED **[S: Ch.33]**⟩ | Everything involving money, contracts, employment and public representation | Already a Phase 0 blocker in **[S: Ch.30]**; this pack adds only that A-01, A-02, A-10, A-14 and A-17 all depend on its answer |
| **B2** | Written answers to A-10 §9.1 (insurance and liability, L1–L15) | **Protection / first-response activity**; public protection claims; any activity carrying injury risk | You cannot retro-insure a known event; an uncovered injured member is an irreversible moral and financial failure |
| **B3** | Counsel review of the intervention boundary and mandatory reporting duties (L8–L10) | Protection training beyond steps 1–6 and 8–11; any work with minors or vulnerable adults | The organisation must not train people to act where the legal boundary is undefined |
| **B4** | Political Neutrality Code adopted, plus counsel review of the §3.1 A.3 questions | Any public activity, distribution, partnership or media engagement | Misclassification is near-irreversible and may carry tax-status consequences **[X]** |
| **B5** | Public Protection Statement (A-07) and DO-NOT list (A-08) approved and published in operating languages | Any public description of the protection function | A capability described publicly without its limits stated is a misrepresentation waiting to happen |
| **B6** | Certified safeguarding: two-adult rule, image and consent absolutes, reporting protocol | Any activity involving minors or vulnerable adults | Harm to a child is the highest-consequence event available to this organisation; **[S: Ch.12]** already warns that internal training is not automatically sufficient |
| **B7** | Privacy minimum: classification (P1), retention schedule (P2), notice (P3), breach runbook (P5), named privacy officer | Any systematic collection of personal data | Duties are live and penalties are large **[X]**; harm to a vulnerable data subject is irreversible; retrofitting retention onto existing data is often impossible |
| **B8** | Protection Activation Gate adopted (A-11) and G-N passed | Appointment of Safety Leads to restricted tasks; team-level safety activation | Without a gate, the most dangerous capability activates as a side-effect of filling a vacancy |
| **B9** | Bank mandate continuity and minimum signatories (N16) | Paying workers during any leadership vacancy | Worker compensation is priority 1 in the waterfall **[S: Ch.18]** and must not depend on one person's availability |

## 23.3 HIGH PRIORITY — before first public use or first significant volume

| # | Item | Reasoning |
|---|---|---|
| **H1** | Incident protocol extension (A-09): authority matrix, mandatory triggers, do-not-attend list | Improvised local response to High/Emergency categories is the most likely source of a serious incident |
| **H2** | Protection Visibility Protocol (A-06) trained and enforced | Perception forms before doctrine is ever read |
| **H3** | Sealed-case model and access logging (A-20) | Sensitive records created before the model exists cannot be retro-protected |
| **H4** | Beneficiary Privacy & Dignity Code (A-19) | The first published story sets the precedent for every later one |
| **H5** | Data minimisation gate and prohibited-collection list (A-18) | Prevents the estate growing before the retention schedule exists |
| **H6** | QR and identification use restriction (A-17 §16.4) | Required before any card or token is issued |
| **H7** | Integrity Line / independent complaint route (stress-test M10) | Must pre-exist the first leader-abuse case, or the case is discovered publicly |
| **H8** | Member political activity rules (A-02) | Required before appointments above Coordinator, where conflicts first become material |
| **H9** | Credential dual custody and emergency-access procedure (A-14 §13.4) | Lockout and opportunistic access both become possible the day a second administrator exists |
| **H10** | Language rule for legally significant documents (stress-test §13.2 rule 1) | A payment sheet, warning or safety instruction a person cannot read is not a record — it is a liability |
| **H11** | AI risk tiers and review caps (A-21 §20.4) | Required before any Medium/High-tier AI use is deployed |
| **H12** | Recruitment-conduct and earnings-reality rules (stress-test M16) | The first recruitment conversation sets an expectation that will later be met or resented |
| **H13** | Processor and vendor standard (P6) | The first cloud, payment or messaging vendor is the first processor |

## 23.4 IMPORTANT — before major scaling

| # | Item | Reasoning |
|---|---|---|
| **I1** | Mission Lock Tier-1 adoption and special amendment process (A-13) | Cheap before the institution has value; expensive after |
| **I2** | Succession architecture and Interim Authority Order (A-14) | Must exist before there is something to succeed to |
| **I3** | Apex dispute-resolution mechanism (N19) | Must pre-date the Council it governs |
| **I4** | Institutional memory instruments M1–M5 (A-15) | Decision reasons must be captured while the deciders are still present |
| **I5** | Key-person dependency register (N20) | Becomes unbuildable retrospectively |
| **I6** | Brand and IP ownership and licensing (N12, N13) | Must be settled before many parties rely on the brand |
| **I7** | Custody of reserves and the social-impact fund (N15) | Must be settled before the sums become material |
| **I8** | AI auditability field set (A-22) | Fields cannot be retro-fitted onto past logs |
| **I9** | Founder-vs-institution representation rules and the four tests (A-16) | Culture sets early and is expensive to change later |
| **I10** | DPIA programme and significant-fiduciary assessment (P4) | Obligations attach at scale **[X]** |
| **I11** | Composition-monitoring decision (N5) | Must be decided deliberately, not by default |

## 23.5 LATER — after pilot evidence

| # | Item | Reasoning |
|---|---|---|
| **L1** | Numeric values for every interval, ratio, threshold and period in this pack | The source deliberately does not invent numbers **[S: Ch.33]**; pilot evidence should set them |
| **L2** | Continuity test at full scope (A-14 §13.8) | Requires the instruments to exist first; a tabletop version can run earlier |
| **L3** | Oral history programme (A-15 M7) | Valuable once there is history |
| **L4** | Public archive and published institutional memory | Requires classification and redaction capability to be mature |
| **L5** | Annual AI governance report in full form (A-21 §20.4 item 9) | Requires a year of AI use |
| **L6** | External independent privacy and governance reviews | Appropriate once there is something substantial to review **[V]** |
| **L7** | Full federation or state-entity structure | A scale question (stress-test §5, Scenario D) |

---

# 24. v1.3-A AMENDMENT PACK (mergeable)

**Merge instruction [P]:** each amendment states where it lands in a future consolidated v1.3 master document. All 23 are additive. **No existing chapter, article, SOP, table or rule is deleted, renumbered or reworded.** Where an amendment extends an existing instrument (SOP-13, App. C, the Ch.31 checklist, the Ch.33 register, Const. Art.9, Const. Art.18), the extension is *appended* and the original text is preserved intact. Each entry carries the twelve fields required by your brief, in order.

## A-01 · Political Neutrality Code — organisational neutrality

| Field | Content |
|---|---|
| **1. Amendment ID** | A-01 |
| **2. Existing architecture reference** | **[S: Ch.2 principles; Ch.5 Legal & Compliance and Communications; Ch.24 communications rules and authorised spokespersons; Ch.28 risks "mission drift", "conflict of interest", "reputational/safeguarding failure"; Ch.29 partnership due diligence; Const. Art.1–2; App. E approval matrix; stress-test F-08]** |
| **3. Problem discovered** | No rule governs partisan use of brand, resources, records, member lists, events, funds or channels; no rule on political donations, symbols or organisational endorsements; no published non-alignment position. Tax-exempt standing may depend on absence of political activity **[X]** |
| **4. New safeguard** | Nine organisational prohibitions (N1–N9); a written civic/partisan boundary with a one-line newspaper-headline test; a standing public non-alignment statement; publication of refusal counts |
| **5. Reason** | Misclassification as a political body is near-irreversible and would falsify the Article 1 non-discrimination promise in the eyes of half of any locality |
| **6. Operational effect** | Teams decline and log political requests instead of improvising; event calendars are checked for political adjacency; distribution activity is reviewed near elections |
| **7. Governance effect** | National Legal becomes the single decision point for political-adjacent requests; Audit & Ethics gains a sampling duty; the proposed Council receives the annual refusal log |
| **8. Technology effect** | An approach/refusal register; an event-calendar adjacency flag; access-log sampling to evidence N7 |
| **9. Cost / capacity implication** | Low. One register, one script, one annual review. Burden falls on National Legal, not on teams |
| **10. New risk introduced** | Over-application chilling legitimate civic advocacy; enforcement used against disliked members; members feeling surveilled. **Mitigations:** the written civic/partisan boundary (§3.1 A.4); the anti-screening prohibition N8; written reasons and appeal rights (§3.2 B.5); symmetric-enforcement audit |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — every question in §3.1 A.3 (entity political-activity restrictions; tax-exemption conditions; donation and deduction effects; foreign contribution; election-period obligations; attribution and agency liability) |
| *Merge target* | New Chapter 29A; Constitution Article 20 |

## A-02 · Member political activity and conflict of interest

| Field | Content |
|---|---|
| **1. Amendment ID** | A-02 |
| **2. Existing architecture reference** | **[S: Ch.2 non-discrimination; Ch.10 delegation recording; Ch.11 vacancy statuses incl. `Temporarily inactive`; Ch.12 membership and conduct; Ch.28 conflict-of-interest control "disclosure, recusal, review/void"; Const. Art.6–8; SOP-17, SOP-18; stress-test F-08]** |
| **3. Problem discovered** | Nothing defines what a member may do politically, when affiliation must be disclosed, or how a conflict is handled — leaving either a vacuum (capture risk) or an improvised response (rights risk) |
| **4. New safeguard** | A six-tier graduated rule set (T0–T5) mapped to the participation spectrum; six universal rules; disclosure, recusal and **role-suspension rather than membership-suspension** mechanics built on existing delegation and vacancy-status instruments; four anti-abuse guards including an absolute ban on belief screening |
| **5. Reason** | Members are citizens first. The organisation regulates attribution, resources and conflict — never belief — which is both narrower and more defensible |
| **6. Operational effect** | T3–T5 role-holders file a declaration on accepting party office, candidacy or a campaign role; recusals are recorded; T4/T5 roles suspend for the duration with automatic end dates |
| **7. Governance effect** | HR holds declarations at classification C4; Audit & Ethics reviews enforcement symmetry; the Council is informed of T5 declarations |
| **8. Technology effect** | A restricted declaration field; recusal flagging on allocation and appointment workflows; automatic delegation end dates |
| **9. Cost / capacity implication** | Very low; affects a small number of role-holders |
| **10. New risk introduced** | Perceived as political vetting; usable against members from communities associated with a party; chilling of legitimate participation. **Mitigations:** N8 prohibition on belief screening; declarations capture *positions held*, never opinions; C4 classification; written reasons; appeal; symmetry audit; explicit statement that membership does not diminish citizenship |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — lawfulness of role-attached restrictions given the unresolved worker-classification question; scope of citizens' rights; any election-law duties |
| *Merge target* | Chapter 29A.2; cross-reference from Ch.11 eligibility dimensions and Ch.12 conduct |

## A-03 · Election-Period Operating Protocol

| Field | Content |
|---|---|
| **1. Amendment ID** | A-03 |
| **2. Existing architecture reference** | **[S: Ch.24 communications rules; Ch.15 service categories incl. donations and distribution; Ch.16 protection; Ch.5 escalation incl. media crisis; App. E public-statement approval; stress-test F-08]** |
| **3. Problem discovered** | No protocol for the highest-adjacency period in the organisation's calendar; a distribution event or a photograph near polling can reclassify the institution permanently |
| **4. New safeguard** | Fourteen rules E1–E14 covering events, service, communications, social media, identification, public statements, candidate contact, political requests, resources, data, member representation, donations and post-period audit review — plus an **emergency exception E9 requiring dual authorisation and mandatory publication of reasons** |
| **5. Reason** | Restraint must be pre-decided, because in the moment it will be contested by someone with a strong reason to proceed |
| **6. Operational effect** | Mass distribution and public events are deferred during the window; routine and household-level help continues uninterrupted; emergency response continues under dual authorisation |
| **7. Governance effect** | National Legal owns the window and its exceptions; Audit & Ethics reviews the period afterwards (E14) and publishes counts |
| **8. Technology effect** | A per-jurisdiction calendar flag; an exception-authorisation workflow; access-log sampling during the window |
| **9. Cost / capacity implication** | Moderate during windows; concentrated in National Legal and Communications |
| **10. New risk introduced** | The protocol could stop genuine help, or be applied selectively against activities a leader dislikes. **Mitigations:** the E9 emergency exception with published reasons; E2 explicitly protects household-level and already-committed service; the window is jurisdiction-defined and published, not discretionary |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL`; the internal window length is separately `PROPOSED — REQUIRES FINAL APPROVAL` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — jurisdiction-specific obligations, expenditure and inducement rules, permissions |
| *Merge target* | Chapter 29A.3; SOP-23; an addition to the Ch.31 checklist |

## A-04 · Political Approach Response Workflow

| Field | Content |
|---|---|
| **1. Amendment ID** | A-04 |
| **2. Existing architecture reference** | **[S: Ch.7 escalation map; Ch.5 Legal & Compliance; Ch.21 humans decide; Ch.27 audit pathway; Ch.28 conflict of interest; App. E approval levels; stress-test F-08]** |
| **3. Problem discovered** | A local team facing a request from a powerful political actor has no script, no route and no protection — and will improvise |
| **4. New safeguard** | The seven-step workflow given in your brief (receive → make no ad-hoc commitment → escalate → policy check → authorised human decision → document → audit) with an approved holding line, refusal script, written-reply template, approach register, published annual refusal counts, and a duty to support members who face consequences for a logged refusal |
| **5. Reason** | Neutrality that cannot be *evidenced* is indistinguishable from neutrality that does not exist |
| **6. Operational effect** | Local members stop having to make institutional decisions under pressure; responses become written and national |
| **7. Governance effect** | Only National Legal (CEO for exceptional cases) may decide; Audit samples the log |
| **8. Technology effect** | A structured register; escalation routing; annual count reporting |
| **9. Cost / capacity implication** | Low; a small number of decisions per year per city is expected **[A-assumption — no source figure exists]** |
| **10. New risk introduced** | Centralisation of a decision that is often time-sensitive; the register itself becoming sensitive data about political actors. **Mitigations:** a standing pre-approved refusal covering the common cases, requiring no decision at all; the register classified C3 with restricted access and holding no belief data (A-18 §17.4) |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — wherever a request touches a legal duty |
| *Merge target* | Chapter 29A.4; SOP-24; extends the **[S: Ch.7]** escalation map as a new lane |

## A-05 · Equal Treatment and Non-Alignment Principle

| Field | Content |
|---|---|
| **1. Amendment ID** | A-05 |
| **2. Existing architecture reference** | **[S: Ch.2 principle 1; Ch.15 category controls; Ch.20 social-impact fund not for political or religious activity; Ch.24 communications; Ch.28 reputational and safeguarding risk; Ch.29 partnership flow; Const. Art.1–2; stress-test F-08, F-31, F-36]** |
| **3. Problem discovered** | Non-discrimination in *service delivery* does not prevent the organisation being *identified with* a faith, caste, language, region or social group through composition, calendar, venue, partners, symbols or leadership pattern |
| **4. New safeguard** | An eight-point principle covering service without distinction, institutional non-alignment, cultural respect without alignment, composition monitored but never engineered, activity-scoped faith-based partnership, no religious or caste framing, no communal symbols, and language equality — with four explicit guards against cultural erasure, against excluding faith-motivated people, against quotas, and against silence about harm |
| **5. Reason** | Pattern-level neutrality cannot be inferred from act-level non-discrimination; and the guards prevent the principle from becoming cultural flattening |
| **6. Operational effect** | Local culture, language, calendar and courtesy remain fully local (stress-test §12); partnerships with faith-based bodies become activity-scoped with a written scope |
| **7. Governance effect** | Audit reviews composition patterns and partnership scopes; the Council holds the principle |
| **8. Technology effect** | Aggregate, optional, restricted composition fields **only if N5 approves their existence at all**; a partnership-scope field |
| **9. Cost / capacity implication** | Low |
| **10. New risk introduced** | Read as hostility to local culture or to faith-motivated members; composition monitoring creating an identity database. **Mitigations:** the §4.3 guards; N5 remains deliberately UNRESOLVED; A-18 §17.4 prohibits individual-level collection of religion, caste and ethnicity absolutely |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — only if any composition data is contemplated |
| *Merge target* | Constitution Article 21; new Chapter 2A beside Mission and Principles |

## A-06 · Protection Visibility and Public Conduct Protocol

| Field | Content |
|---|---|
| **1. Amendment ID** | A-06 |
| **2. Existing architecture reference** | **[S: Ch.16 nine-step sequence, four risk tiers, six DO-NOTs; Ch.9 safety-role boundary; Ch.10 Incident Documentation Officer sub-role; Ch.24 communications; Ch.33 QR concept "non-police visual design"; App. F incident evidence "highly restricted"; stress-test F-09]** |
| **3. Problem discovered** | Doctrine governs intent; nothing governs appearance. Dress, symbols, group movement, filming, crowd presence and interaction with authorities are the channels through which a service organisation is misread as a security or vigilante body |
| **4. New safeguard** | Forty-three rules across seven areas: identification and dress (V1–V7), symbols and marks (V8–V11), group movement and presence (V12–V17), public behaviour (V18–V23), filming, photography and social media (V24–V30), interaction with authorities (V31–V35), scenes, crowds and vulnerable people (V36–V41), and visibility documentation fields making visibility auditable (V42–V43) |
| **5. Reason** | Perception is formed by one image, in ten seconds, by people who will never read the doctrine |
| **6. Operational effect** | No uniform or insignia; identification carried not worn; maximum two responders; no patrolling; no filming of incidents; no publication of incident material; step back and hand over on arrival of authorities |
| **7. Governance effect** | National Safety owns the protocol; Audit tests compliance from records alone using V42–V43 |
| **8. Technology effect** | Incident-record fields for visibility attributes; scan and filming flags |
| **9. Cost / capacity implication** | Low financial cost, moderate behavioural discipline; concentrated on Safety Leads |
| **10. New risk introduced** | Members may under-respond in a genuine emergency from fear of breaching a visibility rule; task-scoped identification (V5) could creep into a de facto uniform. **Mitigations:** §5.5 and §10.5 preserve the source rule that any member may call emergency authorities and trained members may give first aid within training **[S: Ch.16]**; V5 is activity-scoped, removable and audited |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — per-language terminology review (V11); authority-implication review; the V33 boundary on assisting authorities |
| *Merge target* | New Chapter 16A |

## A-07 · Public Protection Statement

| Field | Content |
|---|---|
| **1. Amendment ID** | A-07 |
| **2. Existing architecture reference** | **[S: Ch.16 doctrine; Ch.24 public communication rules; Ch.31 branding and communications checklist item; Ch.34 glossary definition of Protection / First Response; stress-test F-09, F-36]** |
| **3. Problem discovered** | There is no public, plain-language statement of what the protection function is and is not; the public fills the vacuum with the worst available analogy |
| **4. New safeguard** | A drafted public statement (§6.1) stating the trained steps, seven explicit "we are not" declarations, what the public can expect, and published complaint routes — with design notes requiring that limits be stated more loudly than capabilities |
| **5. Reason** | Under-claiming is the only safe posture for a function whose over-claiming is fatal; it also makes the part that is claimed believable |
| **6. Operational effect** | Every team can hand a resident, an official or a journalist the same accurate answer |
| **7. Governance effect** | Approved through **[S: Ch.24]** communications controls; owned by National Communications with Legal |
| **8. Technology effect** | None beyond publication channels |
| **9. Cost / capacity implication** | Low; translation and per-language review are the main cost |
| **10. New risk introduced** | A public description of protective activity may itself create an expectation of response, or a duty of care. **Mitigation:** counsel review of every wording **[V]**; publication gated behind A-11 G-N and the A-10 answers |
| **11. Approval status** | `PROPOSED — draft text requiring approval` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — representations, duty of care, advertising and consumer-protection norms |
| *Merge target* | A public document, referenced from Ch.24 and Ch.31 |

## A-08 · Protection DO-NOT List — constitutional entrenchment

| Field | Content |
|---|---|
| **1. Amendment ID** | A-08 |
| **2. Existing architecture reference** | **[S: Ch.16 six DO-NOTs; Ch.9 safety-role boundary; Const. Art.9; SOP-18; stress-test F-09]** |
| **3. Problem discovered** | The prohibitions exist but are amendable and locally interpretable; under operational pressure a future leader can narrow them |
| **4. New safeguard** | A ten-item permanent list — the six source prohibitions restated, plus no weapons (absolute), no patrolling or watching, and no filming or publicising victims — entrenched as a Tier-1 principle, with local interpretation authority **removed** and breach classified as serious misconduct regardless of outcome |
| **5. Reason** | These are the rules whose violation is irreversible on video and in memory |
| **6. Operational effect** | Any application question escalates to National Safety and National Legal *before* action |
| **7. Governance effect** | Tier-1 entrenchment under A-13; displayed in every team space; recited in every safety training |
| **8. Technology effect** | None |
| **9. Cost / capacity implication** | Negligible |
| **10. New risk introduced** | Members may confuse the DO-NOT list with the source's lawful-intervention permission and freeze in a genuine emergency. **Mitigation:** §7.2 item 3 requires this distinction to be trained explicitly, and the **[S: Ch.16]** emergency provisions are restated unchanged |
| **11. Approval status** | Source items 1–7: `LOCKED / APPROVED ARCHITECTURE` **[S]**. Items 8–10 and the entrenchment mechanism: `PROPOSED — REQUIRES FINAL APPROVAL` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — enforceability of entrenchment given the unresolved entity form |
| *Merge target* | Constitution Article 9 (expanded by appendment); a permanent visual panel |

## A-09 · Protection Incident Protocol (extended)

| Field | Content |
|---|---|
| **1. Amendment ID** | A-09 |
| **2. Existing architecture reference** | **[S: Ch.16 nine-step sequence and four-tier matrix; SOP-13; Ch.8 step 3 basic safety check; Ch.14 safety failure response; App. E high-risk and emergency row; App. F incident evidence; Ch.39.2 incident record minimum fields; stress-test F-09, F-10]** |
| **3. Problem discovered** | SOP-13 is a handful of minimum steps. It does not say who may authorise what, when escalation is mandatory, which situations must not be attended, what the record must contain, or how review independence is preserved |
| **4. New safeguard** | An eleven-step workflow (adding safe exit/handover and corrective action to the source's nine); a five-column incident authority matrix by risk category; three absolute cross-cutting limits; thirteen mandatory escalation triggers; nine do-not-attend categories; an extended documentation standard including visibility fields; an independence rule for review; member-support provisions; and an explicit prohibition on any tactical or force instruction |
| **5. Reason** | The gap between doctrine and an incident at eleven at night is filled by whatever the member improvises, unless it is filled in advance |
| **6. Operational effect** | Members know precisely what they may do at each category; withdrawal is defined as success; two-responder maximum |
| **7. Governance effect** | Review independence (no self-review; no review of relatives or close associates); City level or above reviews all High and Emergency incidents and any use of force |
| **8. Technology effect** | An incident form with mandatory fields; sealed storage per A-20; escalation routing |
| **9. Cost / capacity implication** | Moderate at incident time, low in steady state. The burden falls on Safety Leads, who receive the support provisions in return |
| **10. New risk introduced** | Over-proceduralising an emergency; members delaying a call for help while consulting a matrix. **Mitigation:** the workflow preserves **[S: Ch.16]** — any member may call emergency authorities at any category, immediately, without authorisation; steps 1–6 require no approval |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL`; all time intervals `PROPOSED — thresholds require approval` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — the step 7 legal boundary (L8), first-aid protections (L9), mandatory reporting duties (L10), mental-health and disability context (V40) |
| *Merge target* | New Chapter 16B; SOP-13 revised by appendment, original text preserved |

## A-10 · Protection Liability Framework

| Field | Content |
|---|---|
| **1. Amendment ID** | A-10 |
| **2. Existing architecture reference** | **[S: Ch.31 checklist row "insurance advice / coverage decision"; Ch.33 insurance UNRESOLVED; Ch.5 Legal & Compliance; Ch.12 training-sufficiency caveat; Ch.28 risk responses; App. E escalation and professional-validation column; stress-test F-10]** |
| **3. Problem discovered** | The architecture promotes a liability-bearing function while its insurance and legal-support position remains an open checklist item. A member injured or prosecuted after acting within doctrine has no defined support |
| **4. New safeguard** | A fifteen-item requirements-to-validate register (L1–L15) posed as questions for broker, counsel and tax professionals; a coverage-confirmation rule ("no written confirmation, no activation"); an eight-stage legal-support protocol; an injury, damage and third-party-claim procedure with a no-local-settlement rule; and a training-and-authorisation evidence standard ("no authorisation record, no restricted task") |
| **5. Reason** | This document must not invent coverage. It can, however, make the *absence* of coverage a hard stop |
| **6. Operational effect** | Protection activity is gated on written answers; members receive a written cover statement in their own language before taking a safety role |
| **7. Governance effect** | National Legal owns the register and the claims process; the CEO records any decision to proceed without cover, with its consequences |
| **8. Technology effect** | A claims and policy register; authorisation-record retrieval |
| **9. Cost / capacity implication** | Real cost (premiums, counsel) — which is the point: it forces the decision rather than deferring it |
| **10. New risk introduced** | The framework could be read as promising cover it does not provide. **Mitigation:** §9.2 rule 4 forbids representing any element as cover without written insurer confirmation |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — every row of L1–L15; **no coverage is asserted anywhere in this pack** |
| *Merge target* | New Chapter 16C; the Ch.31 checklist row expanded |

## A-11 · Protection Activation Gate

| Field | Content |
|---|---|
| **1. Amendment ID** | A-11 |
| **2. Existing architecture reference** | **[S: Ch.13 autonomy readiness gates (as a pattern); Ch.30 phase gates; Ch.31 blocker statuses; Ch.11 role appointment and permission activation; Ch.23 restricted tasks; Ch.9 Safety Lead; stress-test F-10, F-25]** |
| **3. Problem discovered** | Protection capability currently activates as a side-effect of filling a Safety Lead vacancy; nobody decides whether the organisation is ready to be doing this in public |
| **4. New safeguard** | A three-level gate (G-N national / G-C city / G-T team) with twelve prerequisite categories, each requiring a named artefact, a named confirmer and recorded evidence; plus seven gate rules (binary and evidence-based; scoped; time-limited and renewable; revocable; support-first on failure; no retroactive activation; public honesty before G-N) |
| **5. Reason** | It applies the architecture's own readiness-gate logic **[S: Ch.13]** to the capability with the highest external consequence |
| **6. Operational effect** | No safety-role authorisation for restricted tasks, and no public protection claim, before the gate is passed at the relevant level |
| **7. Governance effect** | CEO plus National Safety plus National Legal decide G-N; the Council is informed; National Safety may revoke on a serious incident |
| **8. Technology effect** | Gate status per team and city; permission profiles blocked until the gate passes, using existing **[S: Ch.22]** permission and delegation fields |
| **9. Cost / capacity implication** | Moderate once, then a renewal cycle. It deliberately slows activation — that is its function |
| **10. New risk introduced** | The gate becomes a bureaucratic bottleneck, or teams operate informally without passing it. **Mitigations:** the support-first rule; scoped approvals so partial capability can activate; exceptions recorded and reviewed rather than hidden; §10.5 preserves individual citizen conduct |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL`; all intervals and ratios `PROPOSED — thresholds require approval` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — categories 2, 3 and 11 (legal review, insurance, safeguarding) |
| *Merge target* | New Chapter 16D; Ch.31 checklist; Ch.30 Phase 1 and 2 exit gates cross-referenced, not altered |

## A-12 · Founder Concentration Analysis

| Field | Content |
|---|---|
| **1. Amendment ID** | A-12 |
| **2. Existing architecture reference** | **[S: Ch.4 authority hierarchy and table; Const. Art.3, Art.18, Art.19; Ch.33 legal structure and CEO/Council UNRESOLVED; Ch.18 reserves; Ch.20 social-impact fund; Ch.22 data; Ch.26 team succession; stress-test F-11]** |
| **3. Problem discovered** | Ownership, executive authority, brand, strategy, mission amendment and — by default — IP and data all sit in the same hands, with no apex succession provision and no instrument binding a future holder |
| **4. New safeguard** | **None — analysis only.** Deliverables: a source-cited relationship table; a twelve-asset concentration map with continuity risk per asset; and nine **new** unresolved items added to the decision register (N12–N20) without being resolved |
| **5. Reason** | The instruction is explicit: identify what remains unresolved; do not silently resolve it |
| **6. Operational effect** | None directly; feeds A-13, A-14, A-15 and A-16 |
| **7. Governance effect** | Makes concentration visible to the Council, to auditors and to any future partner conducting due diligence |
| **8. Technology effect** | None |
| **9. Cost / capacity implication** | None |
| **10. New risk introduced** | The analysis could be read as criticism of founder leadership, or as pre-deciding the entity structure. **Mitigation:** §11.4 states the structural observation as analysis and explicitly separates *operational* authority, which should stay concentrated, from *constitutional* authority, which should not |
| **11. Approval status** | `ANALYSIS — no decision taken` |
| **12. Professional validation status** | Items N12–N16 each `REQUIRE PROFESSIONAL VALIDATION` |
| *Merge target* | New Chapter 4A (analytical annex) |

---

## A-13 · Mission Lock Framework

| Field | Content |
|---|---|
| **1. Amendment ID** | A-13 |
| **2. Existing architecture reference** | **[S: Const. Art.1–2, Art.4–16, Art.18, Art.19; Ch.2 principles; Ch.16 DO-NOTs; Ch.18 waterfall; Ch.20 fund restrictions; Ch.21 AI doctrine; Ch.15 anti-fake-impact rules; App. F; Ch.33 status labels; stress-test F-11]** |
| **3. Problem discovered** | Foundational principles are amendable by the same ordinary process as any operating policy **[S: Const. Art.18]**, so a future holder could lawfully convert the institution |
| **4. New safeguard** | A two-tier structure: nine Tier-1 foundational principles (T1.1–T1.9), each cited to its existing source, with everything else Tier-2; a six-requirement special amendment process for Tier 1 (written reasons; mandatory publication period; professional review; reserved-matter consent; enhanced majority; two-decision rule); permanent archival of proposals whether adopted or rejected; and an honest statement of what a lock can and cannot achieve |
| **5. Reason** | Long-duration promises to members, partners, professionals and regulators require that the mission be harder to change than the operations |
| **6. Operational effect** | None on daily work — Tier 2 carries all operational flexibility, including every number, weight, cadence and catalogue |
| **7. Governance effect** | Constitutional change becomes slow, public, documented and shared; **requires the CEO/Council question (N19 and [S: Ch.33]) to be answered, which this pack declines to answer** |
| **8. Technology effect** | A versioned constitution with change-reason fields (A-15 M1/M2) |
| **9. Cost / capacity implication** | Low ongoing; high deliberateness at the moment of use — which is the design intent |
| **10. New risk introduced** | **It reduces founder constitutional flexibility**, in acknowledged tension with **[S: Ch.4 "broad executive flexibility"]**; it could entrench a principle later proven wrong; it could paralyse response if the process is unusable. **Mitigations:** §12.5 lists what is deliberately *not* locked; §12.6 requires the process to be short, timed, and paired with a rule that operations continue during any dispute; §12.4 states plainly what a mission lock cannot do |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL`; publication period, majority level and deciding body each `PROPOSED — values require approval` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — legal enforceability by entity form; objects clauses; protective provisions; fund-restriction instruments |
| *Merge target* | Constitution Article 22; procedure appended to Article 18 with the original text preserved |

## A-14 · Succession Architecture

| Field | Content |
|---|---|
| **1. Amendment ID** | A-14 |
| **2. Existing architecture reference** | **[S: Ch.4 executive authority and delegation; Ch.10 sub-role/deputy with recorded delegation and dates; Ch.11 vacancy statuses; Ch.22 `designated_sub_role_id` and delegation dates; Ch.26 succession; Ch.5 escalation triggers; Const. Art.4, Art.15, Art.19; App. E; stress-test F-11]** |
| **3. Problem discovered** | No provision exists for apex absence, long-term incapacity, resignation, removal, death, conflict of interest, loss of trust or organisational crisis. A sudden vacancy would freeze mandates, spokesmanship and every unresolved register item simultaneously |
| **4. New safeguard** | Eight scenario definitions (S1–S8) with interim authority, time limits, permitted and prohibited decisions and confirmation routes; an apex deputy built from the existing sub-role machinery; a written Interim Authority Order held in dual custody; a seven-item reserved-matters list; access, financial and data continuity requirements (dual custody, break-glass with review, two-or-more signatories, an extra confirmer for reserve release during a vacancy, an always-named data officer); a selection mechanism with published criteria naming no person; an emergency decision rule; a continuity-during-dispute rule; a master handover checklist; and an annual unannounced continuity test |
| **5. Reason** | The organisation must not collapse because one person becomes unavailable — and must not be captured because one person did |
| **6. Operational effect** | Operations, payment, safety response and service continue through any apex vacancy by rule rather than improvisation |
| **7. Governance effect** | Interim authority is time-limited, scope-limited, recorded, audited and reported; reserved matters cannot be taken by anyone acting temporarily |
| **8. Technology effect** | A credential inventory; dual custody; an emergency-access procedure with logging; delegation end dates **[S: Ch.22]** |
| **9. Cost / capacity implication** | Low to moderate; one sealed document and one annual exercise |
| **10. New risk introduced** | An interim authority could entrench itself; a Council exercising oversight could become an unaccountable body; the continuity test could become theatre. **Mitigations:** hard time limits; reserved matters; Audit & Ethics review of every interim period; a summary report to members **[S: Ch.24]**; the test is unannounced and its findings are published internally |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL`. **No successor is named, ranked or implied anywhere** |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — entity succession law, banking mandates, removal mechanisms, Krytos governing documents |
| *Merge target* | Constitution Article 23; new Chapter 26A |

## A-15 · Institutional Memory System

| Field | Content |
|---|---|
| **1. Amendment ID** | A-15 |
| **2. Existing architecture reference** | **[S: Const. Art.18 versioned amendments; Ch.27 audit records; Ch.24 correction logs; Ch.15 include failures in reports; Ch.33 decision register; Ch.39 record templates; App. C data dictionary; App. G self-audit; stress-test F-11, F-14]** |
| **3. Problem discovered** | The architecture records *state* but not *reasoning*. A rule whose reason is forgotten will be deleted by the first person who finds it inconvenient, and the failure it prevented will return |
| **4. New safeguard** | Seven instruments: M1 Decision Rationale Register (with problem-addressed, options-considered and review-trigger fields); M2 versioned constitution and policy library with change reasons; M3 SOP library with change reasons; M4 institutional archive; M5 lessons register with a "did the change work" column; M6 key-person and dependency register; M7 consented oral history — plus seven memory rules (no decision without a recorded reason; no deletion of history; failures archived as successes are; corrections permanent; multilingual; inspectable by any member; owned and budgeted) |
| **5. Reason** | Continuity of *understanding*, not merely of documents, is what allows an institution to outlive its founders |
| **6. Operational effect** | One additional field per significant decision (the reason); one lessons entry per review |
| **7. Governance effect** | Any member may read the reason for any rule that binds them; Audit samples attribution quality (A-16 test 2) |
| **8. Technology effect** | Append-only registers; version control; redaction capability for personal data inside decision records |
| **9. Cost / capacity implication** | Low but real; needs a named owner, which at low scale may combine with the Editor family **[S: Ch.9, Ch.10]** |
| **10. New risk introduced** | The register becomes a formality completed after the fact; the archive accumulates personal data. **Mitigations:** a decision without an M1 entry is procedurally incomplete and challengeable **[S: Const. Art.17]**; A-17 and A-18 classification and retention apply to the archive |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — records-retention obligations, evidentiary value, archival law |
| *Merge target* | New Chapter 27A |

## A-16 · Founder versus Institution

| Field | Content |
|---|---|
| **1. Amendment ID** | A-16 |
| **2. Existing architecture reference** | **[S: Ch.4 ownership and executive rows; Const. Art.3, Art.4; Ch.24 communications; Ch.26 earned leadership; Ch.2 principle 6; stress-test F-11, F-33 and §11]** |
| **3. Problem discovered** | Nothing distinguishes the founder from the institution in public representation, decision attribution or dependence; personality synonymity is comfortable now and catastrophic later |
| **4. New safeguard** | A founder/institution distinction table; seven conditions of a healthy model (authority defined in writing; rules constrain abuse rather than initiative; leadership evolves; the mission survives change; members can raise concerns through a route that does not pass through the person complained about; governance responsibilities are defined; no individual is synonymous with the institution); four annual institutional tests (absence, attribution, dissent, successor); and six public-representation rules including no portrait display and decisions announced in the institution's name |
| **5. Reason** | Institutional durability requires that authority be written down and that dependence be measured |
| **6. Operational effect** | Decisions are announced in the organisation's name with the deciding role identified |
| **7. Governance effect** | Four tests reported annually; the dissent test treats a zero count as a warning rather than a success |
| **8. Technology effect** | Attribution sampling from the M1 register |
| **9. Cost / capacity implication** | Negligible |
| **10. New risk introduced** | Read as diminishing the founder, or as creating a governance body that obstructs. **Mitigations:** §15.5 states explicitly what it does not do; operational authority remains concentrated and fast; constraints attach only to constitutional change, money, force, data, brand, politics and personnel justice |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **12. Professional validation status** | Not required, except where it touches N17 or N19 |
| *Merge target* | New Chapter 4B |

## A-17 · Data Estate Map and Security Classification

| Field | Content |
|---|---|
| **1. Amendment ID** | A-17 |
| **2. Existing architecture reference** | **[S: Ch.12 HR record content; Ch.22 data architecture and role/vacancy fields; Ch.23 RBAC; Ch.6 upward minimisation; Ch.15 and App. F privacy rules; Ch.21 AI audit; Ch.27 audit; Ch.33 retention UNRESOLVED; SOP-22; Const. Art.6, Art.13; stress-test F-27, F-28]** |
| **3. Problem discovered** | There is no classification scheme, no category-level map carrying retention, deletion and ownership, no privacy-programme instrument set, and no QR use restriction — while the estate already includes conduct, safeguarding and beneficiary data |
| **4. New safeguard** | A four-level classification (C1 Public / C2 Internal / C3 Restricted / C4 Sealed) applied at field level with a default-upward rule; an eighteen-category estate map (D1–D18) with ten attributes each; six privacy-programme instruments (P1 field register, P2 retention and erasure schedule, P3 privacy notice, P4 DPIA triggers, P5 breach runbook, P6 processor standard); a named privacy officer; an annual privacy report and independent review; and a five-rule QR/member-identification use restriction |
| **5. Reason** | The sharpest harm available to this organisation is endangering a vulnerable person through its own records; and statutory duties are live with large penalties **[X]** |
| **6. Operational effect** | Access becomes class-based and reason-coded; retention becomes scheduled and purged; QR use becomes purpose-limited |
| **7. Governance effect** | A named accountable owner per category; Audit & Ethics reviews access patterns; the Council receives the annual privacy report |
| **8. Technology effect** | Classification metadata per field; RBAC enforcement by class; append-only access logs; purge automation; breach tooling |
| **9. Cost / capacity implication** | The largest implementation cost in this pack — but mostly policy and configuration, and unavoidable at any scale |
| **10. New risk introduced** | Over-restriction impeding legitimate operations (a Safety Lead unable to reach an emergency contact); compliance burden. **Mitigations:** role- and case-scoped access with reason codes rather than blanket denial; a documented break-glass procedure with after-the-fact review (A-20 §19.2) |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL`; retention periods `UNRESOLVED — to be set by counsel` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — all of P1–P6; fiduciary status; notification timelines; children's data; cross-border processing |
| *Merge target* | New Chapter 22A; extends App. C |

## A-18 · Data Minimisation Doctrine

| Field | Content |
|---|---|
| **1. Amendment ID** | A-18 |
| **2. Existing architecture reference** | **[S: Ch.8 step 3 privacy check and minimum-data checklist; Ch.15 "avoid unnecessary beneficiary data"; App. F "category of recipients", "personal recipient lists restricted", and ID-evidence restriction via Ch.12; Ch.22 least privilege; Const. Art.13; stress-test F-27 and M1]** |
| **3. Problem discovered** | Minimisation appears as scattered rules with no doctrine, no owner, no gate and no purge |
| **4. New safeguard** | The three-line doctrine (collect what is needed / protect what is collected / delete what is no longer needed); a four-answer necessity test applied field by field with worked applications; tier-linked collection across the participation spectrum with fresh specific consent on tier upgrade; a ten-item prohibited-collection list; a deployment minimisation gate; an annual logged purge with certificates; and an annual minimisation report |
| **5. Reason** | Technology makes collection nearly free, so organisations collect by default and discover the liability later |
| **6. Operational effect** | Fewer fields, shorter retention, tier-proportionate collection |
| **7. Governance effect** | The privacy officer approves; those who want the data do not approve it; Audit verifies purges |
| **8. Technology effect** | A field register enforced at schema level; no field deployable without a classification |
| **9. Cost / capacity implication** | Low; it reduces downstream cost substantially |
| **10. New risk introduced** | Under-collection impeding a legitimate function; the necessity test becoming a paperwork ritual. **Mitigations:** the test includes a "collect the minimum sufficient form" answer, not only "do not collect"; the register entry is one line per field |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — lawful bases; legality of each prohibited category; any statutory collection duties |
| *Merge target* | New Chapter 22B |

## A-19 · Beneficiary Privacy and Dignity Code

| Field | Content |
|---|---|
| **1. Amendment ID** | A-19 |
| **2. Existing architecture reference** | **[S: Ch.15 privacy-protective evidence, dignity in food service, no exposure of minors; Ch.24 protect privacy; App. F mask identities, avoid unnecessary documents, restricted recipient lists, minors' identities; Ch.8 privacy check; Const. Art.6; Scenarios A and B; stress-test F-27 and §10.2 dignity floor]** |
| **3. Problem discovered** | The source protects beneficiary data but does not separate *service* from *story*, so the same person holds both — and the incentive to publish is strong while the incentive to protect is diffuse |
| **4. New safeguard** | The founding rule ("we helped them" is never "we may tell their story"); an eight-function access-separation matrix carrying the structural rule that **the storytelling channel has no read access to the service channel**; a seven-point consent architecture (separate, specific, informed, reversible, recorded; sought at least a day later by a different person; never from a person in crisis or dependency; guardian consent plus the minor's own assent; absolute withdrawal; a right to remain invisible); seven dignity rules in delivery; and enforcement as serious misconduct regardless of intent |
| **5. Reason** | Dignity is the only candidate principle that cannot be weaponised against the person it protects, and it is the emotional floor of the whole proposition (stress-test §10.2) |
| **6. Operational effect** | Evidence requirements are still met — through stock, process and category records **[S: App. F]** — without exposing people |
| **7. Governance effect** | Communications cannot source stories from case records; consent is held separately and is auditable |
| **8. Technology effect** | A separate consented-story record type with no join to the case record; a publication workflow blocked without a consent reference |
| **9. Cost / capacity implication** | Low; it slows storytelling deliberately |
| **10. New risk introduced** | Fewer stories means less public evidence of impact, weakening the trust loop (stress-test §22). **Mitigation:** impact is published through verified *outcomes, counts and categories* — which **[S: Ch.15]** already prefers — and through consented stories created *with* people rather than extracted *from* cases |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — minors, survivors, medical contexts, consent validity |
| *Merge target* | New Chapter 15A; Constitution Article 24 |

## A-20 · Sensitive Incident and Safeguarding Data Model

| Field | Content |
|---|---|
| **1. Amendment ID** | A-20 |
| **2. Existing architecture reference** | **[S: Ch.12 conduct records "highly restricted"; Ch.16 incident documentation and review; Ch.23 RBAC; App. F safety incident "highly restricted"; Ch.22 `data_access_profile`; Ch.10 and Ch.22 delegation expiry; Const. Art.6, Art.17; SOP-18, SOP-22; stress-test F-27]** |
| **3. Problem discovered** | Sealing is described as a label rather than a mechanism. A record held at team level is a record held among the subject's neighbours |
| **4. New safeguard** | Case-scoped access by named individual with purpose, scope, duration and approver; pseudonymised case references with a separately held sealed identity index; a two-person rule to open a case locally; mandatory reason codes; sealed records held at City level or above, with the local minimum being a flag rather than content; append-only access logging with pattern-anomaly review; automatic expiry using existing delegation-date fields; a break-glass procedure with immediate logging, mandatory after-the-fact review and published counts; a sealed-category list; eight prohibited uses; and seven subject rights extending Const. Art.6 |
| **5. Reason** | Strict least privilege for the highest-harm category; sensitive incident information must never become ordinary team data |
| **6. Operational effect** | Local teams act on flags and escalation, not on case content |
| **7. Governance effect** | Audit & Ethics reviews access patterns; break-glass uses are published in count |
| **8. Technology effect** | Case-scoped grants; a separate identity index; reason-code enforcement; expiry automation |
| **9. Cost / capacity implication** | Moderate configuration; low ongoing |
| **10. New risk introduced** | Delay in a genuine safeguarding emergency; a local leader unable to protect someone because content is sealed. **Mitigations:** break-glass with action-first where life is at risk; the flag model still tells a leader *that* care is required; escalation routes are fast and named |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — disclosure duties, legal hold, subject rights, third-party protection |
| *Merge target* | New Chapter 22C; extends Ch.23 RBAC with the original matrix preserved |

## A-21 · AI Governance Extension

| Field | Content |
|---|---|
| **1. Amendment ID** | A-21 |
| **2. Existing architecture reference** | **[S: Ch.21 doctrine, eight-layer architecture, may/may-not lists, human reviewer; Ch.11 AI cannot appoint, reject or remove; Ch.25 AI drafts need evidence and sign-off; Ch.12 AI training; Ch.17 AI-automation category controls; SOP-21; App. C AI audit events; stress-test F-29, F-31]** |
| **3. Problem discovered** | The doctrine is right but unresourced: no risk tiers, no reviewer capacity model, no friction, no review-quality audit, no language guard |
| **4. New safeguard** | Verbatim preservation of the source doctrine and its ten prohibitions; a nine-function permitted-use map with risk tiers; a thirteen-class register of decisions reserved to human authority; and nine review-capacity rules (published tiers; Low-tier post-hoc sampling; per-reviewer daily caps with visible queues; scope reduction rather than standard reduction when queues grow; free-text reasons for high-tier decisions; a review-quality audit with triggers at near-100% approval or near-zero review time; kill-switch and rollback; enforced model and prompt versioning with source tracking; a language-fluency guard; an annual AI governance report) |
| **5. Reason** | Human-in-the-loop systems fail through throughput, not through principle |
| **6. Operational effect** | AI value is preserved at Low tier; genuine scrutiny is guaranteed where consequences are real |
| **7. Governance effect** | Audit & Ethics gains a review-quality function; AI & Data owns tiers and caps |
| **8. Technology effect** | Tier metadata; reviewer caps; queue visibility; kill-switch; versioning enforcement |
| **9. Cost / capacity implication** | Reviewer time — the cost the doctrine already implied and previously hid |
| **10. New risk introduced** | Caps create queues and delay; tiers could be set too low to avoid review. **Mitigations:** tier assignment is recorded, reviewed by Audit, and may not be changed by the team using the AI; queue visibility forces an explicit scope decision rather than a silent reduction in standard |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL`; the source doctrine is `LOCKED / APPROVED ARCHITECTURE` and is unchanged |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — wherever AI touches employment, safeguarding or regulated decisions |
| *Merge target* | New Chapter 21A |

## A-22 · AI Auditability Standard

| Field | Content |
|---|---|
| **1. Amendment ID** | A-22 |
| **2. Existing architecture reference** | **[S: Ch.21 audit layer "append-only records of prompt, output, model, sources, user, reviewer and final decision"; Ch.22 AI logs; Ch.23 auditor review of AI logs; Ch.27 AI audit domain; App. C; SOP-21; stress-test F-29]** |
| **3. Problem discovered** | A log of prompt, output and reviewer cannot distinguish genuine review from a signature. The source requirement is met formally and can be voided substantively |
| **4. New safeguard** | A seventeen-field consequential-recommendation record, of which five are the accountability fields (input context *reference* rather than copy; reviewer identity, role and authority scope; what the reviewer was shown; free-text reason on modify or reject; time spent); an eight-question audit matrix with named testers; and four retention and minimisation rules for AI logs, including classification inheritance, no training use without DPIA and human review, and a scheduled verified purge |
| **5. Reason** | Human accountability plus machine assistance — not machine accountability plus human signature |
| **6. Operational effect** | Reviewers experience slightly more friction, on consequential decisions only |
| **7. Governance effect** | Audit can test accountability from logs alone; approval-rate and review-time distributions become governance metrics |
| **8. Technology effect** | Log schema extension; append-only storage; context referencing |
| **9. Cost / capacity implication** | Low; storage is bounded by referencing rather than copying |
| **10. New risk introduced** | The log becomes a parallel personal-data estate. **Mitigation:** field 3 references context instead of copying it; field 8 classifies any embedded personal data; retention is set by counsel **[V]**, noting that applicable rules may require minimum retention of processing logs **[X]** |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **12. Professional validation status** | `REQUIRES PROFESSIONAL VALIDATION` — retention periods, evidentiary admissibility, cross-border storage |
| *Merge target* | New Chapter 21B; extends App. C |

## A-23 · Critical Decision Register and Launch Blocker Taxonomy

| Field | Content |
|---|---|
| **1. Amendment ID** | A-23 |
| **2. Existing architecture reference** | **[S: Ch.33 decision register; Ch.31 launch checklist blocker statuses; Ch.30 phase gates; Ch.28 risk register; App. G self-audit; stress-test §26]** |
| **3. Problem discovered** | This pack generates many new open decisions; without a register they become implicit assumptions, and without a blocker taxonomy everything becomes "urgent" |
| **4. New safeguard** | Chapter 33A carrying forward every v1.2 unresolved item unchanged and adding 38 new items (N1–N38) with owner, validation need and gate-based deadline; and Chapter 31A classifying items as BLOCKER (9), HIGH PRIORITY (13), IMPORTANT (11) and LATER (7) with a stated test for each class and explicit reasoning per item |
| **5. Reason** | Honesty about open questions is already a governance asset of this architecture **[S: Ch.33]**; it must survive the amendment |
| **6. Operational effect** | Each capability knows what must exist before it activates |
| **7. Governance effect** | The register is reviewed at every governance cycle; nothing closes silently |
| **8. Technology effect** | A register with status, owner, gate and validation flags |
| **9. Cost / capacity implication** | Low |
| **10. New risk introduced** | Register length becomes intimidating and items stall. **Mitigation:** gate-based deadlines tied to capabilities rather than to invented dates; §24.10 stages adoption so that only Stage 1 items are live now |
| **11. Approval status** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **12. Professional validation status** | Per item, as recorded in §22 |
| *Merge target* | New Chapters 33A and 31A |

## 24.9 Burden table — where the new obligations actually land

**[P]** The absolute rule governing this pack is that institutional hardening must not make ordinary volunteer participation impossible. Every amendment was therefore tested against one question before inclusion: *does this add a task for a person below Coordinator level?* The full 23-row × 6-column burden table is published at **§25.3** (it forms part of the §25 self-audit, answering question C-08). Its result is summarised here so that anyone reading only the amendment pack sees the trade-off:

| Layer | Amendments imposing a **new task** | Amendments imposing only a **restraint** | Amendments imposing **nothing at all** |
|---|---|---|---|
| Levels 0–2 (observer, participant, contributor) | **0** | 3 (A-17, A-18 collect less; A-09 report and withdraw) | 20 |
| Levels 3–4 (volunteer, specialist) | **0** | 6 (A-06 no uniform/no filming; A-08 know the list; A-09 five steps; A-10 receive a cover statement; A-19 no photos of recipients) | 17 |
| Level 5 Verified Member, **no role** | **0** | 4 | 19 |
| Coordinator / Sub-Role | 6 (A-02 declaration; A-04 script and escalation; A-15 one reason line; A-19 consent routing; A-20 grants; A-06 identification rules) | 5 | 12 |
| Primary role-holder | 11 | 4 | 8 |
| National / Council | 18 | 0 | 5 |

**[A] Headline result: 17 of 23 amendments place zero new obligation of any kind on a member below Coordinator level, and no amendment anywhere in this pack places a new *task* on Levels 0–4.** The six amendments that touch them impose restraints (things not to do), not duties (things to do). Every administrative task lands on a role-holder or a national function, which is where the architecture already places responsibility **[S: Ch.9, Ch.10]**.

## 24.10 Adoption sequencing (addressing amendment fatigue — see §25.1 C-06)

**[A]** Twenty-three amendments presented at once will not be adopted. **[P]** Three stages:

| Stage | Amendments | Trigger |
|---|---|---|
| **Stage 1 — before any public activity** | A-01, A-04, A-06, A-07, A-08, A-10, A-11, A-17 (P1, P3, P5 and the privacy officer), A-18 §17.4, A-19 | Immediately — these are the §23.2 blockers |
| **Stage 2 — before the second team or first significant volume** | A-02, A-03, A-05, A-09, A-17 (P2, P4, P6 and the QR rule), A-18 (gate and tier-linking), A-20, A-21 | On first city formation, or on the first 100 personal records |
| **Stage 3 — before multi-state or national scale** | A-12 (adopt as an analytical annex), A-13, A-14, A-15, A-16, A-22, A-23 | On the decision to expand beyond one state |

---

# 25. CONTRADICTION AND CONSISTENCY AUDIT (second adversarial review)

**Method [A]:** each of the eleven questions in your brief was asked against the *drafted text of this pack*, not against the intention behind it. Findings are recorded whether or not they are flattering. Resolutions are themselves marked **[P]**, and residual risks are marked **[A]** because they are judgements, not facts.

## 25.1 Findings

### C-01 · Did political neutrality become political control?
**Finding: YES — partially, in draft. Conflict found and resolved.**
A-02's disclosure duty and A-01's enforcement power concentrate interpretive authority in whoever decides what counts as "partisan". Without a guard, a leader could classify a rival's ordinary civic activity as political and remove them, and the code would supply the paperwork.
**Resolution [P]:** four guards were added at §3.2 B.5 — an absolute prohibition on belief screening (N8: no question, test, inference or record about what a member *believes*, ever); written reasons with appeal rights under **[S: Const. Art.17]**; symmetric enforcement audited across political lines; and independent review for any case at City level or above. The civic/partisan boundary (§3.1 A.4) is written as a table rather than left to judgement, and the newspaper-headline test is objective enough to be argued about in public.
**Residual risk [A]:** interpretation abuse remains possible. The real defence is the published refusal and enforcement log — enforcement *patterns* are auditable even where individual decisions are contestable.

### C-02 · Did protection rules make legitimate emergency assistance impossible?
**Finding: YES — in one draft formulation. Conflict found and resolved.**
The do-not-attend list (§8.4) originally read as prohibiting *attendance* at communal tension, crowds and political events. Taken literally, that would prohibit helping an injured person at such a place — contradicting **[S: Ch.16]**, under which any member may call the emergency authorities and trained members may give first aid within their training.
**Resolution [P]:** §8.4 now states explicitly that do-not-attend means **no organisational response**. Members who happen to be present act as citizens under the law: they call the authorities and may give first aid within their training. They do not attend *as a team*, in identification, or in a group. §10.5 repeats the distinction, and A-06 V13's two-responder maximum is scoped to organisational response only.
**Residual risk [A]:** members will still confuse the two under stress. This is a *training* problem: §8.4 and §10.5 must be trained together, in scenario form, not merely read.

### C-03 · Do the do-not-attend categories conflict with any duty to assist the authorities?
**Finding: POSSIBLE CONFLICT — flagged, not resolved.**
External sources indicate that Indian law contains both a private-person arrest power with a strict handover window and a general duty to assist a Magistrate or police officer who reasonably demands aid **[X: BNSS 2023 §§31, 40]**. A rule saying "do not attend" could, in an unusual case, sit awkwardly beside a duty to assist.
**Resolution [P]:** the pack does **not** resolve this. It records it as question L8/L10 in A-10 and as a validation item in A-06 V33, and it states the design intent: the organisation does not *organise* a response to these categories, and nothing in the pack instructs a member to disobey a lawful demand. **Any final wording must come from counsel, not from this document.**
**Residual risk [A]:** until counsel answers, a member could face a genuine conflict between organisational instruction and legal duty. That is precisely why B3 is a BLOCKER before protection training.

### C-04 · Do sealed-data controls block urgent safeguarding action?
**Finding: YES — partially, in draft. Conflict found and resolved.**
The sealed-case model (§19.2) holds content at City level and gives a Mohalla team only a flag. In a live safeguarding situation a local leader could be unable to act protectively because the content they need is sealed.
**Resolution [P]:** four mitigations — the **flag model** still tells a leader that care is required and of what kind; the **break-glass procedure** permits action first where life is at risk, with immediate logging and mandatory after-the-fact review; **case-scoped grants** allow a named local person to receive access for a defined period when a case is active in their area, using existing delegation-date fields **[S: Ch.22]**; and **escalation is fast and named** (§8.3 and A-09 §8.2).
**Residual risk [A]:** break-glass could normalise. Defence: published counts and mandatory review of every single use.

### C-05 · Does the mission lock contradict the founder's executive flexibility?
**Finding: YES — a genuine, acknowledged tension in one dimension. Not resolved.**
**[S: Ch.4]** gives the Founder/CEO broad executive flexibility within the final legal structure, and **[S: Const. Art.18]** makes the constitution amendable through a versioned process. A-13 Tier 1 deliberately makes nine foundational principles harder to change than everything else — including by the founder.
**Resolution [P]:** the tension is *presented as a decision*, not resolved: §12.6 argues both sides, §12.5 lists everything that is deliberately **not** locked (every number, weight, cadence, catalogue, process, structure and operational policy — i.e. all of Tier 2), and §12.4 states honestly what a mission lock cannot do. Item N21 leaves adoption open. **Operational authority is untouched; only constitutional change is slowed.**
**Residual risk [A]:** if the founder declines A-13, the institution has no continuity instrument binding a future holder — and that consequence is recorded in the register rather than hidden.

### C-06 · Is this pack itself a source of amendment fatigue?
**Finding: YES — structurally. Conflict found and bounded.**
Twenty-three amendments, thirty-eight new register items and forty blocker-classified requirements is more than any small team will adopt in one pass. A pack that is not adopted is worse than no pack, because it creates the appearance of governance.
**Resolution [P]:** §24.10 stages adoption into three tranches keyed to organisational triggers rather than dates, so a Stage-1 organisation carries nine amendments, not twenty-three. §23.1's classification test ensures only irreversible-harm items are blockers. §25.2 shows that 17 of 23 amendments impose nothing on Levels 0–4. And the control-budget rule from stress-test M6 is applied *to this pack itself*: any future mandatory record must be automated or paid for by retiring another.
**Residual risk [A]:** staging can become permanent deferral. Defence: each stage has an objective trigger (first city, first 100 records, decision to expand beyond one state), which is auditable.

### C-07 · Did AI governance become so restrictive that AI is unusable?
**Finding: NO — after revision. An earlier draft formulation was too restrictive.**
A literal reading of **[S: Ch.21]** (every medium and high-risk recommendation needs a named human decision) combined with per-reviewer caps could have made AI unusable for routine operations, defeating the architecture's own efficiency purpose.
**Resolution [P]:** §20.4 introduces a **Low tier that proceeds with post-hoc sampling** rather than pre-approval, reserving individual scrutiny for Medium and High. Summarisation, classification, planning assistance and pattern-surfacing sit at Low. Caps apply only where consequences are real, and when queues grow the response is an explicit **scope reduction**, never a silent reduction in standard.
**Residual risk [A]:** tier assignment is the whole game — a use mis-tiered as Low escapes scrutiny. Mitigation: tier assignment is recorded, owned by AI & Data, reviewable by Audit, and may not be changed by the team using the AI.

### C-08 · Does the control budget exceed realistic organisational capacity?
**Finding: PARTIALLY — measurable, and bounded rather than eliminated.**
The pack adds one refusal register, one declaration field, one calendar flag, eleven additional incident-form fields, one gate checklist across twelve categories and three levels, one rationale line per significant decision, one field-register line per data field, one consent record per story, one grant record per sealed access, and one seventeen-field record per consequential AI recommendation.
**Assessment [A]** (full distribution in the §25.3 burden table): each of these falls on a **role-holder or a national function**, never per beneficiary and never per routine task. Against the compliance-hour concern in stress-test F-05, this pack adds a fixed national/city overhead plus a small per-incident and per-decision cost — not a per-activity cost. At a single Mohalla team in Starter state **[S: Ch.12]** even that overhead is real, which is why Stage 1 is nine amendments and why A-17's largest item (the field register) is a one-time configuration task.
**Resolution [P]:** three bounding rules — the control-budget rule; all numeric intervals left `PROPOSED — requires approval` so pilot evidence sets them; and Low-category incident documentation reduced to a single short record, with the full field set triggered only at High or Emergency.

### C-09 · Did any safeguard accidentally become a final decision?
**Finding: TWO instances caught in review and corrected; one standing control adopted.**
1. An early draft of §9.2 stated that the organisation **will** provide legal-defence funding for members acting within doctrine. That is an entitlement this document cannot create — it depends on entity form, worker classification, cover and counsel. **Corrected** to §9.3 stage 2: support "as determined by counsel and by the approval matrix **[S: App. E]**", with **[V]** marking and an explicit note that the protocol defines the *process*, not the *entitlement*.
2. An early draft of §16.2 stated retention periods in months for several categories. **Corrected** to decision *rules* with periods left to counsel, consistent with **[S: Ch.33]** retention being UNRESOLVED and with the source's discipline of not inventing numbers.
**Standing control [P]:** every substantive statement in this pack carries a tag. Any statement found without one during adoption review is treated as a drafting error and returned, not adopted.

### C-10 · Did any safeguard centralise too much authority?
**Finding: YES — in three places. Conflicts found and bounded.**
(i) **National Legal** becomes the single decision point for political approaches (A-04) and a co-owner of the incident protocol — concentrating judgement in one function that may, at low scale, be one person or an external counsel.
(ii) The **privacy officer** approves classification and retention while Audit verifies — a two-person design, but both sit nationally.
(iii) The **proposed National Council** accumulates reserved matters (A-13), oversight of interim authority (A-14), integrity-line ownership (stress-test M10) and culture reporting — which could make a body that does not yet exist, and whose authority is UNRESOLVED **[S: Ch.33]**, the most powerful organ in the architecture by default.
**Resolution [P]:** (i) standing pre-approved refusals mean most political approaches never reach National Legal — only genuinely novel ones do, and every Legal decision is recorded with reasons and auditable. (ii) The privacy officer may not also hold operational data ownership; Audit & Ethics verifies independently **[S: Ch.27]**. (iii) The reserved-matters list is deliberately **short and specific** (seven items, §13.3); the Council's role during a vacancy is stated as *contingent on* the unresolved CEO/Council question rather than pre-empting it; and operations continue under existing delegated authority during any dispute (§13.6). **This pack does not create Council power; it declines to assume it.**
**Residual risk [A]:** if the CEO/Council question is resolved *after* these amendments are adopted, the reserved-matters list may need re-cutting. Recorded as N18 and N19.

### C-11 · Did founder safeguards remove legitimate founder authority, or succession create an unaccountable mechanism?
**Finding: authority — NO, with one named reduction; accountability — PARTIALLY, bounded.**
**Authority.** A-13 Tier 1 and A-14's reserved matters prevent the founder from changing a foundational principle, transferring the brand or reserves, altering the mission, or restructuring the entity **quickly, alone or privately**. Everything else — operational, financial, personnel, partnership, technology and service decisions — remains with the CEO, and **[S: Ch.4]** flexibility is untouched for Tier 2, which is every number, weight, cadence, catalogue, process and structure in the architecture (§12.5). Ownership under **[S: Const. Art.3]** is not reduced, and A-12 takes no decision at all.
**Accountability.** An Acting CEO with emergency powers, plus a Council whose authority is unresolved, plus a sealed Interim Authority Order, is a structure that could operate without effective challenge during precisely the period when challenge is hardest.
**Resolution [P]:** hard time limits on every scenario S1–S8; a seven-item reserved-matters list that no interim authority may touch; Audit & Ethics review of every interim period; a summary report to members at the next reporting cycle **[S: Ch.24]**; dual custody plus break-glass with mandatory after-the-fact review; the continuity-during-dispute rule (§13.6); and an annual unannounced continuity test whose findings are published internally (§13.8).
**Residual risk [A]:** in scenario S5 (death), the entity's own succession law and Krytos's governing documents operate in parallel and outside this architecture **[V]**. That is an honest limit, recorded at N17.

## 25.2 Did any rule contradict v1.2? (verification table)

| Apparent tension | Examination | Outcome |
|---|---|---|
| A-06 V1–V3 (no uniform, no insignia) versus **[S: Ch.31 checklist "ID card" and Ch.33 QR card CONCEPT APPROVED]** | The source already requires "non-police visual design" and minimal data. V4 adds that identification is *carried, not worn* | **Compatible** — A-06 generalises an existing constraint; the card concept is preserved and its *use* is restricted (A-17 §16.4) |
| A-03 E1–E2 (defer mass events and distribution) versus **[S: Ch.2 mission; Ch.15 service engine]** | E2 explicitly preserves committed service and household-level help; E9 provides an emergency exception with dual authorisation and published reasons | **Compatible** — restraint is scoped to *mass public* activity near elections, not to help |
| A-08 entrenchment (no local reinterpretation) versus **[S: Ch.13 local autonomy]** | Autonomy in v1.2 is expressly conditional on mission, safety, law and central standards **[S: Ch.13]**; the DO-NOT list is a central safety standard | **Compatible** — entrenchment removes interpretation of a *standard*, which was never within local autonomy |
| A-13 Tier-1 lock versus **[S: Ch.4 "broad executive flexibility within the final legal structure"]** | A real tension, in one dimension only: constitutional change | **Acknowledged, not resolved** — presented as a decision at §12.6 with both sides argued; recorded as N21 (see C-05) |
| A-08 items 8–10 versus **[S: Ch.16 permission to intervene where reasonably necessary]** | The source permission is preserved verbatim; the new items prohibit *weapons*, *patrolling* and *filming victims*, none of which the source permission authorises | **Compatible** — but the distinction must be trained explicitly (§7.2 item 3) |
| A-21 Low-tier sampling versus **[S: Ch.21 human reviewer requirement]** | The source requirement attaches to medium and high-risk recommendations; Low-tier uses are those the source already treats as assistive | **Compatible** — no source prohibition is weakened; all ten prohibitions are reproduced verbatim |

Also verified: the protection intervention language matches **[S: Ch.16]** word for word ("physical intervention only when reasonably necessary to protect someone from immediate harm and within applicable law"); the AI prohibitions are reproduced verbatim; the financial waterfall and its priority order are untouched by any amendment; RBAC and the App. E approval matrix are extended, never overridden; and the source's five status labels plus this pack's six evidence tags are used consistently throughout.

## 25.3 Burden table — what each amendment costs an ordinary volunteer (answers C-08 and tests the absolute rule)

| Amendment | Levels 0–2 (observer / participant / contributor) | Levels 3–4 (volunteer / specialist) | Level 5 member, no role | Coordinator / Sub-Role | Primary role-holder | National / Council |
|---|---|---|---|---|---|---|
| A-01 Political neutrality | None | None | None | None | Do not use role or assets partisanly | Own and enforce |
| A-02 Member political activity | None | None | None | Declaration only on taking party office or candidacy | Declaration plus recusal | Declaration plus publication |
| A-03 Election protocol | None | None | None | Observe the event and comms pause | Observe; no local exceptions | Authorise exceptions |
| A-04 Approach workflow | None | None | None | Use the script; escalate | Use the script; escalate | Decide and log |
| A-05 Non-alignment | None | None | None | None | None | Monitor patterns |
| A-06 Visibility protocol | None | No uniform; no filming | Same | Same, plus task-scoped identification rules | Enforce; complete visibility fields | Own the protocol |
| A-07 Public statement | None (they *receive* it) | None | None | None | Hand it out | Approve and publish |
| A-08 DO-NOT list | None | Know the list | Know the list | Know the list | Know and enforce | Entrench |
| A-09 Incident protocol | Report and withdraw | Steps 1, 3, 4, 5, 9 | Same | Plus step 6 if certified | Authorise, review, document | Set the criteria |
| A-10 Liability | None | Receive a cover statement | None | None | Receive a cover statement; know the number | Obtain the answers |
| A-11 Activation gate | None | None | None | None | Cannot hold restricted safety tasks before the gate | Run the gate |
| A-12 Analysis | None | None | None | None | None | Read it |
| A-13 Mission lock | None | None | None | None | None | Operate the process |
| A-14 Succession | None | None | None | None | Participate in handover | Hold and test |
| A-15 Memory | None | None | None | One reason line per decision they make | One reason line | Own the registers |
| A-16 Founder / institution | None | None | None | None | Announce decisions in the organisation's name | Run the four tests |
| A-17 Data estate | Less data collected about them | Less data collected | Access to own record | Access by class plus reason code | Own the category | Name the officer |
| A-18 Minimisation | Fewer questions asked | Fewer questions asked | None | None | None | Approve fields |
| A-19 Beneficiary dignity | None | No photos of recipients; no names | Same | Same | Seek consent separately, later, via another person | Enforce |
| A-20 Sealed data | None | None | None | Grants and reason codes | Hold flags, not content | Audit access |
| A-21 AI governance | None | None | None | None | Review within tier and cap | Set tiers and caps |
| A-22 AI auditability | None | None | None | None | Write a free-text reason on consequential decisions | Audit quality |
| A-23 Registers | None | None | None | None | None | Maintain |

**[A] Result: 17 of 23 amendments impose literally nothing on Levels 0–4.** The remaining six impose *restraints* — no uniform, no filming, no photographing recipients, report-and-withdraw at high-risk incidents, fewer questions asked — rather than tasks. Every *task* in this pack lands on a role-holder or a national function. That distribution is deliberate, and it is the direct answer to the absolute rule in your brief: strong enough to resist abuse, without becoming a machine that ordinary people cannot use.

---

# 26. FINAL RECOMMENDATIONS

## 26.1 The ten actions, in order

| # | Action | Amendment | Gate | Why it sits here |
|---|---|---|---|---|
| **1** | **Commission the legal-structure decision**, and in the same instruction the tax and worker-classification questions | Carried **[S: Ch.33]** plus A-10 | Phase 0 exit **[S: Ch.30]** | Every other answer depends on it; it is already your own Phase 0 blocker |
| **2** | **Adopt the Political Neutrality Code** — Part A prohibitions, the civic/partisan boundary, the refusal script and the register — and commission the §3.1 A.3 legal questions | A-01, A-04 | Before the first public activity | Irreversible risk; cheapest to adopt now; the first approach will arrive earlier than expected |
| **3** | **Commission written answers to L1–L15** and adopt the coverage-confirmation rule | A-10 | Before any protection activity or publicity | Cannot be retro-fitted after an incident |
| **4** | **Approve and publish the Public Protection Statement and the DO-NOT list**, in every operating language, simultaneously | A-07, A-08 | With action 3 | Publication is what converts internal doctrine into public protection |
| **5** | **Adopt the Visibility Protocol and the Incident Protocol; run the Activation Gate at national level** | A-06, A-09, A-11 | Before appointing any Safety Lead to restricted tasks | Prevents the capability activating as a side-effect of a vacancy |
| **6** | **Appoint a privacy officer; adopt classification (P1), the prohibited-collection list, the privacy notice (P3) and the breach runbook (P5)** | A-17, A-18 | Before the first 1,000 personal records | Retrofitting classification and retention onto existing data is often impossible |
| **7** | **Adopt the Beneficiary Privacy and Dignity Code and the sealed-case model** | A-19, A-20 | Before the first published story and the first incident record | The first precedent set is the one that persists |
| **8** | **Decide the CEO/Council question and the reserved-matters list; adopt the Mission Lock and the Succession Architecture** | A-13, A-14, N18, N19 | Before constituting the Council; before national expansion | Cheap now, expensive later, impossible after a succession event |
| **9** | **Stand up the Decision Rationale Register and the Lessons Register** | A-15 | Before the second city | Reasons must be captured while the deciders are still present |
| **10** | **Adopt AI risk tiers, review caps and the auditability field set** | A-21, A-22 | Before deploying any Medium or High-tier AI use | Fields cannot be retro-fitted onto past logs |

## 26.2 What NOT to do, even though this pack makes it possible

**[P]**
1. **Do not build the platform first.** Nine of the fifteen Stage-1 and Stage-2 items are policy, script, register and notice — deliverable on paper this month, with no software.
2. **Do not adopt all 23 amendments at once.** Use the §24.10 staging. An amendment nobody implements is worse than one not yet made, because it creates the appearance of governance.
3. **Do not publish the neutrality code as a legal claim.** Publish it as organisational policy; let counsel's conclusions stay internal until they exist.
4. **Do not use the political-neutrality instruments to settle internal disputes.** The symmetry audit (§3.2 B.5) exists precisely because that is the most likely abuse.
5. **Do not extend the sealed-data model downward into ordinary operations.** Sealing is for C4. Applied to C2 it becomes the bureaucracy the stress test warned about.
6. **Do not treat the Activation Gate as a one-time formality.** Lapse must suspend capability; a gate that never fails is a form, not a control.
7. **Do not soften the DO-NOT list to make recruitment easier.** It is the reason the organisation can be trusted with a protective role at all.
8. **Do not adopt the mission lock without the usability conditions in §12.6** — a short reserved list, defined timelines, and an operations-continue rule. A lock that paralyses will be broken, and breaking it discredits every other rule.
9. **Do not let the burden table drift.** If a future amendment adds a task at Level 3 or below, it must retire one (control-budget rule).
10. **Do not read this pack as legal advice.** It is a set of questions, drafts and proposals for a founder and their professionals — nothing in it is a conclusion of law **[V]**.

## 26.3 What this pack achieves against your five objectives

| Objective | How this pack serves it | What it deliberately does not do |
|---|---|---|
| **Strong enough to resist abuse** | An entrenched DO-NOT list; sealed data with case-scoped access; segregation of duties extended to power itself; refusal registers; a symmetric-enforcement audit; break-glass with published counts | Does not add surveillance of members; prohibits belief screening absolutely |
| **Flexible enough to serve people** | The E9 emergency exception; citizen-conduct preservation (§10.5); do-not-attend meaning no *organisational* response rather than no help; Low-tier AI proceeding with sampling; Tier 2 carrying all operational flexibility | Does not permit flexibility in the ten DO-NOTs, the waterfall priority order, or the dignity rules |
| **Transparent enough to earn trust** | Published refusals; a published cover statement; published incident counts; published corrections; a published privacy report; a published AI governance report; inspectable decision reasons; published external complaint routes | Does not publish identities, case content, or anything that exposes a person helped |
| **Stable enough to survive leadership change** | Eight succession scenarios; an Interim Authority Order; reserved matters; dual custody; mandate continuity; a mission lock; institutional memory; an annual continuity test | Does not name a successor and does not reduce operational authority |
| **Safe enough to scale** | Activation gates at three levels; classification and retention; DPIA triggers; a processor standard; review-capacity governance; staged adoption | Does not attempt the scale questions — federation, sampling assurance, unit economics — which belong to a later stage |

## 26.4 Closing observation

**[A]** Every safeguard in this pack reduces to one of three moves: **make an existing rule visible to outsiders** (A-06, A-07, A-08, A-19, and the transparency column above), **make an existing rule survivable in time** (A-13, A-14, A-15, A-16), or **make an existing rule enforceable against the people who hold power** (A-01 to A-05, A-09 to A-12, A-17, A-18, A-20 to A-22). Not one of them adds a new value to the architecture. All of them convert values you already hold into instruments that do not depend on you continuing to hold them.

**That is the whole of institutional hardening, and it is why it must come before attraction.** A national appeal built on an unhardened institution converts every new member into a new exposure. The reverse — an institution that can prove its own honesty, protect its own people, survive its own founders, and explain itself to a stranger in ten seconds — has little to fear from scale, because scale then becomes the multiplication of something that already works.

**[P] Recommended next instrument after this pack:** the **costed Mohalla unit model** (stress-test §30.2, item 2). Institutional trustworthiness protects the organisation from its worst failures; unit viability determines whether it has any teams to protect. Both are needed, and after this pack the second is the binding constraint.

---

# ANNEXURE A — CONSISTENCY VERIFICATION AGAINST v1.2

| Check | Result |
|---|---|
| Any v1.2 chapter, article, SOP, table or rule deleted, renumbered or reworded? | **No.** All 23 amendments are additive or appendment-based |
| Any UNRESOLVED item in **[S: Ch.33]** closed or resolved? | **No.** All are carried forward unchanged (§22.1); nine further unresolved items are added (§22.2, N12–N20) |
| Any PROPOSED item converted to final without marking? | **No.** Every proposal carries `PROPOSED — REQUIRES FINAL APPROVAL`; two draft overstatements were caught and corrected (§25.1 C-09) |
| Any legal, tax, insurance or privacy conclusion asserted? | **No.** All appear as questions for professionals with **[V]**, or as cited external facts with **[X]** |
| Source terminology preserved? | **Yes** — Team Leader, HR & Verification Manager, Ground-Level Manager, Volunteer Manager, Planner, Social Media Manager, Editor, Funds Manager, Warehouse Manager, AI & Business Manager, Safety/Protection Lead, Sub-Role, Coordinator, Supporting Member, Verified Member, Mohalla / City / State / National, Starter / Growing / Full Team, Head Team, waterfall priority order, reserves, social-impact fund, autonomy readiness, vacancy statuses, RBAC legend, status labels |
| Protection doctrine altered? | **No.** The nine-step sequence, four risk tiers, decision-makers and required actions are reproduced from **[S: Ch.16]** and extended only with handover, documentation fields, an authority matrix, escalation triggers and do-not-attend categories |
| AI doctrine altered? | **No.** "AI may recommend. Humans decide.", the may/may-not lists and the human-reviewer requirement are quoted verbatim; the extensions address capacity, tiers and auditability only |
| Financial waterfall or priority order altered? | **No.** Not touched by any amendment |
| Any number invented? | **No.** Every interval, ratio, threshold and period in this pack is marked `PROPOSED — requires approval`; the only quantified statements are external citations **[X]** and one labelled **[A-assumption]** |
| Evidence standards altered? | **No.** **[S: App. F]** is cited and extended with visibility fields only |
| New obligations placed on ordinary volunteers? | **Minimal and deliberate** — see §25.3. 17 of 23 amendments impose nothing on Levels 0–4 |
| Status-labelling discipline preserved? | **Yes** — all five v1.2 labels plus the six evidence tags are used throughout |
| Any tactical instruction for violence created? | **No.** §8.7 prohibits it explicitly, and A-09 field 4 repeats the prohibition |
| Any successor named, ranked or implied? | **No** |

---

# ANNEXURE B — CONSOLIDATED [V] REGISTER (professional validation required)

Grouped by professional discipline, so a single instruction can be issued to each.

| # | Professional | Questions to put | Source item |
|---|---|---|---|
| **V1** | Corporate / entity counsel | Entity form under Krytos; political-activity restrictions attaching to that form; objects clauses; protective provisions; dissolution and restructuring | §3.1 A.3; §12.4; **[S: Const. Art.19; Ch.33]** |
| **V2** | Tax counsel | 12A/80G conditions and the effect of any political activity; donation and deduction treatment; FCRA eligibility and timing; classification of member payments | §3.1 A.3; A-01; **[S: Ch.33]** |
| **V3** | Employment / labour counsel | Worker classification; lawfulness of role-attached political restrictions; enforceability of conduct and role-suspension rules | A-02; **[S: Ch.33]** |
| **V4** | Insurance broker | Every row L1–L7 and L14; whether any cover exists for volunteer first-response activity, member injury, third-party injury, legal defence, cyber and trustee liability | A-10 §9.1 |
| **V5** | Criminal / regulatory counsel | The intervention boundary (L8); Good-Samaritan and first-aid protections (L9); mandatory reporting duties (L10); the duty-to-assist question (C-03); arrest and handover powers | A-06 V33; A-09; A-10 |
| **V6** | Privacy counsel / DPO | All of P1–P6; fiduciary status; notification timelines; children's data; retention periods; cross-border processing; AI log retention | A-17; A-18; A-20; A-22 |
| **V7** | Safeguarding specialist | Certified training standards; the two-adult rule; reporting protocols; mental-health and disability context (V40); survivor and minor consent validity | A-09; A-19; A-11 category 11 |
| **V8** | IP counsel | Brand ownership and licensing; ownership of architecture, SOPs, curricula, software and data models | N12; N13 |
| **V9** | Governance / company secretary | CEO versus Council authority; reserved matters; dispute resolution; removal mechanisms; Krytos governing documents | N19; A-13; A-14 |
| **V10** | Banking / finance | Mandate continuity; minimum signatories; custody instruments for reserves and the restricted social-impact fund | N15; N16 |
| **V11** | Communications / advertising counsel | Public Protection Statement wording; representations and duty of care; per-language terminology review | A-06 V11; A-07 |
| **V12** | Records / archival specialist | Retention obligations; evidentiary value; archival law for the institutional archive | A-15; A-22 |

---

# ANNEXURE C — EXTERNAL SOURCES CITED ([X])

Cited only where an external constraint is referenced. **No legal conclusion is drawn from any of them in this document; each requires confirmation by a qualified professional for the actual entity, activity and jurisdiction [V].**

1. **DPDP Act 2023 and DPDP Rules 2025 (India)** — breach notification to the Data Protection Board without delay and a detailed report within 72 hours; notification of affected data principals in plain language; prescribed security safeguards; Significant Data Fiduciary obligations (India-based data protection officer, data protection impact assessment, independent data auditor, annual assessment and reporting of significant gaps to the Board); privacy notice available in English or any of the 22 Eighth Schedule languages; time-bound grievance redressal; consent standards; children's-data rules; substantial financial penalties; separate CERT-In incident reporting within 6 hours under IT Act directions. *(ey.com; ssrana.in; complyzero.com; lexology.com)*
2. **Indian not-for-profit forms and tax treatment** — trust, society and Section 8 company compared on founders, credibility, compliance burden, liability and amendability; 12A exemption and its conditions, including application of income to charitable purposes and the prohibition on political activity or support to any party or candidate; 80G donor deduction and cash-donation limits; FCRA generally requiring a multi-year track record and a dedicated account before foreign contribution may lawfully be received. *(incorpx.io; legalsuvidha.com; taxaj.com; ebizfiling.com; setindiabiz.com)*
3. **Bharatiya Nagarik Suraksha Sanhita, 2023** — private-person arrest power with a strict handover window, and the general duty of the public to assist a Magistrate or police officer who reasonably demands aid. Cited **only** to establish that the protection boundary requires legal review (A-10 L8; A-06 V33; §25.1 C-03). **No operational instruction is derived from it.** *(indiacode.nic.in; legalserviceindia.com)*
4. **Volunteer attrition and retention research** — referenced here only where A-02 and A-15 touch retention: leading stated departure reasons include relocation, busyness, cliques and exclusion, unsupportive leadership and unclear time expectations; first-year retention is weakest; recognition is associated with materially lower turnover; exit and stay interviews are the highest-rated interventions; training alone did not improve retention in one sample. *(PMC10078732; nvfc.org; naturalhazards.com.au; scholarworks.indianapolis.iu.edu; givebutter.com)* — **non-Indian or single-programme studies, used for human regularities rather than Indian magnitudes.**
5. **India Stack scale** — cited in the stress test for the platform-feasibility argument and referenced here only at A-17 (identity, verification and payment rails implying an ecosystem of processors requiring P6 contracts). *(Wikipedia India Stack; economic survey citations)*

---

# ANNEXURE D — WHAT THIS PACK DID NOT ADDRESS (scope honesty)

This pack is deliberately incomplete. The following stress-test items were **not** addressed here and remain open:

| Not addressed | Where it lives | Why deferred |
|---|---|---|
| Participation spectrum (Levels 0–4) | Stress-test M1 and §9 | An adoption change, not a survival change — though A-17 and A-18 already assume it, so it should be decided next |
| Cold-start float and anchored revenue | Stress-test M5, F-06 | Financial rather than institutional; needs the entity decision first |
| Compliance-hour measurement and Pilot Fidelity | Stress-test M6, F-05 | Requires pilot data |
| Cohort normalisation and two-speed scoring | Stress-test M8, F-19, F-20 | A performance-system change; must precede the first leaderboard but is not a survival item today |
| Horizontal competence ladder and credential issuance | Stress-test M9, F-24 | A retention instrument; Stage 2–3 |
| Integrity Line and ombuds | Stress-test M10, F-21 | Referenced repeatedly here (A-16 §15.2 item 5; A-20; H7) and **should be adopted alongside Stage 1**, but its full design sits in the stress test |
| Language architecture | Stress-test M17 and §13 | Only the rule for legally significant documents is included here (H10) |
| Mission firewalls: service floor and capacity ceiling | Stress-test M14, F-17 | Business/service balance belongs to a separate upgrade stage |
| Team Recognition Gate and sponsor liability | Stress-test M13, F-25 | A growth-governance item; A-11 covers the protection-specific case only |
| Cross-subsidy policy and footprint map | Stress-test M15, F-18 | Financial and geographic; needs unit economics first |
| Costed Mohalla unit model | Stress-test §30.2 item 2 | **Recommended as the next instrument** (§26.4) |
| Federation and public-interest governance beyond national scale | Stress-test §5 Scenario D and §26 | A later-stage structural question (L7) |

**[A]** Stating this explicitly follows the discipline the architecture already practises **[S: Ch.33; App. G]**: a document that lists what it did not do is more trustworthy than one that implies completeness.

---

*End of v1.3-A. Institutional hardening pass. No element of v1.2 was removed, renumbered or silently altered. Every proposal is marked `PROPOSED` and requires approval by the Founder/CEO under **[S: Const. Art.18]**, and professional validation wherever marked **[V]**.*
