# SEWAK SATHI SANSTHA v1.3-B
# COSTED MOHALLA UNIT ECONOMICS & ECONOMIC SURVIVAL MODEL

| | |
|---|---|
| **Instrument** | v1.3-B — second major v1.3 instrument, following v1.3-A (Institutional Survival & Legitimacy Amendment) |
| **Question answered** | **Can the smallest real operating unit — one Mohalla Team — survive economically and operationally?** |
| **Direction of modelling** | ONE MOHALLA → CITY → STATE → NATIONAL. The national picture in §31 is *derived from* the unit, never assumed onto it |
| **Base architecture** | `KRYTOS_SEWAK_SATHI_SANSTHA_VISUAL_MASTER_ARCHITECTURE_CONSTITUTION_LAUNCH_SPECIFICATION_v1_2.pdf` (179 pp.), including Appendix A preservation of the v1.1 source (81 pp.) |
| **Analytical sources** | `Sewak_Sathi_Strategic_Stress_Test.md` (36 failure modes F-01…F-36; Scenarios A–F; §24 component results; §25 M/R/K items) and `Sewak_Sathi_Sanstha_v1_3_A_Institutional_Survival_and_Legitimacy_Amendment.md` (A-01…A-23; §25.3 burden table) |
| **Scope** | Unit economics, cost structure, revenue mechanics, solvency, governance burden, reserves, cross-subsidy, scaling cost, pilot design and economic controls |
| **Explicitly out of scope** | Any change to hierarchy, roles, the waterfall priority order, performance weights, the constitution or the launch roadmap. No element of v1.2 or v1.3-A is removed, renumbered or silently rewritten |
| **Document status** | **MODEL — PROPOSED.** No figure in this document is organisational policy, a budget, a forecast or a promise. Every quantity is either extracted from source, derived by stated formula, or presented as a named variable requiring a value from the pilot |
| **Prepared** | 4 October 2026 |

---

## HOW TO READ THIS MODEL

### Number classification (mandatory for every quantity in this document)

Your brief requires that every number be classified. Six classes are used, and each is tagged at the point of use:

| Tag | Class | Meaning |
|---|---|---|
| **[S]** | **SOURCE-DERIVED** | Stated in v1.2 or the preserved v1.1 source. Cited by chapter, article, SOP or appendix. Quoted where the wording matters |
| **[C]** | **CALCULATED** | Derived by an explicit formula shown in this document from other classified quantities. Reproducible; no judgement embedded |
| **[M]** | **MODEL ASSUMPTION** | A value or relationship this model needs in order to run at all, which does not exist in the source. **Always** written as a named variable, a range to be measured, or a scenario branch — never as a single asserted fact. Where a bare illustrative value is used to make arithmetic visible, it is additionally marked **[M-ill]** and must be replaced by pilot measurement |
| **[SC]** | **SCENARIO** | A labelled branch of the model. **A scenario is not a forecast.** No scenario in this document predicts what will happen |
| **[P]** | **PROPOSAL** | Recommended here. Not architecture. Requires approval before it binds anyone |
| **[V]** | **REQUIRES VALIDATION** | Legal, tax, employment, insurance, accounting, statutory or regulatory advice required before reliance |
| **[X]** | **EXTERNAL FACT** | Published source outside your documents, cited in Annexure D |

### The five source facts that govern everything below

These are not interpretations. They are statements in your own documents, and the entire model is built around them.

**FACT 1 — The economic blueprint this model needs was never supplied.** **[S: Appendix A §1.1]**

> "It also references the *Zero-Capital Local Venture Ecosystem — Master Architecture and Implementation Blueprint, Working Draft v1.0*. **The full separate blueprint file was not attached in this task**; therefore this specification preserves the blueprint principles as they appear inside the attached PDF and the founder's present instructions."

**Consequence [A]:** v1.2 and v1.1 contain the *governance* of ventures — a 14-step lifecycle, seven categories, controls, QA, closure rules — and **no economic content at all**: no prices, no margins, no cost lines, no volumes, no market sizes, no revenue figures of any kind. Everything quantitative in this document must therefore be a variable, a formula or a scenario. This is not a limitation of the analysis; it is the honest state of the source.

**FACT 2 — The only percentages in the entire architecture are explicitly illustrative.** **[S: Ch.18; Appendix A §14.4]**

> "ILLUSTRATIVE WORKING EXAMPLE — NOT FINAL POLICY: The source PDF states that the supplied blueprint includes illustrative figures such as **37.5% worker compensation, 17% direct delivery costs and 12% organisation service fee** and other allocations. **This specification does not adopt those as final Sewak Sathi Sanstha percentages.** Final percentages, caps, multipliers and calculations require founder approval and professional validation."

And: **"THE PRIORITY ORDER IS THE CONTROL; PERCENTAGES ARE A PLANNING TOOL."** **[S: Ch.18; Appendix A §14.1]**

**Handling in this document:** those three figures are used *only* where explicitly marked **[M-ill]**, always as a sensitivity branch, always with the warning attached, and never converted into a constitutional percentage. The model runs symbolically without them.

**FACT 3 — Almost every financial parameter is formally unresolved.** **[S: Ch.33]**

| Decision | Status in v1.2 |
|---|---|
| Weekly revenue percentages | **NOT FINAL** — "use priority waterfall; set percentages after economic/legal/tax validation" |
| Leader multiplier | **NOT FINAL** — "higher allocation within same framework; define transparently" |
| Worker classification | **UNRESOLVED** — employee / contractor / volunteer / stipend / business participant |
| Social-impact formula | **NOT FINAL** |
| Reserve release rules | **NOT FINAL** |
| Venture categories | **POTENTIAL** — "approve categories one by one" |
| Minimum staffing thresholds | **NOT FINAL** — "define by level/risk after pilots; **no final numbers invented**" |
| Team readiness threshold | **NOT FINAL** |
| Legal structure / insurance / partnerships | **UNRESOLVED / PROPOSED** |

**Consequence [A]:** the source itself forbids inventing these numbers, and states the reason — they must come *after* economic, legal and tax validation and *after* pilots. This model therefore produces **the formulas that will consume the pilot's measurements**, not the measurements.

**FACT 4 — The waterfall is the cost-allocation engine, and it is a *priority order*, not a budget.** **[S: Ch.18; Appendix A §14.2]**

The eight priorities, in the source's own order: **1. Worker compensation → 2. Statutory dues where applicable → 3. Direct business/delivery costs → 4. Founder compensation / approved cap → 5. Organisation service fee → 6. Reserves / wage-protection buffer → 7. Social-impact contribution when conditions are met → 8. Residual surplus / founder upside.**

Three structural consequences are derived in §8 and drive the whole model:

- **Worker compensation is a first charge on *venture revenue*, not on the organisation's income generally [C].** There is no revenue line for service work, governance work or infrastructure work — therefore the waterfall cannot fund them.
- **Reserves sit at priority 6 [S]** — downstream of the revenue instability they exist to absorb. A new team has no wage-protection buffer during exactly the months it needs one (stress-test F-06).
- **The organisation service fee sits at priority 5 [S]** — the City/State/National layer is funded only after a venture has paid its workers, dues, direct costs and founder cap. At team formation, the central layer's income from that team is zero.

**FACT 5 — The architecture already tells you when to stop.** **[S: Appendix A §14.5]**

> "This does not mean workers can be promised money that does not exist… **If a venture repeatedly cannot pay workers lawfully and sustainably, it must be restructured, paused or closed.**"

This is the source's own stopping rule, and §23 uses it rather than inventing one.

### Two standing separations, carried forward from v1.3-A

1. **ORGANISATIONAL POLICY vs. LEGAL / TAX / ACCOUNTING REQUIREMENT.** A rule such as *"worker compensation is paid before the organisation service fee"* is organisational policy. A statement such as *"this payment is a taxable wage and must be reported"* is a legal/tax question **[V]**. They are never merged here.
2. **MODEL OUTPUT vs. DECISION.** This document computes consequences. It does not take decisions. Every point at which a decision is required is routed to §43 (Economic Decision Register) or to the v1.3-A register, and nothing is closed silently.

### The variable system

Because no financial quantity exists in the source, the model is written algebraically. Every variable is defined once in **Annexure A** and used consistently throughout. A short orientation:

| Family | Examples | Meaning |
|---|---|---|
| `N…` | `N_act`, `N_roles`, `N_ver`, `N_paid` | People counts |
| `T…` | `T_avail`, `T_gov`, `T_del`, `T_acq`, `T_train` | Hours per person per month, by use |
| `h…`, `H…` | `h_proj`, `h_act`, `H_gov` | Hours per unit of work; total hours |
| `P…`, `V…` | `P_price`, `P_delivered`, `P_collected`, `V_gross` | Project counts and revenue values |
| `r…` | `r_lead`, `r_prop`, `r_close`, `r_collect`, `r_ret`, `r_act` | Rates (funnel, retention, activation) |
| `C…` | `C_var`, `C_fixed`, `C_gov`, `C_vol`, `C_acq`, `C_train` | Costs |
| `B…` | `B_bare`, `B_healthy`, `B_growth`, `B_resilient` | The four break-even lines |
| `M…` | `M_months` | Runway in months, always computed |
| `w…` | `w_worker`, `w_direct`, `w_org` | Waterfall allocation shares — **[M-ill]** only when a value is shown |

**No variable is ever assigned a value in this document without a tag.** Where arithmetic must be shown to make a mechanism visible, the values used are labelled **[M-ill]** and the same result is restated symbolically so the reader can substitute real measurements.

---

# 1. EXECUTIVE SUMMARY

## 1.1 The finding in one paragraph

**[A]** A Sewak Sathi Mohalla Team is **not a business that also does good**. Structurally, it is **a governance body that also delivers service, and may also run a venture** — and only the venture produces money. The waterfall **[S: Ch.18]** attaches worker compensation to *venture revenue*; the operating loop **[S: Ch.8]** attaches verification, privacy, decision-log, evidence and outcome duties to *every request whether or not it earns anything*; and the staffing states **[S: Ch.10]** require nine functions to exist in a Starter Team even at minimum size. The result is a unit whose **fixed governance cost is roughly constant** while its **revenue capacity varies by an order of magnitude between neighbourhoods** (stress-test F-05, F-18). Whether one Mohalla can pay for itself is therefore not a question about effort or intention. It is a question about **whether that specific neighbourhood contains enough payable demand to cover a governance load that does not shrink when the neighbourhood is poor.**

## 1.2 The verdict

> ## **D — NOT YET ECONOMICALLY VIABLE**, with a defined and testable path to **B — VIABLE WITH CONDITIONS**.

**[A]** The classification is D rather than C for one specific reason: **C ("viable only with subsidy") asserts that a subsidy would make it work, and the source contains no subsidy instrument to evaluate.** There is no cold-start float, no anchored-revenue precondition, no guaranteed minimum-hours pool, no central service budget and no cross-subsidy mechanism anywhere in v1.2 or v1.1 (stress-test F-06, M5). The organisation service fee that would fund the centre is itself at priority 5, i.e. it does not exist until a venture succeeds **[S: Ch.18]**. So the honest statement is not "it needs subsidy" but **"it needs an instrument that has not been designed, approved, costed or validated."**

**The path to B is specific, and §46 states it as six conditions.** B is reachable — the architecture's own Phase 2 is a one-team pilot **[S: Ch.30]**, the waterfall is genuinely well-designed, and the City layer already provides shared functions **[S: Ch.7]** — but only if the six conditions are met *before* the first team is formed, not after.

## 1.3 What allows one team to survive six months — and what kills it

This is the question your brief asks to be answered on one page. **§46.1 contains that page.** In summary:

**What allows it to survive [A], in descending order of importance:**
1. **One anchored, contracted revenue source in place *before* launch** — not a pipeline, a signature (stress-test M5 option iii).
2. **A cash float sized by formula, not by optimism** — `Float = M_target × (C_fixed + C_gov)` (§9.6), with the term, cap and reconciliation rule defined in advance.
3. **Governance carried at City level, not Mohalla level**, using the City Funds Manager, City HR and City AI & Business Manager functions that already exist **[S: Ch.7]** (§26 minimum viable control).
4. **A payment cadence that matches revenue lumpiness** — the source's weekly cycle **[S: Ch.19]** is a *transparency* mechanism; transparency does not require weekly frequency (stress-test R2).
5. **A service programme that costs time rather than money**, so service continues at ₹0 revenue (§33).
6. **A team that was seeded, not recruited** — the first team is taught (stress-test Scenario A).

**What kills it [A], in the order the failures actually arrive:**
1. **Week 3, not month 3:** the first empty distributable week. Members who joined on a compensation expectation experience it as a broken promise (F-02, F-06).
2. **The governance load:** `H_gov` hours per month consumed by 22 SOPs, 14 evidence types, 5 reporting cadences, a 10-step loop, a 12-step service loop and a 13-step payment cycle **[S]** — hours that come out of the same small pool as delivery and sales.
3. **The three unpopular control roles** (HR/Verification, Funds, Safety) are combined into the same few people who must also deliver and sell, and they face social friction for saying no (F-03).
4. **Lumpiness meets a fixed cycle:** local SME revenue is irregular, festival-linked and collection-lagged **[I]**, while the cycle is weekly and distributable amount is computed "under approved waterfall, not gross receipts" **[S: Ch.19]**.
5. **The first incident, dispute or QA failure** consumes a week of the team's capacity and produces no revenue (§5 hidden-cost register).
6. **Then attrition of exactly the people you need** — the paid deliverers — because they have alternatives and volunteers do not (F-04, stress-test retention analysis **[X]**).

## 1.4 The ten findings that matter most

| # | Finding | Class | Where |
|---|---|---|---|
| **1** | **The economic blueprint was never attached to the source.** No price, margin, cost line or volume exists in v1.1 or v1.2. Every quantitative statement in this model is therefore a variable, formula or scenario | **[S]** | Front matter Fact 1 |
| **2** | **The waterfall funds venture work only.** Service, governance and infrastructure work have no revenue line to charge, so priority 1 cannot protect them | **[C]** | §8.4 |
| **3** | **Reserves are downstream of the instability they absorb.** Priority 6 means a new team's wage-protection buffer is zero during months 1–6 | **[S]+[C]** | §8.5, §21 |
| **4** | **The centre is funded last.** Organisation service fee at priority 5 means a Mohalla team contributes nothing to City/State/National until its venture is already healthy — so the City support the team needs in month 1 must be funded from somewhere the architecture does not name | **[S]+[A]** | §8.6, §31 |
| **5** | **Governance cost per team is roughly constant; revenue capacity per team is not.** This single asymmetry determines which neighbourhoods can ever be viable | **[A]** | §25, §31.3 |
| **6** | **Volunteer labour is not free.** It has a measurable per-retained-hour cost that rises as retention falls; at low retention a "free" volunteer can cost more per delivered hour than a paid worker | **[C]** | §15 |
| **7** | **There are four break-even lines, not one,** and they differ by a large multiple. A team can pass Bare Survival and still be unable to pay a worker, hold a reserve or fund the centre | **[C]** | §11 |
| **8** | **Capacity, not demand, is the usual first bottleneck** — but only after the governance hours are subtracted from the delivery pool. `P_max = (N_paid × (T_avail − T_gov_per_head)) / h_proj` | **[C]** | §17 |
| **9** | **Model D (volunteer service + paid venture delivery) is the only model consistent with the source,** but it is also the most fragile, because it depends on two different motivational systems surviving in one small team | **[A]** | §16 |
| **10** | **The unit becomes viable as a *City* before it becomes viable as a *Mohalla*.** Shared governance across `K` teams divides the fixed load; below a minimum `K`, per-team cost is unaffordable in any neighbourhood | **[C]** | §26, §31.2 |

## 1.5 What this document does NOT do

**[A]** Five explicit refusals, so that nothing here is mistaken for a business plan:

1. **It does not project revenue.** There is no forecast, no TAM/SAM/SOM, no growth curve and no year-one number anywhere in this document.
2. **It does not adopt the illustrative percentages.** 37.5 / 17 / 12 **[S]** appear only in labelled sensitivity branches **[M-ill]**, always beside the symbolic form.
3. **It does not replace the waterfall.** The priority order is reproduced verbatim and used as the model's engine (§8).
4. **It does not resolve any v1.2 or v1.3-A unresolved item.** Worker classification, legal structure, percentages, leader multiplier, reserve release rules, minimum staffing thresholds and insurance are all carried forward unchanged into §43.
5. **It does not recommend dissolution of an underperforming team.** §23 applies the source's own support-first philosophy **[S: Ch.14]** and its own stopping rule **[S: Appendix A §14.5]**, and does not add a harsher one.

## 1.6 How to use this document

| If you are… | Read |
|---|---|
| The founder deciding whether to launch a team | §46.1 (one page), §11 (four break-evens), §40–42 (pilot) |
| The person who must actually run the pilot | §3 (unit definition), §4 (cost stack), §13 (first six months), §26 (minimum viable control) |
| The finance professional being asked to validate | §8 (waterfall as formula), §11, §21 (reserves), §43 (register), Annexure B (formula sheet), Annexure C ([V] list) |
| The person worried this will become a bureaucracy | §25 (governance burden calculator), §26 (control budget), §34 (dignity), §36 (anti-gaming proportionality) |
| An adversary trying to break the model | §45 (final adversarial audit) — it is written against this document, not for it |

---

# 2. THE ECONOMIC QUESTION

## 2.1 The question, stated precisely

Your brief poses it as:

> *Can a Mohalla Team deliver meaningful service while maintaining the people, training, verification, technology, transport, communication, governance, business and financial infrastructure required to operate?*

**[A]** That sentence contains three separate questions which must be separated, because they have different answers and different owners.

| | Question | Unit of answer | Owner |
|---|---|---|---|
| **Q1** | **SERVICE CAPACITY** — can the team *do* the work? | Hours of verified, safe, evidenced service per month | Team Leader + Planner + Volunteer Manager |
| **Q2** | **ECONOMIC CAPACITY** — can the team *earn* against its obligations? | Distributable funds per month against the month's obligations | Funds Manager + AI & Business Manager |
| **Q3** | **GOVERNANCE CAPACITY** — can the team *prove* the work and *control* the money without consuming Q1 and Q2? | Governance hours per month as a share of available hours | HR/Verification + Funds + Safety, with City |

**[A] The critical insight:** Q1 and Q2 are usually analysed together, and Q3 is usually ignored. But **Q3 draws from the same hour pool as Q1 and Q2.** A ten-person team does not have ten people's worth of service capacity plus ten people's worth of business capacity plus ten people's worth of governance capacity. It has one pool:

> `N_act × T_avail = T_gov + T_del + T_acq + T_svc + T_train + T_idle` **[C]**

Every governance hour is an hour not delivered, not sold and not served. This is why the stress test called governance hours **"the single most important unknown in the whole model"** (F-05, ratio-assumption table) — and why §25 builds a calculator for it rather than assuming a value.

## 2.2 Why "revenue > zero" is not health

**[A]** A team with ₹1 of revenue has revenue. It has not met an obligation. Health must be tested against the *actual* obligation set, which the source defines by priority **[S: Ch.18]**:

| Obligation | Source | Can it fall to zero? |
|---|---|---|
| Worker compensation for verified work | **[S: Ch.18 priority 1; Ch.19 step 7]** | **No** — it is the first charge; and if it cannot be paid, §14.5 of the source requires restructure/pause/close |
| Statutory dues where applicable | **[S: Ch.18 priority 2; Ch.19 step 5]** | **No** — legally required; amount depends on unresolved classification **[V]** |
| Direct business/delivery costs | **[S: Ch.18 priority 3]** | Only by not delivering |
| Founder compensation / approved cap | **[S: Ch.18 priority 4]** | Yes — capped, and not applicable at Mohalla level (see §8.7) |
| Organisation service fee | **[S: Ch.18 priority 5]** | **Yes — explicitly deferrable**: "Deferrable organisational fees and social contributions fall before verified worker compensation is sacrificed" **[S: Ch.18 control table, bad-month behaviour]** |
| Reserves / wage-protection buffer | **[S: Ch.18 priority 6]** | Yes, but then there is no buffer for the next bad month |
| Social-impact contribution | **[S: Ch.18 priority 7]** | **Yes — "only when surplus conditions are met"** **[S]** |
| Residual surplus | **[S: Ch.18 priority 8]** | Yes |

**[C] Therefore the minimum definition of an economically healthy month is:**

> **All verified worker compensation paid + all statutory dues paid + all direct costs of delivered work covered + a non-zero reserve contribution + nothing deferred into a hole that next month cannot fill.**

A month that pays workers but drains the reserve to zero is **not** healthy; it is *solvent and fragile*. A month that pays workers and adds to reserve but skips the organisation fee **is** healthy under the source's own bad-month rule **[S: Ch.18]**. That distinction is used throughout §10–§13.

## 2.3 The three-capital constraint

**[A]** The unit must simultaneously hold three different kinds of capital, and they are not interchangeable:

| Capital | What it is | What depletes it | What refills it |
|---|---|---|---|
| **Financial capital** | Cash in the venture account, reserves, float | Direct costs, compensation, dues, governance overhead | Collected customer revenue |
| **Human capital** | Verified, trained, willing, available members | Attrition, burnout, promotion-out, seasonal absence | Recruitment, training, retention, recognition |
| **Legitimacy capital** | Local trust, and the institutional standing built by v1.3-A | One incident, one broken payment promise, one exposed beneficiary, one political misreading | Consistent delivery, published honesty, dignified service |

**[A] The ordering matters.** Legitimacy capital is the slowest to build and the fastest to lose; human capital is slower to rebuild than financial capital; financial capital is the only one that can be injected from outside. A team that spends legitimacy capital to save financial capital (e.g. by promising payment it cannot make — stress-test F-02, F-06) has made the worst available trade, because it has consumed the input it cannot buy.

**[I]** And there is a fourth, hidden depletion channel: **governance capital** — the willingness of the three control role-holders to keep saying no to their neighbours. Stress-test F-03 identifies this as social friction inside a small local team. It is depleted by every verification refusal, every expense rejection and every safety stop, and it is refilled only by visible backing from above (v1.3-A A-04 support duty; stress-test M10 Integrity Line).

## 2.4 The unit of analysis, and why it is not the team alone

**[A]** Your brief requires the model to be built upward from one Mohalla. But the source already places several Mohalla obligations at City level **[S: Ch.7]**:

| City responsibility **[S: Ch.7]** | Economic significance |
|---|---|
| "Help Mohalla Teams form, train, verify members, solve bottlenecks and request resources" | Training and verification cost is **shared**, not per-team |
| "**Identify customer needs, combine skills, propose ventures and coordinate delivery**" with output "customer pipeline, venture proposals, delivery records" | **Customer acquisition is a City function in the source architecture.** A Mohalla team is not expected to originate its own demand alone |
| "Allocate donated/purchased materials with approved evidence and priorities" | Inventory and materials cost is **pooled** |
| "Review Mohalla data weekly and monthly for leaderboard evidence" | Reporting is **aggregated upward**, and the review labour sits at City |
| "Support incidents too serious for Mohalla but not national" | Incident cost is **escalated**, not absorbed locally |
| City role catalogue **[S: Ch.7]** — City HR & Verification, City Funds Manager, City AI & Business Manager, City Warehouse/Logistics, City Editor, City Planner, City Safety | These are **shared service centres** already designed into the architecture |

**[C] This produces the model's central structural claim:**

> The Mohalla Team is the **delivery and legitimacy unit**. The City is the **economic unit**. A Mohalla team analysed in isolation will always look unviable, because it is being charged with functions the architecture assigns to the layer above it. Conversely, a City analysed without its Mohalla teams has no delivery capacity and no local trust.

**[P]** Therefore this document models the Mohalla team in full (§3–§29) **and** models the City divisor explicitly (§26, §31.2), and §32 answers the self-sustainability question at both levels. This is not a softening of your instruction to build from one Mohalla upward — it is what building upward reveals.

## 2.5 What would make the answer "yes"

**[A]** Stated in advance, so the model cannot be accused of moving the goalposts. The answer becomes **B — VIABLE WITH CONDITIONS** if and only if all six hold:

| # | Condition | Test | Section |
|---|---|---|---|
| **1** | Governance hours per team per month are **measured**, and the measured value is below the share of available hours that leaves delivery and sales possible | `H_gov / (N_act × T_avail) < σ_max`, with `σ_max` approved | §25, §26 |
| **2** | At least one venture category exists whose **contribution per delivered hour** exceeds the fully-loaded hourly cost of the team, in that neighbourhood | `P_collected × (P_price − C_var) / (P_delivered × h_proj) > C_all_in / H_total` | §11, §19 |
| **3** | A **cold-start instrument** exists, is approved, is capped, is time-bound and is reconciled | Float outstanding ≤ cap; term ≤ approved months; reconciliation published | §9.6, §21 |
| **4** | Governance is **shared at City level** across enough teams that per-team cost falls below the viability threshold | `K ≥ K_min` where `K_min` is derived in §31.2 | §26, §31 |
| **5** | The **payment cadence** actually used matches the collection reality, and members are told the truth about it before joining | Payment continuity rate measured; expectation disclosed in writing | §12, §34 |
| **6** | **Service can continue at ₹0 revenue** without consuming cash, because the service programme is designed in time-costed rather than money-costed categories | Month-0 service output > 0 with cash spend = 0 | §33, §38 |

**[A]** If any one of the six fails, the classification remains D — and §46 states which instrument must then be built. If conditions 1–4 hold but 5 and 6 do not, the classification is **C — VIABLE ONLY WITH SUBSIDY**, because the team would be surviving on an injection rather than on its own economics.

---

# 3. MOHALLA UNIT DEFINITION

**Rule applied:** the existing hierarchy is **not changed** — it is *read economically*. Every element below is cited to the source; the economic-behaviour column is **[A]** or **[C]**.

## 3.1 The unit as the architecture defines it

> **"Mohalla Team — Ground-level neighbourhood team responsible for direct local execution."** **[S: Ch.34 Glossary]**

Position in the chain **[S: Ch.4, Ch.5, Ch.34]**: Krytos / Founder-CEO → National Team → State Team → City Team → **Mohalla Team** → Verified Members. The Mohalla Team is the only layer whose stated purpose is *direct local execution*; every layer above it exists to coordinate, support, review or escalate.

## 3.2 Economic map of the unit

| Element | Source | What it is economically | Behaviour **[A/C]** |
|---|---|---|---|
| **Team (the Mohalla Team itself)** | **[S: Ch.8, Ch.34]** | The delivery and legitimacy unit; **not** a legal entity, not a cost centre with its own bank account unless the unresolved structure says so **[V]** | Cost is incurred here; revenue is *earned* here but *recorded* in a venture revenue account **[S: Ch.18 step 2]** whose ownership and custody are unresolved (v1.3-A N14, N15) |
| **Members (Verified Members)** | **[S: Ch.12, Ch.34]** | The labour pool. Membership is **not automatic** — "application starts a verification process" **[S: App. A §1.1]** | Each member carries acquisition + verification + training + coordination cost **before** contributing any hour (§15) |
| **Primary roles (11 role families)** | **[S: Ch.9, Ch.10]** — Team Leader, HR & Verification Manager, Ground-Level Manager, Volunteer Manager, Planner, Social Media Manager, Editor, Funds Manager, Warehouse Manager, AI & Business Manager, Safety/Protection Lead | **Fixed governance capacity.** "One role → one primary holder" **[S: Ch.10]** | A *fixed* cost of existence, not a variable cost of activity. It does not shrink when revenue is zero |
| **Sub-roles / deputies** | **[S: Ch.10]** — "a delegated operational position, not an automatic transfer of all authority… Authority must be explicit, recorded, RBAC-limited and reviewed" | **Continuity insurance**, purchased with delegation records and RBAC configuration | Cost is administrative (delegation start/end/reviewer **[S: Ch.10, Ch.22]**) and it buys survival of the unit through absence (HC-02) |
| **Coordinators** | **[S: Ch.10]** — recruitment, schedule, issue, platform, QA, documentation | **Variable governance capacity**, opened as workload justifies | The only governance layer that scales with activity — the natural place to absorb growth (§13) |
| **Supporting Members** | **[S: Ch.10]** — "assigned helpers, volunteers, trainees and project workers" | **The actual delivery and sales capacity.** Note the source places *project workers* in this category | Compensation for verified work attaches here **[S: Ch.18 priority 1]** — which is why §16 Model D is the source-consistent model |
| **Volunteers** | **[S: Ch.10 Supporting Members; Ch.15 step 7 "verified and trained members scheduled"]** | Unpaid labour with a **real cost** (§15) | Cost per delivered hour rises as retention falls; verification and conduct duties apply to volunteers identically |
| **Specialists** | **[S: Ch.6 State specialist pool — "trainers, finance reviewers, safety reviewers, logistics and business specialists… shared across cities without waiting for national deployment"]** | **Shared, escalated resource** — not a Mohalla cost line | A Mohalla team should never need to *employ* a trainer or finance reviewer; it should be able to *request* one. **The largest available cost saving in the whole model** (§26) |
| **Business contributors** | **[S: Ch.17; Ch.9 AI & Business family — Business Development, Customer Relations, Venture, AI Ops, Business QA, Revenue & Delivery Coordinators]** | Revenue-producing capacity | Scarce skill; usually the binding constraint (§17, §19) |
| **Service contributors** | **[S: Ch.15 Social Service Engine]** | Mission-producing capacity, **funded by nobody in the waterfall** (§8.4) | The core structural gap of the model |
| **Leadership** | **[S: Ch.9 Team Leader; Ch.26 dynamic leadership; Ch.19 step 8 "FINAL MULTIPLIER REQUIRES APPROVAL"]** | Decision capacity + accountability + a *promotable asset* | Promotion removes it (§24) — the architecture's own ladder can make the winning team weaker |
| **Verification** | **[S: Ch.8 step 4 "site visit, phone/partner confirmation, photos where appropriate or multiple witnesses"; Ch.12; SOP-01…SOP-04]** | A **per-request and per-member** cost that is not reducible | Scales with *requests*, not with revenue — so a poor, high-need area carries the highest verification load and the lowest income |
| **Training** | **[S: Ch.12 categories; Ch.12 boundary — "internal training is not automatically legally sufficient for first aid, emergency response, security, labour, child safeguarding, medical, counselling, legal or regulated activities"]** | Recurrent cost with a **certification floor set externally** | Where the domain is regulated the cost is neither optional nor reducible by the organisation (v1.3-A A-10 §9.5, A-11 cat. 4) |
| **Local operating area** | **[S: Ch.8 "walk-through observation, resident request"; Ch.13]** | The **demand pool** — the largest source of variance in the model | Determines payable demand, delivery distance, competition, ability to pay (§19) |
| **City relationship** | **[S: Ch.7]** | **Shared services + demand aggregation + escalation** | The economic parent of the unit (§2.4): training, verification support, customer pipeline, materials, incident support, data review |
| **State relationship** | **[S: Ch.6]** | Specialist pool, city coaching, escalation filter, state projects | Reduces per-team specialist cost; may "temporarily support or supervise a struggling City Team during improvement" **[S: Ch.6]** |
| **National relationship** | **[S: Ch.5, Ch.18, Ch.27]** | Standards, constitution, platform, reserve custody, audit capability | Holds the reserves — "National Funds Manager manages; release requires approval matrix" **[S: Ch.18]** — so the team's buffer is **not under its own control** (§21) |

## 3.3 The three staffing states, read as cost structures **[S: Ch.10]**

| | STATE A — Starter Team | STATE B — Growing Team | STATE C — Full / Autonomous Team |
|---|---|---|---|
| **Source trigger** | "New or small team; compatible roles may be combined" | "Workload, risk, member count or business volume justifies deputies" | "Mature team with completed/trusted status and sufficient work" |
| **Source structure** | "Team Leader, Sub-Leader if available, HR/Verification, Ground Operations, Volunteer Management, Planning, Finance, AI & Business and Safety; social media/editor/warehouse may be combined or city-supported" | Sub-HR, Sub-Ground, Sub-Volunteer, Sub-Planner, Sub-Funds, Sub-Business, Sub-Safety, Sub-Editor, Sub-Social Media, Sub-Warehouse "opened as vacancies where needed" | "Manager → Sub-Manager → Coordinators → Supporting Members in each major function" |
| **Source control** | "**Small size never removes safety, HR verification, finance integrity or evidence duties**" | "Vacancies must be need-based, eligibility-based and RBAC-limited" | "Autonomy remains conditional on mission, safety, law, finance, verified work, outcomes and audit" |
| **Functions that must exist** | **9 named** **[S]** | 9 + up to 10 sub-roles | 9 families × up to 4 layers |
| **Economic reading [A]** | **Fixed governance cost is at its maximum *per head* here.** Nine functions must exist; the people available are fewest; so each person holds several | Cost rises sub-linearly with capacity: deputies add continuity, not new functions | Governance cost per head falls but absolute coordination cost rises; the unit becomes a management problem |
| **The trap [A]** | The source's own control — small size never removes the duties — is precisely what makes State A expensive. **The duties are fixed; the people are not.** | A deputy opened "where needed" is a governance cost incurred *before* the revenue that justifies it | "Sufficient work" is a *precondition* of State C, so State C cannot be staffed into existence without demand |

**[C] Derived: the State A minimum-personnel problem.** Let `f = 9` be the functions that must exist **[S: Ch.10]** and `c` the maximum number of compatible functions one person may hold. Then minimum role-holders `N_roles_min = ⌈f / c⌉`. The stress test's Scenario A working assumption was `c ≈ 1.5`, giving ~6–8 combined-role holders **[A-assumption, stress-test ratio table]**. **[A]** But `c` cannot rise freely, because:

> "Segregation of duties — **No single person should receive money + approve expense + record transaction + audit transaction.**" **[S: Ch.18 control table]**

**[C]** So there is a hard floor on `c` for finance specifically: receive, approve, record and audit must be four distinct hands. In a State A team at least one of those must sit **outside the team** — which is exactly what the City Funds Manager and Auditor roles provide **[S: Ch.7, Ch.23]**. **This is the first proof that the Mohalla team cannot be economically self-contained, and it comes from the source's own control requirement rather than from an assumption.**

## 3.4 What the unit is *not*

**[A]** Four clarifications that prevent the model being built on a category error:

1. **Not a franchise.** No separate legal personality, no brand licence (v1.3-A N12 unresolved), no own bank mandate (N16 unresolved), no right to set prices or percentages **[S: Ch.33 NOT FINAL]**.
2. **Not a branch of a company.** Its revenue enters a venture revenue account **[S: Ch.18 step 2]** whose ownership is unresolved.
3. **Not a volunteer group.** It carries financial-integrity, verification, safety, evidence and audit duties that a volunteer group does not **[S: Ch.10 State A control]**.
4. **Not a cost centre in the accounting sense** — it can generate revenue — but it **is** a cost centre in the *governance* sense, because governance cost attaches to its existence rather than to its output.

> **[A] The correct economic description:** a Mohalla Team is a small, legally-unresolved, governance-heavy, demand-constrained delivery cell whose revenue capacity depends on a neighbourhood it did not choose, and whose fixed cost depends on a control system it did not design. That sentence is the whole problem; the rest of this document quantifies it.

---

# 4. COMPLETE COST STACK

**Classification discipline:** every line is **[S]** (the source names the cost), **[C]** (derived by formula) or **[M]** (a variable with no source value). **No line carries a rupee amount.** Where an amount is needed to show a mechanism it is marked **[M-ill]** and the symbolic form is given beside it.

## 4.1 PEOPLE COSTS

| # | Cost line | Source status | Variable | Notes |
|---|---|---|---|---|
| **PC-01** | Worker compensation for verified venture work | **[S: Ch.18 priority 1; Ch.19 step 7 "Paid for verified work under approved formula"]** | `C_wc = Σ(verified work × approved formula)` | **The formula does not exist** — "Weekly revenue percentages NOT FINAL" **[S: Ch.33]**. First charge on distributable funds |
| **PC-02** | Leader allocation | **[S: Ch.19 step 8 "Same framework with higher allocation; FINAL MULTIPLIER REQUIRES APPROVAL"; App. A §15.3 "must be transparent, capped or bounded… justified by verified leadership work rather than status alone"]** | `C_lead = C_wc_base × m_lead`, `m_lead` **UNRESOLVED** | Cannot be costed until `m_lead` is approved |
| **PC-03** | Paid specialists (skills the team lacks) | **[S: Ch.17 step 6 "Verified skills, availability, training and QA plan"; App. A §14.3 direct costs include "subcontracted approved services"]** | `C_spec` — a **direct cost**, priority 3 | Not overhead: attaches to a specific project |
| **PC-04** | Temporary / seasonal workers | **Not in source** | `C_temp` **[M]** | Implied by festival-linked demand **[I]**; classification unresolved **[V]** |
| **PC-05** | Business contributors' compensation | **[S: Ch.18 priority 1 covers "verified work"]** | inside `C_wc` | Sales time is work; whether it is *payable* work depends on the unresolved formula |
| **PC-06** | Service contributors' compensation | **No source line exists** | `C_svc_pay = 0` **by structural absence** | **§8.4 — the central finding.** Service work is volunteer or unfunded |
| **PC-07** | Governance role-holders' compensation | **No source line exists** | `C_gov_pay = ?` | HR/Verification, Funds, Safety, Planner, Editor work is *not* venture work, so priority 1 does not reach it |
| **PC-08** | Training compensation "where applicable" | **[S: Ch.19 step 1 "Only approved tasks/projects/venture work are eligible"]** | `C_train_pay` **[M]** | Training is not listed as eligible work — so by the source's own rule **training time is unpaid** unless approved as a task |
| **PC-09** | Founder compensation | **[S: Ch.18 priority 4 "Subject to approved cap and final structure"]** | `C_founder`, capped | **Not applicable at Mohalla level** — §8.7 |
| **PC-10** | Statutory employment obligations | **[S: Ch.18 priority 2; Ch.19 step 5 "Taxes, deductions and legal obligations considered"]** | `C_stat = f(C_wc, classification)` | **Classification UNRESOLVED [S: Ch.33]** → amount not computable **[V]** |

**[A] The structural observation from PC-06, PC-07 and PC-08 together:** the source's compensation machinery is attached to *verified venture work*. Three of the largest labour inputs in a real team — service delivery, governance, training — have **no compensation line in the architecture.** That is not an oversight to be criticised; it is a consequence of a zero-capital venture model. But it must be faced: **either those hours are volunteered, or they are funded from somewhere the architecture has not named.** §33 and §46 address this directly.

## 4.2 OPERATING COSTS

| # | Cost line | Source status | Variable | Fixed / variable |
|---|---|---|---|---|
| **OC-01** | Transport (routine) | **[S: Ch.8 step 4 site visit; Ch.15 "Health-support — transport coordination"]** | `C_trans` | Semi-variable — scales with requests and projects |
| **OC-02** | Transport (emergency / unexpected) | **[S: Ch.16; Ch.15 "Infrastructure/emergency — urgent coordination"]** | `C_trans_em` | **Lumpy, unplannable** — HC-03 |
| **OC-03** | Communication / airtime | Implied by **[S: Ch.8 phone confirmation; Ch.24 daily and weekly reporting]** | `C_comm` | Fixed per active member |
| **OC-04** | Internet / data | Implied by **[S: Ch.22 platform modules; Ch.24 dashboards]** | `C_net` | Fixed |
| **OC-05** | Local workspace | **Not in source** — no facility requirement is stated anywhere | `C_space` **[M]** | Fixed; **can be zero** if meetings use public or home space, which appears to be the source's implicit assumption **[A]** |
| **OC-06** | Equipment (tools, devices, safety kit) | **[S: Ch.15 "safe equipment"; App. A §14.3 "materials, tools"]** | `C_equip`, amortised `C_equip_amort` | Mixed — project tools are direct; shared devices are fixed |
| **OC-07** | Service materials (food packets, study materials, planting stock, cleaning supplies) | **[S: Ch.15 categories; Ch.20 programmes; Warehouse/Inventory roles]** | `C_mat` | Variable per activity — **and often the reason a service activity cannot happen** |
| **OC-08** | Printing / stationery | Implied by **[S: App. F evidence records; Ch.19 payment sheet]** | `C_print` | Small; **rises with governance load** |
| **OC-09** | Identification (member card / QR token) | **[S: Ch.31 "ID card"; Ch.33 QR ID card CONCEPT APPROVED — "Minimal data, revocable token, non-police visual design"]**; restricted by **v1.3-A A-17 §16.4** | `C_id × N_ver` | Per verified member; **recurring**, because a revocable token must be reissued |
| **OC-10** | Training delivery (venue, trainer time, materials, certification) | **[S: Ch.12; Ch.6 State trainer pool]** | `C_train` | Recurrent and rising — HC-12; certification cost externally set **[V]** |
| **OC-11** | Meetings | Implied by **[S: Ch.24 cadences; Ch.13 operating period]** | `C_meet` | Mostly a *time* cost, not a cash cost |
| **OC-12** | Documentation / records / evidence storage | **[S: App. F 14 evidence record types; Ch.22; v1.3-A A-15 M1–M7]** | `C_doc` | **Rises with governance load and with v1.3-A's registers** |
| **OC-13** | Software / platform | **[S: Ch.22 fourteen modules; Ch.30 Phase 1 "software foundation"; Ch.31 "Blocker before scale"]** | `C_sw` | **Shared/national**, not per-team — but someone pays it (§31) |
| **OC-14** | AI usage (inference, tokens, tooling) | **[S: Ch.21; Ch.22 AI logs; v1.3-A A-21/A-22]** | `C_ai` | Variable and rising with use — HC-11 |
| **OC-15** | Accounting / bookkeeping | **[S: Ch.18 segregation; Ch.19 steps 3–4; Ch.23 auditor]** | `C_acct` | **Cannot be self-performed by the same hands**; external or City **[V]** |
| **OC-16** | Payment processing / bank charges | Implied by **[S: Ch.19 step 7; Ch.18 venture revenue account]** | `C_pay = θ_pay × N_txn` | Small per transaction, **but transaction count is high in a weekly cycle** (HC-17) |
| **OC-17** | Customer acquisition (outreach time, proposals, travel to prospects) | **[S: Ch.7 City "identify customer needs… customer pipeline"; Ch.17 steps 2 and 5]** | `C_acq` | **Mostly time, not cash** — which is why it is invisible, and why §18 makes it explicit |
| **OC-18** | Logistics / storage / inventory holding | **[S: Ch.9 Warehouse family; Ch.7 materials allocation; SOP-15, SOP-16]** | `C_log` | City-pooled by design **[S: Ch.7]** |
| **OC-19** | Emergency operating costs | **[S: Ch.16; Ch.14; Ch.18 reserves "continuity, emergencies"]** | `C_emg` | Unplannable; the reason reserves exist |
| **OC-20** | Insurance | **[S: Ch.31 "insurance advice/coverage decision" = Blocker; Ch.33 UNRESOLVED]**; v1.3-A A-10 L1–L15 | `C_ins` | **Unknown until a broker answers [V]** — and a *pre-activation* cost for protection activity |
| **OC-21** | Legal / professional fees | **[S: Ch.30 Phase 0; Ch.5; App. E validation column]** | `C_legal` | Front-loaded and largely **national**, not per-team |
| **OC-22** | Compliance / statutory filing | **[S: Ch.18 priority 2; Ch.33 legal structure UNRESOLVED]** | `C_comp` | Depends entirely on entity form **[V]** |

## 4.3 GOVERNANCE COSTS (explicitly modelled, as required)

**[A]** Governance cost is modelled as **hours**, then converted to money by one of two routes, because the source provides no rate:

> **Route 1 (volunteer):** governance hours × true volunteer cost per hour (§15) → a real *economic* cost with no cash outflow.
> **Route 2 (paid):** governance hours × approved compensation rate → a real *cash* cost with **no waterfall line to pay it from** (§8.4).
>
> **Either route is a real cost. Route 1 hides it from the ledger; Route 2 hides it from the budget.** A model that shows neither commits the failure the stress test identified (F-05).

| # | Governance function | Source obligation | Driver | Form |
|---|---|---|---|---|
| **GC-01** | HR — applications, interviews, probation, records, conduct, welfare | **[S: Ch.12; SOP-01, SOP-03, SOP-04, SOP-17, SOP-18]** | `N_apps`, `N_members` | `g_hr × N_apps + g_hr_fix × N_members` |
| **GC-02** | Verification — identity, site, evidence, witnesses | **[S: Ch.8 step 4; SOP-02; Ch.12; App. F]** | `N_apps`, `N_act` | `g_ver × (N_apps + N_act)` |
| **GC-03** | Training — scheduling, delivery, records, re-certification | **[S: Ch.12; Ch.6 trainer pool]** | `N_trainees`, `N_retrain` | `g_train × N_trainees` |
| **GC-04** | Reporting — daily, weekly, monthly, quarterly, annual | **[S: Ch.24 five cadences; SOP-09, SOP-19]** | cadence count | `g_d×22 + g_w×4 + g_m + g_q/3 + g_y/12` |
| **GC-05** | Financial reconciliation — revenue, expense, payment sheet, audit trail | **[S: Ch.19 all 13 steps; SOP-08, SOP-09; Ch.18 segregation]** | `N_txn`, cycles | `g_fin × N_txn + g_cycle × cycles` |
| **GC-06** | Audits — readiness audit, corrective-action review, domain audits | **[S: Ch.13 gate 8; Ch.27 seven-step audit × six domains; Ch.23]** | periodic + event | `g_audit × N_audits` |
| **GC-07** | Incident review | **[S: Ch.16; SOP-13; v1.3-A A-09]** | `N_inc` | `g_inc × N_inc` — **heavy per incident** |
| **GC-08** | Leadership — decisions, conflicts, escalation, representation | **[S: Ch.9; Ch.8 "Decision — Team Leader within authority"; Ch.7 escalation map]** | constant + `N_dec` | `g_lead_fix + g_dec × N_dec` |
| **GC-09** | Planning — project creation, scheduling, resourcing | **[S: Ch.8 steps 5–7; Ch.9 Planner family; SOP-05, SOP-06]** | `N_act`, `P_projects` | `g_plan × (N_act + P_projects)` |
| **GC-10** | Coordination — internal, upward, lateral | **[S: Ch.7 escalation map; Ch.10 delegation records]** | `N_roles`, `N_escal` | `g_coord × N_roles + g_esc × N_escal` |
| **GC-11** | Compliance — legal, tax, permissions, statutory checks | **[S: Ch.19 step 5; Ch.15 "permissions"; Ch.5]** | activity-dependent | `g_comp` |
| **GC-12** | Data protection — classification, access grants, reason codes, retention, breach readiness | **[S: Ch.22, Ch.23; SOP-22; v1.3-A A-17 P1–P6, A-20]** | records, `N_grants` | `g_dp × records + g_grant × N_grants` |
| **GC-13** | v1.3-A instruments now attached to the unit | **[v1.3-A]** A-04 refusal register, A-06 visibility fields, A-09 incident fields, A-15 M1 rationale line, A-17 field register, A-19 consent records, A-20 grants, A-21 review caps | per event | `g_v13A` — **per the v1.3-A §25.3 burden table, 17 of 23 amendments impose nothing below Coordinator level**, so this is a role-holder cost, not a member cost |

**Total governance hours [C]:** `H_gov = Σ(GC-01 … GC-13)` — the full expanded **Governance Burden Calculator** is §25.

**[A] The stress-test estimate is not adopted as fact.** The stress test used **8–40 governance hours per team per month**, labelled it "unknown; F-05" and called it **"the single most important unknown in the whole model."** This document treats that band as a **scenario range [SC]**, tests points inside and outside it (§25.4), and requires pilot measurement before any value is used for planning.

## 4.4 The four cost layers

**[C]** Grouping every line by *behaviour* rather than by account gives the four layers the model actually needs:

| Layer | Contents | Behaviour | Funded from |
|---|---|---|---|
| **L1 — Existence cost** | PC-07; OC-03, 04, 05, 08, 09, 13; GC-01, 02, 04, 06, 08, 10, 11, 12, 13 | **Incurred whether or not the team does anything.** Roughly constant per team | **Nothing in the waterfall.** This is the gap |
| **L2 — Capability cost** | OC-06, OC-10, OC-14, OC-15, OC-20, OC-21 | Incurred to *become able* to act; front-loaded and recurrent | Partly priority 3 where attributable to a venture; otherwise unfunded |
| **L3 — Activity cost** | OC-01, OC-07, OC-16, OC-17, OC-18; GC-05, GC-09 | Scales with what the team does | Service activity: **unfunded**. Venture activity: priority 3 **[S]** |
| **L4 — Shock cost** | OC-02, OC-19, GC-07, and the HC-* register | Lumpy, unplannable, **correlated with the worst weeks** | **Reserves — priority 6, i.e. last [S]** |

**[A]** This layering is the model's main analytical tool, because it separates what the waterfall *can* fund (L3 venture costs, PC-01, PC-10) from what it *cannot* (L1, most of L2, L3 service costs, and L4 until reserves exist). §8.4 formalises the consequence.

---

# 5. HIDDEN COST REGISTER

**Method:** each of your fourteen questions is answered, then converted into a register entry with a trigger, a variable, a detection signal and a mitigation. **Every cost here is real, and none of it has a ledger line in the source.**

## 5.1 The fourteen questions answered

| Question | What actually happens **[A/I]** | Cost created |
|---|---|---|
| **A volunteer stops showing up** | The task is not merely unstaffed: it is re-planned, re-assigned, the person is followed up (a **Conduct & Welfare Coordinator** exists in the source **[S: Ch.9]**), their status moves through the vacancy lifecycle **[S: Ch.11 six statuses]**, and a replacement is recruited, verified and trained **[S: Ch.12]**. Research shows leavers' top stated reasons are relocation and busyness rather than programme failure **[X]** — i.e. **irreducible churn that no management improvement removes** | `C_replace = C_recruit + C_verify + C_train + C_coordination`, **plus** lost contribution and delayed output |
| **A leader is absent** | "Team Leader within authority" makes the decision **[S: Ch.8]**; the Funds Manager "cannot self-approve" **[S: Ch.18]**; so **decisions and payments stop**. v1.3-A A-14 supplies *apex* succession but nothing at Mohalla level | Decision latency; payment delay; City escalation; deputy activation cost **[S: Ch.10]** |
| **Transport is required unexpectedly** | Emergency and urgent coordination **[S: Ch.15]**, protection response **[S: Ch.16]** — no team-level budget line exists, and reserves are priority 6 and empty | `C_trans_em`, most commonly paid **from a member's own pocket** **[I]** → informal debt inside the team, which the stress test flags as an unhealthy retention mechanism (F-06) |
| **Equipment breaks** | Project tools are direct costs **[S: App. A §14.3]**, but *replacement* is not attributable to a delivered project, so it has no priority-3 home | Unfunded replacement; project delay; QA risk |
| **A customer refuses payment** | The lifecycle has step 10 "Acceptance — customer confirms or **dispute/revision recorded**" and step 11 "Revenue — payment/invoice recorded and **reconciled**" **[S: Ch.17]**. A dispute consumes the Business Manager, the Leader, and possibly City escalation lane 5 **[S: Ch.7]** | `h_dispute` × 2–3 people, **plus** direct costs already sunk, **plus** compensation already accrued for work done (§12.4 — the worst case in the model) |
| **A project takes twice as long** | Revisions are tracked **[S: Ch.17 step 9]**; QA precedes delivery **[step 8]**; scope, price, timeline and acceptance criteria were fixed at step 4 | Doubled labour at a fixed price halves `P_max` (§17) and drives margin negative — **the team has paid to work** |
| **A service activity generates no revenue** | The full 12-step loop runs — verification, priority assessment, project creation, resources, volunteers, execution, evidence, outcome verification, report, impact measurement **[S: Ch.15]** — with **zero** waterfall entry | Full governance + material + transport cost, no funding line (§8.4). **The largest hidden cost in the model, because it is the mission itself** |
| **Verification workload increases** | Verification is per-request and per-member **[S: Ch.8 step 4; Ch.12]** and is not reducible — "small size never removes… HR verification" **[S: Ch.10]**. In a high-need area requests rise exactly when money does not | `g_ver × (N_apps + N_act)` grows while revenue does not → **the needier the area, the higher the unfunded governance load** (§31.3) |
| **The team grows** | Growth adds members (verification, training, coordination) **before** it adds revenue capacity; State B sub-roles open on need **[S: Ch.10]**; coordination cost rises with `N_roles` | Growth is **cash-negative early** — the opposite of a conventional business (§13) |
| **An incident occurs** | Protection incident protocol **[S: Ch.16; v1.3-A A-09]**: documentation, escalation, review at City level or above, independence rules, member support, possible authority contact | `g_inc` (heavy), possible `C_legal`, possible insurance excess, sealed-record handling (v1.3-A A-20) — **plus legitimacy-capital loss** (§2.3) |
| **AI costs increase** | `C_ai` rises with use; v1.3-A A-21 review caps create *human* cost per recommendation; A-22 creates a 17-field record per consequential use | Cash **and** governance hours rise together — **an AI efficiency gain can be consumed by its own governance** |
| **A member must be trained again** | Re-certification is externally driven where the domain is regulated **[S: Ch.12 boundary]**; a lapse blocks task eligibility (v1.3-A A-10 §9.5: "no authorisation record, no restricted task") | `C_train` recurs; capacity drops until re-certified |
| **A customer requires revisions** | "Revisions tracked" **[S: Ch.17 step 9]**; acceptance is step 10 and revenue step 11 — so **revisions occur before payment** | Unpaid labour, delayed cash, and a QA loop consuming the scarcest role |
| **The team must travel outside its normal area** | Cross-Mohalla projects are a **City** responsibility to coordinate **[S: Ch.7]**, but the travel and the day land on the team | Transport + a full day of capacity; opportunity cost is the local work not done |

## 5.2 HIDDEN COST REGISTER

| ID | Hidden cost | Trigger | Variable | Detection signal | Mitigation | Class |
|---|---|---|---|---|---|---|
| **HC-01** | Replacement cost of an exited member | Any exit | `C_replace` | Exit count; time-to-refill; task delays | Stay interviews; recognition — associated with materially lower turnover **[X]**; paused/alumni status | **[C]** |
| **HC-02** | Decision and payment paralysis during leader absence | Absence, illness, travel | `H_paralysis × cost/hour` | Payment sheet late; decisions queued | Sub-Leader with recorded delegation **[S: Ch.10]**; City fallback **[S: Ch.7]**; the v1.3-A A-14 pattern applied locally | **[A]** |
| **HC-03** | Unbudgeted emergency transport | Incident, urgent need | `C_trans_em` | Personal reimbursement requests | A small pre-approved emergency float at **City** level; a rule that members are never expected to fund operations personally (§12.6) | **[A]** |
| **HC-04** | Equipment replacement with no priority-3 home | Breakage, loss, wear | `C_equip_replace` | Repeated "tool unavailable" notes | Shared City inventory **[S: Ch.7]**; amortisation as an approved overhead | **[A]** |
| **HC-05** | Dispute cost after delivery | Customer refuses or disputes | `h_dispute × people + sunk C_var` | Ageing receivables; escalation lane 5 | Acceptance criteria written *before* work **[S: Ch.17 step 4]**; milestone payment; City business review | **[C]** |
| **HC-06** | Scope overrun | Under-scoping, revisions | `(h_actual − h_est) × rate` | Estimated vs actual hours per project | Mandatory hour estimate at approval; revision cap in the contract; QA before delivery **[S: Ch.17 step 8]** | **[C]** |
| **HC-07** | **Unfunded service delivery** | Every non-revenue activity | `C_svc_total = C_mat + C_trans + H_svc × cost` | Service output rising while revenue flat | Time-costed service categories (§6.4, §33, §38); City-pooled materials; social-impact fund **only** when surplus exists **[S: Ch.20]** | **[C]** |
| **HC-08** | Verification load rising with need | High-need area | `g_ver × N_act` | Verification backlog; overdue verification | City-level verification cadre (stress-test §23: "central verification cell or city-level verifier cadre") | **[C]** |
| **HC-09** | Growth is cash-negative early | Team expansion | `ΔC_gov + ΔC_train` arriving before `ΔV_gross` | Member count up, distributable flat | Growth gated on **contribution per head**, not headcount (§13.5) | **[C]** |
| **HC-10** | Incident cost (time + legal + reputational) | Any protection or safeguarding incident | `g_inc + C_legal + legitimacy loss` | Incident count; unresolved incidents ageing | v1.3-A A-09, A-10, A-11; City-level review; insurance **[V]** | **[A]** |
| **HC-11** | AI cost and AI governance cost rising together | Increased AI use | `C_ai + g_review × N_rec` | AI spend up while reviewer queue grows | v1.3-A A-21 Low-tier sampling; caps; kill-switch | **[C]** |
| **HC-12** | Re-training and re-certification | Lapse, regulation change, new venture | `C_train × N_retrain` | Expired authorisations; blocked tasks | Certification-expiry field on the dashboard (§27); State trainer pool **[S: Ch.6]** | **[C]** |
| **HC-13** | Revision labour before acceptance | Quality gap, unclear scope | `h_rev × rate` | Revisions per project; acceptance delay | Scope and acceptance criteria first **[S: Ch.17 step 4]**; QA plan at assignment **[step 6]** | **[C]** |
| **HC-14** | Out-of-area travel | Cross-boundary project | `C_travel + H_day` | Projects with delivery distance beyond the normal area | City coordinates **and funds** cross-boundary work **[S: Ch.7]**; decline where unfunded (§19 distance criterion) | **[A]** |
| **HC-15** | Seasonality and festival troughs | Calendar | variance of `V_gross(month)` | Two or more consecutive low months | Float sized for the **trough, not the average** (§9.6); cadence matched to collection (§12.6) | **[I]** |
| **HC-16** | Collection lag (invoiced ≠ collected) | Customer payment behaviour | `Δt_collect` days | Receivables ageing; distributable < invoiced | Milestone or advance terms; `r_collect` measured per category (§18) | **[C]** |
| **HC-17** | Transaction cost of a weekly cycle | Cadence frequency | `θ_pay × 4.33` cash + `g_cycle × 4.33` hours per month | Payment-transaction count; finance hours | Fortnightly or monthly cycle until contribution-positive (stress-test R2, M5-iii) — **[P]**; this changes frequency, never the priority order or the transparency principle | **[C]** |
| **HC-18** | Social cost borne by control role-holders | Saying no to neighbours | Burnout and exit risk of the HR, Funds and Safety holders | Control-role turnover; refusals declining over time | Visible backing from City; Integrity Line (stress-test M10); v1.3-A A-04 support duty | **[A]** |
| **HC-19** | Translation and multilingual cost | Language equity | `C_translate × documents` | Documents existing in one language only | v1.3-A H10 rule for legally significant documents; City Editor **[S: Ch.7]** | **[A]** |
| **HC-20** | Cost of *not* having data — rework, double entry, lost evidence | Manual control stack | `H_rework` | Duplicate records; missing evidence at audit | Platform minimum at Stage 2 (stress-test §23 technology row); auto-generated reports so "humans supply facts, not formatting" (F-05 mitigation d) | **[A]** |
| **HC-21** | Privacy or safeguarding breach cost | Data incident | `C_breach + legitimacy loss` | Any SOP-22 trigger | v1.3-A A-17 P5 runbook, A-19, A-20; classification before collection | **[V]** |
| **HC-22** | **Opportunity cost of governance hours** | Every governance hour | `H_gov × contribution per hour` | Governance share of total hours above the approved ceiling | §25 calculator + §26 minimum viable control | **[C]** |
| **HC-23** | Cost of closing a failed venture | Venture failure | Settlement + asset recovery + access revocation + lessons | Paused ventures with unresolved customers | The source's own closure rule: "settle customers, recover assets, revoke accesses, record lessons and prevent leaderboard manipulation" **[S: App. A §13.5]** | **[S]** |
| **HC-24** | Dependency cost | Concentration in one customer, leader or revenue line | expected loss × probability | Concentration ratios on the §27 risk dashboard | Concentration limits (B-07); City pipeline **[S: Ch.7]** | **[A]** |
| **HC-25** | Cost of an *unmeasured* cross-subsidy | Service hours silently consuming business capacity | `H_svc × contribution per hour` | Mission-impact score high while distributable falls | B-01 Service Hour Budget (§6.3) | **[C]** |

**[A] Register reading:** HC-07 (unfunded service) and HC-22 (governance opportunity cost) are the two largest, and **neither is a cash line.** That is exactly why they are missed. A team's ledger can be perfectly reconciled — "no unexplained material gaps" **[S: Ch.13 finance gate]** — while the team is economically exhausted.

---

# 6. SERVICE ECONOMICS

## 6.1 The five activity categories, anchored to source

| Category | Definition | Source anchor | Revenue? | Who funds it? |
|---|---|---|---|---|
| **A. Pure Service** | Activities performed primarily for community benefit, with no customer and no price | **[S: Ch.15 — all seven categories: Education, Food, Health-support, Cleaning/plantation, Clothing/donations, Infrastructure/emergency, Animal/environment]** | **No** | **UNRESOLVED — §8.4.** Candidates: social-impact fund (**only** "when surplus conditions are met" **[S: Ch.20]**), donations (**"donations may be possible after validation" [S: Ch.20]**), venture surplus, external grant |
| **B. Revenue-Producing** | Approved venture work for a paying customer | **[S: Ch.17 lifecycle; the seven potential categories]** | **Yes** | The customer, through the waterfall **[S: Ch.18]** |
| **C. Mixed** | Activities carrying both community benefit and a paying element | **[S]** Education/training appears as **both** a Ch.15 service category **and** a Ch.17 venture category; "Health-support — transport coordination" can be a paid logistics service | **Partly** | Split accounting required — **and the source contains no split-accounting rule [A]** |
| **D. Infrastructure** | Work required for the organisation to function, producing neither service output nor revenue | **[S: Ch.19; Ch.24; Ch.27; Ch.22; Ch.11; Ch.10; all 22 SOPs]** | **No** | **UNRESOLVED.** The organisation service fee (priority 5) is the intended source but arrives only after a venture is healthy |
| **E. Capacity Building** | Training, development, certification, member growth | **[S: Ch.12; Ch.25 "Member development 10%"; Ch.6 specialist pool; Ch.26 succession readiness]** | **No**, unless sold as a Ch.17 education/training venture | **UNRESOLVED** — and **[S: Ch.19 step 1]** makes only "approved tasks/projects/venture work" payment-eligible, so trainee time is unpaid by default |

## 6.2 The nine questions applied to each category

| Question | A. Pure Service | B. Revenue-Producing | C. Mixed | D. Infrastructure | E. Capacity Building |
|---|---|---|---|---|---|
| **1. Who benefits?** | The beneficiary and the locality; **the organisation's legitimacy** | The customer; the worker (pay); the organisation (fee, reserve, social fund) | Both, in unmeasured proportion | The organisation itself; indirectly every member | The member; future teams; **replication capacity** |
| **2. Who performs it?** | Verified, trained members scheduled by the Volunteer Manager **[S: Ch.15 step 7]**; the Ground-Level Manager verifies **[S: Ch.8]** | Supporting Members and project workers **[S: Ch.10]**; specialists where skills require **[S: Ch.17 step 6]** | Both — often the same person in the same week | Role-holders: HR, Funds, Planner, Safety, Leader, Editor | State-pool trainers **[S: Ch.6]**, Sub-Role holders, the member |
| **3. What does it consume?** | `H_svc`, `C_mat`, `C_trans`, verification and evidence hours | `h_proj`, `C_var`, `C_acq`, QA hours, AI usage | Both, with no allocation rule | `H_gov` — the largest single consumer in the model (§25) | `C_train`, trainer hours, member hours, certification fees |
| **4. Does it generate revenue?** | **No** | **Yes** — `V_gross` | Partly | **No** | **No**, unless sold |
| **5. If not, who funds it?** | **UNRESOLVED.** No line exists | n/a | **UNRESOLVED split** | **UNRESOLVED.** Priority 5 is intended but downstream | **UNRESOLVED.** Priority 1 does not reach it |
| **6. Can it be repeated?** | Yes — and repetition is the point (a lane stays fixed; a tutoring circle recurs) | Yes, if demand recurs; **repeat customers are the only cheap revenue** (§18) | Yes | Yes — inherently recurrent (weekly, monthly, per member) | Yes, and it *must* repeat (re-certification, new members) |
| **7. Can it scale?** | Scales with volunteers, **not with money** — the only category that scales without revenue | Scales with trained delivery capacity — the binding constraint (§17) | Ambiguously | **Scales badly** — per-team constant (§31.3) | Only with trainer supply, which the stress test identifies as the binding constraint above ~1,000 members |
| **8. What evidence proves completion?** | Outcome verification — "Did the project solve or reduce the problem?" **[S: Ch.15 step 10]**; photos, confirmations, receipts, attendance, outcome checks **[step 9]**, under App. F privacy controls | Customer acceptance **[S: Ch.17 step 10]**; invoice reconciliation **[step 11]**; QA record **[step 8]** | Both sets — **and the ambiguity is where gaming lives** (§36) | "Reconciled records with no unexplained material gaps" **[S: Ch.13 finance gate]**; audit trail **[S: Ch.19 step 13]** | Training records, certification, probation completion **[S: Ch.12]** |
| **9. What is the opportunity cost?** | The revenue work not done, and the governance not completed | The service not delivered — **and mission impact carries the highest performance weight, 20% [S: Ch.25]** | Unclear, because the split is unmeasured | The service and revenue hours consumed — **HC-22** | Immediate output, in exchange for future capacity |

## 6.3 The cross-subsidy that already exists — and is invisible

**[C]** Question 9 exposes the model's real engine:

> The **performance system** awards **20% to mission impact** and **15% to business performance** **[S: Ch.25]**. The **waterfall** pays **only** venture work **[S: Ch.18]**. Therefore a team raises its *score* partly by doing unpaid work and raises its *cash* by doing paid work — and the same small group of people must do both, from one hour pool (§2.1).

**[A]** This is a **structural cross-subsidy from service to business, paid in hours, invisible in every ledger.** It is not a design flaw — the 20% mission weight is precisely the right defence against a money-only organisation, and the source says so: *"Core purpose; prevents money-only optimisation"* **[S: Ch.25]**. But an **unbudgeted** cross-subsidy is the first thing consumed in a hard month, and what gets consumed is the mission.

**[P] Proposal B-01 — Service Hour Budget.** Each team declares monthly an explicit `H_svc_budget`: the hours it intends to spend on Pure Service. Actual against budget is reported **alongside** revenue, on the same page. Service hours then become a managed, defended allocation rather than a residual. This makes the cross-subsidy visible **without monetising service** (§38 forbids that) and **without touching the performance weights** **[S: Ch.25]**. `PROPOSED — REQUIRES FINAL APPROVAL`.

## 6.4 Which service categories can run without money?

**[A]** Ranked by cash intensity, using the source's own category controls **[S: Ch.15]**:

| Rank | Category | Cash intensity | Why |
|---|---|---|---|
| **1** | Education — learning circles, tutoring, digital literacy | **Very low** | Needs people, a place and time; "study materials" is the only cash line. **Safeguarding and consent controls apply; no exposure of minors [S: Ch.15]** |
| **2** | Cleaning / plantation — neighbourhood cleaning, waste awareness, tree planting | **Low** | Tools and permissions; "survival/follow-up tracking" is a time cost |
| **3** | Clothing / donations — collection, sorting, distribution | **Low cash, high governance** | "Condition checks, donor intent, receipts and audit" **[S]** — the goods are donated but the *control* cost is real |
| **4** | Health-support — awareness, transport coordination, qualified partner support | **Low–medium** | "No diagnosis/treatment unless licensed" **[S]** — so it stays awareness and coordination, i.e. time not money |
| **5** | Animal / environment — rescue referral, feeding, environmental work | **Medium** | "Legal compliance and trained handling" **[S]** |
| **6** | Food — packets, community meals, emergency food | **High** | "Food safety, dignity, stock control, no inflated counts" **[S]** — every meal is a rupee *and* a control |
| **7** | Infrastructure / emergency — small improvements, urgent coordination, disaster support | **Highest** | "Permissions, authorities first, no obstruction" **[S]** — materials, transport, unpredictable scale |

**[P] Proposal B-02 — Time-Costed Service Floor.** A team at Stage 0–1 (§30) commits to categories **1–3** as its service floor, because those continue at ₹0 revenue using time and existing materials. Categories **6–7** are explicitly **City- or State-resourced** **[S: Ch.7 materials allocation; Ch.6 state projects]** and are not undertaken by a Mohalla team without a resourcing decision. **This is how service survives a zero-revenue month (§33) without breaching the source's restrictions that the social-impact fund is "not ordinary operating salaries" and "not venture bailouts" [S: Ch.20].** `PROPOSED — REQUIRES FINAL APPROVAL`.

---

# 7. MOHALLA REVENUE ENGINE

## 7.1 The legitimate channels already permitted **[S: Ch.17]**

Reproduced exactly, with the source's own controls. **No category is added. None is assumed viable anywhere.**

| # | Potential business category **[S]** | Controls stated in source **[S]** | Startup requirement | Skill requirement | Capacity driver | Sales difficulty **[A]** |
|---|---|---|---|---|---|---|
| **1** | Software / websites / apps | "Technical quality, scope, contracts, data/security review" | Low cash; **high skill**; portfolio needed | Development, QA, scoping | `h_proj` large; revisions likely | **High** — crowded market, trust barrier, price pressure |
| **2** | AI automation | "Disclose limitations; no unlawful data processing or autonomous consequential decisions" | Low cash; **high skill + high governance** | AI ops, data handling, disclosure discipline | Constrained by v1.3-A A-21 review capacity | **High** — the buyer must understand AI; long cycle |
| **3** | Digital services / analytics | "Customer data legality, confidentiality and source controls" | Low cash; medium–high skill | Analysis, data privacy, reporting | Moderate | **Medium–high** — needs a demonstrable artefact |
| **4** | Design / editing | "IP ownership, consent, fact-check and content rights" | **Very low cash**; medium skill; the Editor family already exists **[S: Ch.9]** | Copy, video, graphic, proofreading, content quality review | Short cycles; **high revision risk** | **Medium** — low price point and many competitors, but the *fastest* route to a first rupee |
| **5** | Education / training | "Trainer competence and **safeguarding for minors**" | Low cash; medium skill; **certification and safeguarding gate it** | Subject mastery, teaching, safeguarding | Session-based; repeatable | **Medium** — real local cash demand; **but minors' safeguarding is a certified requirement [V]** |
| **6** | Local business technology | "**Do not access customer accounts without permission**" | Low cash; medium skill | SME digital support, setup, maintenance | Per-client, recurring | **Low–medium** — the customer is next door; **retainer potential** |
| **7** | Physical products / services | "**Health, safety, licensing, tax and liability review**" | **Cash, stock, storage, licensing** — highest of all | Procurement, quality, logistics, compliance | Inventory-bound; Warehouse family **[S: Ch.9]** | **Medium** — real demand, but the control load and liability are highest **[V]** |

**[A] Honest reading:** categories **4, 5 and 6** have the lowest cash startup and the shortest path to a first rupee; **1, 2 and 3** have the highest margin potential and the highest skill and trust barriers; **7** carries cash, stock, licensing and liability that a zero-capital Mohalla team should not touch at Stage 0–2 (§30). **This is a ranking of *characteristics*, not a recommendation — §19 supplies the framework by which a specific team chooses.**

## 7.2 The fourteen economic attributes, expressed as variables

Your brief lists the attributes required per channel. **No source value exists for any of them** (Fact 1), so each is defined as a variable the pilot measures (§40).

| Attribute | Variable | Source anchor | Status |
|---|---|---|---|
| Startup requirement | `K_startup` (cash) + `H_startup` (hours) | **[S: Ch.17 step 4 "Scope, price, timeline, acceptance criteria, data/IP/confidentiality terms"]** | **[M]** |
| Skill requirement | `skill_level ∈ {low, medium, high, certified}` | **[S: Ch.17 step 6 "Verified skills, availability, training and QA plan"; Ch.12 boundary]** | **[S]** that a requirement exists; **[M]** as to level |
| Delivery capacity | `h_proj` hours per project; `P_max` per month | §17 formula | **[C]** |
| Sales difficulty | `r_close`, cycle length, `h_acq` per lead | **[S: Ch.7 City pipeline; Ch.17 steps 2, 5]** | **[M]** |
| Customer acquisition requirement | `C_acq`, `H_acq` | §18 | **[C]** once the `r_*` are measured |
| Payment cycle | `Δt_collect` days; `r_collect` | **[S: Ch.19 weekly cycle; Ch.17 step 11]** | **[M]** — and revenue is lumpy **[I; stress-test F-06]** |
| Gross revenue | `V_gross = P_collected × P_price` | **[S: App. A §14.3 "Total customer receipts or invoiced revenue before deductions, depending on final accounting policy"]** | **[C]** — note the source leaves the *basis* (receipts vs invoiced) to final accounting policy **[V]** |
| Direct costs | `C_var` = materials + tools + subcontracted approved services + directly attributable platform costs + other approved expenses | **[S: App. A §14.3, verbatim]** | **[C]** |
| Worker compensation | `C_wc` via the approved formula | **[S: Ch.18 priority 1; Ch.33 NOT FINAL]** | **[M]** — formula unresolved |
| Statutory obligations | `C_stat` | **[S: App. A §14.3 "applicable to the legal structure and worker classification"]** | **[V]** — classification unresolved |
| Reserve requirements | `C_res` | **[S: Ch.18 priority 6; Ch.33 "Reserve release rules NOT FINAL"]** | **[M]** |
| Organisation allocation | `C_org` | **[S: Ch.18 priority 5; illustrative `w_org` = 12% — ILLUSTRATIVE ONLY]** | **[M] / [M-ill]** |
| Social-impact contribution | `C_sif` | **[S: Ch.18 priority 7 "only when surplus conditions are met"; Ch.20 restricted; Ch.33 formula NOT FINAL]** | **[M]** |
| Net distributable amount | `D_net` | **[S: App. A §14.3 "revenue remaining after mandatory controls according to the approved waterfall; exact calculation requires final finance policy"]** | **[C]** — §8 |

## 7.3 What the engine is *not* allowed to be **[S]**

Four constraints already in the architecture, restated because revenue pressure always tests them:

1. **Venture approval is tiered** — "Approval tier based on category, risk, money, data and novelty" **[S: Ch.17 step 3]** — and venture categories are **POTENTIAL**, "approve categories one by one using risk/value framework" **[S: Ch.33]**. **A team may not simply start selling.**
2. **Scaling is conditional** — "A venture scales only when it shows real customer demand, quality delivery, acceptable risk, documented revenue, controlled costs and **sufficient trained people**" **[S: App. A §13.5]**.
3. **Failure is a learning event, not a scandal — but only with discipline** — "it becomes a learning event **if money is reconciled, customers are treated fairly, workers are paid according to approved rules and reasons are documented**" **[S: App. A §13.5]**.
4. **AI does not create income by existing.** "AI may recommend. Humans decide." **[S: Ch.21]**; AI cannot appoint, reject or remove **[S: Ch.11]** and cannot set wages or approve ventures **[S: Ch.9 authority limits]**. Your rule — *do not assume AI automatically creates income* — is already architecture.

## 7.4 The demand-side constraint the source already places at City level

> **[S: Ch.7 City responsibility, verbatim]** "Identify customer needs, combine skills, propose ventures and coordinate delivery." Evidence: "Customer pipeline, venture proposals, delivery records."

**[C] Three consequences:**

1. **A Mohalla team is not required to originate its own demand.** The pipeline is a *City* output. This is the single largest economic relief available to the unit — and it is **already in the architecture**.
2. **Therefore `C_acq` should be modelled at City level and allocated**, not duplicated in every team (§18, §26).
3. **Therefore a team in a weak neighbourhood is not automatically doomed** — it can be *assigned* work from a City-wide pipeline, provided skill and delivery capacity match. This is the mechanism that makes §22 cross-subsidy models C and D possible **without inventing a new principle**.

**[A] The reverse also holds:** if the City has no pipeline capability, every Mohalla team must cold-acquire its own customers with no brand, no portfolio, no budget and no sales training. **That difference — not local effort — separates a viable unit from a non-viable one, and it sits one layer above the unit being modelled.** §31.2 quantifies it.

---

# 8. REVENUE WATERFALL — PRESERVED EXACTLY, THEN MADE COMPUTABLE

## 8.1 The source flow, reproduced verbatim

**[S: Ch.18 diagram; App. A §14.2 Diagram 14A]** — identical in both places:

```
CUSTOMER REVENUE
   ↓
VENTURE REVENUE ACCOUNT
   ↓
1. WORKER COMPENSATION
   ↓
2. STATUTORY DUES WHERE APPLICABLE
   ↓
3. DIRECT BUSINESS / DELIVERY COSTS
   ↓
4. FOUNDER COMPENSATION / APPROVED CAP
   ↓
5. ORGANISATION SERVICE FEE
   ↓
6. RESERVES / WAGE-PROTECTION BUFFER
   ↓
7. SOCIAL-IMPACT CONTRIBUTION WHEN CONDITIONS ARE MET
   ↓
8. RESIDUAL SURPLUS / FOUNDER UPSIDE
```

Your brief's version matches this exactly. **The order is not altered, re-weighted, re-labelled or reinterpreted anywhere in this document.**

> **"THE PRIORITY ORDER IS THE CONTROL; PERCENTAGES ARE A PLANNING TOOL."** **[S: Ch.18; App. A §14.1]**

> "A percentage table applied blindly to gross revenue can break the system because it may pay discretionary allocations before wages, taxes or direct costs. **A priority waterfall defines what must be protected first and what can fall to zero in weak periods.**" **[S: App. A §14.1]**

**[A]** That second sentence is the most economically sophisticated statement in the entire architecture, and it is why this model can be built at all. It declares the waterfall to be a **sequencing rule with a fall-to-zero set**, not a percentage split. §8.3 formalises exactly that.

## 8.2 Source definitions, verbatim **[S: App. A §14.3]**

| Term | Source definition |
|---|---|
| **Gross revenue** | "Total customer receipts or invoiced revenue before deductions, **depending on final accounting policy**" |
| **Venture revenue account** | "Designated account/ledger where customer revenue for an approved venture is recorded **before allocation**" |
| **Direct costs** | "Costs required to deliver the customer work: materials, tools, subcontracted approved services, platform costs directly attributable to delivery and other approved expenses" |
| **Statutory obligations** | "Taxes, deductions, labour or other legally required amounts applicable to the **legal structure and worker classification**" |
| **Distributable funds** | "Revenue remaining after mandatory controls according to the approved waterfall; **exact calculation requires final finance policy**" |
| **Worker compensation** | "Payment to workers/members for **verified work** under the approved legal and financial model" |
| **Leader compensation** | "Leadership allocation under the same framework but with a higher approved allocation for leadership responsibility; **exact multiplier not final**" |
| **Organisation service fee** | "Allocation to sustain organisational infrastructure **after higher-priority items**" |
| **Reserve / wage-protection buffer** | "Funds held to protect **continuity, future costs and worker wage protection** under approved rules" |
| **Social-impact contribution** | "Restricted allocation to approved social programmes **when surplus conditions are met**" |
| **Residual surplus / founder upside** | "Remaining surplus after priority obligations and caps as defined by approved structure" |

## 8.3 The waterfall as a computable sequence **[C]**

Let `V_gross` be gross revenue collected in the period, entering the venture revenue account. Let each priority `i` have a **requirement** `R_i` (what is owed) and an **allocation** `A_i` (what is actually paid). The source's rule — protect first, fall to zero in weak periods — gives:

```
S_0 = V_gross
for i = 1 … 8:
    A_i = min( R_i , S_(i-1) )      # never pay more than is owed; never more than remains
    S_i = S_(i-1) − A_i             # the residual passes down
```

with the **deferrable set** defined by the source's own bad-month rule **[S: Ch.18 control table]**:

> **"Bad-month behaviour — Deferrable organisational fees and social contributions fall before verified worker compensation is sacrificed, subject to law and final structure."**

**[C]** So `R_5` (organisation fee), `R_7` (social impact) and `R_8` (residual) may be set to zero in a weak period, while `R_1`, `R_2` and `R_3` may not — and `R_6` (reserves) is *discretionary in the short run and fatal to skip in the long run*.

**Six solvency lines fall out of the arithmetic [C]:**

| Line | Condition | Meaning |
|---|---|---|
| **S-1 Worker solvency** | `V_gross ≥ R_1` | Verified workers can be paid in full |
| **S-2 Legal solvency** | `V_gross ≥ R_1 + R_2` | Workers **and** statutory dues can be paid |
| **S-3 Delivery solvency** | `V_gross ≥ R_1 + R_2 + R_3` | The work can actually be paid for — materials, tools, subcontracted services |
| **S-4 Institutional solvency** | `V_gross ≥ R_1 + … + R_5` | The organisation itself is funded (founder cap + service fee) |
| **S-5 Resilience** | `V_gross ≥ R_1 + … + R_6` | A buffer is being built |
| **S-6 Mission surplus** | `V_gross ≥ R_1 + … + R_7` | Surplus conditions are met and the mission is funded from surplus |

> **[A] This is the model's most important single result.** The architecture's own logic produces **six distinct solvency thresholds**, and a team can sit above one and below the next. "Revenue > 0" does not even reach S-1. §11 converts these into the four break-even lines your brief requires.

## 8.4 The funding gap, derived **[C]**

Applying the waterfall to the five activity categories of §6:

| Category | Produces `V_gross`? | Has a requirement `R_i`? | Funded? |
|---|---|---|---|
| **A. Pure Service** | **No** | **No** — priority 1 is compensation "for verified work" under a venture; priority 3 is "costs required to deliver **the customer work**" | **NOT FUNDED by the waterfall** |
| **B. Revenue-Producing** | **Yes** | Yes — priorities 1, 2, 3, and it feeds 4–8 | **FUNDED** |
| **C. Mixed** | Partly | Partly — **with no split rule in the source** | **PARTLY, and ambiguously** |
| **D. Infrastructure** | **No** | Priority 5 "organisation service fee — sustains organisational infrastructure" is *intended* for this | **FUNDED ONLY FROM THE SURPLUS OF B, AT PRIORITY 5** |
| **E. Capacity Building** | **No** | **No** — and **[S: Ch.19 step 1]** limits payment eligibility to "approved tasks/projects/venture work" | **NOT FUNDED by the waterfall** |

> ### THE CENTRAL FINDING **[C]**
> **The waterfall is a venture-revenue allocation engine. It is not an organisational funding model.** Four of the five activity categories — including the mission itself (A) and the control system that makes the mission trustworthy (D) — have **no revenue line to charge, and therefore no protection from priority 1.**
>
> **Worker compensation is protected. Service, governance and training are not.** Not because the architecture values them less — it gives mission impact the *highest* performance weight, 20% **[S: Ch.25]** — but because the waterfall was designed to allocate **venture receipts**, and for those categories there are no receipts.

**[A] Consequences, stated plainly:**

1. **At ₹0 venture revenue a team can pay nobody and fund nothing** — yet it is not in breach of the waterfall, because priority 1 attaches only to verified venture work. The breach is of the **expectation created at recruitment** (§12, §34; stress-test F-02).
2. **The organisation service fee is the intended funding source for the centre — and it is fifth.** A Mohalla team in months 1–6 contributes **zero** to City, State and National while depending on all three for training, verification, pipeline, materials, incident support and audit **[S: Ch.6, Ch.7]**.
3. **Something must fund the centre before any venture succeeds, and the source does not name it.** Candidates, each requiring validation and approval: founder capital, Krytos internal funding, donations ("donations may be possible after validation" **[S: Ch.20]**), grants, or a pre-revenue service fee that is waived and accrued. **§21, §31 and §43 treat this as an open decision, not a solved one.**
4. **This is the honest core of the Part 31 answer:** one Mohalla cannot pay for itself *and* its governance *and* its share of the centre in its first months. Whether it ever can depends on `H_gov`, on `K` (teams per city) and on neighbourhood demand — all measurable, none currently known.

## 8.5 Reserves: the sequencing problem, quantified **[C]**

**[S: Ch.18 priority 6]** — reserves fill *after* worker compensation, dues, direct costs, founder cap and organisation fee. Let `R_6 = ρ × S_5`, where `ρ` is the approved reserve rate **[M — "Reserve release rules NOT FINAL", S: Ch.33]** and `S_5` is the residual after priority 5.

**[C]** For a new team: `V_gross` is low → `S_5` is small or zero → `R_6 = ρ × (small)`. **The wage-protection buffer accumulates fastest when the team is not in trouble, and is empty exactly when it is.**

> Stress-test F-06, verbatim: **"No — sequence error.** The buffer is *downstream* of the revenue it is supposed to stabilise. There is no cold-start instrument anywhere in the document."

**[C] Time to build a usable buffer.** If the buffer must cover `M_cov` months of fixed obligation `(C_fixed + C_gov)`, and accumulates at `ρ × S̄_5` per month:

> `M_to_buffer = M_cov × (C_fixed + C_gov) / (ρ × S̄_5)`

If `S̄_5` is small — which it is early — `M_to_buffer` is very large, and it grows super-linearly as `S̄_5` falls. **No value is asserted.** The formula is the deliverable; the pilot supplies `S̄_5` (§13, §40).

**[P] Proposal B-03 — Reserve Seeding Order.** The first reserve contribution for a new team should be **seeded, not accumulated**: the wage-protection buffer for months 1 to `M_cov` is established *at formation* from a source named in advance (founder capital, Krytos, or a validated donation), held under the existing custody rule — "National Funds Manager manages; release requires approval matrix" **[S: Ch.18]** — and reconciled against any float. **This does not alter the priority order**; it pre-funds priority 6 instead of waiting for it. `PROPOSED — REQUIRES FINAL APPROVAL`; **[V]** for source-of-funds legality and tax treatment.

## 8.6 The centre's income problem **[C]**

| Layer | What it must provide **[S]** | What it receives from a new Mohalla team |
|---|---|---|
| **City** | Formation help, training, member verification, bottleneck solving, resource requests; cross-boundary coordination; **customer pipeline**; materials allocation; weekly and monthly data review; incident support **[S: Ch.7]** | **The priority-5 organisation service fee — i.e. nothing until the venture is healthy** |
| **State** | City coaching and comparison, specialist deployment, bottleneck resolution, regional coordination, the **specialist pool**, state projects, escalation filtering, performance review **[S: Ch.6]** | Same, via City |
| **National** | Standards, constitution, platform, reserve custody, audit capability, CEO functions **[S: Ch.5, Ch.18, Ch.27]** | Same, plus residual surplus at priority 8 |

**[C]** `Cost(City + State + National)` is incurred from **Phase 1** — "Create CEO-led core national team and foundation" **[S: Ch.30]** — i.e. **before Phase 2 runs a single team**, while its revenue source is priority 5 of a venture that does not yet exist.

> **The centre is funded last and spent first.** This is the mirror image of the reserve problem, and it is why §31 is not a multiplication exercise.

**[A]** Nothing in the source resolves this. Phases 0 and 1 are validation and foundation-building **[S: Ch.30]**, which implies the founder bears those costs — consistent with Krytos ownership **[S: Const. Art.3]** — but no instrument, amount, cap or duration is stated, and v1.3-A N15 (custody of reserves and the social-impact fund) and N16 (bank mandates) remain UNRESOLVED. **§43 carries this forward as decision E-03 without closing it.**

## 8.7 Founder compensation at Mohalla level **[A]**

**[S: Ch.18 priority 4]** — "Founder compensation / approved cap — subject to approved cap and final structure."

1. The founder is a **Krytos / CEO-level** figure **[S: Ch.4; Const. Art.3]**, not a Mohalla role-holder. A single neighbourhood venture cannot fund a national founder; charging priority 4 per team would be economically absurd.
2. **[C]** Therefore priority 4 must operate on **aggregated** venture revenue at whatever level the final structure defines — venture, city or entity. **Which level is unresolved [V]**, carried to §43 as decision E-04.
3. **Why this matters to the unit model:** if priority 4 were applied per team, `S_5` would fall and reserves (priority 6) would fill later still. **This model assumes priority 4 applies above team level — marked [M], requiring approval, and flagged because the alternative moves every break-even line in §11.**

## 8.8 The illustrative percentages — used only as a labelled sensitivity **[M-ill]**

**[S: Ch.18; App. A §14.4]** — 37.5% worker compensation, 17% direct delivery costs, 12% organisation service fee: **"illustrative working assumptions only, not final organisational percentages… Final percentages, caps, multipliers and calculations require founder approval and professional validation."**

| Permitted use in this document | Prohibited use |
|---|---|
| Showing that the *arithmetic* behaves as described — e.g. `w_worker + w_direct + w_org = 66.5%`, leaving `33.5%` for dues, founder cap, reserves, social impact and surplus **combined** **[M-ill]** | Stating or implying that any team will pay 37.5% to workers |
| A sensitivity branch clearly labelled **[M-ill]**, always beside the symbolic form | Using them in a budget, a pitch, a recruitment conversation or a member payment sheet |
| Demonstrating that the residual for priorities 2, 4, 6, 7 and 8 **together** is a minority share **[M-ill]** — the analytically important point | Treating the split of that residual as known |

**[C] The one durable insight from the illustrative set:** if worker compensation, direct costs and the organisation fee together consume roughly two-thirds of gross **[M-ill]**, then statutory dues, founder cap, reserves, social impact and surplus must share roughly one-third — **and reserves sit behind two of those five claims.** So even in a *good* month, on illustrative numbers, the wage-protection buffer receives a small single-digit share. **[A]** That is a structural reason — independent of any real percentage — why reserves cannot be relied upon early, and why B-03 matters.

## 8.9 What the waterfall protects, and what it cannot

| Protected | Not protected |
|---|---|
| ✅ Worker compensation for **verified venture work** — priority 1 **[S]** | ❌ Service delivery (category A) — no revenue line |
| ✅ Statutory dues — priority 2 **[S]** | ❌ Governance and infrastructure (category D) — priority 5, deferrable |
| ✅ Direct costs of delivered customer work — priority 3 **[S]** | ❌ Training and capacity building (category E) — not payment-eligible **[S: Ch.19 step 1]** |
| ✅ The *order* itself, against discretionary capture — "THE PRIORITY ORDER IS THE CONTROL" **[S]** | ❌ The team's fixed existence cost (layer L1, §4.4) |
| ✅ Continuity, via reserves — priority 6 **[S]** | ❌ Continuity **early**, because reserves accumulate last (§8.5) |
| ✅ Mission funding from surplus — priority 7, restricted **[S: Ch.20]** | ❌ Mission funding **before** surplus exists |
| ✅ Bad-month behaviour: deferrable fees fall before worker pay is sacrificed **[S: Ch.18]** | ❌ A bad month with **no revenue at all** — there is nothing left to sequence |

**[A] Verdict on the waterfall:** it is the best-designed single component in the architecture (stress-test §24: **"Pass — the best single design in the document"**) and should be kept verbatim. Its limitation is not a design defect but a **scope** fact: it allocates venture receipts. **The economic-survival question is about everything the waterfall does not reach.**

---

# 9. ZERO-REVENUE MODEL

**Condition:** `V_gross = ₹0` for the whole period. **No revenue is assumed anywhere in this section.** Nothing is invented: the model computes *what stops* and *for how long* from explicitly stated assumptions.

## 9.1 What the source says happens at ₹0

| Source rule | Effect at ₹0 |
|---|---|
| `A_i = min(R_i, S_(i-1))` and `S_0 = 0` **[C from S: Ch.18]** | **Every allocation is zero.** `A_1 = A_2 = … = A_8 = 0` |
| "Deferrable organisational fees and social contributions fall before verified worker compensation is sacrificed" **[S: Ch.18]** | The rule is satisfied trivially — everything falls. **It provides no protection when there is nothing to protect** |
| "This does not mean workers can be promised money that does not exist" **[S: App. A §14.5]** | **The source itself forbids the expectation.** Recruitment language must match (§34) |
| "If a venture repeatedly cannot pay workers lawfully and sustainably, it must be restructured, paused or closed" **[S: App. A §14.5]** | **The stopping rule is the source's own** — used in §23, not replaced |
| Social-impact fund: "Not ordinary operating salaries. Not venture bailouts. Not political or religious activity" **[S: Ch.20]** | **The social-impact fund cannot be used to keep the team alive.** This closes the most tempting escape route |
| Reserve release: "National Funds Manager manages; release requires approval matrix"; SOP-10 flags "Personal request, **venture bailout**, missing approvals" **[S: Ch.18; SOP-10]** | **Reserves are not a team-level survival tool, and a venture bailout is an explicitly flagged abuse** |
| Weekly payment step 1: "Only approved tasks/projects/venture work are eligible" **[S: Ch.19]** | No venture work → no eligible work → **no payment, correctly and by design** |

> **[A] The critical honesty point:** at ₹0 revenue the architecture does **not** fail. It behaves exactly as designed — nothing is distributed, because nothing was earned. **The failure is human, not mechanical:** it is the gap between what a member was led to expect and what the system was ever designed to deliver (stress-test F-02, F-06).

## 9.2 What continues at ₹0

**[A]** Ranked by whether the activity needs cash:

| Continues | Why | Source |
|---|---|---|
| **Local observation and request intake** | Costs time only | **[S: Ch.8 step 1]** |
| **Verification of needs** | Time + possibly transport | **[S: Ch.8 step 4]** |
| **Time-costed service (categories 1–3 of §6.4)** — learning circles, tutoring, digital literacy, cleaning, plantation, donation sorting | Needs people and existing materials | **[S: Ch.15]** + B-02 |
| **Member recruitment, verification, probation** | Time only — but note it *adds* future cost (HC-01, HC-09) | **[S: Ch.12]** |
| **Training delivered internally by the State specialist pool** | Pool is a shared State resource | **[S: Ch.6]** |
| **Governance: records, reporting, reconciliation of a zero ledger** | **Continues in full — this is the cruel part.** `H_gov` does not fall when revenue does | **[S: Ch.24, Ch.19, App. F]** |
| **Safety doctrine, escalation readiness** | Must not lapse | **[S: Ch.16; v1.3-A A-08]** |
| **Business development: pipeline building, proposals** | Time only — and it is the *only* route out of ₹0 | **[S: Ch.17 steps 1–5; Ch.7]** |
| **Community trust building** | Time only; and it is the asset that later converts to customers **[I]** | **[S: Ch.25 "Community trust 10%"]** |

## 9.3 What stops at ₹0

| Stops | Why | Consequence |
|---|---|---|
| **All member and leader payment** | `A_1 = A_2 = 0` **[C]** | Anyone with an alternative leaves; research shows "too busy" and relocation dominate exit reasons **[X]** — money-motivated members leave first **[I]** |
| **Cash-purchased service materials** | No funds; social-impact fund unavailable **[S: Ch.20]** | Food and infrastructure categories stop (B-02) |
| **Paid specialists and subcontracted delivery** | Priority 3 unfunded | Skill-dependent ventures cannot be delivered |
| **Transport beyond walking distance** | `C_trans` unfunded; HC-03 becomes personal spending | Service area shrinks to the immediately walkable neighbourhood |
| **Certification and external training** | `C_train` unfunded, externally priced **[V]** | Regulated-domain eligibility lapses → restricted tasks blocked (v1.3-A A-10 §9.5) |
| **Insurance** | `C_ins` unfunded | **Protection activity must not run at all** (v1.3-A A-10 coverage-confirmation rule; A-11 gate) |
| **Paid software, AI usage, payment processing** | `C_sw`, `C_ai`, `C_pay` unfunded | Falls back to manual — which *increases* `H_gov` (HC-20) |
| **Reserve contribution** | `S_5 = 0` | The buffer stays at whatever it was — for a new team, zero |
| **Organisation service fee to City/State/National** | Priority 5 deferrable **[S]** | **The centre receives nothing from this team while still supporting it** |
| **Growth** | HC-09: growth is cash-negative | Recruitment should *stop*, not continue (§9.5) |

## 9.4 Month-by-month at ₹0

**[SC] Scenario Z — zero revenue throughout. Structure only; every quantity is a variable.**

| | **MONTH 0–1** | **MONTH 2–3** | **MONTH 4–6** |
|---|---|---|---|
| **Cash in** | `0` (plus any seeded float `F_0`, B-03/§9.6) | `0` | `0` |
| **Cash out (unavoidable)** | `C_comm + C_net + C_id×N_ver + C_print + C_pay(0)` — the *existence* cost L1 cash subset | Same, recurring | Same, recurring |
| **Cash out (discretionary, should be zero)** | `C_mat, C_trans, C_train, C_ai, C_space` | Must remain zero | Must remain zero |
| **What continues** | Formation, verification, first time-costed service, pipeline building, governance in full | Service continues if volunteer willingness holds; governance continues; **pipeline work is now the whole economic strategy** | Either a first venture closes, or the team is in §23 territory |
| **What stops** | Anything requiring cash | Paid specialists, transport beyond walking, certification | Growth, insurance-dependent activity, any remaining discretionary spend |
| **Who remains unpaid** | Everyone — correctly, since no venture work exists **[S: Ch.19 step 1]** | Everyone | Everyone |
| **What must be volunteer-based** | All service, all governance, all business development | Same, under rising strain | Same, at the limit of strain |
| **What can be deferred** | Materials, training, equipment, AI, workspace | Also: reporting depth (via §26 minimum viable control, *not* by skipping records) | Also: sub-role openings, growth, any capital item |
| **What reserves may be used for** | **Nothing** — SOP-10 flags "venture bailout" as an abuse **[S]**; and a new team has none | Nothing | Nothing |
| **What cannot be funded at all** | Insurance, certification, cash materials, paid specialists, transport | Same + any accumulated payable | Same + replacement of anything broken |
| **Dominant risk** | **Expectation mismatch** — members discovering there is no payment (F-02) | **Attrition of the paid-motivated and of the control roles** (F-03, F-04) | **Legitimacy loss** — the locality concludes the team is not real (§2.3) |
| **Human state [A]** | Enthusiasm; high goodwill | Goodwill eroding; first exits; "when does payment start?" | Either renewed energy from a first customer, or dissolution-level demoralisation |
| **Governance hours** | **Full** `H_gov` — it does not scale down with revenue | Full, plus the overhead of chasing exits and re-verifying | Full, plus §23 support processes if invoked |
| **Does the team survive?** | **Yes**, if float `F_0` covers L1 cash and expectations were honest | **Conditional** — survives on volunteer willingness, which is a depletable stock | **Only if** a venture has closed *or* an explicit support decision is taken (§23) |

## 9.5 What the team should do at ₹0 — and what it must not

**[P]**

**Should:**
1. **Stop recruiting.** Growth is cash-negative (HC-09) and each new member adds verification, training and coordination cost plus a new expectation.
2. **Shrink the operating scope, not the standards** — the stress test's own conclusion for Scenario A: "Run one team. Suspend the leaderboard, the weekly payment cycle, the vacancy catalogue and the state layer entirely. Keep only: verification, safety doctrine, two-signature money, six evidence records, one monthly report."
3. **Convert the whole economic effort to pipeline** — one anchored customer is worth more than ten prospects (§9.6, §18).
4. **Publish the truth about payment** before the first empty cycle, not after (§34, stress-test M16 earnings-reality rule).
5. **Keep service in the time-costed categories** (B-02), so the mission visibly continues while revenue does not.

**Must not:**
1. **Must not use the social-impact fund** — "not ordinary operating salaries… not venture bailouts" **[S: Ch.20]**.
2. **Must not treat reserve release as a survival route** — SOP-10 explicitly flags "venture bailout" **[S]**.
3. **Must not let members fund operations personally** (HC-03) — this creates debt-based loyalty, which the stress test identifies as an unhealthy retention mechanism.
4. **Must not soften evidence or verification standards** to save time — "small size never removes safety, HR verification, finance integrity or evidence duties" **[S: Ch.10]**. Reduction must come through the §26 minimum-viable-control route, which is *approved and recorded*, not informal.
5. **Must not count planned activity as impact** — "Do not count planned activities as completed impact" **[S: Ch.15]**. At ₹0 the temptation to inflate service output is at its maximum.

## 9.6 Runway: calculated, never invented

**[C]** Your brief forbids inventing a survival period. It is therefore **computed**:

> `M_runway = (F_0 + Reserve_available − L_min) / Burn_net`
>
> where
> `F_0` = seeded float at formation (**[M]** — B-03/§21; no source value)
> `Reserve_available` = `0` for a new team (§8.5)
> `L_min` = minimum unavoidable cash outflow per month (the L1 cash subset: `C_comm + C_net + C_id×N_ver + C_print` plus any committed `C_sw`, `C_ins`, `C_acct`)
> `Burn_net = L_min + C_discretionary_committed − V_collected`
> and at ₹0: **`M_runway = F_0 / L_min`**

**[C] The sizing rule for the float follows directly:**

> `F_0 ≥ M_target × L_min`  — i.e. **the float must be sized against the *minimum unavoidable cash cost*, not against the full cost stack**, because everything else can be deferred or volunteered at ₹0.

**[A] Three consequences that do not depend on any number:**

1. **`L_min` is small but non-zero, and it is *fixed*.** It does not fall when activity falls. So the runway is a simple division — and it is entirely determined by how much cash the team *must* spend to exist.
2. **The real runway constraint is not cash, it is volunteer willingness.** `F_0` can be topped up; goodwill cannot. **[I]** A team can be solvent and still dissolve. §12 and §15 model willingness as a depletable stock.
3. **`M_target` is a decision, not a calculation** — how many months of zero revenue the organisation is *prepared* to fund. It belongs in §43 as decision E-05, marked **[M]/[P]**, because the source contains no value and this document will not invent one.

**[P] Proposal B-04 — First-Season Float.** A capped, time-bound, explicitly accounted advance against future distributable amounts, available only to teams in months 1 to `M_target`, with: a hard cap; a fixed term; mandatory reconciliation against future distributable amounts; **one** renewal maximum with City sponsor sign-off; publication of float utilisation; and an absolute bar on using it to pay anything the waterfall would not pay (it may cover `L_min` and approved capability costs; it may **not** become a salary substitute or a venture bailout). Adopted from stress-test M5 with its controls intact. `PROPOSED — REQUIRES FINAL APPROVAL`; **[V]** for tax, accounting and entity treatment.

**[A] Honest caveat:** a float **is** a subsidy. Adopting B-04 moves the classification from **D** toward **C**, not toward **A** — and §46 says so rather than hiding it.

---

# 10. REVENUE SCENARIOS

**Naming rule:** every branch below is a **SCENARIO [SC]**. **None is a forecast.** "Required revenue" is model-derived and its formula is shown in full before the table.

## 10.1 Required revenue — the formula

**[C]** From §4.4 and §8.3, the *required* revenue for a period is the sum of what must be paid, in priority order, plus what must be set aside:

> `V_req = R_1 + R_2 + R_3 + R_4 + R_5 + R_6*`
>
> where
> `R_1 = C_wc` — compensation for verified venture work (formula unresolved **[S: Ch.33]**)
> `R_2 = C_stat` — statutory dues (**[V]**, classification unresolved)
> `R_3 = C_var` — direct costs of the delivered work **[S: App. A §14.3]**
> `R_4 = C_founder` — **assumed zero at team level (§8.7) [M]**
> `R_5 = C_org` — organisation service fee (deferrable **[S: Ch.18]**)
> `R_6* = ρ × S_5` — the *target* reserve contribution (**[M]**, `ρ` unresolved)
>
> **and, separately, the requirement the waterfall does not contain:**
> `V_req_total = V_req + C_L1 + C_L2_share + C_svc_cash`
> where `C_L1` is the existence cost (§4.4 L1), `C_L2_share` the team's share of capability cost, and `C_svc_cash` the cash cost of the service programme (§6.4, B-02).

**[A] Note what this formula exposes:** `V_req` — the amount the waterfall needs — is only part of `V_req_total`. **The difference `C_L1 + C_L2_share + C_svc_cash` is the unfunded gap identified in §8.4, expressed in rupees.** Every scenario below is run against **both**, because a team can satisfy `V_req` and still be unsustainable.

## 10.2 The eight scenarios

Let `x` be the fraction of `V_req_total` actually collected. Each row states what the waterfall does, mechanically, per §8.3.

| Scenario | `V_gross` | Waterfall result **[C]** | Solvency line reached (§8.3) | Operational state **[A]** |
|---|---|---|---|---|
| **SC-0** | `0` | All `A_i = 0` | **None** | §9 — existence only; service in time-costed categories; no payment to anyone |
| **SC-25** | `0.25 × V_req_total` | `A_1 = min(R_1, V_gross)` → **partial worker pay or full pay for fewer workers**; `A_2…A_8 = 0` | Below **S-1** | The worst political position: *some* work is verified but *not all* can be paid. Requires an explicit, published rationing rule (§12.5) |
| **SC-50** | `0.50 × V_req_total` | `A_1` likely satisfied; `A_2` partially; `A_3` at risk | **S-1**, approaching **S-2** | Workers paid, but direct costs of the *next* project are unfunded → the team cannot take new work without advancing costs |
| **SC-75** | `0.75 × V_req_total` | `A_1, A_2` satisfied; `A_3` satisfied; `A_5` partial | **S-3** | Delivery solvency reached. **The first genuinely operable state.** Still no reserve, still no centre funding, still `C_L1` unfunded |
| **SC-100** | `1.00 × V_req_total` | `A_1…A_5` satisfied; `A_6` begins | **S-4 / S-5** | Institutionally solvent: the centre is funded and a buffer begins. **`C_L1` is now covered — this is the first scenario in which the team truly pays for itself** |
| **SC-125** | `1.25 × V_req_total` | `A_6` accumulates; `A_7` may begin if surplus conditions are met **[S: Ch.18]** | **S-5**, approaching **S-6** | Resilience begins. First shock can be absorbed without a support request |
| **SC-150** | `1.50 × V_req_total` | `A_6` and `A_7` both live | **S-6** | Mission surplus: social-impact contribution becomes possible — with all Ch.20 restrictions intact |
| **SC-200** | `2.00 × V_req_total` | `A_8` residual surplus appears | **Above S-6** | Growth capital available. **But note the capacity constraint: this scenario is unreachable without more trained delivery capacity (§17), not merely more demand** |

## 10.3 What the scenario table actually shows

**[A] Four findings, none of which depends on a rupee value:**

1. **The jump from SC-75 to SC-100 is the important one, and it is not about profit.** At SC-75 the team can deliver and pay. At SC-100 it can *also* fund its own existence cost and the centre. **Everything below SC-100 requires an external contributor** — float, founder capital, City subsidy or donation (§9.6, §21, §22).
2. **SC-25 is the most dangerous scenario, not SC-0.** At ₹0 everyone knows the position. At 25% the team must decide *which* verified workers to pay — a decision with no rule in the source and enormous fairness and trust consequences. **§12.5 proposes one; it is the single most urgent policy gap this model found.**
3. **SC-150 and SC-200 are capacity-limited, not demand-limited.** `P_max` (§17) caps deliverable projects; `r_close` and `h_acq` (§18) cap acquisition; and **[S: App. A §13.5]** permits scaling only with "sufficient trained people". **A team cannot sell its way to SC-200.**
4. **No scenario is a target.** Setting "reach SC-100 by month 6" would be exactly the optimistic-startup projection your brief forbids. The scenarios are a **diagnostic scale**: given the month's actual `V_gross`, the team and City can locate the month, know what the waterfall will and will not do, and know which decisions become live.

## 10.4 Scenario discipline

**[P]** Three rules for using §10.2 honestly:

1. **Report the scenario reached, never the scenario hoped for.** The weekly report **[S: Ch.19 step 12]** should state which solvency line was crossed, so "we had a good month" becomes a checkable claim.
2. **Never present a scenario externally as a projection.** Recruitment, partnership and public statements must use the earnings-reality rule (stress-test M16) and v1.3-A A-07's under-claiming posture.
3. **Re-run the scenarios whenever `V_req_total` changes** — which happens when `H_gov` is measured (§25), when `K` changes (§31.2), or when classification is resolved **[V]**. The scenario table is a function, not a fixture.

---

# 11. BREAK-EVEN ANALYSIS

## 11.1 Definition

> **MOHALLA BREAK-EVEN REVENUE** is the gross revenue `V_gross` at which a stated obligation set is fully satisfied by the waterfall in the period, with nothing carried into a hole the next period cannot fill.

**[C]** Because the obligation set differs by purpose, **there is not one break-even.** Your brief requires four; the model derives four from the six solvency lines of §8.3.

## 11.2 The four break-even lines

### B_bare — Bare Survival Break-Even
> *Minimum needed to continue operating.*

**[C]**
```
B_bare = L_min
       = C_comm + C_net + C_id×N_ver + C_print + C_sw_committed + C_ins_committed + C_acct_committed
```
- Covers: the **unavoidable cash cost of existing** (§4.4 L1 cash subset).
- Does **not** cover: any worker payment, any direct cost, any service material, any training, any reserve.
- **Meaning:** at `V_gross = B_bare` the team can keep its phones, its records and its compliance alive. **It cannot pay anyone and cannot deliver anything that costs money.**
- **Source note:** even this is *not* funded by the waterfall, because none of it is a venture direct cost. It is the float's job (§9.6).

### B_healthy — Healthy Operating Break-Even
> *Minimum needed to operate reliably.*

**[C]**
```
B_healthy = R_1 + R_2 + R_3 + C_L1 + C_L2_share
          = C_wc + C_stat + C_var + C_L1 + C_L2_share
```
- Covers: **worker solvency + legal solvency + delivery solvency (§8.3 S-3) + existence cost + capability cost.**
- This is the first line at which the team is *not being subsidised* on a current basis.
- It corresponds to **SC-100** in §10.2, and it is the line that answers your Part 31 question (§32).
- **Does not cover:** reserves, the organisation service fee, social impact, or any shock.

### B_growth — Growth Break-Even
> *Minimum needed to grow capacity.*

**[C]**
```
B_growth = B_healthy + R_5 + C_growth
where C_growth = C_train×N_new + C_verify×N_new + C_recruit×N_new + C_id×N_new + ΔC_gov
```
- Covers everything in `B_healthy`, **plus** the organisation service fee (priority 5) **plus** the full cost of adding a member.
- **[A] The critical term is `ΔC_gov`:** adding a member adds governance hours (GC-01, GC-02, GC-03, GC-10) *before* it adds delivery capacity. Growth therefore raises break-even **faster than it raises capacity** unless `c` (functions per person) and the City divisor both improve (§13.5, §31.2).
- **This is why HC-09 says growth is cash-negative early**, and why §13 gates growth on contribution per head.

### B_resilient — Resilient Break-Even
> *Minimum needed to absorb ordinary shocks.*

**[C]**
```
B_resilient = B_growth + R_6 + E_shock
where R_6 = ρ × S_5                     (reserve contribution, ρ unresolved [M])
      E_shock = expected monthly shock cost = Σ p_j × C_j  over the HC-* register
```
- Covers everything in `B_growth`, **plus** the reserve contribution **plus** the expected value of the shock register (§5.2: HC-03, HC-04, HC-05, HC-06, HC-10, HC-12, HC-13, HC-15, HC-16, HC-21).
- **[A] `E_shock` is the term most often omitted from small-unit models,** and it is the one that decides whether a good month is actually good. A team at `B_growth` with no shock allowance will be knocked below `B_healthy` by the first dispute, breakage or delayed payment.
- Reaching `B_resilient` is what makes **S-5** true, and it is the precondition for §22 cross-subsidy model C (a team that can contribute to a central pool).

## 11.3 The four lines compared

| | `B_bare` | `B_healthy` | `B_growth` | `B_resilient` |
|---|---|---|---|---|
| Workers paid | ❌ | ✅ | ✅ | ✅ |
| Statutory dues | ❌ | ✅ | ✅ | ✅ |
| Direct delivery costs | ❌ | ✅ | ✅ | ✅ |
| Existence cost `C_L1` | ✅ (cash subset only) | ✅ | ✅ | ✅ |
| Capability cost `C_L2` | ❌ | ✅ | ✅ | ✅ |
| Organisation service fee | ❌ | ❌ | ✅ | ✅ |
| New-member cost | ❌ | ❌ | ✅ | ✅ |
| Reserve contribution | ❌ | ❌ | ❌ | ✅ |
| Expected shock cost | ❌ | ❌ | ❌ | ✅ |
| Solvency line (§8.3) | none | **S-3** | **S-4** | **S-5** |
| Scenario (§10.2) | between SC-0 and SC-25 | **SC-100** | between SC-100 and SC-125 | **SC-125+** |
| Who bears the remainder | Float / founder / City | Nobody — self-funding | — | — |

**[C] Ordering:** `B_bare < B_healthy < B_growth < B_resilient`, strictly, because each adds non-negative terms. **The multiple between `B_bare` and `B_resilient` is the single most important ratio in the model** — and it cannot be computed until `C_wc`, `C_stat`, `ρ`, `H_gov` and `E_shock` are measured. **That is a pilot deliverable (§40), not an estimate.**

## 11.4 Contribution form (the version a team can actually use)

**[C]** Per project `j`, define contribution:

```
CM_j = P_price_j − C_var_j − C_wc_j − C_stat_j
```

Then, with `P` projects delivered and collected in the month:

```
V_gross = Σ P_price_j
Break-even volume:  P_be = (C_L1 + C_L2_share + C_fixed_gov_cost) / CM̄_j
```

where `CM̄_j` is average contribution per project. **[A] This is the only form of break-even a Mohalla team can reason about without accounting support**, because it needs three numbers it can see: what a project pays, what it costs to deliver, and what the month costs regardless.

**[A] And it exposes the real risk:** if `CM̄_j` is small — which it is for category 4 (design/editing) and category 6 (local business technology), the two lowest-barrier categories in §7.1 — then `P_be` is **large**, and a small team cannot deliver that many projects because `P_max` (§17) is capped by hours. **The easiest categories to enter are the hardest to break even in.** That is a genuine structural tension, and §19 makes it an explicit selection criterion rather than letting a team discover it.

## 11.5 What break-even does NOT mean here

**[A]** Four clarifications, to prevent the numbers being misused:

1. **Break-even is not viability.** It says nothing about whether the hours were available, whether the members stayed, or whether the service happened. §28 exists because a single score would hide those.
2. **Break-even is per period, not cumulative.** A team can break even monthly and still be dying from an accumulated receivable or an unreplaced member.
3. **Break-even excludes legitimacy capital.** A team can hit `B_healthy` in the month it publishes a beneficiary's identity (v1.3-A A-19) and destroy its ability to earn anything next month.
4. **Break-even is not a target to be optimised.** Optimising for it produces exactly the harmful incentives §35 catalogues — easy projects over difficult needs, revenue over service.

---

# 12. WORKER COMPENSATION TEST

## 12.1 The principle under test

> **[S: Ch.18 priority 3 row]** "Worker compensation — **Verified work protected ahead of deferrable allocations**, subject to law and final structure."
> **[S: Ch.18 control table]** "Bad-month behaviour — **Deferrable organisational fees and social contributions fall before verified worker compensation is sacrificed**, subject to law and final structure."
> **[S: App. A §14.5]** "This does not mean workers can be promised money that does not exist; it means the waterfall should not divert money to lower-priority pools while verified worker compensation and mandatory dues remain unpaid."
> **[S: Ch.25 dimension]** "Financial discipline 15% — **Money integrity and worker payment trust.**"

**[A]** Your brief's instruction is explicit: **do not weaken the worker-first principle merely to make the numbers work. If the economics cannot support it, identify the structural problem.** That is what this section does.

## 12.2 The structural problem, stated first

**[C]** The principle is a **priority rule**, not a **guarantee**. Priority determines *who is paid first when there is something to pay*. It has no operation when `V_gross = 0`, and only partial operation when `V_gross < R_1`.

> **The worker-first principle protects the distribution of scarcity. It does not create the money.**

**[A]** Three consequences follow, and none of them is a criticism of the principle:

1. **The principle is unconditionally correct as a sequencing rule** and should be kept verbatim. Every alternative — paying the organisation fee before workers, or bailing out a venture from the social-impact fund — is worse and is already forbidden **[S: Ch.18, Ch.20]**.
2. **The principle is silent on the case that actually threatens a new team**, which is not "we have money and might spend it wrongly" but "we have no money." That case is governed by `M_runway` (§9.6), not by priority.
3. **Therefore the principle needs a companion instrument, not a modification.** The companion is a **scarcity rule**: what happens when `0 < V_gross < R_1`. The source does not contain one, and §12.5 proposes one.

## 12.3 The seven stress conditions

**[SC]** Each row is a scenario. `V_gross` is the collected amount for the period; `R_1` is compensation owed for verified work.

| # | Condition | Waterfall mechanics **[C]** | Can worker-first be honoured? | What actually breaks **[A]** |
|---|---|---|---|---|
| **1** | **Full revenue month** (`V_gross ≥ B_healthy`) | `A_1 = R_1` in full; `A_2, A_3` satisfied; `A_5` may be satisfied | **Yes, fully** | Nothing. But note: reserves still accumulate slowly because priority 6 sits behind 4 and 5 (§8.5) |
| **2** | **Weak month** (`R_1 + R_2 + R_3 ≤ V_gross < B_healthy`) | `A_1 = R_1` full; `A_5 = 0` (deferrable); `C_L1` unfunded | **Yes for venture workers** | The **existence cost** — phones, data, records, compliance — competes with nothing in the waterfall and is simply unpaid. This is the invisible failure |
| **3** | **Delayed customer payment** (`invoiced ≫ collected`) | `V_gross` is defined by the final accounting policy as receipts **or** invoiced **[S: App. A §14.3]** — **and the choice determines whether workers can be paid** | **Depends on an unresolved accounting policy [V]** | If receipts-basis: verified work is unpaid through no fault of the worker. **This is the single most damaging routine event in the model** — the member did the work, the customer holds the cash |
| **4** | **Customer default** (`V_gross` never arrives for delivered work) | `A_1 = 0` for that project's workers; direct costs already sunk | **No** | The team has paid to work (HC-05, HC-06). Compensation was *earned* and cannot be *funded*. **A promise was made to the worker at assignment and broken at collection** |
| **5** | **Unexpected direct cost** (`C_var` spikes mid-period) | Priority 3 sits **below** priority 1, so `A_1` is protected — but `A_3` may be unfunded, meaning the *next* delivery cannot be paid for | **Yes, this period** | The waterfall works exactly as designed. **The damage is deferred to next period's capacity** (§17) |
| **6** | **Negative month** (`C_var + C_L1 > V_gross`) | `A_1` may still be payable if `V_gross ≥ R_1`, but the team's cash position falls | **Technically yes** | Cash declines while obligations hold. Two consecutive negative months consume any float (§9.6) |
| **7** | **Temporary business shutdown** (venture paused per **[S: Ch.14 business failure — "Pause/close venture"]**) | `V_gross = 0` → all `A_i = 0` | **No — correctly, per [S: Ch.19 step 1]** | Members who joined for the venture income have no income and no alternative inside the team. **Retention outcome depends entirely on whether a non-monetary reason to stay exists** (stress-test §10: Purpose / Proof / Livelihood / Building doors) |

## 12.4 The worst case: work delivered, cash not collected

**[A]** Conditions 3 and 4 deserve isolation because they are the only cases where the worker-first principle **fails through no fault of the organisation's intentions**:

```
Work assigned → work performed → work verified [S: Ch.19 step 2] → compensation accrued
                                                                   ↓
                                    customer does not pay [S: Ch.17 steps 10–11]
                                                                   ↓
                                    V_gross = 0 → A_1 = 0 → verified worker unpaid
```

**[C]** The architecture is internally consistent here — nothing was diverted, priorities were respected, the social fund was not raided **[S: Ch.20]** — and yet the outcome is that **a person who did verified work was not paid.** Stress-test F-06 names the consequence: "Unpaid labour inside an organisation that publicly promises transparent compensation — a reputational and potentially legal exposure **[V]**."

**[P] Proposal B-05 — Accrued Compensation Ledger.** Where work is verified but revenue is not collected, the compensation is **recorded as an accrued, aged, published obligation of the venture** — not written off, not forgotten, not converted into a gift. Rules: (i) the accrual is visible to the worker on their own dashboard **[S: Ch.24 Member dashboard already includes "earnings"]**; (ii) it ages and is reported in the weekly report **[S: Ch.19 step 12]**; (iii) it is settled from the *next* collected revenue of that venture **at priority 1**, ahead of new work's compensation, so a recovering venture repays its debt before it grows; (iv) it is capped, and once the cap is reached **no further work may be assigned on credit terms without City approval**; (v) it is never presented to a member as a promise of payment, only as a record of an obligation whose settlement depends on collection. `PROPOSED — REQUIRES FINAL APPROVAL`; **[V]** for accounting treatment, employment-law characterisation and tax.

**[A] Why this is not weakening the principle:** it *strengthens* it. Priority 1 currently applies within a period; B-05 extends it **across** periods, so a bad month cannot erase an earned claim. And condition (iv) converts an unlimited hidden liability into a bounded, approved one.

## 12.5 The scarcity rule the source does not contain

**[A]** When `0 < V_gross < R_1`, someone verified is not paid. The source gives no rule. **[P] Proposal B-06 — Pro-Rata Verified-Work Rule:**

1. **All** verified workers in the period share the available `A_1` **pro rata to verified work value**, rather than the earliest or loudest being paid in full.
2. **No role-holder may exclude themselves from the pro-rata reduction and still approve it** — the Leader and Funds Manager take the same proportional reduction. (This is the fairness condition; without it the rule is a mechanism for the powerful to be paid first.)
3. **The reduction, its cause and the accrued balance are published to the team in the same period**, per the source's transparency discipline **[S: Ch.19 step 12; Ch.24]**.
4. **The accrued balance is carried per B-05** and settled at priority 1 from the next collection.
5. **The rule is triggered by arithmetic, not by discretion:** it applies automatically whenever `V_gross < R_1`, and its application is recorded.
6. **Statutory dues are never reduced by this rule.** `R_2` remains at priority 2 **[S]** and **[V]** applies.

`PROPOSED — REQUIRES FINAL APPROVAL`; **[V]** for labour-law lawfulness of pro-rata reduction and for any minimum-wage or timely-payment obligation that may make partial payment unlawful outright — **in which case the correct answer is that the venture must not have assigned the work, which is condition (iv) of B-05.**

## 12.6 Three absolute rules for the compensation system

**[P]** Derived from the source and from the failure modes, and deliberately stated as absolutes because they are the ones most likely to be bent under pressure:

1. **A member is never expected to fund operations personally.** HC-03 (emergency transport) is the most common breach. Personal spending creates debt-based loyalty, which the stress test identifies as an unhealthy retention mechanism and which v1.3-A's manipulation prohibitions forbid.
2. **Compensation is never recruited on before it is collectable.** The earnings-reality rule (stress-test M16): what is said at recruitment must be what the waterfall can actually deliver in the *weak* month, not the good one. "Workers can[not] be promised money that does not exist" **[S: App. A §14.5]**.
3. **The cadence may change; the priority order and the transparency may not.** Moving from weekly to fortnightly or monthly distribution for a team below `B_healthy` (HC-17, stress-test R2) alters *frequency* only. What must survive any change is: verified-work-first, published calculation, challengeable errors, and an audit trail **[S: Ch.19 steps 6, 7, 12, 13]**.

## 12.7 Verdict on the worker-first principle

| Question | Answer |
|---|---|
| Can the organisation preserve worker-first in a **full** month? | **Yes** — trivially **[C]** |
| In a **weak** month? | **Yes for venture workers**, but the existence cost `C_L1` goes unpaid and is invisible (§12.3 row 2) |
| In a **zero** month? | **The principle has no operation.** There is nothing to sequence. Survival depends on `M_runway` (§9.6), not on priority |
| When payment is **delayed**? | **At risk — and the risk is created by an unresolved accounting policy [V]**: receipts-basis vs invoiced-basis **[S: App. A §14.3]** |
| When a customer **defaults**? | **No.** Verified work goes unpaid. **This is the structural problem, and B-05 is the instrument that addresses it without weakening the principle** |
| Should the principle be weakened? | **No.** It is the architecture's best feature (stress-test §24). It needs a **companion scarcity rule (B-06)** and a **cross-period accrual (B-05)**, not a dilution |

**[A] The honest structural finding:** *worker-first is a rule about the division of a surplus. A new team has no surplus. The economic-survival question is therefore not "can we protect workers' share?" but "can we create a share to protect?" — and the answer depends on `CM̄_j`, `P_max` and `C_L1`, none of which the source supplies.*

---

# 13. FIRST SIX MONTHS

**Rule:** no number is fabricated. Every cell is a **variable**, a **formula**, a **[SC]** branch or a structural statement. The month-by-month grid is the *instrument* the pilot fills in (§40), not a set of predictions.

## 13.1 The survival grid

Columns are exactly as your brief specifies. Rows are the six months.

| Month | Team capacity | Revenue | Costs | Worker compensation | Reserve | Service output | Cash position | Risk |
|---|---|---|---|---|---|---|---|---|
| **M1** | `N_ver` verified; `N_roles_min = ⌈f/c⌉` with `f = 9` **[S: Ch.10]**; `H_avail = N_act × T_avail`; `H_gov` **full from day one** (§25); `P_max = 0` — no approved venture yet **[S: Ch.17 step 3 approval required]** | `V_gross = 0` **[SC]** | `C_L1` cash subset + formation cost `C_form` (verification, ID, training, first materials) | `A_1 = 0` — no eligible venture work **[S: Ch.19 step 1]** | `0` — priority 6 unreachable (§8.5) | Time-costed categories 1–3 only (B-02); `H_svc` limited by formation load | `F_0 − C_form − C_L1` | **Expectation mismatch** (F-02); verification backlog; role combination strain (F-03) |
| **M2** | Same people; `H_gov` still full; first training completed; `P_max` still gated on venture approval | `0`, or first `V_gross` if a venture was approved and closed | `C_L1` + `C_train` + `C_acq` (all hours) | `A_1 = 0` or first small `A_1` | `0` | First completed service project with outcome verification **[S: Ch.15 step 10]** | Falling | **First empty payment period** if expectations were set wrong; attrition of money-motivated joiners |
| **M3** | Capacity *effectively* lower than M1 despite same headcount — churn (HC-01) plus learning curve; `r_act` falls | Small, lumpy **[I]** | `C_L1 + C_var` (first delivery) + `C_acq` | First real `A_1`; **B-06 scarcity rule may trigger** | `0` | Service continues; **first tension between `H_svc` and `h_proj`** (§6.3) | Lowest point **[A]** | **The trough.** Cash and goodwill are both at minimum. HC-15 seasonality can coincide |
| **M4** | Stabilising if M3 was survived; `P_max` becomes the constraint rather than approval | Rising if the pipeline converted; flat if not | `C_L1 + C_var + C_train` (re-certification, HC-12) | `A_1` regular; first `A_2` | `0` or first `ρ × S_5` if `S_5 > 0` | Service hours must now be *budgeted* (B-01) or they will be silently cut | Recovering or flat | **Capacity ceiling** (§17): demand may now exceed trained delivery |
| **M5** | Coordination cost rises with activity (GC-09, GC-10); first Coordinator openings considered **[S: Ch.10]** | `x × V_req_total` — locate the scenario (§10.2) | `C_L1 + C_var + C_L2 + ΔC_gov` | `A_1` full; `A_3` full | First real accumulation if `B_resilient` approached | Service output is now a *choice* between mission and cash (§35) | Positive if `≥ B_healthy` | **Growth temptation** — HC-09: adding people now raises break-even faster than capacity |
| **M6** | State A → State B decision point **[S: Ch.10]**; autonomy readiness gates assessable **[S: Ch.13]** | Locatable on the §10.2 scale | Full stack minus deferred items | `A_1` full; **B-05 accruals settled first** if any exist | `A_6` live only if `S-5` reached | Service + venture both running, or one has been sacrificed | `F_0` exhausted or replenished | **The assessment month.** Either §30 Stage 2 is evidenced, or §23 support is invoked |

**[A] The shape of the six months is knowable without any numbers:** cost is **front-loaded and flat**, capacity is **gated by approval and training rather than by willingness**, revenue is **back-loaded, lumpy and uncertain**, and cash therefore has a **trough at M3** whose depth is `C_form + 3 × C_L1 − (collections by M3)`. **The float must be sized for the trough, not the average (§9.6).**

## 13.2 What gates each month

**[C]** Derived from the source's own lifecycle, not invented:

| Month | Gate that must be passed | Source |
|---|---|---|
| **M1** | Members **verified** — "Membership is not automatic; application starts a verification process" | **[S: App. A §1.1; Ch.12]** |
| **M1–M2** | Roles filled by "verified members or approved combined-role holders" | **[S: Ch.13 autonomy gate — Membership]** |
| **M2** | **Venture approved** — "Approval tier based on category, risk, money, data and novelty" | **[S: Ch.17 step 3]** |
| **M2–M3** | Business setup complete — "Scope, price, timeline, acceptance criteria, data/IP/confidentiality terms" | **[S: Ch.17 step 4]** |
| **M3** | **First full project cycle** — "request, verification, execution, evidence and report" | **[S: Ch.13 autonomy gate — Operations]** |
| **M3–M4** | Reconciled records "with no unexplained material gaps" | **[S: Ch.13 autonomy gate — Finance]** |
| **M4** | Trained Safety Lead; no unresolved serious safety breach | **[S: Ch.13 autonomy gate — Safety]** |
| **M5** | Approved customer work "priced, delivered and recorded where ventures exist" | **[S: Ch.13 autonomy gate — Business]** |
| **M6** | Readiness audit or corrective-action review passed | **[S: Ch.13 autonomy gate — Audit]** |

**[A] Note the ordering:** the **safety** gate and the **finance** gate arrive at M3–M4, i.e. *before* the team is likely to be economically stable. That is correct — the stress test's institutionalisation table says only Safety and Finance must be institutional early "because their failure is irreversible" — but it means **M3–M4 carries the highest combined load of financial trough and control formalisation.** That is the hardest window in the six months, and the pilot should be designed to measure it specifically (§40).

## 13.3 Decision points the six months force

**[P]** Each is routed to §43 rather than answered here:

| Month | Decision | Why it cannot be deferred |
|---|---|---|
| **Before M1** | Float size `F_0` and term `M_target` (B-04) | The team cannot form without it (§9.6) |
| **Before M1** | Payment cadence to be used and **disclosed** (HC-17, §12.6 rule 3) | Recruitment language must match reality (M16) |
| **M1** | Which venture category (§19 framework) | Approval is a gate on revenue (M2) |
| **M2** | Whether to recruit more members | HC-09 — growth is cash-negative; the default answer at ₹0 is **no** (§9.5) |
| **M3** | Whether to invoke B-05/B-06 | First empty or partial period |
| **M4** | Whether service hours are being silently cut (B-01) | The cross-subsidy becomes visible or invisible here |
| **M5** | Whether to open sub-roles **[S: Ch.10 State B]** | Deputies cost governance before they earn revenue |
| **M6** | Continue / support / restructure, per **[S: Ch.14 step 9 "Continue, support, restructure or replace"]** | The source's own reassessment step |

## 13.4 Three six-month scenarios

**[SC]** Structure only. **None is a forecast.**

| | **SC-A: Anchored** | **SC-B: Unanchored** | **SC-C: Service-heavy** |
|---|---|---|---|
| **Precondition** | One contracted revenue source signed **before** launch (stress-test M5-iii) | No contracted source; cold acquisition from M1 | High local need, low payable demand |
| **M1–M3 revenue** | `V_gross > 0` from month 1–2 | `≈ 0` through M3 | `≈ 0` throughout |
| **Cash trough** | Shallow — collections begin before `F_0` is consumed | **Deep at M3** — `F_0 / L_min` decides survival | Deep and *permanent* without subsidy |
| **Worker compensation** | First `A_1` at M2–M3 | First `A_1` at M4–M6, if at all | **Never, for service work** (§8.4) |
| **Service output** | Moderate — squeezed by delivery hours (§6.3) | Low early, rising after M4 if the team survives | **High** — this team delivers the mission |
| **Human trajectory [A]** | Transactional culture risk: stress-test Scenario A warns that "culture formed under monetary framing resists re-framing" | Attrition at M2–M3 of money-motivated joiners; survivors are mission-motivated | High commitment, high burnout risk, no income |
| **M6 position** | Approaching `B_healthy`; **but mission balance must be checked** (§35) | At or below `B_bare`; §23 support decision live | **Below `B_bare` on cash, above every mission metric** — §31/§32 asks who should fund it |

**[A] Which is best?** None is "best". SC-A is the most *solvent*; SC-C is the most *mission-faithful*; SC-B is the most likely default and the most likely failure. **The design question is whether an SC-A team can be kept mission-faithful and an SC-C team can be kept solvent** — §22 and §37 address exactly that.

## 13.5 The growth rule the six months imply

**[P] Proposal B-07 — Contribution-Gated Growth.** A team may add members or open sub-roles only when **both** hold:

1. `V_gross ≥ B_growth` (§11.2) for `n` consecutive periods, where `n` is approved **[M]**; **and**
2. `CM̄_j / h_proj` — contribution per *delivery hour* — is not falling, so growth is not being bought by accepting worse work; **and**
3. Concentration limits are met: no single customer above a stated share of `V_gross`, no single revenue category above a stated share, no single leader as the only holder of a critical skill (HC-24).

**Rationale [A]:** the source already gates growth on need — "Open new vacancies where workload/risk/continuity need justifies" **[S: Ch.13 step 5]** and "Vacancies must be need-based, eligibility-based and RBAC-limited" **[S: Ch.10]**. B-07 adds the **economic** half of the need test, which the source leaves implicit. It does not restrict service-driven growth of *volunteers*, only of *funded positions*. `PROPOSED — REQUIRES FINAL APPROVAL`.

---

# 14. TEAM-SIZE SENSITIVITY

**Rule:** no fixed member count is assumed, because **"Minimum staffing thresholds — NOT FINAL — Define by level/risk after pilots; no final numbers invented" [S: Ch.33]**. Size classes are therefore derived from the source's own **staffing states [S: Ch.10]**, and every quantity is a variable.

## 14.1 The four size classes

| | **T1 — Very small starter** | **T2 — Small operating** | **T3 — Growing** | **T4 — Mature autonomous** |
|---|---|---|---|---|
| **Source state** | STATE A, minimum **[S: Ch.10]** | STATE A, complete | STATE B | STATE C |
| **Source description** | "compatible roles may be combined" | all 9 functions separately held | "Sub-… opened as vacancies where needed" | "Manager → Sub-Manager → Coordinators → Supporting Members in each major function" |
| **Headcount variables** | `N_ver` minimal; `N_roles = ⌈9/c⌉` with `c` at its maximum | `N_roles = 9`; `N_act` small | `N_roles = 9`, `N_sub > 0` | `N_roles = 9`, `N_sub ≈ 9`, `N_coord > 0` |
| **Segregation of duties** | **Cannot be satisfied internally** — at least one finance function must sit outside the team (§3.3) **[C]** | Satisfiable if the four finance hands are distinct | Satisfiable with deputies | Fully satisfiable |
| **`H_gov` total** | Lowest in absolute terms | Rising | Rising faster (GC-10 coordination grows with `N_roles`) | Highest absolute, **lowest per head** |
| **`H_gov` per head** | **Highest** | High | Medium | Lowest |
| **Service capacity** | Very limited; time-costed categories only | Modest | Growing | Substantial, and Coordinators make it schedulable |
| **Business capacity `P_max`** | ~0–1 projects; approval and skill gated | 1–few | Several, if trained people exist | Constrained by trained delivery people, not by structure |
| **Revenue requirement** | `B_bare` only — nobody is being paid | `B_bare` + first `R_1` | `B_healthy` | `B_growth` or `B_resilient` |
| **Coordination requirement** | Trivial | Low | **Rising steeply** — this is where teams break | High, but *structured* (Coordinators own workstreams) |
| **Leadership requirement** | One person holding several functions | One Leader + emerging Sub-Leader | Leader + Sub-Leader + Coordinators | Full ladder with succession readiness **[S: Ch.26]** |
| **Failure risk** | **Role-holder loss** — one exit disables multiple functions (HC-02) | **Cash trough** (§13) | **Coordination collapse** and growth-before-revenue (HC-09) | **Bureaucratic drift** — governance consuming the unit it governs (HC-22) |
| **Cost per member** | **Highest** | High | Medium | Lowest |
| **Cost per service activity** | Highest | High | Medium | Lowest — but with the risk that activity becomes *process* |

## 14.2 The two curves that decide everything **[C]**

**Curve 1 — governance cost per head falls with size:**
```
H_gov(N) ≈ H_gov_fixed + h_gov_var × N
H_gov per head = H_gov_fixed / N + h_gov_var
```
`H_gov_fixed` is large because the nine functions and the 22 SOPs must exist regardless of size **[S: Ch.10 State A control; App. D]**. **So per-head governance cost falls hyperbolically — and the fall is steepest at small N.**

**Curve 2 — revenue capacity rises with size, but only up to `P_max`:**
```
P_max(N) = ( N_paid × (T_avail − T_gov_per_head) − H_acq − H_svc ) / h_proj
V_capacity = P_max × P_price × r_collect
```

**[C] The viability condition is where curve 2 crosses `B_healthy` from §11.2:**
```
P_max(N) × CM̄_j  ≥  C_L1 + C_L2_share + H_gov(N) × cost_per_hour
```

**[A] Three results follow, and they are the analytical core of this section:**

1. **There is a minimum viable team size `N_min`,** below which `H_gov_fixed` consumes so much of `T_avail` that `P_max` cannot generate `CM` sufficient to cover `C_L1`. **`N_min` is computable but not computable yet** — it needs `H_gov_fixed` (measured in the pilot, §25) and `CM̄_j` (measured per venture category, §19). **This document does not invent it.**
2. **`N_min` falls sharply when governance is shared.** Replacing `H_gov_fixed` with `H_gov_fixed / K` for `K` teams sharing a City function (§26, §31.2) is the single most powerful lever in the model — more powerful than any revenue improvement, because it acts on the fixed term.
3. **There is also a maximum useful size `N_max` per Mohalla,** above which coordination cost (GC-10) and the loss of local knowledge outweigh capacity — and the source already implies it, since the layer above is the City **[S: Ch.7]** and the architecture's answer to growth is *more teams*, not bigger teams (stress-test §26: fine to ~1k–5k members; ~100k needs a professional institutional layer). **Growing a Mohalla team past `N_max` converts a community unit into a small firm, which is not what the architecture describes.**

## 14.3 Sensitivity of the conclusion to size

| If the pilot measures… | Then **[C]** |
|---|---|
| `H_gov_fixed` **low** (near the bottom of the stress test's 8–40 band) | `N_min` is small; T1 teams are viable; the architecture works roughly as written |
| `H_gov_fixed` **high** (near or above the top of the band) | `N_min` is large; **T1 is not viable at all**; only T3/T4 teams with City sharing can exist — and the "start small" instruction **[S: Ch.13]** becomes economically false |
| `CM̄_j` **high** (skill-intensive categories 1–3) | `N_min` falls; but skill supply becomes the constraint (§17) and `r_close` falls (§18) |
| `CM̄_j` **low** (categories 4, 6) | `N_min` rises sharply; `P_be` (§11.4) becomes unreachable at small size |
| `r_collect` **low / `Δt_collect` long** | The cash trough deepens and lengthens; `F_0` must rise; B-05 accruals accumulate (§12.4) |
| `r_act` (active ratio) **low** | Effective `N` is much lower than `N_ver` — **so `N_ver` is the wrong planning variable.** The stress test used 30–50% active early **[A-assumption]**; at 15% "every capacity figure worsens by ~2×" |

**[A] The last row deserves emphasis:** the architecture reports **member counts** and the leaderboard already warns against counting them — "Volunteer counts → Verified members/approved participants only; attendance cross-checked" **[S: Ch.25]**. **Economically, the only count that matters is `N_act × T_avail`, and that is a monthly measured quantity, not a register entry.**

## 14.4 What size policy follows

**[P]**
1. **Do not set a minimum member count now.** **[S: Ch.33]** forbids inventing one, and §14.2 shows the right minimum is a *derived* quantity.
2. **Do set a minimum *role-coverage* count now:** the nine State A functions must be covered, with the four finance hands distinct, at least one of which may sit at City level (§3.3). This is derivable from source **[S]** and does not require a number to be invented.
3. **Plan on `N_act`, not `N_ver`.** Every capacity, cost and revenue figure in this model is expressed in `N_act`.
4. **Prefer more small teams over fewer large ones, above `N_max`** — consistent with the Mohalla/City design **[S: Ch.7, Ch.8]** — but only where `K` is large enough to make City sharing economical (§31.2). Below that `K`, the opposite is true, and that tension is real and unresolved (§43 E-11).

---

# 15. VOLUNTEER ECONOMICS

> **Rule from your brief, adopted absolutely:** the organisation must never use *"they are volunteers"* as a reason to ignore operational cost.

## 15.1 Why volunteer labour is not free **[S]**

The architecture itself imposes costs on every volunteer, identically to every paid member:

| Obligation applying to volunteers | Source |
|---|---|
| Application, identity verification, interview, probation | **[S: Ch.12; SOP-01, SOP-02, SOP-03, SOP-04]** |
| "Verified and trained members scheduled" for service | **[S: Ch.15 step 7]** |
| Training categories, with certified floors in regulated domains | **[S: Ch.12 professional-validation boundary]** |
| Conduct rule: first violation warning, repeat removal | **[S: App. A §1.1; SOP-17, SOP-18]** |
| Attendance, engagement, welfare coordination | **[S: Ch.9 Volunteer Manager family — Volunteer, Shift, Attendance, Member Engagement, Volunteer Support Coordinators]** |
| Privacy and dignity duties toward beneficiaries | **[S: App. F; v1.3-A A-19]** |
| Safety doctrine and DO-NOT list | **[S: Ch.16; v1.3-A A-08]** |
| Evidence and outcome duties on every activity | **[S: Ch.15 steps 9–10; App. F]** |
| Performance measurement including "Member retention — healthy active retention, not inactive names" | **[S: Ch.25]** |

**[C]** A volunteer is therefore **the most heavily processed unit of labour in the architecture** — verified, trained, scheduled, supervised, welfare-tracked, conduct-monitored, safety-trained, privacy-bound and evidence-accountable — **and the least remunerated.** That is not a moral observation; it is a cost observation, and it is the reason the per-hour cost of volunteer labour can be high.

## 15.2 TRUE COST OF VOLUNTEERING — the formula

**[C]** Ten components, each mapped to the cost stack of §4:

```
C_vol_total = C_recruit + C_verify + C_train + C_coord + C_transport
            + C_comm + C_supervise + C_replace + C_retain + C_admin
            + C_opportunity  (where relevant and where the volunteer bears it)
```

| Component | What it is | Source anchor | Cost stack ref |
|---|---|---|---|
| **C_recruit** | Outreach, applications, interviews | **[S: Ch.12; SOP-01, SOP-03]** | GC-01 |
| **C_verify** | Identity, site, witnesses, records | **[S: SOP-02; Ch.8 step 4]** | GC-02 |
| **C_train** | Initial + recurring + certification | **[S: Ch.12]** | OC-10, GC-03 |
| **C_coord** | Scheduling, shift management, task assignment | **[S: Ch.9 Volunteer Manager family]** | GC-09, GC-10 |
| **C_transport** | Getting the volunteer to the activity | **[S: Ch.15]** | OC-01 |
| **C_comm** | Airtime, data, messaging | implied **[S: Ch.8, Ch.24]** | OC-03, OC-04 |
| **C_supervise** | Review of work, QA, welfare | **[S: Ch.15 steps 9–10; Ch.9 Conduct & Welfare Coordinator]** | GC-09 |
| **C_replace** | Re-recruiting when they leave (HC-01) | **[S: Ch.11 vacancy lifecycle]** | GC-01, GC-02, GC-03 |
| **C_retain** | Recognition, engagement, exit and stay interviews | **[X: recognition associated with materially lower turnover; stress-test M-items]** | GC-01 |
| **C_admin** | Records, ID token, reporting, RBAC | **[S: App. F; Ch.22; Ch.33 QR concept]** | OC-09, OC-12, GC-12 |
| **C_opportunity** | The income or study time the volunteer forgoes | not in source | **[M]** — borne by the volunteer, not the organisation, but **real** and relevant to §34 dignity |

## 15.3 Cost per delivered volunteer hour — where the surprise is

**[C]** Let `H_contrib` be the hours a volunteer actually contributes over their whole tenure, and `T_tenure` their tenure in months. Then:

```
C_vol_per_hour = C_vol_total / H_contrib
```

and, because `H_contrib = T_tenure × months⁻¹ hours × r_attendance`:

```
C_vol_per_hour = C_vol_total / (T_tenure × h_month × r_attendance)
```

> ### **The retention multiplier [C]**
> **`C_vol_per_hour` is inversely proportional to tenure.** Halve tenure and you double the true hourly cost of volunteer labour — *with no change in any cash outlay.*
>
> Front-loaded costs (`C_recruit + C_verify + C_train + C_admin`) are paid **once per person**; contribution is received **over time**. A volunteer who leaves after one activity has cost the organisation a full onboarding and delivered nothing.

**[C] Break-even tenure.** The tenure at which a volunteer's contribution covers their own processing cost:

```
T_be = C_vol_total / (h_month × r_attendance × value_per_hour)
```

where `value_per_hour` is the service value or the shadow cost of the alternative. **`T_be` is computable and must be measured — not guessed.** **[A]** Its practical significance is decisive: if `T_be` exceeds the median actual tenure, **the volunteer programme is value-destroying in cash-equivalent terms however noble it is in mission terms**, and the correct response is either to reduce front-loaded cost per volunteer (tiered onboarding — stress-test M1 participation spectrum) or to raise tenure (retention instruments **[X]**), **not** to recruit more.

## 15.4 Volunteer cost vs paid cost — the honest comparison

**[C]** Per delivered hour:

| | Volunteer | Paid |
|---|---|---|
| Marginal cash cost of one more hour | **≈ 0** (after onboarding) | `rate` |
| Fixed cost per person | `C_vol_total` (onboarding-heavy) | `C_recruit + C_verify + C_train` **plus** the wage |
| Hours available per month | `h_month_vol` — **low and unpredictable**; constrained by study, work, family **[X: "too busy" ~38% of stated exit reasons]** | `h_month_paid` — high and contractible |
| Cost per *delivered* hour | `C_vol_total / H_contrib` — **rises sharply as retention falls** | `rate + (fixed per person / H_contrib_paid)` — **stable** |
| Cost per *reliable* hour | Higher still — reliability requires coordination and chase (GC-01 welfare, Attendance Coordinator **[S: Ch.9]**) | Lowest — reliability is the point of payment |
| Governance cost generated | **Identical to a paid member** — verification, conduct, safety, evidence duties do not scale with pay **[S]** | Identical |
| Exit consequence | Task unstaffed; HC-01 replacement cost | Task unstaffed; HC-01 **plus** notice period and possible statutory obligations **[V]** |

> **[A] The counter-intuitive result:** *at low retention, a volunteer can cost more per reliably delivered hour than a paid worker* — because the onboarding cost is the same, the governance cost is the same, and the hours delivered are fewer and less dependable. **This is precisely the trap in the phrase "they are volunteers."** It is not an argument against volunteers; it is an argument for **measuring `T_be` and `r_ret` before scaling a volunteer programme**, and for investing in retention rather than recruitment.

**[X] Supporting external evidence** (non-Indian and single-programme studies; used for human regularities, not Indian magnitudes): leavers' leading stated reasons are relocation (~26%) and school/work busyness (~38%), with programme issues only ~5%; first-year retention is weakest; recognition and awards correlate with materially lower turnover (roughly 6% vs 15% in one sample; odds of staying ~1.43×); exit and stay interviews are the top-rated interventions; and — counter-intuitively — **training alone did not improve retention**, because training raises expectations the role must then meet.

**[A] That last finding has a direct economic consequence for this architecture:** the source invests heavily in training **[S: Ch.12, 11 training categories]**. Training raises capability **and** expectations. If the role cannot meet the raised expectation — because there is no paid work, no progression, no recognition — **the investment accelerates exit.** §35 treats this as an incentive failure, and §24 as a leadership-pipeline cost.

## 15.5 Volunteer economics under the architecture's own rules

**[C]** Four interactions worth stating:

1. **Volunteers are not payment-eligible** — "Only approved tasks/projects/venture work are eligible" **[S: Ch.19 step 1]** — so their hours generate no `R_1`. They are therefore **pure cost-plus-mission**, never revenue-capacity, unless they perform venture work (Model D, §16).
2. **Volunteers carry the same governance load per head** (GC-01, GC-02, GC-03). **So a large volunteer base increases `H_gov` without increasing `P_max`.** This is the mechanism behind stress-test F-07 ("The Starter Team that never grows past five people") and F-05.
3. **The leaderboard already knows this** — "Volunteer counts → Verified members/approved participants only; attendance cross-checked" and "Member retention → healthy active retention, not inactive names" **[S: Ch.25]**. **[A]** The anti-gaming controls are correct; the *economic* implication is that **headcount is a cost driver before it is a capacity driver.**
4. **Recognition is cheap and effective** **[X]**, and the source already contains a recognition concept in "achievements" on the Member dashboard **[S: Ch.24]** — but recognition must "celebrate contribution, not loyalty" (stress-test constraint, carried forward). **The cheapest retention instrument available is already in the architecture and is not costed anywhere.**

**[P] Proposal B-08 — Volunteer True-Cost Accounting.** Each team reports, monthly and per cohort: `C_vol_total` per onboarded volunteer; `T_tenure` and `r_ret`; `C_vol_per_hour`; and `T_be` against actual tenure. Purpose: **to stop treating volunteer growth as free success**, and to direct investment toward retention when `T_be > T_actual`. No cash value is assigned to volunteer *time* — that would monetise service, which §38 forbids. Only the organisation's **own cost** of processing a volunteer is measured. `PROPOSED — REQUIRES FINAL APPROVAL`.

---

# 16. PAID VERSUS VOLUNTEER MODELS

**Rule:** no winner is chosen automatically. Each model is assessed against the source, then on eight criteria, and the recommendation is derived from the model rather than from preference.

## 16.1 The four models

| | **MODEL A — Mostly volunteer** | **MODEL B — Mostly paid** | **MODEL C — Mixed** | **MODEL D — Service volunteer + revenue-producing paid work** |
|---|---|---|---|---|
| **Definition** | Nearly all labour unpaid; paid roles only where unavoidable | Nearly all labour compensated | Paid and unpaid interleaved across functions without a rule | **A rule:** mission work is volunteered; venture work is paid |
| **Source consistency** | Partial — the source clearly expects volunteers **[S: Ch.10 Supporting Members "helpers, volunteers, trainees"]** but also expects payment for verified work **[S: Ch.18]** | Weak — nothing in the source funds general payroll; priority 1 attaches to *venture* receipts only (§8.4) | Weak — "mixed without a rule" is what actually happens by default, and it is unaccountable | **Strong — this is what the architecture describes.** Priority 1 pays verified *venture* work **[S: Ch.18]**; service is scheduled from "verified and trained members" **[S: Ch.15 step 7]** with no payment line |
| **Sustainability** | Low cash need, **high churn risk**; survives on mission commitment | Requires revenue the unit cannot yet generate; **fails immediately at ₹0** | Unpredictable — depends on which roles happen to be filled by whom | **Highest**, because cash need scales with revenue: no revenue → no payroll → no insolvency |
| **Mission capacity** | **Highest per rupee** | Lowest per rupee; mission work competes with payroll | Medium | High — mission work is protected from market pressure by being unpaid |
| **Worker dignity (§34)** | **At risk** — depends on unpaid labour indefinitely, which your brief names as a failure | **Highest** — predictable, understandable pay | Inconsistent — two people doing the same work on different terms, which is a fairness problem | **Coherent if and only if the boundary is honest and visible**: nobody is *expected* to work free, and free work is genuinely optional |
| **Recruitment** | Easy to attract, hard to retain **[X]** | Attracts on income — **and the income must be real** (F-02, M16) | Confusing to explain | Explainable: "serve as a volunteer; earn when there is paid work" |
| **Retention** | Weakest on money, strongest on belonging | Strongest on money, weakest on belonging — **transactional retention is the weakest kind** (stress-test §10) | Unpredictable | Depends on whether *both* doors stay open — the stress test's four-door model (Purpose / Proof / Livelihood / Building) |
| **Cost** | `C_vol_total` per person; no payroll | Full payroll + statutory `C_stat` **[V]** | Both, unallocated | `C_vol_total` for service people; `C_wc + C_stat` for venture people — **separable and therefore accountable** |
| **Scalability** | Scales with recruitment, degrades with churn | Scales only with revenue | Scales ambiguously | **Scales with venture revenue, and service scales independently of it** — the only model where the two do not compete for the same cash |
| **Risk** | Burnout; invisibility of cost; mission drift into social club | Insolvency; mission subordination to payroll; loss of the seva character | **Unaccountability** — nobody can say what the labour model is | **Boundary erosion** — service work silently becoming unpaid venture work, or venture work being pushed onto volunteers to protect margin |

## 16.2 The decisive criterion: what the waterfall actually funds

**[C]** From §8.4, only category B (revenue-producing) has a funding line. Therefore:

- **Model B is not fundable** at team level. There is no revenue from which a general payroll could be paid, and the organisation service fee (priority 5) is *deferrable* and downstream.
- **Model A is fundable but fragile**, because it depends on an unmeasured, depletable stock of goodwill (§9.4).
- **Model C is what happens by accident**, and its danger is that it is *unaccountable*: without a stated rule, whether a person is paid depends on who asked, which is a fairness and discrimination risk (v1.3-A A-05 equal-treatment principle).
- **Model D is the only one the architecture can actually finance**, because it aligns the payment boundary with the revenue boundary.

> **[A] Finding: Model D is source-consistent and is the only financially coherent option — and it is also the most fragile, because it asks one small team to run two motivational systems at once.** A person who volunteers on Saturday for a tutoring circle and is paid on Tuesday for a website must understand why, and must not experience the Tuesday work as more *valued* than the Saturday work. **The performance weights already answer this — mission impact 20% exceeds business performance 15% [S: Ch.25] — and that ordering must be visibly honoured, not merely stated.**

## 16.3 The boundary rules Model D requires

**[P] Proposal B-09 — Paid/Volunteer Boundary Rules.** Seven rules, all additive, none altering the waterfall:

1. **Venture work is paid at priority 1** **[S]**. No venture work is performed by a person who has not agreed, in writing and in their own language, that it is paid work at the approved formula.
2. **Service work is voluntary.** No person is required, pressured, scored or shamed into unpaid service; and unpaid service is never a condition of paid work.
3. **No substitution.** A venture task may not be re-labelled as service, or assigned to a volunteer, to protect margin. Any such re-labelling is a **serious** integrity matter (§36, gaming register).
4. **Governance work is named.** HR, finance, safety, planning and documentation hours are **not** "volunteering by default". They are either (i) an explicitly agreed volunteer commitment with a stated hour expectation, or (ii) compensated from an approved source. **Which one, and from what source, is decision E-06 in §43 and is UNRESOLVED.**
5. **Hour expectations are disclosed at recruitment** (stress-test M16; **[X]** unclear time expectations are a leading cause of exit).
6. **The same person may hold both kinds of work**, but the hours are recorded separately, so that B-01's service-hour budget and the payroll are both auditable.
7. **The boundary is published.** A member must be able to state, without ambiguity, which of their activities are paid and which are voluntary. **If they cannot, the model has failed whatever the ledger says.**

`PROPOSED — REQUIRES FINAL APPROVAL`; **[V]** for employment and labour characterisation of each category, which depends on the unresolved worker-classification decision **[S: Ch.33]**.

## 16.4 What each model implies for the four break-even lines

**[C]**

| Model | Effect on `B_bare` | Effect on `B_healthy` | Effect on `B_growth` | Effect on `B_resilient` |
|---|---|---|---|---|
| **A** | Unchanged | **Lower** — no payroll to cover | Lower | Lower, but **fragile**: the "cost" has been moved into churn, not removed |
| **B** | Unchanged | **Much higher** — full payroll + `C_stat` | Much higher | **Unreachable early** |
| **C** | Unchanged | Unpredictable | Unpredictable | Unmeasurable — **which is itself the disqualifying problem** |
| **D** | Unchanged | **Payroll scales with revenue**, so `B_healthy` is closest to `R_1 + R_2 + R_3 + C_L1` — i.e. the *lowest achievable* while still paying people for revenue work | Rises with venture growth, not with mission growth | Same as D-healthy plus reserve and shock |

**[A] Model A looks cheapest and is not** — it converts a cash cost into a churn cost, and churn cost is `C_replace` per exit (HC-01) plus lost capacity plus lost legitimacy. Model D is the only one where the cost line and the revenue line move together.

---

# 17. BUSINESS CAPACITY CONSTRAINT

## 17.1 The chain, as your brief specifies

```
CUSTOMERS ↓ SALES ↓ PROJECTS ↓ WORKLOAD ↓ AVAILABLE PEOPLE ↓ DELIVERY CAPACITY ↓ QA ↓ CUSTOMER ACCEPTANCE ↓ PAYMENT
```

Each arrow is anchored to source and given a variable:

| Stage | Source anchor | Variable | Constraint type |
|---|---|---|---|
| **Customers** | **[S: Ch.7 City "identify customer needs… customer pipeline"]** | `N_cust`, pipeline depth | **External** — the neighbourhood and the City pipeline |
| **Sales** | **[S: Ch.17 steps 2 Validation, 5 Customer/partner]** | `r_lead→prop`, `r_prop→close`, `h_acq` | **Human** — the scarcest hours in the team |
| **Projects** | **[S: Ch.17 steps 3 Approval, 4 Business setup]** | `P_approved` | **Governance** — approval tier by "category, risk, money, data and novelty" |
| **Workload** | **[S: Ch.17 steps 6 Work assignment, 7 Production]** | `Σ h_proj` | **Human** |
| **Available people** | **[S: Ch.10 Supporting Members; Ch.12 verified skills, training]** | `N_paid × (T_avail − T_gov_per_head − T_svc)` | **The binding constraint** |
| **Delivery capacity** | **[S: App. A §13.5 "sufficient trained people"]** | `P_max` | **Derived** |
| **QA** | **[S: Ch.17 step 8 "Quality review before delivery"; Ch.9 Business QA Coordinator]** | `h_qa × P` | **Human, and non-skippable** |
| **Customer acceptance** | **[S: Ch.17 step 10 "Customer confirms or dispute/revision recorded"]** | `r_accept`, `h_rev` | **External + human** |
| **Payment** | **[S: Ch.17 step 11; Ch.19 step 3 reconciliation]** | `r_collect`, `Δt_collect` | **External — and the last, not the first, stage** |

## 17.2 The capacity formula **[C]**

```
H_pool      = N_act × T_avail
H_gov       = governance hours (§25)          ← subtracted FIRST
H_svc       = service hours (B-01 budget)     ← subtracted SECOND
H_acq       = acquisition and sales hours (§18)
H_train     = training and certification hours
H_deliver   = H_pool − H_gov − H_svc − H_acq − H_train − H_idle

P_max       = H_deliver / (h_proj + h_qa + h_rev_expected)
V_capacity  = P_max × P_price × r_accept × r_collect
```

**[A] The order of subtraction is the finding.** Governance is subtracted **first**, because it is non-deferrable — "small size never removes safety, HR verification, finance integrity or evidence duties" **[S: Ch.10]**. Service is subtracted second because mission impact carries the highest performance weight **[S: Ch.25]**. **Delivery capacity is therefore the residual of the residual.** A team that plans its sales target from `N_act × T_avail` without subtracting `H_gov` and `H_svc` will over-commit by a large margin — and the consequence arrives as HC-06 (scope overrun), HC-13 (revisions) and a QA failure (§29 Scenario 8).

## 17.3 The two asymmetries your brief asks about

### "What happens if customer demand grows faster than trained workers?"

**[C]** `P_demand > P_max`. Four consequences, in order:

1. **Queue forms.** Backlog rises — a dashboard field (§27). Backlog is not inherently bad; it is evidence of demand.
2. **Then quality falls.** Pressure appears to skip QA (step 8) or compress `h_rev`. **[S: Ch.17]** places QA *before* delivery precisely to prevent this, and the source's control for design/editing is "IP ownership, consent, **fact-check** and content rights" — non-skippable.
3. **Then acceptance falls and disputes rise** (steps 10–11), so `r_accept` and `r_collect` fall — **revenue falls while workload rises.** This is the worst quadrant in the model.
4. **Then the trained worker leaves.** Overwork is a documented exit driver **[X]**, and the person who leaves is the one whose skill cannot be replaced quickly — HC-01 at maximum cost, and §29 Scenario 3.

**[P] Mitigation (B-10 — Capacity Ceiling Rule):** a team may not accept work beyond `P_max` computed with `H_gov` and `H_svc` subtracted. Excess demand is **referred to the City pipeline** for allocation to another team **[S: Ch.7 "combine skills… coordinate delivery"; Ch.6 specialist deployment]** rather than absorbed. Referral is recorded as a success, not a failure — **and this is the mechanism by which one team's demand becomes another team's revenue, which is the only cross-subsidy that costs nobody anything (§22 Model C).**

**[A]** The source already forbids the alternative: "A venture scales **only** when it shows… **sufficient trained people**" **[S: App. A §13.5]**. B-10 makes that a scheduling rule rather than an aspiration.

### "What happens if workers exist but customers do not?"

**[C]** `P_max ≫ P_demand`. Consequences:

1. **`H_deliver` is idle.** Idle capacity is not free: `C_L1`, `H_gov` and `C_vol_total` continue (§4.4, §15).
2. **The rational response is to convert idle delivery capacity into acquisition capacity** — but `H_acq` is a *skill*, not just time, and the source provides no sales training category beyond "Business operations — customer acquisition, validation, quality, pricing, delivery and closure" **[S: Ch.12 training]**.
3. **The other rational response is to convert idle capacity into service** — which raises mission impact (20% weight) and community trust (10%) **[S: Ch.25]**, and *later* converts to demand **[I]**, because trust is the acquisition channel in a neighbourhood.
4. **The irrational response, and the likely one under pressure, is to lower price or accept bad projects** — which drives `CM̄_j` down (§11.4), raises `P_be`, and produces the SC-25 scarcity case (§10.3 finding 2).

**[P] Mitigation (B-11 — Idle Capacity Doctrine):** when `P_demand < P_max` for `n` consecutive periods, the team must (i) raise `H_acq` with City pipeline support **[S: Ch.7]**, (ii) raise `H_svc` within the B-01 budget, and (iii) **not** reduce price below the approved floor without City business review **[S: Ch.7 lane 5]**. Price floors and the review requirement are **[M]/[P]**; no value is invented.

## 17.4 Where the bottleneck actually is

**[A]** Ranked, from the model's structure:

| Rank | Bottleneck | Why | Evidence it is real |
|---|---|---|---|
| **1** | **`H_gov` — governance hours** | Subtracted first, non-deferrable, constant per team | **[S: Ch.10 State A control]**; stress-test F-05 "arithmetic, not behaviour" |
| **2** | **Trained delivery people** | `P_max` is capped by them; training has an external certification floor | **[S: App. A §13.5; Ch.12 boundary]**; stress-test: trainer supply is "the binding constraint at every stage above 1,000 members" |
| **3** | **Payable local demand** | Determines `N_cust` and `P_price`; varies by an order of magnitude between neighbourhoods | §19; stress-test F-18 |
| **4** | **Acquisition skill** | `H_acq` is scarce and untrained; the source assigns the pipeline to the City | **[S: Ch.7]** |
| **5** | **Collection** | `r_collect` and `Δt_collect` sit at the *end* of the chain and decide cash | **[S: Ch.17 step 11]**; HC-16 |
| **6** | QA capacity | Non-skippable, single-role | **[S: Ch.17 step 8]** |

**[A] Note what is *not* on the list:** motivation, mission clarity, architecture quality, documentation. Those are the architecture's strengths (stress-test §24: 11 components "keep verbatim"). **The bottlenecks are arithmetic and market, not cultural.** That is good news for design and bad news for effort — you cannot work harder out of a governance load or a neighbourhood without payable demand.

---

# 18. CUSTOMER ACQUISITION ECONOMICS

> **Rule from your brief, adopted:** do not assume social media automatically produces customers.

## 18.1 The acquisition funnel

**[C]** Each stage is a measured rate, none assumed:

```
Outreach (H_acq hours)
   ↓  r_reach      — contacts reached per hour
Leads (N_lead)
   ↓  r_qualify    — leads that are real, lawful, in-scope and payable
Qualified leads
   ↓  r_prop       — leads receiving a proposal [S: Ch.17 step 4 scope/price/timeline]
Proposals
   ↓  r_close      — proposals accepted [S: Ch.17 step 5 customer order/contract]
Customers (N_cust)
   ↓  P_delivered, r_accept   [S: Ch.17 steps 8–10]
Accepted work
   ↓  r_collect, Δt_collect   [S: Ch.17 step 11; Ch.19 step 3]
Collected revenue → V_gross
   ↓  r_repeat, r_referral
Repeat and referral customers
```

## 18.2 Acquisition cost — and why it is mostly invisible

**[C]**
```
H_acq_total = H_outreach + H_proposal + H_followup + H_contract + H_travel_to_prospect
C_acq_cash  = C_travel + C_print + C_comm_attributable + any paid promotion (requires approval)
C_acq_true  = C_acq_cash + H_acq_total × cost_per_hour

CAC = C_acq_true / N_cust_new
```

**[A] The critical fact: `C_acq_true` is dominated by the hours term, not the cash term.** A zero-capital team spends almost nothing and almost everything. Because the hours come out of `H_pool` (§17.2) *before* delivery capacity is computed, **acquisition competes directly with delivery and with service** — and it is the stage most likely to be silently skipped when the team is busy, which is exactly when the pipeline for *next* month should be being built.

**[C] The acquisition/delivery tension, stated as a formula:**
```
∂P_max/∂H_acq < 0      (more sales hours ⇒ fewer delivery hours this month)
∂P_demand(next)/∂H_acq > 0   (more sales hours ⇒ more work next month)
```
**[A]** So `H_acq` is an **investment with a one-period lag**, and a team under cash pressure will always cut it first — which is the classic small-firm death spiral. **B-11's rule (raise `H_acq` when demand is low) exists to break exactly that loop.**

## 18.3 The source's own acquisition model

**[S: Ch.7]** — the City, not the Mohalla, holds the pipeline: "Identify customer needs, combine skills, propose ventures and coordinate delivery" → "Customer pipeline, venture proposals, delivery records."

**[C] Two economic consequences:**

1. **`CAC` should be computed at City level and allocated,** because the City performs outreach across many teams. `CAC_city = C_acq_city / N_cust_city`, and a team's share is its allocation. **This lowers per-team acquisition cost by roughly the factor `K`** (teams per city) — the same divisor that makes governance affordable (§26, §31.2).
2. **A Mohalla team's own acquisition advantage is *proximity and trust*, not scale.** The categories where that advantage is decisive are **6 (local business technology)** and **5 (education/training)** — where the customer is a neighbour and the sale is a relationship (§7.1). Categories **1, 2, 3** are the *City's* game, because they need portfolio, contracts and credibility a single team cannot build.

## 18.4 Why social media does not produce customers

**[A]** Stated plainly, because the architecture contains a Social Media Manager family **[S: Ch.9]** and the temptation to treat it as a sales channel is strong:

| What social media does **[S: Ch.24]** | What it does not do |
|---|---|
| Publishes **verified facts only**; distinguishes completed work from plans; protects privacy | Does not create payable demand in a specific neighbourhood |
| Builds **community trust** — a performance dimension worth 10% **[S: Ch.25]** | Does not substitute for a proposal, a scope, a price and a contract **[S: Ch.17 step 4]** |
| Corrects misinformation calmly with correction logs **[S: Ch.24]** | Does not survive being used to exaggerate capability — and v1.3-A A-07 requires *under*-claiming |
| Requires authorised spokespersons for anything sensitive **[S: Ch.24]** | Does not permit a team to make commercial representations on its own authority |

**[A]** And the anti-gaming controls already say so: "Raw revenue, **follower count, social-media views**, volunteer count, application count or raw activity count **cannot determine leadership**" **[S: Ch.25]**. **[C]** An architecture that forbids using follower counts to *reward* a team cannot coherently rely on follower counts to *feed* it.

**[P] Proposal B-12 — Trust-to-Demand Conversion Path.** Social media and public communication are treated as a **legitimacy instrument** whose economic return is *indirect and lagged*: published, verified service outcomes → local trust → referrals and inbound requests → City pipeline qualification → venture work. The path is measured at the **referral** step (`r_referral`), never at the view. `PROPOSED — REQUIRES FINAL APPROVAL`.

## 18.5 The only cheap customers

**[C]**
```
CAC_repeat   ≈ 0        (existing relationship; no outreach)
CAC_referral ≈ small    (a neighbour's introduction; trust already transferred)
CAC_cold     = C_acq_true / N_cust_new   (full funnel)
```

**[A]** Therefore **`r_repeat` and `r_referral` are the two most important business metrics in the entire model** — more important than lead volume — and both are driven by *delivery quality and treatment*, not by marketing:

| Driver | Source anchor |
|---|---|
| QA before delivery | **[S: Ch.17 step 8]** |
| Revisions tracked, acceptance recorded | **[S: Ch.17 steps 9–10]** |
| "Customers are treated fairly" even when a venture fails | **[S: App. A §13.5]** |
| Customer complaints trigger business review, not defence | **[S: Ch.14 business failure row]** |
| Privacy of customer data | **[S: Ch.17 category controls "customer data legality, confidentiality"; v1.3-A A-17]** |

**[A]** Note the closing of the loop: **the architecture's ethics controls are its acquisition strategy.** Fair treatment of a customer on a failed project is the cheapest marketing available to a neighbourhood team, and it is already mandatory **[S]**.

## 18.6 Payment delay and the collection problem

**[C]**
```
V_invoiced  = Σ P_price for delivered, accepted work
V_collected = V_invoiced × r_collect   (with lag Δt_collect)
V_gross     = V_collected   OR  V_invoiced   ← **the accounting policy choice [S: App. A §14.3] [V]**
```

**[A] This single unresolved choice determines whether workers are paid in the month they worked (§12.3 row 3).** It is decision **E-07** in §43, marked **[V]**, and it must be resolved *before* the first project is invoiced — not after the first dispute.

**[P] Proposal B-13 — Collection Terms Standard.** For every approved venture: (i) written scope, price, timeline and acceptance criteria before work **[S: Ch.17 step 4]** — already mandatory; (ii) an advance or milestone structure where the category permits, so `C_var` is not financed by the team; (iii) a stated payment window; (iv) a stated consequence for non-payment that is **lawful, non-coercive and never enforced by protection roles** (v1.3-A A-08 DO-NOT list; A-09 do-not-attend categories); (v) automatic escalation to City business review at a stated ageing **[S: Ch.7 lane 5]**; (vi) no further work assigned to a customer in arrears beyond an approved cap (B-05 condition iv). `PROPOSED — REQUIRES FINAL APPROVAL`; **[V]** for enforceability, interest, and consumer/contract law.

**[A] Point (iv) deserves emphasis:** in a neighbourhood, the person who owes money is a neighbour, and the team contains a Safety Lead. **The separation between debt collection and protection roles must be absolute and written**, or the organisation's most dangerous perception risk (v1.3-A F-09 vigilante perception) acquires a financial motive.

---

# 19. LOCAL VENTURE SELECTION FRAMEWORK

> **Rule from your brief, adopted:** do not assume every Mohalla should sell the same service. **The organisation provides the framework; the local team does not receive unlimited freedom to violate organisational financial or legal controls.**

## 19.1 Why a framework rather than a catalogue

**[A]** The source is already explicit that categories are **POTENTIAL** and must be "approve[d]… one by one using risk/value framework" **[S: Ch.33]**, that approval is tiered by "category, risk, money, data and novelty" **[S: Ch.17 step 3]**, and that validation checks "real customer need, legality, ethics, capability and economics" **[S: Ch.17 step 2]**. **So a selection framework is not an addition to the architecture — it is the missing content of step 2.**

## 19.2 The twelve evaluation criteria

Each criterion is scored, with the scoring *scale* left to approval **[M]** so that no numeric weighting is invented here.

| # | Criterion | Question it answers | Variable | Source anchor |
|---|---|---|---|---|
| **1** | **Local demand** | Is there payable need within the operating area, this quarter? | `N_cust_potential`, frequency | **[S: Ch.17 step 2 "real customer need"]** |
| **2** | **Local skills** | Does the team hold verified skill, or can the State pool supply it? | `skill_level`, `N_skilled` | **[S: Ch.17 step 6 "verified skills"; Ch.6 specialist pool]** |
| **3** | **Local competition** | Who else sells this here, at what price and quality? | `n_competitors`, price band | **[S: Ch.17 step 2 economics]** |
| **4** | **Available technology** | Can it be delivered with the tools the team has, without cash startup? | `K_startup`, `C_ai` | **[S: Ch.22 platform; Ch.21 AI governance]** |
| **5** | **Customer ability to pay** | Can the customer pay within a window the team can survive? | `r_collect`, `Δt_collect` | **[S: Ch.17 step 11; Ch.19 step 3]** |
| **6** | **Delivery distance** | Is it inside the normal service area? | `distance`, `C_travel` | **[S: Ch.7 cross-boundary is City work]**; HC-14 |
| **7** | **Startup cost** | What cash is needed *before* the first rupee arrives? | `K_startup`, `H_startup` | **[S: Ch.17 step 4]** |
| **8** | **Repeatability** | Does it recur, or is it one-off? | `r_repeat` | §18.5 — repeat customers are the only cheap revenue |
| **9** | **Margin / contribution** | What is `CM_j` per project **and per delivery hour**? | `CM̄_j`, `CM̄_j / h_proj` | §11.4 |
| **10** | **Social value** | Does it serve the mission, or only the ledger? | mission-alignment score | **[S: Ch.15 mission; Ch.25 mission impact 20%]** |
| **11** | **Risk** | Legal, data, safety, liability, reputational, regulated-domain | risk tier | **[S: Ch.17 step 3 "risk"; category controls; Ch.12 professional-validation boundary]** |
| **12** | **Team capacity** | Can it be delivered inside `P_max` **after** `H_gov` and `H_svc` are subtracted? | `P_max`, `H_deliver` | §17.2 |

## 19.3 The four gates — applied in order

**[P]** A venture proposal passes only if it clears all four, in this sequence. The order matters: the cheapest tests come first.

| Gate | Test | Fails if |
|---|---|---|
| **G1 — Lawful** | Legality, ethics, data, permissions, licensing, safeguarding | Any unresolved legal question, any regulated activity without certification **[S: Ch.12 boundary; Ch.17 step 2]**, any category-7 licensing gap **[S]**, any minors' safeguarding gap **[V]** |
| **G2 — Capable** | Verified skill exists or is obtainable from the State pool **before** commitment | The team must *learn on the customer's project* |
| **G3 — Economical** | `CM̄_j / h_proj` above the approved floor; `P_be` (§11.4) reachable within `P_max`; `r_collect` and `Δt_collect` survivable | Contribution per delivery hour below floor, or break-even volume above capacity |
| **G4 — Mission-compatible** | Does not distort the service programme; does not create the incentives §35 lists; social value assessed honestly | It crowds out `H_svc` below the B-01 budget, or it depends on a relationship the team cannot ethically use |

**[A]** Gate G1 is absolute and cannot be traded against G3. **A highly profitable venture that fails G1 is refused, and the refusal is recorded** — the same discipline v1.3-A A-04 applies to political approaches.

## 19.4 The trade-off the framework must expose

**[C]** From §7.1 and §11.4:

| Category | `K_startup` | `skill_level` | `r_close` | `CM̄_j` | `h_proj` | `CM̄_j / h_proj` | `P_be` |
|---|---|---|---|---|---|---|---|
| **4 Design/editing** | Very low | Medium | Medium | **Low** | **Low** | **Low–medium** | **High volume needed** |
| **6 Local business tech** | Low | Medium | **Low–medium (easiest)** | Low–medium | Low–medium | Medium | Medium; **but recurring** |
| **5 Education/training** | Low | Medium + **certified safeguarding [V]** | Medium | Medium | Medium (session-based) | Medium | Medium |
| **3 Digital/analytics** | Low | Medium–high | Medium–high | **Medium–high** | Medium | **Medium–high** | Lower |
| **1 Software/apps** | Low cash, **high skill** | High | **High** | **High** | **High** | Medium | Lower per project, but `h_proj` risk (HC-06) |
| **2 AI automation** | Low cash, **high skill + governance** | High | **High** | **High** | Medium–high | Medium–high | Lower, **but `C_ai` and review load rise (HC-11)** |
| **7 Physical products** | **High cash, stock, licensing [V]** | Medium | Medium | Variable | Variable | Variable | **Highest risk; not for Stage 0–2** |

> **[A] The structural tension, stated honestly: the categories easiest to enter (4 and 6) have the lowest contribution per hour and therefore the highest break-even volume — and a small team cannot reach a high volume because `P_max` is capped (§17.2). The categories with the best contribution (1, 2, 3) require skills a Mohalla team usually does not have and a credibility it has not yet earned.**

**[P] Proposal B-14 — Two-Track Venture Strategy.** A team runs, at most, two tracks:
- **Track 1 (cash track):** a low-`K_startup`, high-`r_close` category — typically **6** or **4** — chosen for *speed to first collection*, accepting low `CM̄_j`. Purpose: reach `B_bare` and then `B_healthy`.
- **Track 2 (capability track):** one higher-`CM̄_j` category — typically **3, 1 or 2** — entered **through the City pipeline** **[S: Ch.7 "combine skills"]** with a State specialist attached **[S: Ch.6]**, so the skill is borrowed rather than built at the team's expense. Purpose: raise `CM̄_j / h_proj` over time.

**Rules:** Track 2 may not be started before Track 1 has produced `n` consecutive collected periods **[M]**; Track 1 may not be abandoned while it funds `C_L1`; **and neither track may consume `H_svc` below the B-01 budget.** `PROPOSED — REQUIRES FINAL APPROVAL`.

## 19.5 What the framework forbids

**[A]** Four refusals, each traceable to source:

1. **No venture may be started without approval** — "Approval tier based on category, risk, money, data and novelty" **[S: Ch.17 step 3]**. Local autonomy includes "which legitimate business opportunities it pursues" **[S: App. A §16.1]** but *within* central standards **[S: Ch.13]** — and finance is a central standard **[S: Ch.16.2/16.3 boundaries]**.
2. **No venture in a regulated domain without certification** **[S: Ch.12 boundary]** — which excludes, at team level, anything touching medical, legal, counselling, security or child-safeguarding delivery.
3. **No venture whose collection depends on a relationship the team cannot ethically leverage** — beneficiary relationships, protection relationships, or verification relationships. **This is the hard wall between §7 (revenue) and §38 (never monetised).** A person helped by the team is not a sales prospect.
4. **No venture that requires the protection function** for collection, enforcement or presence (v1.3-A A-08 DO-NOT list; §18.6 point iv).

---

# 20. MOHALLA AUTONOMY VERSUS FINANCIAL CONTROL

## 20.1 The principle preserved

> **[S: App. A §16.1]** "A team that becomes sufficiently complete and trusted receives broad flexibility over how it operates, how it manages its area, how many members it takes, how it structures work, **which legitimate business opportunities it pursues** and how it solves local problems. This is not permission to ignore the mission. **Autonomy is earned freedom inside central standards.**"

> **[S: App. A §16.3]** Autonomy boundaries: mission compliance; legal compliance; safety compliance.
> **[S: Ch.13]** "Autonomy remains conditional on mission, safety, law, finance, verified work, outcomes and audit."
> **[S: App. A §16.2]** Central control "creates slow decisions and local dependency" and "makes local leaders afraid to act or report problems"; central standards "create trustworthy freedom and comparable evidence".

**[A]** Your brief's two constraints are therefore both source requirements: **do not centralise routine decisions unnecessarily** (the source's own critique of central control) and **do not allow local autonomy to become financial chaos** (the source's own boundary list).

## 20.2 The decision-boundary matrix

**[P]** Five levels, as your brief specifies. Each row is a *class* of decision; the level assigned is derived from **reversibility** and **blast radius**, which is the same logic the source uses for approval tiers **[S: Ch.17 step 3; App. E]**.

| Decision class | **Local team may decide** | **City approval** | **State approval** | **National approval** | **Professional validation** |
|---|---|---|---|---|---|
| Which service need to address first | ✅ within the priority-assessment criteria **[S: Ch.8 step 5]** | if cross-boundary **[S: Ch.7]** | if multi-city **[S: Ch.6]** | — | if safeguarding/regulated **[V]** |
| How to schedule and structure work | ✅ **[S: App. A §16.1]** | — | — | — | — |
| How many volunteers to take | ✅ within readiness gates **[S: Ch.13]** | if it changes role structure | — | — | — |
| Which venture **category** to pursue | ✅ propose **[S: App. A §16.1]** | ✅ recommend | ✅ where specialist pool needed **[S: Ch.6]** | **✅ approve — category is POTENTIAL until approved [S: Ch.33]** | ✅ by category **[S: Ch.17 controls]** |
| Venture **scope, price, timeline, acceptance criteria** | ✅ within approved category and price floor | ✅ above a stated value **[M]** | — | — | if novel or data-intensive **[S: Ch.17 step 3]** |
| Direct cost spend within an approved project | ✅ with receipt and link **[S: SOP-08]** | above a stated threshold **[M]** | — | — | — |
| Expense approval | ❌ **not self-approval** — "cannot self-approve" **[S: Ch.18 Funds Manager limits]** | ✅ per approval matrix **[S: App. E]** | — | — | — |
| Reserve release | ❌ | ❌ | ❌ | ✅ **"National Funds Manager manages; release requires approval matrix" [S: Ch.18; SOP-10]** | ✅ by amount/risk **[S: Ch.33]** |
| Float drawdown (B-04) | ❌ request only | ✅ sponsor sign-off | ✅ renewal | ✅ cap and term | ✅ tax/accounting **[V]** |
| Payment cadence change (HC-17) | ❌ | ✅ recommend | ✅ | ✅ **approve — it is a member-facing promise** | ✅ labour law **[V]** |
| Compensation formula, percentages, multiplier | ❌ | ❌ | ❌ | ❌ **"Change compensation percentages, priority order or leader multiplier" is outside delegated authority [S: App. A]** | ✅ **[S: Ch.33 NOT FINAL]** |
| Worker classification | ❌ | ❌ | ❌ | ❌ **UNRESOLVED [S: Ch.33]** | ✅ **employment + tax [V]** |
| Waterfall priority order | ❌ | ❌ | ❌ | ❌ — **constitutional; v1.3-A Tier-1 candidate (A-13 T1.x)** | ✅ |
| Social-impact fund use | ❌ | ❌ | ✅ programme approval tier **[S: Ch.20 "approval tier by amount, risk, beneficiary and geography"]** | ✅ restricted ledger **[S: Ch.18, Ch.20]** | ✅ **[S: Ch.33 formula NOT FINAL]** |
| Cross-team support / referral of excess demand (B-10) | ✅ offer | ✅ allocate | ✅ deploy specialists **[S: Ch.6]** | if cross-state | — |
| Cross-subsidy transfer (§22) | ❌ | ❌ | ❌ | ✅ **and only if a model is approved — none is, today** | ✅ **[V]** |
| Data collection of any new field | ❌ | ❌ | ❌ | ✅ **privacy officer per v1.3-A A-17/A-18** | ✅ **[V]** |
| Public statements, branding, protection claims | ❌ | ❌ | ❌ | ✅ **[S: Ch.24 authorised spokespersons; v1.3-A A-06/A-07]** | ✅ where representations create duties **[V]** |
| Incident response within doctrine | ✅ **[S: Ch.16 any member may call authorities; trained first aid]** | ✅ High/Emergency review **[v1.3-A A-09]** | ✅ trends | ✅ policy | ✅ legal boundary **[V]** |
| Opening a sub-role | ✅ propose on need **[S: Ch.13 step 5]** | ✅ approve — "need-based, eligibility-based and RBAC-limited" **[S: Ch.10]** | — | — | — |

## 20.3 The three rules that keep this from becoming either chaos or bureaucracy

**[P]**

1. **The local default is YES for anything reversible and local.** Scheduling, sequencing, method, volunteer intake, service design, venture scoping inside an approved category — all local. Central approval is the *exception*, and each exception in §20.2 exists because the decision is either irreversible, money-moving, member-facing, or legally consequential.
2. **Every "National approval" row must have a stated response time.** An approval without a clock is central control wearing a central-standards costume — precisely the failure **[S: App. A §16.2]** describes. Response times are **[M]** and belong in the approval matrix **[S: App. E]**.
3. **A refusal must carry a reason and an alternative.** Where the answer is "you may not", the answering layer must say what the team *may* do instead. This is the v1.3-A A-04 refusal-script discipline applied to finance, and it is what prevents autonomy boundaries from producing the fear-of-reporting that the source warns about.

## 20.4 The economic reading of the matrix

**[C]** Three observations that matter to viability:

1. **The team controls its own cost of delivery but not its own cost of existence.** Direct costs are local with receipts **[S: SOP-08]**; `C_L1` (existence cost) has no local funding source at all (§8.4). **Autonomy without a budget is autonomy to do unpaid work.**
2. **The team cannot change the two numbers that most determine its viability** — the compensation formula and the payment cadence — both reserved upward **[S: Ch.33; App. A]**. **That is correct**, because both are member-facing promises; but it means a struggling team's only real levers are **venture selection, `H_gov` sharing and service-hour budgeting.** §26 is therefore not a governance preference; it is the team's only remaining lever.
3. **Reserve release sits at National level with an approval matrix [S]**, which means a team in a shock cannot self-rescue. **This is deliberate and correct** — SOP-10 flags "venture bailout" as abuse — **but it requires that the escalation path be fast**, or HC-03 (personal spending) becomes the de facto reserve. §21.5 sets the requirement.

---

# 21. RESERVE SYSTEM

## 21.1 The five funds, as the source defines them

| Fund | Source definition and restrictions | Level held | Who releases |
|---|---|---|---|
| **Venture reserve / wage-protection buffer** | "Funds held to protect **continuity, future costs and worker wage protection** under approved rules" **[S: App. A §14.3]**; priority **6** **[S: Ch.18]**; "Wage-protection/continuity buffer under policy" **[S: Ch.19 step 10]** | **National Funds Manager manages** **[S: Ch.18]** | "release requires approval matrix" **[S]**; SOP-10: purpose, amount, evidence, approvals, ledger, follow-up |
| **Organisation reserve** | Implied by priority 5–6 and by **[S: Ch.30 Phase 5 exit "Compliance, reserves, funding"]** | National | Approval matrix **[S: App. E]** |
| **Social-impact fund** | "**Restricted mission fund; not slush fund or venture bailout**" **[S: Ch.18]**; "**Not ordinary operating salaries. Not venture bailouts. Not political or religious activity.**" **[S: Ch.20]**; funded "from positive venture economics when waterfall conditions are met; donations may be possible after validation" **[S: Ch.20]**; programme budget restricted to "education, learning support, adult training, emergency participant support, community infrastructure, safeguarding capability and certain health/nutrition support" **[S]** | Segregated **[S: App. A §1.1 "segregated and not a discretionary cash pool"]** | Approval tier "by amount, risk, beneficiary and geography" **[S: Ch.20]** |
| **Other approved reserves** | "Residual surplus / founder upside" **[S: Ch.18 priority 8]**; **"Reserve release rules — NOT FINAL" [S: Ch.33]** | Unresolved | Unresolved |
| **(Proposed) First-season float** | **Does not exist in the source.** B-04, from stress-test M5 | Would be City/National | Would require a cap, term and reconciliation |

**[A] Two facts govern everything below:** (i) the reserve release rules are **NOT FINAL [S: Ch.33]**, so no operational detail can be asserted; and (ii) custody is **National**, with v1.3-A N15 (custody of reserves and the social-impact fund) and N16 (bank mandates) both **UNRESOLVED**. **This section therefore models *behaviour*, not balances.**

## 21.2 What each fund may and may not do

| Purpose | Venture reserve / wage buffer | Social-impact fund | Float (B-04, proposed) | Organisation reserve |
|---|---|---|---|---|
| Pay verified worker compensation in a weak month | ✅ **this is its stated purpose** | ❌ **"Not ordinary operating salaries" [S]** | ⚠️ only `L_min` and approved capability costs, never a salary substitute | ⚠️ policy-dependent |
| Bail out a failing venture | ❌ **SOP-10 flags "venture bailout" as abuse [S]** | ❌ **"Not venture bailouts" [S]** | ❌ | ❌ |
| Cover an emergency operating cost | ✅ "continuity, emergencies" **[S: Ch.18]** | ⚠️ only within its restricted programme list, e.g. "emergency participant support" **[S: Ch.20]** | ⚠️ within cap | ✅ |
| Fund a service programme | ❌ not its purpose | ✅ **its exact purpose**, within the restricted list and approval tier | ❌ | ⚠️ |
| Fund governance / existence cost `C_L1` | ❌ no source basis | ❌ **"Not ordinary operating salaries"** | ✅ **the only candidate instrument** | ⚠️ unresolved |
| Fund political or religious activity | ❌ | ❌ **explicit [S: Ch.20]**; also v1.3-A A-01 N1–N9 | ❌ | ❌ |
| Transfer to another team | ❌ **no source mechanism** | ❌ | ❌ | ❌ **see §22** |

> **[C] The gap, isolated:** the one cost that a new team reliably has and no fund is permitted to cover is **`C_L1` — the cost of existing.** The social-impact fund is barred from salaries and bailouts **[S: Ch.20]**; the wage buffer is for continuity and wage protection and is empty early (§8.5); reserve release is National with a matrix **[S]** and SOP-10 treats a venture bailout as abuse. **B-04 (float) is the only instrument in this model that can lawfully and honestly fill the gap, and it does not exist in the source.** That is decision **E-05/E-08** in §43.

## 21.3 Shock tests

### "What happens if revenue falls sharply?"
**[C]** Sequence: `V_gross ↓` → `A_5 = 0` (deferrable, correctly) → `A_6 = 0` (reserve stops accumulating) → if `V_gross < R_1`, **B-06 pro-rata triggers and B-05 accruals begin** → `C_L1` unpaid → capability costs deferred → `H_gov` *rises* if tools lapse (HC-20) → capacity falls → revenue falls further. **[A] The loop is self-reinforcing, and the only external interrupt is a float, a City pipeline referral (B-10), or a §23 support intervention.**

### "What happens if multiple teams fail simultaneously?"
**[A]** Correlated failure is the realistic case, not the tail case, because the drivers are shared: a festival-season revenue trough (HC-15), a regional economic shock, a single large customer defaulting across a City pipeline, or a reputation event. Then: reserve requests arrive together at a National approval matrix **[S]**; the State specialist pool **[S: Ch.6]** is asked to support several cities at once; and **[S: Ch.6]** permits State teams to "temporarily support or supervise a struggling City Team" — **but only one at a time in practice.** §29 Scenario 11 and 12 model this.

### "What happens if one team experiences an emergency?"
**[C]** The team cannot self-release reserves (§20.2). It must escalate: SOP-10 requires purpose, amount, evidence, approvals, ledger, follow-up — and the approver is National **[S: Ch.18]**. **[A] So the binding variable is not the reserve balance but the *escalation latency*.** If latency exceeds the emergency, the cost is met personally (HC-03) or not at all. §21.5 addresses this.

## 21.4 Can one team's reserves be transferred to another?

**[C] No — and the source is clear rather than merely silent:**

| Evidence | Effect |
|---|---|
| "Reserve funds — **National Funds Manager manages**; release requires approval matrix" **[S: Ch.18]** | Reserves are not team property; a team has no balance to transfer |
| SOP-10 escalation flags "**Personal request, venture bailout, missing approvals**" **[S]** | The three obvious transfer motives are already flagged as abuse |
| Social-impact fund is "**segregated and not a discretionary cash pool**" **[S: App. A §1.1]** | No lateral movement |
| "Reserve release rules — **NOT FINAL**" **[S: Ch.33]** | Nothing may be assumed about the eventual mechanism |
| v1.3-A **N15** custody of reserves and social-impact fund: **UNRESOLVED** | The instrument holding the money does not yet exist |

**[A]** So cross-team support cannot be a *reserve transfer*. It can only be: (i) a **National release** under the approval matrix for a stated purpose; (ii) an **in-kind** deployment of people and materials — which the source already provides via the State specialist pool **[S: Ch.6]** and City materials allocation **[S: Ch.7]**; or (iii) a **demand referral** moving revenue *opportunity* rather than money (B-10). **(ii) and (iii) are already architecture and cost no cash. That is the finding §22 builds on.**

## 21.5 Reserve governance requirements this model adds

**[P] Proposal B-15 — Reserve and Shock Governance.** Six requirements, all additive:

1. **A stated escalation latency target** for emergency reserve release, by severity, using the existing risk tiers **[S: Ch.16 Low/Medium/High/Emergency]**. **Value [M]** — but the *requirement* that one exists is not optional, or HC-03 becomes the de facto reserve.
2. **A pre-approved City emergency float** — small, capped, per-City, for `C_trans_em`-class costs only, reconciled monthly. Distinct from B-04 (which is a *team formation* float).
3. **Reserve adequacy measured in months, not rupees:** `Reserve_months = Reserve_balance / (C_L1 + C_gov_cost)` per team and per city, reported at the quarterly and annual cadences **[S: Ch.24]**.
4. **A correlated-shock test** run annually: what happens to the reserve if `x%` of teams in a city simultaneously fall to SC-25? **[SC]** — no probability asserted.
5. **An absolute prohibition on using any fund for a purpose §21.2 marks ❌,** enforced as serious misconduct **[S: SOP-18]** regardless of outcome — the same entrenchment logic as v1.3-A A-08.
6. **Publication of reserve and float utilisation** at the annual cadence **[S: Ch.24]**, with the social-impact fund's restricted programmes reported separately per **[S: Ch.20 evidence and reporting]**.

`PROPOSED — REQUIRES FINAL APPROVAL`; **[V]** for custody, banking, tax and accounting treatment — all contingent on v1.3-A N15/N16.

---

# 22. CROSS-SUBSIDIZATION

## 22.1 The question

> Does a profitable team subsidise a weaker team — and should it?

**[A]** The economics make the question unavoidable: governance cost per team is roughly **constant** while revenue capacity per team varies by **an order of magnitude** across neighbourhoods (§14.2, §31.3). Without some transfer — of money, of people, or of demand — **structurally non-viable teams are not an accident; they are an arithmetic certainty.** The stress test reached the same conclusion (F-18: "With no cross-subsidy policy and no differentiated standard, low-capacity teams are structurally non-viable").

**[C]** And §21.4 has already established the hard constraint: **money cannot move laterally between teams** under the source's reserve and fund rules. So any viable model must transfer **something other than cash**, or must route cash **through National approval**.

## 22.2 The four models

| | **Model A — No cross-subsidy** | **Model B — Limited emergency support** | **Model C — Central support pool** | **Model D — Performance-based recovery grants** |
|---|---|---|---|---|
| **Mechanism** | Each team stands alone | National reserve release on escalation **[S: Ch.18; SOP-10]** + State/City in-kind support **[S: Ch.6, Ch.7]** | A pooled fund at National/City level, allocated by rule | Time-bound grants tied to a §23 improvement plan |
| **Source basis** | **Implicit default** — nothing in the source authorises lateral transfer | **Strong** — every element already exists | **Weak** — requires a new instrument; the organisation service fee (priority 5) is the natural funding source but is deferrable and downstream | **Partial** — **[S: Ch.14]** support-first recovery already implies resources: "Provide coaching, temporary help, process correction or **resources**" |
| **Fairness** | Formally equal, **substantively unfair** — teams in poor areas carry the same governance load with less income | Fair for shocks; silent on structural weakness | Fair if allocation is need-and-plan based; unfair if political | Fair if criteria are published; **risks rewarding failure** if grants are not earned |
| **Incentives** | Strong self-reliance; **but punishes high-need areas** and rewards wealthy neighbourhoods | Good — support is exceptional | **Moral hazard**: teams may under-perform expecting support | Mixed — a grant is a *contract*, which can be healthy, or a *prize*, which is not |
| **Dependency** | None | Low | **High risk** | Medium, bounded by term |
| **Gaming** | Under-reporting of need; hiding weakness (fatal, §36) | Overstating emergencies | **Lobbying the pool**; inflating need | **Grant-writing as a skill** replacing delivery; leaderboard manipulation **[S: App. A §13.5 warns of it]** |
| **Autonomy** | Maximum | High | Reduced — pool conditions attach | Reduced during the grant term |
| **Transparency** | Low — nobody can see who is actually failing | Medium | **High if allocations are published** | High if criteria and outcomes are published |
| **Sustainability** | **Unstable** — structurally non-viable teams fail in sequence | Stable for shocks, **not for structural gaps** | Depends entirely on priority-5 income, which is last and deferrable (§8.6) | Depends on grant funding source — unresolved |
| **Cost** | Zero central cost; **high failure cost** (HC-23, §23) | Low | High and recurring | Medium and time-bound |

## 22.3 Evaluation against the seven criteria your brief names

**[C]**

| Criterion | A | B | C | D |
|---|---|---|---|---|
| Fairness | ✗ | ◐ | ● | ◐ |
| Incentives | ◐ | ● | ✗ | ◐ |
| Dependency | ● | ● | ✗ | ◐ |
| Gaming resistance | ✗ (concealment) | ◐ | ✗ | ◐ |
| Autonomy | ● | ● | ✗ | ◐ |
| Transparency | ✗ | ◐ | ● | ● |
| Sustainability | ✗ | ◐ | ✗ (funding source) | ◐ |
| **Source consistency** | implicit | **strong** | weak | partial |

## 22.4 The recommendation, and why it is not a single model

**[A]** No model wins outright, and your brief forbids selecting one merely because it sounds best. **The model's own evidence points to a sequencing, not a choice:**

> **[P] Proposal B-16 — Layered Support Doctrine (Model B as the floor, C and D deferred).**
>
> **Layer 1 — Non-cash transfer, immediate, already architecture.** Demand referral (B-10) and specialist deployment **[S: Ch.6]** and City pipeline allocation **[S: Ch.7]** and materials allocation **[S: Ch.7]**. **This is cross-subsidy that costs no cash and requires no new instrument** — a strong team's *surplus capacity* absorbs a weak team's *surplus demand*. It should be adopted first because it is free, reversible, and already permitted.
> **Layer 2 — Emergency support, existing instrument.** National reserve release under the approval matrix **[S: Ch.18; SOP-10]**, with the latency target of B-15. Plus §23 support-first recovery **[S: Ch.14]** including its "resources" element.
> **Layer 3 — Formation subsidy, proposed instrument.** B-04 float and B-03 reserve seeding, for teams in months 1 to `M_target`. Explicitly time-bound and reconciled.
> **Layer 4 — Central support pool (Model C) — DEFERRED.** It cannot be funded until priority-5 income exists at scale (§8.6), and creating it earlier would create dependency without a revenue base. **Revisit at §30 Stage 4.**
> **Layer 5 — Recovery grants (Model D) — DEFERRED and conditional.** Adopt only with published criteria, a hard term, an improvement plan per **[S: Ch.14 steps 7–8]**, and an explicit bar on grants becoming recurrent.

`PROPOSED — REQUIRES FINAL APPROVAL` for Layers 3 and 5; Layers 1 and 2 are **[S]** implementations of existing architecture. **[V]** for the funding source, tax treatment and any donor-restriction questions in Layers 3–5.

## 22.5 The honest cost of the recommendation

**[A]** Layer 1 is free in cash and **not free in capacity**: a strong team that absorbs a weak team's demand spends `H_deliver` it could have spent on its own growth, and — critically — **its `H_svc` is the buffer that will be consumed first** (§6.3). So layered support transfers *mission hours* from strong teams to weak teams unless the B-01 service-hour budget is defended. **That is a real cost, it falls on the strongest teams, and it must be visible in the performance system rather than absorbed silently.** §35 records it as incentive risk I-06.

---

# 23. FAILED TEAM ECONOMICS

## 23.1 The source philosophy, preserved

> **[S: Ch.14]** "Team Failure and Recovery — Purpose: Show the **support-first** recovery system for operational, financial, leadership, HR, safety and business failures."
> **[S: Ch.14 step 3]** "Specific bottleneck identified **rather than immediately destroying team**."
> **[S: App. A §17]** "The goal is **not to create shame but to restore capability.** Replacement is appropriate when support fails, when misconduct is serious, or when keeping current leadership creates risk to people, money, mission or reputation."
> **[S: App. A §1.1]** "Teams that fail should receive **support before replacement** when safe and practical."

**Your brief's instruction — do not recommend immediate dissolution merely because a team underperforms — is already source doctrine.** This section costs it rather than restating it.

## 23.2 The recovery chain, costed

**[S: Ch.14 steps 1–9]**, with the economic content of each:

| Step | Source | What it consumes | Variable | Who pays |
|---|---|---|---|---|
| **1. Performance problem** | "Operational, finance, leadership, HR, safety or business weakness appears" | Nothing yet | — | — |
| **2. Detection** | "Reports, dashboards, audits, complaints or performance decline" | Governance hours already spent (§25); **detection latency is the real cost** | `t_detect` | Team + City review **[S: Ch.7]** |
| **3. Problem identification** | "Specific bottleneck identified" | Leader + City time | `h_diag` | City |
| **4. Support team assigned** | "**Capable team from same or another city may support**" | **`H_deliver` of another team's members** — the largest single cost | `H_support × N_support` | The supporting team, i.e. §22.5's hidden transfer |
| **5. Discussion** | "Talk with struggling team; **avoid fear of reporting problems**" | Time; and psychological safety is a *precondition*, not a nicety | `h_disc` | City/State |
| **6. Root-cause analysis** | "**Skill, resources, leadership, process, fraud, safety or workload?**" | Diagnostic time; may require audit **[S: Ch.27]** | `h_rca` | State specialist pool **[S: Ch.6]** |
| **7. Training / resources** | "Provide coaching, temporary help, process correction or **resources**" | `C_train`, specialist time, possibly materials | `C_support` | State/City; **funding source UNRESOLVED (§22.4 Layer 2)** |
| **8. Improvement period** | "**Defined review period with evidence**" | **The whole cost stack continues while output is depressed** | `T_improve × (C_L1 + C_gov)` | Team + float/reserve |
| **9. Reassessment** | "**Continue, support, restructure or replace**" | Decision cost; if closure, HC-23 | `h_reassess` | City/State/National |

**[C] Total cost of supporting a failing team:**
```
C_failure_support = (H_support × cost_per_hour)          ← step 4, usually dominant
                  + C_train + C_specialist                ← steps 6–7
                  + T_improve × (C_L1 + C_gov_cost)       ← step 8: the carrying cost of a depressed team
                  + C_diag + C_decision                   ← steps 3, 5, 9
                  + (opportunity cost: the supporting team's own P_max falls)
```

**[A] The dominant term is step 8, not step 7.** Training and coaching are visible and budgeted; **the carrying cost of keeping a team alive through an improvement period is not**, and it is `T_improve × (C_L1 + C_gov)`. Since `C_L1` has no funding source (§21.2), **the improvement period is funded by whatever the team can defer — which is service hours and capability costs.** A team in recovery therefore tends to stop doing mission work, which destroys the very thing worth recovering.

## 23.3 When does support become economically irrational?

**[A]** Your brief asks the question and forbids a glib answer. **The source already answers it**, and the answer is not a number:

> **[S: App. A §14.5]** "**If a venture repeatedly cannot pay workers lawfully and sustainably, it must be restructured, paused or closed.**"
> **[S: App. A §17]** "Replacement is appropriate when **support fails**, when **misconduct is serious**, or when keeping current leadership creates **risk to people, money, mission or reputation**."
> **[S: Ch.14 financial-failure escalation]** "Audit/suspension if fraud suspected."
> **[S: Ch.14 safety-failure response]** "**Immediate stop-work** and safety review."

**[C] Four stopping conditions, all source-derived — no threshold invented:**

| # | Condition | Source | What stops |
|---|---|---|---|
| **SC-1** | The venture **repeatedly** cannot pay workers lawfully and sustainably | **[S: App. A §14.5]** | The **venture** is restructured, paused or closed — **not necessarily the team** |
| **SC-2** | Support has been given and **has failed** | **[S: App. A §17]** | Further support; move to restructure or replace |
| **SC-3** | **Serious misconduct or suspected fraud** | **[S: Ch.14; SOP-18]** | Support stops immediately; audit and suspension |
| **SC-4** | **Safety failure** or risk to people, money, mission or reputation | **[S: Ch.14 "immediate stop-work"]** | Activity stops immediately |

**[A] The critical distinction the source makes and this model preserves:** SC-1 closes a **venture**, not a **team**. A team whose venture fails can continue to exist as a service unit — provided something funds `C_L1`, which is the unresolved question (§21.2, §33). **Conflating venture failure with team failure is the most expensive error available here**, because it destroys mission capacity in a neighbourhood in order to close a business line.

## 23.4 What "repeatedly" must mean

**[A]** The source says "repeatedly" and gives no count — consistent with its refusal to invent numbers **[S: Ch.33]**. **[P] Proposal B-17:** "repeatedly" is defined as **`n_consecutive` periods below `B_bare` or `n_of_m` periods below S-1 worker solvency (§8.3)**, where `n_consecutive`, `n_of_m` and the period length are **approved values [M]**, published in advance, and applied uniformly. **Publishing the definition in advance is what makes it fair**; leaving it to judgement makes it a tool. `PROPOSED — REQUIRES FINAL APPROVAL`.

## 23.5 Closure economics

**[S: App. A §13.5]** — the source's own closure checklist, which is also a cost list:

| Closure task | Source | Cost |
|---|---|---|
| "Money is reconciled" | **[S]** | `h_reconcile` + `C_acct` |
| "Customers are treated fairly" / "settle customers" | **[S]** | Refunds, completed work, `h_dispute` |
| "Workers are paid according to approved rules" | **[S]** | **`A_1` must still be honoured** — closure does not extinguish priority 1 |
| "Recover assets" | **[S]** | Logistics, inventory audit **[S: Ch.9 Warehouse family]** |
| "Revoke accesses" | **[S]** | RBAC and delegation expiry **[S: Ch.22; v1.3-A A-14 §13.4]** |
| "Record lessons" | **[S]** | v1.3-A A-15 M5 lessons register |
| "Prevent leaderboard manipulation" | **[S]** | Performance-record correction **[S: Ch.25 corrections and appeals]** |
| "Reasons are documented" | **[S]** | v1.3-A A-15 M1 rationale register |

**[A]** Closure is **not free and not fast**, and it must not be used as a threat. A team that believes closure is punitive will conceal weakness (SC-3 detection latency rises, §36), which is the outcome the source explicitly designs against: "avoid fear of reporting problems" **[S: Ch.14 step 5]**.

---

# 24. LEADERSHIP COST

## 24.1 What leadership costs

**[C]** Five cost components, each anchored:

| Component | What it is | Source anchor | Variable |
|---|---|---|---|
| **Compensation** | "Leader payment — same framework with higher allocation; **FINAL MULTIPLIER REQUIRES APPROVAL**" | **[S: Ch.19 step 8; App. A §15.3]** | `C_lead = C_wc_base × m_lead`, `m_lead` unresolved |
| **Time** | Decision, conflict, escalation, representation — GC-08 | **[S: Ch.8 "Decision — Team Leader within authority"; Ch.7 escalation; Ch.9 Team Leader family]** | `g_lead_fix + g_dec × N_dec` |
| **Social cost** | Accountability without pay certainty, friction for saying no, visibility | stress-test F-03, F-24; HC-18 | burnout/exit risk |
| **Replacement** | Succession, handover, re-training | **[S: Ch.26 succession; Ch.9 "Succession" column per role; v1.3-A A-14 master handover checklist]** | `C_replace_leader ≫ C_replace_member` |
| **Capacity loss on promotion** | **The winning team loses its best leader** | **[S: Ch.26 / App. A §1.1 dynamic leadership: "best Mohalla team can become City Head Team; best City Head Team can become State Head Team; best State Head Team can reach National Team opportunity"]** | §24.3 |

**[A]** The leader differential is bounded by principle: "Any leader differential must be **transparent, capped or bounded** where appropriate, and **justified by verified leadership work rather than status alone**" **[S: App. A §15.3]**. That is an anti-hierarchy rule with an economic effect: it prevents leadership becoming a rent, which is what would make promotion attractive for the wrong reason (§35 I-05).

## 24.2 Promotion without capacity destruction — the problem

**[S]** The ladder is a core, preserved design: earned leadership, dynamic succession, the best Mohalla team becoming a City Head Team. **[A]** Its economic side-effect is exact and unavoidable:

```
Team X performs best → Leader(X) promoted to City layer
                     → Team X loses: decision capacity, relationships, tacit knowledge, credibility
                     → Team X's P_max, r_close and H_gov efficiency all fall
                     → Team X's score falls → the leaderboard rewards the team that has NOT been promoted
```

**[A]** This is a **success tax on success**, and it creates three perverse effects: (i) a team may under-perform deliberately to avoid losing its leader (§36 leaderboard gaming); (ii) the promoted leader's new layer inherits a person whose former team is now weaker, so the *network* loses capacity twice; (iii) the pipeline narrows, because the pool of experienced Mohalla leaders is continuously drained upward.

## 24.3 Mechanisms that preserve capacity on promotion

**[P] Proposal B-18 — Succession-Neutral Promotion.** Six mechanisms, all additive, **none rewriting the leaderboard architecture**:

1. **Successor-before-transition.** A promotion is not executed until a named, trained, delegated successor exists, using the source's own machinery: Sub-Role/deputy with recorded delegation and dates **[S: Ch.10, Ch.22]** and the per-role "Succession" column **[S: Ch.9 — e.g. "Reviewer → Sub-Editor → Editor"; "Coordinator → Sub-Funds → Funds Manager"]**. (Stress-test M9 reached the same conclusion independently.)
2. **Overlap period.** Outgoing and incoming leader both hold delegation for a stated overlap **[M]**, so tacit knowledge transfers in the presence of the team rather than in a handover document.
3. **Mentor obligation, time-bounded.** The promoted leader remains a *mentor* to the former team for a stated period with a stated hour cap — enough to transfer, not enough to prevent the successor from owning the role.
4. **Promotion cohort scoring.** For `n` periods after a promotion, the team's score is reported **with and without** a promotion adjustment, so the leaderboard does not punish a team for the transition it did not choose. **This does not change the weights [S: Ch.25]** — it changes only the reporting of a known structural effect, and it is marked `PROPOSED` because it touches a NOT FINAL area.
5. **Horizontal recognition as an alternative to vertical promotion.** Not every excellent leader should be moved upward. The stress test's M9 horizontal competence ladder and credential issuance **[S: Ch.24 Member dashboard already shows "achievements"]** gives status without extraction. **This is the cheapest capacity-preservation mechanism available and requires no new authority.**
6. **Promotion is recorded as a *cost* as well as an achievement** — the M1 rationale register (v1.3-A A-15) entry states what the losing team gives up and what support it receives. A promotion that is not accompanied by a support decision is a capacity destruction event disguised as a reward.

`PROPOSED — REQUIRES FINAL APPROVAL` for all six; item 4 additionally **[V]** as it touches performance methodology.

## 24.4 Leader absence, and the Mohalla-level gap

**[A]** v1.3-A A-14 built succession for the **apex** (S1–S8). Nothing equivalent exists at Mohalla level, where absence is far more frequent. HC-02 records the consequence: decisions and payments stop, because the Funds Manager "cannot self-approve" **[S: Ch.18]**.

**[P] Proposal B-19 — Local Interim Authority Order.** Apply the v1.3-A A-14 *pattern* at team level: a written, standing order naming (i) who holds decision authority during Leader absence, (ii) for how long, (iii) what they may **not** decide (reserve requests, venture approval, conduct outcomes, payment-formula changes — all reserved per §20.2), and (iv) the City fallback where no local deputy exists. Uses the existing Sub-Leader/deputy machinery **[S: Ch.10]** and the existing delegation-date fields **[S: Ch.22]**, so it needs no new technology. `PROPOSED — REQUIRES FINAL APPROVAL`.

## 24.5 Relocation and the leader-supply constraint

**[X]** External retention research puts **relocation (~26%)** as the single most common stated reason for leaving. **[A]** For a neighbourhood-based leadership model this is decisive: **the leader pool is drained by geography, not only by promotion.** Combined with the stress test's finding that trained-leader production is "limited by trainer supply, not by curriculum", the conclusion is:

> **[C] Leader supply is a *stock* problem, not a *training-content* problem.** The binding constraint is the number of people who can be trusted with the four segregated finance hands (§3.3), the safety doctrine, and the social cost of saying no to neighbours — and that stock is depleted by promotion, relocation, burnout and exit simultaneously.

**[P]** Therefore: **plan team formation against leader supply, not against population.** The number of teams a city can form is `N_leaders_available / leaders_per_team`, and forming teams faster than that produces teams without the control roles — which is stress-test F-03 and F-30 in one step.

---

# 25. GOVERNANCE BURDEN MODEL

## 25.1 The workload calculator

**[C]** Inputs are the ten variables your brief specifies; outputs are the seven hour categories. **Every coefficient `g_*` is [M] — a value to be measured in the pilot, never asserted here.**

### Inputs

| Variable | Meaning | Source driver |
|---|---|---|
| `N_members` | Total members on roll | **[S: Ch.12]** |
| `N_roles` | Roles and sub-roles filled | **[S: Ch.10]** |
| `N_apps` | Applications received | **[S: SOP-01]** |
| `N_inc` | Incidents | **[S: SOP-13; Ch.16]** |
| `P_projects` | Business projects | **[S: Ch.17]** |
| `N_txn` | Financial transactions | **[S: Ch.19]** |
| `N_act` | Service activities / requests | **[S: Ch.8; Ch.15]** |
| `N_reports` | Reports due | **[S: Ch.24 five cadences]** |
| `N_audits` | Audits and reviews | **[S: Ch.27; Ch.13 gate 8]** |
| `N_train` | Training events and certifications | **[S: Ch.12]** |

### Outputs

```
H_hr     = g_hr_app   × N_apps   + g_hr_mem  × N_members  + g_hr_cond × N_conduct
H_fin    = g_fin_txn  × N_txn    + g_fin_cyc × cycles     + g_fin_rec × N_reports_fin
H_lead   = g_lead_fix            + g_dec      × N_decisions + g_esc × N_escalations
H_plan   = g_plan_act × N_act    + g_plan_prj × P_projects
H_ver    = g_ver_app  × N_apps   + g_ver_act  × N_act     + g_ver_site × N_site_visits
H_audit  = g_audit    × N_audits + g_corr     × N_corrective_actions
H_doc    = g_doc_rec  × N_records + g_doc_rep × N_reports + g_doc_dp × N_data_events

H_gov    = H_hr + H_fin + H_lead + H_plan + H_ver + H_audit + H_doc
σ        = H_gov / (N_act × T_avail)        ← governance share of available hours
```

## 25.2 The fixed and variable split — the part that matters

**[C]** Separating by driver:

| Term | Driver | Behaviour |
|---|---|---|
| `g_lead_fix` | existence | **Fixed** |
| `g_hr_mem × N_members` | headcount | **Semi-fixed** — rises with roll, not with activity |
| `g_doc_rep × N_reports` | cadence **[S: Ch.24]** | **Fixed by cadence count** — daily, weekly, monthly, quarterly, annual = **5 fixed obligations** |
| `g_fin_cyc × cycles` | payment cadence **[S: Ch.19]** | **Fixed by cadence** — weekly = 4.33/month; monthly = 1 |
| `g_audit × N_audits` | periodic **[S: Ch.27]** | **Fixed by schedule** |
| everything else | activity | **Variable** |

> **[A] The finding:** a large share of `H_gov` is driven by **cadence and headcount, not by activity.** A team that does nothing still owes five reporting cadences, four-plus payment cycles, its audit schedule and its per-member records. **This is why `H_gov` does not fall at ₹0 revenue (§9.4) and why governance cost per team is roughly constant (§14.2).**

**[C] Two immediate levers follow, and both are already contemplated by the source or the stress test:**
1. **Reduce cadence** for teams below a maturity threshold — `g_fin_cyc × 4.33 → × 1` removes roughly three-quarters of the payment-cycle governance load. The source's weekly cycle is a **transparency** mechanism **[S: Ch.19 "Transparent team and higher-level review"]**; transparency does not require weekly frequency (stress-test R2, HC-17). **[P]**, and it does not alter the priority order.
2. **Share the fixed terms across `K` teams** at City level **[S: Ch.7]** — `g_audit`, `g_doc_rep` preparation, `H_fin` reconciliation and verification can be performed by City Funds Manager, City HR & Verification and City Editor functions that already exist. **This attacks the fixed term, which is the largest lever available (§14.2 result 2).**

## 25.3 The 22-SOP and 14-record load

**[S: App. D — 22 SOPs]** SOP-01 Application, 02 Identity, 03 Interview, 04 Probation, 05 Local Request Intake, 06 Service Project Execution, 07 Donation Handling, 08 Expense Approval, 09 Weekly Payment, 10 Reserve Release, 11 Venture Proposal, 12 Customer Delivery, 13 Safety Incident, 14 Public Statement, 15 Inventory Issue, 16 Transfer, 17 Ordinary Conduct, 18 Serious Misconduct, 19 Monthly Report, 20 Team Recovery, 21 AI Use, 22 Data Breach.

**[S: App. F]** 14 evidence record types, with sensitivity markings including "highly restricted" for conduct and safety-incident records.

**[C]** Of the 22 SOPs, the ones a Stage-0/1 team **cannot** avoid even at zero activity: **02 (Identity), 08 (Expense), 09 (Weekly Payment), 13 (Safety Incident), 14 (Public Statement), 17 (Ordinary Conduct), 18 (Serious Misconduct), 19 (Monthly Report), 22 (Data Breach)** — because each is triggered by *existence, risk or event*, not by volume. The rest are volume-triggered and fall to zero with activity.

> **[A] That gives a defensible minimum: roughly nine SOPs are existence-level and roughly thirteen are activity-level.** The stress test proposed a "Pilot Fidelity (6 mandatory records) vs Full Fidelity" split and a control-budget rule (M6). **This model's contribution is the criterion for the split: a record belongs in Pilot Fidelity if and only if its absence would be irreversible — money, safety, identity, conduct, privacy, public statement.** Everything else can be graduated in with maturity. That criterion is derived from the stress test's own institutionalisation table, where only **Safety and Finance** must be institutional early "because their failure is irreversible".

## 25.4 Scenario bands for `H_gov`

**[SC]** The stress test's band is **8–40 governance hours/team/month**, explicitly labelled "unknown" and "the single most important unknown in the whole model". This document tests the band rather than adopting it.

| Band | `H_gov` /month | `σ` at `N_act = 8`, `T_avail = 20 h` (=160 h pool) | Consequence **[C]** |
|---|---|---|---|
| **GB-1 Optimistic** | 8 | **5%** | Viable. Leaves ~152 h for delivery, sales, service and training. A T1 team can exist |
| **GB-2 Low-mid** | 16 | **10%** | Viable but tight. Governance is one person's part-time week |
| **GB-3 Stress-test midpoint** | 24 | **15%** | Strained. Governance ≈ 1.5 part-time people; `H_deliver` falls by a sixth |
| **GB-4 High** | 40 | **25%** | **A quarter of all available hours.** With `H_svc` and `H_acq` also required, `H_deliver` may be too small to reach `P_be` (§11.4) → **T1 and T2 are not viable; only City-shared governance works** |
| **GB-5 Stress-test arithmetic case** | ~13 from its worked example (2 h/week records + 1 h verification ≈ 13 h/month) | **8%** | "Roughly one full person-equivalent per team, before any service or business work" — the stress test's own framing |
| **GB-6 Above band** | 60 | **37.5%** | **The unit cannot exist.** Stress test: "if it is 25 hours/month the unit cannot exist" — 60 is beyond that |

**[A] Sensitivity conclusion, stated without pretending to know the answer:** the viability of the entire architecture turns on which band is real. **GB-1 to GB-3 → the architecture works roughly as written. GB-4 → it works only with City-shared governance (§26) and only for T3/T4 teams. GB-5+ → the operating model must be redesigned, not merely resourced.** Measuring `H_gov` is therefore the **first** pilot deliverable (§40), ahead of any revenue measurement — because if `σ` is too high, no revenue level saves the unit.

## 25.5 Governance hours by role — who actually carries it

**[A]** Mapped to the source's role families **[S: Ch.9]**, so the burden can be assigned rather than diffused:

| Role family | Governance hours carried | Notes |
|---|---|---|
| **HR & Verification Manager** (+ Verification Officer, Training & Probation Coordinator, Member Records Assistant, Conduct & Welfare Coordinator **[S]**) | `H_hr + H_ver` | **The heaviest load per head**, and it scales with *requests and applications*, not revenue |
| **Funds Manager** (+ Finance, Payment, Expense Verification, Revenue Reconciliation, Records Coordinators **[S]**) | `H_fin` | Bounded by cadence; **cannot self-approve [S: Ch.18]**, so every hour needs a second hand |
| **Team Leader** (+ Leadership Assistant, Team Coordinator **[S]**) | `H_lead` | Fixed plus decisions plus escalations; **the only role with no deputy guaranteed in State A** ("Sub-Leader *if available*" **[S: Ch.10]**) |
| **Planner** (+ Project Planning, Schedule, Resource Planning, Follow-up, Project Documentation Coordinators **[S]**) | `H_plan` | The only governance load that scales *usefully* with activity |
| **Safety/Protection Lead** | `H_audit` share + `N_inc` load | **Non-deferrable** (v1.3-A A-08/A-09) |
| **Editor / Social Media** | `H_doc` public-facing share | Public statement SOP-14; **corrections are permanent records** (v1.3-A A-15 M4) |
| **AI & Business Manager** | SOP-11, SOP-12, SOP-21 load + v1.3-A A-21 review caps | **Rises with AI use** (HC-11) |
| **Warehouse Manager** | SOP-15, SOP-16 | Falls to zero with no materials |
| **Volunteer Manager** (+ Shift, Attendance, Engagement, Support Coordinators **[S]**) | `H_hr` retention share | **The role that determines `r_ret`, and therefore `C_vol_per_hour` (§15.3)** |
| **Ground-Level Manager** | verification site visits, field logs | Per-request; **the highest-need areas carry the most** |

**[A] The distribution is the problem:** the three heaviest carriers — HR/Verification, Funds, Safety — are exactly the three "unpopular control roles" the stress test identifies (F-03) as facing social friction for saying no to neighbours, and exactly the three that **[S: Ch.18]** segregation rules prevent from being combined with each other. **So the least reducible governance load falls on the least supported people.** HC-18 and B-15/§26 exist for this reason.

---

# 26. CONTROL BUDGET

> **Objective from your brief, adopted verbatim:** MINIMUM CONTROL NECESSARY FOR TRUST. **Not** MAXIMUM CONTROL POSSIBLE.

## 26.1 How much governance can a small team realistically carry?

**[C]** From §25: `σ = H_gov / (N_act × T_avail)`. The team also needs `H_deliver` to reach `P_be` (§11.4) and `H_svc` to keep the mission alive (B-01). So:

```
σ_max = 1 − ( H_deliver_required + H_svc_budget + H_acq_required + H_train_required ) / (N_act × T_avail)
```

**[A]** `σ_max` is therefore **not a policy preference — it is derived from the team's own revenue requirement and mission commitment.** A team that must deliver `P_be` projects and honour a service budget has a *computable* governance ceiling. **If measured `σ > σ_max`, one of three things must change: `H_gov` (share it or reduce cadence), `N_act` (more people), or the commitments (lower `P_be` or `H_svc`).** There is no fourth option, and pretending otherwise produces the back-filling culture the stress test predicts (F-05, F-30).

## 26.2 MINIMUM VIABLE CONTROL

**[P] Proposal B-20.** The irreducible control set for a Stage 0–2 Mohalla team, derived by the §25.3 criterion — **a control is in the minimum set if and only if its absence causes irreversible harm to money, safety, identity, privacy, or public truth.**

| # | Minimum control | Why irreducible | Source |
|---|---|---|---|
| **MVC-1** | **Two-signature money handling** — receive / approve / record / audit in four distinct hands, one outside the team if necessary | Financial loss and fraud are irreversible; the source already forbids combining them | **[S: Ch.18 segregation; Funds Manager limits]** |
| **MVC-2** | **Member verification before any activity** | An unverified person acting in the organisation's name is an irreversible liability | **[S: Ch.12; SOP-01, SOP-02; Ch.13 gate]** |
| **MVC-3** | **Safety doctrine + the ten DO-NOTs + incident reporting** | Physical harm and vigilante perception are irreversible | **[S: Ch.16; Ch.9; v1.3-A A-08, A-09]** |
| **MVC-4** | **Safeguarding absolutes** — two-adult rule, no image of a minor, certified floor in regulated domains | Harm to a child is the highest-consequence event available | **[S: Ch.12 boundary; Ch.15 "no exposure of minors"; v1.3-A B6]** |
| **MVC-5** | **Beneficiary privacy and dignity rules** — no publication without separate consent; storytelling channel has no read access to service records | Dignity harm cannot be undone | **[S: App. F; v1.3-A A-19]** |
| **MVC-6** | **Expense receipt + approval link** | The audit trail is the only defence against leakage; "receipts, approval, direct-cost link" is already the anti-gaming control | **[S: SOP-08; Ch.25 expenses control]** |
| **MVC-7** | **Payment sheet with formula version, approvals and evidence retained** | A payment that cannot be shown to be correct destroys trust irreversibly | **[S: Ch.19 step 13 audit trail]** |
| **MVC-8** | **One monthly report** | Without it the City cannot see failure, and §23 detection latency becomes infinite | **[S: SOP-19; Ch.24]** |
| **MVC-9** | **Public statement control** — authorised spokesperson only; corrections logged | A misrepresentation, once public, is irreversible | **[S: SOP-14; Ch.24; v1.3-A A-06, A-07]** |
| **MVC-10** | **Data breach route** — who to tell, how fast | Statutory windows are short and unforgiving | **[S: SOP-22; v1.3-A A-17 P5]** **[X: 72-hour and 6-hour regimes]** |
| **MVC-11** | **Decision reason recorded** (one line) | Without it the institution cannot learn, and rules get deleted by the next person | **[v1.3-A A-15 M1]** |

**[C] What is explicitly NOT in the minimum set** — and may be graduated in with maturity, without any loss of trust:

| Deferred control | Reason it can wait | Graduates in at |
|---|---|---|
| Daily reporting cadence **[S: Ch.24]** | Daily "operational memory" is valuable but its absence is recoverable from the monthly record | Stage 3 |
| Weekly payment cycle **[S: Ch.19]** | Transparency is required; weekly frequency is not (§25.2 lever 1) | When contribution-positive |
| Full 14-record evidence set **[S: App. F]** | The six irreversible categories are already covered by MVC-1…MVC-11 | Stage 3, per record type |
| Quarterly and annual report preparation at team level | City and State already prepare these **[S: Ch.6, Ch.7]** | Never at team level — it belongs upward |
| Leaderboard participation **[S: Ch.25]** | Comparative scoring requires cohorts; a single team has none (stress-test F-19 cohort normalisation) | When `K` is large enough |
| Autonomy readiness audit **[S: Ch.13 gate 8]** | It certifies *freedom*, which a Stage-0 team does not yet need | Stage 3–4 |
| Sub-role openings **[S: Ch.10 State B]** | Deputies buy continuity, which matters once there is something to continue | Stage 3 |
| Vacancy taxonomy in full **[S: Ch.11 six statuses]** | A small team can operate on filled/unfilled | Stage 2 |

**[A] This is not a weakening of standards.** It is the stress test's own prescription — "**shrink the operating scope, not the standards**" (Scenario A) — made operational: the *standard* (money is controlled, people are verified, children are protected, truth is published) never relaxes; the *instrument count* does.

## 26.3 The control-budget rule, applied to this document

**[P]** The stress test's control-budget rule (M6) is: **any new mandatory record requires either automation or the retirement of an existing one.** Applied honestly to v1.3-A and v1.3-B:

| Instrument added | Retired or automated in exchange |
|---|---|
| v1.3-A A-04 refusal register | Automated: one structured form, no narrative; and it *replaces* ad-hoc escalation conversations |
| v1.3-A A-09 incident field extension | Retires informal incident narration; the form *is* the report |
| v1.3-A A-15 M1 rationale line | Retires the retrospective "why did we do this?" investigation, which costs far more |
| v1.3-A A-22 AI audit record | Automated entirely by the platform; zero human formatting |
| **v1.3-B B-01 service hour budget** | **Automated from existing task records [S: Ch.24 daily "tasks, attendance"]** — no new form |
| **v1.3-B B-05 accrual ledger** | **Automated from the existing payment sheet [S: Ch.19 step 13]** |
| **v1.3-B B-08 volunteer true-cost accounting** | **Automated from existing HR and training records [S: Ch.12]** |
| **v1.3-B B-17 "repeatedly" definition** | Retires case-by-case judgement, which is the most expensive control of all |
| **v1.3-B §27 dashboard** | **Must be auto-generated.** "Auto-generated reports from the platform so humans supply facts, not formatting" (stress-test F-05 mitigation d) |

**[A] Rule adopted for the future:** if an economic control cannot be automated from data the team already produces, **it is not adopted at Stage 0–2.** That is the practical meaning of "minimum control necessary for trust".

## 26.4 The City divisor — the largest single lever

**[C]** Sharing the fixed governance terms across `K` teams:

```
H_gov_per_team(K) = H_gov_fixed / K_shared + H_gov_local
```

where `K_shared` is the number of teams sharing a given City function and `H_gov_local` is what genuinely cannot be shared (site verification, local decisions, field logs).

| Function | Sharable at City level? | Source basis |
|---|---|---|
| Financial reconciliation, payment preparation | ✅ **City Funds Manager** exists | **[S: Ch.7]** |
| Verification cadre, identity checks | ✅ **City HR & Verification** exists | **[S: Ch.7]** |
| Training delivery | ✅ **State specialist pool — trainers** | **[S: Ch.6]** |
| Safety review, incident review | ✅ **City Safety**; High/Emergency review at City+ | **[S: Ch.7; v1.3-A A-09]** |
| Audit | ✅ **Auditor role is separate from operations by design** | **[S: Ch.23 "Review only; not operational commander"]** |
| Editorial, public statements, translation | ✅ **City Editor** exists | **[S: Ch.7]** |
| Inventory, logistics, materials | ✅ **City Warehouse / Logistics Manager** exists | **[S: Ch.7]** |
| Customer pipeline, venture proposals | ✅ **City AI & Business Manager** exists | **[S: Ch.7]** |
| Report preparation and formatting | ✅ should be automated | **[S: Ch.24; stress-test F-05(d)]** |
| Site verification, local decisions, field execution, relationships | ❌ **irreducibly local** | **[S: Ch.8]** |

> **[A] The conclusion is striking: every shared function required by the minimum control set already exists as a named City or State role in the architecture.** The Mohalla team does not need to *be* given shared services — it needs to be *allowed to use* the ones already designed. **That permission is the cheapest viability intervention available, and it requires no new structure, no new money and no new rule.**

**[P] Proposal B-21 — City Shared Services Contract.** Each Mohalla team has a written, published statement of which functions the City performs on its behalf, at what cadence, with what response time, and what the team retains. **Purpose:** to make the divisor explicit, so that neither layer assumes the other is doing it — which is the actual failure mode in every small-organisation governance collapse. `PROPOSED — REQUIRES FINAL APPROVAL`.

## 26.5 Minimum viable `K`

**[C]** The City layer has its own cost `C_city`. Allocating it across `K` teams:

```
C_per_team_total = C_L1_local + (C_city + C_L1_fixed_shared) / K
```

`K` must be large enough that `C_per_team_total` is below the contribution a team can realistically generate:

```
K_min = (C_city + C_L1_fixed_shared) / ( CM̄_j × P_realistic − C_L1_local )
```

**[A]** No value is asserted — `C_city`, `CM̄_j` and `P_realistic` are all pilot outputs. **But the structure of the formula carries the finding:** `K_min` rises sharply when the denominator is small, i.e. **in poor neighbourhoods a city needs *more* teams to afford the shared layer, while being *less* able to form them.** That is the inequality at the heart of the scaling question, and §31.2 and §32 develop it rather than resolving it.

---

# 27. UNIT ECONOMICS DASHBOARD

**Design rules [P]:** (i) every field must be **auto-derivable** from a record the team already creates, per §26.3 — "humans supply facts, not formatting" (stress-test F-05 mitigation d); (ii) nothing is added that is not either a decision input or an early-warning signal; (iii) the dashboard **extends** the existing Team Leader dashboard **[S: Ch.24 — "Team health, projects, revenue, expenses, members, safety, performance, leaderboard, vacancies and support needs"]** rather than replacing it; (iv) fields already present in v1.3-A's audit instruments are reused, not duplicated.

## 27.1 Financial panel

| Field | Formula / source record | Existing in source? | Class |
|---|---|---|---|
| Revenue collected `V_gross` | **[S: Ch.19 step 3 reconciliation]** | ✅ | **[S]** |
| Revenue invoiced, and `r_collect = collected/invoiced` | **[S: Ch.17 step 11]** | ✅ (implied) | **[C]** |
| Direct costs `C_var` | **[S: Ch.19 step 4 expense verification; SOP-08]** | ✅ | **[S]** |
| Worker compensation paid `A_1` | **[S: Ch.19 step 7]** | ✅ | **[S]** |
| **Accrued unpaid compensation (B-05)** | `Σ verified work − Σ paid`, aged | ❌ **new** | **[P]** |
| Statutory dues `A_2` | **[S: Ch.19 step 5]** | ✅ | **[S]** |
| Reserves contributed `A_6`, and `Reserve_months` | §21.5 B-15(3) | ⚠️ balance only | **[C]** |
| Organisation allocation `A_5` | **[S: Ch.19 step 9]** | ✅ | **[S]** |
| Social-impact allocation `A_7` | **[S: Ch.19 step 11; Ch.20]** | ✅ | **[S]** |
| Cash position | ledger | ✅ | **[S]** |
| Outstanding receivables, aged | **[S: Ch.17 step 11]** | ⚠️ implied | **[C]** |
| Float drawn / outstanding / term remaining (B-04) | ❌ **new** | ❌ | **[P]** |
| **Solvency line reached this period (S-1…S-6)** | §8.3 | ❌ **new** | **[C]** |
| **Scenario position (SC-0…SC-200)** | §10.2 | ❌ **new** | **[C]** |
| **Contribution per project `CM̄_j` and per delivery hour** | §11.4 | ❌ **new** | **[C]** |

## 27.2 Operational panel

| Field | Source record | Class |
|---|---|---|
| Active members `N_act` (contributed this month) | **[S: Ch.25 "attendance cross-checked"]** | **[S]** |
| Verified members `N_ver` | **[S: Ch.12]** | **[S]** |
| **Active ratio `r_act = N_act / N_ver`** | §14.3 — **the planning variable that matters** | **[C]** |
| Roles filled / nine required functions covered | **[S: Ch.10; Ch.13 gate]** | **[S]** |
| **Segregation status: are the four finance hands distinct?** | §3.3 | **[C]** |
| Service activities completed, with outcome verification | **[S: Ch.15 steps 9–10]** | **[S]** |
| **Service hours actual vs `H_svc_budget` (B-01)** | ❌ **new** | **[P]** |
| Completed projects `P_delivered`; backlog | **[S: Ch.17 steps 8–10]** | **[S]** |
| **Delivery capacity `P_max` and utilisation `P_delivered / P_max`** | §17.2 | **[C]** |
| Incidents, by tier | **[S: Ch.16; SOP-13]** | **[S]** |
| Training status and certification expiry | **[S: Ch.12; v1.3-A A-10 §9.5]** | **[S]+[P]** |
| **Governance hours `H_gov` and share `σ`** | §25 | **[C]** — *the most important new field in the dashboard* |

## 27.3 Human panel

| Field | Source record | Class |
|---|---|---|
| Retention `r_ret`; exits by reason | **[S: Ch.25 "healthy active retention, not inactive names"]** | **[S]** |
| Attendance | **[S: Ch.9 Attendance Coordinator; Ch.24 daily]** | **[S]** |
| **Workload per role-holder — hours by function** | §25.5 | **[C]** |
| Member development: trainings, role progress | **[S: Ch.25 dimension; Ch.24 "achievements"]** | **[S]** |
| **Leadership pipeline: named successor per role** | **[S: Ch.9 succession column; Ch.26; B-18(1)]** | **[S]+[P]** |
| Volunteer-to-active conversion | **[S: Ch.11 vacancy lifecycle; Ch.12 probation]** | **[C]** |
| **`C_vol_per_hour` and `T_be` vs actual tenure (B-08)** | §15.3 | **[P]** |
| **Control-role tenure (HR, Funds, Safety) — HC-18 signal** | §25.5 | **[P]** |
| Dissent and concern counts via the independent route | stress-test M10; v1.3-A A-16 test 3 | **[P]** |

## 27.4 Business panel

| Field | Source record | Class |
|---|---|---|
| Leads `N_lead`; proposals; customers `N_cust` | **[S: Ch.7 City pipeline; Ch.17 steps 2, 5]** | **[S]** |
| Active projects; completion rate `r_accept` | **[S: Ch.17 steps 8–10]** | **[S]** |
| **Repeat customers `r_repeat`; referrals `r_referral`** | §18.5 — **the two metrics that matter most** | **[C]** |
| **Payment delay `Δt_collect`; ageing buckets** | §18.6 | **[C]** |
| **`H_acq` hours and `CAC` (mostly hours, not cash)** | §18.2 | **[C]** |
| Revisions per project `h_rev` | **[S: Ch.17 step 9]** | **[S]** |
| **Estimated vs actual hours per project (HC-06)** | §5.2 | **[C]** |
| Venture category and approval status | **[S: Ch.17 step 3; Ch.33 POTENTIAL]** | **[S]** |

## 27.5 Risk panel

| Field | Threshold logic | Class |
|---|---|---|
| Unresolved incidents, ageing | Any High/Emergency unresolved escalates **[S: Ch.16; v1.3-A A-09]** | **[S]** |
| Overdue verification | `N_act` backlog beyond approved window **[M]** | **[P]** |
| Overdue financial reconciliation | **[S: Ch.13 gate "no unexplained material gaps"]** | **[S]** |
| Privacy issues / access anomalies | **[S: SOP-22; v1.3-A A-17 P5, A-20]** | **[S]+[P]** |
| Safety issues | **[S: Ch.14 safety failure — "immediate stop-work"]** | **[S]** |
| **Dependency on one customer** (`share of V_gross`) | B-07(3) concentration limit **[M]** | **[P]** |
| **Dependency on one revenue source** (category share) | B-07(3) | **[P]** |
| **Dependency on one leader** (functions held; successor named?) | §24; B-18(1); HC-02 | **[P]** |
| **Dependency on one skill** (`N_skilled` for the active venture) | §17.4 bottleneck 2 | **[P]** |
| **Float burn rate vs term remaining** | B-04; §9.6 | **[P]** |
| **`σ` (governance share) vs `σ_max`** | §26.1 — **the single best early-warning indicator in the model** | **[C]** |

## 27.6 Dashboard discipline

**[P]** Four rules, because a dashboard can itself become a governance burden (HC-22):

1. **Auto-generated or not at all** (§26.3). Any field requiring manual formatting is rejected.
2. **One page, one cadence.** The Team Leader sees one page; the City sees the same page aggregated **[S: Ch.24 dashboards already separate Member / Team Leader / City / State / National / Auditor]**.
3. **Every threshold breach routes to a named action,** not to a colour. A red field with no action is decoration.
4. **The dashboard is evidence, not judgement.** Scores and rankings remain governed by **[S: Ch.25]** with its anomaly review, corrections and appeals — and by §28's warning about composite scores.

---

# 28. UNIT HEALTH MODEL

## 28.1 Is a single score useful? — investigated, not assumed

**[A]** Your brief asks whether a single score is useful and warns: **do not allow REVENUE = TEAM HEALTH.** The evidence in the source and in this model points one way.

**Arguments for a single score:**
- The architecture already has one, for a different purpose: the team score and leaderboard **[S: Ch.25]**, with proposed weights 20/15/15/15/10/10/10/5.
- A single number travels upward cheaply across five cadences and six dashboards **[S: Ch.24]**.
- Comparison across teams requires a common unit.

**Arguments against — and they are stronger:**
1. **The source itself refuses the inference.** "Raw revenue, follower count, social-media views, volunteer count, application count or raw activity count **cannot determine leadership**" **[S: Ch.25]**; "Revenue alone is insufficient because it can push teams to neglect service, safety, member development or truth" **[S: App. A §18.1]**.
2. **The weights are PROPOSED, not final** **[S: Ch.25; Ch.33 "Leaderboard weights — PROPOSED — Pilot 20/15/15/15/10/10/10/5 formula; adjust after testing"]**. Building an economic health score on unfinalised weights would convert a proposal into a rule — which your standing instructions forbid.
3. **A single team has no cohort.** Comparative scoring across teams in different neighbourhoods with different `CM̄_j` and different payable demand is not comparison, it is a lottery (stress-test F-19, cohort normalisation).
4. **Composite scores create gaming — measurably.** §28.3.
5. **The dimensions are not commensurable.** Money, safety, dignity and trust cannot be traded against each other at a stated exchange rate without implying that enough money compensates for an unsafe act. **The architecture already rejects that trade: "Unsafe success is not success" [S: Ch.25].**

## 28.2 Recommendation: a dashboard with veto gates, not a score

> **[P] Proposal B-22 — Health Panel with Veto Gates.** Economic health is reported as **eight dimensions plus four veto gates**, and is never reduced to one number at team level.

**The eight dimensions** (your brief's list, each with its own unit — never summed):

| Dimension | Reported as | Source anchor |
|---|---|---|
| **Mission impact** | Outcome-verified service activities against `H_svc_budget`; **never** planned activity | **[S: Ch.15 step 10 "Did the project solve or reduce the problem?"; Ch.15 "Do not count planned activities as completed impact"]** |
| **Financial health** | Solvency line reached (§8.3); `Reserve_months`; cash; accruals aged (B-05) | **[S: Ch.18, Ch.19]** |
| **Operational health** | `P_max` utilisation; backlog; completion rate; revision rate | **[S: Ch.17]** |
| **Member health** | `r_act`, `r_ret`, `C_vol_per_hour`, `T_be` vs tenure, workload per role | **[S: Ch.25 retention control; §15]** |
| **Business health** | `r_repeat`, `r_referral`, `Δt_collect`, `CM̄_j / h_proj`, concentration | §18 |
| **Safety** | Incidents by tier; unresolved ageing; DO-NOT breaches (any = veto) | **[S: Ch.16; v1.3-A A-08]** |
| **Compliance** | Reconciliation gaps; verification backlog; privacy anomalies; audit findings | **[S: Ch.13 gates; Ch.27; v1.3-A A-17]** |
| **Resilience** | `M_runway`; float term remaining; successor named per role; dependency ratios | §9.6; §24; §27.5 |

**The four veto gates** — any one breached means the unit is **not healthy, regardless of every other dimension**:

| Gate | Breach condition | Source |
|---|---|---|
| **V-G1 Safety** | Any DO-NOT breach, any unresolved serious safety matter, any uncertified activity in a regulated domain | **[S: Ch.16; Ch.14 "immediate stop-work"; v1.3-A A-08]** |
| **V-G2 Money integrity** | Any unreconciled gap, any self-approved expense, any payment that cannot be shown correct, any use of a restricted fund for a prohibited purpose | **[S: Ch.18 segregation; Ch.20 restrictions; Ch.13 finance gate]** |
| **V-G3 Dignity and privacy** | Any publication without consent, any exposed minor, any sealed-record misuse | **[S: App. F; v1.3-A A-19, A-20]** |
| **V-G4 Truth** | Any counted plan as impact, any inflated evidence, any uncorrected public misstatement | **[S: Ch.15; Ch.25 anti-gaming; Ch.24 corrections]** |

**[A] Why veto gates rather than weights:** a weight says *how much* a failure costs; a veto says *this failure is not tradeable*. The source already thinks in vetoes — "Unsafe success is not success" **[S: Ch.25]** — and v1.3-A entrenched the DO-NOT list against exactly this kind of trade-off (A-08, Tier-1). **B-22 extends that logic to economics: no revenue makes a vetoed team healthy.**

## 28.3 Does a composite score create gaming? — tested explicitly

**[A]** Yes, predictably, and the source's own anti-gaming table **[S: Ch.25]** is evidence that the designers knew it. Applied to an *economic* composite:

| Gaming vector | How it appears | Existing source control | Residual risk after that control |
|---|---|---|---|
| Revenue weight | Accept bad-margin work; under-price to close; book invoiced as collected | "Collected legitimate customer revenue; exclude fake/circular/related-party manipulation" **[S]** | **Margin and collection quality are invisible in a revenue figure** — hence `CM̄_j / h_proj` and `Δt_collect` reported separately (§27.4) |
| Mission weight | Count activities, not outcomes; photograph distributions | "Completed verified outcomes"; "Do not count planned activities as completed impact" **[S]** | Outcome verification is itself performed by the team — **independence needed at City level [S: Ch.7]** |
| Member/retention weight | Keep inactive names on roll; recruit to inflate counts | "Verified members/approved participants only; attendance cross-checked"; "healthy active retention, not inactive names" **[S]** | **Recruitment is cheaper than retention**, so pressure still points the wrong way — hence `C_vol_per_hour` and `T_be` (B-08) |
| Safety/compliance weight | Under-report incidents | **[S: Ch.14 "incident concealment" is itself a failure signal; v1.3-A A-09 mandatory escalation]** | Concealment is only detectable by pattern review — hence the veto gate, not a weight |
| Innovation weight | Novelty for its own sake | "Useful improvements should be rewarded but not gamed" **[S]** | Low stakes; leave as is |
| **Composite itself** | **Optimise the score rather than the mission** | — | **This is the decisive argument against B-22 using a single number** |

> **[C] Conclusion:** a composite economic score at team level would be **gameable in at least six identifiable ways**, four of which the source already has controls for and two of which (margin quality and the composite-optimisation effect itself) it does not. **Therefore: dashboard plus veto gates, not a score.** Where a single comparative number is genuinely required — the leaderboard **[S: Ch.25]** — it remains governed by the source's own PROPOSED weights, cohort normalisation (stress-test M8) and anomaly review, and **is not extended into an economic health verdict.**

## 28.4 What replaces "is this team healthy?"

**[P]** Three questions, answerable from §27 without a score:

1. **Can it pay its people and its legal obligations this period?** → solvency line (§8.3) + accrual ageing (B-05).
2. **Can it survive the next shock?** → `M_runway` (§9.6) + `Reserve_months` (§21.5) + successor coverage (§24).
3. **Is it doing the mission, honestly and safely?** → outcome-verified service vs budget (B-01) + four veto gates.

**[A]** If the answer to all three is yes, the team is healthy — **whether or not its revenue is large.** A team at SC-75 with a named successor, a defended service budget and no veto breach is healthier than a team at SC-150 with one customer, no deputy and an unresolved incident. **That is the judgement a score would hide.**

---

# 29. FAILURE SIMULATIONS

**Method:** each of your twelve scenarios is run against the model. **Financial impact is expressed in variables and solvency-line movement, never in rupees.** "Survivability" is answered against `M_runway` (§9.6), the veto gates (§28.2) and the source's stopping conditions (§23.3).

| # | Scenario | Trigger | Financial impact **[C]** | Operational impact | Human impact | Recovery mechanism | Escalation point | Survivability |
|---|---|---|---|---|---|---|---|---|
| **1** | **₹0 revenue for 3 months** | Venture not approved, or no demand, or QA/acceptance failure | `V_gross = 0` → all `A_i = 0`; solvency **none**; `M_runway = F_0 / L_min` consumed | Service in time-costed categories only (B-02); `H_gov` **unchanged**; acquisition becomes the whole economic activity | Money-motivated members exit first **[I]**; control roles carry full load with no reward; expectation breach if recruitment over-promised (F-02) | §9.5: stop recruiting, shrink scope not standards, publish truth, convert effort to pipeline; B-04 float; City pipeline **[S: Ch.7]** | City at month 1 of zero; §23 support at the reassessment point | **Survivable only if `F_0 ≥ 3 × L_min` AND expectations were honest AND the City pipeline functions.** Otherwise **not survivable** |
| **2** | **Main customer disappears** | Concentration (HC-24); customer insolvency; relationship loss | `V_gross` falls by that customer's share; solvency line drops one or more steps; `A_1` at risk → **B-06 pro-rata** | `P_max` suddenly idle; `H_acq` must spike (§18.2 lag = one period of lost revenue) | The member who owned the relationship is blamed or leaves; confidence falls | B-07(3) concentration limits *prevent* this; B-11 idle-capacity doctrine; B-10 referral to other teams; City pipeline | City business review **[S: Ch.7 lane 5]** | **Survivable if concentration limits were in force. If one customer was >50% of revenue, likely not survivable inside one period** |
| **3** | **Top business worker leaves** | Better offer; relocation (~26% of exits **[X]**); burnout | Delivery capacity `P_max` falls by their share; in-flight projects at risk → `r_accept` falls; possible refunds | Skill gap cannot be filled locally; State specialist pool required **[S: Ch.6]** | Remaining members absorb the load → HC-01 chain; morale falls | Successor-before-transition discipline (B-18); skill redundancy as a B-07(3) condition; cross-training as `H_train` budget | State specialist deployment **[S: Ch.6]** | **Survivable if the skill was not unique. If it was, the venture pauses per [S: Ch.14 business failure] and the team reverts to service** |
| **4** | **Team leader leaves** | Promotion (the *good* case, §24.2); relocation; conflict; removal | Payments and decisions stop (HC-02) because Funds cannot self-approve **[S: Ch.18]**; float/reserve requests cannot be signed | Everything routed through the Leader queues; escalations rise | Highest-impact single exit; the team's external face disappears | **B-19 Local Interim Authority Order** + Sub-Leader delegation **[S: Ch.10]** + City fallback **[S: Ch.7]**; v1.3-A A-14 pattern | City immediately; State if no local deputy | **Survivable if B-19 exists. Without it, a leader exit is a team-ending event in all but name** |
| **5** | **50% volunteer dropout** | Season (exams, harvest, festivals); a broken promise; a social conflict; relocation | `N_act` halves → `H_pool` halves → `P_max` halves; but `H_gov` **per head rises** because fewer people carry the same fixed load (§25.2) | Service output halves; `H_svc_budget` breached; verification backlog grows | Survivors are overloaded; the exit reason, if organisational, will repeat | Retention instruments **[X]**; recognition **[S: Ch.24 achievements]**; stay interviews (stress-test M-items); B-08 measurement to find whether `T_be > T_actual` | City HR support **[S: Ch.7; Ch.14 HR failure row]** | **Survivable — but `σ` may exceed `σ_max` (§26.1), which converts a people problem into a control failure. This is the most common real death spiral** |
| **6** | **Unexpected major service expense** | Flood, fire, collapse, disease outbreak, mass need | `C_mat` and `C_trans_em` spike; **no funding line** (§8.4); social-impact fund unavailable unless surplus conditions already met **[S: Ch.20]** | Service demand exceeds capacity; the team is visible in a crisis it cannot resource | Members spend personally (HC-03) → debt-based loyalty; burnout | **Category 7 is City/State-resourced under B-02**; emergency reserve release via SOP-10 with B-15(1) latency target; City materials **[S: Ch.7]**; State projects **[S: Ch.6]** | **Immediate** — City, then State; authorities first for infrastructure/emergency **[S: Ch.15 "Permissions, authorities first, no obstruction"]** | **Not survivable at team level by design — and correctly so.** The architecture never intended a Mohalla team to fund a disaster. **Survivability depends entirely on the escalation latency being real** |
| **7** | **Customer payment delayed 60 days** | Normal SME behaviour **[I]**; dispute; cash cycle | Invoiced ≫ collected; whether workers are paid depends on the **unresolved receipts-vs-invoiced policy [V]** (§12.3 row 3, E-07) | New work cannot be funded for materials; `P_max` idle while cash is trapped | Workers who delivered are unpaid → the single most damaging routine event (§12.4) | **B-05 accrued ledger + B-06 pro-rata + B-13 collection terms (advance/milestone)**; City business review **[S: Ch.7 lane 5]** | City at stated ageing (B-13(v)) | **Survivable if B-13 advance terms were used. Without them, a 60-day delay consumes `M_runway` and the team fails while profitable on paper** |
| **8** | **Business project fails QA** | Skill gap; scope creep; revision loop | `h_rev` and `h_qa` consumed with no revenue; `r_accept` falls; possible refund; direct costs sunk | `P_max` consumed by rework; delivery of *other* projects delayed | The worker's confidence and standing; blame risk if the failure is punished rather than reviewed | QA plan at assignment **[S: Ch.17 step 6]**; hour estimate at approval (HC-06); State specialist support **[S: Ch.6]**; **a failure is a learning event if money is reconciled and customers treated fairly [S: App. A §13.5]** | City AI & Business **[S: Ch.7]** | **Survivable, and should be treated as normal.** Failing QA is the control working. **What is not survivable is a culture where QA failure is hidden** (V-G4 truth veto) |
| **9** | **High revenue, poor service outcomes** | The incentive distortion §35 predicts | Financially strong: `B_healthy`+ reached; solvency S-4/S-5 | `H_svc_budget` breached; mission impact (20% weight **[S: Ch.25]**) falls | Members who joined for the mission leave; the team's character changes; local trust falls | **B-01 service hour budget makes the trade visible**; B-22 reports mission as a dimension, not a residual; §35 mitigations | City review of mission balance; the source's own answer — mission impact carries the **highest** weight **[S: Ch.25]** | **Economically survivable, mission-fatal.** This is the scenario in which the organisation succeeds at the wrong thing. **V-G4 does not catch it, so B-01 must** |
| **10** | **Excellent service, almost no revenue** | High-need, low-payable-demand area | Below `B_bare`; `M_runway` falling; no `A_1` ever | Service output high; verification load high (HC-08) | Strong mission commitment, no income; eventual burnout or exit of the most committed | **§22 Layer 1 non-cash transfer**; B-10 referral of *capacity* to a revenue-rich team; B-04 float; **§32/§33: this team should be subsidised deliberately, not accidentally** | City and State; a funding decision, not a performance decision | **Not self-sustaining — and the honest answer is that it should not be expected to be.** See §32.4: this is the clearest case for a *chosen* subsidy with a *named* source |
| **11** | **Two teams require support simultaneously** | Correlated shock (§21.3) | Both draw on the same City/State capacity; reserve requests arrive together at one National matrix **[S: Ch.18]** | The supporting team (step 4 **[S: Ch.14]**) cannot support two; State specialist pool is finite **[S: Ch.6]** | Support quality falls for both; the "capable team" is itself weakened (§22.5) | Prioritisation rule needed *in advance*; State may "temporarily support or supervise a struggling City Team" **[S: Ch.6]** — but one at a time | **State escalation filter [S: Ch.6]**, then National | **Not survivable for both without external resource.** This is the scenario that proves Layer 4 (central pool) will eventually be needed — §22.4 defers it, it does not deny it |
| **12** | **City-level support itself becomes financially constrained** | The centre is funded at priority 5 (§8.6) and receives nothing from struggling teams | `C_city` unfunded → the divisor `K` fails → `H_gov` per team jumps back to local (§26.4) | Every shared function degrades at once: verification, finance, pipeline, training, incident review | Teams discover simultaneously that the support they were promised does not exist — the worst possible moment for trust | **This is a national-level failure, not a team-level one.** B-03/B-04 seeding, §8.6 centre-funding decision (E-03), and §31.2's `K_min` must be satisfied *before* the City layer is promised to teams | National; CEO; Council (v1.3-A N19) | **If this happens, no Mohalla team is survivable** — because §3.3 proved none can be self-contained. **This is the model's most severe finding** |

## 29.1 What the twelve simulations show together

**[A]** Five conclusions, none of which is a forecast:

1. **Nine of twelve scenarios are survivable with an instrument the source does not yet have** — B-04 float, B-05 accrual, B-06 scarcity rule, B-13 collection terms, B-19 local interim authority, B-15 escalation latency, B-21 shared-services contract. **That is the amendment pack's justification (§44).**
2. **Scenario 6 and Scenario 12 are not survivable at team level by design** — and correctly so. A Mohalla team should not fund a disaster, and cannot fund its own City. **Both are arguments for explicit resourcing decisions at the top, not for team-level heroism.**
3. **Scenario 9 is the most dangerous**, because it looks like success. It is the only scenario in which every financial indicator improves while the mission fails. **No score would catch it; B-01 and B-22 would.**
4. **Correlation is the real risk, not frequency.** Scenarios 1, 5, 6, 7 and 11 share drivers — season, local economy, one customer, one monsoon. **A risk register that counts events independently will underestimate the joint probability** (stress-test F-18 reached the same conclusion for geography).
5. **Detection latency decides everything.** In every scenario the difference between survivable and fatal is how early it was seen — which is why §27's `σ`, accrual ageing, concentration ratios and successor coverage are early-warning fields rather than reporting fields.

---

# 30. MOHALLA ECONOMIC MATURITY

**Rule:** no revenue thresholds are invented. Stages are defined by **evidence**, and the structure is marked **[P]** because the source contains economic *staffing* states **[S: Ch.10]** and *launch* phases **[S: Ch.30]** but no economic maturity ladder. Where a stage corresponds to an existing source construct, that construct is cited and the correspondence is explicit.

## 30.1 The seven stages

| Stage | Name | Corresponds to | Minimum evidence required | Financial characteristic | Operational characteristic | Leadership characteristic | What it may do | What it must not yet do | Principal risks |
|---|---|---|---|---|---|---|---|---|---|
| **0** | **Formation** | Pre-Phase-2 **[S: Ch.30]**; before State A is staffed | Nine functions identified with named holders; four finance hands distinct (§3.3); verification SOP live; float `F_0` and term agreed (B-04); payment cadence and earnings reality disclosed in writing (§12.6) | `V_gross = 0`; funded entirely by float/seed | Recruiting, verifying, training; no delivery | Appointed, not yet earned; a City sponsor exists | Form; verify; train; build pipeline; run time-costed service (B-02) | Take customers; make payment promises; open sub-roles; publish capability claims | Expectation mismatch (F-02); formation cost overrun; no City pipeline |
| **1** | **Proof** | State A operating **[S: Ch.10]**; Phase 2 exit evidence **[S: Ch.30 "Pilot report, safety review, finance reconciliation, member feedback, improvement plan"]** | One full project cycle completed with request, verification, execution, evidence and report **[S: Ch.13 gate]**; reconciled records with no unexplained material gaps **[S]**; one outcome-verified service project **[S: Ch.15 step 10]** | First `V_gross > 0`; below `B_bare` or between `B_bare` and `B_healthy` | Delivery proven once; QA proven once; `H_gov` **measured for the first time** | Leader has survived one payment cycle honestly | Accept approved-category work; report solvency line; measure `σ` | Scale; recruit aggressively; open sub-roles; claim self-sufficiency | `σ > σ_max` (§26.1); first accrual (B-05); first dispute |
| **2** | **Operating** | State A complete; Phase 3 entry **[S: Ch.30 "Operate multiple Mohalla Teams with city coordination"]** | Repeat delivery — `r_repeat > 0`; `CM̄_j / h_proj` measured and above the approved floor; `H_gov` stable and shared per B-21; MVC-1…MVC-11 all live | At or above `B_healthy` for `n` periods **[M]** | `P_max` is the constraint, not approval or skill | Sub-Leader named and delegated (B-18(1)) | Run two tracks (B-14); refer excess demand (B-10); publish service-hour budget | Enter regulated domains; open State B sub-roles without B-07; accept concentration above limits | Capacity ceiling breached (B-10); seasonality (HC-15); leader dependency |
| **3** | **Sustainable** | Approaching autonomy readiness **[S: Ch.13 gates 1–8]** | All eight autonomy gates evidenced: membership, operations, finance, safety, HR, business, community trust, audit **[S]** | At or above `B_growth`; reserves accumulating (`S_5 > 0`) | Full service + venture balance; succession pipeline real | Leader could leave for one month without collapse (v1.3-A A-16 test 1 applied locally) | Open sub-roles on need **[S: Ch.10]**; support another team (§22 Layer 1); graduate to fuller evidence fidelity | Assume permanence; treat reserves as available (§21.2); reduce controls because things are going well | Complacency; governance drift; the promotion tax (§24.2) |
| **4** | **Autonomous** | State C / "Autonomous team — completed/trusted team with broad local flexibility inside central standards" **[S: Ch.34, Ch.13]** | Autonomy readiness audit passed **[S: Ch.13 gate 8]**; no unresolved serious breach; evidence at full fidelity | At or above `B_resilient`; `Reserve_months` above target **[M]** | Chooses its own venture mix inside approved categories **[S: App. A §16.1]** | Earned leadership; recognized as a support provider | Broad local flexibility **inside central standards**; mentor other teams | Alter central standards, compensation, waterfall, protection boundaries or data policy **[S: App. A §16.3; Ch.6]** | Autonomy mistaken for independence — §3.3 proves no team is self-contained |
| **5** | **Support-Capable** | **[S: Ch.14 step 4 "Capable team from same or another city may support"]**; Head Team concept **[S: Ch.34]** | Has actually supported another team with a recorded outcome; has spare `H_deliver` after its own `P_max` and `H_svc` | Contributes to City/State through priority 5; can absorb a support cost | Exports people and skill, not just money | Leader is a candidate for the City layer — **and B-18 must be applied before promotion** | Provide step-4 support; host trainees; hold City-shared functions | Support so much that its own `H_svc_budget` is breached (§22.5) | The success tax (§24.2); burnout of the strongest team |
| **6** | **Replication-Capable** | **[S: Ch.30 Phase 4–5]**; stress-test scaling conclusion | Has produced a *leader* who now runs another team; its own SOP variants are documented as lessons (v1.3-A A-15 M5); its economics are reproducible in a *different* neighbourhood, evidenced | Its model survives transfer to a lower-demand area **or the difference is explicitly subsidised** | Replicates by exporting people and method, not by growing headcount | Succession has occurred at least once without collapse | Seed new teams; hold training capacity; contribute to the central pool (§22 Layer 4) | Assume its neighbourhood's economics generalise (§31.3 proves they do not) | False replication — exporting the model without the subsidy that quietly made it work |

## 30.2 Stage discipline

**[P]** Four rules:

1. **A stage is evidenced, not declared.** Each stage lists *minimum evidence*; the absence of evidence means the team is at the previous stage whatever its revenue.
2. **Stages can be lost.** Falling below `B_healthy` for `n_consecutive` periods (B-17) returns a Stage-3 team to Stage 2, and a veto-gate breach (§28.2) returns any team to Stage 1 pending review. **A ladder that only ascends is a leaderboard, not a control.**
3. **Stage does not equal size.** A six-person team can be Stage 3; a thirty-person team can be Stage 1. **The stages measure evidence and resilience, never headcount** — consistent with **[S: Ch.25]** refusing to let counts determine leadership.
4. **Stage 6 is the only stage that answers the replication question,** and it requires proof in a *different* neighbourhood. Your brief's core principle — "A HEALTHY LOCAL UNIT CAN REPLICATE" — is Stage 6's entry condition, and it is deliberately the hardest evidence in the ladder.

---

# 31. NATIONAL SCALING ECONOMICS

**Rule from your brief, adopted:** national scale is **not** multiplication. Every quantity below is derived from the unit model of §3–§29 and then tested for non-linearity.

## 31.1 The cost structure at scale

**[C]** Total cost at `T` teams organised into `C` cities and `S` states:

```
Cost_total(T, C, S) = T × C_team_local
                    + C × C_city
                    + S × C_state
                    + C_national
                    + T × C_support_expected      ← §23 failure support, expected value
                    + T × C_shock_expected        ← §5 L4 layer, expected value
                    + C_platform(T)               ← §31.3: non-linear
                    + C_assurance(T)              ← §31.3: non-linear
```

with `C_team_local = C_L1_local + C_L2_share + C_L3 + C_gov_local`.

**[A]** The first term is linear in `T`. **Everything else is not**, and the non-linearities are the finding.

## 31.2 The City divisor — and its floor

**[C]** From §26.4 and §26.5:

```
C_per_team(T, K) = C_team_local + (C_city + C_state/S_per_city + C_national/T) / K
```

where `K = T / C` is teams per city.

**Three regimes [C]:**

| Regime | Condition | Behaviour |
|---|---|---|
| **Sub-viable** | `K < K_min` (§26.5) | The shared layer costs more per team than the team can contribute. **Every team is subsidised and none can be self-sustaining** |
| **Efficient** | `K ≈ K_min … K_opt` | Per-team cost falls steeply as `K` rises. **This is the only regime in which Stage 3+ is reachable for ordinary neighbourhoods** |
| **Congested** | `K > K_opt` | City coordination, pipeline management and incident-review capacity saturate; per-team cost **rises again**; the stress test's warning that metro cities "could exceed 200 [teams], requiring a sub-city zone layer not in the architecture" becomes live |

> **[A] The most important scaling result in this document: viability is a property of `K`, not of `T`.** A national organisation of 10,000 teams spread as 1,000 cities of 10 teams is **less** viable per team than 500 cities of 20 teams — and both are less viable than a smaller number of denser cities. **Growth policy is therefore a density policy.** The architecture already implies it: the layer above Mohalla is the City **[S: Ch.7]**, and the stress test concluded that ~100k members "needs a professional institutional layer".

## 31.3 Non-linear costs

| # | Non-linearity | Why it is not linear | Source / evidence | Consequence |
|---|---|---|---|---|
| **NL-1** | **Assurance and audit** | 100% verification of 10 teams is possible; of 100,000 teams it is not. Assurance must convert from *examination* to *sampling plus anomaly detection* | **[S: Ch.27 seven-step audit × six domains]** assumes examination; stress-test §26: "~100k needs professional institutional layer + sampling assurance" | A new function must be built — risk-based sampling — which does not exist in v1.2 |
| **NL-2** | **Trainer supply** | Leadership and certification are produced by people, not by curriculum | stress-test: "Trained-leader production rate — limited by trainer supply, not by curriculum… the binding constraint at every stage above 1,000 members"; **[S: Ch.6 specialist pool]** | Team formation rate is capped by leader stock (§24.5), **not by demand or money** |
| **NL-3** | **Governance constancy** | `H_gov_fixed` per team does not fall with `T`; it falls only with `K` (§26.4) | **[S: Ch.10 State A control; App. D 22 SOPs; App. F 14 records]** | Total governance hours grow **linearly with teams** while revenue capacity grows with *neighbourhood quality* — the asymmetry of §14.2 at national scale |
| **NL-4** | **Platform and technology** | Manual controls work at 10 teams and fail at 1,000; the platform is a step function, not a slope | **[S: Ch.22 fourteen modules; Ch.30 Phase 1; Ch.31 "Blocker before scale"]**; stress-test F-30 | A large one-time investment whose *timing* is a decision (stress-test: manual stack retired at a hard trigger) |
| **NL-5** | **Legal, tax and compliance** | Entity, FCRA, statutory and safeguarding obligations attach at thresholds, not smoothly | **[X: 12A/80G conditions; FCRA track record; DPDP Significant Data Fiduciary obligations attach at scale]**; **[S: Ch.30 Phase 5 "Professional compliance"]** | Step-change costs at defined thresholds, each **[V]** |
| **NL-6** | **Failure support** | `C_support_expected` per team is roughly constant, but *simultaneous* failures are correlated (§21.3, §29 Scenario 11) | **[S: Ch.14 step 4]** assumes one support team per failure | Support capacity must be sized for correlation, not for the average |
| **NL-7** | **Coordination and latency** | Escalation lanes **[S: Ch.7, Ch.6]** have finite throughput; the State "escalation filter" exists precisely to "prevent national overload" **[S: Ch.6]** | **[S]** | Decision latency rises with `T` unless the filter layers are staffed — a cost that grows faster than teams |
| **NL-8** | **Trust and legitimacy** | Local trust is produced locally and does not transfer; national brand "follows evidence, never precedes it" | stress-test §23 institutionalisation table; v1.3-A A-07, A-16 | A national reputation is an aggregate of local ones and can be destroyed by a single local event (v1.3-A §2) |
| **NL-9** | **Data and privacy** | Records grow linearly; privacy obligations and breach exposure grow **super-linearly** because sensitivity concentrates | **[X: DPDP breach notification within 72 hours; Significant Data Fiduciary obligations]**; v1.3-A A-17, A-20 | A privacy function must exist before scale, not after |
| **NL-10** | **Heterogeneity of demand** | Neighbourhood payable demand varies by an order of magnitude; averaging it produces a plan that is wrong everywhere | stress-test F-18; §19 | **National revenue projections built on per-team averages are meaningless.** Only distributions are usable |

## 31.4 The five scales

**[SC]** Structure only. **No rupee amounts, no headcounts asserted, no forecast.** `K` is teams per city.

| Scale | Teams | What must exist that did not exist before | Binding constraint | Non-linearities active | Verdict on "is it multiplication?" |
|---|---|---|---|---|---|
| **10 teams** | one city, `K ≈ 10` | A functioning City layer: Funds, HR/Verification, Business pipeline, Safety review, Editor **[S: Ch.7]**; B-21 shared-services contract; MVC set; measurement of `H_gov` | **`K` at or near `K_min`** — the City layer is barely affordable | NL-3, NL-6, NL-8 | **No.** Per-team cost is dominated by the City layer |
| **100 teams** | several cities, `K` rising | State layer with a real specialist pool **[S: Ch.6]**; professional finance; sampling-based assurance beginning; platform minimum | **Trainer and leader supply (NL-2)** | NL-1 begins, NL-2, NL-3, NL-4, NL-7 | **No.** Leader stock caps formation |
| **1,000 teams** | multi-state | Full platform (NL-4); risk-based sampling assurance (NL-1); professional compliance function (NL-5); privacy function (NL-9); a real reserve base | **Assurance and governance throughput (NL-1, NL-7)** | NL-1…NL-10 all active | **Emphatically no.** This is a different organisation |
| **10,000 teams** | national | Federation-level structure; sub-city zone layer in metros; institutional audit; external reviews | **Coordination latency and legitimacy aggregation (NL-7, NL-8)** | all | **No.** The stress test's conclusion applies: national scale "needs a professional institutional layer" |
| **100,000 teams** | beyond | Public-interest governance; the stress test's finding that beyond this the protocol must sit "under public-interest governance" | **Systemic risk and public accountability** | all, plus regulatory attention | **No.** At this scale the organisation is infrastructure, and infrastructure is governed differently |

**[A] The scaling conclusion, stated plainly:** the architecture scales **organizationally** — its layers, roles, gates and standards are genuinely well designed for it, and the stress test found the hierarchy sound. It does **not** scale **economically by multiplication**, because (i) governance cost per team is roughly constant while revenue capacity per team is a property of the neighbourhood, and (ii) the shared layer that makes governance affordable requires density `K`, which is a *geographic distribution* decision rather than a growth-rate decision.

> **[P] Proposal B-23 — Density-First Growth Rule.** New teams are formed to raise `K` in existing cities before new cities are opened, until `K ≥ K_target` **[M]**; a new city is opened only with a named City-layer capability and a funded `C_city`. **Rationale:** §31.2 shows per-team viability is a function of `K`, so spreading thin makes every team less viable — the opposite of the intuition that "more cities = more growth". `PROPOSED — REQUIRES FINAL APPROVAL`.

## 31.5 What must be true at each scale — the honest list

**[A]** Restating the stress test's scaling verdict in economic terms, and marking what v1.3-B adds:

| Scale | Stress-test verdict | v1.3-B economic addition |
|---|---|---|
| ~1k–5k members | "fine" — the architecture works as written | **Only if `H_gov` measures in band GB-1…GB-3 (§25.4) and `K ≥ K_min`** |
| ~100k members | needs a professional institutional layer + sampling assurance | **Plus a funded centre.** Priority-5 income at scale can fund it (§8.6) — but only after a long pre-revenue period that must be financed another way (E-03) |
| ~1M members | needs federation | Plus NL-5 step-change compliance and NL-9 privacy obligations **[V]**, and a reserve base sized for correlated shocks (§21.3) |
| beyond | protocol under public-interest governance | Plus the acceptance that per-team economics will *never* be uniform, so cross-subsidy (§22) becomes permanent rather than transitional |

---

# 32. THE "ONE MOHALLA CAN PAY FOR ITSELF" TEST

## 32.1 The question, answered honestly

> **Can one Mohalla Team eventually generate enough legitimate economic value to support its own recurring operating requirements?**

**[C]** "Its own recurring operating requirements" decomposes into four, and the answer differs for each:

| Requirement | Contents | Can one Mohalla team fund it from its own venture revenue? |
|---|---|---|
| **R-A Direct venture cost** | `C_var` — priority 3 **[S]** | **Yes** — by construction; it is charged to the venture |
| **R-B Worker compensation + statutory dues** | `R_1 + R_2` — priorities 1–2 **[S]** | **Yes, for venture work** — the waterfall's core function |
| **R-C Existence and capability cost** | `C_L1 + C_L2_share` — phones, data, ID, records, compliance, accounting, training, insurance, AI | **Conditionally.** Requires `V_gross ≥ B_healthy` (§11.2), which requires `P_max × CM̄_j` sufficient — i.e. **depends on `H_gov`, `CM̄_j`, `r_collect` and neighbourhood demand** |
| **R-D Share of the centre** | City, State, National — `C_city / K` etc. | **Only via priority 5, and only above `B_healthy`** — i.e. **requires R-C first**, and requires `K ≥ K_min` (§31.2) |
| **R-E Service delivery cost** | `C_svc_cash` — materials, transport for categories 4–7 (§6.4) | **No, not from venture revenue** — the waterfall has no line (§8.4). Candidates: social-impact fund **only when surplus conditions are met [S: Ch.20]**, validated donations **[S: Ch.20]**, or City/State resourcing **[S: Ch.7, Ch.6]** |
| **R-F Resilience** | `R_6` reserves + `E_shock` | **Only above `B_resilient`** (§11.2) — the last to arrive and the first to stop |

## 32.2 The five revenue positions your brief requires

| Position | Definition | What is funded **[C]** | Verdict |
|---|---|---|---|
| **A. No revenue** | `V_gross = 0` | Nothing. §9 applies in full | **Cannot pay for itself.** Survives only on float/seed and volunteer willingness, for `M_runway = F_0 / L_min` |
| **B. Low revenue** | `0 < V_gross < B_healthy` | `R_A` and part of `R_B` | **Cannot pay for itself.** Existence cost `C_L1` unfunded; the team is subsidised whether or not anyone says so |
| **C. Moderate revenue** | `B_healthy ≤ V_gross < B_resilient` | `R_A, R_B, R_C` and part of `R_D` | **Pays for itself on a current basis. Does not build resilience, and does not fully fund the centre or service cash costs** |
| **D. Sustainable revenue** | `B_resilient ≤ V_gross` and stable across a seasonal cycle (HC-15) | `R_A … R_F` | **Genuinely self-supporting** — the only position in which "one Mohalla can pay for itself" is true without qualification |
| **E. High revenue** | `V_gross ≫ B_resilient`, and `P_max` is the binding constraint | All of the above plus contribution to others | **Self-supporting and support-capable (§30 Stage 5)** — but note `P_max` caps it (§17), so this position requires more trained people, not more sales |

## 32.3 The answer

> ### **[A] Answer: NO — not one Mohalla team, alone, from a standing start.**
>
> A single Mohalla Team **can** reach position **D** and pay for `R_A` through `R_F` — **but only if four conditions outside its own control hold:**
>
> 1. **`H_gov` is in band GB-1…GB-3** (§25.4). At GB-4 or worse, `σ_max` is exceeded and no revenue level compensates, because the hours are gone.
> 2. **`K ≥ K_min`** (§26.5, §31.2), so the City shared-services divisor exists. **§3.3 proves the team cannot satisfy segregation of duties alone**, so this is not a preference — it is a control requirement.
> 3. **Its neighbourhood contains payable demand sufficient for `P_max × CM̄_j ≥ B_healthy`** (§11.2, §19). This is a property of the locality, not of the team's effort — and it varies by an order of magnitude (NL-10).
> 4. **It survives months 1–`M_target`** on a float or seed that the source does not provide (§9.6, B-04), because reserves are priority 6 and the centre is priority 5 (§8.5, §8.6).
>
> **And even at position D, `R_E` — the cash cost of service — is not funded by venture revenue.** Service is funded from surplus via the restricted social-impact fund **[S: Ch.20]**, from validated donations **[S]**, or from above. **A team at position D can pay its own way and still not be able to pay for its mission.**

## 32.4 If the answer is no: what must change

Your brief requires that a "no" not be forced into a "yes", and that five things be determined. All five are answered:

| Question | Answer |
|---|---|
| **What must change?** | Four instruments, none of which alters the architecture's principles: **(1)** a cold-start float (B-04) and reserve seeding (B-03); **(2)** an explicit City shared-services contract (B-21) making the divisor real; **(3)** a measured governance ceiling with graduated fidelity (§26.2, B-20); **(4)** a cadence and collection standard matched to lumpy local revenue (HC-17, B-13). **Plus one decision the model cannot make: who funds the centre before priority 5 exists (E-03).** |
| **What must be subsidised?** | **`C_L1` (existence cost) in months 1–`M_target`; `C_city / K` until `K ≥ K_min`; `C_svc_cash` for categories 4–7 permanently or until surplus; and `C_L2` capability costs (insurance, certification) where they are externally priced.** Everything else can be earned. |
| **What should remain volunteer?** | **Service delivery in the time-costed categories (§6.4), governance *beyond* the minimum viable control set, and community relationship-building** — provided B-09's boundary rules hold: voluntary means optional, disclosed, hour-bounded, and never a condition of paid work. **What must never remain volunteer indefinitely: the four segregated finance hands and the safety role** (§3.3, HC-18) — because those carry legal and social exposure that cannot fairly be unpaid forever (§34). |
| **What belongs at City/State/National level?** | **City:** verification cadre, finance reconciliation and payment preparation, customer pipeline, materials and inventory, incident review, editorial and translation, report preparation **[S: Ch.7]**. **State:** trainers, finance reviewers, safety reviewers, logistics and business specialists, cross-city projects, escalation filtering **[S: Ch.6]**. **National:** platform, standards, reserve custody, audit capability, legal and compliance, insurance, entity and tax **[S: Ch.5, Ch.18, Ch.27, Ch.30]**. **Every one of these already exists as a named role in the architecture — the change is permission to use them, not permission to create them.** |
| **Does the architecture need structural modification?** | **Not structurally. Instrumentally, yes.** No hierarchy, role, principle, waterfall order or constitutional article needs to change. What is missing is **five financial instruments** (float, seeded reserve, shared-services contract, accrual ledger, scarcity rule) and **one unresolved decision** (centre funding). §44 packages them; §43 registers the decision. **[A] This is the most favourable finding in the document: the architecture is not wrong, it is unfinished in a specific, nameable, additive way.** |

---

# 33. SOCIAL SERVICE FUNDING

> **Question from your brief:** Can service continue when business revenue temporarily falls? **If not, identify the gap honestly.**

## 33.1 What service costs, split by funding source

**[C]** Decomposing `C_svc` for the seven source categories **[S: Ch.15]**:

| Cost element | Needed for categories 1–3 (time-costed) | Needed for 4–5 | Needed for 6–7 (cash-intensive) | Possible source |
|---|---|---|---|---|
| Volunteer hours `H_svc` | ✅ | ✅ | ✅ | **Not a cash cost** — but a real cost (§15) and a competed-for one (§6.3) |
| Governance: verification, evidence, outcome, report | ✅ | ✅ | ✅ | **Unfunded** — part of `H_gov` (§8.4, category D) |
| Transport | ◐ (walkable) | ✅ | ✅ | `C_trans` — unfunded at ₹0 |
| Materials | ◐ (existing/donated) | ✅ | ✅✅ | Donations **[S: SOP-07; Ch.7 materials allocation]**; social-impact fund **only if surplus conditions met [S: Ch.20]** |
| Permissions | ◐ | ✅ | ✅ | Time cost; **[S: Ch.15 "Permissions, authorities first"]** |
| Certified supervision (safeguarding, food safety, trained handling) | ✅ for education with minors | ✅ | ✅ | **Externally priced [V]** — cannot be volunteered away |
| Stock holding and issue control | — | ◐ | ✅ | City Warehouse **[S: Ch.7; Ch.9]** |

## 33.2 The four candidate funding sources, tested against source restrictions

| Source | Available? | Restriction that binds | Verdict |
|---|---|---|---|
| **Venture surplus via the waterfall** | Only above `B_resilient` | Priority 7 — **after** priorities 1–6 **[S: Ch.18]** | ✅ **The intended source, and it arrives last.** Cannot fund service in months 1–`M_target` |
| **Social-impact fund** | Only "when surplus conditions are met" **[S: Ch.18 priority 7; Ch.20]** | **"Not ordinary operating salaries. Not venture bailouts. Not political or religious activity."** Programme list is restricted to education, learning support, adult training, emergency participant support, community infrastructure, safeguarding capability, certain health/nutrition support **[S: Ch.20]** | ✅ **For programmes on the restricted list, once surplus exists.** ❌ For team operating cost, always |
| **Donations** | "donations may be possible **after validation**" **[S: Ch.20]**; SOP-07 requires donor, restriction, receipt, storage, allocation, report **[S]** | Donor intent must be honoured **[S: Ch.15 clothing/donations control]**; foreign contribution requires FCRA **[X]**; 12A/80G conditions include no political activity **[X]** and v1.3-A A-01 applies | ⚠️ **Possible, conditional, unresolved [V].** A real candidate for `C_svc_cash` — and the *only* one that does not depend on venture success |
| **City / State resourcing** | City allocates "donated/purchased materials with approved evidence and priorities" **[S: Ch.7]**; State runs "multi-city projects" **[S: Ch.6]** | Requires `C_city` to be funded — which requires priority-5 income (§8.6) | ✅ **For materials and larger projects.** ⚠️ Circular for a pre-revenue network |
| **Cross-subsidy from stronger teams (§22)** | Only Layer 1 (non-cash) exists in source | Money cannot move laterally (§21.4) | ✅ **For demand referral and specialist time.** ❌ For materials |

## 33.3 Can service continue when revenue falls? — the honest answer

**[C]**

| Service type | Continues at ₹0 revenue? | Why |
|---|---|---|
| **Categories 1–3, walkable, using existing or donated materials** | **YES** | Costs only `H_svc` and `H_gov`, both of which are volunteer-able in the short run (§9.2) |
| **Categories 1–3 requiring purchased materials** | **NO**, without donation or City stock | `C_mat` has no funding line (§8.4) |
| **Categories 4–5** | **PARTLY** | Awareness and coordination continue; anything requiring transport or certified supervision stops |
| **Categories 6–7 (food, infrastructure, emergency)** | **NO** | Cash-intensive, and correctly so — the source's own controls (food safety, stock control, permissions, authorities first) imply resource backing **[S: Ch.15]**. **B-02 assigns these to City/State resourcing for exactly this reason** |
| **Safeguarding-critical service** (a child at risk, an abuse disclosure) | **MUST continue** | v1.3-A A-09/A-11 and **[S: Ch.16]** do not permit a financial reason to stop a protective response. **This creates an unfunded mandatory obligation — the sharpest form of the gap** |

> ### **The gap, stated without softening [A]**
> **Service continues when revenue falls only to the extent that service can be delivered in *time* rather than *money*.** The moment a service need requires materials, transport, certification or stock, a revenue fall stops it — **and there is no instrument in the architecture that fills the gap, because the social-impact fund is surplus-dependent and expressly barred from operating cost [S: Ch.20], reserves are National and bailout-flagged [S: Ch.18; SOP-10], and donations are unresolved [V].**
>
> **The one obligation that may never stop — protecting a person from immediate harm [S: Ch.16] — is therefore unfunded by design.** That is not a criticism of the design's intent; it is a statement that **the design requires a funding source it has not yet named.**

## 33.4 What would close the gap

**[P] Proposal B-24 — Service Continuity Instrument.** Three components, each additive and each respecting the existing restrictions:

1. **A restricted Service Materials Allocation at City level**, funded from (i) validated donations with unrestricted or matching intent **[S: SOP-07 donor-intent rule]**, (ii) priority-7 social-impact contributions once surplus exists **[S: Ch.20]**, and (iii) an approved central allocation. Held and issued by the **City Warehouse/Logistics Manager** **[S: Ch.7]** under the existing evidence rules. **Not a cash transfer to teams** — a materials stock, which is what SOP-07 and Ch.7 already contemplate.
2. **A standing Emergency Service Exception** for safeguarding-critical needs, allowing a team to incur a capped, pre-approved cost and reconcile afterwards — the service analogue of v1.3-A's break-glass, with the same after-the-fact review and published counts.
3. **A published Service Funding Statement** per team per quarter: what service was delivered, what it cost, and **which source funded each element** — so that a service programme is never quietly financed by an unnamed party, and so that §38's prohibition on monetising help is auditable from the other direction: *help must be shown to be free to the recipient.*

`PROPOSED — REQUIRES FINAL APPROVAL`; **[V]** for donation law, FCRA, donor-restriction compliance, tax treatment of materials, and any statutory duty to provide.

**[A] Honest caveat:** B-24 does not create money. It creates a **named place for money to go and a named person to hold it**, which is the precondition for anyone giving it. Without B-24, a donor cannot fund service even if they wish to, because there is no instrument to receive the gift consistently with **[S: Ch.20]** and **[S: SOP-07]**.

---

# 34. ECONOMIC DIGNITY TEST

> **Objective from your brief, adopted verbatim:** SERVICE SHOULD NOT REQUIRE PERMANENT ECONOMIC SELF-SACRIFICE.

## 34.1 The eight questions, answered against the architecture

| # | Question | Verdict | Evidence and reasoning |
|---|---|---|---|
| **1** | **Are workers paid predictably?** | **NO — not yet** | The cycle is fixed weekly **[S: Ch.19]** but the *amount* depends on `V_gross`, which is lumpy **[I; stress-test F-06]**. Predictability of **timing** is not predictability of **amount**. At SC-0 and SC-25 (§10.2) the amount is zero or pro-rata. **Fix requires B-04 float, B-06 scarcity rule and cadence matching (HC-17) — none of which exist** |
| **2** | **Is compensation understandable?** | **PARTIALLY** | The *mechanism* is clear and well documented: verified work → approved formula → payment sheet with formula version, approvals and evidence **[S: Ch.19 steps 2, 6, 7, 13]**. But **the formula does not exist** — "Weekly revenue percentages NOT FINAL", "Leader multiplier NOT FINAL" **[S: Ch.33]**. A person cannot understand a rule that has not been written |
| **3** | **Can workers see how payment was calculated?** | **YES — by design** | **[S: Ch.19 step 13]** "Payment sheet, **formula version**, approvals and evidence retained"; **[S: Ch.24]** Member dashboard already includes "**earnings**". **This is a genuine strength and should be preserved exactly** |
| **4** | **Can they challenge errors?** | **YES — by design** | **[S: Const. Art.17]** grievance and appeal; **[S: Ch.25]** leaderboard "corrections and appeals"; **[S: SOP-17]** ordinary conduct process; v1.3-A A-16 §15.2 requires a route that does not pass through the person complained about (stress-test M10 Integrity Line) |
| **5** | **Are volunteers respected?** | **YES in doctrine, AT RISK in economics** | Doctrine: dignity, non-discrimination, recognition, welfare coordination **[S: Ch.2 principle 1; Ch.9 Conduct & Welfare Coordinator; Ch.24 achievements]**. Economics: §15 shows volunteers carry the **same** verification, training, conduct, safety, privacy and evidence obligations as paid members **[S]** while receiving nothing — and `C_vol_per_hour` rises as retention falls. **Respect requires that the organisation know what it is asking of them (B-08) and not ask indefinitely (§34.2)** |
| **6** | **Are leaders compensated without creating excessive hierarchy?** | **PRINCIPLED, UNRESOLVED** | **[S: App. A §15.3]** "Any leader differential must be **transparent, capped or bounded** where appropriate, and justified by **verified leadership work rather than status alone**." That is an explicit anti-hierarchy rule. But `m_lead` is NOT FINAL **[S: Ch.33]**, and §24 shows the leader also bears uncompensated social cost (HC-18) and the promotion tax |
| **7** | **Does the organisation depend on unpaid labour indefinitely?** | **YES — currently, and this is the most serious dignity finding** | §8.4: service, governance and training have **no funding line**. §4.1 PC-06/07/08. §33.3: service continues at ₹0 only because it is volunteered. **[A] An organisation whose mission, control system and capability-building all rest on unpaid labour is depending on unpaid labour indefinitely — not as a phase, but as a structure** |
| **8** | **Can a capable person build a livelihood through the system?** | **CONDITIONALLY — and the condition is not in their control** | Yes if: the venture category has real `CM̄_j / h_proj` (§11.4), the neighbourhood has payable demand (§19), `K ≥ K_min` (§31.2), `H_gov` is in a survivable band (§25.4), and the person has or can borrow the skill (§17.4). **All five are structural, not personal.** A capable person in a low-demand neighbourhood with GB-4 governance cannot build a livelihood here however hard they work |

## 34.2 The dignity floor — what must be true

**[P]** Derived from the eight answers, and stated as requirements rather than aspirations:

| # | Requirement | Why | Instrument |
|---|---|---|---|
| **D-1** | **The compensation formula must exist in writing before the first person is recruited on the basis of it** | A rule that does not exist cannot be understood, seen or challenged (questions 2–4) | E-09 in §43; **[S: Ch.33 NOT FINAL]** must be closed before Phase 2 |
| **D-2** | **Payment expectations disclosed at recruitment must be the weak-month reality, not the good-month possibility** | "Workers can[not] be promised money that does not exist" **[S: App. A §14.5]**; stress-test M16 earnings-reality rule | §12.6 rule 2; §9.5 |
| **D-3** | **No member is expected to fund operations personally, ever** | HC-03; personal spending creates debt-based loyalty, which v1.3-A's manipulation prohibitions forbid | §12.6 rule 1; B-15(2) City emergency float |
| **D-4** | **Unpaid work is optional, bounded, disclosed and never a condition of anything** | Question 5; §16.3 B-09 rules 2, 5 | B-09 |
| **D-5** | **Accrued unpaid compensation is recorded, aged, visible to the person and settled at priority 1** | Question 1; §12.4 — an earned claim must not be erased by a bad month | **B-05** |
| **D-6** | **The organisation measures what volunteering costs it, and reports it** | Question 5; "they are volunteers" must never be a reason to ignore cost | **B-08** |
| **D-7** | **Control roles are supported, backed and rotated — not left to absorb social friction alone** | Question 6; HC-18; §25.5 | v1.3-A A-04 support duty; stress-test M10 |
| **D-8** | **There is a stated point at which a role ceases to be volunteerable** | Question 7 — the four segregated finance hands and the safety role carry legal exposure that cannot fairly be unpaid indefinitely | **E-10** in §43; §33.4 |
| **D-9** | **A person can see a path from volunteering to earning that does not depend on their neighbourhood being wealthy** | Question 8; §19 two-track strategy; City pipeline **[S: Ch.7]** | **B-10, B-14, B-21** |
| **D-10** | **Dignity of the person helped is never traded for revenue or evidence** | v1.3-A A-19; §38 | **B-02, §38, §39** |

## 34.3 The dignity test applied to the model itself

**[A]** This document is also subject to the test. Three self-checks:

1. **Does the model treat people as cost lines?** It measures `C_vol_per_hour` — which could read as pricing a volunteer. **Clarification:** §15 measures **the organisation's own cost of processing a volunteer**, never the value of the person's time, and B-08 explicitly forbids assigning cash value to volunteer hours. The purpose is to stop the organisation *assuming* volunteering is free, which is the disrespectful position.
2. **Does the model recommend paying people less?** No. Every proposal either protects a claim (B-05), makes a scarcity rule fair (B-06), or creates a funding source (B-03, B-04, B-24). **B-06 pro-rata reduces payment only in the case where the alternative is that some people are paid in full and others not at all** — and it applies to role-holders first (§12.5 rule 2).
3. **Does the model make dignity conditional on viability?** No. §28.2 makes dignity a **veto gate** (V-G3), which by construction cannot be traded against revenue. §38 and §39 place whole categories beyond commerce permanently.

---

# 35. INCENTIVE ANALYSIS

**Method:** each of your seven suspected distortions is tested against the architecture's actual mechanisms. Where a distortion is real, it is named, explained, mitigated, and the mitigation is marked **[P]**.

| ID | Distortion | Does the architecture produce it? | Mechanism | Mitigation | Status |
|---|---|---|---|---|---|
| **I-01** | **Revenue over service** | **PARTIALLY — and the architecture already fights it** | Revenue is the only funded activity (§8.4), so cash pressure always points at venture work. **But mission impact carries the highest performance weight, 20%, and the source states the reason: "prevents money-only optimisation" [S: Ch.25]** | **B-01 service hour budget** — makes the trade visible and defended rather than residual; §28.2 reports mission as a dimension; §10.3 finding 1 keeps `B_healthy` inclusive of `C_L1` so that "profitable" cannot mean "unfunded existence" | **[P]** — mitigation proposed; the 20% weight is **[S]** and unchanged |
| **I-02** | **Easy projects over difficult needs** | **YES** | `CM̄_j / h_proj` is higher for easy work; difficult needs are cash-intensive categories 6–7 (§6.4) with heavy governance (HC-08) and no funding line | Priority assessment stays need-based, not margin-based **[S: Ch.8 step 5 "Urgency, vulnerability, resources, expected impact, safety risk and feasibility" — note: no margin criterion]**; B-02 assigns cash-intensive categories upward; **B-24** funds materials so difficulty is not penalised by cost | **[P]**; note the source's criteria already exclude margin — **preserve verbatim** |
| **I-03** | **Visible service over invisible service** | **YES — strongly** | Visible service produces photographs, counts and social proof; invisible service (verification, follow-up, safeguarding, record-keeping, a prevented incident) produces nothing publishable. **[S: Ch.25]** already warns that "follower count, social-media views… raw activity count cannot determine leadership" | v1.3-A **A-19** forbids photographing recipients — which *removes* the visibility reward and is therefore an economic instrument as much as a dignity one; outcome verification **[S: Ch.15 step 10]** scores *solving*, not *showing*; §27.3 reports control-role tenure and workload so invisible labour is at least seen internally | **[S]** + **[P]** — A-19 already adopted in v1.3-A; the internal-visibility proposal is new |
| **I-04** | **Quantity over quality** | **PARTIALLY, with strong existing controls** | Counting is cheap; quality is expensive. **But the source's controls are unusually good:** "Completed verified outcomes; no artificial splitting"; "Do not count planned activities as completed impact"; QA before delivery; acceptance recorded **[S: Ch.25; Ch.15; Ch.17 steps 8–10]** | Preserve those verbatim; add **estimated-vs-actual hours per project** (§27.4) so that under-scoping to win work is visible; revision rate as a quality signal | **[S]** controls + **[P]** measurement |
| **I-05** | **Customer acquisition over delivery** | **YES, in a specific and dangerous form** | Acquisition is rewarded immediately (a signed customer); delivery is rewarded later (collection). With `Δt_collect` long (§18.6), a team can look busy and solvent on invoices while being unable to pay anyone | `r_collect` and `Δt_collect` reported *alongside* revenue (§27.1); **the accounting-basis decision E-07 must resolve receipts-vs-invoiced before the first invoice**; B-05 accrual makes unpaid delivery visible; B-13 advance/milestone terms | **[P]**; **E-07 is [V] and urgent** |
| **I-06** | **Leader promotion over team stability** | **YES — structurally** | The ladder promotes the best team's leader upward **[S: Ch.26; App. A §1.1]**, which weakens the winning team (§24.2). Meanwhile a supporting team's `H_deliver` is consumed by §23 step-4 support with no recognition (§22.5) | **B-18** successor-before-transition, overlap, time-bounded mentorship, promotion-cohort scoring, **horizontal recognition as an alternative to vertical promotion**; promotion recorded as a *cost* with a support decision attached | **[P]** — and item 4 touches a NOT FINAL area, so it is flagged accordingly |
| **I-07** | **Short-term revenue over long-term trust** | **YES — the deepest one** | Trust is the acquisition channel in a neighbourhood (§18.5) and is worth 10% of the score **[S: Ch.25]**, but it compounds slowly and is destroyed instantly (v1.3-A §2.3 legitimacy capital). Every short-term pressure — one exaggerated claim, one exposed beneficiary, one political adjacency, one unpaid worker — trades a compounding asset for a one-off gain | v1.3-A **A-07** under-claiming, **A-19** dignity, **A-01** neutrality, **A-08** entrenched DO-NOTs; **§28.2 veto gates**, which make trust non-tradeable by construction; **B-12** measures the trust→demand path at the *referral* step, so trust has a metric that is not a vanity metric | **[S]** + **[P]** — the veto-gate design is the strongest single anti-distortion instrument in this document |

## 35.1 The meta-incentive

**[A]** Beyond the seven, one structural incentive deserves naming because it is not in your list and is more dangerous than any of them:

> **I-08 — The incentive to under-report weakness.** Every mechanism in this model — support, float, referral, grant — is triggered by a team *admitting* it is struggling. Every performance mechanism rewards looking strong. **[S: Ch.14 step 5]** already identifies the risk: "Talk with struggling team; **avoid fear of reporting problems**." And **[S: App. A §18.4]** contains an anti-retaliation provision for performance.

**Mitigation [P]:** (i) **detection must not depend on self-report alone** — §27's `σ`, accrual ageing, concentration ratios and verification backlog are computed from records the team must already keep; (ii) **asking for support must be recorded as a positive**, in the same register as an achievement; (iii) **a team that concealed a material weakness and was found out is treated under SOP-18 serious misconduct, while a team that reported one is protected** — making honesty the cheaper strategy; (iv) **the City's own incentive must be aligned**: a City whose score depends on its teams looking healthy will not report them (§36).

## 35.2 Incentive design principles adopted

**[P]** Four, all derived from source:

1. **Reward outcomes, never counts** — **[S: Ch.25]** already: "Completed verified outcomes"; "Real outcomes, not inflated counts" **[S: Ch.15 step 12]**.
2. **Make the invisible visible internally, and keep it invisible publicly** — control-role workload and service hours on the internal dashboard; beneficiary identities never (v1.3-A A-19).
3. **Never let a metric be both the target and the judge** — the team that reports its own mission balance must not be the only reviewer of it; City review and audit exist **[S: Ch.7, Ch.27]**.
4. **Prefer a veto to a weight where the harm is irreversible** — §28.2. A weight invites trade; a veto forbids it.

---

# 36. ANTI-GAMING ECONOMICS

**Design rule from your brief, adopted:** create controls **proportionate to risk**. **Do not burden low-risk teams with maximum controls.** This is the same principle as §26.2's minimum viable control, applied to integrity.

## 36.1 Gaming register

| ID | Manipulation | Why it is attractive here | Existing source control | Sufficient? | Proportionate addition | Risk tier |
|---|---|---|---|---|---|---|
| **G-01** | **Fake revenue** (invoiced work that does not exist; circular or related-party transactions) | Revenue is the only funded activity (§8.4) and 15% of the score **[S: Ch.25]** | "**Collected legitimate customer revenue; exclude fake/circular/related-party manipulation**" **[S: Ch.25]**; reconciliation to bank/cash records **[S: Ch.19 step 3]** | **Largely yes** — collection-basis reconciliation is a strong control | Customer confirmation sampling at City level **[S: Ch.7 review]**; related-party declaration; **ageing of receivables** (§27.1) — fake revenue ages badly | **High** |
| **G-02** | **Inflated expenses** | Direct costs are priority 3 and reduce distributable amounts | "**Receipts, approval, direct-cost link and anomaly review**" **[S: Ch.25]**; SOP-08 checks budget, approval, receipt, role, ledger entry; **self-approval is impossible** **[S: Ch.18]** | **Yes — this is the best-controlled area in the architecture** | Nothing at team level. Sampling by Audit **[S: Ch.27]** | Low |
| **G-03** | **Fake service activities** | Mission impact is 20% — the highest weight — and service is unfunded, so inflating it costs nothing | "Completed verified outcomes"; "**Do not count planned activities as completed impact**" **[S: Ch.15]**; outcome verification **[step 10]**; "Outcome verification and privacy-safe audit trail" **[S: Ch.25]** | **Partly** — outcome verification is performed by the team itself | **Independent beneficiary confirmation sampling at City level** — the source already contemplates city review of Mohalla data **[S: Ch.7]**; duplicate-evidence detection (stress-test §23 quality-control row) | **High** |
| **G-04** | **Customer collusion** (a friendly customer accepts, delays, or round-trips) | Small local markets make collusion easy and hard to detect | Related-party exclusion **[S: Ch.25]**; acceptance recorded **[S: Ch.17 step 10]** | **Partly** | Concentration reporting (§27.5); **B-07(3) concentration limits**; City-level customer verification for repeat counterparties | Medium |
| **G-05** | **Expense shifting** (charging personal or service costs to a venture to raise distributable funds, or the reverse) | The boundary between `C_var` (priority 3, funded) and `C_L1`/`C_svc` (unfunded) is exactly where the money is | "Direct costs — costs **required to deliver the customer work**" **[S: App. A §14.3]**; "direct-cost link" **[S: Ch.25]** | **Partly — the definition is right but the attribution is judgemental** | A **written direct-cost attribution rule** per venture category, approved once at City level rather than argued per invoice | Medium |
| **G-06** | **Duplicate claims** (same work claimed twice; same expense twice) | Manual records and multiple teams make duplication easy | Payment sheet with formula version and evidence **[S: Ch.19 step 13]**; audit trail | **Partly** | Unique task/project identifiers — the platform provides them **[S: Ch.22]**; **this is a case where automation is cheaper than the control** (§26.3) | Low–medium |
| **G-07** | **Ghost workers** (paid people who do not exist or do not work) | Compensation is priority 1 and is paid on "verified work" | "**Verified work**" **[S: Ch.18]**; work verification by supervisor/customer/role lead **[S: Ch.19 step 2]**; membership is verified **[S: Ch.12]**; attendance cross-checked **[S: Ch.25]** | **Yes, if verification is real** — the control chain is complete | Nothing new. **But note: this is why member verification cannot be relaxed at any stage (§26.2 MVC-2)** | **High consequence, low likelihood** |
| **G-08** | **Artificial project completion** (marking done what is not; splitting one project into many) | Completion drives acceptance, revenue and the execution score (15%) | "**No artificial splitting**" **[S: Ch.25]**; QA before delivery **[S: Ch.17 step 8]**; acceptance by the customer **[step 10]** | **Yes — customer acceptance is an external check** | Revision rate and estimated-vs-actual hours (§27.4) detect the *opposite* gaming (under-scoping) | Medium |
| **G-09** | **Leaderboard gaming** | Leadership, promotion and Head Team status follow the score **[S: Ch.26]** | "Published **after anomaly review, corrections and appeals**" **[S: Ch.25]**; eight anti-gaming controls **[S]**; "prevent leaderboard manipulation" on venture closure **[S: App. A §13.5]** | **Largely yes — the source anticipated this thoroughly** | **Cohort normalisation** (stress-test M8) so teams are not compared across incommensurable neighbourhoods; **promotion-cohort reporting** (B-18(4)) so a promoted team is not penalised | **High** |
| **G-10** | **Customer concentration hiding** | A team dependent on one customer looks healthy until it is not (§29 Scenario 2) | No source control | **No** | **§27.5 concentration fields + B-07(3) limits** — new, cheap, and auto-derived from the sales ledger | **High** |
| **G-11** | **Revenue timing manipulation** (pulling collections into a scoring period; delaying expenses out of it) | Periodic scoring and periodic payment both reward timing | Reconciliation to bank/cash records **[S: Ch.19 step 3]**; weekly report reviewed at team and higher level **[step 12]** | **Partly** | Cut-off rules stated once per period; **audit of period-boundary transactions** **[S: Ch.27]**; ageing buckets make a pulled-forward collection visible next period | Medium |
| **G-12** | **Under-reporting weakness** (the meta-gaming of §35.1 I-08) | Support is triggered by admission; performance rewards strength | "Avoid fear of reporting problems" **[S: Ch.14 step 5]**; anti-retaliation for performance **[S: App. A §18.4]** | **Partly — cultural, not mechanical** | **Computed early-warning fields that do not depend on self-report** (`σ`, accrual ageing, verification backlog, concentration); asking for support recorded as a positive; concealment treated under SOP-18 | **High** |
| **G-13** | **Volunteer-count inflation** | Headcount looks like capacity and is cheap to produce | "**Verified members/approved participants only; attendance cross-checked**"; "healthy active retention, not inactive names" **[S: Ch.25]** | **Yes** | Report `r_act` and `C_vol_per_hour` (B-08) instead of headcount — **so that inflating the roll visibly worsens the metric** | Low |
| **G-14** | **Evidence fabrication** (identical photos across projects; back-filled records) | Evidence is required for everything and is tedious to produce | **[S: App. F]** evidence standards; audit domain **[S: Ch.27]** | **Partly** | Metadata and duplicate detection (stress-test F-05 early-warning sign: "identical photo evidence across projects"); **auto-capture at the point of activity** rather than later upload | **High** |
| **G-15** | **Float or reserve capture** (optimising for access to subsidy rather than viability) | B-04 creates a resource to be captured | Not in source — **a risk this document itself introduces** | n/a | B-04's own controls: hard cap, fixed term, mandatory reconciliation, **one renewal maximum with City sponsor sign-off**, publication of utilisation | **High — self-inflicted, and disclosed** |
| **G-16** | **Grant capture** (§22 Model D) | A grant is money without a customer | Not in source | n/a | Layer 5 deferred; if adopted: published criteria, hard term, improvement plan per **[S: Ch.14 steps 7–8]**, bar on recurrence | Medium |

## 36.2 Proportionality — the control tier rule

**[P] Proposal B-25 — Risk-Proportionate Integrity Controls.** Controls are applied by **risk tier**, not uniformly:

| Tier | Team profile | Controls applied |
|---|---|---|
| **Tier 1 — Low risk** | Stage 0–1; no venture or one small venture; no cash handling beyond petty expenses; no concentration | **MVC-1…MVC-11 only** (§26.2). No sampling, no independent confirmation, no concentration reporting beyond automatic fields |
| **Tier 2 — Medium** | Stage 2–3; recurring venture; cash handling; first accruals | Tier 1 + G-01 ageing, G-05 attribution rule, G-10 concentration fields, G-11 cut-off rules |
| **Tier 3 — Elevated** | Stage 3+; `V_gross` above a stated threshold **[M]**; concentration above limit; prior finding; float or grant outstanding | Tier 2 + City-level sampling of G-01/G-03/G-14, related-party declarations, period-boundary audit |
| **Tier 4 — Under intervention** | §23 support active; fraud suspected; veto gate breached | Full controls **[S: Ch.14 "Audit/suspension if fraud suspected"]**; independent review; immediate stop-work where safety is involved |

**Rules:** (i) **tier assignment is computed from records, not chosen by the team**; (ii) a team may request a lower tier and must be answered with reasons; (iii) **movement between tiers is itself recorded** — because a team quietly dropping from Tier 3 to Tier 1 is the single most informative event in the register; (iv) **no tier removes a veto gate** (§28.2). `PROPOSED — REQUIRES FINAL APPROVAL`.

**[A] Why proportionality is not leniency:** the source's own logic is graduated — "Approval tier based on category, risk, money, data and novelty" **[S: Ch.17 step 3]**, approval matrix by amount and risk **[S: App. E]**, reserve release by amount/risk **[S: Ch.33]**. **B-25 applies an existing architectural principle to integrity controls, which is where it was missing.**

---

# 37. THREE ECONOMIC ARCHITECTURES

## 37.1 The models

| | **MODEL A — Central funding** | **MODEL B — Local self-sustainability** | **MODEL C — Hybrid** |
|---|---|---|---|
| **Description** | Teams are funded from a central pool (donations, grants, founder capital, Krytos); ventures are optional | Each team must fund itself from its own ventures; the centre is funded by priority-5 fees | Service and governance funded centrally or by donation; venture economics local; cross-subsidy layered (§22.4) |
| **Source basis** | **Weak.** Donations "may be possible after validation" **[S: Ch.20]**; the social-impact fund is surplus-dependent and barred from operating cost **[S]**; no central operating budget exists anywhere | **Strong in principle.** The whole architecture is a "Zero-Capital Local Venture" design **[S: App. A §1.1, §14]**; the waterfall is venture-receipts-based **[S: Ch.18]** | **Strongest in fact.** The source already *is* hybrid: ventures local **[S: Ch.17]**, reserves national **[S: Ch.18]**, materials and pipeline at City **[S: Ch.7]**, specialists at State **[S: Ch.6]**, standards and platform national **[S: Ch.5, Ch.22]** |
| **Resilience** | **High** for teams, **low** for the centre — one donor decision ends everything | **Low** for teams, high for the centre — teams fail individually without systemic risk | **Medium-high** — diversified sources; failure is local and supportable |
| **Autonomy** | **Low** — he who pays decides; donor intent **[S: SOP-07]** and funder capture (stress-test M19) | **High** — but only for teams that survive | **Medium-high** — local venture choice **[S: App. A §16.1]** inside central standards |
| **Fairness** | High between teams, **low between donors' preferences and local need** | **Low** — a poor neighbourhood is penalised for being poor (§32.3) | **Highest available** — need-based Layer 1–3 support with published criteria |
| **Scaling** | Scales with fundraising capacity, **not** with capability | Scales only where demand exists — **so it cannot reach the places the mission exists for** | Scales with `K` and with centre funding (§31.2) |
| **Control** | Strong central control; **risk of becoming a grant-administration organisation** | Weak central control; strong local discipline from survival | Balanced; the §20.2 matrix already describes it |
| **Incentives** | **Poor** — no survival pressure; dependency (§22 Model C risk) | **Strong for revenue, destructive for mission** — I-01, I-02, I-07 all maximised | **Best available** — venture discipline exists, mission is protected by B-01 and the veto gates |
| **Startup feasibility** | Feasible **only** if a funder exists — and none is named in the source | **Not feasible.** §32.3: a standing-start team cannot reach `B_healthy` in months 1–`M_target` | **Feasible with B-03/B-04** — the float *is* the hybrid's startup instrument |
| **Service continuity** | **Excellent** — service is funded directly | **Poor** — service is the first thing cut (§6.3, §33.3) | **Good** — B-02 time-costed floor + B-24 materials instrument |

## 37.2 The evidence from the model

**[C]** Testing each against the findings of §8–§33:

| Finding | Model A | Model B | Model C |
|---|---|---|---|
| §8.4 — the waterfall funds venture work only | Irrelevant (funded otherwise) | **Fatal for service, governance and training** | Addressed by naming a source for each |
| §8.5 — reserves arrive last | Central reserves exist | **No reserves early** | Seeded reserves (B-03) |
| §8.6 — the centre is funded last | Centre funded externally | **Centre unfunded until teams succeed — circular** | Centre funded explicitly during Phase 0–1 (E-03) |
| §9.6 — runway needs a float | Float unnecessary | **No float exists** | B-04 |
| §15.4 — volunteers cost real money | Absorbed centrally | **Absorbed by the volunteers** | Measured (B-08) and bounded (D-8) |
| §26.4 — the City divisor is essential | Present but expensive | **Unaffordable at low `K`** | Present, contracted (B-21) |
| §32.3 — one Mohalla cannot self-fund at start | Doesn't need to | **Contradicted** | Consistent — with conditions |
| §33.3 — safeguarding service must never stop | Funded | **Unfunded — the sharpest gap** | B-24(2) emergency exception |
| §34.2 D-8 — some roles cannot be unpaid indefinitely | Paid centrally | **Unpaid** | Explicit decision (E-10) |

## 37.3 Recommendation

> **[A] Model C — Hybrid — is recommended, and the recommendation is derived from the model rather than from preference.**
>
> **Model B is contradicted by §32.3**, which is itself derived from source facts: the waterfall's scope **[S: Ch.18]**, reserve position **[S]**, centre funding position **[S]**, and the absence of any cold-start instrument. A team cannot self-fund from a standing start, so Model B is not a policy choice but a description of failure.
>
> **Model A is not available**, because the source names no central funder, bars the social-impact fund from operating cost **[S: Ch.20]**, and leaves donations conditional and unvalidated **[S; V]**. Adopting Model A would mean deciding to become a donor-funded organisation — which contradicts **"The organisation is not merely a donation-funded charity; legitimate business is part of the design" [S: App. A §1.1, preserved as APPROVED ARCHITECTURE]**.
>
> **Model C is what the architecture already is**, once its distributed funding is made explicit: ventures local, reserves national, materials and pipeline at City, specialists at State, standards and platform national. **What it lacks is not a design but three named funding decisions** — the centre's pre-revenue source (E-03), the float (E-05/B-04), and the service-continuity instrument (E-12/B-24).

**[P] Proposal B-26 — Explicit Hybrid Funding Map.** A single published table stating, for each cost layer of §4.4, **which source funds it at each stage (§30)**: venture revenue, float, seeded reserve, validated donation, City allocation, State specialist pool, national platform budget, social-impact fund (surplus only). **No layer may be left blank.** A blank cell is the gap that §8.4, §21.2 and §33.3 all identify from different directions. `PROPOSED — REQUIRES FINAL APPROVAL`; **[V]** for every source's legality and tax treatment.

**[A] Honest caveat:** Model C is the most complex of the three and therefore the most exposed to §36 G-15 and G-16 (subsidy and grant capture). **Its controls — caps, terms, reconciliation, publication, one renewal maximum — are not optional extras. They are what distinguishes a hybrid from a dependency.**

---

# 38. WHAT MUST BE FREE

> **Rule from your brief, adopted:** do not allow revenue generation to contaminate essential service.

## 38.1 The six categories, and the payment position of each

| Category | Free to the recipient? | Reasoning | Source anchor |
|---|---|---|---|
| **Free community service** — education/learning circles, tutoring, digital literacy, cleaning, plantation, awareness, donation distribution | **ALWAYS FREE** | It is the mission. Charging would convert a service into a transaction and would exclude exactly the people it exists for | **[S: Ch.15 categories; Ch.2 principle 1 non-discrimination]** |
| **Emergency assistance** — urgent coordination, disaster support, immediate protective response | **ALWAYS FREE, and never conditional** | A price at the moment of emergency is coercion. v1.3-A §10.5 preserves the duty to act as a citizen regardless of organisational capacity | **[S: Ch.15 "Infrastructure/emergency"; Ch.16; v1.3-A A-09, A-11]** |
| **Safeguarding response** — protecting a child or vulnerable adult, referral, reporting | **ALWAYS FREE, and mandatory** | It is a veto gate (§28.2 V-G1/V-G3). A financial consideration may never enter the decision | **[S: Ch.12 boundary; Ch.15 "no exposure of minors"; v1.3-A B6, A-19, A-20]** |
| **Educational support** — study materials, learning circles, adult literacy, digital literacy | **FREE at the point of use** | Note the tension: "Education/training" is **also** a Ch.17 venture category. **Resolution [P]: the same subject matter may be sold to a customer who can pay (a business, an institution, a professional) and given free to a beneficiary who cannot — and the two must be separately accounted, separately evidenced, and never cross-subsidised in a way that reduces the free provision** | **[S: Ch.15 Education; Ch.17 Education/training]** |
| **Subsidized service** — a service with a real cost where the recipient pays part | **PERMITTED ONLY BY EXPLICIT, APPROVED, PUBLISHED RULE** | Sliding scales are legitimate in principle and dangerous in practice: they require means assessment, which requires data the architecture restricts (v1.3-A A-18 §17.4 prohibits collecting financial position). **Therefore: no means-tested pricing at Mohalla level. If a subsidy exists, it is categorical (e.g. all students free) not individual** | **[S: Ch.15; v1.3-A A-17, A-18]** **[V]** |
| **Business customer services** — venture work for a paying customer | **PAID — this is correct and necessary** | The customer is not a beneficiary. Charging a business for a website is not contamination; it is the funding mechanism that makes the free categories possible | **[S: Ch.17; Ch.18]** |

## 38.2 The wall between the two sides

**[P] Proposal B-27 — Service/Commerce Separation Rules.** Six rules:

1. **A beneficiary is never a sales prospect.** No approach, offer, referral request or upsell may be made to a person because they received help. Their details may not be used for commercial purposes — which v1.3-A A-20 §19.5 already prohibits as a use of sensitive data.
2. **A customer is never treated as a beneficiary, and a beneficiary never as a customer**, in the same interaction. The two relationships are recorded separately.
3. **Free provision is never reduced to make paid provision more profitable.** If `H_svc` falls below the B-01 budget because of venture demand, that is a reportable variance, not a management decision.
4. **No pricing may depend on a person's vulnerability, urgency or lack of alternatives.** This is the economic form of the dignity principle (v1.3-A A-19) and of the manipulation prohibitions (stress-test constraints).
5. **A paid engagement may not be presented as help, and help may not be presented as an engagement.** Language discipline: v1.3-A A-19 §18.5 already requires it for storytelling; B-27 extends it to commerce.
6. **Any proposed activity that cannot be clearly classified as free or paid is refused pending a decision** — the same posture as v1.3-A A-04's refusal script for political approaches.

`PROPOSED — REQUIRES FINAL APPROVAL`; **[V]** for consumer-protection, unfair-trade-practice and any sector-specific rules.

## 38.3 Why "free" is an economic instrument, not only a moral one

**[A]** Three effects worth stating, because they answer the objection that free service is unaffordable:

1. **Free service is the acquisition channel.** §18.5: `CAC_referral` is near zero and trust is the neighbourhood's currency. **The free categories are the only marketing a Mohalla team can afford** — and B-12 measures the path at the referral step.
2. **Free service is the legitimacy asset** that v1.3-A spent 23 amendments protecting. Its economic value is the difference between an organisation that can operate in a locality and one that cannot.
3. **Free service is the recruitment and retention channel.** The stress test's four doors (Purpose / Proof / Livelihood / Building) begin with Purpose; §34.2 D-9 requires a path from volunteering to earning. **Removing the free provision removes the front door.**

**[A] And the honest limit:** those three effects do **not** make free service self-funding. They make it *valuable*. Its funding remains §33's open question.

---

# 39. WHAT SHOULD NEVER BE MONETIZED

> **Rule from your brief, adopted:** identify categories that should not become commercialised merely because they can produce money. **Use the dignity principle established in v1.3-A.**

## 39.1 The prohibited commercial categories

| # | Category | Why it must never be monetised | Source / v1.3-A anchor |
|---|---|---|---|
| **NM-1** | **Vulnerable people's access to help** | Selling access converts need into a market and excludes the poorest — the exact inverse of the mission | **[S: Ch.2 principle 1; Ch.15]**; v1.3-A A-19 dignity rules |
| **NM-2** | **Emergency assistance** | A price at the moment of emergency is coercion; and it would create an incentive to *wait* for a payable emergency | **[S: Ch.15, Ch.16]**; §38.1 |
| **NM-3** | **Safeguarding, protection and incident response** | The protection function's legitimacy depends on it being beyond commerce. v1.3-A A-11's activation gate and A-10's liability framework exist to keep it non-commercial; **selling protection would make it a private security service, which A-07 explicitly declares the organisation is not** | **[S: Ch.16; Ch.9]**; **v1.3-A A-07, A-08, A-10, A-11** |
| **NM-4** | **Sensitive personal information** — conduct records, incident records, safeguarding data, beneficiary identity | Data is not an asset to be sold. v1.3-A A-20 §19.5 already lists prohibited uses including **commercial use**; A-18 §17.4 prohibits collecting categories that exist only to be exploitable | **v1.3-A A-17, A-18, A-20**; **[S: App. F "highly restricted"]** **[X: DPDP purpose limitation]** |
| **NM-5** | **Incident and case records** | Sealed for protection, not for product. Any analytics use requires DPIA and human review, and no sale is permissible | **v1.3-A A-20 §19.2–§19.5, A-21 §20.4** |
| **NM-6** | **Beneficiary testimony, images and stories** | "We helped them" is never "we may tell their story" — and it is certainly never "we may sell their story". Consent for a dignity-respecting publication is not consent to commercial exploitation | **v1.3-A A-19**; **[S: App. F minors' identities, mask identities]** |
| **NM-7** | **Verification, membership status or organisational endorsement** | Selling verification destroys its evidentiary value and creates a two-tier membership; selling endorsement converts legitimacy into inventory | **[S: Ch.12; Ch.13 gates]**; v1.3-A A-01 N-series (no partisan or commercial use of the brand) |
| **NM-8** | **Influence over decisions** — priority assessment, venture approval, resource allocation, leaderboard position | This is corruption by another name. The source's segregation rules exist to prevent it | **[S: Ch.18 segregation; Ch.8 step 5 criteria; Ch.25 anomaly review; Ch.17 step 3]** |
| **NM-9** | **Political or religious access** | Already prohibited: the social-impact fund is "not political or religious activity" **[S: Ch.20]**, and v1.3-A A-01/A-05 prohibit partisan and communal positioning | **[S: Ch.20]**; **v1.3-A A-01 N1–N9, A-05** |
| **NM-10** | **Volunteer labour, as a sellable resource** | Supplying members' unpaid time to a third party for money converts volunteering into labour brokerage | §15; §34.2 D-4; **[S: Ch.19 step 1 eligibility]** **[V]** |
| **NM-11** | **Data-derived behavioural or credit inference about members or beneficiaries** | Profiling vulnerable people for third-party value is the highest-harm use of the estate | **v1.3-A A-17 P4 DPIA triggers, A-18 prohibited collection, A-21 prohibited AI uses** **[X: DPDP]** |
| **NM-12** | **Access to the organisation's own audit, grievance or integrity routes** | A complaint channel that costs money is not a channel | **[S: Const. Art.17]**; stress-test M10; v1.3-A A-16 §15.2 |

## 39.2 The test

**[P]** A single question decides any new proposal:

> **Would monetising this make the organisation's help conditional on a person's ability to pay, or make a person's vulnerability valuable to the organisation?**
>
> If **yes** to either → **prohibited**, permanently, at every level, with no approval route. This is a Tier-1 candidate under v1.3-A A-13.

**[A]** Note the second limb, which is subtler and more dangerous: a category can be monetised *without* charging the vulnerable person — by selling data *about* them, images *of* them, or access *to* them. **The harm is identical and the transaction is invisible to the person harmed.** That is why NM-4, NM-5, NM-6 and NM-11 are in the list even though no beneficiary would ever see an invoice.

## 39.3 The grey zones, decided conservatively

| Grey zone | Position | Reasoning |
|---|---|---|
| **Selling training that is also given free** | **Permitted with separation** (§38.1) | Same content, different payer, separately accounted; the free provision must not shrink |
| **A business paying for a community-benefit project** (e.g. a shop funding a lane repair) | **Permitted as sponsorship, not as purchase** | The community benefit must not become conditional on the sponsor's preferences; donor intent honoured **[S: SOP-07]**; no naming rights that imply endorsement (NM-7) **[V]** |
| **Charging a fee for a materials pass-through** (actual cost, no margin) | **Permitted only with published cost basis and City approval** | A hidden margin converts service into commerce; an honest pass-through does not |
| **Selling aggregate, anonymised insight to a public body** | **PROHIBITED at Stage 0–3; revisitable only with DPIA, professional advice and Tier-1 amendment** | Re-identification risk in a small locality is high **[A]**; v1.3-A A-17/A-18 classification applies; the reputational cost of being an organisation that sells data about poor neighbourhoods exceeds any plausible revenue **[I]** |
| **Paid priority or expedited service** | **PROHIBITED** | Directly violates §39.2 limb one, and NM-8 |
| **Membership fees** | **PROHIBITED as a condition of membership**; a voluntary contribution is a different thing and must never gate access | Membership is verification-based, not fee-based **[S: Ch.12]**; a fee would exclude the poorest members, inverting the mission |

---

# 40. COSTED PILOT

> **Rule from your brief, adopted:** do NOT choose a large pilot because the organisation wants to look impressive. **The pilot must answer: can the system actually work with real people and real money?**

## 40.1 The source already specifies the pilot

**[S: Ch.30 Phase 2 — Pilot Mohalla]**

| Field | Source content |
|---|---|
| **Objective** | "**Run one local team.**" |
| **Activities / prerequisites** | "Verified members, initial service projects, **initial business venture**, evidence collection." |
| **Outputs / exit gate** | "**Pilot report, safety review, finance reconciliation, member feedback, improvement plan.**" |
| **Blockers** | "Verification, training, finance, safety." |

**[A]** The architecture's own answer to "how big should the pilot be?" is **one team**. That is adopted unchanged. **This section does not enlarge it**; it specifies what the one team must be *able to measure*, which is what makes it a pilot rather than a launch.

## 40.2 Minimum pilot specification

| Element | Minimum | Source basis | Why not more |
|---|---|---|---|
| **Team structure** | STATE A, nine functions covered, four finance hands distinct with at least one outside the team | **[S: Ch.10; Ch.18 segregation; §3.3]** | State B sub-roles buy continuity that a pilot does not yet need and cannot yet afford (HC-09) |
| **People** | `N_roles_min = ⌈9/c⌉` role-holders plus enough `N_act` to run **one** service activity and **one** venture project simultaneously | **[S: Ch.10; Ch.13]**; no numeric threshold invented **[S: Ch.33]** | A pilot that cannot run service and venture *at the same time* cannot measure the cross-subsidy (§6.3), which is the thing most in need of measurement |
| **Services** | Two or three activities from the time-costed categories 1–3 (§6.4), one of which runs to outcome verification | **[S: Ch.15 step 10; B-02]** | Cash-intensive categories 6–7 would require a funding instrument the pilot does not have (§33) |
| **Business** | **One** approved venture in **one** category, with a real customer and a written scope, price, timeline and acceptance criteria | **[S: Ch.17 steps 3–4; Ch.30 "initial business venture"]** | Two ventures would confound `CM̄_j` measurement; one is enough to test the whole 14-step lifecycle |
| **Technology** | **None required.** Manual records meeting MVC-1…MVC-11 (§26.2) | **[S: Ch.30 Phase 1 permits "pilot-ready platform/manual process"]** | The platform is "Blocker before scale" **[S: Ch.31]**, not before pilot. **Building it first would be the most expensive possible mistake** |
| **Governance** | MVC-1…MVC-11 only; Tier-1 integrity controls (§36.2); one monthly report; measurement of `H_gov` | §26.2; §36.2 | Full fidelity would consume the pilot (§25.4 GB-4+ risk) and would measure nothing about the *minimum* |
| **Financial controls** | Two-signature money; receipt + approval link; payment sheet with formula version; reconciliation; the compensation formula **written and approved before the first recruitment** | **[S: Ch.18; Ch.19 step 13; §34.2 D-1]** | A pilot that runs without an approved formula measures nothing about dignity (§34) and creates a liability |
| **Training** | Verification and safety doctrine; the venture skill needed for the one project; safeguarding if any activity involves minors | **[S: Ch.12; Ch.12 boundary; v1.3-A B6]** | Certified domains are gated externally **[V]** and must not be entered by a pilot team without certification |
| **Measurement period** | **Long enough to observe one full seasonal/collection cycle**, and at least `M_target` months so the zero/low-revenue path is observed | §9.6; HC-15; **[M]** for the actual number | A one-month pilot cannot measure `r_collect`, `Δt_collect`, `r_ret` or `σ` stability — i.e. cannot answer any of the five viability questions |

## 40.3 What the pilot must MEASURE — the deliverable list

**[A]** This is the pilot's real product. **Not a success story: a set of numbers that replace the [M] variables in this model.**

| # | Measurement | Replaces | Needed by |
|---|---|---|---|
| **P-01** | **`H_gov` per month, by role and by GC line** — the time-and-motion study | The 8–40 band (§25.4); `σ`; `σ_max` | **Everything.** If `σ > σ_max`, no revenue figure matters (§25.4 conclusion) |
| **P-02** | `h_proj`, `h_qa`, `h_rev` actual vs estimated, per project | §11.4, §17.2, HC-06, HC-13 | `P_max` and `P_be` |
| **P-03** | `P_price`, `C_var`, `CM̄_j`, `CM̄_j / h_proj` for the venture category | §7.2, §11.4, §19 | Gate G3 (§19.3) |
| **P-04** | `r_lead`, `r_prop`, `r_close`, `h_acq`, `CAC` (mostly hours) | §18 | Whether the City pipeline (B-21) is necessary or sufficient |
| **P-05** | `r_collect`, `Δt_collect`, ageing | §18.6, §12.3 row 3, E-07 | The accounting-basis decision and B-13 terms |
| **P-06** | `N_ver`, `N_act`, `r_act`, `r_ret`, exits by reason, `T_tenure` | §14.3, §15.3 | `C_vol_per_hour`, `T_be` (B-08) |
| **P-07** | `C_L1` actual — the true monthly cost of existing | §4.4, §9.6, §11.2 | `B_bare`, `M_runway`, float sizing |
| **P-08** | `C_vol_total` per onboarded member, by component | §15.2 | Whether recruitment or retention is the better investment |
| **P-09** | `H_svc` actual vs budget; service outcomes verified | §6.3, B-01, §35 I-01 | Whether the cross-subsidy is being consumed |
| **P-10** | Solvency line reached per period (§8.3) and scenario position (§10.2) | §10, §11 | The team's actual economic trajectory |
| **P-11** | `E_shock` — every HC-* event that occurred, with its cost in hours and rupees | §5.2, §11.2 `B_resilient` | The expected-shock term nobody estimates |
| **P-12** | Escalation latency for each City/State request made | §20.3 rule 2, §21.3, B-15(1) | Whether shared services are real or nominal |
| **P-13** | Member payment continuity (paid in how many periods out of how many) | §12, §34.2 D-1/D-5; stress-test F-06 evidence | The dignity test |
| **P-14** | Beneficiary and customer feedback, and any complaint via the independent route | **[S: Ch.30 exit gate "member feedback"]**; §28.2 V-G3/V-G4 | Trust viability (§41) |
| **P-15** | `C_city` actual — what the City layer cost to run for one team | §26.5, §31.2 | **`K_min` — and therefore the whole scaling question** |

**[A] P-15 deserves emphasis:** a one-team pilot is the *only* time the City layer's cost can be observed without the confound of sharing. **It is the most expensive measurement per team and the most valuable per decision**, because `K_min` (§26.5) determines whether the architecture is deployable in ordinary neighbourhoods at all.

## 40.4 Pilot cost structure — variables, not amounts

**[C]**
```
C_pilot = C_formation            (verification, ID, training, first materials, first records)
        + M_measure × C_L1       (existence cost over the measurement period)
        + C_city_pilot           (the City layer's cost, P-15)
        + C_capability           (certification, insurance decision, legal, accounting)
        + C_float                (B-04 float committed, not spent — a commitment, not a cost, unless unrecovered)
        + C_measurement          (the time-and-motion study itself, P-01 — which is real and is usually forgotten)
        − V_collected_pilot      (whatever the one venture actually collects)
```

**[A]** Every term is a variable. **The one structural claim this document makes is that `C_measurement` and `C_city_pilot` are routinely omitted from pilot budgets, and both are large relative to a one-team pilot.** A pilot that does not budget for measuring itself produces anecdotes, not decisions.

## 40.5 Pilot design rules

**[P]**
1. **One team, one city, one venture, two service activities.** Anything more confounds every measurement in §40.3.
2. **Choose the neighbourhood for measurability, not for impressiveness** — an *ordinary* locality with ordinary payable demand. A wealthy pilot proves nothing about the mission; a destitute pilot proves nothing about the venture model. **§19's framework should be run honestly on the candidate area and the result published either way.**
3. **Recruit for the pilot, do not recruit *into* the pilot.** The stress test's Scenario A conclusion: "the first teams are *taught*, not *recruited*", with the founder or a national appointee mentoring personally.
4. **Publish the pilot design before running it,** including what would count as failure (§42). A pilot whose success criteria are written afterwards is marketing.
5. **Budget the measurement** (P-01, P-15) as a line item with a named owner.
6. **Do not build software for the pilot.** Manual records meeting MVC are sufficient **[S: Ch.30]**, and the manual experience is what tells you what to automate (§26.3).
7. **Anchor one revenue source before launch** if at all possible (stress-test M5-iii), and **run a second, unanchored team later** if the organisation can afford it — because SC-A and SC-B (§13.4) answer different questions and the model needs both.

---

# 41. PILOT SUCCESS CONDITIONS

**Rule from your brief, adopted:** do not invent pass/fail numbers without evidence. **Where thresholds are proposed they are marked `PROPOSED — REQUIRES FINAL APPROVAL`.** Each condition below therefore states a **form** (what must be true) and leaves the **value** to be set from pilot data or by approval.

## 41.1 The seven viability questions

| # | Viability | Question | Evidence form | Threshold | Verifiable from |
|---|---|---|---|---|---|
| **V1** | **Human viability** | **Do people return voluntarily?** | `r_ret` over the measurement period; `r_act` monthly; unsolicited return after a break; exits by reason | **`PROPOSED — REQUIRES FINAL APPROVAL`** — and it must be set *relative to a comparison*, not absolutely: external research shows first-year retention is weakest and ~12% annual turnover occurs in one sample **[X]**, so a raw number without context is meaningless | P-06 |
| **V2** | **Service viability** | **Can meaningful service be delivered?** | Outcome-verified activities — "Did the project solve or reduce the problem?" **[S: Ch.15 step 10]**; beneficiary confirmation; `H_svc` actual vs budget | Count **and** outcome rate; **never** planned activity **[S: Ch.15]**. Value `PROPOSED` | P-09, P-14 |
| **V3** | **Business viability** | **Can legitimate revenue be generated?** | A completed 14-step lifecycle **[S: Ch.17]** ending in **collected** revenue; `r_repeat > 0`; `CM̄_j / h_proj` above the approved floor | **`PROPOSED`** — and note that "legitimate" is doing work here: collected, non-circular, non-related-party **[S: Ch.25]** | P-02…P-05, P-10 |
| **V4** | **Financial viability** | **Can obligations be paid?** | Solvency line reached (§8.3); payment continuity (P-13); accrual ageing (B-05); reconciliation with no unexplained material gaps **[S: Ch.13 gate]** | **Minimum condition, not proposed but derived: at least S-2 (worker + statutory solvency) in the final `n` periods, with no unreconciled gap and no veto-gate breach.** `n` is `PROPOSED` | P-10, P-13, §27.1 |
| **V5** | **Governance viability** | **Can controls operate without crushing the team?** | `σ = H_gov / (N_act × T_avail)` measured; report lateness; records back-filled or contemporaneous; MVC compliance | **`PROPOSED`: `σ < σ_max` (§26.1) and no systematic back-filling.** The stress test's early-warning list is the detector: "reports filed late then back-filled; identical photo evidence; payment sheets completed after payment" | P-01, P-11, §27.5 |
| **V6** | **Leadership viability** | **Can leadership be transferred without collapse?** | A named, delegated successor per role **[S: Ch.9 succession column; Ch.10]**; a **completed** absence test — the Leader is genuinely unavailable for a stated period and the team continues; decision latency during that period | **`PROPOSED`: one completed absence test with payments and decisions continuing.** This is the local application of v1.3-A A-14 §13.8's continuity test | P-12, §24, §29 Scenario 4 |
| **V7** | **Trust viability** | **Do participants and beneficiaries trust the system?** | Member feedback **[S: Ch.30 exit gate]**; beneficiary confirmation; complaints via the independent route **and their resolution**; unsolicited requests from residents; correction history | **`PROPOSED`** — and one **structural** requirement that needs no number: **a zero-complaint result is a warning, not a success** (v1.3-A A-16 test 3), because it usually means the route is not trusted | P-14 |

## 41.2 The composite success condition

**[C]** The pilot succeeds if and only if:

```
V4 (financial minimum, derived)  AND
V5 (σ < σ_max)                   AND
no veto-gate breach (§28.2)      AND
at least 4 of {V1, V2, V3, V6, V7} met at their approved thresholds
```

**[A]** Two design choices in that formula deserve explanation:

1. **V4 and V5 are conjunctive and non-negotiable.** A team that is trusted and delivers service but cannot pay its people or is crushed by its own controls has not demonstrated a *viable* unit — it has demonstrated a good intention. Conversely a team that pays its people while `σ > σ_max` is borrowing governance hours it will soon have to repay (§25.4 GB-4+).
2. **The remaining five are 4-of-5** rather than all-of-five, because **V3 (business) and V1 (retention) can legitimately trade off in a pilot**: an anchored team (SC-A) may show weak mission balance, and a service-heavy team (SC-C) may show weak revenue. **Both are informative.** Requiring all five would force the pilot toward a middle case that answers nothing.

## 41.3 What success does NOT mean

**[A]** Four explicit refusals:

1. **Success does not mean the team is self-sustaining.** §32.3 shows that requires four conditions beyond the pilot's control. The pilot measures whether the *mechanism* works, not whether the *neighbourhood* is rich.
2. **Success does not mean scale is approved.** `K_min` (P-15, §26.5) must be computed first, and §31's non-linearities must be priced.
3. **Success does not mean the percentages can now be set.** Compensation formula, leader multiplier, reserve rate and social-impact formula remain **NOT FINAL [S: Ch.33]** and require professional validation as well as pilot data.
4. **Success is not a verdict on the mission.** A pilot can succeed economically in a favourable locality and still leave the §32 question — can this work where the need is greatest? — unanswered. **That question requires a second pilot in a low-demand area, and the organisation should decide now whether it is willing to run one (§40.5 rule 7).**

---

# 42. PILOT FAILURE CONDITIONS

**Rule from your brief, adopted:** failure should produce **LEARNING**, not automatic abandonment. Each condition therefore states what is learned.

## 42.1 The failure conditions

| ID | Condition | Detector | What it means | What is learned | Response |
|---|---|---|---|---|---|
| **PF-01** | **Persistent inability to pay obligations** | Below S-2 (§8.3) for `n` consecutive periods; accrual ageing (B-05); payment continuity (P-13) | The venture cannot reach `B_healthy` in this locality with this model | **Which term failed:** `CM̄_j / h_proj`, `P_max`, `r_collect`, or `C_L1`. Each implies a different fix | §23 support-first; restructure the venture (SC-1); **not** dissolution of the team (§23.3) |
| **PF-02** | **Unsafe operating conditions** | Any DO-NOT breach; any unresolved serious safety matter; uncertified work in a regulated domain | **Veto gate V-G1 breached** — the pilot is failed regardless of every other result | Whether doctrine, training, supervision or pressure caused it | **Immediate stop-work [S: Ch.14]**; safety review; v1.3-A A-09/A-11 re-examination |
| **PF-03** | **Excessive governance burden** | `σ > σ_max` sustained; systematic back-filling; report lateness | The control set exceeds the unit's capacity — **GB-4 or worse (§25.4)** | **Which GC lines dominate**, and therefore which are shareable (§26.4) or automatable (§26.3) | Reduce cadence; move functions to City (B-21); graduate fidelity (§26.2). **This is the most valuable failure the pilot can produce** |
| **PF-04** | **No repeat participation** | `r_ret` and `r_act` collapse; nobody returns after a break | The proposition does not hold for real people | **Which door failed** — Purpose, Proof, Livelihood or Building (stress-test §9/§10); whether recruitment language over-promised (D-2) | Redesign recruitment and the participation path (stress-test M1); **not** "recruit harder" |
| **PF-05** | **No sustainable revenue pathway** | No collected revenue after the full lifecycle; `r_repeat = 0`; `CM̄_j / h_proj` below floor | The category or the locality cannot support a venture | **Which of the two** — and §19's framework is re-run with real data | Change category (B-14 two-track); change locality; or accept §32.4's subsidy answer honestly |
| **PF-06** | **Severe volunteer burnout** | Control-role exits (HC-18); workload concentration (§27.3); welfare signals **[S: Ch.9 Conduct & Welfare Coordinator]** | The model depends on unsustainable personal sacrifice | **Which roles**, and whether the load was governance, service or sales | §34.2 D-7/D-8; B-08 measurement; consider paying the irreducible roles (E-10) |
| **PF-07** | **Financial leakage** | Unreconciled gaps; missing receipts; self-approval attempts; expense anomalies | **Veto gate V-G2 breached** | Whether the cause is capability, workload (PF-03 causing shortcuts) or intent — **and these have completely different responses** | Audit/suspension if fraud suspected **[S: Ch.14]**; otherwise fix the workload that produced the shortcut |
| **PF-08** | **Customer exploitation** | Complaints; acceptance disputes; pricing pressure on vulnerable counterparties; any breach of §38/§39 | **Veto gates V-G3/V-G4 engaged**; the mission has been inverted | Whether the pressure came from revenue targets, from an individual, or from an uncategorised grey zone (§39.3) | Serious misconduct **[S: SOP-18]**; B-27 rules tightened; category refused |
| **PF-09** | **Mission distortion** | `H_svc` below budget while revenue rises (§29 Scenario 9); service categories drifting toward payable ones; outcome rate falling while activity count rises | The team is succeeding at the wrong thing | **Whether the incentive analysis (§35) predicted it** — and if it did, why the mitigation was not applied | B-01 enforced; §28.2 mission dimension escalated; City review of mission balance |
| **PF-10** | **Data or privacy incident** | Any SOP-22 trigger; access anomaly; publication without consent | Statutory and dignity exposure **[V]** | Whether classification, minimisation or training failed | v1.3-A A-17 P5 runbook; breach notification within statutory windows **[X]**; A-19/A-20 review |
| **PF-11** | **Dependency on one person, customer or funder** | Concentration ratios (§27.5); successor coverage; float dependency (G-15) | Fragility, not failure — but it invalidates the viability claim | Which dependency, and whether B-07/B-18/B-21 would have prevented it | Remediate before any scaling decision; **a pilot that passes while single-threaded has not passed** |
| **PF-12** | **Measurement failure** | P-01…P-15 not collected, incomplete, or collected retrospectively | **The pilot has failed at its only essential function** | That the organisation cannot yet observe itself — which is itself the finding | Re-run. **A pilot without measurement must not be reported as evidence, whatever else happened** |

## 42.2 Failure discipline

**[P]** Five rules:

1. **A veto-gate breach (PF-02, PF-07, PF-08, PF-10) fails the pilot outright**, regardless of financial or service results. This mirrors §28.2 and v1.3-A A-08's entrenchment logic: some outcomes are not tradeable.
2. **Every other failure produces a written lesson** in the M5 lessons register **with its "did the change work" column opened** (v1.3-A A-15), and a stated next step. The source's own rule: a failure "becomes a learning event if money is reconciled, customers are treated fairly, workers are paid according to approved rules and reasons are documented" **[S: App. A §13.5]**.
3. **Failure of the pilot is not failure of the architecture.** PF-03 and PF-05 are *findings about parameters*, and both are answerable by changing the control set or the venture category without touching a single principle.
4. **Failure must be published internally, and the improvement plan must exist** — the source's own Phase 2 exit gate requires an "improvement plan" **[S: Ch.30]**.
5. **Nobody is punished for reporting a failure.** **[S: Ch.14 step 5 "avoid fear of reporting problems"; App. A §18.4 anti-retaliation]**. A pilot in which failure is career-ending produces PF-12 plus concealment (§36 G-12).

---

# 43. ECONOMIC DECISION REGISTER

**Columns exactly as your brief specifies.** Items already UNRESOLVED in v1.2 or v1.3-A are **carried forward unchanged** and marked ⟨carried⟩. Items newly identified are ⟨new⟩. **Nothing is closed here.** Triggers are stated as events, not dates, because the source invents no numbers **[S: Ch.33]**.

## 43.1 Carried forward, unchanged

| ID | Decision | Current state | Evidence | Proposed direction | Owner | Validation required | Trigger |
|---|---|---|---|---|---|---|---|
| **E-C1** ⟨carried⟩ | Legal structure under Krytos | **UNRESOLVED [S: Ch.33]** | Entity, tax, liability, continuity all depend on it; v1.3-A N12–N16 | Review division / subsidiary / nonprofit / hybrid / two-entity | Founder/CEO | **Yes — corporate, tax, regulatory** | Phase 0 exit **[S: Ch.30]** |
| **E-C2** ⟨carried⟩ | Worker classification | **UNRESOLVED [S: Ch.33]** | Determines `C_stat`, the legality of role restrictions, and whether B-06 pro-rata is lawful | Categories: employee / contract labour / volunteer / stipend / business participant | CEO + HR | **Yes — employment, tax** | Before the first paid engagement |
| **E-C3** ⟨carried⟩ | Weekly revenue percentages | **NOT FINAL [S: Ch.33]** | "Use priority waterfall; set percentages after economic/legal/tax validation" | Set from pilot P-02/P-03 data, **never before** | CEO + Finance | **Yes** | After pilot measurement |
| **E-C4** ⟨carried⟩ | Leader multiplier | **NOT FINAL [S: Ch.33; App. A §15.3]** | Must be transparent, capped or bounded, justified by verified leadership work | Bounded differential with published rationale | CEO + Finance | **Yes** | With E-C3 |
| **E-C5** ⟨carried⟩ | Social-impact formula | **NOT FINAL [S: Ch.33]** | Allocate only after surplus conditions; restricted ledger | Keep restrictions verbatim **[S: Ch.20]**; formula from surplus data | CEO + Finance | **Yes** | When first surplus occurs |
| **E-C6** ⟨carried⟩ | Reserve release rules | **NOT FINAL [S: Ch.33]** | National Funds Manager prepares; approval matrix by amount/risk | Add B-15 latency targets and `Reserve_months` reporting | National Finance | **Yes** | Before the first reserve balance exists |
| **E-C7** ⟨carried⟩ | Venture categories | **POTENTIAL [S: Ch.33]** | Approve one by one using risk/value framework | **Adopt §19 as the risk/value framework** | CEO + AI & Business | **Yes by category** | Before the first venture proposal |
| **E-C8** ⟨carried⟩ | Minimum staffing thresholds | **NOT FINAL — "no final numbers invented" [S: Ch.33]** | §14 shows the right answer is *derived* from `H_gov` and `CM̄_j` | Derive `N_min` from pilot P-01/P-03; set role-coverage rule now (§14.4 rule 2) | CEO + HR | Yes | After pilot |
| **E-C9** ⟨carried⟩ | Team readiness threshold | **NOT FINAL [S: Ch.33]** | Eight autonomy gates **[S: Ch.13]** | Keep gates; add §30 stage evidence | CEO + Operations | Yes | With E-C8 |
| **E-C10** ⟨carried⟩ | Insurance | **UNRESOLVED [S: Ch.33; Ch.31 Blocker]** | v1.3-A A-10 L1–L15 unanswered | Obtain written answers; `C_ins` then enters `C_L2` | Legal + Finance | **Yes — broker, counsel** | Before protection activation |
| **E-C11** ⟨carried⟩ | CEO vs National Council authority | **UNRESOLVED [S: Ch.33; v1.3-A N19]** | Determines who approves every economic instrument in this pack | v1.3-A A-13/A-14 reserved-matters approach | CEO + governance | **Yes** | Before the Council is constituted |
| **E-C12** ⟨carried⟩ | Data retention / AI model policy | **UNRESOLVED / PROPOSED [S: Ch.33; v1.3-A N26, N37]** | Affects `C_doc`, log storage, `g_dp` | Per v1.3-A A-17/A-22 | AI & Data + Legal | **Yes** | Before the first 1,000 records |

## 43.2 Newly identified by v1.3-B

| ID | Decision | Current state | Evidence | Proposed direction | Owner | Validation required | Trigger |
|---|---|---|---|---|---|---|---|
| **E-01** ⟨new⟩ | **Adopt the four break-even lines as the reporting standard** | PROPOSED (§11.2) | "Revenue > 0" is not health (§2.2); six solvency lines exist **[C]** | Report solvency line + scenario position per period (§27.1) | Finance + CEO | No | Before the first revenue |
| **E-02** ⟨new⟩ | **Compensation formula must exist in writing before first recruitment** | **REQUIRED by §34.2 D-1**; depends on E-C3 | A rule that does not exist cannot be understood or challenged | Write a *provisional* formula for the pilot, approved and published, revisited after P-03 | CEO + Finance | **Yes — employment, tax** | **Before recruiting anyone** |
| **E-03** ⟨new⟩ | **Who funds the centre before priority-5 income exists?** | **UNRESOLVED — no source instrument** | §8.6: Phase 1 cost is incurred before Phase 2 revenue; priority 5 is downstream | Name the source explicitly (founder capital / Krytos / validated donation / accrued-and-waived fee) | CEO + Finance + Council | **Yes — tax, entity, donor restriction** | Before Phase 1 spend |
| **E-04** ⟨new⟩ | **At what level does priority 4 (founder compensation) apply?** | **[M] assumed above team level (§8.7)** | A neighbourhood venture cannot fund a national founder | Confirm aggregation level | CEO + Finance | **Yes** | With E-C3 |
| **E-05** ⟨new⟩ | **Cold-start instrument: float, anchored revenue, or slower cadence** | PROPOSED — B-04 (§9.6); stress-test M5 | No cold-start instrument exists anywhere in the source | Adopt B-04 with its five controls, or the anchored-revenue precondition, or both | CEO + Finance | **Yes — tax, accounting** | **Before forming the first team** |
| **E-06** ⟨new⟩ | **Is governance work volunteer or compensated, and from what source?** | **UNRESOLVED (§16.3 B-09 rule 4)** | §8.4: category D has no funding line; §25.5: the heaviest loads fall on the least supported roles | Decide per role; §34.2 D-8 requires *some* roles to cease being volunteerable | CEO + HR + Finance | **Yes — employment** | Before the first appointment |
| **E-07** ⟨new⟩ | **Gross revenue basis: receipts or invoiced?** | **UNRESOLVED — the source explicitly leaves it open**: "depending on final accounting policy" **[S: App. A §14.3]** | Determines whether workers are paid in the month they worked (§12.3 row 3) | **Receipts basis recommended for member-facing payment; invoiced basis for management reporting** — with the choice published | Finance + CEO | **Yes — accounting, tax, labour** | **Before the first invoice** |
| **E-08** ⟨new⟩ | **Reserve seeding (B-03) — source, amount, custody** | PROPOSED | §8.5: reserves arrive last; a new team has none | Seed `M_cov` months of `C_L1` at formation | CEO + Finance | **Yes — entity, banking (v1.3-A N15/N16)** | With E-05 |
| **E-09** ⟨new⟩ | **Payment cadence for teams below `B_healthy`** | PROPOSED (HC-17, §12.6 rule 3) | Weekly cadence × lumpy revenue = repeated empty periods; transaction and governance cost per cycle | Fortnightly or monthly below `B_healthy`, disclosed at recruitment; **priority order and transparency unchanged** | CEO + Finance | **Yes — labour** | Before the first recruitment |
| **E-10** ⟨new⟩ | **Which roles may never be unpaid?** | PROPOSED (§34.2 D-8) | The four segregated finance hands and the safety role carry legal exposure | Name the roles; fund them explicitly | CEO + HR + Legal | **Yes** | With E-06 |
| **E-11** ⟨new⟩ | **`K_target` — teams per city, and density-first growth (B-23)** | PROPOSED; `K_min` computable only after P-15 | §26.5, §31.2: viability is a function of `K`, not `T` | Compute `K_min` from pilot; set `K_target` with margin | CEO + Operations + Finance | Yes | After pilot P-15 |
| **E-12** ⟨new⟩ | **Service Continuity Instrument (B-24)** | PROPOSED | §33.3: cash-requiring service stops when revenue falls, and safeguarding response may never stop | City materials allocation + emergency exception + published funding statement | CEO + Operations + Finance | **Yes — donation law, FCRA, tax** | Before any category 4–7 service |
| **E-13** ⟨new⟩ | **Cross-subsidy model (B-16 layers)** | PROPOSED; Layers 1–2 are **[S]** implementations | §21.4: money cannot move laterally; §22.4 | Adopt Layers 1–3 now; defer 4–5 | CEO + Council | **Yes for Layers 3, 5** | Before the second team |
| **E-14** ⟨new⟩ | **"Repeatedly" defined (B-17)** | PROPOSED | **[S: App. A §14.5]** says "repeatedly" without a count | `n_consecutive` / `n_of_m` published in advance | CEO + Finance + Audit | Yes | Before the first underperformance review |
| **E-15** ⟨new⟩ | **Concentration limits (B-07(3))** | PROPOSED | §29 Scenario 2; HC-24; G-04/G-10 | Customer, category and skill limits, computed not judged | AI & Business + Finance | No | Before the second customer |
| **E-16** ⟨new⟩ | **Direct-cost attribution rule (G-05)** | PROPOSED | The `C_var` / `C_L1` boundary is where expense shifting lives | One written rule per venture category, approved at City level | Finance + City | **Yes — accounting** | Before the first venture |
| **E-17** ⟨new⟩ | **Risk-proportionate integrity tiers (B-25)** | PROPOSED | §36.2; your brief's "do not burden low-risk teams with maximum controls" | Computed tier assignment; recorded tier movement | Audit + Finance | No | With the pilot |
| **E-18** ⟨new⟩ | **Health panel with veto gates instead of a composite score (B-22)** | PROPOSED | §28.3: a composite is gameable in six ways; **[S: Ch.25]** weights are PROPOSED | Eight dimensions + four veto gates at team level; leaderboard unchanged | CEO + Operations | Yes | Before the first team report |
| **E-19** ⟨new⟩ | **Price floors and idle-capacity doctrine (B-11)** | PROPOSED | §17.3: under-pricing is the likely response to idle capacity | Approved floor per category; City business review for exceptions | AI & Business + City | Yes | Before the first proposal |
| **E-20** ⟨new⟩ | **Service/Commerce separation rules (B-27)** | PROPOSED | §38.2; v1.3-A A-19/A-20 | Adopt the six rules; refuse unclassifiable activities | CEO + Legal | **Yes — consumer protection** | Before the first mixed activity |
| **E-21** ⟨new⟩ | **Never-monetised list (NM-1…NM-12)** | PROPOSED as **Tier-1 candidates** under v1.3-A A-13 | §39; the dignity principle (v1.3-A A-19) | Entrench with the §39.2 two-limb test; no approval route | CEO + Council | **Yes — enforceability** | With the v1.3-A Tier-1 decision (N21) |
| **E-22** ⟨new⟩ | **Density-first growth rule (B-23)** | PROPOSED | §31.2 | Raise `K` before opening cities | CEO + Operations | No | Before the second city |
| **E-23** ⟨new⟩ | **Pilot design, measurement budget and locality choice** | PROPOSED (§40) | **[S: Ch.30 Phase 2]** specifies one team; measurement is unbudgeted by default | One team, one venture, two service activities, P-01…P-15 funded and owned | CEO + Operations + Finance | Yes | **Immediately — this is the next action** |
| **E-24** ⟨new⟩ | **Second pilot in a low-demand locality** | PROPOSED (§41.3 point 4) | The §32 question cannot be answered by a favourable pilot alone | Decide in principle now; schedule after pilot 1 | CEO + Council | No | After pilot 1 report |

---

# 44. v1.3-B AMENDMENT PACK

**Merge instruction [P]:** 27 amendments, **B-01 … B-27**, each additive. **Nothing in v1.2 is deleted, renumbered or reworded; nothing in v1.3-A is silently rewritten.** Where an amendment extends an existing instrument (the waterfall, the approval matrix, the launch checklist, the decision register, an SOP, a dashboard), it is *appended* and the original text is preserved. Each entry carries the twelve fields your brief specifies, in order.

## B-01 · Service Hour Budget

| Field | Content |
|---|---|
| **1. Amendment ID** | B-01 |
| **2. Source reference** | **[S: Ch.15 service loop and categories; Ch.25 mission impact 20%; Ch.24 daily "tasks, attendance"; Ch.8 operating loop]**; §6.3 of this model |
| **3. Problem** | Service and venture work draw from one hour pool; mission work is unfunded by the waterfall (§8.4) and therefore silently consumed first in any hard month. The cross-subsidy is invisible in every ledger |
| **4. Economic mechanism** | An explicit monthly `H_svc_budget` declared by the team, with actual reported alongside revenue, converting an unmanaged residual into a defended allocation |
| **5. Operational effect** | Service hours are planned, not leftover; variance is reportable to City |
| **6. Financial effect** | None directly — **no cash value is assigned to service hours**; the effect is on opportunity cost (HC-22, HC-25) |
| **7. Human effect** | Protects the mission-motivated member's reason for being there; makes invisible labour visible (§35 I-03) |
| **8. Technology effect** | Auto-derived from existing task and attendance records **[S: Ch.24]** — no new form (§26.3) |
| **9. New risk** | The budget becomes a quota to be hit cosmetically; service is performed to fill hours. **Mitigation:** outcome verification remains the measure of completion **[S: Ch.15 step 10]**, and "planned activities" may never be counted as impact **[S]** |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` (CEO + National Operations) |
| **11. Professional validation** | Not required |
| **12. Merge target** | New Chapter 15B; a field added to the Team Leader dashboard **[S: Ch.24]** |

## B-02 · Time-Costed Service Floor

| Field | Content |
|---|---|
| **1. Amendment ID** | B-02 |
| **2. Source reference** | **[S: Ch.15 seven categories and their controls; Ch.7 City materials allocation; Ch.6 State projects; Ch.20 social-impact fund restrictions]**; §6.4 |
| **3. Problem** | Cash-intensive service categories (food, infrastructure/emergency) stop when revenue falls, and a Stage-0 team has no instrument to fund them (§33.3) |
| **4. Economic mechanism** | Assigns each service category a cash-intensity rank; commits Stage 0–1 teams to the time-costed categories (education, cleaning/plantation, donation handling) as a floor, and assigns cash-intensive categories to City/State resourcing |
| **5. Operational effect** | Service continues at ₹0 revenue; a team does not attempt a disaster response it cannot resource |
| **6. Financial effect** | Prevents an unfunded cash commitment; routes materials cost to the layer that holds inventory **[S: Ch.7]** |
| **7. Human effect** | Removes the moral injury of being unable to help; prevents members spending personally (HC-03) |
| **8. Technology effect** | A category-cash-intensity attribute on the project record |
| **9. New risk** | Read as refusing help to the neediest. **Mitigation:** the assignment is of *resourcing responsibility*, never of *willingness to help*; escalation routes remain **[S: Ch.7, Ch.15 "authorities first"]**; B-24(2) provides an emergency exception |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** where a category carries a statutory or licensing dimension (food safety, permissions) |
| **12. Merge target** | Chapter 15B; Ch.31 checklist row; cross-reference from Ch.7 and Ch.6 |

## B-03 · Reserve Seeding Order

| Field | Content |
|---|---|
| **1. Amendment ID** | B-03 |
| **2. Source reference** | **[S: Ch.18 priority 6 and "National Funds Manager manages; release requires approval matrix"; Ch.19 step 10; Ch.33 "Reserve release rules NOT FINAL"; SOP-10; App. A §14.3 reserve definition]**; §8.5 |
| **3. Problem** | Reserves sit at priority 6, downstream of the volatility they exist to absorb; a new team's wage-protection buffer is zero during exactly the months it is needed |
| **4. Economic mechanism** | Pre-funds `M_cov` months of `C_L1` at formation from a named source, held under existing custody and release rules, and reconciled against any float — **the priority order is unchanged; priority 6 is seeded rather than awaited** |
| **5. Operational effect** | A shock in months 1–6 has somewhere to go other than a member's pocket |
| **6. Financial effect** | Converts an unquantified contingent liability into a bounded, approved, reconciled one |
| **7. Human effect** | Payment continuity becomes credible, which is the retention variable that matters most (§34.2 D-1) |
| **8. Technology effect** | A reserve-balance field per team with `Reserve_months` computed |
| **9. New risk** | A seeded reserve is treated as spendable income. **Mitigation:** release remains under the approval matrix **[S]**; SOP-10's bailout prohibition applies unchanged; B-15(3) reports adequacy in months |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** — source of funds, entity, banking, tax, donor restriction (with v1.3-A N15/N16) |
| **12. Merge target** | Chapter 18A (financial instruments); SOP-10 appended; Ch.31 finance row |

## B-04 · First-Season Float

| Field | Content |
|---|---|
| **1. Amendment ID** | B-04 |
| **2. Source reference** | **No source instrument exists** — this is the gap identified in **[S: Ch.18 priority 6 sequencing; Ch.30 Phase 2]** and in stress-test F-06/M5 |
| **3. Problem** | `M_runway = F_0 / L_min` (§9.6). With `F_0 = 0`, a standing-start team has no runway at all, and the source provides none |
| **4. Economic mechanism** | A capped, time-bound, explicitly accounted advance against future distributable amounts, available only in months 1 to `M_target`, sized by `F_0 ≥ M_target × L_min` |
| **5. Operational effect** | The team can exist, verify, train and build pipeline before its first collection |
| **6. Financial effect** | A recoverable advance, not a grant; reconciled against future distributable amounts; **may cover `L_min` and approved capability costs, and may never become a salary substitute or a venture bailout** |
| **7. Human effect** | Prevents the expectation breach that stress-test F-02 identifies as the earliest failure |
| **8. Technology effect** | Float drawn / outstanding / term-remaining fields on the dashboard (§27.1) |
| **9. New risk** | **Disclosed as G-15:** floats become permanent subsidies; teams optimise for float access rather than viability. **Mitigations (all from stress-test M5):** hard cap; fixed term; mandatory reconciliation; **one renewal maximum with City sponsor sign-off**; publication of utilisation |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** — accounting characterisation, tax, entity authority to advance, employment implications if used for pay |
| **12. Merge target** | Chapter 18A; Ch.30 Phase 2 exit gate (cross-referenced, not altered); SOP-10 pattern; §43 E-05 |

## B-05 · Accrued Compensation Ledger

| Field | Content |
|---|---|
| **1. Amendment ID** | B-05 |
| **2. Source reference** | **[S: Ch.18 priority 1; Ch.19 steps 2, 7, 12, 13; Ch.24 Member dashboard "earnings"; App. A §14.5]**; §12.4 |
| **3. Problem** | Where work is verified but revenue is not collected, an earned claim silently disappears. Priority 1 operates *within* a period and has no memory across periods |
| **4. Economic mechanism** | Records unpaid verified compensation as an aged, published obligation of the venture, settled at **priority 1 from the next collection ahead of new work's compensation**, with a cap beyond which no further credit work may be assigned without City approval |
| **5. Operational effect** | Extends worker-first across periods; makes credit exposure a managed quantity |
| **6. Financial effect** | Converts a hidden liability into a bounded, visible one; **strengthens** priority 1 rather than diluting it |
| **7. Human effect** | The single most important dignity instrument in this pack (§34.2 D-5): an earned claim is not erased by a bad month |
| **8. Technology effect** | Auto-derived from the existing payment sheet and formula-version record **[S: Ch.19 step 13]** |
| **9. New risk** | The accrual is read as a promise of payment. **Mitigation:** it is presented as a record of an obligation whose settlement depends on collection — "workers can[not] be promised money that does not exist" **[S: App. A §14.5]** |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** — accounting treatment, employment-law characterisation, tax, limitation periods |
| **12. Merge target** | Chapter 19A; payment sheet template appended; Ch.24 Member dashboard |

## B-06 · Pro-Rata Verified-Work Rule

| Field | Content |
|---|---|
| **1. Amendment ID** | B-06 |
| **2. Source reference** | **[S: Ch.18 priority 1 and bad-month behaviour; Ch.19 steps 6, 7, 12; Const. Art.6 equality; App. E]**; §12.5 |
| **3. Problem** | When `0 < V_gross < R_1` someone verified is not paid, and the source contains **no rule** for choosing whom. Left to discretion, it becomes a patronage instrument |
| **4. Economic mechanism** | Automatic, arithmetic pro-rata distribution of the available `A_1` across all verified work in the period, with role-holders taking the same proportional reduction, publication in the same period, and carry-forward of the balance under B-05 |
| **5. Operational effect** | Removes a discretionary decision from the most emotionally charged moment in a team's month |
| **6. Financial effect** | No change to the total paid; changes only its distribution |
| **7. Human effect** | Fairness under scarcity — which is the condition under which fairness is most remembered |
| **8. Technology effect** | Computable from the payment sheet; auto-triggered when `V_gross < R_1` |
| **9. New risk** | Pro-rata partial payment may itself be unlawful (minimum wage, timely payment). **Mitigation:** **[V]** determines this first; if partial payment is unlawful, **the correct consequence is that the work must not have been assigned on credit terms** — which is B-05's cap and B-13's terms, not a weakening of B-06 |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** — labour law, minimum wage, timely payment, classification (E-C2) |
| **12. Merge target** | Chapter 19A; SOP-09 appended |

## B-07 · Contribution-Gated Growth

| Field | Content |
|---|---|
| **1. Amendment ID** | B-07 |
| **2. Source reference** | **[S: Ch.13 step 5 "Open new vacancies where workload/risk/continuity need justifies"; Ch.10 State B "need-based, eligibility-based and RBAC-limited"; App. A §13.5 scaling conditions]**; §13.5 |
| **3. Problem** | Growth adds governance and training cost **before** it adds revenue capacity (HC-09); the source's need test is operational but not economic |
| **4. Economic mechanism** | Adds the economic half of the need test: `V_gross ≥ B_growth` for `n` periods; `CM̄_j / h_proj` not falling; and concentration limits on customer, category and single-skill dependency |
| **5. Operational effect** | Vacancies open on demonstrated contribution, not on enthusiasm |
| **6. Financial effect** | Prevents the most common small-unit insolvency: growing fixed cost ahead of contribution |
| **7. Human effect** | Protects existing members from being diluted by unfunded additions |
| **8. Technology effect** | Three computed gate fields on the dashboard |
| **9. New risk** | Suppresses growth that *would* have been productive. **Mitigation:** the gate applies to **funded positions**, not to volunteers; and an exception route exists with a recorded reason (v1.3-A A-15 M1) |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | Not required beyond E-C2 |
| **12. Merge target** | Chapter 13A; Ch.11 vacancy lifecycle (appended criterion) |

## B-08 · Volunteer True-Cost Accounting

| Field | Content |
|---|---|
| **1. Amendment ID** | B-08 |
| **2. Source reference** | **[S: Ch.12 HR lifecycle; Ch.9 Volunteer Manager family; Ch.25 "healthy active retention, not inactive names"; Ch.11 vacancy lifecycle]**; §15 |
| **3. Problem** | Volunteer labour is treated as free. It is not: onboarding cost is per person and contribution is over time, so `C_vol_per_hour` rises as retention falls (§15.3) |
| **4. Economic mechanism** | Measures `C_vol_total` per onboarded member, `T_tenure`, `r_ret`, `C_vol_per_hour` and `T_be` (break-even tenure), and compares `T_be` with actual tenure per cohort |
| **5. Operational effect** | Directs investment to retention when `T_be > T_actual`, and to recruitment when it is not |
| **6. Financial effect** | No cash value is assigned to volunteer **time** — only to the organisation's **own cost of processing** a volunteer. This preserves §39's prohibition on monetising help |
| **7. Human effect** | Ends the practice of treating volunteers as an inexhaustible free resource (§34.1 question 5) |
| **8. Technology effect** | Auto-derived from existing HR and training records |
| **9. New risk** | Misread as pricing a person's time. **Mitigation:** the measure is explicitly organisational cost, published with that definition attached |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** only where it touches classification (E-C2) |
| **12. Merge target** | Chapter 12A; Ch.25 metric specification appended |

## B-09 · Paid/Volunteer Boundary Rules

| Field | Content |
|---|---|
| **1. Amendment ID** | B-09 |
| **2. Source reference** | **[S: Ch.18 priority 1; Ch.19 step 1 eligibility; Ch.10 Supporting Members; Ch.15 step 7; App. A §14.3 worker compensation]**; §16 |
| **3. Problem** | Model D (volunteer service + paid venture work) is the only source-consistent labour model, but its boundary is nowhere written — so whether a person is paid depends on who asked, which is a fairness and discrimination risk |
| **4. Economic mechanism** | Seven rules aligning the payment boundary with the revenue boundary: venture work paid at priority 1 with written agreement; service work voluntary and never compulsory; no substitution of venture work onto volunteers; governance work explicitly named as volunteer or compensated; hour expectations disclosed at recruitment; hours recorded separately; the boundary published |
| **5. Operational effect** | A member can state unambiguously which of their activities are paid |
| **6. Financial effect** | Makes the payroll a *consequence of revenue* rather than a claim against it — the only structure the waterfall can support (§16.4) |
| **7. Human effect** | Prevents the two-tier resentment of "mixed without a rule"; protects dignity (§34.2 D-4) |
| **8. Technology effect** | A work-type attribute on the task record |
| **9. New risk** | The boundary hardens into a caste distinction between "earners" and "volunteers". **Mitigation:** mission impact carries the **higher** performance weight **[S: Ch.25]** and that ordering must be visibly honoured; recognition is not pay-dependent **[S: Ch.24 achievements]** |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** — employment and labour characterisation of each category; depends on E-C2 |
| **12. Merge target** | Chapter 12A; Constitution cross-reference (v1.3-A A-05 equal treatment); SOP-01 appended |

## B-10 · Capacity Ceiling and Demand Referral

| Field | Content |
|---|---|
| **1. Amendment ID** | B-10 |
| **2. Source reference** | **[S: App. A §13.5 "sufficient trained people"; Ch.17 steps 6–8; Ch.7 "combine skills… coordinate delivery"; Ch.6 specialist deployment]**; §17.3 |
| **3. Problem** | Demand exceeding `P_max` degrades QA, then acceptance, then collection, then the trained worker's tenure (§17.3) |
| **4. Economic mechanism** | A team may not accept work beyond `P_max` computed **after** `H_gov` and `H_svc` are subtracted; excess demand is referred into the City pipeline for allocation to another team. **Referral is recorded as a success, not a failure** |
| **5. Operational effect** | Prevents over-commitment; makes capacity a scheduling input |
| **6. Financial effect** | **The only cross-subsidy that costs nobody cash** (§22.4 Layer 1): one team's surplus demand becomes another's revenue |
| **7. Human effect** | Protects delivery workers from the overload that drives exit **[X]** |
| **8. Technology effect** | `P_max` and utilisation computed on the dashboard (§27.2) |
| **9. New risk** | Referral becomes refusal — demand is turned away rather than redirected. **Mitigation:** referral is a recorded action with a destination, auditable at City level **[S: Ch.7]** |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | Not required |
| **12. Merge target** | Chapter 17A; SOP-11/SOP-12 appended; Ch.7 City responsibilities (cross-reference) |

## B-11 · Idle Capacity Doctrine

| Field | Content |
|---|---|
| **1. Amendment ID** | B-11 |
| **2. Source reference** | **[S: Ch.7 City pipeline; Ch.17 step 2 validation; Ch.7 escalation lane 5 business dispute]**; §17.3 |
| **3. Problem** | When demand is low, the rational short-term response is to cut price — which lowers `CM̄_j`, raises `P_be` and produces the SC-25 scarcity case |
| **4. Economic mechanism** | When `P_demand < P_max` for `n` periods, the team must raise `H_acq` with City pipeline support, raise `H_svc` within the B-01 budget, and **not** reduce price below an approved floor without City business review |
| **5. Operational effect** | Converts idle capacity into either future demand or present mission, rather than into margin destruction |
| **6. Financial effect** | Protects `CM̄_j / h_proj`, the variable that determines whether the unit is viable at all (§11.4) |
| **7. Human effect** | Prevents the demoralisation of a team chasing work at any price |
| **8. Technology effect** | Utilisation field; floor breach flag |
| **9. New risk** | A price floor makes the team uncompetitive. **Mitigation:** floors are set **per category and per city** from measured data, not nationally, and are reviewed with the venture (§19) |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** — competition law if floors are set collectively above team level |
| **12. Merge target** | Chapter 17A; SOP-11 appended |

## B-12 · Trust-to-Demand Conversion Path

| Field | Content |
|---|---|
| **1. Amendment ID** | B-12 |
| **2. Source reference** | **[S: Ch.24 communications rules and authorised spokespersons; Ch.25 community trust 10% and the prohibition on follower counts determining leadership; Ch.9 Social Media family]**; §18.4 |
| **3. Problem** | Social media is mistaken for a sales channel. The architecture already forbids using follower counts and views to determine leadership **[S: Ch.25]**, so it cannot coherently rely on them to feed revenue |
| **4. Economic mechanism** | Treats public communication as a legitimacy instrument with an **indirect, lagged** return: verified published outcomes → local trust → referrals and inbound requests → City pipeline qualification → venture work. Measured at the **referral** step (`r_referral`), never at the view |
| **5. Operational effect** | Communications effort is justified by referrals, not by reach |
| **6. Financial effect** | Redirects scarce `H_acq` toward the cheapest acquisition channel available (§18.5) |
| **7. Human effect** | Removes the pressure to exaggerate — which v1.3-A A-07 already requires against |
| **8. Technology effect** | A referral-source field on the lead record |
| **9. New risk** | Referral attribution is unreliable and can be gamed. **Mitigation:** referral is recorded at City pipeline qualification **[S: Ch.7]**, not self-declared by the team |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** where publication creates commercial representations |
| **12. Merge target** | Chapter 24A; SOP-14 cross-reference |

## B-13 · Collection Terms Standard

| Field | Content |
|---|---|
| **1. Amendment ID** | B-13 |
| **2. Source reference** | **[S: Ch.17 steps 4, 10, 11; Ch.19 step 3 reconciliation; Ch.7 lane 5; App. A §14.3 gross revenue basis]**; §18.6 |
| **3. Problem** | Collection sits at the *end* of the chain and decides cash; `Δt_collect` and the unresolved receipts-vs-invoiced basis together determine whether workers are paid in the month they worked (§12.3 row 3) |
| **4. Economic mechanism** | Six terms per approved venture: written scope/price/timeline/acceptance before work **[S — already mandatory]**; advance or milestone structure where the category permits; stated payment window; a lawful, non-coercive consequence for non-payment **never enforced by protection roles**; automatic escalation at stated ageing; no further work beyond an approved arrears cap |
| **5. Operational effect** | Cash timing becomes a contract term rather than a hope |
| **6. Financial effect** | Raises `r_collect`, shortens `Δt_collect`, bounds B-05 accruals |
| **7. Human effect** | Prevents the most damaging routine event — delivered work, unpaid worker (§12.4) |
| **8. Technology effect** | Ageing buckets and terms fields on the venture record |
| **9. New risk** | Terms make the team uncompetitive against informal providers. **Mitigation:** terms are per category and negotiable within an approved band; the advance is the *only* non-negotiable element where `C_var` is material |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** — contract enforceability, interest, consumer law, and **absolute separation of debt collection from protection roles** (v1.3-A A-08/A-09) |
| **12. Merge target** | Chapter 17A; SOP-12 appended; contract template **[S: Ch.31 business row]** |

## B-14 · Two-Track Venture Strategy

| Field | Content |
|---|---|
| **1. Amendment ID** | B-14 |
| **2. Source reference** | **[S: Ch.17 steps 2–3 and the seven categories with controls; Ch.33 venture categories POTENTIAL; Ch.7 City pipeline; Ch.6 specialist pool]**; §19.4 |
| **3. Problem** | The easiest categories to enter (design/editing, local business technology) have the lowest contribution per hour and therefore the highest break-even volume — unreachable at small `P_max`. The high-contribution categories need skills and credibility a new team lacks |
| **4. Economic mechanism** | Track 1: a low-startup, fast-collection category for cash. Track 2: one higher-contribution category entered **through the City pipeline with a State specialist attached**, so the skill is borrowed rather than built at team expense. Sequencing rules prevent Track 2 before Track 1 collects, and prevent abandoning Track 1 while it funds `C_L1` |
| **5. Operational effect** | A realistic entry path instead of an aspirational one |
| **6. Financial effect** | Reaches `B_bare`/`B_healthy` early while building `CM̄_j / h_proj` over time |
| **7. Human effect** | Gives a skills ladder to members who cannot yet deliver Track 2 work |
| **8. Technology effect** | Track attribute on the venture record |
| **9. New risk** | Track 1 becomes permanent and Track 2 never starts. **Mitigation:** Track 2 entry is a §30 Stage-2 evidence item, reviewed at City level |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` (venture categories remain individually approved **[S: Ch.33]**) |
| **11. Professional validation** | **[V]** per category, using the source's own controls **[S: Ch.17]** |
| **12. Merge target** | Chapter 17A; SOP-11 appended |

## B-15 · Reserve and Shock Governance

| Field | Content |
|---|---|
| **1. Amendment ID** | B-15 |
| **2. Source reference** | **[S: Ch.18 reserves and social-impact restrictions; Ch.33 reserve release rules NOT FINAL; SOP-10; Ch.16 risk tiers; Ch.24 quarterly/annual cadences; Ch.7 City materials]**; §21.5 |
| **3. Problem** | A team cannot self-release reserves (§20.2), so the binding variable in a shock is **escalation latency** — and none is specified. HC-03 (personal spending) becomes the de facto reserve |
| **4. Economic mechanism** | Six requirements: stated escalation latency targets by risk tier; a pre-approved capped City emergency float for `C_trans_em`-class costs; reserve adequacy reported in **months** (`Reserve_months`); an annual correlated-shock test; an absolute prohibition on any §21.2 ❌ use, enforced as serious misconduct; publication of reserve and float utilisation |
| **5. Operational effect** | An emergency has a funded, fast path |
| **6. Financial effect** | Bounded, reconciled, published — the opposite of an informal float |
| **7. Human effect** | Ends the practice of members funding the organisation (§34.2 D-3) |
| **8. Technology effect** | Latency measured from request to release; `Reserve_months` computed |
| **9. New risk** | The City emergency float is captured (G-15). **Mitigation:** capped, per-City, reconciled monthly, published |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** — custody, banking, tax (with v1.3-A N15/N16) |
| **12. Merge target** | Chapter 18A; SOP-10 appended |

## B-16 · Layered Support Doctrine

| Field | Content |
|---|---|
| **1. Amendment ID** | B-16 |
| **2. Source reference** | **[S: Ch.14 support-first recovery including "resources"; Ch.6 State specialist pool and support/supervision of a struggling City Team; Ch.7 City support and materials; Ch.18 reserve custody; SOP-10; SOP-20 Team Recovery]**; §22.4 |
| **3. Problem** | Governance cost per team is roughly constant while revenue capacity varies by an order of magnitude (§14.2), so structurally non-viable teams are arithmetically certain — yet money cannot move laterally (§21.4) |
| **4. Economic mechanism** | Five layers adopted in sequence: **L1 non-cash transfer** (demand referral B-10, specialist deployment, pipeline allocation, materials) — already architecture; **L2 emergency support** (National reserve release, §23 recovery resources) — already architecture; **L3 formation subsidy** (B-03, B-04) — proposed; **L4 central pool** — deferred to Stage 4; **L5 recovery grants** — deferred and conditional |
| **5. Operational effect** | Support is available without inventing a lateral money transfer the source forbids |
| **6. Financial effect** | Layers 1–2 cost no cash; Layer 3 is bounded and reconciled |
| **7. Human effect** | A struggling team is supported rather than shamed — the source's own intent **[S: App. A §17]** |
| **8. Technology effect** | Support requests and outcomes recorded; referral volumes tracked |
| **9. New risk** | **Disclosed at §22.5:** Layer 1 transfers *mission hours* from strong teams to weak teams, consuming `H_svc`. **Mitigation:** B-01 makes the consumption visible; §35 I-06 records it |
| **10. Required approval** | Layers 1–2: **[S]** implementation. Layers 3, 5: `PROPOSED — REQUIRES FINAL APPROVAL`. Layer 4: deferred |
| **11. Professional validation** | **[V]** for Layers 3–5 funding source, tax and donor restriction |
| **12. Merge target** | Chapter 14A; SOP-20 appended |

## B-17 · Definition of "Repeatedly"

| Field | Content |
|---|---|
| **1. Amendment ID** | B-17 |
| **2. Source reference** | **[S: App. A §14.5 "If a venture repeatedly cannot pay workers lawfully and sustainably, it must be restructured, paused or closed"; Ch.14 step 8 "defined review period with evidence"]**; §23.4 |
| **3. Problem** | The source's own stopping rule turns on "repeatedly", which is undefined. Undefined, it becomes a judgement exercised by whoever is under most pressure |
| **4. Economic mechanism** | Defines "repeatedly" as `n_consecutive` periods below `B_bare`, or `n_of_m` periods below S-1 worker solvency, with all three values **approved and published in advance** and applied uniformly |
| **5. Operational effect** | Makes the stopping rule operable and predictable |
| **6. Financial effect** | Prevents both premature closure and indefinite loss-making |
| **7. Human effect** | **Publishing the definition in advance is what makes it fair.** A rule applied only when convenient is a threat |
| **8. Technology effect** | Computed from the solvency-line series (§27.1) |
| **9. New risk** | A team manages to the definition, staying just above it. **Mitigation:** the definition triggers *support*, not punishment (§23.1) — so gaming it gains nothing |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL`; values **[M]** |
| **11. Professional validation** | **[V]** — where closure engages employment or contractual obligations |
| **12. Merge target** | Chapter 14A; SOP-20 appended |

## B-18 · Succession-Neutral Promotion

| Field | Content |
|---|---|
| **1. Amendment ID** | B-18 |
| **2. Source reference** | **[S: Ch.26 dynamic leadership; Ch.9 per-role "Succession" column; Ch.10 Sub-Role and recorded delegation; Ch.22 delegation dates; App. A §1.1 Head Team ladder; Ch.25 weights PROPOSED]**; §24.3 |
| **3. Problem** | The ladder promotes the best team's leader upward, weakening the winning team — a success tax on success, which also creates an incentive to under-perform (§35 I-06) |
| **4. Economic mechanism** | Six mechanisms: successor-before-transition using the existing sub-role machinery; a bounded overlap period; a time-capped mentor obligation; promotion-cohort score reporting **with and without** a transition adjustment; **horizontal recognition as an alternative to vertical promotion**; and promotion recorded as a *cost* with an attached support decision |
| **5. Operational effect** | Capacity is transferred, not extracted |
| **6. Financial effect** | Preserves the promoted team's `P_max` and `CM` through the transition |
| **7. Human effect** | Removes the choice between ambition and loyalty; gives status without extraction |
| **8. Technology effect** | Uses existing delegation and succession fields — no new structure |
| **9. New risk** | Item 4 touches performance methodology, which is **PROPOSED/NOT FINAL [S: Ch.25; Ch.33]**. **Mitigation:** it changes only the *reporting* of a known structural effect, never the weights; and it is flagged for approval accordingly |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL`; item 4 additionally **[V]** |
| **11. Professional validation** | **[V]** for item 4 (performance methodology) and where promotion engages employment terms |
| **12. Merge target** | Chapter 26A (alongside v1.3-A A-14's Chapter 26A — appended, not merged); Ch.25 reporting appended |

## B-19 · Local Interim Authority Order

| Field | Content |
|---|---|
| **1. Amendment ID** | B-19 |
| **2. Source reference** | **[S: Ch.10 Sub-Leader "if available" and recorded delegation; Ch.18 Funds Manager cannot self-approve; Ch.8 "Team Leader within authority"; Ch.7 escalation]**; v1.3-A A-14 pattern; §24.4 |
| **3. Problem** | v1.3-A built apex succession but nothing at Mohalla level, where absence is frequent. A leader exit stops decisions **and payments** (§29 Scenario 4) |
| **4. Economic mechanism** | A standing written order naming who holds authority during absence, for how long, what they may **not** decide (reserve requests, venture approval, conduct outcomes, payment-formula changes — all reserved per §20.2), and the City fallback where no deputy exists |
| **5. Operational effect** | Payments and decisions continue through absence |
| **6. Financial effect** | Prevents the payroll paralysis that is the fastest route to attrition |
| **7. Human effect** | Members are not held hostage to one person's availability |
| **8. Technology effect** | Uses existing sub-role, delegation-date and RBAC fields **[S: Ch.22]** |
| **9. New risk** | An interim holder overreaches. **Mitigation:** the reserved list, a hard time limit, and City notification — the same three controls v1.3-A A-14 uses at apex level |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** where delegation touches financial mandates (v1.3-A N16) |
| **12. Merge target** | Chapter 10A; SOP appended; v1.3-A A-14 cross-reference |

## B-20 · Minimum Viable Control Set

| Field | Content |
|---|---|
| **1. Amendment ID** | B-20 |
| **2. Source reference** | **[S: Ch.10 State A control "Small size never removes safety, HR verification, finance integrity or evidence duties"; Ch.18 segregation; Ch.12; Ch.16; Ch.13 gates; Ch.19 step 13; Ch.24; SOP-08, 14, 19, 22; App. F]**; stress-test M6; §26.2 |
| **3. Problem** | The full control set exceeds a small team's capacity at GB-4 governance (§25.4), and informal non-compliance is worse than approved reduction — "shrink the operating scope, not the standards" |
| **4. Economic mechanism** | Eleven irreducible controls (MVC-1…MVC-11) selected by one criterion: **a control is in the minimum set if and only if its absence causes irreversible harm to money, safety, identity, privacy or public truth.** Everything else is graduated in by stage (§26.2 deferred list) |
| **5. Operational effect** | A Stage-0 team can be compliant rather than nominally compliant |
| **6. Financial effect** | Reduces `H_gov` — the largest lever on `σ` and therefore on `N_min` (§14.2) |
| **7. Human effect** | Prevents the back-filling culture that destroys evidence-based governance (stress-test F-05, F-30) |
| **8. Technology effect** | Fidelity tier per team; graduated record set |
| **9. New risk** | "Minimum" becomes permanent and teams never graduate. **Mitigation:** graduation is tied to §30 stage evidence, which is itself audited **[S: Ch.13 gate 8]**; **no standard is relaxed — only instrument count** |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** — statutory record-keeping minima, which set a floor below which no reduction is lawful |
| **12. Merge target** | Chapter 27A extension (with v1.3-A A-15); App. D SOP index tiered; App. F tiered |

## B-21 · City Shared Services Contract

| Field | Content |
|---|---|
| **1. Amendment ID** | B-21 |
| **2. Source reference** | **[S: Ch.7 City responsibilities and City role catalogue; Ch.6 State specialist pool; Ch.23 Auditor separation; Ch.18 segregation]**; §26.4 |
| **3. Problem** | Every shared function the minimum control set requires **already exists as a named City or State role** — but nothing states that a Mohalla team is entitled to use it, so both layers assume the other is doing it |
| **4. Economic mechanism** | A written, published statement per team of which functions the City performs on its behalf, at what cadence, with what response time, and what the team retains. Makes the `K` divisor explicit and therefore manageable |
| **5. Operational effect** | Verification, finance, pipeline, training, incident review, editorial and inventory become reliably available |
| **6. Financial effect** | **The largest single cost reduction available in the model** — it attacks the fixed term `H_gov_fixed` (§14.2 result 2) |
| **7. Human effect** | Relieves the three overloaded control roles (§25.5, HC-18) |
| **8. Technology effect** | A service-catalogue record per city; response times measurable (P-12) |
| **9. New risk** | The City becomes a bottleneck, converting shared service into central control — the failure **[S: App. A §16.2]** warns of. **Mitigation:** stated response times (§20.3 rule 2), measured latency (P-12), and a refusal-with-alternative rule (§20.3 rule 3) |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** for accounting and audit separation where functions are shared |
| **12. Merge target** | Chapter 7A; Ch.31 checklist row |

## B-22 · Health Panel with Veto Gates

| Field | Content |
|---|---|
| **1. Amendment ID** | B-22 |
| **2. Source reference** | **[S: Ch.25 dimensions, weights PROPOSED, anti-gaming controls, "Unsafe success is not success"; Ch.24 dashboards; Ch.13 gates]**; §28 |
| **3. Problem** | A single composite economic score would be gameable in at least six identifiable ways (§28.3), would rest on weights that are **PROPOSED/NOT FINAL [S]**, and would permit trade-offs the source forbids |
| **4. Economic mechanism** | Eight reported dimensions with incommensurable units, plus **four veto gates** (safety, money integrity, dignity/privacy, truth) whose breach makes the unit unhealthy regardless of every other reading |
| **5. Operational effect** | Health is assessed by three answerable questions (§28.4) rather than one number |
| **6. Financial effect** | Prevents revenue from being read as health — your brief's explicit prohibition |
| **7. Human effect** | Removes the pressure to trade safety or dignity for score |
| **8. Technology effect** | Auto-derived from §27 panels |
| **9. New risk** | A panel is harder to compare than a score. **Mitigation:** the **leaderboard remains exactly as the source defines it [S: Ch.25]**, with its PROPOSED weights, cohort normalisation and anomaly review — B-22 does not replace it and must not be extended into a leadership decision |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | Not required |
| **12. Merge target** | Chapter 25A (reporting extension only); Ch.24 Team Leader dashboard |

## B-23 · Density-First Growth Rule

| Field | Content |
|---|---|
| **1. Amendment ID** | B-23 |
| **2. Source reference** | **[S: Ch.7 City layer; Ch.30 Phases 3–5; Ch.6 State layer]**; §31.2 |
| **3. Problem** | Per-team viability is a function of `K` (teams per city), not of `T` (total teams). Spreading thin makes every team less viable — the opposite of the intuition that more cities means more growth |
| **4. Economic mechanism** | New teams are formed to raise `K` in existing cities until `K ≥ K_target`; a new city is opened only with a named City-layer capability and a funded `C_city` |
| **5. Operational effect** | Growth becomes a density policy |
| **6. Financial effect** | Lowers `C_per_team` (§26.5) and makes `B_healthy` reachable in ordinary neighbourhoods |
| **7. Human effect** | Teams are not left isolated without the shared services they were promised |
| **8. Technology effect** | `K` per city on the City dashboard **[S: Ch.24]** |
| **9. New risk** | Over-concentration in accessible areas leaves high-need areas unserved — a mission distortion. **Mitigation:** `K_target` is a *floor*, not a cap; opening in a low-`K` high-need area is permitted **with an explicit subsidy decision** (§32.4, E-12) rather than by pretending the economics work |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | Not required |
| **12. Merge target** | Chapter 30A (launch roadmap extension); Ch.31 checklist |

## B-24 · Service Continuity Instrument

| Field | Content |
|---|---|
| **1. Amendment ID** | B-24 |
| **2. Source reference** | **[S: Ch.20 social-impact fund sources and restrictions; SOP-07 donation handling; Ch.7 materials allocation; Ch.6 state projects; Ch.15 categories; Ch.16 protection duty]**; §33.4 |
| **3. Problem** | Service requiring materials, transport, certification or stock stops when revenue falls, and **the one obligation that may never stop — protecting a person from immediate harm [S: Ch.16]** — is unfunded by design (§33.3) |
| **4. Economic mechanism** | Three components: a restricted **Service Materials Allocation** held at City level under the existing Warehouse function and funded from validated donations, surplus-derived social-impact contributions, or an approved central allocation; a capped **Emergency Service Exception** with after-the-fact review and published counts (the service analogue of v1.3-A break-glass); and a published **Service Funding Statement** per team per quarter showing which source funded each element |
| **5. Operational effect** | Cash-requiring service can continue through a revenue trough |
| **6. Financial effect** | Creates a **named place for money to go and a named person to hold it** — the precondition for anyone giving it, consistent with **[S: SOP-07]** and **[S: Ch.20]** |
| **7. Human effect** | Ends the situation where a team must watch a need it cannot resource |
| **8. Technology effect** | Materials ledger **[S: SOP-15, SOP-16]**; exception log |
| **9. New risk** | Donor intent distorts the service programme; a materials allocation becomes a patronage resource. **Mitigations:** donor restriction honoured **[S: SOP-07; Ch.15 "donor intent"]**; allocation by the published priority-assessment criteria **[S: Ch.8 step 5]** with no margin criterion; quarterly publication |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** — donation law, FCRA, donor-restriction compliance, tax treatment of materials, any statutory duty to provide |
| **12. Merge target** | Chapter 20A (social-impact fund extension, restrictions preserved verbatim); SOP-07 appended |

## B-25 · Risk-Proportionate Integrity Controls

| Field | Content |
|---|---|
| **1. Amendment ID** | B-25 |
| **2. Source reference** | **[S: Ch.25 eight anti-gaming controls; Ch.17 step 3 tiered approval; App. E approval matrix by amount/risk; Ch.33 reserve release by amount/risk; Ch.27 audit; SOP-18]**; §36.2 |
| **3. Problem** | Uniform maximum controls would crush a Stage-0 team (B-20), while uniform minimum controls would leave real exposure unmanaged |
| **4. Economic mechanism** | Four integrity tiers assigned **by computation from records**, with controls scaled per tier; tier movement itself recorded; no tier removes a veto gate |
| **5. Operational effect** | Low-risk teams carry low control load; elevated teams are sampled |
| **6. Financial effect** | Control cost tracks risk rather than being fixed |
| **7. Human effect** | Avoids treating every team as a suspect — which is itself a retention factor |
| **8. Technology effect** | Tier computed from concentration, thresholds, findings and float status |
| **9. New risk** | Tier assignment is gamed by keeping records small. **Mitigation:** assignment is computed, not declared; a team may request a **lower** tier and must be answered with reasons; **movement between tiers is recorded**, because a quiet drop from Tier 3 to Tier 1 is the most informative event in the register |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** where statutory audit minima apply |
| **12. Merge target** | Chapter 27A; Ch.25 anti-gaming table appended; SOP-18 cross-reference |

## B-26 · Explicit Hybrid Funding Map

| Field | Content |
|---|---|
| **1. Amendment ID** | B-26 |
| **2. Source reference** | **[S: Ch.18 waterfall; Ch.20 social-impact fund and donations; Ch.7 City; Ch.6 State; Ch.5 National; Ch.30 Phases 0–1; App. A §1.1 "not merely a donation-funded charity"]**; §37.3 |
| **3. Problem** | The architecture is already hybrid in fact but has no published statement of which source funds which cost, so the blank cells (§8.4, §21.2, §33.3) remain invisible |
| **4. Economic mechanism** | One published table: for each cost layer of §4.4, which source funds it at each §30 stage — venture revenue, float, seeded reserve, validated donation, City allocation, State specialist pool, national platform budget, social-impact fund (surplus only). **No cell may be blank** |
| **5. Operational effect** | Every layer knows what it may spend and from where |
| **6. Financial effect** | Converts an implicit, unaccountable subsidy into an explicit, approved one |
| **7. Human effect** | Honesty with members about where money comes from (§34.2 D-2) |
| **8. Technology effect** | A funding-source attribute on every ledger entry |
| **9. New risk** | The map ossifies and prevents local initiative. **Mitigation:** it maps **sources**, not amounts; local venture choice remains autonomous **[S: App. A §16.1]** |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Professional validation** | **[V]** — every source's legality and tax treatment; FCRA for foreign funds **[X]** |
| **12. Merge target** | Chapter 18A; Ch.30 Phase 0/1 outputs appended |

## B-27 · Service/Commerce Separation Rules

| Field | Content |
|---|---|
| **1. Amendment ID** | B-27 |
| **2. Source reference** | **[S: Ch.15 service categories; Ch.17 venture categories; Ch.2 principle 1; App. F privacy]; v1.3-A A-19 dignity code, A-20 prohibited uses, A-04 refusal posture, A-13 Tier-1 mechanism**; §38.2, §39 |
| **3. Problem** | The same organisation serves beneficiaries and sells to customers, in the same locality, sometimes to the same people. Without a written wall, revenue pressure will erode the free side (§35 I-01, I-02) |
| **4. Economic mechanism** | Six separation rules (a beneficiary is never a sales prospect; relationships recorded separately; free provision never reduced to raise paid margin; no vulnerability-based pricing; language discipline in both directions; unclassifiable activities refused pending decision) plus the **twelve never-monetised categories NM-1…NM-12** and the two-limb test of §39.2 |
| **5. Operational effect** | Any commercial proposal is classified before it is pursued |
| **6. Financial effect** | Forecloses a category of revenue **permanently and by design** — the point of the amendment |
| **7. Human effect** | Guarantees that help is never conditional on payment (§34.2 D-10, §38) |
| **8. Technology effect** | A beneficiary/customer relationship-type flag with no join permitted between the two records (mirrors v1.3-A A-19's storytelling/service separation) |
| **9. New risk** | Over-application blocks legitimate mixed activities (a business sponsoring a community project). **Mitigation:** §39.3 decides the grey zones conservatively but **decides them**, so they are not blocked indefinitely — sponsorship is permitted with donor-intent and no-endorsement conditions |
| **10. Required approval** | `PROPOSED — REQUIRES FINAL APPROVAL`; **NM-1…NM-12 proposed as Tier-1 items under v1.3-A A-13** |
| **11. Professional validation** | **[V]** — consumer protection, unfair trade practice, sector-specific rules, data protection |
| **12. Merge target** | Constitution (Tier-1 candidate list appended to v1.3-A A-13 T1.x); new Chapter 15C; SOP-11/SOP-12 appended |

## 44.28 Adoption sequencing

**[A]** Twenty-seven amendments will not be adopted at once — the same fatigue problem v1.3-A §24.10 addressed. **[P]** Three stages, keyed to the same triggers:

| Stage | Amendments | Trigger |
|---|---|---|
| **Stage 1 — before forming the first team** | **B-20** (minimum viable control), **B-09** (paid/volunteer boundary), **B-27** (separation rules), **B-04** + **B-03** (float and seeded reserve), **B-26** (funding map), **B-19** (local interim authority), **B-06** (scarcity rule), **B-05** (accrual ledger), plus decisions **E-02, E-03, E-05, E-07** | Immediately — these are the pilot's preconditions (§40.2) |
| **Stage 2 — during the pilot, as measurement arrives** | **B-01** (service hour budget), **B-02** (service floor), **B-08** (volunteer true cost), **B-13** (collection terms), **B-14** (two-track), **B-10**/**B-11** (capacity ceiling, idle capacity), **B-22** (health panel), **B-25** (integrity tiers), **B-12** (trust-to-demand) | On first revenue, first volunteer cohort, first venture approval |
| **Stage 3 — before the second team or city** | **B-21** (shared services contract), **B-16** (layered support), **B-17** ("repeatedly"), **B-18** (succession-neutral promotion), **B-15** (reserve governance), **B-07** (contribution-gated growth), **B-23** (density-first), **B-24** (service continuity) | On the decision to form a second team or open a second city |

## 44.29 Burden check — the v1.3-A rule applied to this pack

**[C]** v1.3-A §25.3 established that 17 of 23 amendments impose nothing on Levels 0–4. The same test is applied here:

| Layer | Amendments imposing a **new task** | Amendments imposing only a **restraint or a report** | Amendments imposing **nothing** |
|---|---|---|---|
| **Levels 0–4 (observer → specialist)** | **0** | 2 (B-09 disclose/record work type; B-27 never treat a beneficiary as a prospect) | 25 |
| **Level 5 member, no role** | **0** | 1 | 26 |
| **Coordinator / Sub-Role** | 3 (B-01 declare service hours; B-10 refer excess demand; B-05/B-06 record accrual and pro-rata) | 4 | 20 |
| **Primary role-holder** | 8 | 6 | 13 |
| **City / State / National** | 19 | 3 | 5 |

**[A] Result: no amendment in v1.3-B places a new task on a member below Coordinator level.** Every task lands on a role-holder or above, and the largest concentrations are at City level — which is deliberate, because §26.4 shows the City layer is where the fixed cost can actually be absorbed.

---

# 45. FINAL ADVERSARIAL AUDIT

**Method:** this section is written **against** the model above, not for it. Each of your fourteen attacks is run at full force. Where the model survives, the reason is stated. Where it does not, the failure is recorded as a finding rather than softened.

## 45.1 The fourteen attacks

### AD-01 · "What if people do not join?"
**Attack lands: YES — the model has no answer, and says so.**
`N_act` appears in every capacity and cost formula. If recruitment fails, `H_pool = 0`, `P_max = 0`, `V_gross = 0`, and the model correctly returns "not viable" — but it cannot tell you *why* people did not join.
**What survives:** §34 (dignity) and §15.3 (`T_be`) at least make the proposition testable rather than assumed, and §41 V1 requires that people *return*, which is a stronger test than that they join.
**What fails:** the model contains **no demand-for-membership analysis at all** — no study of why a person in a specific neighbourhood would give hours to this organisation rather than to a temple committee, a political cadre, a cricket team or a tuition centre. The stress test addressed this (§9 four doors; §10 core emotion) and v1.3-B inherits it without extending it.
**Finding AD-01:** *recorded as an open gap. The economic model cannot substitute for a proposition model.* Routed to §43 as a note against E-23: the pilot must measure **why** people joined and stayed, not only whether they did (P-06, P-14).

### AD-02 · "What if volunteers stop working?"
**Attack lands: PARTIALLY — the model anticipates it but cannot prevent it.**
§9.2 shows what continues (time-costed service), §15.3 shows the cost consequence, §29 Scenario 5 shows the spiral: `N_act` halves → `H_pool` halves → **but `H_gov` per head rises** because fewer people carry the same fixed load → `σ` exceeds `σ_max` → controls fail → PF-03 and PF-07 together.
**What survives:** B-08 measures whether the model is asking more than it returns (`T_be > T_actual`); B-16 Layer 1 and B-21 let a City absorb the load; §34.2 D-8 requires that some roles cease to be volunteerable.
**What fails:** **there is no instrument that adds hours.** Volunteer supply is exogenous. The model can measure the shortfall and share it; it cannot fill it.
**Finding AD-02:** *the honest limit of the model. Volunteer supply is a social fact, not a design parameter.* **[X]** external research is consistent: leading exit reasons are relocation and busyness — causes no management intervention removes.

### AD-03 · "What if customers do not come?"
**Attack lands: NO — the model handles this, and identifies the real reason it would happen.**
§7.4 and §18.3 locate demand origination at **City** level **[S: Ch.7]** — which means "customers do not come" is usually a *City capability* failure, not a team failure. §17.3 gives the response (B-11: raise `H_acq`, raise `H_svc`, do not cut price). §19 gives the selection framework so a team does not pursue a category its neighbourhood cannot buy.
**What survives:** the diagnosis is structural and testable — measure `N_lead` at City level (P-04, P-15).
**Finding AD-03:** *handled.* But note the corollary: **if the City has no pipeline function, every team fails this attack simultaneously** — which is §29 Scenario 12, the model's most severe finding.

### AD-04 · "What if customers come but do not pay?"
**Attack lands: YES — and this is the model's most quantitatively dangerous gap.**
§12.4 isolates it: work delivered → verified → compensation accrued → customer does not pay → `A_1 = 0`. §18.6 shows `Δt_collect` and the **unresolved receipts-vs-invoiced accounting basis [S: App. A §14.3; V]** decide whether workers are paid in the month they worked.
**What survives:** B-05 (accrual, aged, settled at priority 1 from the next collection), B-06 (fair scarcity rule), B-13 (advance/milestone terms, arrears cap, escalation), E-07 (decide the basis before the first invoice).
**What fails:** **none of these creates the money.** If a category's `r_collect` is structurally low in a locality, the venture is not viable and no instrument fixes it. B-13's cap simply stops the bleeding.
**Finding AD-04:** *mitigated, not solved.* `r_collect` and `Δt_collect` must be measured **per category per locality** (P-05) and used as a §19 gate-3 exclusion criterion. **A category whose collection behaviour is bad should not be entered at all.**

### AD-05 · "What if revenue exists but margins are poor?"
**Attack lands: NO — the model was built around this case.**
§11.4 makes `CM̄_j / h_proj` the operative metric rather than revenue; §19.4 exposes the tension that the *easiest* categories have the *lowest* contribution per hour; B-11 sets price floors; B-07(2) prevents growth bought by accepting worse work; §27.4 reports estimated-vs-actual hours so under-scoping is visible.
**Finding AD-05:** *handled, and handled early.* The model never uses revenue as a health measure (§28.2, B-22).

### AD-06 · "What if service demand is huge but business demand is tiny?"
**Attack lands: YES — and the model's answer is uncomfortable.**
This is §29 Scenario 10 and §32.2 position A/B. High service demand raises `H_gov` through verification (HC-08: "the needier the area, the higher the unfunded governance load") while contributing nothing to `V_gross`.
**What survives:** B-02 keeps service running in time-costed categories at zero cash; B-24 funds materials; §22 Layer 1 lets a *different* team's revenue capacity absorb this team's *people*; §32.4 says plainly that such a team **should be subsidised deliberately rather than accidentally**.
**What fails:** **the model cannot make such a team self-sustaining, and refuses to pretend otherwise.** §31.3 NL-10 is the reason: neighbourhood demand heterogeneity means an average-based plan is wrong everywhere.
**Finding AD-06:** *the model correctly identifies this as a funding decision, not a performance problem.* **This is the strongest argument for B-23's caveat and for E-12: high-need areas require a chosen subsidy, and the choice must be made at the top, not left to the team to fail at.**

### AD-07 · "What if business demand is huge but trained people are unavailable?"
**Attack lands: NO — the model anticipated it, with source support.**
§17.3 first asymmetry, B-10 capacity ceiling, and **[S: App. A §13.5]** "a venture scales only when it shows… **sufficient trained people**". §17.4 ranks trained delivery people as bottleneck #2 and §24.5 identifies leader/trainer supply as a *stock* problem.
**What fails:** nothing in the model *creates* trained people. §31.3 NL-2 states that formation rate is capped by trainer supply.
**Finding AD-07:** *handled as a constraint; unhandled as a supply problem.* B-10's referral mechanism is the only relief, and it works only if **another** team has the skill.

### AD-08 · "What if the leader is excellent but the team is weak?"
**Attack lands: PARTIALLY.**
§24.3 shows the promotion tax working in reverse: an excellent leader in a weak team produces good scores, gets promoted, and the weak team becomes weaker (§29 Scenario 4). B-18's successor-before-transition is designed for exactly this — **but there is no successor to name**, which is the definition of a weak team.
**What survives:** B-19 (interim authority with City fallback), B-16 Layer 1 (a capable team supports **[S: Ch.14 step 4]**), §24.5 (plan formation against leader supply).
**What fails:** the model has no instrument for **building** a weak team's second rank. That is a training-supply problem (NL-2) sitting outside unit economics.
**Finding AD-08:** *mitigated. The deeper issue is that the architecture rewards the leader and does not fund the bench.* Routed to E-11/E-23 as a note: the pilot must measure whether a **deputy** exists, not only whether a leader does (P-06, V6).

### AD-09 · "What if the team is excellent but the local market is poor?"
**Attack lands: YES — structurally, and this is the model's central admission.**
§19 criterion 1 and 5, §31.3 NL-10, §32.3 condition 3, AD-06. Excellence cannot manufacture payable demand.
**What survives:** B-14 Track 2 (enter higher-contribution categories **through the City pipeline**, selling beyond the neighbourhood while remaining rooted in it) and B-10 (take referred work from elsewhere). **This is the one genuine escape route the model contains: a team's *customers* need not be its *neighbours*.**
**Finding AD-09:** *partially solvable — but only if the City pipeline actually functions.* Which returns the argument to §7.4 and §29 Scenario 12. **The viability of a team in a poor market is a City-capability question.**

### AD-10 · "What if a city contains many economically weak Mohalla teams?"
**Attack lands: YES — and it inverts the density rule.**
§31.2 says viability is a function of `K`. But `K_min = (C_city + shared) / (CM̄_j × P_realistic − C_L1_local)` (§26.5): **when the denominator is small because every team is weak, `K_min` becomes very large** — the city needs *more* teams to afford the shared layer while being *less* able to form them.
**What survives:** B-23's caveat (a low-`K` high-need city may be opened **with an explicit subsidy decision**); B-16 Layer 1 (weak teams can still refer and share people even when they cannot share money); §22.4's sequencing.
**What fails:** **the model has no answer for a city that is uniformly poor.** Such a city cannot bootstrap. It requires external funding of `C_city` — which is E-03 at city scale.
**Finding AD-10:** *the most severe structural inequality in the model, and it is not fixable at unit level.* It is the economic form of the mission problem: **the places with the most need have the least capacity to pay for the organisation that would serve them.** Any honest national plan must fund those cities deliberately. §46.4 states this as a condition of the verdict.

### AD-11 · "What if the organisation grows faster than its governance capacity?"
**Attack lands: NO — the model is built to prevent exactly this.**
§31.3 NL-1/NL-2/NL-7; B-07 contribution-gated growth; B-23 density-first; §25.4's bands; §26.1's `σ_max`; §30's evidenced stages; §41.3's refusal to treat pilot success as scaling approval.
**Finding AD-11:** *handled.* The model's growth gates are all evidence-based and none is headcount-based, consistent with **[S: Ch.25]**.

### AD-12 · "What if central support becomes expensive?"
**Attack lands: YES.**
§8.6: the centre is funded at priority 5 — last and deferrable — while being spent from Phase 1. §31.1's `C_national`, `C_state`, `C_city` terms grow with structure, not with revenue. NL-1 (assurance must convert from examination to sampling) and NL-4 (platform as a step function) both add large discrete costs.
**What survives:** B-26 forces the funding map to name a source for every layer with **no blank cell**; E-03 makes the pre-revenue centre-funding decision explicit; §31.5 states what must exist at each scale.
**What fails:** **the model cannot fund the centre.** It can only make the requirement visible and unignorable.
**Finding AD-12:** *disclosed, not solved.* **This is why the verdict is D rather than B:** a viable unit model without a funded centre produces viable teams inside a collapsing organisation.

### AD-13 · "What if the business division becomes more powerful than the service mission?"
**Attack lands: PARTIALLY — and the architecture already resists it better than most.**
§35 I-01, I-02, I-07; §6.3's invisible cross-subsidy; §29 Scenario 9 (high revenue, poor service outcomes — "economically survivable, mission-fatal").
**What survives:** mission impact carries the **highest** performance weight, 20% vs business 15% **[S: Ch.25]**; B-01 makes the hour trade visible; B-22 refuses to reduce health to revenue; B-27 and §39 place whole categories beyond commerce permanently; §28.2's V-G4 truth veto.
**What fails:** **all of those are internal controls, and internal controls are only as strong as the person at the top.** If the founder concludes that revenue is the precondition of everything else — which §32 makes *economically arguable* — the weights will be revisited. **[S: Ch.33]** lists leaderboard weights as PROPOSED, so they are revisable.
**Finding AD-13:** *structurally resisted, constitutionally unprotected.* **Recommendation:** the 20% mission weight and the §39 never-monetised list should both be **Tier-1 candidates under v1.3-A A-13** — which is how E-21 is already framed. That is the only durable defence.

### AD-14 · "What if revenue becomes the real definition of success?"
**Attack lands: NO — this is the model's most deliberately defended position.**
Every instrument points the other way: six solvency lines rather than one revenue number (§8.3); eight dimensions plus four veto gates rather than a score (B-22); `CM̄_j / h_proj` rather than turnover (§11.4); outcome verification rather than activity counts **[S: Ch.15]**; the source's own explicit prohibition **[S: Ch.25 "Raw revenue… cannot determine leadership"; App. A §18.1 "Revenue alone is insufficient"]**; and §28.4's three questions, of which revenue answers one.
**Finding AD-14:** *handled.* And the reason it can be handled is that **the source already held this line.** v1.3-B did not have to invent the value; it only had to refuse to contradict it.

## 45.2 Attacks the brief did not list, run anyway

| ID | Attack | Result |
|---|---|---|
| **AD-15** | **What if the model itself is used as a business plan?** | **Real risk.** Mitigated by the classification discipline (six tags, no invented numbers, `[M-ill]` quarantine of the illustrative percentages) and by §1.5's five explicit refusals. **Residual:** a reader who skips the front matter will find tables and assume forecasts. §46.5 restates the warning at the end as well as the beginning |
| **AD-16** | **What if measuring `H_gov` is itself a governance burden?** | **Yes — P-01 is a time-and-motion study, which costs hours.** Disclosed in §40.4 as `C_measurement`, "usually forgotten". It is a one-time pilot cost, not a recurring one, and it is the cheapest decision-input available |
| **AD-17** | **What if the float creates a class of subsidised teams and an unsubsidised resentment?** | **Real risk** — G-15. Mitigated by publication of utilisation (B-04) and by the rule that float terms are identical for all teams in a stage. **Residual:** teams that did not need a float will resent those that did. This is a leadership-communication problem, not a design problem |
| **AD-18** | **What if `K_min` is larger than any realistic city?** | **Fatal if true, and unknowable now.** §26.5 gives the formula and P-15 gives the measurement. **If pilot data shows `K_min` exceeds achievable density, the architecture's Mohalla-level design is not deployable in ordinary neighbourhoods and must be re-cut — most likely by moving more functions upward, which is a structural change this document does not propose.** Recorded as the model's single largest falsifiable claim |
| **AD-19** | **What if the whole model is wrong because the venture categories are wrong?** | **Possible and undetectable from the source.** Fact 1: the blueprint was never attached. §7.1's difficulty ranking is **[A]**, not evidence. **§19's framework exists precisely so that the choice is made from local measurement rather than from this document's opinion** |
| **AD-20** | **What if a team is economically viable and institutionally illegitimate?** | **Answered by v1.3-A, not by this model.** §28.2's veto gates import v1.3-A's A-08, A-19, A-20 as economic vetoes — **so a profitable team that breaches a DO-NOT or publishes a beneficiary's story is, by construction, unhealthy.** That coupling is deliberate and is the main way v1.3-A and v1.3-B interlock |

## 45.3 Audit summary

| Attack | Landed? | Model's status |
|---|---|---|
| AD-01 no members | **YES** | Open gap — outside economic modelling |
| AD-02 volunteers stop | **PARTIAL** | Anticipated; cannot be prevented |
| AD-03 no customers | No | Handled — and diagnosed as a City-capability question |
| AD-04 no payment | **YES** | Mitigated (B-05/B-06/B-13/E-07), not solved |
| AD-05 poor margins | No | Built around it |
| AD-06 huge need, no market | **YES** | Correctly identified as a funding decision |
| AD-07 no trained people | No | Handled as a constraint; supply unhandled |
| AD-08 strong leader, weak team | **PARTIAL** | Mitigated; bench-building unfunded |
| AD-09 strong team, poor market | **YES** | One escape route (City pipeline / B-14 Track 2) |
| AD-10 uniformly poor city | **YES** | **Unsolvable at unit level — requires deliberate central funding** |
| AD-11 growth outruns governance | No | Gated throughout |
| AD-12 expensive centre | **YES** | Disclosed; E-03 unresolved |
| AD-13 business over mission | **PARTIAL** | Structurally resisted, constitutionally unprotected → Tier-1 recommendation |
| AD-14 revenue as success | No | Most defended position in the document |

**[A] Score: 5 attacks land fully, 3 partially, 6 are handled.** Every landed attack traces to one of two causes: **(i) an unfunded obligation the source never assigned a source to** (AD-04, AD-06, AD-10, AD-12), or **(ii) an exogenous social fact no design can create** (AD-01, AD-02, AD-07, AD-08, AD-09). **Not one landed attack is caused by a defect in the architecture's principles.** That is the most favourable finding available, and it is also the reason the verdict below is D-with-a-path rather than D-permanent.

---

# 46. FINAL RECOMMENDATION

## 46.1 THE ONE-PAGE ANSWER

> ### If we create one Sewak Sathi Mohalla Team tomorrow with real people, real expenses, real service work and real business activity — exactly what allows that team to survive its first six months, and what causes it to fail?

**WHAT ALLOWS IT TO SURVIVE — six things, in the order they matter:**

1. **One anchored, contracted revenue source signed *before* launch.** Not a pipeline, not a prospect — a signature. It is the only difference between scenario SC-A and SC-B (§13.4), and SC-B is the failure path.
2. **A float sized by formula, not by optimism:** `F_0 ≥ M_target × L_min` (§9.6), where `L_min` is the team's unavoidable monthly cash cost of existing. Capped, time-bound, reconciled, one renewal maximum, published (B-04). **This instrument does not exist in your architecture. Without it the runway is zero.**
3. **The City layer actually performing the functions it is already designed to perform** — verification, finance reconciliation, customer pipeline, materials, training, incident review, editorial **[S: Ch.7]**. This is the largest cost reduction available and it requires a *contract*, not new structure (B-21). **§3.3 proves the team cannot satisfy segregation of duties alone, so this is not optional.**
4. **A written compensation formula and an honest payment expectation, both delivered *before* recruitment** (§34.2 D-1, D-2; E-02). The first failure arrives in week 3, not month 3, and it is an expectation failure rather than a cash failure.
5. **A minimum viable control set** — eleven irreducible controls, everything else graduated in with maturity (B-20). At governance band GB-4 (§25.4) the full control set consumes a quarter of all available hours and the unit cannot exist.
6. **A service programme that costs time, not money** (B-02), so the mission visibly continues through the revenue trough — because the trough is certain, and legitimacy capital is the one input that cannot be bought back (§2.3).

**WHAT CAUSES IT TO FAIL — six things, in the order they arrive:**

1. **The first empty payment period,** experienced as a broken promise. This is the earliest and most common cause, and it is caused by *recruitment language*, not by revenue.
2. **The governance load** — 22 SOPs, 14 evidence types, 5 reporting cadences, a 10-step operating loop, a 12-step service loop and a 13-step payment cycle **[S]** — subtracted *first* from the same hour pool as delivery and sales (§17.2). `H_gov` does not fall when revenue falls (§9.4).
3. **The three control roles** (HR/Verification, Funds, Safety) carried by the same few people who must also deliver and sell, and who pay a social price for saying no to their neighbours (§25.5, HC-18) — while **[S: Ch.18]** forbids combining the four finance hands.
4. **Lumpy revenue against a fixed cadence** — collection lag, one non-paying customer, one revision loop (§12.4, §18.6, AD-04). Verified work goes unpaid and the claim silently disappears because priority 1 has no memory across periods.
5. **The first shock** — an incident, a broken tool, an emergency transport need, an unexpected material cost — meeting an empty reserve, because reserves sit at priority 6 and fill last (§8.5). The cost is then met from a member's pocket (HC-03), which creates debt inside the team.
6. **Then the people who leave are exactly the people you needed** — the paid deliverers, who have alternatives, and the control role-holders, who are exhausted. Research puts relocation and busyness at the top of stated exit reasons **[X]**, so this churn is irreducible.

**THE ONE SENTENCE:** *the team survives if its fixed costs are shared upward, its first revenue is contracted rather than hoped for, its runway is funded rather than assumed, and its members are told the truth before they join — and it fails if any one of those four is left to optimism.*

## 46.2 REQUIRED FINAL VERDICT

> # **D — NOT YET ECONOMICALLY VIABLE**
> ### with a defined, testable path to **B — VIABLE WITH CONDITIONS**

**[A] Why D and not C.** C asserts "viable only with subsidy" — which claims that a subsidy would make it work. **The source contains no subsidy instrument to evaluate:** no float, no seeded reserve, no central operating budget, no cross-subsidy mechanism, and the social-impact fund is expressly barred from operating cost and venture bailouts **[S: Ch.20]**. The organisation service fee that would fund the centre sits at priority 5, downstream of everything (§8.6). So the accurate statement is not "it needs a subsidy" but **"it needs an instrument that has not been designed, approved, costed or validated."**

**[A] Why D and not A or B.** A is unavailable: §32.3 shows a standing-start team cannot reach `B_healthy` without four conditions outside its own control. B requires the conditions to *exist*, and five of the six (§2.5) do not yet:

| §2.5 condition | Status today | Instrument that would satisfy it |
|---|---|---|
| 1. `H_gov` measured and below `σ_max` | ❌ unknown — the 8–40 band is untested (§25.4) | Pilot P-01 |
| 2. A category whose contribution per delivery hour exceeds fully-loaded cost | ❌ unknown — **the blueprint was never attached** (Fact 1) | Pilot P-02/P-03; §19 framework |
| 3. A cold-start instrument exists, capped, time-bound, reconciled | ❌ **does not exist** | **B-04 + B-03** |
| 4. Governance shared at City level across `K ≥ K_min` | ❌ roles exist **[S: Ch.7]** but no entitlement is stated | **B-21**; P-15 measures `K_min` |
| 5. Payment cadence matches collection reality, disclosed before joining | ❌ weekly cycle vs lumpy revenue; basis unresolved **[V]** | **E-07, E-09, B-13, §34.2 D-1/D-2** |
| 6. Service continues at ₹0 without consuming cash | ⚠️ possible for categories 1–3 only (§6.4) | **B-02 + B-24** |

**Zero of six are satisfied today. Two are unknown-but-measurable, three require a new instrument, one requires a decision.** That is the definition of "not yet".

## 46.3 What must change for the verdict to become B

**[P]** Six changes, in dependency order. **None alters a principle, a hierarchy, a role, a waterfall priority or a constitutional article.** All are additive.

| # | Change | Instrument | Why it is first |
|---|---|---|---|
| **1** | **Decide who funds the centre before priority-5 income exists** | E-03, B-26 | Everything else is a local instrument; this is the one that has no local answer (§8.6, AD-12) |
| **2** | **Write and approve the compensation formula, the payment cadence and the accounting basis — before recruiting anyone** | E-02, E-07, E-09; §34.2 D-1/D-2 | The first failure is an expectation failure (§46.1) and it is irreversible |
| **3** | **Create the cold-start instruments: float and seeded reserve** | B-04, B-03 | Without them `M_runway = 0` (§9.6) and reserves arrive too late (§8.5) |
| **4** | **Contract the City shared-services layer in writing** | B-21; measure `K_min` (P-15) | It is the largest cost lever (§26.4) and a control requirement, not a convenience (§3.3) |
| **5** | **Adopt the minimum viable control set and measure `H_gov` honestly** | B-20, §25, P-01 | If `σ > σ_max` no revenue level saves the unit (§25.4) |
| **6** | **Adopt the worker-protection instruments and the mission-protection instruments together** | B-05, B-06, B-13 / B-01, B-02, B-22, B-27, §39 | Change 6 must be adopted *with* the revenue instruments, not after — otherwise §29 Scenario 9 is the outcome |

**[A] If all six are done, the classification becomes B — VIABLE WITH CONDITIONS**, where the conditions are the four in §32.3: `H_gov` in band GB-1…GB-3; `K ≥ K_min`; neighbourhood payable demand sufficient for `P_max × CM̄_j ≥ B_healthy`; and survival of months 1 to `M_target` on the float.

**[A] If changes 1–4 are done but 5 and 6 are not, the classification becomes C — VIABLE ONLY WITH SUBSIDY**: the team survives on injection while its governance load and mission balance erode unsupervised.

**[A] If the pilot measures `H_gov` in band GB-5/GB-6, or `K_min` beyond achievable density (AD-18), the classification cannot rise above D at Mohalla level and the architecture requires a structural change this document does not propose** — most plausibly moving more functions permanently upward, which is a decision for the founder and the Council, not for a model.

## 46.4 The condition nobody wants to hear

**[A]** §45 AD-06 and AD-10 produced the finding that the model cannot soften:

> **The neighbourhoods with the greatest need have the least payable demand, and therefore the least capacity to fund the team that would serve them.** Governance cost per team is roughly constant; revenue capacity per team varies by an order of magnitude (§14.2, §31.3 NL-10). `K_min` rises as the denominator falls (§26.5). So a uniformly poor city needs *more* teams to afford its shared layer while being *less* able to form them.

**This is not a design flaw. It is a property of the mission.** An organisation that exists to serve people who cannot pay cannot be funded by those people. **[S: App. A §1.1]** already accepts half of this — "The organisation is not merely a donation-funded charity; legitimate business is part of the design" — and the venture model is the right answer *where a market exists*.

**[P] Therefore the recommendation is explicit:** the organisation should decide, in advance and in public, **which localities it will serve on a deliberately subsidised basis**, and fund them from a named source (B-26's map, E-12's instrument) — rather than forming teams in those localities and discovering the subsidy informally, through unpaid members, personal spending and quiet mission failure. **A chosen subsidy is a strategy. An unchosen one is a slow failure that blames the team.**

## 46.5 Final statements

**[A] What this document is:** a model. Every number in it is source-derived, calculated from a stated formula, a named variable awaiting measurement, or a labelled scenario. **It contains no forecast, no projection, no budget and no rupee amount that is not explicitly marked illustrative and quarantined.**

**[A] What this document is not:** a business plan, a fundraising document, or evidence that the organisation will succeed. It is evidence about **what must be true** for it to succeed, and about **which of those things are currently unknown**.

**[P] The recommended next action is not another document.** It is **decision E-23: design and cost the one-team pilot of §40**, with its fifteen measurements (P-01…P-15) funded and owned, its locality chosen for measurability rather than impressiveness, and its failure conditions (§42) published before it starts. The pilot's purpose is not to prove the model right. **Its purpose is to replace the 8–40 governance band, the unknown `CM̄_j`, the unknown `K_min` and the unknown `r_collect` with four real numbers — after which every verdict in this document can be recomputed rather than argued.**

**[A] And the closing observation, which is the reason v1.3-B exists:**

> v1.3-A protected the organisation from institutional failure. It did so thoroughly, and it assumed — necessarily — that there was an organisation to protect.
>
> **This document's answer is that there is not yet one at the Mohalla level, and that the reason is specific, nameable and fixable: five missing financial instruments, one missing funding decision, and four unknown numbers.**
>
> The architecture's principles survived every attack in §45. Not one landed attack was caused by a defect in what the organisation believes. **They were all caused by what it has not yet built.** That is the most encouraging finding in this document, and it is also a deadline: the instruments are cheap now and expensive after the first team has already failed without them.

---

# ANNEXURE A — VARIABLE DICTIONARY

**Every variable used in this document. No value is assigned to any of them here.**

## People and time

| Variable | Meaning | First used |
|---|---|---|
| `N_ver` | Verified members on roll | §3.2 |
| `N_act` | Members who actually contributed in the month | §14.3 |
| `r_act` | Active ratio `N_act / N_ver` | §14.3 |
| `N_roles` | Roles and sub-roles filled | §3.3 |
| `N_roles_min` | `⌈f / c⌉`, minimum role-holders | §3.3 |
| `f` | Functions that must exist in State A = **9 [S]** | §3.3 |
| `c` | Maximum compatible functions per person | §3.3 |
| `N_paid` | Members performing paid venture work | §14.2 |
| `N_skilled` | Members holding the active venture's skill | §27.5 |
| `N_apps`, `N_trainees`, `N_retrain` | Applications; trainees; re-certifications | §25.1 |
| `T_avail` | Hours available per active member per month | §2.1 |
| `T_tenure` | Average member tenure in months | §15.3 |
| `h_month` | Hours contributed per member per month | §15.3 |
| `r_ret` | Retention rate | §15.3 |
| `r_attendance` | Attendance rate | §15.3 |

## Hours

| Variable | Meaning | First used |
|---|---|---|
| `H_pool` | Total available hours `N_act × T_avail` | §2.1 |
| `H_gov` | Total governance hours | §4.3 |
| `H_gov_fixed` / `h_gov_var` | Fixed and per-head governance components | §14.2 |
| `σ` | Governance share `H_gov / H_pool` | §25.1 |
| `σ_max` | Maximum sustainable governance share | §26.1 |
| `H_svc`, `H_svc_budget` | Service hours; declared budget (B-01) | §6.3 |
| `H_deliver` | Hours remaining for delivery | §17.2 |
| `H_acq` | Acquisition and sales hours | §18.2 |
| `H_train` | Training hours | §17.2 |
| `h_proj`, `h_qa`, `h_rev`, `h_dispute` | Hours per project, QA, revision, dispute | §5, §17 |
| `g_*` | Governance coefficient per driver (`g_hr`, `g_ver`, `g_fin`, `g_lead_fix`, `g_dec`, `g_plan`, `g_audit`, `g_doc`, `g_inc`, `g_coord`, `g_esc`, `g_comp`, `g_dp`, `g_grant`, `g_train`, `g_cycle`, `g_rep_*`) | §4.3, §25.1 |

## Revenue and projects

| Variable | Meaning | First used |
|---|---|---|
| `P_projects`, `P_delivered`, `P_max`, `P_be` | Projects proposed, delivered, maximum capacity, break-even volume | §11.4, §17.2 |
| `P_price` | Price per project | §7.2 |
| `V_gross`, `V_invoiced`, `V_collected`, `V_capacity` | Revenue measures | §7.2, §18.6 |
| `V_req`, `V_req_total` | Required revenue (waterfall); required revenue (total incl. `C_L1`) | §10.1 |
| `N_cust`, `N_lead` | Customers; leads | §18.1 |
| `r_lead`, `r_qualify`, `r_prop`, `r_close`, `r_accept`, `r_collect`, `r_repeat`, `r_referral` | Funnel rates | §18.1 |
| `Δt_collect` | Collection lag in days | §18.6 |
| `CM_j`, `CM̄_j` | Contribution per project; average | §11.4 |
| `K_startup`, `H_startup` | Venture startup cash and hours | §7.2 |

## Costs

| Variable | Meaning | First used |
|---|---|---|
| `C_L1`, `C_L2_share`, `C_L3`, `C_L4` | Existence, capability, activity, shock cost layers | §4.4 |
| `L_min` | Minimum unavoidable monthly cash cost | §9.6 |
| `C_fixed`, `C_var` | Fixed; direct/variable costs | §4.4, §8.2 |
| `C_wc`, `C_lead`, `C_stat`, `C_spec`, `C_temp` | Compensation lines | §4.1 |
| `C_trans`, `C_trans_em`, `C_comm`, `C_net`, `C_space`, `C_equip`, `C_mat`, `C_print`, `C_id`, `C_train`, `C_meet`, `C_doc`, `C_sw`, `C_ai`, `C_acct`, `C_pay`, `C_acq`, `C_log`, `C_emg`, `C_ins`, `C_legal`, `C_comp` | Operating cost lines OC-01…OC-22 | §4.2 |
| `C_vol_total`, `C_vol_per_hour`, `C_replace`, `C_recruit`, `C_verify`, `C_coord`, `C_supervise`, `C_retain`, `C_admin`, `C_opportunity` | Volunteer cost components | §15.2 |
| `T_be` | Break-even tenure for a volunteer | §15.3 |
| `CAC` | Customer acquisition cost | §18.2 |
| `C_svc_cash`, `C_svc_total` | Service cash cost; total service cost | §10.1, §33 |
| `E_shock` | Expected monthly shock cost | §11.2 |
| `C_city`, `C_state`, `C_national`, `C_team_local` | Layer costs | §31.1 |
| `C_pilot`, `C_formation`, `C_measurement` | Pilot cost terms | §40.4 |
| `C_failure_support` | Cost of supporting a failing team | §23.2 |
| `θ_pay` | Payment-processing charge per transaction | §4.2 |

## Waterfall, reserves, runway

| Variable | Meaning | First used |
|---|---|---|
| `R_1 … R_8` | Requirement at each priority | §8.3 |
| `A_1 … A_8` | Allocation at each priority | §8.3 |
| `S_0 … S_8` | Residual after each priority | §8.3 |
| `w_worker`, `w_direct`, `w_org` | Illustrative shares — **[M-ill] only** | §8.8 |
| `ρ` | Reserve contribution rate | §8.5 |
| `m_lead` | Leader multiplier — **UNRESOLVED [S]** | §4.1 |
| `M_cov`, `M_to_buffer`, `M_runway`, `M_target` | Reserve coverage months; time to build buffer; runway; float term | §8.5, §9.6 |
| `F_0` | Seeded float at formation | §9.6 |
| `Reserve_months` | Reserve adequacy in months | §21.5 |
| `K`, `K_min`, `K_target`, `K_shared` | Teams per city; minimum; target; sharing divisor | §26.5, §31.2 |
| `T`, `C`, `S` | Teams, cities, states | §31.1 |
| `n`, `n_consecutive`, `n_of_m` | Approved period counts — **[M]** | §23.4 |

---

# ANNEXURE B — FORMULA SHEET

| # | Formula | Class | Section |
|---|---|---|---|
| **F-01** | `N_act × T_avail = T_gov + T_del + T_acq + T_svc + T_train + T_idle` | **[C]** | §2.1 |
| **F-02** | `N_roles_min = ⌈f / c⌉`, `f = 9` **[S]** | **[C]** | §3.3 |
| **F-03** | `H_gov = Σ GC-01…GC-13` (expanded in §25.1) | **[C]** | §4.3, §25.1 |
| **F-04** | Waterfall sequence: `A_i = min(R_i, S_(i-1))`; `S_i = S_(i-1) − A_i` | **[C]** | §8.3 |
| **F-05** | Six solvency lines S-1…S-6 | **[C]** | §8.3 |
| **F-06** | `M_to_buffer = M_cov × (C_fixed + C_gov) / (ρ × S̄_5)` | **[C]** | §8.5 |
| **F-07** | `M_runway = (F_0 + Reserve_available − L_min) / Burn_net`; at ₹0, `M_runway = F_0 / L_min` | **[C]** | §9.6 |
| **F-08** | `F_0 ≥ M_target × L_min` | **[C]** | §9.6 |
| **F-09** | `V_req = R_1 + R_2 + R_3 + R_4 + R_5 + R_6*`; `V_req_total = V_req + C_L1 + C_L2_share + C_svc_cash` | **[C]** | §10.1 |
| **F-10** | `B_bare = L_min` | **[C]** | §11.2 |
| **F-11** | `B_healthy = C_wc + C_stat + C_var + C_L1 + C_L2_share` | **[C]** | §11.2 |
| **F-12** | `B_growth = B_healthy + R_5 + C_growth` | **[C]** | §11.2 |
| **F-13** | `B_resilient = B_growth + ρ × S_5 + E_shock` | **[C]** | §11.2 |
| **F-14** | `CM_j = P_price_j − C_var_j − C_wc_j − C_stat_j`; `P_be = (C_L1 + C_L2_share + C_fixed_gov) / CM̄_j` | **[C]** | §11.4 |
| **F-15** | `C_vol_per_hour = C_vol_total / (T_tenure × h_month × r_attendance)` | **[C]** | §15.3 |
| **F-16** | `T_be = C_vol_total / (h_month × r_attendance × value_per_hour)` | **[C]** | §15.3 |
| **F-17** | `H_deliver = H_pool − H_gov − H_svc − H_acq − H_train − H_idle` | **[C]** | §17.2 |
| **F-18** | `P_max = H_deliver / (h_proj + h_qa + h_rev_expected)` | **[C]** | §17.2 |
| **F-19** | `V_capacity = P_max × P_price × r_accept × r_collect` | **[C]** | §17.2 |
| **F-20** | `CAC = (C_acq_cash + H_acq_total × cost_per_hour) / N_cust_new` | **[C]** | §18.2 |
| **F-21** | `σ = H_gov / (N_act × T_avail)`; `σ_max = 1 − (H_deliver_req + H_svc_budget + H_acq_req + H_train_req) / H_pool` | **[C]** | §25.1, §26.1 |
| **F-22** | `H_gov_per_team(K) = H_gov_fixed / K_shared + H_gov_local` | **[C]** | §26.4 |
| **F-23** | `K_min = (C_city + C_L1_fixed_shared) / (CM̄_j × P_realistic − C_L1_local)` | **[C]** | §26.5 |
| **F-24** | `Reserve_months = Reserve_balance / (C_L1 + C_gov_cost)` | **[C]** | §21.5 |
| **F-25** | `C_failure_support = H_support × cost/hr + C_train + C_specialist + T_improve × (C_L1 + C_gov) + C_diag + C_decision` | **[C]** | §23.2 |
| **F-26** | `C_per_team(T,K) = C_team_local + (C_city + C_state/S_per_city + C_national/T) / K` | **[C]** | §31.2 |
| **F-27** | `C_pilot = C_formation + M_measure × C_L1 + C_city_pilot + C_capability + C_float + C_measurement − V_collected_pilot` | **[C]** | §40.4 |
| **F-28** | Pilot success: `V4 ∧ V5 ∧ ¬veto ∧ (≥4 of {V1,V2,V3,V6,V7})` | **[C]** | §41.2 |

---

# ANNEXURE C — CONSOLIDATED [V] REGISTER (economic)

Grouped by discipline so one instruction can be issued to each. Complements v1.3-A Annexure B; items already listed there are cross-referenced, not repeated.

| # | Professional | Questions | Source item |
|---|---|---|---|
| **EV-1** | **Accountant / auditor** | Gross-revenue basis: receipts vs invoiced (E-07); accrued-compensation treatment (B-05); float characterisation — advance, loan, grant or deferred income (B-04); seeded-reserve accounting (B-03); direct-cost attribution rule (E-16); materials allocation treatment (B-24) | §8.2, §12.4, §9.6 |
| **EV-2** | **Tax counsel** | Tax treatment of each revenue category; GST/indirect tax on services; 12A/80G conditions and the effect of any commercial activity; donation deductibility and cash limits; FCRA eligibility and timing; tax on member payments | §7.1, §33.2 **[X]** |
| **EV-3** | **Employment / labour counsel** | Worker classification (E-C2); lawfulness of pro-rata partial payment (B-06); minimum-wage and timely-payment obligations; whether accrued unpaid compensation creates a wage debt; volunteer status and its limits; trainee-time eligibility | §12.5, §12.4, §16.3 |
| **EV-4** | **Corporate / entity counsel** | Authority to advance funds, hold reserves, operate bank mandates; entity form (E-C1); whether a Mohalla team can hold any balance at all | v1.3-A N15/N16; §21 |
| **EV-5** | **Insurance broker** | Whether any cover exists for venture delivery, professional indemnity on client work, member injury, third-party injury, cyber, and trustee liability — v1.3-A A-10 L1–L15 | §4.2 OC-20 |
| **EV-6** | **Competition / commercial counsel** | Price floors (B-11); contract enforceability, interest and consumer law (B-13); sponsorship and naming rights (§39.3); exclusion of liability for venture work | §17.3, §18.6 |
| **EV-7** | **Privacy counsel / DPO** | Whether any economic measurement creates new personal data (P-06 workload per person; P-13 payment continuity; B-08 cohort data); retention of financial records; DPIA triggers for any profiling | v1.3-A A-17/A-18; §27.3 |
| **EV-8** | **Safeguarding specialist** | Certified supervision requirements for education with minors and for food handling — which set a cost floor that cannot be volunteered away | §33.1, §40.2 |
| **EV-9** | **Sector regulators** | Category 7 licensing (health, safety, tax, liability **[S: Ch.17]**); category 5 trainer competence and safeguarding; category 2 data-processing limits | §7.1 |
| **EV-10** | **Banking / payments** | Mandate continuity and minimum signatories (v1.3-A N16); payment-processing costs at weekly cadence; collection instruments for SME customers | §4.2 OC-16, HC-17 |

---

# ANNEXURE D — EXTERNAL SOURCES CITED ([X])

Cited only where an external fact is referenced. **No economic, legal or tax conclusion is drawn from any of them in this document; each requires confirmation by a qualified professional for the actual entity, activity and jurisdiction [V].**

1. **Indian not-for-profit forms and tax treatment** — trust / society / Section 8 company compared on founders, credibility, compliance burden, liability and amendability; **12A** exemption conditional on application of income to charitable purposes **and on the absence of political activity or support to any party or candidate**; **80G** donor deduction with cash-donation limits; **FCRA** generally requiring a multi-year track record and a dedicated account before foreign contribution may lawfully be received. Cited at §31.3 NL-5 and §33.2. *(incorpx.io; legalsuvidha.com; taxaj.com; ebizfiling.com; setindiabiz.com)*
2. **DPDP Act 2023 / DPDP Rules 2025 (India)** — breach notification to the Board without delay and a detailed report within 72 hours; separate CERT-In incident reporting within 6 hours; Significant Data Fiduciary obligations attaching at scale (India-based DPO, DPIA, independent data auditor, annual assessment); substantial financial penalties. Cited at §31.3 NL-5/NL-9 and §42 PF-10. *(ey.com; ssrana.in; complyzero.com; lexology.com)*
3. **Volunteer attrition and retention research** — leading stated exit reasons include relocation (~26%) and school/work busyness (~38%), with programme issues only ~5%; first-year retention is weakest; recognition and awards correlate with materially lower turnover (roughly 6% vs 15% in one sample; odds of staying ~1.43×); exit and stay interviews are the top-rated interventions; training alone did not improve retention in one sample. Cited at §5.1, §15.4, §24.5, §29 Scenarios 3 and 5, §41 V1. **Non-Indian or single-programme studies — used for human regularities, not Indian magnitudes.** *(PMC10078732; nvfc.org; naturalhazards.com.au; scholarworks.indianapolis.iu.edu; givebutter.com)*
4. **India Stack scale** — Aadhaar near-universal adult enrolment; UPI transaction volumes; DigiLocker user base; persistent rural–urban and gender digital divides; and the observation that newer digital public infrastructure struggles with *sustained* adoption despite scale. Cited only as context for payment-rail feasibility and for the proposition that **reach is easier than sustained use** — which is the adoption analogue of this document's finding that forming a team is easier than sustaining one. *(Wikipedia India Stack; Economic Survey citations; DPI reviews)*
5. **Bharatiya Nagarik Suraksha Sanhita, 2023** — cited in v1.3-A and referenced here only at §38.1, where the emergency-assistance category is concerned. **No economic instruction is derived from it.** *(indiacode.nic.in; legalserviceindia.com)*

---

# ANNEXURE E — CONSISTENCY VERIFICATION AGAINST v1.2, v1.3-A AND THE STRESS TEST

| Check | Result |
|---|---|
| Any v1.2 chapter, article, SOP, table or rule deleted, renumbered or reworded? | **No.** All 27 amendments are additive or appendment-based |
| Waterfall priority order altered? | **No.** Reproduced verbatim from **[S: Ch.18; App. A §14.2]** and used as the model's engine (§8.1). B-03 and B-05 *pre-fund* and *extend across periods*; neither re-orders |
| Illustrative percentages adopted as policy? | **No.** 37.5 / 17 / 12 appear only in §8.8, marked **[M-ill]**, with the source's own warning quoted beside them |
| Performance weights altered? | **No.** 20/15/15/15/10/10/10/5 remain **PROPOSED [S: Ch.25; Ch.33]**; B-18(4) changes only *reporting* of a transition effect and is flagged for approval |
| Any rupee amount invented? | **No.** Every quantity is a variable, a formula, a scenario, or a source citation. The only rupee-denominated expressions are symbolic |
| Any revenue, donation, customer or volunteer availability assumed? | **No.** §9 models ₹0 explicitly; §10 models eight labelled scenarios; §41 leaves every threshold `PROPOSED` |
| Any survival period invented? | **No.** `M_runway` is computed from stated assumptions (§9.6); `M_target` is a decision routed to E-05 |
| Any UNRESOLVED v1.2 item closed? | **No.** All twelve financial items are carried forward unchanged in §43.1 |
| Any v1.3-A amendment rewritten or contradicted? | **No.** v1.3-A is extended: A-13 Tier-1 gains candidates (§39, E-21); A-14's pattern is applied locally (B-19); A-19/A-20 become economic veto gates (§28.2); A-17/A-18/A-21 constrain economic measurement (§27.3, EV-7); A-04's refusal posture is reused for commerce (§38.2 rule 6) |
| v1.3-A's burden rule respected? | **Yes.** §44.29 re-runs the test: **no amendment places a new task on a member below Coordinator level** |
| Any tactical, legal, tax or insurance conclusion asserted? | **No.** All appear as questions with **[V]** or as cited external facts with **[X]** |
| Source terminology preserved? | **Yes** — Mohalla/City/State/National Team, Head Team, Verified Member, Supporting Member, Coordinator, Sub-Role, Primary Role, Starter/Growing/Full Team, Funds Manager, AI & Business Manager, Safety/Protection Lead, HR & Verification Manager, Ground-Level Manager, Volunteer Manager, Planner, Editor, Social Media Manager, Warehouse Manager, venture revenue account, distributable funds, direct costs, statutory obligations, organisation service fee, wage-protection buffer, social-impact fund, residual surplus, autonomy readiness gate, vacancy statuses, RBAC, status labels |
| Any optimistic startup projection presented as fact? | **No.** §1.5 refuses it explicitly; §10.4 forbids presenting a scenario as a projection; §46.5 restates the warning at the end |
| Does the model recommend dissolving an underperforming team? | **No.** §23 applies the source's support-first philosophy **[S: Ch.14]** and its own stopping rule **[S: App. A §14.5]**, and distinguishes venture closure from team closure (§23.3) |
| Is the verdict derived from the model rather than from ambition? | **Yes.** §46.2 scores the six §2.5 conditions: **zero satisfied today**, two measurable, three requiring new instruments, one requiring a decision |

---

*End of v1.3-B. Costed Mohalla unit economics and economic survival model. No element of v1.2 or v1.3-A was removed, renumbered or silently altered. No financial figure was invented. Every proposal is marked `PROPOSED` and requires approval by the Founder/CEO under **[S: Const. Art.18]**, and professional validation wherever marked **[V]**.*
