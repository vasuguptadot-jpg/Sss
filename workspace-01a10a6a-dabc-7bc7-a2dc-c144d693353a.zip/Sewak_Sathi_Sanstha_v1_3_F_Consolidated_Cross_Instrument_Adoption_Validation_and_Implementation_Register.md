# SEWAK SATHI SANSTHA v1.3-F
# MASTER ARCHITECTURE → PILOT BRIDGE
# CONSOLIDATED CROSS-INSTRUMENT ADOPTION, VALIDATION & IMPLEMENTATION REGISTER

| | |
|---|---|
| **Instrument** | v1.3-F — the consolidation and execution-readiness instrument. **Sixth and terminal document of the v1.3 sequence** |
| **Type** | **REGISTER, NOT THEORY.** This document proposes no new organisational architecture, no new amendment, no new rule, no new measurement and no new body. It consolidates, sequences, de-duplicates and audits what v1.2 and v1.3-A/B/C/D/E already contain |
| **Question answered** | **Exactly what must now be DECIDED, PROFESSIONALLY VALIDATED, BUILT, IMPLEMENTED, MEASURED, TESTED, FUNDED, DOCUMENTED and DEMONSTRATED before Sewak Sathi Sanstha can move from architecture → controlled pilot → proven local institution → controlled expansion?** |
| **Source corpus** | **(1)** v1.2 `…v1_2.pdf` 179 pp. incl. Appendix A (v1.1 preserved) — **PRIMARY**; **(2)** v1.3-A Institutional Survival, Legitimacy & Critical Decision Architecture (318,492 B); **(3)** v1.3-B Economic Viability / Zero-Capital Local Venture Ecosystem (475,834 B); **(4)** v1.3-C Human System / Mass Participation / Adoption (432,762 B); **(5)** v1.3-D Leadership, Succession & Performance (725,675 B); **(6)** v1.3-E National Identity, Communication, Reputation & Mass Adoption (744,543 B) |
| **Authority of the corpus** | The source corpus is **authoritative** for terminology, existing decisions, unresolved decisions, amendment IDs, validation requirements, rules, gates, contradictions and verdicts. **Where this document and a source instrument differ, the source instrument governs — except where a source instrument mis-cites another, in which case the mis-citation is recorded at §0.3 and the *original* source governs** |
| **What this document does not do** | It does not redesign v1.2 or v1.3-A/B/C/D/E. It does not resolve an unresolved question because one answer seems better. It does not invent numbers, thresholds, budgets, staffing requirements, membership targets, growth rates, conversion rates, rupee values, percentages, legal conclusions, ownership arrangements or pilot success rates. It does not convert a recommendation into a decision, an assumption into a fact, or an architectural rule into evidence of real-world effectiveness |
| **Document status** | `CONSOLIDATION REGISTER — PROPOSED`. Nothing here is an approval, a decision, a validation or a finding of readiness |
| **Prepared** | 5 October 2026 |

---

## 0.1 The four states, and why they are not interchangeable

**[A]** The absolute rule of this instrument. Four states exist and are frequently confused:

```
STATE 1  WRITTEN ARCHITECTURE
         A rule, structure, register, formula or protocol exists on paper.
         Cost: authorship.  Proof value: ZERO about the real world.
              |
              v
STATE 2  OPERATIONAL READINESS
         A named human owns it, a mechanism exists to perform it, a record
         is produced by performing it, and an audit method can check it.
         Cost: implementation.  Proof value: that it CAN be done.
              |
              v
STATE 3  PILOT EVIDENCE
         It was done, by real people, on real problems, for long enough to
         produce a measurement, and the measurement was recorded and verified.
         Cost: time and people.  Proof value: that it WAS done, HERE, ONCE.
              |
              v
STATE 4  INSTITUTIONAL PROOF
         It was done repeatedly, in materially different contexts, survived
         adverse conditions, was independently verified, and corrected itself
         when it failed.
         Cost: years and scale.  Proof value: that it GENERALISES.
```

**[A]** Every one of the six source instruments ends at **State 1** and reports a verdict of **D — NOT YET PROVEN**. That is not a criticism of them; it is the correct verdict for a document. **The error this instrument exists to prevent is reading a State 1 artefact as though it were State 3 evidence.**

**[P] Rule F-1 (No State Promotion Without Evidence).** No item may be described as ready, working, proven, validated or effective at a state above the highest state for which evidence exists in the corpus. **A written policy is State 1. An owned, performed, recorded and auditable mechanism is State 2. A measurement from the pilot is State 3. Multi-context, independently verified, self-corrected operation is State 4.**

**[P] Rule F-2 (Completeness Is Not Readiness).** The corpus is complete enough to test. **It is not ready to test.** The distinction is the entire subject of this document, and Part XVIII exists to enforce it.

## 0.2 The lifecycle state machine

**[P]** Every actionable item is mapped through this lifecycle **where applicable**. Where a stage is skipped, the reason is recorded — because a skipped stage is either a genuine inapplicability or an unnoticed gap, and the two look identical unless the reason is written down.

```
UNRESOLVED DECISION
      |
      v
PROFESSIONAL / LEGAL VALIDATION
      |
      v
BUILD / IMPLEMENT
      |
      v
PILOT TEST
      |
      v
EVIDENCE REVIEW
      |
      v
PASS / MODIFY / BLOCK
      |
      v
EXPANSION ELIGIBILITY
```

**[P] Rule F-3 (Permitted Stage Skips, With Reasons).** A stage may be skipped only for one of the five recorded reasons below. **Any other skip is a gap.**

| Skip | Reason code | Example |
|---|---|---|
| **No decision required** | `SKIP-ND` — the source has already decided it | The waterfall priority order **[S: Ch.18]** is APPROVED; nothing to decide |
| **No external validation required** | `SKIP-NV` — the item is internal policy with no legal, tax, safety or privacy dimension | The category-sentence register; a correction log's format |
| **Nothing to build** | `SKIP-NB` — the item is a discipline on existing activity, not a new mechanism | Rule E-9's prohibited emotional registers; the attribution grammar |
| **Not testable at pilot scale** | `SKIP-NT` — recorded with its minimum population, never approximated | **[S-D: LM-8, LM-10]**; **[S-E: CI-3, CI-4, CI-5, CI-10, CI-13]** |
| **No expansion consequence** | `SKIP-NE` — the item does not gate any scale transition | A local recognition ritual form |

## 0.3 Cross-document provenance defects found by this consolidation

**[A]** The brief requires exact provenance. Consolidating 3.1 MB across six instruments surfaced **seven** genuine inconsistencies. **None is corrected silently; each is recorded with its exact location, and the *original* source governs.**

| # | Defect | Where it occurs | Original source | Correct position | Effect |
|---|---|---|---|---|---|
| **PD-1** | **Pilot measurement count understated by one** | **[S-D]** cites `B-P-01…B-P-14` **4×**; **[S-E]** cites `B-P-01…B-P-14` **3×** | **[S-B: §40]** defines **`P-01 … P-15`** — fifteen measurements | **The pilot has 60 measurements across four instruments, not 59.** P-15 = "`C_city` actual — what the City layer cost to run for one team" | **Material.** P-15 is the measurement that prices the City layer, and it was dropped from both downstream citation sets. Part IX restores it |
| **PD-2** | **Prefix `B-P-nn` does not exist in v1.3-B** | Created by **[S-D: Rule D-129]** to disambiguate v1.3-B's `P-nn` from v1.3-D's own `P-01…P-20` simulations | **[S-B: §40]** uses `P-01…P-15` | **`B-P-nn` is a citation convention, not a source ID.** Both are recorded here; the source ID governs | Low — but it must be stated, or a reader will search v1.3-B for "B-P-01" and find nothing |
| **PD-3** | **`V1…V8` is used for two different things inside v1.3-A** | **[S-A: A-06]** uses V1…V8 for the **Protection Visibility Protocol**; **[S-A: Annexure B / §Validation]** uses V1…V8 for **validation counsel categories** | Both are original | **Two distinct series sharing one prefix in one instrument.** Cited here as `A-06 V1…V8` and `A-V1…A-V8` | Medium — a cross-reference to "V4" is ambiguous between *insurance broker* and *no weapons* |
| **PD-4** | **`N1…N9` is used for two different things inside v1.3-A** | **[S-A: A-01]** uses N1…N9 for the **Political Neutrality prohibitions**; **[S-A: §22]** uses **N1…N38 ⟨new⟩** for the **Critical Decision Register** | Both are original | **Two distinct series.** Cited here as `A-01 N1…N9` and `A-N1…A-N38` | **Medium-high** — "N5" is either *no political content in communications* or *whether composition monitoring is undertaken at all* |
| **PD-5** | **`B1…B9` collides with `B-01…B-27`** | **[S-A: §23.2]** uses B1…B9 for **launch BLOCKERS**; **[S-B]** uses B-01…B-27 for **amendments** | Both are original | Distinguished by zero-padding, exactly as **[S-D: Rule D-129]** does for `P-nn`. Cited here as `A-B1…A-B9` | Low — but a reader searching "B-1" must know which series |
| **PD-6** | **`E1…E14` collides with `E-01…E-46`** | **[S-A: A-03]** uses E1…E14 for **election-period rules**; **[S-E]** uses E-01…E-46 for **amendments** and E-1…E-225 for **rules** | All three are original | **[S-E]** already flagged the A-03 collision. **v1.3-F adds the third: `E-n` unpadded = v1.3-E rule; `E-nn` zero-padded = v1.3-E amendment; `En` unpadded no hyphen = v1.3-A election rule** | **High** — three series, one letter |
| **PD-7** | **`H8` appears in two v1.3-A series** | **[S-A: §23.3]** uses H1…H13 for **HIGH PRIORITY items**; **[S-A]** also uses H10 for a **language rule** referenced by **[S-C: §30.2]** and **[S-E]** | Both are original | Same series, but **[S-C]** and **[S-E]** cite "v1.3-A H10" as though it were an amendment ID; it is a HIGH-PRIORITY *item*, not an amendment | Low — no amendment `H-10` exists in v1.3-A (its amendments are A-01…A-23); `H-10` in **[S-C]** is *Portable Credentials*, a different instrument entirely |
| **PD-8** | **`A-06` Protection Visibility Protocol is V1…V43, not V1…V8** | **[S-D]** and **[S-E]** both cite "A-06 V1…V8" | **[S-A: A-06]** contains **V1…V43** — **[S-E: Part 13 §13.4, Rule E-65, BR-1…BR-12, N-E-06]** built the entire dress, symbol and mark analysis on eight provisions | **[S-A: A-06]** contains **V1…V43** in seven groups: dress and insignia (V1–V8); **marks, colours, symbols and authority implication (V9–V11)**; public-space conduct (V12–V17); de-escalation and speech (V18–V23); filming, photography and media at scenes (V24–V30); authorities (V31–V35); scenes, crowds, children, victims, vulnerable persons and private property (V36–V41); **and mandatory incident-record fields making visibility an auditable property (V42–V43)** | **MATERIAL — the largest defect found.** Three consequences: **(i)** **[S-E: Rule E-65]**'s "four permitted surfaces" is incomplete — **V10 further prohibits any organisational flag, banner or stall at a crowd event, procession, rally or religious congregation**, which narrows the "banner at an authorised service activity" surface materially; **(ii)** **V9** independently prohibits any mark, colour combination, symbol, slogan, song, gesture or portrait identifying the organisation with a party, ideology, caste, community or movement — **the same prohibition [S-E: Rule E-61] reached by analysis, already stated in source**; **(iii)** **V42–V43** require incident records to state whether any member wore organisational identification, which **[S-E: Part 47 CC-7]** does not include. **[S-E] Part 13 must be re-run against V9…V43 before adoption** |
| **PD-9** | **The v1.3-A validation counsel series is V1…V12, not V1…V8** | Part III of this register | This register's own Part III initially inherited the shorter count | **[S-A: §Validation register, lines V1…V12]** — adds **V9 governance / company secretary** (CEO-versus-Council authority, reserved matters, dispute resolution), **V10 banking / finance** (mandate continuity, minimum signatories, custody instruments for reserves), **V11 communications / advertising counsel** (Public Protection Statement wording, representations), **V12 records / archival specialist** (retention obligations, evidentiary value, archival law) | **Material for Part III and for A-B9.** **V9 is the only counsel category that addresses LDR-U01 (CEO vs National Council) directly, and V10 is the only one that addresses the bank-mandate BLOCKER A-B9.** Total `[V]` items across the corpus is therefore **77, not 73** |

**[P] Rule F-4 (Source ID Supremacy).** Where a downstream instrument re-labels an upstream ID, **the upstream ID governs and the downstream label is recorded as a citation convention.** No ID in this register is newly minted except the register's own `F-` series, which labels *this document's* rules and findings only and never replaces a source ID.

## 0.4 Naming conventions used in this register

| Prefix | Meaning | Origin |
|---|---|---|
| **A-01 … A-23** | v1.3-A amendments | **[S-A: §24]** |
| **B-01 … B-27** | v1.3-B amendments | **[S-B: §47-equivalent amendment pack]** |
| **H-01 … H-28** | v1.3-C amendments | **[S-C: §60 / Annexure B]** |
| **L-01 … L-40** | v1.3-D amendments | **[S-D: Part 46, Annexure H]** |
| **E-01 … E-46** | v1.3-E amendments | **[S-E: Part 63, Annexure J]** |
| **A-B1 … A-B9** | v1.3-A launch **BLOCKER** items (source form `B1…B9`) | **[S-A: §23.2]** |
| **A-H1 … A-H13** | v1.3-A HIGH PRIORITY items | **[S-A: §23.3]** |
| **A-I1 … A-I11** | v1.3-A IMPORTANT-before-scaling items | **[S-A: §23.4]** |
| **A-L1 … A-L7** | v1.3-A LATER-after-pilot items | **[S-A: §23.5]** |
| **A-N1 … A-N38** | v1.3-A Critical Decision Register items (source form `N1…N38 ⟨new⟩`) — **38 items: 9 `UNRESOLVED`, 29 `PROPOSED`** | **[S-A: §22]** |
| **A-01 N1 … N9** | Political Neutrality Code prohibitions | **[S-A: A-01]** |
| **A-06 V1 … V43** | Protection Visibility Protocol, in seven groups — **PD-8** | **[S-A: A-06]** |
| **A-V1 … A-V12** | v1.3-A validation counsel categories (source form `V1…V12`) — **PD-9** | **[S-A: §Validation register]** |
| **HV-1 … HV-10** | v1.3-C consolidated `[V]` register | **[S-C: Annexure C]** |
| **LV-1 … LV-25** | v1.3-D professional validation register | **[S-D: Annexure C]** |
| **LV-E-1 … LV-E-30** | v1.3-E professional validation register | **[S-E: Annexure C]** |
| **LDR-C01 … LDR-C44** | v1.3-D carried source decisions | **[S-D: Part 45, Annexure B]** |
| **LDR-U01 … LDR-U20** | v1.3-D carried **UNRESOLVED** decisions | **[S-D: Part 45]** |
| **LDR-01 … LDR-20** | v1.3-D newly proposed decisions | **[S-D: Part 45]** |
| **N-E-01 … N-E-27** | v1.3-E National Identity Decision Register | **[S-E: Part 62, Annexure B]** |
| **C-D-01 … C-D-20** | v1.3-D contradiction audit | **[S-D: Part 47]** |
| **E-C-01 … E-C-20** | v1.3-E contradiction audit | **[S-E: Part 64]** |
| **P-01 … P-15** | v1.3-B pilot measurements — **source ID; cited downstream as `B-P-nn` (PD-1, PD-2)** | **[S-B: §40]** |
| **HM-1 … HM-15** | v1.3-C human measurements | **[S-C: §58]** |
| **LM-1 … LM-15** | v1.3-D leadership measurements | **[S-D: Part 44, Annexure I]** |
| **CI-1 … CI-15** | v1.3-E identity and communication measurements | **[S-E: Part 73, Annexure I]** |
| **MVLS-1 … MVLS-12** | Minimum Viable Leadership System | **[S-D: L-21, Part 40]** |
| **MVC-1 … MVC-11** | Minimum Viable Control set | **[S-B: B-20, §26]** |
| **XG-1 … XG-8** | Expansion gate | **[S-D: L-22, Rule D-43]** |
| **GATE E0 … GATE E7** | National identity expansion gates | **[S-E: Part 58]** |
| **F-1 … F-nn** | **This document's** rules | v1.3-F |
| **SR-nn** | **This document's** master-register item IDs | v1.3-F Part XXII |
| **BLK-A/B/C/D/E/F-nn** | **This document's** blocker categories | v1.3-F Part V |
| **CP-1 … CP-8** | **This document's** critical paths | v1.3-F Part VII |
| **P0-A … P0-J** | **This document's** pilot-authorisation gate | v1.3-F Part VIII |
| **PAK-01 … PAK-10** | **This document's** authorisation packages | v1.3-F Part XIX |

---

# MANDATORY ONE-PAGE EXECUTIVE ANSWER

> ## The twenty questions, answered from the corpus and from nothing else.
> **[A]** Every answer below is derived from the six source instruments. **No number, threshold, budget, target, legal conclusion or ownership arrangement is invented. Where the corpus is silent, the answer says so.**

| # | Question | Answer |
|---|---|---|
| **1** | **What is architecturally complete?** | **Substantially complete, and complete enough to test.** v1.2 supplies mission, doctrine, four pillars, four-level hierarchy, eleven role families, the universal role ladder, a 13-step vacancy lifecycle, a 12-step member lifecycle with ten training categories, a 9-step team-growth loop with an autonomy gate, a 9-step failure-recovery loop, the service/protection/AI-business engines, the eight-priority financial waterfall with four segregated finance hands, RBAC, six dashboards × five cadences, a multidimensional performance system with eight anti-gaming controls, a six-step dynamic leadership transition, audit, and a 19-article constitution. v1.3-A adds 23 amendments covering neutrality, protection visibility and liability, mission lock, succession, institutional memory, founder-versus-institution, data classification and minimisation, beneficiary dignity, safeguarding data, and AI governance. v1.3-B adds 27 amendments costing the mohalla unit. v1.3-C adds 28 amendments building the human system. v1.3-D adds 40 amendments and 135 rules building leadership, succession and performance. v1.3-E adds 46 amendments and 225 rules building identity, communication and reputation. **Total: 164 amendments, ~400 numbered rules and instruments, 60 defined pilot measurements, 40 recorded contradictions, 73 professional-validation items.** All of it is **State 1 — written architecture** |
| **2** | **What is operationally incomplete?** | **Almost everything.** Not one mechanism has a named human owner performing it, producing a record, under an audit method. Specifically absent: a legal entity; insurance; a privacy notice; a retention schedule; a named privacy officer; a certified safeguarding capability; a bank mandate; an adopted Political Neutrality Code; an approved Public Protection Statement; a comms policy; an approved non-police ID card design; a public local page; a public complaint route; a correction log; a refusal log; a claim register; a terminology register; a decision register in operation; a playbook tested rather than filed; any assessment performed by anyone outside a candidate's team; any published account; any verified outcome with follow-up. **v1.3-A's own taxonomy classifies nine of these as BLOCKERS — "the capability may not activate until resolved"** |
| **3** | **How many unresolved decision items exist?** | **259 authorised human acts stand between this corpus and an operative institution.** De-duplicated across all six instruments: **30 decisions are `UNRESOLVED`** — no answer exists (**A-N5, A-N10, A-N12, A-N13, A-N14, A-N15, A-N16, A-N19, A-N26** from v1.3-A; **LDR-U01…LDR-U20** from v1.3-D; **N-E-02** visual identity from v1.3-E, blocked by A-N12). **65 decisions are `PROPOSED`** — an answer exists as a proposal and needs an authorised yes or no (**A-N1…A-N4, A-N6…A-N9, A-N11, A-N17…A-N18, A-N20…A-N25, A-N27…A-N38** = 29; **LDR-01…LDR-20** = 20; **N-E-01, N-E-03…N-E-05, N-E-07…N-E-16, N-E-20, N-E-21** = 16). **164 amendments each require approval.** **Three decisions have `AUTHORITY UNRESOLVED`: LDR-U01 CEO versus National Council, A-N19 apex dispute resolution, and LDR-U19 successor to the founder — in each case the body that would decide is itself the subject of the decision.** Separately, **44 source decisions are carried and preserved (LDR-C01…LDR-C44)** and require no new act |
| **4** | **How many professional validation categories exist?** | **17 categories**, consolidating **77 distinct `[V]` items** — **A-V1…A-V12** (12), **HV-1…HV-10** (10), **LV-1…LV-25** (25), **LV-E-1…LV-E-30** (30) — de-duplicated semantically with every originating ID preserved. Part III names **who** must validate each, by role and never by invented person |
| **5** | **What are the top pilot blockers?** | **Nine, in dependency order.** **(1) Legal entity structure, tax position and worker classification** — `UNRESOLVED`, blocks everything involving money, contracts and employment, and therefore blocks priority-1 worker compensation, which is the whole economic premise. **(2) Written answers to the insurance and liability questions A-10 §9.1 L1–L15** — blocks all protection and first-response activity. **(3) Counsel review of the intervention boundary and mandatory reporting duties.** **(4) Political Neutrality Code adopted plus counsel review.** **(5) Public Protection Statement and DO-NOT list approved and published in operating languages.** **(6) Certified safeguarding — two-adult rule, image and consent absolutes, reporting protocol.** **(7) Privacy minimum — classification, retention schedule, notice, breach runbook, named privacy officer.** **(8) Protection Activation Gate adopted.** **(9) Bank mandate continuity and minimum signatories.** **Plus two v1.2 launch blockers of its own: a comms policy and an approved non-police ID card design [S: Ch.31]** |
| **6** | **What is the critical path?** | **CP-2 LEGAL / COMPLIANCE, and it is not close.** The master path is: **entity structure decided → counsel validates tax, employment and classification → insurance answers obtained → bank mandate and two signatories established → worker compensation can lawfully be paid → the pilot can pay anyone → anything economic can be measured.** Eight paths are mapped in Part VII; **CP-2 has the greatest downstream blocking effect because seven of the eight other paths contain at least one item that cannot lawfully operate without an entity** |
| **7** | **What must be built?** | **Eleven things, all of them paper or human, none of them software.** The entity and its governing documents; the privacy minimum (classification, retention schedule, notice, breach runbook, named officer); the certified safeguarding capability; the Political Neutrality Code and its refusal workflow; the Public Protection Statement and DO-NOT list in operating languages; the Protection Activation Gate; the bank mandate with two signatories and dual custody of credentials; the comms policy and the non-police ID card design; **the public local record PLR-1…PL-7 on paper**; the outward-reaching complaint route; the correction log and the refusal log. **Part XI maps each to a mechanism, an owner, a record and an audit method** |
| **8** | **What must be funded?** | **The pilot's own operating costs, and nothing else — because there is no revenue line for service, governance, training or communication.** Required: worker compensation at priority 1; statutory obligations at priority 2; direct business costs at priority 3; a first-season float; a wage-protection buffer; a reserve seed; the professional fees for the nine blockers; translation of the mandatory language set; certified safeguarding training; insurance premia; and the human time for `H_gov` **including communication hours, which no prior instrument costed ([S-E: §42.5 EA-E1])**. **No rupee value is asserted anywhere in this register. Every figure is `UNKNOWN — MEASURE IN PILOT` or a symbolic variable from [S-B]** |
| **9** | **What must be legally or professionally validated?** | **77 items across 17 categories.** The pre-pilot subset — marked ◆ in **[S-A: Annexure B]** — is: corporate/entity, tax, employment/labour, safeguarding, criminal/liability, insurance, data protection. **Everything else is important-before-scaling or later.** Part III names the validating role for each |
| **10** | **What must be measured?** | **60 measurements, in one shared pilot, by one mohalla team, with no technology.** **P-01…P-15** economic (including **P-15, dropped by PD-1 and restored here**); **HM-1…HM-15** human; **LM-1…LM-15** leadership; **CI-1…CI-15** identity and communication. **13 are recorded `NOT TESTABLE AT PILOT SCALE` and must not be approximated: LM-8, LM-10, CI-3, CI-4, CI-5, CI-10, CI-13, and the cohort-dependent items.** Part IX gives all twelve attributes per measurement. **No threshold is invented; where the corpus does not specify one, the entry reads `THRESHOLD REQUIRES FINAL APPROVAL`** |
| **11** | **What cannot be proven in the pilot?** | **Ten things.** Succession and continuity beyond one team; promotion without hollowing out the winning team; out-of-team assessment independence (**there is no outside at Stage 0–1**); cohort normalisation (a cohort of one is not a cohort); economic sustainability (`m_lead`, `σ_max`, the City divisor and `K_min` all need a range of values); governance burden at scale (no technology, no range of `K`); national identity, recognition, reputation and adoption; language equity across states; political, religious and caste neutrality under real external pressure; business-network scaling. **Part X separates MUST-PROVE, SHOULD-TEST, CANNOT-PROVE, NEEDS-MULTI-CITY and NEEDS-NATIONAL** |
| **12** | **What can safely wait?** | **[S-A: §23.5 L1…L7]:** numeric values for every interval, ratio, threshold and period; the full-scope continuity test; the oral-history programme; a public archive; the full-form annual AI governance report; external independent privacy and governance reviews; any federation or state-entity structure. **[S-A: §23.4 A-I1…I11]:** mission lock, succession architecture, apex dispute resolution, memory instruments M1–M5, the key-person register, brand and IP ownership, reserve custody, AI auditability fields, founder-versus-institution rules, the DPIA programme, composition monitoring. **Plus, explicitly NOT blockers per [S-A: §23.1]: software completeness, badges, ceremonies, the state layer, the leaderboard, national branding, and the full 14-module platform** |
| **13** | **What is the biggest institutional risk?** | **Founder concentration combined with unresolved ownership.** **[S: Ch.4]** places "property, brand, strategy and ultimate founder-level control" in one pair of hands; **A-N12** brand ownership and **A-N13** IP ownership are both `UNRESOLVED`; **LDR-U01** CEO-versus-Council is `UNRESOLVED` with **`AUTHORITY UNRESOLVED`**; **LDR-U19** successor to the founder is `UNRESOLVED`; **A-N19** apex dispute resolution is `UNRESOLVED`. **[S-ST: §11.1]** states the mechanism: *"the institution's identity and its legal continuity are the same object, held by one person… if the public face is one person, every controversy about that person is a controversy about the institution, and there is no way to defend the institution by separating them."* **The architecture has no exit ramp from founder-centrality that has been executed** |
| **14** | **What is the biggest economic risk?** | **Priority 1 cannot lawfully be paid until the entity structure is decided.** The waterfall puts worker compensation first **[S: Ch.18]**, and it is APPROVED architecture — but paying a worker requires an entity, a classification and a bank mandate, and **B1 (entity structure, tax position, worker classification) is `UNRESOLVED`** while **LDR-U09 worker classification**, **LDR-U02 `m_lead`**, **LDR-U16 founder compensation**, **LDR-U17 the economic blueprint** and **LDR-U18 the 37.5/17/12 percentages** are all unresolved or NOT FINAL. **Compounding it: there is no revenue line for service, governance, training or communication, and `H_gov` is bounded only by an unmeasured `σ_max`** |
| **15** | **What is the biggest human-system risk?** | **Recruitment at the moment of vulnerability, and the invisibility of the excluded.** **[S-C: H-03]** prohibits recruitment at the moment of vulnerability and **[S-E: Rule E-13]** removes the beneficiary-to-participant pathway entirely — but the pilot will place members in direct contact with people in acute need, and the prohibition is a rule, not a mechanism. **The second half is unresolvable: [S-E: MAF-25] — the people excluded by language, caste, class, gender, age, disability or digital access are precisely the people absent from every dataset the organisation will hold. Non-participation leaves no record** |
| **16** | **What is the biggest leadership risk?** | **There is no mechanism to select the unpopular competent person over the popular incompetent one — and at Stage 0–1 there is nobody outside the social field to supply it.** **[S-D: ES.5]**, carried forward unsoftened. Every selection signal is socially mediated; the correction requires four affordances, **two of which need a person from outside the unit's social field**, which does not exist until there is a second team. **[S-D: Part 52]**: eight requirements for a B verdict, **zero satisfied**. **And [S-D: Rule D-122] — an unexercised control counts as absent — means a written leadership system that is never used is indistinguishable from no system** |
| **17** | **What is the biggest reputation risk?** | **The correction log stays empty.** **[S-E: ES.5]**: the entire reputation architecture rests on one voluntary act — publishing what went wrong — and **no instrument in v1.2 or v1.3-A/B/C/D/E compels it, detects its absence, or penalises its omission.** Every other value has a control; publication of failure has none, and the incentive runs backwards. **[S-E: Rule E-88]** is the only control across all six instruments that acts on the *absence* of a record, and **[S-E: OQ-E19]** records honestly that it may still be reinterpreted as applying only to failures that were already public |
| **18** | **What is the final readiness verdict?** | # **C — PILOT NOT READY, BUT THE PATH IS FINITE.** Part XXV |
| **19** | **What is the next single artifact that should be produced?** | **An ENTITY-STRUCTURE DECISION PAPER, for the founder/CEO, putting the options to qualified Indian corporate and tax counsel.** Not an answer — the corpus forbids inventing one — but the artifact that converts **A-B1 / LDR-U08** from `UNRESOLVED` into `DECIDABLE`. It must state: the options (Section 8 company, trust, society, other, or a two-entity structure); what each permits and prohibits for the four pillars; the 12A application-of-income and political-activity conditions **[X]**; 80G; FCRA timing; worker-classification consequences per option; objects-clause requirements; dissolution and restructuring constraints **[S: Const. Art.19]**; and the brand and IP ownership consequence of each **(A-N12, A-N13)**. **It unblocks A-B1, A-B9, LDR-U08, LDR-U09, and downstream of those, priority-1 payment, insurance, contracts, the privacy notice's named data fiduciary, and CP-2 in its entirety** |
| **20** | **What must NOT be built yet?** | **The platform.** Specifically: the 14-module software platform; any app; the leaderboard; dashboards; AI features of any tier; the state layer; badges, uniforms, insignia or ceremonies; a mark, palette or logo; any national domain, account portfolio or campaign; national branding of any kind; contribution portability; and any numeric threshold, weight, ratio, interval or period. **[S-A: §23.1]** is explicit that *"software completeness, badges, ceremonies, the state layer, the leaderboard, national branding and the full 14-module platform are **not** in the blocker list."* **[S-B: §40]** runs the pilot **with no technology at all**, which is the proof that none of it is required. **[S-E: Rule E-60]** separately blocks national brand use while A-N12 and A-N13 are unresolved. **Building software now would substitute engineering for the nine decisions that are actually blocking** |

---

# PART I — SOURCE RECONNAISSANCE

## I.1 The corpus, as measured

**[A]** Verified by direct count against the files, not recalled.

| Instrument | Bytes | Amendments | Numbered rules / instruments | Measurements | Validation items | Unresolved decisions | Contradictions | Verdict |
|---|---|---|---|---|---|---|---|---|
| **v1.2** (incl. App. A / v1.1) | 179 pp. | — | 19 constitution articles; 36 visual chapters; 11 role families; 6 dashboards × 5 cadences; 8 anti-gaming controls; RBAC matrix; App. E delegation matrix; App. F evidence standards | — | "professional validation required before deployment" stated globally | **12 items in Ch.33** `NOT FINAL` / `UNRESOLVED` / `PROPOSED` | — | Not graded |
| **Strategic Stress Test** | 352,460 | — | F-01…F-36 failure modes; M1…M23 modifications; R1…R5 reconsiderations; §23.1 stage model; §23.2 twenty-function table | — | Annexure B consolidated validation register | — | — | Diagnostic |
| **v1.3-A** | 318,492 | **A-01…A-23 (23)** | A-01 N1…N9; A-03 E1…E14; **A-06 V1…V43 (PD-8)**; A-08 DO-NOT; A-13 Tier-1; A-14 §13.3–§13.8; A-15 M1…M7; A-16 four tests; A-17 C1–C4 and P1–P6; A-18 necessity test; A-20 sealed regime; A-21/A-22 AI | — | **A-V1…A-V8 (8)** + Annexure B ◆-marked pre-launch set | **A-N1…A-N38 (38: 9 UNRESOLVED, 29 PROPOSED)**; blockers A-B1…A-B9; A-H1…A-H13; A-I1…A-I11; A-L1…A-L7 | — | **D** |
| **v1.3-B** | 475,834 | **B-01…B-27 (27)** | `C_lead`, `m_lead`, `H_gov` 8–40 h/team/month, `σ_max`, `K_min`, `H_gov_per_team(K)`, `P_max`, `C_city`, MVC-1…MVC-11, GB-1…GB-6, B-18(1)…(6), HC-* hidden costs, the eight-priority waterfall variables | **P-01…P-15 (15)** | `[V]` items inside A-V1…A-V8 and HV-series | `m_lead`, `σ_max`, `K_min`, `c`, City divisor shape, economic blueprint, 37.5/17/12 | — | **D** |
| **v1.3-C** | 432,762 | **H-01…H-28 (28)** | H-02 nine levels; H-08 six instruments; SR-1…SR-7; CR-1…CR-4; AC-1…AC-11; CK-1…CK-7; MLM-1…MLM-7; SA-1…SA-7; §30.2 L1/L2/L3; H-11 S1…S6 | **HM-1…HM-15 (15)** | **HV-1…HV-10 (10)** | Composition of L4 payment; credential recognition | — | **D** |
| **v1.3-D** | 725,675 | **L-01…L-40 (40)** | **D-1…D-135 rules**; LC-1…LC-20; LE-1…LE-5; PG-1…PG-12; SS-0…SS-5; TL-1…TL-5; SP-1…SP-6; PL-0…PL-6; XG-1…XG-8; DV-1…DV-5; AF-C1…AF-C12; RV-1…RV-4; GF-1…GF-30; CU-1…CU-10; VG-1…VG-6; PC-1…PC-8; MVLS-1…MVLS-12; MAT-0…MAT-5; INV-1…INV-20; ADAPT-1…ADAPT-12 | **LM-1…LM-15 (15)** | **LV-1…LV-25 (25)** | **LDR-U01…LDR-U20 (20)**; LDR-C01…C44 carried; LDR-01…20 proposed | **C-D-01…C-D-20 (20)** | **D** |
| **v1.3-E** | 744,543 | **E-01…E-46 (46)** | **E-1…E-225 rules**; CL-0…CL-8; GATE E0…E7; NI-0…NI-6; MA-0…MA-6; TS-1…TS-14; CC-1…CC-8; MC-1…MC-11; LA-1…LA-5; BR-1…BR-12; NP-1…NP-9; PLR-1…PL-7; NEF-1…NEF-10; MAF-01…MAF-28; NRT-01…NRT-20; SIM-01…SIM-20 | **CI-1…CI-15 (15)** | **LV-E-1…LV-E-30 (30)** | **N-E-01…N-E-27 (27)**, of which 18 carry or depend on an unresolved source item | **E-C-01…E-C-20 (20)** | **D** |
| **TOTAL** | **3,049,766 bytes of amendment instruments** | **164 amendments** | **~400 numbered rules, gates, registers and instruments** | **60 measurements** | **77 `[V]` items in 17 categories** | **30 UNRESOLVED + 65 PROPOSED decisions** | **40 recorded contradictions** | **Five instruments, five `D` verdicts** |

## I.2 The master reconnaissance table

**[P]** The brief specifies fourteen fields. **Applied to the corpus as a whole rather than to each of ~400 items individually** — a per-item table of that size would be unreadable and would itself violate **[S-E: Rule E-101]** no reporting theatre. Part XXII supplies the per-item canonical register.

| Field | Content |
|---|---|
| **Source instrument** | v1.2 · Stress Test · v1.3-A · v1.3-B · v1.3-C · v1.3-D · v1.3-E |
| **Source version** | v1.2 = "Visual Transformation Edition", 1 Oct 2026, 179 pp., Appendix A preserves v1.1 page-by-page. v1.3-A/B/C/D/E = undated amendments prepared to 5 Oct 2026 |
| **Amendment ID** | A-01…A-23 · B-01…B-27 · H-01…H-28 · L-01…L-40 · E-01…E-46 — **164 total, all preserved, none renumbered** |
| **Rule ID** | **[S-D]** D-1…D-135 · **[S-E]** E-1…E-225 — **360 rules total** |
| **Decision ID** | **A-N1…A-N38** · LDR-C01…C44 · LDR-U01…U20 · LDR-01…20 · N-E-01…N-E-27 |
| **Validation ID** | A-V1…A-V12 · HV-1…HV-10 · LV-1…LV-25 · LV-E-1…LV-E-30 — **77 items (PD-9)** |
| **Gate ID** | **[S-D]** Gate E, Gate R, XG-1…XG-8 · **[S-E]** GATE E0…E7 · **[S-A]** A-11 Protection Activation Gate G-N · **[S-B]** solvency line §8.3 · **this document** GATE P0 (P0-A…P0-J), the Part XX exit gate, the Part XXI expansion gates |
| **Contradiction ID** | C-D-01…C-D-20 · E-C-01…E-C-20 — **40 total, of which [S-D] records 2 as true-and-refused and [S-E] records 5 as not-resolved** |
| **Requirement** | Stated per item in Parts II, IV, IX, XI, XIX, XXII |
| **Requirement type** | DECISION · VALIDATION · BUILD · IMPLEMENTATION · MEASUREMENT · PILOT TEST · EVIDENCE REVIEW · DISCIPLINE-ON-EXISTING-ACTIVITY |
| **Current status** | One of the thirteen permitted statuses (Part XXII). **No item in the corpus is at `PASS`; every architectural item is at `COMPLETE — NOT YET PROVEN` or below** |
| **Provenance** | Exact instrument, part/section and ID. Where an item appears in multiple instruments, **all source IDs are retained** (Rule F-4) |
| **Dependencies** | Part VI dependency graph, 25 named chains |
| **Downstream consequence** | Stated per item; summarised in Part V blockers and Part VII critical paths |

## I.3 The five verdicts, and what their identity means

**[A]** All five amendment instruments returned **D — NOT YET PROVEN**, independently, using different criteria:

| Instrument | Its own reason for D |
|---|---|
| **v1.3-A** | Institutional survival mechanisms are proposed; nothing is executed; entity, tax, insurance, ownership and succession all open |
| **v1.3-B** | Every economic variable is symbolic; `m_lead`, `σ_max`, `K_min` and the City divisor are unmeasured; no revenue line exists for service, governance or training |
| **v1.3-C** | The human system is designed; no human has experienced it; adoption is unevidenced |
| **v1.3-D** | Eight requirements for B, **zero satisfied**; the pivot — out-of-team assessment capability — does not exist |
| **v1.3-E** | Eight requirements for B, **zero satisfied**; nothing has been seen by a member of the public; brand ownership unresolved |

**[A]** Five instruments reaching the same verdict by five different routes is the strongest single finding available about the corpus: **the deficiency is not local to any one domain.** It is that **the entire body of work is State 1**, and no amount of additional State 1 work moves it to State 2. **Part XVIII exists to make that unavoidable.**

## I.4 What the corpus already agrees on

**[A]** Consolidation surfaces a set of propositions that appear independently in three or more instruments. **These are the load-bearing agreements, and none of them is contradicted anywhere in the corpus:**

| Agreement | Appears in |
|---|---|
| **One shared pilot: one mohalla team, no technology** | **[S-B: §40]**, **[S-C: §57]**, **[S-D: Part 41 / Rule D-130]**, **[S-E: Part 72 / Rule E-222]** |
| **No number is invented; every threshold is `PROPOSED` or `UNKNOWN — MEASURE IN PILOT`** | All five |
| **The waterfall priority order is APPROVED and is a reserved matter** | **[S: Ch.18]**, **[S-A: A-14 §13.3]**, **[S-D: LDR-C16, LDR-C26, INV-2]**, **[S-B]** throughout |
| **AI recommends; humans decide; AI cannot autonomously make consequential HR, wage, legal, safeguarding, safety, major-fund or leadership decisions** | **[S: Const. Art.12]**, **[S-A: A-21, A-22]**, **[S-D: L-26, AI-1…AI-8]**, **[S-E: Rule E-68, E-133]** |
| **A person is never scored; no composite human score; no universal score** | **[S-C: §23.2, CR-1…CR-4]**, **[S-D: Rule D-63]**, **[S-E: Rule E-200]** |
| **Political and religious non-alignment; service without discrimination** | **[S: Ch.2]**, **[S-A: A-01, A-05]**, **[S-D: PC-1…PC-8]**, **[S-E: Parts 7–9]** |
| **No uniform, no insignia, no worn mark, no authority by appearance** | **[S-A: A-06 V1…V3, V8]**, **[S-D: Part 21 §21.7]**, **[S-E: Rule E-65, N-E-06]** |
| **Unexercised controls count as absent** | **[S-D: Rule D-122]**, **[S-E: Rule E-88, MAF-28]** |
| **Under-claiming is a strategy, not modesty** | **[S-ST: §18.3 item 4, §30.3]**, **[S-E: Rule E-4, CL-0…CL-8, Rule E-128]** |
| **A zero count on a health indicator is a warning sign, not a clean bill** | **[S-A: A-16 test 3]**, **[S-D: Rule D-94]**, **[S-E: Rule E-88, CI-10]** |

**[P] Rule F-5 (Agreed Propositions Are Not Reopened).** Nothing in the table above is re-examined, qualified or weakened by this register. **They are the fixed points against which readiness is assessed.**

---

# PART II — MASTER AMENDMENT REGISTER

## II.1 Method and the ten determinations

**[P]** All **164 amendments** are merged into one register. **No ID is renumbered; no duplicate provenance is erased.** Where two instruments address the same matter, both IDs appear and the relationship is stated.

For every amendment the brief's ten determinations are answered:

| # | Determination | How it is recorded here |
|---|---|---|
| 1 | What changed? | Column **What changed / why** |
| 2 | Why was it introduced? | Same column |
| 3 | Is it already incorporated into the architecture? | Column **In arch.** — values: `NO — proposed` (all 164 are proposals; **none has been merged into v1.2**), `CONSTRAINS v1.2` (binds an existing APPROVED rule without altering it), `PRESERVES v1.2` (restates and extends) |
| 4 | Does it require implementation? | Column **Impl.** — `YES-BUILD` (a new mechanism must exist), `YES-DISCIPLINE` (a constraint on existing activity, no new mechanism), `NO` |
| 5 | Does it require professional validation? | Column **Val.** — the category from Part III, or `—` |
| 6 | Does it require pilot evidence? | Column **Pilot** — `YES` with the measurement ID, `NO — not testable` with the reason, `NO — pre-pilot` |
| 7 | Does it create dependencies? | Column **Deps** |
| 8 | Does another instrument supersede, constrain or depend on it? | Same column, with the instrument and ID |
| 9 | Is it unresolved? | Column **Deps** carries any `UNRESOLVED` item it touches; Part IV lists all 58 |
| 10 | What happens if it is ignored? | Column **If ignored** |

**[P] Rule F-6 (No Amendment Is Incorporated).** A factual finding that governs the whole register: **not one of the 164 amendments has been merged into v1.2 or into any operative document.** Each source instrument states its own merge target and its own status `PROPOSED — REQUIRES FINAL APPROVAL`. **Every row of this register therefore begins at State 1 with an approval step outstanding.**

## II.2 v1.3-A amendments — A-01 … A-23

| ID | Amendment | What changed / why | In arch. | Impl. | Val. | Pilot | Deps / constrained by | If ignored |
|---|---|---|---|---|---|---|---|---|
| **A-01** | Political Neutrality Code — organisational neutrality (N1…N9) | Adds nine prohibitions on endorsement, use of name/marks/colours/dress/records/channels for partisan purposes, political fundraising and crowd mobilisation, political symbols, political content **including favourable**, acceptance of political resources, political use of data, belief screening, and misrepresentation by omission. **Why:** no rule governed any of it; tax-exempt standing may depend on absence of political activity **[X]** | CONSTRAINS v1.2 | YES-DISCIPLINE + YES-BUILD (the code, the refusal script, the approach register) | Legal, tax, electoral | **YES** — refusal log must show at least one logged use **[S-ST: §30.3 item 3]** | **A-B4 BLOCKER**; A-02, A-03, A-04; **[S-D: PC-1…PC-8]**; **[S-E: E-06]** | Misclassification as a party front — rated **Severe** **[S-ST: §18.2]**; possible loss of tax-exempt standing **[X][V]** |
| **A-02** | Member political activity and conflict of interest | Adds tier restrictions on role-holders' political activity, declaration duties, and an **anti-screening guard (A-01 N8)** so neutrality never becomes a loyalty test. **Why:** a member's civic rights and the organisation's neutrality collide above Coordinator level | CONSTRAINS v1.2 | YES-DISCIPLINE | Employment/labour, constitutional | NO — pre-pilot adoption | A-01; **A-N3**; **[S-A: A-H8]** required before appointments above Coordinator | Either citizens' rights are over-restricted, or a role-holder's political activity is attributed to the organisation |
| **A-03** | Election-Period Operating Protocol (E1…E14) | Adds an internal window and fourteen rules including emergency exception **E9**. **Why:** distribution adjacency to an election is read as political regardless of intent | CONSTRAINS v1.2 | YES-DISCIPLINE | Electoral law per jurisdiction | NO — requires an election in the operating area | A-01; **A-N2**; **[S-E: Rule E-30]** | Distribution near an election; MC-1 crystallises |
| **A-04** | Political Approach Response Workflow | Adds an approved refusal script in every operating language, a written-reply template signed at National level, an **approach register with a published annual count**, and a support duty where a member suffers consequence for a logged refusal. **Why:** "publishing refusals is more credible than declaring neutrality" | NO — proposed | YES-BUILD | Legal | **YES** — **[S-E: CI-10]** | A-01; **[S-E: TS-8, Rule E-33]** | A 22-year-old Team Leader must either be rude to a senior politician or capitulate; and neutrality is declared rather than evidenced |
| **A-05** | Equal Treatment and Non-Alignment Principle (8 clauses, 4 guards) | Adds institutional non-alignment on religion, caste, ethnicity, language, region and social group; cultural respect without alignment; composition monitored never engineered; activity-scoped faith partnerships; no religious or caste framing; symbols and dress carry no communal identification; **language is not identity-ranking**. **Why:** pattern-level neutrality cannot be inferred from act-level non-discrimination | CONSTRAINS v1.2 Ch.2 | YES-DISCIPLINE | Legal, cultural, equality | **YES** — behavioural pattern review | **A-N4**; **A-N5 composition monitoring `UNRESOLVED — deliberately`**; A-06; **[S-E: E-07, E-08]** | The organisation is classified as one community's organisation **even if every individual decision was neutral** |
| **A-06** | Protection Visibility and Public Conduct Protocol (**V1…V43 — PD-8**) | Adds: no uniform; no uniform-like garments; no insignia of authority; identification carried not worn; task-scoped removable activity identification; no weapons or force-suggesting equipment; PPE never styled or branded as identity; **the mark may appear only on documents, authorised-activity banners, digital channels and task-scoped identification**. **Why:** adjacency is read as equivalence by observers and by cameras | CONSTRAINS v1.2 Ch.16 | YES-DISCIPLINE | Legal, criminal | NO — pre-pilot, absolute | A-05 clause 7; A-07; A-08; **[S-D: VG-1…VG-6]**; **[S-E: BR-1…BR-12, Rule E-65]** | Vigilante / private-security misclassification — rated **Severe**; police attention; member criminal exposure |
| **A-07** | Public Protection Statement | Adds a published plain-language statement of what the protection function is, is not, and will not do. **Why:** the word "protection" imports the most dangerous category | NO — proposed | YES-BUILD (the statement, in operating languages) | Legal | NO — pre-pilot | **A-B5 BLOCKER**; A-06, A-08 | MC-3 uncorrected; the organisation is discovered rather than described |
| **A-08** | Protection DO-NOT List — constitutional entrenchment | Entrenches the DO-NOT list so it binds at every level and cannot be altered by any interim or local authority; makes it a reserved matter. **Why:** the list is the only hard boundary between service and enforcement | CONSTRAINS v1.2 Ch.16 → Constitution | YES-DISCIPLINE | Criminal law per jurisdiction | NO — pre-pilot, absolute | **A-B5**; A-14 §13.3 reserved matters; **[S-D: LDR-C31, VG-2]**; **[S-E: Rule E-116]** | A local team rationalises an intervention; the act is unlawful and the organisation has no entrenched rule to point to |
| **A-09** | Protection Incident Protocol (extended) | Adds mandatory triggers, an authority matrix, a do-not-attend list and an incident record. **Why:** incidents are where legality is decided in minutes | CONSTRAINS v1.2 | YES-BUILD (the record and the matrix) | Criminal, safeguarding | **YES** — incident records | **A-N9**; A-06, A-08, A-10, A-11; **[S-E: CC-1, CC-7]** | An incident is handled inconsistently; no record exists; the review cannot occur |
| **A-10** | Protection Liability Framework (L1…L15) | Poses fifteen liability and insurance questions requiring **written answers**. **Why:** volunteer first-response activity may be uninsured and the exposure is personal | NO — proposed | YES-BUILD (the answers) | **Insurance broker; criminal/regulatory counsel** | NO — pre-pilot | **A-B2 BLOCKER**; **A-N10**; A-06, A-08, A-09 | **Uninsured personal injury to a member or a third party. Irreversible harm** |
| **A-11** | Protection Activation Gate (G-N) | Adds a gate that must be passed before any protection activity activates, with scope definition and a renewal interval. **Why:** protection is the pillar most likely to be activated by enthusiasm rather than by authority | NO — proposed | YES-BUILD | Legal, safety | NO — pre-pilot | **A-B8 BLOCKER**; **A-N11**; A-06…A-10 | Protection activity occurs without a gate, without scope and without renewal |
| **A-12** | Founder Concentration Analysis | Documents that ownership, executive authority, brand, strategy, mission amendment and — by default — IP and data sit in the same hands. **Changes nothing; proposes nothing.** **Why:** the concentration is legitimate for a founder-led origin and fatal for a national institution | PRESERVES v1.2 Ch.4 | NO | Governance | NO | **LDR-U01, LDR-U19**; A-13, A-14, A-16; **[S-D: L-29]**; **[S-E: E-C-15, SIM-10]** | The institution's identity and its legal continuity remain the same object, held by one person |
| **A-13** | Mission Lock Framework | Adds a Tier-1 amendment process — irrevocable purpose clause, supermajority, cooling-off, publication — for mission, brand, reserves and social-impact fund. **Why:** cheap before the institution has value, expensive after | NO — proposed | YES-BUILD (legal drafting) | Corporate counsel | NO — post-pilot **[S-A: A-I1]** | **[S: Const. Art.19]** requires professional validation; **A-N18**; A-14 §13.3 | A future holder can change the mission, transfer the brand or reorder the waterfall quickly, alone and privately |
| **A-14** | Succession Architecture | Adds apex Deputy, an Interim Authority Order, seven **reserved matters**, dual custody of credentials including **domain, payment gateway, communication channels, social accounts and statutory portals**, minimum two authorised signatories so worker compensation can be paid during an apex vacancy, continuity-during-dispute, a 16-item handover, and an **annual unannounced 72-hour continuity test**. **Why:** mortality and incapacity are certainties over a 20-year horizon | NO — proposed | YES-BUILD | Corporate, governance | **YES** — **[S-D: LM-2, CT-C]** | **A-N17**; **A-B9 BLOCKER** (bank mandate); A-13; **[S-D: L-08, L-10, L-17, L-20]**; **[S-E: Rule E-188]** | Apex vacancy becomes an ending rather than an inconvenience; worker compensation cannot be paid; credentials are locked to one person |
| **A-15** | Institutional Memory System (M1…M7) | Adds a decision-rationale register, a versioned standards library, an open change-request route, institutional (not personal) record ownership, a lessons entry with a **"did it work"** column, a playbook library and an oral-history programme. **Why:** institutions survive because their memory is external to people | NO — proposed | YES-BUILD | Governance | **YES** — **[S-D: LM-3]** decision-record completeness | **A-I4**; **[S-D: L-16, Part 28]**; **[S-E: Part 57]** | Every decision is justified by reference to a person rather than to a rule, a record or a reason |
| **A-16** | Founder versus Institution | Adds seven conditions and **four annual tests** — absence, attribution, dissent, successor — with the rule that **"a zero count is a warning sign, not a clean bill of health"**, plus §15.4 public-representation rules: decisions in the organisation's name with the deciding role identified; no portrait as an object of display; no founder-attribution requirement; no observance of personal dates as organisational festivals; **many authorised spokespersons by domain and region**. **Why:** there is no exit ramp from founder-centrality | NO — proposed | YES-DISCIPLINE | Governance | **YES** — **[S-D: LM-15; S-E: CI-13]** | **A-I9**; A-12, A-14; **[S-D: L-29, CU-1…CU-10]**; **[S-E: E-35 AC-1…AC-9]** | Personality cult; every controversy about the person becomes a controversy about the institution |
| **A-17** | Data Estate Map and Security Classification | Adds C1 PUBLIC / C2 INTERNAL / C3 RESTRICTED / C4 SEALED; classification as a property of the *field*; default-upward on mixed records; ten attributes per category; a named human owner; **P1 classification, P2 retention schedule, P3 privacy notice in English or any Eighth Schedule language, P4 DPIA programme, P5 breach response, P6 processor standard**. **Why:** least privilege existed but classification, retention and breach response did not | CONSTRAINS v1.2 Ch.22 | YES-BUILD | **Privacy counsel / DPO** | **YES** — breach runbook rehearsed | **A-B7 BLOCKER**; **LDR-U10 data retention `UNRESOLVED`**; **A-N14 data fiduciary**; A-18, A-19, A-20; **[X]** DPDP Act 2023 notification timelines **[V]** | Systematic personal-data collection with no classification, no retention rule, no notice and no rehearsed breach response. **Statutory penalty exposure [X][V]** |
| **A-18** | Data Minimisation Doctrine | Adds a four-branch necessity test before any field is collected. **Why:** every unnecessary field is a future breach and a future inference | CONSTRAINS v1.2 | YES-DISCIPLINE | Privacy | **YES** — field audit | A-17; **[S-C: CR-1…CR-4]**; **[S-D: L-30]**; **[S-E: Rule E-48, E-80]** | Identity data accumulates; the instrument that would prove neutrality becomes the instrument that sorts people |
| **A-19** | Beneficiary Privacy and Dignity Code | Adds an eight-function access matrix separating contributor records from beneficiary records, and dignity rules on images, consent and testimony. **Why:** the person helped is the least able to object and the most likely to be exposed | CONSTRAINS v1.2 Ch.15, App. F | YES-DISCIPLINE | Privacy, safeguarding | **YES** — consent completeness **[S-E: CI-14]** | A-17, A-18, A-20; **[S-C: H-22]**; **[S-E: E-34, Rule E-148]** | Dignity violation; MC-9 "charity with poor people as props" — rated **High** |
| **A-20** | Sensitive Incident and Safeguarding Data Model | Adds the sealed-category regime: named individuals, case scope, **two-person rule for opening**, reason code, time-limited, logged, audited; and subject rights including access to one's own record. **Why:** C4 data can endanger a person physically, legally or socially | CONSTRAINS v1.2 | YES-BUILD | Privacy, safeguarding | NO — pre-pilot | A-17, A-19; **[S-D: L-30, LV-14]**; **[S-E: Part 22]** | A whistleblower, survivor or minor is identified; the complaint route becomes a risk rather than a protection |
| **A-21** | AI Governance Extension | Adds risk tiers, review caps and prohibited autonomous decisions, extending **[S: Const. Art.12]**. **Why:** "AI recommends, humans decide" is a principle without a mechanism | CONSTRAINS v1.2 Ch.21 | YES-BUILD (tiers, caps, logs) | Technology, privacy | NO — no AI in the pilot | **A-H11**; A-22; **[S-D: L-26, AI-1…AI-8]**; **[S-E: Rule E-68, E-133]** | AI is deployed at Medium/High tier with no review cap and no log field set |
| **A-22** | AI Auditability Standard | Adds an append-only field set — prompt, output, model, sources, user, reviewer, final decision. **Why:** fields cannot be retro-fitted onto past logs | CONSTRAINS v1.2 Ch.21 | YES-BUILD | Technology, privacy | NO — no AI in the pilot | **A-I8**; A-21; **[S-D: LV-15, LV-16]** | Logs exist but cannot answer who decided what on what basis |
| **A-23** | Critical Decision Register and Launch Blocker Taxonomy | Adds **A-N1…A-N38** decisions with owner, dependency and timing, and the four-class blocker taxonomy — **BLOCKER A-B1…A-B9 / HIGH PRIORITY A-H1…A-H13 / IMPORTANT A-I1…A-I11 / LATER A-L1…A-L7** — with the classification test and the explicit note that nothing is a blocker merely because it would be *good*. **Why:** without a taxonomy, every architectural requirement becomes a launch blocker | NO — proposed | YES-BUILD (the register, maintained) | Governance | NO — pre-pilot | **This is the direct ancestor of Part V of this register** | Either everything blocks the pilot, or the nine things that genuinely block it are not distinguished from the things that would be nice |

## II.3 v1.3-B amendments — B-01 … B-27

| ID | Amendment | What changed / why | In arch. | Impl. | Val. | Pilot | Deps / constrained by | If ignored |
|---|---|---|---|---|---|---|---|---|
| **B-01** | Service Hour Budget (`H_svc`) | Puts a time budget on service so mission work is planned rather than residual. **Why:** there is no revenue line for service | NO — proposed | YES-BUILD | Accounting | **YES — P-09** | `σ_max`; **[S-D: LM-12]**; **[S-E: Rule E-185]** mission balance | Service displaces paid work silently, or paid work displaces service silently |
| **B-02** | Time-Costed Service Floor | Costs service in hours so it is visible in the ledger. **Why:** unpaid service is invisible and therefore inexhaustible | NO — proposed | YES-BUILD | Accounting | **YES — P-09** | B-01, B-08 | Volunteer time is consumed without record; burnout arrives without a signal |
| **B-03** | Reserve Seeding Order | Fixes the order in which reserves are seeded relative to the waterfall. **Why:** reserves compete with priority 1 | CONSTRAINS v1.2 Ch.18 | YES-DISCIPLINE | Accounting, financial controls | **YES — P-10** | **[S: Ch.18]** priority order is a reserved matter; **A-N15 custody of reserves `UNRESOLVED`** | Reserves are either never seeded or seeded ahead of worker compensation |
| **B-04** | First-Season Float | Requires a float before the first season because revenue lags cost. **Why:** `M_to_buffer` is very large when average surplus is small, and grows super-linearly | NO — proposed | YES-BUILD (**funding**) | Accounting | **YES — P-10, P-11** | **BLOCKER D — must be funded before pilot**; `S̄_5` unmeasured | The team cannot pay a worker in month two and the pilot ends for a cash reason, not an architectural one |
| **B-05** | Accrued Compensation Ledger | Records compensation earned but not yet paid. **Why:** an unpaid obligation that is not recorded is not an obligation | NO — proposed | YES-BUILD | Accounting, financial controls | **YES — P-13** | **[S: Ch.19]** payment sheet with formula version; entity structure | Work is performed and owed with no record; the ledger overstates health |
| **B-06** | Pro-Rata Verified-Work Rule | Pays pro-rata against verified work. **Why:** all-or-nothing payment punishes partial delivery and incentivises claim inflation | CONSTRAINS v1.2 Ch.19 | YES-DISCIPLINE | Labour, accounting | **YES — P-02, P-13** | **LDR-U09 worker classification `UNRESOLVED`**; verification capability | Payment disputes; verification becomes the thing people game |
| **B-07** | Contribution-Gated Growth | Growth is gated on contribution capacity, not on demand. **Why:** growth beyond capacity is a queue | NO — proposed | YES-DISCIPLINE | — | **YES — P-06** | **[S-D: XG-1…XG-8, Rule D-43]**; **[S-E: GATE E0…E7, Rule E-166]** | Demand outruns delivery; decline rate rises; refusals are experienced as betrayal |
| **B-08** | Volunteer True-Cost Accounting | Costs volunteering in supervision, verification, training and administration hours. **Why:** a volunteer is not free | NO — proposed | YES-BUILD | Accounting | **YES — P-08** | `H_gov`; `σ_max` | Volunteer numbers rise while net capacity falls — the classic scale failure |
| **B-09** | Paid/Volunteer Boundary Rules | Requires the paid/voluntary boundary to be **published**, with seven rules. **Why:** ambiguity is read as bad faith by the person who expected payment | NO — proposed | YES-BUILD (publication) | Labour, consumer | **YES — HM-11** | **[S-C: PM-4]**; **[S-E: Rule E-120, MC-6]**; **LDR-U09** | MC-6 "job portal / scheme" — rated **High**; material harm to a low-income person |
| **B-10** | Capacity Ceiling and Demand Referral | Sets `P_max` and requires referral beyond it. **Why:** an unlimited promise is a broken promise | NO — proposed | YES-DISCIPLINE | — | **YES — P-09, P-14** | **[S-E: Rule E-5, E-92]** well-delivered decline | Over-promise at intake; HM-14 promises-kept collapses |
| **B-11** | Idle Capacity Doctrine | Permits and plans for idle capacity rather than treating it as waste. **Why:** a system with zero slack has zero shock absorption | NO — proposed | YES-DISCIPLINE | Accounting | **YES — P-11** | B-04, B-15 | The first shock — **E_shock / HC-*** — becomes an existential event |
| **B-12** | Trust-to-Demand Conversion Path | Models how trust becomes demand. **Why:** demand is the input to the economic model and it is not exogenous | NO — proposed | YES-DISCIPLINE | — | **YES — P-14, HM-1, CI-15** | **[S-E: Part 19, Rule E-87]** | Demand is assumed rather than observed; the model is unfalsifiable |
| **B-13** | Collection Terms Standard | Fixes collection terms and ageing measurement. **Why:** revenue recognised but not collected is not revenue | NO — proposed | YES-BUILD | Accounting, financial controls | **YES — P-05** | Entity structure; bank mandate **A-B9** | Cash-flow failure with a healthy ledger |
| **B-14** | Two-Track Venture Strategy | Separates anchored contracted revenue from opportunistic work. **Why:** only the first can fund priority 1 reliably | NO — proposed | YES-DISCIPLINE | Commercial, accounting | **YES — P-03, P-04** | **[S: Ch.17]** venture approval; **[S-E: Rule E-18]** separate trading names | The venture portfolio is all opportunistic and priority 1 depends on luck |
| **B-15** | Reserve and Shock Governance | Governs reserve release and shock response. **Why:** a reserve without a release rule is not a reserve | CONSTRAINS v1.2 Ch.18 | YES-BUILD | Accounting, governance | **YES — P-10, P-11** | **A-N15 custody of reserves `UNRESOLVED`**; A-14 §13.3 reserved matters | Reserves are released by whoever is loudest, or never released |
| **B-16** | Layered Support Doctrine | Defines what the City/State layer supplies and when. **Why:** a local unit cannot carry every function | NO — proposed | YES-DISCIPLINE | — | **YES — P-12, P-15** | **[S-B: B-21]**; `H_gov_per_team(K)` **LDR-U14 `UNRESOLVED`**; **[S-D: Rule D-103]** | The local unit absorbs every function and `H_gov` exceeds `σ_max` |
| **B-17** | Definition of "Repeatedly" | Fixes what "repeatedly" means in the source's continuity language. **Why:** an undefined adverb is unauditable | NO — proposed | YES-DISCIPLINE | — | **YES — P-13** | **[S-D: LM-2, CT-A/B/C]** | Continuity is claimed without a definition and cannot be tested |
| **B-18** | Succession-Neutral Promotion (six mechanisms) | Makes promotion succession-neutral so a team is not hollowed out by its own success. **Why:** the winning team loses its best people | NO — proposed | YES-BUILD | Governance | **YES — LM-14, LM-1** | **[S-D: L-09 PT-1…PT-9]**; A-14; **LDR-U04** | The strongest team is systematically dismantled by promotion; attrition follows |
| **B-19** | Local Interim Authority Order | Provides interim authority at the local level. **Why:** A-14 covers the apex only | NO — proposed | YES-BUILD | Governance | **YES — LM-5** | A-14; **[S-D: L-10 TL-1…TL-5, Rule D-102]** | A local vacancy becomes a local collapse |
| **B-20** | Minimum Viable Control Set (MVC-1…MVC-11) | Fixes the smallest control set that may not be deferred, plus the automate-or-retire discipline. **Why:** control effort is bounded by `σ_max` | NO — proposed | YES-BUILD | Governance, financial controls | **YES — P-01, LM-12** | `σ_max` **`UNKNOWN`**; **[S-D: MVLS-1…MVLS-12, Rule D-52]** | Controls are added until governance exceeds delivery; or controls are skipped until an integrity failure occurs |
| **B-21** | City Shared Services Contract | Contracts the City layer's services to teams. **Why:** the City divisor determines whether a State layer is arithmetically possible | NO — proposed | YES-BUILD | Governance, accounting | **YES — P-15** | **LDR-U14 City divisor `UNRESOLVED`; LDR-U15 `K_min` `UNRESOLVED`**; **[S-D: Rule D-91, Rule D-103]**; **[S-E: Rule E-138]** | A State layer is authorised on a divisor measured in one environment type, and collapses |
| **B-22** | Health Panel with Veto Gates | Gives health a veto at defined gates. **Why:** burnout is detected by the person least able to report it | NO — proposed | YES-BUILD | Occupational health, employment | **YES — LM-6** | **[S-D: L-25 LLI/LDI, LV-21]** | Burnout arrives as resignation rather than as a signal |
| **B-23** | Density-First Growth Rule | Requires density before spread. **Why:** a dispersed network cannot verify, support or supervise itself | NO — proposed | YES-DISCIPLINE | — | **YES — P-06** | **[S-D: XG-1…XG-8, Rule D-37 density reported never targeted]**; **[S-E: GATE E4]** | Spread without density; every unit is alone; verification is impossible |
| **B-24** | Service Continuity Instrument | Guarantees continuity of open commitments through a unit failure. **Why:** the people harmed by a closure are the ones with an open commitment | NO — proposed | YES-BUILD | — | **YES — P-14** | A-14; B-19; **[S-D: SS-0…SS-5, Scenario D]**; **[S-E: Rule E-176]** | A unit closes and the households it served are never told |
| **B-25** | Risk-Proportionate Integrity Controls | Scales integrity controls to risk rather than applying them uniformly. **Why:** uniform controls exceed `σ_max` at small scale | NO — proposed | YES-DISCIPLINE | Financial controls, audit | **YES — P-01** | B-20; `σ_max`; **[S: Ch.27]** | Controls are either unaffordable or absent |
| **B-26** | Explicit Hybrid Funding Map | Maps which activities are funded by revenue, by contribution, by reserve and by nothing. **Why:** the architecture has no revenue line for service, governance, training or communication | NO — proposed | YES-BUILD | Accounting, tax | **YES — P-07, P-10** | **LDR-U17 economic blueprint never attached**; **[S-E: EA-E1 communication unfunded]**; 12A/80G **[X][V]** | Activities are performed with no funding source, which means they are performed by unpaid people until they stop |
| **B-27** | Service/Commerce Separation Rules | Separates the service identity from commercial activity. **Why:** the tension is structural, not disciplinary | CONSTRAINS v1.2 Ch.17 | YES-DISCIPLINE | Consumer, tax | **YES — P-03, HM-11** | **[S-ST: §17.2, §17.3 mission balance]**; **[S-E: Rule E-18, E-119a]** | MC-5 "they use charity to get clients"; mission displacement becomes structural before it becomes visible |

---

## II.4 v1.3-C amendments — H-01 … H-28

| ID | Amendment | What changed / why | In arch. | Impl. | Val. | Pilot | Deps / constrained by | If ignored |
|---|---|---|---|---|---|---|---|---|
| **H-01** | Four-Door Participation Model | Purpose · Proof · Livelihood · Building as four separate entry propositions. **Why:** there is no single reason and a single message misleads three of the four audiences | NO — proposed | YES-DISCIPLINE | Consumer (Door 3 claims) | **YES — HM-11** | **[S-E: Rule E-15, E-23]**; B-09; B-14 | One message is used for everyone; the livelihood door is implied where no funded venture exists |
| **H-02** | Nine-Level Participation Spectrum | Observer → Community Participant → Contributor → Volunteer → Specialist → Verified Member → Coordinator → Leader → Builder. **Why:** the architecture's only visible entry was membership | CONSTRAINS v1.2 Ch.12 | YES-BUILD | — | **YES — HM-4, HM-15** | **[S-E: Rule E-14 low-level is complete]** | Verification is weakened or participation is all-or-nothing |
| **H-03** | Public Local Page | A public local record per locality. **Why:** **[S-ST: §20.3]** — "requires a public local page, **not in the current architecture**" | NO — proposed | YES-BUILD | Privacy | **YES — PS-E1, CI-15** | **[S-E: PLR-1…PL-7, E-16]**; A-17 classification; entity structure | The first available action remains "apply for membership" — integrity-first and conversion-fatal |
| **H-04** | First-Ten-Seconds Standard | A standard for what a stranger can determine in ten seconds. **Why:** the current architecture **fails 4 of 5** **[S-ST: §20.1]** | NO — proposed | YES-DISCIPLINE | Cultural, consumer | **YES — CI-2** | **[S-E: E-15 eight-question test]**; terminology register | Misclassification by default; the observer supplies the worst available category |
| **H-05** | First-Five-Minutes Experience | Value before vetting; contribution before commitment; a person before a process. **Why:** nothing in the current first five minutes gives value | NO — proposed | YES-BUILD | Privacy | **YES — PS-E3, HM-4** | H-03; **[S-E: E-16, E-80, E-81]** | The gate precedes the value; the person never reaches a task |
| **H-06** | Paired First Task | A first task performed alongside two existing members, ending with a mandatory scripted statement that nothing further is expected. **Why:** the alternative is a first task that becomes a recruitment conversation | NO — proposed | YES-BUILD | Safeguarding (minors) | **YES — HM-5, HM-9, PS-E4** | **[S-E: FW-1…FW-6]**; H-02; H-22 | The two members become recruiters and destroy the win |
| **H-07** | No-Forced-Progression Rule and Six Endpoints | No level is a probation for the next; six legitimate endpoints. **Why:** forced progression converts a service into a funnel | NO — proposed | YES-DISCIPLINE | — | **YES — HM-12** | **[S-E: Rule E-85, E-86]** | Every stage is experienced as an incomplete journey; pressure to advance |
| **H-08** | Recognition Taxonomy | Six instruments — appreciation, proof, credential, responsibility, compensation, promotion — **never collapsed into one leaderboard**. **Why:** collapse creates a single status market | CONSTRAINS v1.2 Ch.25 | YES-BUILD | — | **YES — HM-10** | **[S-C: §23.2]** "a person is never scored"; **[S-D: L-24, Rule D-66]**; **LDR-U11 leaderboard publicity `UNRESOLVED`** | Popularity becomes the currency; Goodhart at scale |
| **H-09** | Verified Contribution Record | A narrative, non-ordinal record of contribution. **Why:** "the most valuable and least developed asset in the architecture" **[S-ST: §19.2]** | NO — proposed | YES-BUILD | Privacy, entity | **YES — HM-5, HM-6** | A-17, A-18; **[S-C: CR-1…CR-4]**; **[S-E: PO-1…PO-5]** | The record is not portable, not checkable, and yields no value |
| **H-10** | Portable Credentials | Absolute (never comparative) credentials against a published standard. **Why:** a credential nobody outside accepts is a souvenir | NO — proposed | YES-BUILD | **Regulated-profession bodies; entity counsel (HV-5, HV-6)** | NO — needs ≥2 localities | **[S-E: E-41 Stage 3, Rule E-201, MAF-26]**; **[S-D: L-11, LV-24, Rule D-48]** | Certification without a standard becomes a loyalty ritual; or a credential is issued that misrepresents scope |
| **H-11** | Specialist and Elder/Mentor Paths (S1…S6) | Twelve domains with hard limits; Elder/Mentor excluded from RBAC command and from scoring. **Why:** "a path with no economic expression is a hobby" | CONSTRAINS v1.2 Ch.9 | YES-BUILD | Regulated professions | **YES — HM-10** | **[S-D: SP-1…SP-6, L-11]**; **[S-E: E-205…E-210]**; HV-5 | Specialists are conscripted into command; or the path exists on paper and produces nothing |
| **H-12** | Friendship Infrastructure | Designs for relationships rather than for attendance. **Why:** companionship without contribution is a club; contribution without companionship burns out | NO — proposed | YES-DISCIPLINE | — | **YES — HM-3** | **[S-E: Part 5 stage 5]** | Belonging is asserted rather than produced; retention fails silently |
| **H-13** | Rituals Under Six Tests | Any ritual must pass six tests before adoption. **Why:** rituals drift toward loyalty objects | NO — proposed | YES-DISCIPLINE | Cultural, political | **YES — vocabulary and artefact audit** | **[S-A: A-05 clause 6]**; **[S-D: Part 21 §21.7 refused oaths and insignia]**; **[S-E: Rule E-144 no national date, E-33]** | A loyalty ceremony is adopted for aesthetic or morale reasons and becomes a cult vector |
| **H-14** | Story Framework | Problem → people → contribution → action → outcome → learning. **Why:** the default story form is saviour grammar | NO — proposed | YES-DISCIPLINE | Privacy, media | **YES — CI-14** | **[S-E: ST-1…ST-8, Rule E-145 attribution grammar]**; A-19 | Beneficiaries become props; MC-9 rated **High** |
| **H-15** | Attribution and Follow-Up Loop | The outcome is returned to the contributor inside a stated window. **Why:** "the most damaging break in the loop" **[S-C: §27.2]** | NO — proposed | YES-BUILD | — | **YES — HM-7, HM-8** | **[S: Ch.15 step 10]**; **[S-E: Part 5 stage 4]** | Under-attribution becomes the default; the person concludes their hour did not matter |
| **H-16** | Community Experience Charter | States what a participant may expect. **Why:** an expectation that is not stated cannot be met deliberately | NO — proposed | YES-BUILD | Consumer, entity (HV-6) | **YES — HM-14** | H-03; A-17 | Promise–reality mismatch — **[X]** a leading stated reason volunteers leave |
| **H-17** | Rights of Refusal and Exit with Dignity | Seven refusal rights and a dignified exit. **Why:** a right that cannot be exercised politely is not a right | NO — proposed | YES-BUILD | Employment, privacy | **YES — HM-12** | **[S-E: Rule E-163, E-165 published refusal scripts in every operating language]**; H-18 | Exit is socially costly; paused people are marked inactive; retention is measured by lock-in |
| **H-18** | Paused and Alumni Status | Pausing carries no penalty; alumni retain their record. **Why:** seasonal migration and care responsibilities are structural, not personal failures | NO — proposed | YES-BUILD | Privacy, employment | **YES — HM-12** | **[S-ST: §12.2]** Rajasthan row — "paused status is not a nicety but a necessity" | Capable people exit permanently for a temporary reason |
| **H-19** | Anti-Cult Safeguard Instrument | Controls on leader worship, inner circles and personality dependence. **Why:** affection converts into authority unless constrained | NO — proposed | YES-DISCIPLINE | Governance | **YES — LM-15** | **[S-A: A-16 §15.4]**; **[S-D: CU-1…CU-10, L-19]**; **[S-E: AC-1…AC-9, E-35]** | Personality cult; **[S-ST: §11.1]** the institution and the person become the same object |
| **H-20** | Psychological Safety Instruments | Makes it safe to report failure and dissent. **Why:** fear-driven reporting hides exactly the information the system needs | NO — proposed | YES-BUILD | Employment | **YES — LM-11 honest-reporting latency** | **[S-ST: F-19]**; **[S-D: Part 18 non-retaliation with reversed burden]**; **[S-A: A-15 M5]** | Failures are hidden until they are catastrophic |
| **H-21** | Anti-MLM Compensation Firewall | No compensation may be a function of another person's participation. **Why:** the structure, not the currency, is what makes an MLM | CONSTRAINS v1.2 | YES-DISCIPLINE | Labour, consumer | **YES — formula audit** | **[S-D: Rule D-118, L-35]**; **[S-E: Rule E-24, E-135, E-159, E-162]** | Growth becomes recruitment; the organisation acquires an MLM reputation without ever paying a commission |
| **H-22** | Beneficiary/Recruitment Separation | The person helped is never a recruitment prospect. **Why:** recruitment at the moment of vulnerability is the single prohibited act the architecture names absolutely | CONSTRAINS v1.2 Ch.15 | YES-DISCIPLINE | Safeguarding, privacy | **YES — PF-E3** | **[S-C: H-03]**; **[S-E: Rule E-13, §38.3 no pathway exists at all]**; A-19 | Help becomes conditional in appearance; the service identity becomes an extraction mechanism |
| **H-23** | Flexible Participation Modes | Participation adapts to shifts, care responsibilities and season. **Why:** a fixed model excludes everyone with obligations | NO — proposed | YES-BUILD | Employment | **YES — HM-4** | **[S-E: Part 15 AX-series]** | The able population is limited to those with discretionary daytime hours |
| **H-24** | Remote Participation Architecture | Full L2→L8 progression without physical presence. **Why:** the most productive contributors may be the least local | NO — proposed | YES-BUILD | Employment, privacy, technology | **YES — HM-7 measured specifically for remote contributors** | **[S-E: Part 53]**; A-17 | Remote contributors are the most productive and the most likely to leave silently |
| **H-25** | Language Architecture (L1/L2/L3) | Constitutional-legal / operational / cultural-expressive layers; one authoritative text per language; no publication without review. **Why:** "a person who cannot read the invitation cannot accept it" — a **hard exclusion** | NO — proposed | YES-BUILD | **Legal per language (HV-1/H10)** | **YES — CI-6, CI-7** | **[S-A: A-05 clause 8 names language architecture as out of scope]**; **[S-E: LA-1…LA-5, Rule E-66, E-67, E-68]** | A language hierarchy inside the organisation becomes a status hierarchy among members |
| **H-26** | Layered Identity | Five rules; the six-layer sentence test; two-way flow; **the national layer supplies capability, not identity**. **Why:** local belonging and national connection must both be felt without uniformity | NO — proposed | YES-DISCIPLINE | Cultural, political per state | **YES — locality attribution** | **[S-E: E-10, Rule E-3, E-55, E-57]**; A-05 | The centre becomes the hero; "national capability deployed locally" becomes central control in a helpful costume |
| **H-27** | Youth and Elder Participation Rules | Age-appropriate participation with guardian consent and the two-adult rule; Elder/Mentor standing. **Why:** minors and elders are the two groups most easily exploited and most easily excluded | NO — proposed | YES-BUILD | **Safeguarding (HV-2)** | **YES** | **A-B6 BLOCKER certified safeguarding**; **[S-E: Rule E-121, E-122, Part 28]**; **[S-D: LV-17, LV-23]** | A minor is harmed, or is used as an image, or is treated as a pipeline |
| **H-28** | Human-System Measurement and Pilot | **HM-1…HM-15** in the same single shared pilot. **Why:** the human system is the least measurable and the most load-bearing | NO — proposed | YES-BUILD | — | **This IS the pilot measurement set** | **[S-B: §40]**; **[S-D: Rule D-130]**; **[S-E: Rule E-222]** | The human system is asserted rather than measured; adoption is assumed |

## II.5 v1.3-D amendments — L-01 … L-40

| ID | Amendment | What changed / why | In arch. | Impl. | Val. | Pilot | Deps / constrained by | If ignored |
|---|---|---|---|---|---|---|---|---|
| **L-01** | Eligibility and Readiness Separation (Gate E / Gate R) | Two gates, separately evidenced, decided, recorded and appealed; **Gate R assessed out of team**. **Why:** a promotion can be legitimate and still be wrong | CONSTRAINS v1.2 Ch.11 | YES-BUILD | Leadership-selection (LV-1) | **YES — LM-1** | **[S-D: ES.5]**; **[S-E: GATE E1]** | The strongest worker is promoted and the team collapses |
| **L-02** | Leadership Capability Model (LC-1…LC-20) | Twenty dimensions with GATED / SCORED / MONITORED / NARRATIVE treatment rather than one composite. **Why:** seven of the twenty are invisible to the existing team score | CONSTRAINS v1.2 Ch.25 | YES-BUILD | Human-factors (LV-2) | **YES** | **[S-C: §23.2]** "a person is never scored"; **LDR-U03 weights `NOT FINAL`** | Capability is inferred from activity volume and popularity |
| **L-03** | Leadership Evidence Model (LE-1…LE-5) | Five evidence classes with an admissibility rule per decision type, nine prohibited evidence types, and a self-assembled portfolio. **Why:** what may legitimately promote someone was undefined | NO — proposed | YES-BUILD | — | **YES — LM-1** | L-01, L-02; **[S: App. F]** | Seniority, revenue, popularity and volume become evidence by default |
| **L-04** | Performance Gate Architecture (PG-1…PG-12) | Hard gates that void *status*, never payment and never dignity. **Why:** a high score must be refus­able without harming the person | CONSTRAINS v1.2 Ch.25/26 | YES-BUILD | — | **YES** | **[S: Ch.26]** "a high score is void if fraud, safety breach or manipulation is found"; **[S-D: INV]** | Either a fraudulent high score promotes, or a gate punishes the person rather than the status |
| **L-05** | Outcome Windows, Confidence and Honesty Scoring | Four windows — activity, outcome, sustainability, correction; two-speed scoring; an activity cap; **honesty of failure reporting scored**. **Why:** activity volume is not impact | CONSTRAINS v1.2 Ch.25 | YES-BUILD | — | **YES — LM-11** | **[S-ST: F-20]**; **[S: App. A §16.3]** honest failure reporting | Activity is optimised; failures are hidden; the record looks better than the reality |
| **L-06** | Cohort Normalisation (CN-1…CN-7) | Cohorts assigned from records, never elected; raw and normalised views both retained. **Why:** a mature team in a low-demand area and a new team in a high-demand one cannot share one board | NO — proposed | YES-BUILD | — | **NO — `SKIP-NT` a cohort of one is not a cohort** | **[S-ST: F-19]**; **[S-D: Part 41 §41.2]** | Relative performance punishes the hard context and rewards the easy one |
| **L-07** | Baseline, Maturity and Provisional Status | Baselines locked once recorded; maturity bands; provisional status with a hard expiry. **Why:** newness is either punished or permanently excused | NO — proposed | YES-BUILD | — | **YES** | L-06; **[S-D: Part 8]** | New teams are permanently excused or permanently behind |
| **L-08** | Succession State Model (SS-0…SS-5) | Every covered role carries a *state*, not a pathway; mandatory state by role class; **SS-0 is a reported organisational risk**. **Why:** the source has a `succession_status` field and no obligation attached to it | CONSTRAINS v1.2 Ch.22 | YES-BUILD | — | **YES — LM-1** | **[S-A: A-16 test 4]**; **[S-B: B-18]**; **[S-D: LDR-C18]** | Every departure is an emergency; continuity is documented rather than real |
| **L-09** | Promotion Transition Protocol | Successor-before-transition; bounded overlap; bounded mentorship; promotion-cohort reporting; a Promotion Decision Record; eight tie-breaks and a prohibited-tie-break list. **Why:** promotion hollows out the winning team | CONSTRAINS v1.2 Ch.26 | YES-BUILD | Governance | **YES — LM-14** | **[S-ST: F-24]**; **[S-B: B-18]**; **LDR-U04 transition rules `NOT FINAL`** | The strongest team is dismantled by its own success |
| **L-10** | Temporary Leadership Instruments (TL-1…TL-5) | Acting, Interim, Emergency, Delegated, Permanent — each with scope, start, end condition, authority limit and review; **all expire; reserved matters excluded absolutely**. **Why:** interim authority without an end date becomes permanent | CONSTRAINS v1.2 Ch.10/11 | YES-BUILD | Governance (LV-9, LV-10) | **YES — LM-5** | **[S-A: A-14 §13.3]**; **[S-B: B-19]**; **[S-D: Rule D-102]** | An acting holder exercises a reserved matter, or never stops acting |
| **L-11** | Triple Career Architecture | Leadership, Specialist (SP-1…SP-6 with authority ceilings) and Builder, plus the Contributor endpoint and Elder/Mentor standing, under an explicit no-track-superiority rule. **Why:** the only visible path upward is command | CONSTRAINS v1.2 Ch.9 | YES-BUILD | Regulated professions | **YES — HM-10** | **[S-C: H-11]**; **[S-E: E-205…E-210]**; **[S-ST: F-24]** | Capable people who do not want to command leave; attrition concentrates exactly where capability is scarcest |
| **L-12** | Development Programme and Authority Formation | DV-1…DV-5 including **Authority Formation** with twelve capabilities AF-C1…AF-C12 and demonstration methods; **mentorship as paid work**. **Why:** authority is the capability nobody trains and everybody assumes | NO — proposed | YES-BUILD | Human-factors (LV-2) | **YES** | **[S-D: Rule D-47 paid trainer time]**; trainer supply is the binding constraint **[S-ST: Scenario B]**; **no hour counts are invented** | Leaders are selected on delivery performance and given authority they have never exercised |
| **L-13** | Review Types and Decomposed 360 | RV-1…RV-4 never merged; reviewer independence; skip-level; **360 rejected as a scored instrument and adopted as three decomposed ones**. **Why:** a scored 360 creates a popularity market | CONSTRAINS v1.2 Ch.24/25 | YES-BUILD | Human-factors | **YES — LM-9** | **[S-D: Rule D-50 out-of-team]**; **[S-E: CI-13]** | Popularity becomes the measurement; the unpopular competent person is filtered out |
| **L-14** | Succession as a Performance Dimension | Coverage as a gate; readiness and exercised delegation assessed at RV-3; **no new weight added to the PROPOSED source weighting**. **Why:** replaceability is a duty, not a virtue | CONSTRAINS v1.2 Ch.25 | YES-DISCIPLINE | — | **YES — LM-1, LM-2** | **LDR-U03 weights `NOT FINAL`** — deliberately not altered | Leaders hoard knowledge; succession is a slogan |
| **L-15** | Leadership Compensation Structure | Leadership work itemised and paid; allocation bounded and capped; delivery paid separately; **no premium for indispensability**. **No multiplier proposed** | CONSTRAINS **[S: App. A §15.3]** | YES-BUILD | Labour, tax, accounting (LV-7) | **YES — LM-13** | **LDR-U02 `m_lead` `NOT FINAL`; LDR-U16 founder compensation `UNRESOLVED`; LDR-U09 classification `UNRESOLVED`** | Leadership is unpaid and becomes a wealth privilege; or indispensability is paid for, which manufactures dependency |
| **L-16** | Role Playbook and Relational Memory | PB-1…PB-10, **tested not filed**; relational memory captured at transition with consent and minimisation. **Why:** a playbook nobody has used is a document, not a capability | NO — proposed | YES-BUILD | Privacy | **YES — CT-B, LM-2** | **[S-A: A-15 M2, M6]**; **[S-D: Part 28]**; **[S-E: Rule E-211 conditions travel with the solution]** | A vacancy exposes that the role was a person, not a function |
| **L-17** | Transition Access Protocol | TA-0…TA-4 and TA-a…TA-h; no overlapping write authority; bounded advisory access; suspended and removed holders hold nothing; sealed audit log. **Why:** transition is the highest-risk window in any access system | CONSTRAINS v1.2 Ch.23 | YES-BUILD | Technology, privacy (LV-25) | **YES — LM-2** | **[S-A: A-14 §13.4 dual custody]**; **[S-E: Rule E-188]**; A-20 | A departing holder retains access; or a successor and predecessor both hold write authority |
| **L-18** | Anti-Gaming Register and Goodhart Prohibition List | GF-1…GF-30; the Goodhart Prohibition List; the two-independent-signal rule. **Why:** any metric that becomes a target stops measuring | CONSTRAINS v1.2 Ch.25 | YES-DISCIPLINE | — | **YES** | **[S: Ch.25]** eight anti-gaming controls; **[S-E: Rule E-106 vanity metrics]** | The record improves while the work does not |
| **L-19** | Cult Resistance Controls (CU-1…CU-10) | No person as organisational identity; no loyalty object; attribution discipline; dissent counted; replaceability as a duty; **the founder bound**. **Why:** affection becomes unaccountable authority | NO — proposed | YES-DISCIPLINE | Governance | **YES — LM-15** | **[S-A: A-16]**; **[S-C: H-19]**; **[S-E: AC-1…AC-9]** | Founder worship; **[S-ST: §11.1]** no way to defend the institution by separating it from the person |
| **L-20** | Continuity Testing (CT-A/B/C) | Delegation exercise, playbook exercise, unannounced 72-hour test; **unexercised counts as absent**; a failure is a governance finding, not a person finding. **Why:** false continuity is invisible until exercised | CONSTRAINS **[S-A: A-14 §13.8]** | YES-BUILD | — | **YES — LM-2** | A-14; L-16; L-17; **[S-A: A-L2 full-scope test is LATER]** | Written continuity instruments are assumed to work |
| **L-21** | Minimum Viable Leadership System (MVLS-1…MVLS-12) | Twelve items non-deferrable at any stage; everything else tiered; **a deferral is a recorded risk**. **Why:** the smallest leadership system that can safely run one mohalla had not been defined | NO — proposed | YES-BUILD | — | **YES** | **[S-B: B-20 MVC-1…MVC-11]**; `σ_max` | Either everything is required and nothing happens, or the twelve essentials are lost among the optional |
| **L-22** | Pipeline and Expansion Gate (XG-1…XG-8) | Density reported but never publicly targeted; span basis declared; **expansion recorded as a cost**. **Why:** growth that hollows out the organisation that grows | CONSTRAINS v1.2 Ch.30 | YES-BUILD | — | **YES — LM-14** | **[S-B: B-07, B-23]**; **[S-E: GATE E0…E7, Rule E-214 conjunctive]**; **LDR-U06 minimum staffing `NOT FINAL`; no span number exists anywhere** | Expansion is authorised on demand or attention rather than on capacity |
| **L-23** | Complaints, Appeals, Improvement and Removal | CR-1…CR-4, IP-1…IP-7, RM-1…RM-10; four routes that may never substitute for one another; **non-retaliation with the burden reversed**; no removal from a score. **Why:** **[S-ST: M10]** required an Integrity Line, an ombuds and skip-level | CONSTRAINS v1.2 Ch.14/27 | YES-BUILD | Employment, safeguarding (LV-3…LV-6) | **YES — LM-9, LM-10 (`SKIP-NT`)** | **[S-E: E-190…E-195 whistleblowing]**; A-20 sealed categories | A grievance has no route except exit; retaliation is undetectable |
| **L-24** | Leaderboard Scope and Recognition–Authority Separation | Permitted and prohibited uses enumerated; fatigue mechanisms; measurement retirement; **recognition confers nothing**; **R5 left open**. **Why:** the brief required a leadership system, not a leaderboard | CONSTRAINS v1.2 Ch.25 | YES-DISCIPLINE | — | **YES** | **LDR-U11 `UNRESOLVED`; [S-ST: R5]**; **[S-C: H-08]**; **[S-E: Rule E-106]** | Recognition becomes authority; popularity becomes promotion |
| **L-25** | Load and Dependency Indices (LLI / LDI) | Organisational resilience measures in bands, **never personal scores**; `H_unrecorded` as the primary overload signal. **Why:** overload is felt but never measured | NO — proposed | YES-BUILD | Occupational health (LV-21) | **YES — LM-6, LM-7** | **[S-B: B-22 health panel]**; `H_gov` | Burnout arrives as resignation rather than as a signal |
| **L-26** | AI-Assisted Leadership Boundary (AI-1…AI-8) | Permitted and prohibited function table; fairness controls; the stranger test for explainability; **historical bias never used as prediction labels**. **Why:** **[S-ST: F-29]** rubber-stamping | CONSTRAINS **[S: Const. Art.12]** | YES-BUILD | Technology, privacy (LV-15, LV-16) | NO — no AI in the pilot | A-21, A-22; **[S-E: Rule E-133]**; **Rule D-107 `UNVALIDATED`** | AI becomes the judge; a biased history becomes a prediction |
| **L-27** | Opportunity Fairness and Access (OB-1…OB-7, AX-1…AX-9) | Access corrections are not favouritism; a mandatory specific-feedback obligation to every non-selected applicant; the four-affordance route for the unpopular competent person. **Why:** eligibility on paper is unequal in practice | NO — proposed | YES-BUILD | Equality, privacy (LV-13) | **YES — LM-8 (`SKIP-NT`)** | **[S-D: ES.5]**; **[S-E: Part 25, Part 51]**; **A-N5 composition monitoring `UNRESOLVED`** | The locally popular are selected and the record calls it earned |
| **L-28** | Staffing, Span and Function Routing | `n_min` as a five-condition set with **no number invented**; held-versus-routed; **the City divisor must be measured before State formation**. **Why:** minimum staffing is `NOT FINAL` in the source and no span number exists anywhere | NO — proposed | YES-BUILD | Governance | **YES — LM-12** | **LDR-U06, LDR-U13 `c`, LDR-U14 divisor, LDR-U15 `K_min` — all `UNRESOLVED`**; **[S-B: B-16, B-21]** | Functions are held locally until `H_gov` exceeds `σ_max`, or routed upward until the local unit is hollow |
| **L-29** | Founder Concentration and Institutional Independence | Founder Recusal Register; **the founder may not assess**; the four annual tests applied with counts published internally; interim reserved-matter procedure. **Why:** **[S-ST: F-14, F-15]** | CONSTRAINS **[S-A: A-16]** | YES-BUILD | Governance | **YES — LM-15** | A-12, A-16; **LDR-U01, LDR-U19**; **[S-D: Rule D-92, D-93, D-113]** | The founder assesses the people the founder appointed; the four tests return zero and nobody notices |
| **L-30** | Privacy and Data Classification for Leadership Records | Every new data type classified; small-cell suppression with suppression itself reported; the six-condition social-credit test. **Why:** leadership records are the most sensitive personal data the organisation creates | CONSTRAINS **[S-A: A-17]** | YES-BUILD | Privacy (LV-11, LV-14) | **YES** | A-17…A-20; **LDR-U10 retention `UNRESOLVED`**; **[S-E: Rule E-100, E-199]** | A universal human score emerges by aggregation; a small cell identifies a person |
| **L-31** | Multi-Level Leadership Differentiation | Per-level evidence, capability and assessment-independence obligations; staged obligations S0…S5; **a deferred control is a recorded risk**. **Why:** one model cannot serve four levels | NO — proposed | YES-DISCIPLINE | — | NO — needs multiple levels | **[S-ST: §23.1, §23.2]**; **[S-E: ML-series, Rule E-20]** | Mohalla rules are applied to National decisions, or National rules crush a mohalla |
| **L-32** | Selection Typology and Democracy of Voice | Five acts distinguished — promotion, appointment, delegation, succession, recognition; act typing recorded with ambiguity resolved to the least consequential type; **strong voice rights, deliberately weak selection rights**. **Why:** democracy and efficiency were treated as one question | NO — proposed | YES-DISCIPLINE | Governance | **YES** | **[S: Ch.11]**; **[S-E: Part 33]**; **LDR-U04** | An appointment is experienced as an election that was not held; or an election is used where competence is the criterion |
| **L-33** | Governance Bodies, RACI and Interim Reserved-Matter Procedure | Authority map with every unresolved point marked; **five bodies retained and five refused**; **CEO-vs-Council not resolved**. **Why:** seven reserved matters had no determined holder | CONSTRAINS **[S: App. E]** | YES-BUILD | Governance (LV-8, LV-9) | **YES — LM-3** | **LDR-U01, LDR-U12 `AUTHORITY UNRESOLVED`**; **[S-A: A-N19, A-I3]**; **[S-D: Rule D-113]** | A reserved matter arises and nobody is authorised to decide it |
| **L-34** | Conflict of Interest and Anti-Favouritism | Declaration before participation; recusal on the matter, not removal from the role; **recusal is not suspicion**; opportunity-allocation recording. **Why:** the favouritism that leaves no record | CONSTRAINS v1.2 Ch.28 | YES-BUILD | Employment, governance | **YES — LM-8 (`SKIP-NT`)** | **[S-A: A-02]**; **[S-D: Rule D-116]**; **[S-E: Rule E-164]** | Favouritism operates through opportunity allocation and is invisible in every record |
| **L-35** | Anti-Capture Controls — MLM, Vigilante, Political | No compensation may depend on another person's participation; VG-1…VG-6; PC-1…PC-8 **preserving members' civic rights**. **Why:** three capture vectors, one instrument | CONSTRAINS **[S-A: A-01, A-06; S-C: H-21]** | YES-DISCIPLINE | Legal, criminal | **YES** | **[S-E: Parts 36, 39, 40]**; A-08 | Capture by a political actor, a vigilante incident, or an MLM structure |
| **L-36** | Crisis Leadership and Incident Review | **Standards are not suspended in a crisis, only sequence**; a mandatory missing-information field; blameless by default and accountable by record. **Why:** hindsight bias is an institutional selection pressure | CONSTRAINS **[S-A: A-09]** | YES-DISCIPLINE | — | **YES — LM-11** | A-09; **[S-E: CC-1…CC-8, Rule E-177]** | Crisis decisions are punished retrospectively, so future leaders conceal during crises |
| **L-37** | Leadership Economics and Feasibility | An eighteen-component cost structure, five findings, six sustainability tests, and **unpaid leadership work recorded as an organisational deficit**. **Why:** the cost is dominated by assessment, development and trainer time, and nobody had budgeted it | NO — proposed | YES-BUILD | Accounting, labour | **YES — LM-13** | **[S-B: §24, §24.5]**; **LDR-U02 `m_lead`**; **Rule D-126 deficit** | Leadership is funded by the leader's unpaid time; affordability for a poor person fails (**[S-D: EF-5 / EA-12]**) |
| **L-38** | Maturity Model and Simplification Obligation | MAT-0…MAT-5 determined by what a unit actually operates, plus **one retirement for every addition**. **Why:** a maturity claim based on documentation is unfalsifiable, and obligation grows monotonically | CONSTRAINS **[S-ST: §23.1]** | YES-DISCIPLINE | — | **YES** | **[S-B: §26.3 automate-or-retire]**; **[S-E: Rule E-101 no reporting theatre]**; NI/MA models | Obligation grows until governance exceeds delivery; maturity is claimed from documentation |
| **L-39** | Pilot Integration and Scope Statement | LM-1…LM-15 added to the single shared pilot; twelve falsifiable success conditions; ten fatal failure conditions; **seven explicit limits on what the pilot can prove**. **Why:** the leadership claims are precisely the ones a single team cannot test | NO — proposed | YES-BUILD | — | **This IS the pilot measurement set** | **[S-B: §40]**; **[S-C: §57]**; **[S-E: Part 72, Rule E-222, E-223]** | A narrow success is reported as a general one; a second pilot is created |
| **L-40** | Leadership Invariants, Local Adaptation and Final Architecture | INV-1…INV-20 never adaptable; ADAPT-1…ADAPT-12 adaptable only via an M2/M3 change request; four interlocking loops; one master data flow. **Why:** a national system must hold some things constant and let other things vary | NO — proposed | YES-DISCIPLINE | — | **YES** | **[S-ST: §12.1]**; **[S-C: H-26]**; **[S-E: R-1…R-20, Rule E-136]** | Either invariants drift locally, or local adaptation is refused and the system is rejected |

---

## II.6 v1.3-E amendments — E-01 … E-46

**[A]** All forty-six are `PROPOSED`; **none is incorporated**. Columns are abbreviated: **Impl.** `B` = BUILD, `D` = DISCIPLINE, `B+D` = both. **Val.** cites the Part III category. **Pilot** cites the CI measurement or the reason it is not testable.

| ID | Amendment | What changed / why | Impl. | Val. | Pilot | Deps / constrained by | If ignored |
|---|---|---|---|---|---|---|---|
| **E-01** | Five-Distinction Rule and the Claim Ceiling | Recognition, membership, trust, legitimacy, brand and impact defined separately with an operable test each; the claim ceiling IMPACT→TRUST→LEGITIMACY→MEMBERSHIP→RECOGNITION→BRAND. **Why:** the five are used interchangeably, so a claim about one is read as a claim about another | D | Comms | CI-8 | Part 31 ladder; E-05, E-29, E-46 | Over-claiming is undetectable from the artefact |
| **E-02** | Every-Citizen Relationship Matrix | Twenty-five legitimate relationships, membership being one; L0–L4 are complete positions; commercial, funding, media and research relationships sit outside the spectrum. **Why:** "every Indian" is read as "every Indian must join" | D | Safeguarding (minors) | HM-12 | **[S-C: H-02, H-03]** | Recruitment pressure; twenty-five relationships collapse into one funnel |
| **E-03** | National Participation Without Membership | NP-1…NP-9; advice is not authority; money buys a receipt; commerce and service separately named; observation ungated. **Why:** no pathway existed for the things a person should be able to do without joining | B | Privacy | CI-15 | H-03; A-17, A-18 | Every pathway implies membership; hidden authority accrues to unaffiliated experts |
| **E-04** | Emotional Conditions Architecture | Eight stages as conditions with observable evidence and a prohibited message each; the emotional hierarchy with national connection last; ten prohibited registers; emotion is never a budget line. **Why:** emotion is treated as a message to send | D | Human-factors | HM-9 | **[S-ST: §10.2, §10.3]**; **[S-C: PM-1…PM-8]** | Manufactured emotion; guilt, fear and urgency become the growth mechanism |
| **E-05** | National Story and Claim Traceability | Ten story questions answered within the claim ceiling; four defensible and three prohibited claims; a claim register; facts not adjectives; labelled commitments. **Why:** the organisation can generate more evidence than it can publish | B | Comms, consumer | CI-8 | **[S-ST: §11.3, §19.2]** | Unverifiable claims are published; the differentiation is lost |
| **E-06** | Political Neutrality in Expression | Four surfaces added to **[S-A: A-01]** — adjacency, timing, vocabulary, silence; the election calendar governs the communication calendar; neutrality published not declared. **Why:** N1…N9 govern acts, not expression | D | **Legal, tax, electoral** | CI-3 | **A-01…A-04**; A-B4 BLOCKER | MC-1 Severe misclassification; tax-exempt exposure **[X][V]** |
| **E-07** | Religious Neutrality in Expression | Seven surfaces — calendar, venue, ritual, language, imagery, food, death and disaster; no religious ritual as an organisational requirement; *seva* descriptive never prescriptive. **Why:** pattern-level association arises where every act is neutral | D | Legal, cultural | CI-4 | **[S-A: A-05]** | MC-2 Severe; the organisation is classified as one faith's |
| **E-08** | Caste Neutrality and the Composition-Monitoring Refusal | Six behavioural surfaces — routing, venue and timing, naming, food, recognition, leadership composition; **no caste data for any purpose**. **Why:** caste is invisible in a record and determinative of a pattern | D | **Privacy, equality** | — | **A-N5 `UNRESOLVED — deliberately`; A-18; [S-D: Rule D-79]** | Either exclusion patterns are invisible, or an identity database is created. **Both outcomes are real and the choice is not this document's** |
| **E-09** | Regional Plurality and the Localisation Contract | Eight immutable and ten localisable items; local by default; no decision by unit count; state-level legal review where a distinct regime applies; no language senior; structural variables only. **Why:** without a positive localisable list, localisation happens silently or not at all | D | **Legal per state** | — | **[S-ST: §12.1]**; **[S-C: H-26]** | One region's norms become the unmarked national default |
| **E-10** | Layered Identity | Five rules and the six-layer sentence test carried; national is derived never primary; capability not direction; epistemic before affective. **Why:** local belonging and national connection must both be felt without coercion | D | — | Locality attribution | **[S-C: H-26]**; **[S-E: Rule E-57]** | The centre becomes the hero; national capability becomes central control |
| **E-11** | Three-Tier Brand Architecture and Parent Subordination | T1 master / T2 parent / T3 local / T4 venture; the parent named accurately in legal and financial contexts and subordinated in service contexts; no concealment on request; BR-1…BR-12. **Why:** four identities appeared together with no salience rule | D | **IP counsel** | — | **A-N12, A-N13 `UNRESOLVED`; Rule E-60 blocks national use** | The corporate owner is imported into a neighbour's lane; or ownership is concealed and discovered |
| **E-12** | Visual Identity and the Red-Colour Resolution | **The nine information colours are reserved and may not be identity colours**; no colour-only meaning; a six-question symbol test; no symbol grants authority by appearance; four permitted surfaces; ID-card constraints; the dated result board as the primary artefact. **Why:** red already means prohibition and risk inside every v1.2 document | D+B | **IP, legal, per-state political, accessibility** | — | **A-06 V1…V8; A-N12; [S: Ch.1; Ch.31 ID-card blocker]** | The organisation's colour for "prohibited" becomes its colour for "us"; MC-3 vigilante reading |
| **E-13** | Five Language Registers | LA-1…LA-5; the mandatory four-item translation set; simultaneous or not published; a terminology register per language and per state; machine translation never publishes; four error classes. **Why:** **[S-A: A-05 clause 8]** named language architecture as out of scope and **[S-C: §30]** built three layers for the human system only | B | **Legal per language** | CI-6, CI-7 | **[S-C: H-25]**; A-H10; A-17 P3 | A person is bound by, consents to, or is denied something they could not read |
| **E-14** | Accessibility Standard | Five dimensions; implemented or not claimed; every process has a human route requiring no reading, writing, device, account or fee. **Why:** accessibility is claimed more often than implemented | B | Accessibility specialist | AX-T1…T3 | **[S-C: H-23, H-24]**; **[S-D: AX-1…AX-9]**; **[S-B: §40]** no-technology pilot | A false accessibility claim is believed by exactly the people it excludes |
| **E-15** | First Contact Standard | The eight-question national test; questions 4–8 answered at first contact not on request; sequencing is not concealment with four auditable conditions; MC-1…MC-11 with detectors and first responses. **Why:** the current architecture fails 4 of 5 and the silent questions are answered by the observer | D+B | Cultural, consumer | CI-1, CI-2 | **[S-ST: §18.2, §20.1]**; **[S-C: H-04]** | Four Severe and High misclassifications form at first contact and never correct |
| **E-16** | First Five Minutes and the Public Local Record | PLR-1…PL-7, seven elements and nothing else, ungated and unadorned; the paper sheet is a complete implementation; the minimum safe pathway for a help seeker; the boundary is stated before the disclosure. **Why:** the first available action is membership application | B | Privacy | PS-E1, PS-E3 | **H-03, H-05**; **[S-ST: §20.3]** | The gate precedes the value; a help seeker discloses before learning the boundary |
| **E-17** | First Real Win, national version | FW-1…FW-6; four failure modes; **three first wins — contribution, help and verification**; the twelve-persona value proposition; media and research are not participants. **Why:** a first win that ends with an invitation is a funnel stage | B | Safeguarding | HM-5…HM-7, HM-9, PS-E4 | **[S-C: H-06]**; **[S-ST: §21.3]** | The paired task becomes a recruitment conversation; the win is destroyed |
| **E-18** | National Participation Funnel | S1…S10 with owner, precondition and prohibition; S10 is system improvement not bringing people; every stage is an exit and a destination; no conversion target ever; fourteen acquisition channels assessed. **Why:** a funnel maximises progression; this must maximise value at the stage reached | D | — | HM-9, HM-15 | **[S-C: H-07, §8.4]**; **[S-D: Rule D-37]** | A conversion target manufactures the moment of vulnerability **[S-C: H-03]** prohibits |
| **E-19** | Trust Production System | Four layers operationalised with an owner, an artefact and a test; TS-1…TS-14 public trust signals; **the correction log must not be empty and an empty log is published as an anomaly and referred to Audit**; pre-conditions 1–7 are gates; the organisation never claims to be trusted. **Why:** the architecture is strong on being trustworthy and silent on being seen to be trustworthy | B | Privacy, accounting | CI-8, CI-9, CI-12 | **[S-ST: §14.1–§14.3]**; A-17 | Invisible honesty does not compound; and the correction log stays empty |
| **E-20** | Reputation Architecture | Reality→Evidence→Transparency→Correction→Trust→Reputation→Repeat participation, against the counterfeit; reputation is downstream and never a target; RC-1…RC-4 alignment; publish the limit; the disappearance test; followers are not being missed; complement never rival; **repair reality before repairing reputation**; the rebranding test. **Why:** the counterfeit model has no arrow returning from failure to reality | D | — | CI-1 | E-01, E-19 | Brand outruns institution; the fall exceeds the rise |
| **E-21** | Four-Audience Transparency Regime | Five audiences with entitlements; three publication tests — necessity, identifiability, harm; small-cell suppression with suppression reported; the public reporting calendar mapped to existing cadences; no reporting theatre; the never-publish list. **Why:** transparency is treated as one thing; it is five | B | **Privacy** | CI-12 | A-17…A-20; **[S-D: Rule D-108]** | Either C3/C4 content is published, or nothing is and honesty stays invisible |
| **E-22** | Crisis Communication Protocol | CC-1…CC-8 with who speaks, what is released, what is withheld, timing, correction and follow-up; the seven-step public error response; four prohibited reflexes plus the fake apology; no invented spokesperson titles; domain and region not hierarchy. **Why:** the first failure in a crisis is usually a statement made too early | B | **Legal per class; DPDP [X]** | CI-9 | **[S: Ch.24]**; A-09; A-17 P5 | A conclusion is announced before the record supports one; or nothing is said and omission misleads |
| **E-23** | Social Media Doctrine and the Vanity-Metric Prohibition | Six permitted purposes and six prohibited outcomes; vanity metrics may never determine, evidence, target or be published as achievement; post only what is already published; five comment categories with five responses; legitimate criticism preserved and deletion logged; creators report never represent; no paid or solicited endorsement; no referral mechanism. **Why:** follower counts rise when the organisation says what people want to hear | D | Privacy, platform terms | — | **[S: Ch.24; App. A §8.x]**; **[S-ST: R5]**; **LDR-U11** | A popularity contest; a leader-fandom system; criticism deleted and screenshot forever |
| **E-24** | Partnership Architecture | PT-A…PT-F with a record each; partnership is not endorsement in either direction; due diligence is not surveillance; eleven partner classes with specific risks; information only never brokerage; every partnership terminable and tested for independence. **Why:** a partner's mark, reputation or politics transfers by adjacency | B | **Legal** | — | **[S: Ch.5 §4.4; Ch.29; Ch.33 signatory authority `Not final`]**; A-01 N6; A-05 clause 5 | MC-5; capture; a partner's scandal becomes the organisation's |
| **E-25** | Government Interface Communication Boundaries | The may/may-never table; the boundary statement is published; the election calendar governs; one voice, in writing, to the right desk, recorded. **Why:** cooperation shades into becoming an instrument | D | **Criminal, administrative law per jurisdiction** | — | **A-08; A-03 E1…E14; [X] BNSS 2023 ss.31, 40, 43 [V]** | MC-10 parallel government; state hostility; mission overreach |
| **E-26** | Business Interface and the public Service/Sales Firewall | Five business relationships with what each confers and may never confer; ability to pay never determines access; four public firewall rules; no earnings claim without a local funded reality, with the weak month disclosed at equal prominence. **Why:** the business pillar collapses the mission in public perception | D | Consumer, tax | HM-11 | **B-09, B-14, B-27**; **[S-ST: §17.2, §17.3]** | "They use charity to get clients"; MC-6 job-portal reading |
| **E-27** | Education Interface | Institutions are not pipelines; young participants are protected before they are useful, with six absolute prohibitions including no image of any minor ever; campus chapters refused by default. **Why:** educational institutions are the most available and most dangerous recruitment channel | D | **Safeguarding, education law** | — | **[S-C: SA-1…SA-7, H-27]**; **A-B6 BLOCKER**; **[S-D: LV-17, LV-23]** | A minor is harmed, imaged, or treated as pipeline; safeguarding exposure |
| **E-28** | Media Interface, local and national | What may be provided per subject with its evidence standard; no paid praise, disclosed paid information; the local protocol with a non-local contact; national claims require national evidence; "national" describes capability not reach; no exclusivity, no pre-publication review, no copy approval; the early-attention protocol. **Why:** local media determine local legitimacy and national attention at CL-0 is the most dangerous success available | D | **Media and paid-news regulation** | — | **[S: Ch.24]**; **[S-ST: §18.3]** | Access becomes a managed relationship; a claim is made at CL-0 that CL-8 requires |
| **E-29** | Claim Ladder and Under-Claiming | CL-0…CL-8 with evidence required, what may be claimed and what may not; the ladder is itself published; the early-attention protocol; **the ladder is audited each period and an over-claim is withdrawn and the withdrawal published**. **Why:** no mechanism tied a public claim to a demonstrated stage | B | — | CI-8 | E-01, E-05; **[S-ST: §30.3]** | Recognition jumps several classes at once; RC-4; the fall exceeds the rise |
| **E-30** | Flywheels and Expansion Gates | Both flywheels with the prohibited reversal; no stage skipped forward, a skip is a recorded risk; GATE E0…E7 plus GATE E-X; what never justifies expansion; the three gate sets are conjunctive. **Why:** the prohibited order produces demand rather than capacity | B | — | — | **[S-D: XG-1…XG-8, Rule D-43]**; **[S-B: §24.5, §26]**; B-07, B-23 | Expansion is authorised on attention; the weakest capacity is exceeded |
| **E-31** | Replication Classification | R-1…R-10 must-replicate and R-11…R-20 may-adapt; adaptation runs through the register not through discretion; **replication does not transfer trust**; RT-1…RT-5 tests. **Why:** the communication layer's copy-exactly versus adapt boundary was undefined | D | — | CI-7 | **[S-ST: §12.1]**; **[S-D: INV-1…INV-20, ADAPT-1…ADAPT-12]**; A-15 M2/M3 | Immutable items drift locally, or local expression is refused and the system is rejected |
| **E-32** | Structural Variance Register | Ten structural variables applied to eleven environment types; independence cost is the binding variable; every environment has a distinct first publication requirement; **the City divisor must be measured per environment type**. **Why:** a single national template is wrong in eleven different ways | D | **Area-specific legal** | — | **[S-ST: §12.2]**; **[S-D: Rule D-91]**; **LDR-U14** | A state structure is authorised on a divisor measured in one environment type |
| **E-33** | National Culture and Shared Practices | Culture is transmitted by consequence not statement; nine principles converted to observable behaviours with a record and a tripwire; three practices rejected, two merged, four adopted; **the conformity tripwire is the dissent count**; one event not two; shared practice not shared experience; no national date. **Why:** culture is transmitted by what is rewarded, tolerated and selected | D | Cultural | LM-15 | **[S-ST: §15]**; **[S-A: A-16 test 3]**; **[S-D: Rule D-40]** | Shared culture becomes conformity; a national day creates exclusion and a crowd |
| **E-34** | Story Architecture and Beneficiary Dignity | ST-1…ST-8 including cost and next; the attribution grammar; no flattening or composites; the person who did it tells it; the person served is not organisational material; dignity rules for consent, anonymity, images, children, vulnerable people, emergencies, before/after, testimony, gratitude and exit; **no beneficiary-to-participant pathway exists at all**. **Why:** saviour grammar enters through syntax | D+B | **Safeguarding, privacy, media** | CI-14 | A-19, A-20; **[S-C: H-14, H-22]**; **[S: App. F]** | MC-9; dignity harm; the fastest route to a real, irreversible failure |
| **E-35** | Anti-Cult, Anti-MLM and Anti-Coercion in Communication | AC-1…AC-9, ML-1…ML-8, CO-1…CO-9 with detectors; no individual images; authority cited to a document version; a founder preference is a declared interest; no eponymous artefact; no unrecorded decision channel; no personal account as an organisational channel; no personal fundraising; no person is the only source of a fact; the substitution test; the prohibited-vocabulary list; the growth-source test; leaving is complete and immediate. **Why:** compensation firewalls do not reach vocabulary, imagery, urgency or referral mechanics | D | Cultural, employment | LM-15 | **[S-A: A-16 §15.4]**; **[S-C: H-19, H-21, H-17]**; **[S-D: CU-1…CU-10, Rule D-118]** | Cult, MLM and coercion vectors that no compensation rule reaches |
| **E-36** | National Capacity and the Bottleneck Principle | CAP-1…CAP-8 with the binding stage named; the capacity formula is a **minimum, not a sum**; the weakest critical capacity constrains and is named in the authorisation; capacity may not be substituted by enthusiasm; eight collapse modes ranked; **communication is a costed governance function — recorded as a gap in v1.3-B**; the communication burden test; a surge is managed by publishing the limit. **Why:** growth is authorised on demand rather than capacity | B | Accounting | LM-12 | **[S-B: §25, §26]**; **[S-D: Rule D-43, D-91]**; **LDR-U14, LDR-U15** | A capacity deficit is converted into individual burnout and hidden from the record |
| **E-37** | Four Growth-Shock Protocols | Viral, slow, zero and negative growth each specified; a surge suspends celebration; slow growth is the design case; publish the small numbers; no growth campaign ever; a closure is published on the same terms as an opening; the seven-step decline sequence. **Why:** only the viral case is usually planned for | D | — | HM-9 | **[S-B: §24.5]**; **[S-D: Rule D-26]** | Open commitments are quietly dropped in a decline; a growth campaign produces a flow into a stock that cannot absorb it |
| **E-38** | Reputation Shock and Attack Response | Process before narrative; the eight-element misconduct-accusation protocol; **the default classification of any negative statement is criticism**; classification recorded and auditable; eight attack scenarios with the evidence that disproves each; **defence is pre-publication**. **Why:** every attack is disproved by a record that must already be published | D | **Legal per attack class** | CI-9 | **[S: Ch.24]**; A-01…A-06; **[S-D: Part 18]** | A conclusion is announced before determination; whistleblowing is misfiled as an attack |
| **E-39** | National Communication Governance | The artefact-class publication matrix with approver, evidence and correction duty; **a correction requires no approval**; editorial independence from the subject; the brand-governance asset table; no personal account is an official channel; four public-accountability mechanisms; no promise of independent review without a mechanism; whistleblowing rules E-190…E-195. **Why:** publishing authority was distributed with no rule about which artefact needs which approval | B | **Legal, IP** | CI-9, CI-12 | **[S: Ch.5; Ch.24; App. A §8.x; App. E]**; A-14 §13.4; A-N12, A-N13 | A correction that needs approval arrives after the damage; the channel leaves with the person who set it up |
| **E-40** | Digital Architecture and Platform Dependency | Digital serves physical and never replaces it; the two searches designed separately; local discovery without the hierarchy; seven platform dependencies with controls; **the public record is platform-independent**; digital-identity and continuity requirements. **Why:** the public record depends on platforms the organisation does not control | B | **Security, privacy** | — | A-14 §13.4; **[S: Ch.22, Ch.23]**; **[S-B: §40]**; A-N13 | A platform or account loss removes the public record; a personal departure takes the channel |
| **E-41** | Contribution Portability | PO-1…PO-5; six properties separating a record from a social-credit system, all of which must hold; no ordinal element in any field; **the value proposition to a third party is checkability, not prestige**. **Why:** portability is one design decision away from a social-credit score | B | **Privacy** | **`SKIP-NT` needs ≥2 localities** | **[S-C: H-09, H-10, CR-1…CR-4]**; A-17…A-20; **[S-D: SEC-series]** | A portable record becomes a score; or the most valuable asset is never accepted by anyone outside |
| **E-42** | National Recognition and the Hero-Language Rule | What recognition rewards and never rewards; hero, warrior and guardian refused; *sewak* and contributor permitted descriptively; absolute instruments only at every level; **no national hero and no national recognition of a person**. **Why:** the protection pillar makes combat vocabulary available and it would be read as a mandate | D | Cultural | CI-5 | **[S-C: H-08, SR-2]**; **[S-D: Rule D-66, D-67]**; A-06 | MC-3 Severe; vigilante identity; ordinal recognition returns by another name |
| **E-43** | Specialist and Knowledge Networks in public | Advises never commands; engagement on request or under an immutable standard; engagements published in aggregate; no publicly displayed tier; entry open by evidence; **the elite-disconnection test — recent local delivery required for standard-setting**; the knowledge chain; conditions travel with the solution; a failure is published with its learning. **Why:** either network can become a visible elite | B | — | — | **[S-C: §47, H-11]**; **[S-D: SP-1…SP-6]**; **[S-B: B-21]**; A-15 M2/M3/M5 | A disconnected elite sets standards; a local solution is copied into a place where it fails |
| **E-44** | Identity and Adoption Maturity | NI-0…NI-6 and MA-0…MA-6 determined by operation not documentation; **a level is determined by the weakest locality claimed**; adoption maturity measured per locality, never in aggregate; the NI/MA diagnostic matrix — the healthy trajectory is MA ahead of NI. **Why:** a maturity claim based on documentation is unfalsifiable | D | — | — | **[S-ST: §23.1]**; **[S-D: MAT-0…MAT-5]**; E-29, E-30 | Branding is undetected; a handful of good units is averaged into a network-level assertion |
| **E-45** | One Integrated Evidence System | The six evidence families reported **together, for the same locality, for the same period**; EXPAND / IMPROVE / PAUSE with triggers; a pause is published on expansion terms; **the default outcome is IMPROVE**; no class promotion without a label change. **Why:** reported separately, each family is optimisable in isolation and conceals the others | B | — | All 60 | All five prior instruments | Expansion is decided on partial evidence; EXPAND becomes the default success condition |
| **E-46** | Claim Discipline and Evidence Labels | Six claim classes with publication permission and required marker; **"we do not know yet" is a protected public statement**; five plain-language evidence labels with "pending" carrying a due date; the combined grammar. **Why:** uncombined, the two classification systems cannot be audited from an artefact | D | — | CI-8 | E-05, E-29; **[S-ST: §11.3]** | Readers cannot tell what kind of statement they are reading; UNKNOWN is never said in public |

## II.7 Register findings

**[A]** Six findings across all 164 amendments:

1. **None is incorporated.** All 164 are `PROPOSED` in their source instrument with a stated merge target. **The first action on the critical path for every one of them is an approval decision, not a build.**
2. **Implementation type is dominated by discipline, not construction.** Of 164: **63 are `YES-BUILD`** (a mechanism must exist), **71 are `YES-DISCIPLINE`** (a constraint on existing activity, no new mechanism), **30 are `B+D`**. **[A]** This matters for cost: **a discipline costs training and audit; a build costs a person and a record.** The corpus is cheaper to adopt than its volume suggests.
3. **Forty-one amendments require professional validation** across the 17 categories of Part III. **Nine of those are pre-pilot.**
4. **Twenty-six amendments touch an `UNRESOLVED` source decision.** They cannot be fully implemented until that decision is made, and **Part IV identifies the five decisions that block the most amendments.**
5. **Seven amendments are `SKIP-NT` — not testable at pilot scale:** L-06 (cohort normalisation), LM-8 and LM-10 dependencies in L-27 and L-23, E-41 (portability), and the CI-3/4/5/10/13 dependencies in E-06, E-07, E-15 and E-33. **None is approximated.**
6. **Supersession and constraint are dense, and run in one direction.** v1.3-D constrains v1.3-B and v1.3-C on leadership and performance; v1.3-E constrains all four on public expression; **v1.3-A constrains all four on law, neutrality, safety and data.** No instrument supersedes v1.3-A, and **[S-A]**'s BLOCKER taxonomy (A-B1…A-B9) is the only pre-pilot gate the corpus itself defines. **Part V adopts it rather than inventing a competing one.**

---

# PART III — VALIDATION REQUIREMENT CONSOLIDATION

## III.1 Method

**[P]** Every `[V]` in the corpus is located: **A-V1…A-V12** (12 counsel categories), **[S-A: Annexure B]** (10 domains, ◆ marking pre-launch), **HV-1…HV-10** (10), **LV-1…LV-25** (25), **LV-E-1…LV-E-30** (30), plus `[V]` items embedded in **[S-B]** and **[S: Ch.33]**. **Total 77 distinct items (PD-9).** Semantically identical requirements are merged; **every originating ID is preserved.**

**[P] Rule F-7 (No Professional Is Named).** Every entry names a **role or category**, never a person, firm or invented title. Where the corpus names a category, that wording is used.

## III.2 The seventeen categories

| Cat | Category | **WHO must validate** | Merged originating IDs | Pre-pilot? |
|---|---|---|---|---|
| **V-01** | **Legal — corporate / entity** | **Qualified Indian corporate counsel** | A-V1; HV-6; LV-8; LV-E-1, **LV-E-11** (LA-1 texts in every operating language); **[S: Ch.33]** entity structure | **YES ◆ — A-B1** |
| **V-02** | **Regulatory — sector permissions** | **Qualified Indian regulatory counsel plus the relevant sector authority adviser** (food safety for distribution; health-support and camp boundaries; municipal permissions; regulated markets) | A-V1 (objects clauses); **[S-A: Annexure B sector permissions]**; **[S-C: HV-5]**; LV-E-27 | **YES for any activity actually undertaken** |
| **V-03** | **Accounting / financial** | **A practising Chartered Accountant** | A-V2 (partly); **[S-A: Annexure B financial/audit]** — reserve-release matrix, cross-subsidy legality and accounting, restricted-fund accounting, cold-start treatment; LV-E-14 (partly) | **YES — the pilot produces published accounts** |
| **V-04** | **Tax** | **A practising Chartered Accountant with Indian not-for-profit tax experience, plus tax counsel** | A-V2; HV-9; LV-E-2, LV-E-3; LV-19 (partly); **LV-20** (foreign contribution, if any) | **YES ◆ — 12A/80G/FCRA conditions attach to the entity chosen under V-01** |
| **V-05** | **Labour / employment** | **Qualified Indian employment and labour counsel** | A-V3; HV-1; LV-3, LV-4, LV-6, LV-7 (partly); LV-E-24 (partly); **LDR-U09 worker classification** | **YES ◆ — A-B1 includes worker classification** |
| **V-06** | **Insurance** | **A qualified Indian insurance broker or adviser** | A-V4; LV-22; LV-E-20; **[S-A: A-10 §9.1 L1–L15]** | **YES — A-B2 BLOCKER** |
| **V-07** | **Data protection / privacy** | **Qualified Indian privacy counsel or a certified Data Protection Officer** | A-V6; HV-3; LV-11, LV-12, LV-13, LV-14, LV-25; LV-E-10, LV-E-12, LV-E-13, LV-E-14, LV-E-15, LV-E-28; **[S-A: P1…P6]** | **YES ◆ — A-B7 BLOCKER** |
| **V-08** | **Child / vulnerable-person safeguarding** | **A certified child-protection and vulnerable-adult safeguarding specialist** | A-V7; HV-2, HV-4; LV-17; LV-E-17, LV-E-18; **[S-C: SA-1…SA-7]** | **YES ◆ — A-B6 BLOCKER** |
| **V-09** | **Safety / first-response** | **A qualified emergency-medicine, first-aid or occupational-safety professional, plus criminal counsel on the intervention boundary** | A-V5; LV-18; LV-E-19; LV-21 (occupational health); **[S-A: A-06, A-08, A-09, A-11]** | **YES — A-B2, A-B3, A-B8 BLOCKERS** |
| **V-10** | **Governance** | **A qualified company secretary or corporate-governance counsel — A-V9 names this category explicitly** | **A-V9** (CEO-versus-Council authority, reserved matters, dispute resolution); A-V1 (protective provisions); LV-9, LV-10; LV-E-23 (partly); **[S-A: A-13, A-14, A-16; A-N17, A-N18, A-N19]** | Important-before-scaling (A-I1…I3), **except** A-B9 bank mandate which is pre-pilot |
| **V-11** | **Brand / IP** | **Qualified Indian IP counsel — A-V8** | A-V8; LV-24 (partly); LV-E-4, LV-E-5, LV-E-6, LV-E-7, LV-E-9; **A-N12, A-N13, [S: Ch.33] public name** | Important-before-scaling (**A-I6**), **but LV-E-9 non-police ID card design is pre-pilot — [S: Ch.31] blocker** |
| **V-12** | **Technology / cybersecurity** | **A qualified information-security professional** | A-V6 (partly); LV-25; LV-E-14, LV-E-40 dependencies; **[S-A: A-14 §13.4 credential custody; P6 processor standard]** | **Not pre-pilot — the pilot runs with no technology [S-B: §40]** |
| **V-13** | **Financial controls / audit** | **A practising Chartered Accountant or a qualified internal-audit professional** | **[S-A: Annexure B financial/audit]**; LV-E-23 (partly); **[S: Ch.27]**; B-15, B-20, B-25 | **YES — published accounts are a pre-condition of CL-2** |
| **V-14** | **Human factors** | **A qualified organisational-psychology or human-factors professional** | LV-1, LV-2, LV-21; HV-10 (partly); **[S-D: L-02, L-12, L-13, L-25]** | Important; not pre-pilot |
| **V-15** | **Leadership selection** | **A qualified assessment or occupational-psychology professional** | LV-1, LV-2, LV-5, LV-13; **[S-D: L-01, L-03, L-13, L-27]** | Important; **the out-of-team assessment capability is the [S-D: §52.3 step 5] pivot and cannot exist before a second team** |
| **V-16** | **Communications / reputation / cultural** | **Communications and advertising counsel — A-V11 names this category — plus a qualified communications professional and a cultural and linguistic reviewer per operating language and state** | **A-V11** (Public Protection Statement wording; representations and the expectations they create); HV-7, HV-8, HV-10; LV-E-8, LV-E-21, LV-E-22, LV-E-25, LV-E-26, LV-E-30; **[S-C: H-26 field 11]** | **YES for the category sentence, the "what we are not" list and the mandatory translation set; the comms policy is a [S: Ch.31] blocker** |
| **V-17** | **Other — political / electoral, equality, consumer, research ethics, records and archival** | **Qualified Indian electoral counsel; equality counsel; consumer and advertising counsel; a research-ethics adviser** | **A-V12 records / archival specialist** (retention obligations, evidentiary value, archival law); HV-7, HV-8; LV-E-16, LV-E-21, LV-E-24, LV-E-28, LV-E-29; **[S-A: A-01…A-04]** | **YES for electoral (A-B4 BLOCKER); the rest important-before-scaling** |

## III.3 The pre-pilot validation subset

**[A]** Of 77 items, the ones that must be validated **before the pilot may be authorised** — derived from **[S-A: A-B1…A-B9]** and the ◆-marked domains, not from judgement:

| # | Validation | Category | Blocker | Consequence if skipped |
|---|---|---|---|---|
| 1 | Entity form, objects clauses permitting all four pillars, dissolution and restructuring | **V-01** | **A-B1** | Nothing involving money, contracts or employment can lawfully occur |
| 2 | Tax position: 12A application-of-income and political-activity conditions; 80G; FCRA eligibility and timing | **V-04** | **A-B1** | Exemption exposure; a political-activity finding could cancel exemption **[X][V]** |
| 3 | Worker classification: employee / contract labour / volunteer / stipend / business participant; minimum-wage and statutory consequences | **V-05** | **A-B1** | Priority-1 payment may be unlawful; statutory liability |
| 4 | Insurance and liability: personal accident, public/third-party liability, professional indemnity, directors'/trustees' liability, cyber — written answers to L1–L15 | **V-06** | **A-B2** | **Uninsured personal injury. Irreversible** |
| 5 | The intervention boundary: private-person arrest and handover, duty to assist, Good-Samaritan and first-aid protections, mandatory reporting duties | **V-09, V-17** | **A-B3** | Unlawful intervention; member criminal exposure |
| 6 | Political activity restrictions attaching to the chosen entity form; the §3.1 A.3 questions | **V-01, V-04, V-17** | **A-B4** | Tax-exempt exposure; MC-1 |
| 7 | Certified safeguarding standards; the two-adult rule; reporting protocols; consent validity for minors and vulnerable adults | **V-08** | **A-B6** | **Harm to a child. Irreversible** |
| 8 | Privacy: lawful basis and consent design, notice content and languages, purpose limitation, retention schedule, breach runbook, named privacy officer, data-fiduciary status | **V-07** | **A-B7** | Statutory exposure — **[X]** DPDP penalties up to ₹200 crore for failure to notify, ~₹250 crore for inadequate safeguards **[V]** |
| 9 | Bank mandate continuity and minimum signatories; custody instruments for reserves | **V-01, V-10 — A-V10 banking/finance is the named category** | **A-B9** | Worker compensation cannot be paid during an apex vacancy |
| 10 | Non-police ID card design | **V-11, V-17** | **[S: Ch.31]** | Resemblance to an official credential; MC-3 |
| 11 | The comms policy, including the public-statement rules and misinformation-correction procedure | **V-16** | **[S: Ch.31]** | Unauthorised statements; no correction discipline |

**[P] Rule F-8 (Validation Precedes Build).** Where an item requires both validation and construction, **validation comes first.** Building a privacy notice before the retention schedule is validated, or an ID card before the non-police constraint is validated, produces an artefact that must be rebuilt. **[A]** This is the ordering rule that makes the critical path in Part VII finite rather than iterative.

---

# PART IV — UNRESOLVED DECISION REGISTER

## IV.1 Method

**[P]** Every unresolved decision in A–E is extracted, **de-duplicated across instruments with all source IDs preserved**, and recorded with the thirteen fields the brief requires. **No decision is resolved here. Where authority is itself unresolved, the entry reads `AUTHORITY UNRESOLVED` and no authority is invented.**

**[A]** Two classes are distinguished, because they require different acts:

| Class | Meaning | Count | Act required |
|---|---|---|---|
| **`UNRESOLVED`** | **No answer exists.** The corpus poses the question and refuses to answer it | **30** | A decision must be *made* |
| **`PROPOSED`** | **An answer exists as a proposal.** The corpus recommends and marks it `PROPOSED — REQUIRES FINAL APPROVAL` | **65** | A decision must be *ratified or rejected* |
| **Amendment approval** | Each of the 164 amendments requires adoption | **164** | A decision must be *ratified, modified or rejected* |

**[P] Rule F-9 (A `PROPOSED` Item Is Not A Decision).** A proposal that has not been approved has no operative force. **This register does not treat the existence of a well-reasoned proposal as progress toward readiness**, because readiness requires an authorised act, and 259 such acts are outstanding.

## IV.2 The thirty `UNRESOLVED` decisions

| ID | Source | Exact issue | Why it matters | Alternatives as stated in source | **Authority** | Ext. val? | **Blocks** | Does NOT block | Decision window (earliest → latest safe) | Consequence of delay |
|---|---|---|---|---|---|---|---|---|---|---|
| **A-N5** | **[S-A: §22 N5]**; **[S-E: N-E-22]** | Whether composition monitoring is undertaken at all, and in what form | "Exclusion patterns invisible **or** an identity database is created" | Aggregate, optional, self-declared, restricted, purpose-limited — **or not at all** | CEO + Council + privacy officer | **Yes** — privacy and equality | Pattern review of exclusion; **[S-E: E-08]**; **[S-D: Rule D-79]** aggregate reporting | Service delivery; the pilot itself | **Before any collection** → before the first aggregate disparity report | Either exclusion is invisible forever, or an identity database is built that could later be used to sort people |
| **A-N10** | **[S-A: §22 N10]**; **[S-A: A-10 §9.1 L1–L15]** | Written answers to the fifteen insurance and liability questions | "Uncovered injury; unsupported member; unanswerable regulator" | Commission written answers; hold as governance evidence | National Legal + Finance + CEO | **Yes — broker, counsel, tax (A-V4)** | **A-B2 BLOCKER**; all protection and first-response activity; A-11 activation gate; **[S-E: CC-1, CC-7]** | Service activities carrying no injury risk | **Now** → before protection activation | **Uninsured personal injury to a member or third party. Irreversible** |
| **A-N12** | **[S-A: §22 N12]**; **[S-E: N-E-17]** | Brand ownership and licensing terms | "Teams hold no documented right to the name; exit and dissolution become chaotic" | Determine owner, licence terms, use conditions, post-exit restrictions | Founder/CEO + Legal | **Yes — IP (A-V8)** | **A-I6**; **[S-E: Rule E-60, E-11, BR-9]**; multi-city expansion; any mark, palette or logo; **N-E-02** | A single team using the name locally under recorded interim permission (**BR-9**) | **Now** → **before multi-city expansion**; **[S-A: A-I6]** requires it "before many parties rely on the brand" | Every team, partner and member relying on the name is relying on an asset nobody is documented to own |
| **A-N13** | **[S-A: §22 N13]**; **[S-E: N-E-18, N-E-19]** | IP ownership of the architecture, SOPs, curricula, software, data models and brand assets | "The institution's operating system could be withdrawn by a licensor" | Determine ownership and any licence to the operating entity | Founder/CEO + Legal | **Yes — IP, tax (A-V8)** | **A-I6**; national expansion; domain and digital-asset ownership; the knowledge repository | A single team operating from printed SOPs it does not own | **Now** → before national expansion | The operating system of the institution is held by a party who may withdraw it |
| **A-N14** | **[S-A: §22 N14]** | Data fiduciary identity and named accountable officer | "Regulator has no contactable person; duties unassigned" | Assign per entity and per data category | CEO + Legal + AI & Data | **Yes — privacy (A-V6)** | **A-B7 privacy minimum**; the privacy notice; breach notification; **[X]** DPDP fiduciary duties | Paper-only record-keeping below any fiduciary threshold **[V]** | **Now** → before the first 1,000 personal records | Statutory duties attach with no accountable person; a breach has no notifier |
| **A-N15** | **[S-A: §22 N15]** | Custody of reserves and the social-impact fund | "Restricted purpose survives in policy but in no instrument" | Determine holding entity, instrument and change-of-control protections | CEO + Finance + Council | **Yes — banking/finance (A-V10), corporate** | **A-I7**; B-03, B-15; **[S: Ch.18, Ch.20]**; any reserve release | The pilot's operating account at trivial scale | **Now** → before reserves accumulate materially | A restricted fund is held in an instrument that does not restrict it; change of control moves it |
| **A-N16** | **[S-A: §22 N16]** | Bank mandate continuity and minimum signatories | "Worker compensation could stop on one person's unavailability" | Two or more signatories with a continuity rule | Finance + CEO | **Yes — banking, entity (A-V10)** | **A-B9 BLOCKER**; **priority-1 payment during an apex vacancy**; B-05, B-13; **[S-D: INV-2]** | Nothing — this blocks the first external payment | **Now** → **before the first external payment** | **Priority 1 fails on one person's absence. The waterfall's first obligation becomes unpayable** |
| **A-N19** | **[S-A: §22 N19]**; **[S-D: LDR-U12]** | Apex dispute-resolution mechanism | "Deadlock settled by power rather than procedure" | Ladder: written positions → cooling period → joint session → external mediator; operations continue throughout | **`AUTHORITY UNRESOLVED`** — the register names "CEO + Council", but whether the Council has authority over the CEO is **LDR-U01**, which is itself unresolved | **Yes — governance (A-V9)** | **A-I3**; constituting the Council; **[S-D: Rule D-113 interim reserved-matter procedure]**; **[S-A: A-13, A-14]** | Day-to-day operations | **Now** → **before constituting the Council** | A deadlock between the CEO and the Council is settled by whoever is stronger |
| **A-N26** | **[S-A: §22 N26]**; **[S-D: LDR-U10]**; **[S-E: N-E-26]** | Retention and erasure schedule with actual periods — "**periods deliberately not invented**" | "Over-retention liability or unlawful under-retention" | Counsel sets periods per category | Legal + privacy officer | **Yes — privacy (A-V6), records/archival (A-V12)** | **A-B7**; the communication archive; **[S-E: Part 53]**; contribution-record portability; audit-log retention | Collecting the minimum data for one pilot cycle | **Now** → before the first 1,000 records | Data is kept indefinitely with no rule, or destroyed while still required as evidence |
| **LDR-U01** | **[S-D: LDR-U01]**; **[S: Ch.33; Ch.4]**; **[S-E: N-E-25]** | **CEO versus National Council authority** | Determines who approves a national claim, a partnership, a brand decision, a reserved matter and a leadership appointment | Not stated — the source leaves it open | **`AUTHORITY UNRESOLVED`** | **Yes — governance (A-V9 names this exact question)** | **Everything requiring an apex decision**: A-N17, A-N18, A-N19, A-N21, A-N22, **[S-D: L-33]**, **[S-E: GATE E7]**, LDR-U12 | Local and City operations within delegated authority | **Now** → before the first reserved matter arises | A reserved matter arises and nobody is authorised to decide it; **[S-D: Rule D-113]** interim procedure is the only fallback |
| **LDR-U02** | **[S-D: LDR-U02]**; **[S: Ch.33; App. A §15.3]** | **Leader multiplier `m_lead`** | `C_lead = C_wc_base × m_lead` is the leadership cost formula; without `m_lead` leadership cost is uncomputable | Not stated — "does not invent the exact multiplier"; must be transparent, capped or bounded, justified by verified leadership work rather than status alone | Founder/CEO with National Finance | **Yes — labour, tax, accounting (LV-7)** | **[S-D: L-15, LM-13]**; the pilot's leadership cost; B-26 hybrid funding map | Running the pilot with leadership unpaid and recording the deficit (**[S-D: Rule D-126]**) | Pilot start (to record the deficit honestly) → before the second team | Leadership is unpaid, which makes it a wealth privilege; **affordability of leadership for a poor person fails ([S-D: EF-5 / EA-12])** |
| **LDR-U03** | **[S-D: LDR-U03]**; **[S: Ch.25; Ch.33]** | **Leaderboard weights 20/15/15/15/10/10/10/5** | The performance score's composition. Source marks them `PROPOSED` | Not stated | **`AUTHORITY UNRESOLVED`** — depends on LDR-U01 | **Yes — human factors (LV-1)** | **[S-D: L-02, L-05, L-14, L-18]**; any scored decision | The pilot, if scoring is deferred and gates plus narrative are used instead (**[S-D: Part 52 step 4]** adopts windows and cohorts **without altering the PROPOSED weights**) | Pilot → before the first scored promotion | A promotion is made on weights nobody approved, and the decision cannot be defended on appeal |
| **LDR-U04** | **[S-D: LDR-U04]**; **[S: Ch.33; Ch.26]** | **Leadership transition rules** | Six-step transition exists; the rules that govern it are `NOT FINAL` | Not stated | **`AUTHORITY UNRESOLVED`** — depends on LDR-U01 | Yes — governance | **[S-D: L-09, L-32]**; B-18; any promotion | The pilot, where no promotion will occur | Pilot → before the first promotion | A promotion occurs under rules that were never approved |
| **LDR-U05** | **[S-D: LDR-U05]**; **[S: Ch.33]** | **Team readiness threshold** | The autonomy-readiness gate has eight rows and no threshold | Not stated | City + National with CEO | Yes — governance | **[S: Ch.13]** autonomy gate; **[S-D: L-22]** | The pilot team operating at minimum autonomy | Pilot → before granting autonomy | Autonomy is granted by judgement rather than by a threshold, and cannot be defended |
| **LDR-U06** | **[S-D: LDR-U06]**; **[S: Ch.33]** | **Minimum staffing thresholds** | `n_min` determines whether a unit may operate at all | **[S-D: L-28]** gives a five-condition set with **no number invented** | National + CEO | Yes — governance, labour | **[S-D: L-28, Rule D-33, MVLS]**; any new unit; **[S-E: GATE E4]** | The pilot, if the pilot team's staffing is set explicitly as a recorded decision | **Before the pilot** — one team's `n_min` must be decided to authorise it | A unit operates below the capability needed for safety, verification, funds and evidence duties |
| **LDR-U07** | **[S-D: LDR-U07]**; **[S: Ch.33]** | **Serious-misconduct procedure** | **[S: App. E]** assigns removal to a Governance/HR panel; the procedure is `NOT FINAL` | Not stated | **`AUTHORITY UNRESOLVED`** — depends on LDR-U01 | **Yes — employment (A-V3), safeguarding** | **[S-D: L-23 RM-1…RM-10]**; **[S-E: CC-4]**; any removal | The pilot, if no misconduct arises — **which cannot be assumed** | **Before the pilot** | A misconduct allegation arrives with no approved procedure, and the response itself becomes the liability |
| **LDR-U08** | **[S-D: LDR-U08]**; **[S: Ch.33]**; **[S-E: N-E-24]** | **Legal structure under Krytos** | Determines tax, disclosure, liability, political-activity restrictions, worker classification and what may lawfully be said publicly | Section 8 company / trust / society / other / two-entity structure — **the corpus states the options and refuses to choose** | Founder/CEO | **Yes — corporate, tax (A-V1, A-V2)** | **A-B1 BLOCKER — everything involving money, contracts and employment**; A-N14, A-N15, A-N16, LDR-U09; the privacy notice's fiduciary; insurance; **[S-E: GATE E7, Rule E-59]** | **Nothing.** Writing, thinking, designing and training may continue | **Now — this is the first item on the master critical path (Part VII)** | **Priority-1 worker compensation cannot lawfully be paid. The pilot cannot pay anyone. Nothing economic can be measured** |
| **LDR-U09** | **[S-D: LDR-U09]**; **[S: Ch.33]** | **Worker classification** | Employee / contract labour / volunteer / stipend / business participant — each carries different statutory consequences | Not stated | Founder/CEO with Legal and Finance | **Yes — labour (A-V3), tax (A-V2)** | **A-B1 BLOCKER**; B-06, B-09; **[S-D: L-15]**; **[S-C: HV-1]**; payroll | Volunteer-only activity with no payment at all | **Now** → before the first payment | A member is paid in a way that creates an unrecorded statutory liability |
| **LDR-U11** | **[S-D: LDR-U11]**; **[S-ST: R5]**; **[S-E: N-E-23]** | **Whether the leaderboard should be public at all** | Determines whether comparative performance becomes a public status market | Not stated — **[S-ST: R5]** leaves it open | **`AUTHORITY UNRESOLVED`** — depends on LDR-U01 | Yes — human factors, communications | **[S-D: L-24]**; **[S-C: H-08]**; **[S-E: Part 24]** | The pilot, where no leaderboard need exist | Pilot → before any comparative artefact is published | A comparative artefact is published and cannot be withdrawn from memory |
| **LDR-U13** | **[S-D: LDR-U13]**; **[S-B: §40.2]** | **Role combination factor `c` and `⌈9/c⌉`** | Determines how few people can hold the nine State-A functions | Not stated — no span-of-control number exists anywhere in the corpus | National + CEO | Yes — governance, human factors | **[S-D: L-28]**; `n_min`; the pilot's staffing | The pilot, once its own `c` is observed | Pilot → before the second team | A unit is authorised with too few people, or requires more than exist |
| **LDR-U14** | **[S-D: LDR-U14]**; **[S-B: §26]** | **City divisor `H_gov_per_team(K)` shape** | Determines whether a State layer is arithmetically possible | Not stated — sub-linear, linear or super-linear are all possible | National + Finance | Yes — accounting, governance | **B-21**; **[S-D: Rule D-91]**; **[S-E: GATE E6, Rule E-138]**; State formation | The pilot and a single City | Pilot → **before State formation** | A State layer is authorised on a divisor measured in one environment type and collapses |
| **LDR-U15** | **[S-D: LDR-U15]**; **[S-B: §26]** | **`K_min`** | The minimum team count at which a City layer is viable | Not stated | National + Finance | Yes — accounting | **B-21**; City formation; **[S-E: GATE E5]** | The pilot | Pilot → before City formation | A City layer is formed too early and consumes the teams it exists to serve |
| **LDR-U16** | **[S-D: LDR-U16]**; **[S: Ch.33]** | **Founder compensation** | Sits at priority 4 in the waterfall; no rule and no figure exists | Not stated | **`AUTHORITY UNRESOLVED`** — the founder is the beneficiary; **[S-D: Rule D-92]** Founder Recusal Register applies | **Yes — corporate, tax, governance (A-V9)** | **[S-D: L-37]**; the waterfall's integrity; public accounts (TS-3) | The pilot, if founder compensation is nil and recorded as nil | Pilot → before the first published accounts | Either the founder is paid without a rule, or is not paid and the deficit is invisible — **both damage the published accounts** |
| **LDR-U17** | **[S-D: LDR-U17]**; **[S: App. A §1.1]** | **The economic blueprint** | "Never attached" — the corpus's central economic gap | Not stated | Founder/CEO | Yes — accounting, financial | **All of v1.3-B's numeric content**; B-26; the pilot's funding requirement | **The pilot itself, which is designed to produce the blueprint's inputs** | Pilot → before any expansion | Every economic variable remains symbolic forever |
| **LDR-U18** | **[S-D: LDR-U18]**; **[S: App. A]** | **The 37.5 / 17 / 12 percentages** | The only percentages in 179 pages, and they are illustrative | Not stated | Founder/CEO with Finance | Yes — accounting, tax | B-26; published accounts; **[S-E: TS-3]** | The pilot, which measures the actual splits | Pilot → before publication | Illustrative percentages are published as though they were policy |
| **LDR-U19** | **[S-D: LDR-U19]** | **Successor to the founder** | The single point on which institutional continuity depends | Not stated — **no successor may be named by any instrument** | **`AUTHORITY UNRESOLVED`** — A-N17 names "Founder/CEO + Council", and the Council's authority is LDR-U01 | **Yes — corporate, governance (A-V1, A-V9)** | **A-N17, A-N18, A-I2**; **[S-A: A-14]**; **[S-D: L-29, Scenario A–H]**; **[S-E: SIM-11]** | Day-to-day operations under the Interim Authority Order, once adopted | **Now** → before national expansion; **[S-A: A-N17]** says "preferably before the first hire" | Apex vacancy becomes an ending; **[S-ST: §11.1]** the institution and the person are the same object |
| **LDR-U20** | **[S-D: LDR-U20]**; **[S: Ch.33]** | **Apostille / formal validation of "Sewak Sathi Sanstha" as public name** | The name is `PROPOSED` with availability and registration unvalidated | Not stated | Founder/CEO with IP counsel | **Yes — IP (A-V8)** | **A-N12**; every public artefact; the domain; **[S-E: T1–T4 brand tiers]** | Internal work and a single team's local use under BR-9 | **Now** → before public use at scale | Investment in a name that is unavailable, conflicting or unregistrable |
| **N-E-02** | **[S-E: N-E-02]** | **Visual identity — whether a mark exists at all, and what it is** | Every surface, every locality, every artefact | Word-only / word + mark / mark-only | **Blocked by A-N12** — the register states the mark cannot be settled while brand ownership is unresolved | **Yes — IP, legal, per-state political, accessibility (LV-E-7, LV-E-8, LV-E-9)** | **[S: Ch.31]** ID-card blocker; **[S-E: E-12]**; the palette; BR-1…BR-12 | The prohibitions — **Rule E-61 colour reservation, E-62 no colour-only meaning, E-63 symbol test, E-64 no authority by appearance, E-65 four surfaces are all adoptable now and cost nothing** | After A-N12 → before any public visual artefact | Either no mark exists (acceptable, and Rule E-65 permits word-only identification) or an unowned mark is published |

## IV.3 The sixty-five `PROPOSED` decisions awaiting ratification

**[A]** These are not open questions — they are **unratified answers**. Each has a proposed content in its source instrument and requires an authorised yes, no or modification. **Grouped by the act required, because that determines who must be in the room.**

| Group | Items | Act required | Authority per source | Blocking tier |
|---|---|---|---|---|
| **Neutrality and protection** | **A-N1** Political Neutrality Code · **A-N2** election protocol · **A-N3** member political activity · **A-N4** Equal Treatment & Non-Alignment · **A-N6** Protection Visibility Protocol V1…V43 · **A-N7** Public Protection Statement wording · **A-N8** DO-NOT entrenchment · **A-N9** incident protocol matrix · **A-N11** Activation Gate | Adopt | A-N1 CEO+Council · A-N2 CEO+National Legal · A-N3 CEO+HR+Legal · A-N4 CEO+Council · A-N6 National Safety+Legal+Communications · A-N7 CEO+Communications+Legal · A-N8 CEO+Council · A-N9 National Safety+Legal · A-N11 CEO+National Safety+Legal | **A-B4, A-B5, A-B8 → BLOCKER A** |
| **Privacy and data** | **A-N25** classification scheme and field register · **A-N27** privacy notice content and languages · **A-N28** DPIA trigger list · **A-N29** breach runbook and notification · **A-N30** processor and vendor standard · **A-N31** QR and member-identification use restriction · **A-N32** prohibited-collection list · **A-N33** tier-linked collection · **A-N34** Beneficiary Privacy & Dignity Code · **A-N35** sealed-case model and subject rights | Adopt | AI & Data + privacy officer; Legal + Communications; Legal + privacy officer + Safety; HR + Safety + Legal; CEO + privacy officer; CEO + National Operations + Legal | **A-B7 → BLOCKER A** |
| **Governance and continuity** | **A-N17** apex succession mechanism · **A-N18** reserved-matters list · **A-N20** key-person dependency register · **A-N21** Mission Lock Tier-1 list · **A-N22** publication period, majority level and deciding body for Tier-1 amendment · **A-N23** memory instruments and archive ownership · **A-N24** founder-versus-institution rules and the four annual tests · **A-N38** amendment adoption sequencing | Adopt | Founder/CEO + Council; CEO + Council; National HR + Operations; National Operations + Editor | **A-N17, A-N18 → IMPORTANT (A-I2); A-N38 → immediate** |
| **AI** | **A-N36** risk tiers, review caps and language guard · **A-N37** auditability field set and log retention | Adopt | AI & Data + Audit; AI & Data + Legal | **A-H11, A-I8** — not pre-pilot (no AI in the pilot) |
| **Leadership (v1.3-D)** | **LDR-01…LDR-20** — eligibility/readiness separation; twenty capability dimensions; five evidence classes; gates void status not payment; four windows and two-speed scoring; cohorts from records; locked baselines; six succession states; nine-step promotion transition; five temporary instruments with expiry; three tracks two endpoints; Authority Formation assessed out of team; four review types with decomposed 360; succession as a scored dimension with no new weight; leadership allocation itemised and bounded; playbooks tested not filed; Transition Access Protocol; Goodhart Prohibition List; twelve MVLS items; expansion gate XG-1…XG-8 | Adopt | Founder/CEO with the relevant national function; **[S-D: Part 45]** | **LDR-19 (MVLS) → Tier 0; LDR-01, LDR-08, LDR-20 → Tier 1** |
| **Identity and communication (v1.3-E)** | **N-E-01** national identity definition (epistemic vs affective) · **N-E-03** red/crimson usage · **N-E-04** language policy · **N-E-05** symbols · **N-E-07** ceremonies · **N-E-08** national service day · **N-E-09** public claims · **N-E-10** spokesperson model · **N-E-11** social media · **N-E-12** partnerships · **N-E-13** celebrity relationships · **N-E-14** public transparency · **N-E-15** national branding threshold · **N-E-16** national expansion threshold · **N-E-20** digital-asset continuity · **N-E-21** the category sentence (`NOT ADOPTED — draft only`) | Adopt | Founder/CEO + National Communications; **N-E-21 requires comprehension testing (CI-2) before adoption** | **N-E-04, N-E-09, N-E-14 → Tier 1; N-E-03, N-E-05, N-E-07, N-E-08 → Tier 1 (all are refusals and cost nothing); N-E-15, N-E-16 → Tier 4** |

## IV.4 The five decisions that block the most

**[A]** Ranked by downstream blocking effect, not by importance:

| Rank | Decision | Directly blocks | Transitively blocks |
|---|---|---|---|
| **1** | **LDR-U08 legal structure under Krytos** | A-B1, A-N14, A-N15, A-N16, LDR-U09, the privacy notice, insurance, contracts, employment, banking | **Priority-1 payment, therefore the entire economic model, therefore the pilot's ability to pay anyone, therefore P-01…P-15 as a set** |
| **2** | **LDR-U01 CEO versus National Council** | A-N17, A-N18, A-N19, A-N21, A-N22, LDR-U03, LDR-U04, LDR-U07, LDR-U11, LDR-U12, LDR-U16, **[S-D: L-33]**, **[S-E: GATE E7]** | Every reserved matter, every appeal of a leadership decision, every national claim approval |
| **3** | **A-N16 bank mandate and signatories** | A-B9, B-05, B-13, **[S-D: INV-2]** | **The first external payment.** Independent of scale and not deferrable |
| **4** | **A-N10 insurance and liability answers** | A-B2, A-11 activation gate, all protection activity | The protection pillar entirely; **[S-E: CC-1, CC-7]** |
| **5** | **LDR-U06 minimum staffing** | **[S-D: L-28, Rule D-33, MVLS]**, any new unit, **[S-E: GATE E4]** | **Authorisation of the pilot team itself** — one team's `n_min` must be decided to authorise it |

**[P] Rule F-10 (Authority Precedes Everything).** Decisions 1, 2 and 5 have this property: **the body that would decide them is itself partly constituted by them.** LDR-U01 determines whether a Council can decide anything; LDR-U08 determines what legal person is deciding; LDR-U06 determines whether a decider exists at unit level. **[A]** The only escape is that all three sit with the **founder/CEO under [S: Ch.4] ownership authority**, which is APPROVED architecture. **That is not a resolution of LDR-U01 — it is the fact that, today, one person can decide all three, and [S-A: A-12] documents that concentration without changing it.**

---

# PART V — CRITICAL BLOCKERS

## V.1 The classification test, adopted rather than reinvented

**[S-A: §23.1]** supplies a four-class taxonomy with an explicit test, and v1.3-F adopts it instead of inventing a competing one:

| Class **[S-A]** | Test applied | Meaning |
|---|---|---|
| **BLOCKER** | *If this is absent, the capability either cannot lawfully or ethically operate, or its failure causes harm that cannot be reversed* | The relevant capability may not activate |
| **HIGH PRIORITY** | *Harm is likely and material within the pilot, but is detectable and correctable* | Must be in place before first public use or first significant volume |
| **IMPORTANT** | *Harm emerges with scale rather than with the pilot* | Must be in place before major scaling |
| **LATER** | *Value is real but the correct design depends on pilot evidence* | Build after evidence; designing it now would be guesswork |

**[S-A: §23.1, verbatim]** — "nothing is a blocker merely because it would be *good*. **Software completeness, badges, ceremonies, the state layer, the leaderboard, national branding and the full 14-module platform are not in the blocker list.**"

**[P] Rule F-11 (Six Categories, Not One List).** The brief requires six. They are derived from the **[S-A]** taxonomy by splitting BLOCKER into the four kinds of act it requires — decide, validate, build, fund — and adding the two deferral categories. **No item is promoted to a blocker that [S-A] placed lower, and no item is demoted that [S-A] placed higher.**

## V.2 BLOCKER A — MUST DECIDE BEFORE PILOT

| ID | Decision | Source | Why it cannot wait | If deferred |
|---|---|---|---|---|
| **BLK-A-01** | **Legal structure under Krytos** | **LDR-U08**; **[S: Ch.33]**; **A-B1** | Everything involving money, contracts and employment requires a legal person | **The pilot cannot lawfully pay a worker, sign a contract, hold a bank account or be insured** |
| **BLK-A-02** | **Worker classification** | **LDR-U09**; **A-B1**; **[S-C: HV-1]** | Priority 1 is worker compensation; the classification determines whether paying it is lawful | Unrecorded statutory liability from the first payment |
| **BLK-A-03** | **Bank mandate continuity and minimum signatories** | **A-N16**; **A-B9** | Independent of scale, and **[S-D: INV-2]** makes priority-1 payment non-suspendable | Worker compensation stops on one person's absence |
| **BLK-A-04** | **Adopt the Political Neutrality Code (A-01 N1…N9)** | **A-N1**; **A-B4** | Required "before the first public activity" | Any public act carries political-perception exposure with no rule to point to |
| **BLK-A-05** | **Approve the Public Protection Statement (A-07) and entrench the DO-NOT list (A-08)** | **A-N7, A-N8**; **A-B5** | Required before any public description of the protection function | MC-3 vigilante misclassification, rated **Severe** |
| **BLK-A-06** | **Adopt the Protection Visibility Protocol V1…V43 (PD-8)** | **A-N6** | A single image creates the perception | Uniform, insignia or crowd presence; **"V10 flag/banner/stall prohibition unenforced** |
| **BLK-A-07** | **Adopt the Protection Incident Protocol matrix, triggers and do-not-attend list (A-09)** | **A-N9** | Improvised local response to a high-risk situation | An incident handled without authority, record or boundary |
| **BLK-A-08** | **Adopt the Protection Activation Gate (A-11) and its scope** | **A-N11**; **A-B8** | Otherwise capability activates as a side-effect of filling a vacancy | Protection activity without a gate, scope or renewal |
| **BLK-A-09** | **Set `n_min` for the pilot team** | **LDR-U06**; **[S-D: L-28, Rule D-33]** | One team's minimum staffing must be decided in order to authorise it | A unit operates without the four capabilities Rule D-33 requires |
| **BLK-A-10** | **Adopt MVLS-1…MVLS-12** | **[S-D: L-21, LDR-19]** | Twelve items non-deferrable at any stage | The smallest safe leadership system does not exist |
| **BLK-A-11** | **Adopt the amendment sequencing (A-N38)** | **A-N38** — "Immediately" | Otherwise 164 amendments arrive at once and nothing is implemented | Amendment fatigue; **[S-A: A-N38]** names this exact risk |
| **BLK-A-12** | **Decide whether founder compensation is nil for the pilot, and record it** | **LDR-U16** | Priority 4 of the waterfall; the published accounts must state it | Either the founder is paid without a rule, or the deficit is invisible |
| **BLK-A-13** | **Appoint a named privacy officer and data fiduciary** | **A-N14**; **A-B7** | Duties attach with no accountable person | A breach has no notifier; **[X]** statutory notification windows are missed |

## V.3 BLOCKER B — MUST VALIDATE BEFORE PILOT

| ID | Validation | Category | Source | Blocks |
|---|---|---|---|---|
| **BLK-B-01** | Entity form, objects clauses permitting all four pillars, dissolution and restructuring | **V-01** | **A-B1**; **[S: Const. Art.19]** | BLK-A-01 |
| **BLK-B-02** | Tax position: 12A application-of-income and political-activity conditions; 80G; FCRA timing | **V-04** | **A-B1**; **[X]** | BLK-A-01, BLK-A-04 |
| **BLK-B-03** | Worker classification and its statutory consequences | **V-05** | **A-B1** | BLK-A-02 |
| **BLK-B-04** | Written answers to **A-10 §9.1 L1–L15** insurance and liability | **V-06** | **A-B2**; **A-N10** | All protection and first-response activity |
| **BLK-B-05** | Intervention boundary: private-person arrest and handover, duty to assist, Good-Samaritan and first-aid protections, mandatory reporting duties | **V-09, V-17** | **A-B3**; **[X]** BNSS 2023 ss.31, 40, 43 | Protection training beyond the basic steps; any work with minors |
| **BLK-B-06** | Certified safeguarding standards, the two-adult rule, reporting protocols, consent validity for minors and vulnerable adults | **V-08** | **A-B6**; **[S-C: SA-1…SA-7]** | **Any activity involving a minor or vulnerable adult** |
| **BLK-B-07** | Privacy minimum: lawful basis and consent design, notice content and languages, purpose limitation, **retention schedule**, breach runbook | **V-07** | **A-B7**; **A-N26** | Any systematic collection of personal data |
| **BLK-B-08** | Non-police ID card design | **V-11, V-17** | **[S: Ch.31]**; **A-N31** | Issuing any card or token |
| **BLK-B-09** | Comms policy including public-statement rules and misinformation-correction procedure | **V-16** | **[S: Ch.31]**; **A-N7** | Any public statement |
| **BLK-B-10** | Per-state political association of any colour, symbol, date or term actually used | **V-16, V-17** | **[S-C: H-26 field 11]**; **LV-E-8** | Any visual or ceremonial artefact |
| **BLK-B-11** | LA-1 texts in the pilot locality's language, legally reviewed | **V-01, V-07** | **[S-E: Rule E-66, E-68]**; **[S-C: H-25]**; **A-H10** | Any rights, duties, consent or grievance text |

## V.4 BLOCKER C — MUST BUILD BEFORE PILOT

**[A]** Eleven items. **All are paper or human; none is software.** This is a direct consequence of **[S-B: §40]** — the pilot runs with no technology.

| ID | Build | Source | Mechanism | Owner (role) | Record produced |
|---|---|---|---|---|---|
| **BLK-C-01** | The legal entity and its governing documents | **A-B1**; **[S: Ch.33]** | Registration, objects clause, articles or deed | Founder/CEO with corporate counsel | Certificate, objects clause, register of officers |
| **BLK-C-02** | The privacy minimum | **A-B7**; **A-N25, A-N26, A-N27, A-N29** | C1–C4 classification; retention schedule; notice in the operating language; rehearsed breach runbook; named officer | Privacy officer with Legal | Classification register; schedule; published notice; runbook and rehearsal record |
| **BLK-C-03** | The certified safeguarding capability | **A-B6**; **[S-C: SA-1…SA-7]** | Certified training; the two-adult rule; image and consent absolutes; reporting protocol | Safety with a safeguarding specialist | Certificates; protocol; consent forms |
| **BLK-C-04** | The neutrality instrument set | **A-B4**; **A-N1…A-N4** | The Code; the refusal script in the operating language; the written-reply template; **the approach register** | CEO with National Legal | The Code; scripts; **a refusal log with a published count** |
| **BLK-C-05** | The protection boundary set | **A-B5, A-B8**; **A-N6…A-N9, A-N11** | The Public Protection Statement; the entrenched DO-NOT list; **V1…V43**; the incident matrix; the Activation Gate | National Safety with Legal | Published statement; entrenched list; incident records with the **V42–V43 visibility fields** |
| **BLK-C-06** | The bank mandate and credential custody | **A-B9**; **[S-A: A-14 §13.4]** | Two or more signatories with a continuity rule; dual custody of every credential and channel | Finance with CEO | Mandate document; custody register; emergency-access procedure |
| **BLK-C-07** | The comms policy and the non-police ID card design | **[S: Ch.31]** — **both are v1.2 launch blockers** | Public-statement rules; misinformation correction; approved card mock-up | Communications with Legal | The policy; the approved mock-up |
| **BLK-C-08** | **The public local record PLR-1…PL-7, on paper** | **[S-C: H-03]**; **[S-E: E-16, Rule E-79]**; **[S-ST: §20.3]** | One sheet per locality with the seven elements; ungated; unadorned | The team | The posted sheet; a dated local result record |
| **BLK-C-09** | **The outward-reaching complaint route** | **[S-D: MVLS-9]**; **[S-ST: M10, §14.1]** | A route that reaches outside the local unit, published, with non-retaliation | Team intake with an out-of-locality recipient | Complaint log; outcome record |
| **BLK-C-10** | **The correction log and the refusal log** | **[S-E: TS-6, TS-8, Rule E-88, Rule E-186]**; **[S-A: A-04]** | Two logs, append-only, published, requiring no approval to enter | Anyone who finds an error; Audit reviews | **A non-empty correction log; a refusal count** |
| **BLK-C-11** | The decision register in operation | **[S-A: A-15 M1]**; **[S-D: LM-3]** | Every decision with its reason, decider and date | The decider; Audit samples | **LM-3 decision-record completeness** |

## V.5 BLOCKER D — MUST FUND / RESOURCE BEFORE PILOT

**[A]** No rupee value is asserted. **Every entry is a funding *requirement*, and every amount is `UNKNOWN — MEASURE IN PILOT` or a symbolic variable from [S-B].**

| ID | Requirement | Source | Variable | Note |
|---|---|---|---|---|
| **BLK-D-01** | **Worker compensation at priority 1** | **[S: Ch.18]**; **[S-D: INV-2]** | `C_wc` | **Non-suspendable.** Cannot be paid until BLK-A-01…03 are closed |
| **BLK-D-02** | Statutory obligations at priority 2 | **[S: Ch.18]** | `C_stat` | Depends on BLK-A-02 classification |
| **BLK-D-03** | Direct business costs at priority 3 | **[S: Ch.18]** | `C_var` | — |
| **BLK-D-04** | **First-season float** | **[S-B: B-04]** | `M_to_buffer` | "Very large when average surplus is small, and grows super-linearly" |
| **BLK-D-05** | Wage-protection buffer | **[S-B: §13]** | Derived from `S̄_5` | **`S̄_5` is unmeasured; the buffer cannot be sized until the pilot measures it** |
| **BLK-D-06** | Reserve seed | **[S-B: B-03]** | Per the seeding order | Custody is **A-N15 `UNRESOLVED`** |
| **BLK-D-07** | **Professional fees for BLK-B-01…BLK-B-11** | Part III | Not stated anywhere | **The single most overlooked pre-pilot cost in the corpus: eleven validations across eight professional categories** |
| **BLK-D-08** | Insurance premia | **A-N10** | Unknown until BLK-B-04 | May be unavailable for volunteer first-response activity **[V]** |
| **BLK-D-09** | **Translation of the mandatory language set** | **[S-E: Rule E-66]**; **[S-B: HC-19]** | LA-1 and LA-5 fully; LA-3 four items | **LA-5 emergency text must be pre-positioned before the emergency** |
| **BLK-D-10** | Certified safeguarding training | **A-B6** | Per participant | — |
| **BLK-D-11** | **`H_gov` — governance hours, including communication hours** | **[S-B: §25]**; **[S-E: Rule E-168]** | 8–40 h/team/month is the **observation window**, not a target | **Communication hours are not costed in any prior instrument ([S-E: §42.5 EA-E1])** |
| **BLK-D-12** | Trainer time, paid | **[S-D: Rule D-47]**; **[S-B]** | — | Trainer supply is the binding constraint on leader production **[S-ST: Scenario B]** |
| **BLK-D-13** | Mentorship as paid work | **[S-D: L-12]** | — | Otherwise mentoring competes with paid delivery |
| **BLK-D-14** | The pilot's own measurement effort | Part IX | 60 measurements, 47 testable | **Recording 60 measurements by hand, with no technology, is itself a workload the pilot must absorb** |

**[P] Rule F-12 (An Unfunded Blocker Is A Blocked Blocker).** BLK-D-07, BLK-D-09 and BLK-D-11 are the three most likely to be omitted from a pilot budget, because none of them appears in **[S-B]**'s cost model and all three are prerequisites rather than activities. **A pilot authorised without them will proceed and will fail on a compliance or language ground rather than on an architectural one.**

## V.6 BLOCKER E — MAY BE TESTED DURING PILOT

**[A]** Items whose correct design **depends on pilot evidence**, and which would be guesswork if built now. **[S-A: §23.5 A-L1…A-L7]** is the source.

| ID | Item | Source | Why it belongs here |
|---|---|---|---|
| **BLK-E-01** | **Numeric values for every interval, ratio, threshold and period** | **A-L1** | "The source deliberately does not invent numbers; pilot evidence should set them" |
| **BLK-E-02** | `m_lead`, `σ_max`, `K_min`, `c`, the City divisor shape | **LDR-U02, U13, U14, U15**; **[S-B]** | All are measured, not chosen — **P-01, P-15, LM-12, LM-13** |
| **BLK-E-03** | Cohort definitions and normalisation | **L-06** | **`SKIP-NT` — a cohort of one is not a cohort** |
| **BLK-E-04** | Out-of-team assessment capability | **[S-D: §52.3 step 5]** | Requires a second team; **the pivot from D to B** |
| **BLK-E-05** | Succession coverage, continuity testing, playbook exercise | **L-08, L-16, L-20** | **LM-1, LM-2, CT-A/CT-B** |
| **BLK-E-06** | Promotion transition protocol | **L-09** | Requires an actual promotion; **LM-14** |
| **BLK-E-07** | Complaint, appeal and improvement routes under real use | **L-23** | **LM-9; LM-10 is `SKIP-NT`** |
| **BLK-E-08** | Load and dependency indices, burnout signals | **L-25**; **[S-B: B-22]** | **LM-6, LM-7** |
| **BLK-E-09** | The whole human journey | **[S-C: H-28]** | **HM-1…HM-15** |
| **BLK-E-10** | First contact, first five minutes, first real win | **[S-E: E-15, E-16, E-17]** | **CI-1 (partial), CI-2, PS-E1…PS-E4** |
| **BLK-E-11** | Claim traceability, correction performance, language match, publication completeness, attribution and consent compliance, unaffiliated repeat use | **[S-E: E-05, E-19, E-13, E-34]** | **CI-6, CI-8, CI-9, CI-11, CI-12, CI-14, CI-15 — all fully testable by one team on paper** |
| **BLK-E-12** | Anti-gaming and Goodhart controls under real incentive pressure | **L-18** | Requires real incentives, which require real work |
| **BLK-E-13** | Venture economics, collection terms, idle capacity, service-hour budget | **B-01…B-06, B-11, B-13, B-14** | **P-02…P-05, P-09, P-11** |
| **BLK-E-14** | Hybrid funding map in practice | **B-26** | **P-07, P-10** |
| **BLK-E-15** | Mission balance | **[S-ST: §17.3; M14]** | Requires both service and commercial activity to have occurred |
| **BLK-E-16** | Whether the organisation will actually publish a correction | **[S-E: ES.5, OQ-E19, MAF-04]** | **CI-9 — and this is the item on which the entire reputation architecture depends** |
| **BLK-E-17** | Local identity and recognition forms | **[S-E: R-14, R-20]**; **[S-C: H-13]** | Local by design; tested by use |
| **BLK-E-18** | The category sentence | **N-E-21** | `NOT ADOPTED — draft only`; **CI-2 must be measured before adoption** |

## V.7 BLOCKER F — MAY SAFELY WAIT UNTIL AFTER PILOT

| ID | Item | Source | Why it can wait |
|---|---|---|---|
| **BLK-F-01** | **The software platform — all 14 modules** | **[S-A: §23.1]** explicitly not a blocker; **[S-B: §40]** no technology | **The pilot proves every process is executable on paper** |
| **BLK-F-02** | Any app, dashboard, leaderboard or AI feature | **[S-A: §23.1]**; **[S-D: L-26]**; **LDR-U11** | None is required; the leaderboard question is unresolved anyway |
| **BLK-F-03** | The mark, palette and logo | **N-E-02**, blocked by **A-N12** | **Rule E-65 permits word-only identification: "Sewak Sathi Sanstha — [locality]" is sufficient** |
| **BLK-F-04** | **National branding of any kind** | **[S-A: §23.1]**; **[S-E: Rule E-60]** | Blocked by A-N12 and A-N13, and prohibited below CL-7 |
| **BLK-F-05** | Badges, ceremonies, oaths, uniforms, a national day | **[S-A: §23.1]**; **[S-D: §21.7]**; **[S-C: H-13]**; **[S-E: Rule E-144]** | **Most are refused outright, not deferred** |
| **BLK-F-06** | The State layer and any federation | **[S-A: A-L7]**; **[S-ST: §2.3]** | "Works as coordination; fails as a formal layer too early" |
| **BLK-F-07** | Contribution portability across localities | **[S-E: E-41]** | Requires ≥ 2 localities |
| **BLK-F-08** | Mission lock, apex succession execution, apex dispute resolution | **A-I1, A-I2, A-I3** | Important-before-scaling — **but A-N17 says "preferably before the first hire"** |
| **BLK-F-09** | The full-scope 72-hour continuity test | **A-L2**; **[S-D: CT-C]** | A tabletop version can run earlier |
| **BLK-F-10** | Oral history; public archive; published institutional memory | **A-L3, A-L4** | Valuable once there is history; requires mature redaction |
| **BLK-F-11** | The full-form annual AI governance report | **A-L5** | Requires a year of AI use; the pilot has none |
| **BLK-F-12** | External independent privacy and governance reviews | **A-L6**; **[S-E: OQ-E17]** | "Appropriate once there is something substantial to review" — **and Rule E-189 forbids promising one without a mechanism** |
| **BLK-F-13** | DPIA programme and significant-fiduciary assessment | **A-I10**; **LV-12** | "Obligations attach at scale **[X]**" |
| **BLK-F-14** | Composition monitoring | **A-N5** | Must be decided deliberately before any collection — and the pilot should collect none |
| **BLK-F-15** | Brand and IP ownership **at national scale** | **A-N12, A-N13**; **A-I6** | Important-before-scaling — **but see the caveat below** |
| **BLK-F-16** | Key-person dependency register at national scope | **A-N20**; **A-I5** | "Becomes unbuildable retrospectively" — so start it early even though it scales later |

**[P] Rule F-13 (Two Deferrals Are Riskier Than They Look).** **BLK-F-08** and **BLK-F-15** are correctly classified as post-pilot by **[S-A]**, and both carry a source caveat that pulls them earlier: **A-N17** says apex succession should be adopted "preferably before the first hire", and **A-I6** says brand and IP ownership must be settled "before many parties rely on the brand." **[A]** A pilot with one team and a handful of members does not create "many parties" — but a pilot that publishes a public local record, issues a contribution record, signs a partnership and posts a paper sheet in a lane **does** create parties relying on the name. **Recommendation recorded, not decided: bring A-N12 to a decision before the first public artefact bearing the name, not before national expansion.**

---

# PART VI — DEPENDENCY GRAPH

## VI.1 Method

**[P]** Each dependency is stated as **A → B** with the reason in the form the brief requires: *"if A remains unresolved, B cannot be validly demonstrated."* **Twenty-five chains are tested, as mandated.**

## VI.2 The twenty-five chains

| # | **A → B** | If A remains unresolved, B cannot be validly demonstrated because… | Evidence |
|---|---|---|---|
| **1** | **Brand / IP ownership (A-N12, A-N13) → national identity claims (GATE E7, CL-8)** | a claim made under a mark nobody is documented to own is a claim the organisation may not be entitled to make, and **[S-A: A-I6]** requires settlement "before many parties rely on the brand" | **[S-E: Rule E-60]** |
| **2** | **Brand / IP ownership → the mark, palette and ID card (N-E-02, BLK-B-08)** | a design cannot be approved for an asset whose owner is unknown; **[S: Ch.31]** requires an "approved card mock-up" and approval presupposes ownership | **[S-E: N-E-02]** |
| **3** | **Communication launch blocker (comms policy + ID card) → any public statement or any issued card** | **[S: Ch.31]** classifies both as `Blocker`; an unauthorised public statement is the failure mode the policy exists to prevent | **[S: Ch.31]** |
| **4** | **Entity structure (LDR-U08) → economic viability measurement (P-01…P-15)** | there is no legal person to incur cost, hold an account, employ anyone or be audited; **the pilot's economic measurements have no subject** | **A-B1** |
| **5** | **Entity structure → worker classification (LDR-U09) → priority-1 payment** | classification depends on the entity form; payment depends on classification; **priority 1 is the waterfall's first and non-suspendable obligation** | **[S: Ch.18]**; **[S-D: INV-2]** |
| **6** | **Entity structure → data fiduciary identity (A-N14) → privacy notice and breach notification** | fiduciary duties attach to a legal person; without one there is no notifier and **[X]** DPDP timelines cannot be met | **A-B7** |
| **7** | **Entity structure → insurance (A-N10) → any protection activity** | cover is written on a legal person; **A-B2** blocks protection activity until answers exist | **A-B2** |
| **8** | **Pilot funding (BLK-D) → the pilot itself** | the float, buffer, professional fees, translation and governance hours must exist before activity, not after; **B-04** shows revenue lags cost | **[S-B: B-04]** |
| **9** | **Compensation formula (`m_lead`, LDR-U02) → leadership cost (LM-13) → leadership affordability** | `C_lead = C_wc_base × m_lead` is uncomputable without `m_lead`; **[S-D: EF-5 / EA-12]** affordability of leadership for a poor person stays untested | **[S-B: §24]** |
| **10** | **Social-impact funding → the social-impact line at priority 7** | the line exists in the waterfall but its formula is unresolved (**LDR-U18** 37.5/17/12 are illustrative) and its custody is unresolved (**A-N15**) | **[S: Ch.18, Ch.20]** |
| **11** | **Data governance (A-N25…A-N35) → any personal-data collection → any published aggregate** | classification precedes collection; retention precedes archiving; suppression precedes publication; **an aggregate published before classification may identify a person in a small cell** | **[S-A: A-17…A-20]**; **[S-D: Rule D-108]** |
| **12** | **HR verification capability → membership → any responsibility-bearing role** | **[S: Ch.12 immutable item 4]** makes verification gates non-waivable; without a verifier there is no member and no role-holder | **[S-ST: §12.1 item 4]** |
| **13** | **Safety protocol (A-06 V1…V43, A-08, A-09, A-11) → any public activity → any published claim** | **[S-B: §23.2]** and **[S-ST: §23.2]** place Safety among the two functions that must be ● early; a safety failure invalidates every claim made before it | **A-B5, A-B8** |
| **14** | **Insurance / legal support (A-N10) → protection activation (A-11) → the protection pillar** | the Activation Gate cannot pass without written liability answers | **A-B2, A-B8** |
| **15** | **Leadership assessment independence → Gate R → any promotion → succession coverage (LM-1)** | **[S-D: ES.5]**: Gate R requires an assessor outside the candidate's team, and **at Stage 0–1 there is no outside**; so no promotion can be validly assessed until a second team exists | **[S-D: Rule D-45]** |
| **16** | **Performance scoring (LDR-U03 weights) → any scored decision → any appeal** | a decision made on unapproved weights cannot be defended on appeal; **[S-D: Part 52 step 4]** therefore adopts windows and cohorts **without altering the PROPOSED weights** | **LDR-U03** |
| **17** | **Reputation disclosure (TS-1…TS-14) → trust → participation → CL-2 and above** | **[S-ST: §14.1]**: "all honesty machinery is internal. A stranger cannot see any of it"; trust that cannot be observed does not compound | **[S-E: E-19]** |
| **18** | **Correction logs (TS-6, Rule E-88) → the "we are verifiable" claim → the entire differentiation** | **[S-ST: §19.2 claim 1]** makes verifiability the core claim; a verification claim with nothing to verify is worse than no claim | **[S-E: Rule E-90, ES.5]** |
| **19** | **Public communication capacity (CAP-6) → GATE E6 → any state-level claim** | **[S-E: §42.5 EA-E1]**: communication is an unfunded obligation in every prior instrument; a gate cannot pass on an unfunded capacity | **[S-E: Rule E-168]** |
| **20** | **Pilot evidence (60 measurements) → CL-2 → every claim above it** | **[S-E: CL-0…CL-8]** ties each claim class to evidence; GATE E3 makes pilot evidence mandatory | **[S-E: Part 31]** |
| **21** | **National identity claims (CL-7, CL-8) → NI-5, NI-6 → GATE E7** | **[S-E: Rule E-215]**: a level is determined by the weakest locality claimed; and **all ten [S-ST: §14.3] plus all fifteen [S-ST: §30.3] pre-conditions must hold** | **[S-E: Part 58]** |
| **22** | **Expansion authority (LDR-U01) → XG-1…XG-8 and GATE E0…E7 → any expansion** | the body that authorises expansion is unresolved; **[S-D: Rule D-113]** interim procedure is the only fallback and it excludes reserved matters | **LDR-U01** |
| **23** | **Succession (A-N17, A-N18, LDR-U19) → continuity → institutional survival** | **[S-A: A-14]**: without an Interim Authority Order and reserved matters, an apex vacancy is an ending; **[S-D: LM-1, LM-2]** cannot be measured against a nonexistent state | **A-I2** |
| **24** | **Financial controls (A-N16, B-05, B-13, B-15, B-25) → published accounts (TS-3) → CL-2** | **[S-ST: §14.3 item 2]** requires one full year of published accounts; accounts cannot be published from an unaudited, unsegregated, unmandated ledger | **[S-E: Part 20 §20.4]** |
| **25** | **Audit → every claim in this register** | **[S: Ch.23]** makes the Auditor "review only; not operational commander"; **[S-D: INV-15]** preserves it. **If audit is not independent of the line it reviews, no measurement in Part IX is credible** | **[S: Ch.27]** |
| **26** | **Founder concentration (A-12, LDR-U01, LDR-U19) → institutional independence → national identity** | **[S-ST: §11.1]**: "the institution's identity and its legal continuity are the same object, held by one person"; **[S-E: SIM-10]** is the simulation the architecture is least able to survive | **[S-A: A-16]** |
| **27** | **Reserve custody (A-N15) → reserve release → shock absorption (B-11, B-15)** | a restricted fund held in an unrestricted instrument is not a reserve | **[S: Ch.18, Ch.20]** |
| **28** | **Bank mandate continuity (A-N16) → priority-1 payment during an apex vacancy** | **[S-A: A-14 §13.4]** requires minimum two signatories precisely so compensation can be paid when the apex is vacant | **A-B9** |

**[A]** Chains 4, 5, 6 and 7 all originate at **LDR-U08 entity structure**. **Chain 22 originates at LDR-U01.** Together those two decisions are the roots of eleven of the twenty-eight chains.

---

# PART VII — CRITICAL PATHS

## VII.1 The eight paths

**[P]** Each path is the **smallest chain** that controls readiness in its domain. Items are ordered; nothing is added that is not already in the corpus.

### CP-1 GOVERNANCE

```
LDR-U01 CEO vs Council authority          [AUTHORITY UNRESOLVED]
   -> A-N18 reserved-matters list
   -> A-N17 apex succession mechanism
   -> A-N19 apex dispute resolution        [AUTHORITY UNRESOLVED]
   -> A-N21/A-N22 Mission Lock Tier-1
   -> [S-D: L-33] governance bodies + RACI + interim reserved-matter procedure
   -> A-N38 amendment sequencing           [must be FIRST in practice]
   -> BLK-C-11 decision register operating (A-15 M1)
```
**Length: 8 steps. Blocking effect: HIGH — but only for reserved matters, which do not arise in a one-team pilot.**

### CP-2 LEGAL / COMPLIANCE

```
LDR-U08 entity structure                  [UNRESOLVED — THE ROOT]
   -> V-01 corporate counsel: form, objects clauses, dissolution
   -> V-04 tax counsel: 12A / 80G / FCRA conditions
   -> V-05 labour counsel: worker classification (LDR-U09)
   -> A-N16 bank mandate + two signatories (A-B9)
   -> A-N14 data fiduciary + named privacy officer
   -> V-07 privacy: classification, retention, notice, breach runbook (A-B7)
   -> V-06 insurance: written answers to A-10 L1-L15 (A-B2)
   -> V-09 criminal/regulatory: intervention boundary, reporting duties (A-B3)
   -> V-08 safeguarding: certified standards, two-adult rule (A-B6)
   -> A-N1..A-N4 neutrality code adopted (A-B4)
   -> A-N6..A-N9, A-N11 protection visibility, statement, DO-NOT, gate (A-B5, A-B8)
   -> BLK-B-08..11 ID card, comms policy, per-state review, LA-1 texts
   -> PILOT MAY BE AUTHORISED
```
**Length: 13 steps. Blocking effect: MAXIMUM — it gates every other path.**

### CP-3 ECONOMIC

```
LDR-U08 entity  ->  LDR-U09 classification  ->  [S: Ch.18] waterfall operable
   -> BLK-D-04 first-season float  ->  BLK-D-05 wage-protection buffer
   -> BLK-D-06 reserve seed (custody A-N15 unresolved)
   -> B-05 accrued compensation ledger  ->  B-13 collection terms
   -> B-01/B-02 service-hour budget  ->  B-26 hybrid funding map
   -> P-01..P-15 measured  ->  sigma_max, m_lead, K_min, c, City divisor OBSERVED
```
**Length: 11 steps. Blocking effect: HIGH — and it cannot start before CP-2 step 1.**

### CP-4 HUMAN / MEMBERSHIP

```
H-02 nine-level spectrum  ->  H-01 four doors  ->  H-07 no forced progression
   -> BLK-C-08 public local record PLR-1..PL-7  ->  H-04/H-05 first contact
   -> H-06 paired first task  ->  H-15 attribution loop
   -> H-17 refusal rights + H-18 paused status  ->  H-22 beneficiary separation
   -> H-25 language architecture (LA-1..LA-5, mandatory set)
   -> HM-1..HM-15 measured
```
**Length: 11 steps. Blocking effect: MEDIUM — depends on CP-2 for the privacy notice and LA-1 legal review, and on BLK-C-08/09.**

### CP-5 LEADERSHIP

```
BLK-A-09 n_min for the pilot team  ->  BLK-A-10 MVLS-1..MVLS-12
   -> L-08 SS states recorded  ->  L-01 Gate E operating
   -> L-10 temporary instruments  ->  L-16 playbooks
   -> L-23 complaint, appeal, improvement, removal routes
   -> LDR-01..LDR-20 adopted  ->  LM-1..LM-15 measured
   -> [SECOND TEAM] -> out-of-team assessment capability -> Gate R valid
```
**Length: 10 steps. Blocking effect: MEDIUM at pilot, MAXIMUM at expansion — the last step is [S-D: §52.3 step 5], the pivot.**

### CP-6 SAFETY

```
A-08 DO-NOT list entrenched  ->  A-06 V1..V43 adopted  ->  A-07 statement published
   -> A-09 incident matrix, triggers, do-not-attend list  ->  A-11 Activation Gate
   -> A-N10 insurance answers (A-B2)  ->  certified safeguarding (A-B6)
   -> BLK-C-05 built  ->  stop-work capability present at all times
   -> incident records with V42-V43 visibility fields
```
**Length: 10 steps. Blocking effect: HIGH — [S-ST: §23.2] makes Safety one of only two functions that must be ● early.**

### CP-7 COMMUNICATION / REPUTATION

```
BLK-C-07 comms policy ([S: Ch.31] blocker)  ->  BLK-B-08 ID card design
   -> E-13 mandatory translation set + LA-5 pre-positioned
   -> BLK-C-08 PLR-1..PL-7  ->  BLK-C-09 outward complaint route
   -> BLK-C-10 correction log + refusal log
   -> E-29 claim ladder + E-46 claim classes and evidence labels
   -> E-19 TS-1..TS-14  ->  CI-1..CI-15 measured
```
**Length: 9 steps. Blocking effect: MEDIUM at pilot — but [S: Ch.31] makes two of them launch blockers in the source's own terms.**

### CP-8 TECHNOLOGY / DATA

```
A-N25 classification C1-C4 + field register  ->  A-N32 prohibited-collection list
   -> A-N26 retention schedule (UNRESOLVED)  ->  A-N27 privacy notice
   -> A-N29 breach runbook rehearsed  ->  A-N30 processor standard
   -> A-N31 QR use restriction  ->  A-N35 sealed-case model + subject rights
   -> [PILOT: PAPER ONLY]  ->  (platform deferred to BLK-F-01)
```
**Length: 9 steps to the pilot; **the technology half is entirely deferred**. Blocking effect: HIGH for data governance, NIL for software.**

## VII.2 The master critical path

**[P]** The smallest chain that controls pilot readiness, across all eight paths:

```
STEP 1   LDR-U08  DECIDE THE LEGAL ENTITY STRUCTURE
            |      (the entity-structure decision paper for counsel -
            |       the single next artifact, one-page answer item 19)
            v
STEP 2   V-01 + V-04 + V-05  COUNSEL VALIDATES FORM, TAX AND CLASSIFICATION
            |      (LDR-U09 resolved as a consequence)
            v
STEP 3   A-N16  BANK MANDATE + TWO SIGNATORIES   [A-B9]
            |
            v
STEP 4   PRIORITY-1 WORKER COMPENSATION CAN NOW LAWFULLY BE PAID
            |      <-- the first moment the economic model is real
            v
STEP 5   A-N14 + A-N26 + V-07  DATA FIDUCIARY, RETENTION, PRIVACY MINIMUM  [A-B7]
            |
            v
STEP 6   A-N10 + V-06  INSURANCE AND LIABILITY ANSWERS  [A-B2]
            |
            v
STEP 7   V-09 + V-08  INTERVENTION BOUNDARY + CERTIFIED SAFEGUARDING  [A-B3, A-B6]
            |
            v
STEP 8   A-N1..A-N9, A-N11  NEUTRALITY CODE + PROTECTION SET ADOPTED  [A-B4, A-B5, A-B8]
            |
            v
STEP 9   BLK-C-07 + BLK-B-08/09  COMMS POLICY + ID CARD DESIGN  [[S: Ch.31] blockers]
            |
            v
STEP 10  BLK-A-09 + BLK-A-10  n_min SET + MVLS ADOPTED
            |
            v
STEP 11  BLK-C-01..C-11 BUILT  (entity, privacy, safeguarding, neutrality,
            |                   protection, bank, comms, PLR, complaint route,
            |                   correction + refusal logs, decision register)
            v
STEP 12  BLK-D-01..D-14 FUNDED  (compensation, float, buffer, reserve,
            |                   professional fees, insurance, translation,
            |                   training, H_gov incl. communication, measurement effort)
            v
STEP 13  GATE P0 (Part VIII)  ->  PILOT AUTHORISED
```

**[A] Thirteen steps. Step 1 is a decision that one person can make today. Steps 2, 6, 7 and 9 require external professionals. Steps 3, 5, 8, 10 and 11 are build acts. Steps 4 and 12 are funding consequences. Nothing in the chain requires software, a mark, a second team, or any national ambition.**

**[P] Greatest downstream blocking effect: CP-2 LEGAL / COMPLIANCE**, and within it **LDR-U08 entity structure**. **Eleven of the twenty-eight dependency chains in Part VI root at LDR-U08 or LDR-U01.** No priority score is used, because the corpus does not supply one — the ranking is by **count of chains rooted**, which is observable from Part VI.

---

# PART VIII — PILOT READINESS GATE

## VIII.1 GATE P0 — PILOT AUTHORISATION

**[P]** A formal gate. **The organisation must not be declared pilot-ready merely because documents are complete** — that is Rule F-1 and Part XVIII in operational form.

**[P] Rule F-14 (P0 Is Conjunctive And Recorded).** All ten sub-gates must PASS. **A PASS requires evidence, not assertion.** The authorisation record names: the sub-gate, the evidence produced, the responsible authority, the date, and — where a sub-gate FAILs — whether the pilot is blocked or whether the blocked capability is withdrawn from scope. **The last option is the one that makes the gate usable: a FAIL on P0-F need not block a pilot that does no protection activity at all, provided the withdrawal is recorded and the capability is genuinely absent rather than nominally absent.**

| Sub-gate | Domain | **PASS condition** | **FAIL condition** | **Evidence required** | **Responsible authority** | Dependency | Blocks pilot? |
|---|---|---|---|---|---|---|---|
| **P0-A** | **Governance readiness** | The entity exists; the reserved-matters list is adopted; the interim reserved-matter procedure exists; **the decision register is operating and produces records**; amendment sequencing adopted (A-N38); `n_min` for the pilot team set; MVLS-1…MVLS-12 adopted | No legal person; no reserved-matters list; no decision records; **LDR-U01 unresolved AND no interim procedure adopted** | Certificate of registration; objects clause; reserved-matters document; **≥1 decision record with reason, decider and date**; MVLS adoption record; `n_min` decision record | Founder/CEO with Council **if constituted**; otherwise Founder/CEO under **[S: Ch.4]** | **LDR-U08**; LDR-U01 (interim procedure suffices) | **YES** |
| **P0-B** | **Legal / compliance readiness** | All eleven BLK-B validations complete with written opinions held; the Political Neutrality Code adopted; the Public Protection Statement and DO-NOT list approved; the protection set A-06 V1…V43, A-09, A-11 adopted | Any BLK-B item outstanding; **any activity undertaken outside a validated boundary** | Written opinions per category, held as governance evidence **[S-A: A-N10]**; adoption records; published statement in the operating language | National Legal with Founder/CEO | **CP-2 in full** | **YES** |
| **P0-C** | **Economic readiness** | A bank account exists with **≥2 signatories and a continuity rule**; the float and wage-protection buffer are funded; the accrued-compensation ledger exists; collection terms are set; the waterfall is operable and priority 1 has been paid at least once | No mandate; **no float**; priority 1 unpaid or unpayable; no ledger | Mandate document; bank statement; **one completed payment sheet with its formula version [S: Ch.19 step 13]**; ledger extract | Finance with CEO | **LDR-U08, LDR-U09, A-N16** | **YES** |
| **P0-D** | **Human-system readiness** | PLR-1…PL-7 exist on paper for the locality; the two ungated actions operate; the minimum safe pathway is implemented; refusal rights and paused status exist in the operating language; **no beneficiary-to-participant pathway exists**; the mandatory translation set is present | Any first-contact artefact asks for something; **LA-1 texts absent or unreviewed**; a conversion pathway exists | The posted sheet; the intake record; **the refusal script in the operating language**; the LA-1 review record | Team with City support and Communications | **BLK-C-08, BLK-B-11** | **YES** |
| **P0-E** | **Leadership readiness** | Every role in the pilot team has a recorded SS state; Gate E criteria are published; **Gate R is recorded as a known gap** with no promotion planned; temporary instruments exist with automatic expiry; playbooks exist for every covered role | A role has no SS state; **a promotion is planned during the pilot without an out-of-team assessor** | SS-state register; Gate E criteria; TL instrument templates; **≥1 playbook exercised (CT-B)** | Team Leader with HR & Verification | **BLK-A-09, BLK-A-10**; **[S-D: Rule D-45]** | **YES — unless no promotion occurs and the gap is recorded** |
| **P0-F** | **Safety readiness** | Insurance answers written; certified safeguarding in place; the two-adult rule operational; the Activation Gate adopted; stop-work capability present; **incident records carry the A-06 V42–V43 visibility fields** | Any protection activity without insurance; any minor activity without certified safeguarding; no stop-work capability | Written insurance answers; certificates; Activation Gate record; **an incident-record template containing the V42–V43 fields** | National Safety with Legal | **A-N10, A-N11, A-B6** | **YES for any protection or minor-involving activity. A pilot scoped to exclude both may proceed with the exclusion recorded** |
| **P0-G** | **Communication readiness** | The comms policy exists (**[S: Ch.31] blocker**); the non-police ID card design is approved (**[S: Ch.31] blocker**); the claim ladder and claim classes are adopted; **the correction log and refusal log exist and are published**; the category sentence is registered — **or explicitly not adopted, with the draft's status recorded** | Either **[S: Ch.31]** blocker undelivered; **no correction log**; any claim published above CL-1 | The policy; the approved mock-up; **the two logs, even if empty, with the emptiness publication rule adopted**; the claim register | Communications with Legal | **BLK-C-07, BLK-C-10, BLK-B-08** | **YES** |
| **P0-H** | **Data / technology readiness** | C1–C4 classification adopted with a field register; the prohibited-collection list adopted; **a retention schedule exists with counsel-set periods**; a privacy notice published in the operating language; a breach runbook rehearsed; the sealed-case model and subject rights adopted; **no technology is required** | No classification; **no retention schedule**; no rehearsed runbook; any C4 data held as ordinary team data | Classification register; schedule; published notice; **a rehearsal record**; sealed-case procedure | Privacy officer with Legal and AI & Data | **A-N14, A-N25…A-N35** | **YES** |
| **P0-I** | **Measurement readiness** | All 60 measurements have a named recorder, a named verifier, a method executable on paper, and a recording form; **the 13 `NOT TESTABLE AT PILOT SCALE` items are recorded as such with their minimum populations**; every threshold either comes from source or reads `THRESHOLD REQUIRES FINAL APPROVAL` | Any measurement without a recorder; **any invented threshold**; any `NOT TESTABLE` item approximated | The measurement plan (Part IX); the recording forms; the not-testable schedule | City owner with Audit | **H-28, L-39, E-45, [S-B: §40]** | **YES** |
| **P0-J** | **Funding / resource readiness** | BLK-D-01…D-14 are funded or their absence is recorded with the consequence; **`H_gov` including communication hours is declared per role and tested against `σ_max`**; professional fees for BLK-B are paid or committed | Any priority-1 obligation unfunded; **`H_gov` undeclared**; professional fees unbudgeted | A funding statement in variables and commitments — **no rupee figure is required by this register and none is invented**; the `H_gov` declaration | Finance with CEO | **BLK-D in full**; **[S-E: Rule E-168]** | **YES** |

## VIII.2 What P0 does not require

**[A]** Stated explicitly, because the most likely failure of a readiness gate is scope creep:

| Not required for P0 | Source |
|---|---|
| **Any software, platform, app, dashboard or AI feature** | **[S-A: §23.1]**; **[S-B: §40]** no technology |
| **A mark, palette, logo or visual identity** | **N-E-02** blocked by A-N12; **[S-E: Rule E-65]** permits word-only identification |
| **Any national branding, domain, account portfolio or campaign** | **[S-E: Rule E-60, GATE E7]**; **[S-A: §23.1]** |
| **A second team, a City layer or a State layer** | **[S-A: A-L7]**; **[S-ST: §2.3]** |
| **A resolved CEO-versus-Council question** | **LDR-U01** — the interim reserved-matter procedure **[S-D: Rule D-113]** suffices for a one-team pilot |
| **A resolved brand or IP ownership question** | **A-N12, A-N13** — important before scaling; **BR-9 interim recorded permission suffices for one team's local use. But see Rule F-13** |
| **A named founder successor** | **LDR-U19** — no instrument may name one; the Interim Authority Order suffices once adopted |
| **Numeric values for `m_lead`, `σ_max`, `K_min`, `c`, weights or thresholds** | **A-L1**; the pilot exists to produce them |
| **A leaderboard** | **LDR-U11** unresolved; **[S-C: H-08]** six instruments suffice |
| **Composition monitoring** | **A-N5** `UNRESOLVED — deliberately`; the pilot should collect none |
| **An independent external review** | **[S-A: A-L6]**; **[S-E: Rule E-189]** forbids promising one without a mechanism |

## VIII.3 The verdict P0 is designed to prevent

**[A]** The gate exists because of a specific and foreseeable error:

```
DOCUMENTS COMPLETE
   -> "the architecture is comprehensive"
   -> "therefore we are ready"
   -> PILOT AUTHORISED
   -> first payment cannot lawfully be made       (LDR-U08)
   -> first public statement has no approved policy ([S: Ch.31])
   -> first incident has no insurance answer      (A-N10)
   -> first child activity has no certified safeguarding (A-B6)
   -> first data collection has no retention rule  (A-N26)
   -> PILOT HALTS, and the halt is attributed to "implementation problems"
      rather than to nine decisions that were never made
```

**[P] Rule F-15 (A Halted Pilot Is A Governance Failure, Not An Operational One).** Where a pilot halts because a P0 sub-gate was not satisfied, the finding is recorded against the authorisation, not against the team. **[A]** This mirrors **[S-D: L-20]** — a failed continuity test is a governance finding, not a person finding — and it matters because the alternative is that the team absorbs the blame for a decision nobody made.

---

# PART IX — PILOT EVIDENCE REGISTER

## IX.1 Method and the four families

**[P]** Sixty measurements, merged from four instruments, **without duplicating equivalents and with every source ID preserved.**

| Family | Source IDs | Count | Domain |
|---|---|---|---|
| **Economic** | **P-01 … P-15** **[S-B: §40]** — *cited downstream as `B-P-nn` per PD-2* | **15** | Cost, revenue, burden, solvency, shock |
| **Human** | **HM-1 … HM-15** **[S-C: §58]** | **15** | Journey, belonging, dignity, return |
| **Leadership** | **LM-1 … LM-15** **[S-D: Part 44]** | **15** | Succession, continuity, decisions, load |
| **Identity & communication** | **CI-1 … CI-15** **[S-E: Part 73]** | **15** | Perception, claims, corrections, language |
| **TOTAL** | | **60** | |

**[P] Rule F-16 (PD-1 Correction Applied).** **[S-D]** and **[S-E]** cite the economic family as `B-P-01…B-P-14`. **The source defines fifteen: P-01…P-15. P-15 — "`C_city` actual: what the City layer cost to run for one team" — is restored to the register here and is not omitted from the pilot plan.**

**[P] Rule F-17 (Thresholds).** Where the source specifies a threshold, it is reproduced. **Where it does not, the entry reads `THRESHOLD REQUIRES FINAL APPROVAL` and no number is supplied.** Where the source explicitly refused to set one — density, span, `n_min`, weights, `m_lead` — the refusal is preserved.

**[P] Rule F-18 (Non-Duplication Verified).** The four families were checked item by item by their source instruments: **[S-D: Part 44]** verified LM against HM; **[S-E: §73.1]** verified CI against both. **No measurement appears in two families.** The three places where they interlock are recorded rather than merged: **HM-9 ↔ LM-14** (return versus pipeline), **HM-13 ↔ CI-14** (dignity felt versus dignity in the artefact), **P-01 ↔ LM-12** (`H_gov` economic versus leadership load).

## IX.2 Economic measurements — P-01 … P-15 **[S-B: §40]**

| ID | What it measures | Why it matters | Method | Frequency | Min evidence | Records → verifies | Failure | Informs | Pilot-testable? |
|---|---|---|---|---|---|---|---|---|---|
| **P-01** | **`H_gov` per month, by role and by GC line** — the time-and-motion study | `σ_max` is the only bound on control effort and is unmeasured | Direct hour recording per role per governance line | Monthly | A ledger of hours by role and line | Team → Audit | `H_gov > σ_max` sustained | B-20, B-25; **[S-D: LM-12]**; **[S-E: Rule E-168]** | **YES** |
| **P-02** | `h_proj`, `h_qa`, `h_rev` actual vs estimated, per project | Estimation error drives pricing and the wage-protection buffer | Per-project hour records against estimates | Per project | Dated hour records with the estimate held beforehand | Team → verifier other than the performer | Systematic under-estimation | B-06, B-13; venture pricing | **YES** |
| **P-03** | `P_price`, `C_var`, `CM̄_j`, `CM̄_j / h_proj` for the venture category | Whether any venture category actually contributes margin | Per-category price, variable cost and contribution | Per period | Invoices, cost records, contribution computation | Finance → Audit | Negative contribution after `H_gov` allocation | B-14 two-track strategy | **YES** |
| **P-04** | `r_lead`, `r_prop`, `r_close`, `h_acq`, `CAC` (mostly hours) | Acquisition cost in hours determines whether growth is affordable | Per-opportunity record from lead to close | Per opportunity | A dated opportunity record | Business → Finance | Acquisition hours exceed contribution | B-07 contribution-gated growth | **YES** |
| **P-05** | `r_collect`, `Δt_collect`, ageing | Revenue recognised but not collected is not revenue | Collection record with dates and ageing | Monthly | Dated collection records | Finance → Audit | Ageing beyond terms with no action | B-13 collection terms | **YES** |
| **P-06** | `N_ver`, `N_act`, `r_act`, `r_ret`, exits by reason, `T_tenure` | Verification throughput and retention determine capacity | Member and task records | Monthly | Verification and activity records with exit themes only | HR → Audit | Verification is the binding constraint | B-08, B-23; **[S-C: HM-4]** | **YES** |
| **P-07** | `C_L1` actual — the true monthly cost of existing | The floor beneath which the unit cannot operate | All costs, including unpaid hours valued | Monthly | A complete cost record | Finance → Audit | Unknown, because unpaid hours are not valued | B-26 hybrid funding map | **YES** |
| **P-08** | `C_vol_total` per onboarded member, by component | A volunteer is not free | Supervision, verification, training and administration hours per onboarded member | Per onboard | Component-wise hour record | HR → Finance | Onboarding cost exceeds contribution | B-08 volunteer true-cost | **YES** |
| **P-09** | `H_svc` actual vs budget; service outcomes verified | Service is unfunded and therefore invisible without this | Hour records plus verified outcome records | Monthly | Outcome records with follow-up state | Team → verifier | Service displaces paid work, or paid work displaces service | B-01, B-02; **[S-E: Rule E-185]** | **YES** |
| **P-10** | Solvency line reached per period and scenario position | The pilot must know which scenario it is in | Period position against the four break-evens | Per period | A dated position statement | Finance → Audit | Below the solvency line with no action | B-03, B-15; the funding requirement | **YES** |
| **P-11** | `E_shock` — every HC-* event that occurred, with its cost in hours and rupees | Shock absorption is the difference between a hard month and an ending | Event record with cost | Per event | A dated event record with cost | Team → Finance | A shock with no recorded cost | B-04 float, B-11 idle capacity | **YES** |
| **P-12** | Escalation latency for each City/State request made | Layered support is a promise with a time attached | Request and response timestamps | Per request | Dated request and response | Team → City | Latency makes escalation useless | B-16 layered support | **PARTIAL — requires a City to exist** |
| **P-13** | Member payment continuity — paid in how many periods out of how many | **Priority 1 is non-suspendable** | Payment sheets against periods | Per period | Completed payment sheets with formula version | Finance → Audit | **Any period unpaid is a critical failure** | **[S-D: INV-2]**; B-05 | **YES** |
| **P-14** | Beneficiary and customer feedback, and any complaint via the independent route | The only external check on service quality | Independent collection, at least a day after help, by someone other than the deliverer | Per period | Feedback records; complaint records | Independent collector → Audit | No complaints recorded at all — **a zero count is a warning sign** | **[S-C: HM-13]**; B-24 | **YES** |
| **P-15** | **`C_city` actual — what the City layer cost to run for one team** *(restored per PD-1)* | The City divisor determines whether a State layer is arithmetically possible | City cost attributed to one team | Per period | A City cost record | City → Finance | Unmeasured, so the divisor is guessed | **LDR-U14, LDR-U15; B-21; [S-D: Rule D-91]; [S-E: Rule E-138]** | **PARTIAL — requires a City; at one team it yields a single-point observation only** |

## IX.3 Human measurements — HM-1 … HM-15 **[S-C: §58]**

| ID | What it measures | Why it matters | Method | Frequency | Records → verifies | Failure | Informs | Pilot-testable? |
|---|---|---|---|---|---|---|---|---|
| **HM-1** | **Inbound contacts** — needs reported, questions asked, people who approached | The only honest awareness proxy | Count from the public intake record | Monthly | Team → City | Zero with no explanation | Discovery; **[S-E: CI-11]** | **YES** |
| **HM-2** | **Comprehension** — can a person restate what this is and what they could do? | Stage 2 of the journey | Short structured conversation by someone **outside** the team, in the person's language | Per cohort | City → National (aggregate) | Cannot restate | **[S-E: CI-2]** complements it | **YES** |
| **HM-3** | **Belonging** — can they name two people here? | The second clause of the emotional proposition | One conversational question; **names of others are not recorded, only the count** | Per cohort | Team → City (aggregate) | Cannot name two | H-12 friendship infrastructure | **YES** |
| **HM-4** | **First-participation completion** | Tests whether the first action is achievable | Task records | Monthly | Team → City | Started but not finished | H-05, H-06 | **YES** |
| **HM-5** | **Contribution completion** — one defined contribution done | Stage 4 of the journey | Task record with outcome | Monthly | Team → City | Counts inflated by splitting tasks — **[S: Ch.25]** prohibits artificial splitting | H-06; **[S-E: FW-1]** | **YES** |
| **HM-6** | **Can they say what they did?** | The subjective half of attribution | One question, in their language | Per cohort | City (aggregate) | A confident answer masking a trivial task — pair with HM-5 | Usefulness | **YES** |
| **HM-7** | **Attribution received** — was the outcome returned inside the stated window? | **The most damaging break in the loop** | From the H-15 record | Per contribution | Team → City | Window missed | H-15; **[S-E: Part 5 stage 4]** | **YES** |
| **HM-8** | **Follow-up outcome known** — resolved / reduced / unchanged / worsened / unknown | The mission-balance data **[S-B: B-01]** and **[S-ST: M14]** require | Follow-up record **[S: Ch.15 step 10]** | Per case | Team → City → State (aggregate) | "Unknown" dominates | **[S-E: TS-2, Rule E-131]** | **YES** |
| **HM-9** | **Voluntary return** — second contribution within the defined window | **The primary measure**, chosen over conversion by **[S-ST: §21.3]** | Two dated contribution records | Rolling | Team → City | Low return with no diagnostic | H-06; **[S-E: Part 5 stage 7]** | **YES — window `PROPOSED`** |
| **HM-10** | **Development taken up voluntarily** | The anti-gate test | Training and delegation records | Quarterly | Team → City | **Compulsory uptake is not development** | H-11; **[S-D: SP-series]** | **YES** |
| **HM-11** | **Understanding of the service/business distinction** | **[S-C: PM-4]**; **[S-B: B-09 rule 7]** | Ask them to classify their own activities | Per cohort | City (aggregate) | Correct answers given after being told the answer measure nothing | B-09; **[S-E: MC-6]** | **YES** |
| **HM-12** | **Understanding that leaving is allowed** | HV-1 | Ask; **and observe whether anyone actually paused, reduced or left without adverse consequence** | Per cohort; quarterly | City → National (aggregate; exit themes only) | Nobody has ever left, and nobody knows they may | H-17, H-18 | **YES** |
| **HM-13** | **Dignity and respect** — reported by participants **and** beneficiaries, separately | **HV-2 veto gate** | Independent collection at least a day after help, by someone other than the deliverer | Per period | Independent collector → Audit | Low dignity with high activity | A-19; **[S-E: E-34]** | **YES — the only measurement requiring restricted handling** |
| **HM-14** | **Promises made vs promises kept** | The trust ladder | From the intake record: what was promised, what was done, when | Monthly | Team → City | Small promises kept easily inflates this — **measure the promise size** | B-10; **[S-E: Rule E-5]** | **YES** |
| **HM-15** | **Where friction stopped them** — the last stage reached | The diagnostic that says what to fix | From the journey record: stage reached, stage abandoned | Per cohort | Team → City | No reason recorded about a person | H-07; the funnel design | **YES** |

## IX.4 Leadership measurements — LM-1 … LM-15 **[S-D: Part 44]**

| ID | What it measures | Why it matters | Method | Records → verifies | Failure | Pilot-testable? |
|---|---|---|---|---|---|---|
| **LM-1** | **Succession coverage** | SS-0 is a reported organisational risk | SS-state register against mandatory role classes | Team → City | Any mandatory role at SS-0 | **YES** |
| **LM-2** | **Continuity exercise rate** | **Unexercised counts as absent (Rule D-122)** | CT-A/CT-B exercise records | City → Audit | Zero exercises | **YES** |
| **LM-3** | **Decision-record completeness** | A decision with no reason cannot be appealed or learned from | M1 register sampling | Audit | Reason-free decisions | **YES** |
| **LM-4** | **Time-to-fill a vacancy** | The 13-step lifecycle has a duration | Vacancy records | HR → Audit | `THRESHOLD REQUIRES FINAL APPROVAL` | **PARTIAL — needs a vacancy** |
| **LM-5** | **Interim duration** | All temporary instruments expire | TL instrument start and end | HR → Audit | An expiry passed without renewal or ending | **PARTIAL** |
| **LM-6** | **Leadership load distribution** | Overload is felt before it is reported | LLI bands from the workload ledger | City → Audit | L2/L3 bands with no action | **YES** |
| **LM-7** | **Dependency exposure** | A DEP-L role is a single point of failure | LDI inputs I-1…I-7 | City → Audit | DEP-L on a mandatory role | **YES** |
| **LM-8** | **Opportunity-allocation pattern** | Favouritism operates through opportunity, not decision | Aggregate distribution with small-cell suppression | Audit | — | **NO — `NOT TESTABLE AT PILOT SCALE`; needs multiple cohorts** |
| **LM-9** | **Complaint and appeal volume, by channel and outcome** | The route must be used to be real | Complaint and appeal records | Audit | **Zero is a warning sign** | **YES** |
| **LM-10** | **Appeal outcome rate** | Whether appeals can succeed | Appeal outcomes | Audit | — | **NO — `NOT TESTABLE AT PILOT SCALE`; needs appeal volume** |
| **LM-11** | **Honest-reporting latency** | Interval from a failure occurring to it being recorded | Incident and lesson records against occurrence dates | Audit | Long latency | **YES** |
| **LM-12** | **Governance-hour load** | `H_gov` against `σ_max` | Workload ledger | City → Finance | Above `σ_max` | **YES — interlocks with P-01** |
| **LM-13** | **Leadership-cost ratio** | `C_lead` against the unit's cost base | Finance records | Finance → Audit | Uncomputable while `m_lead` is unresolved | **PARTIAL — yields a deficit observation, not a ratio** |
| **LM-14** | **Pipeline throughput** | Leader supply is a stock problem | Development, delegation and readiness records | City → Audit | **No target may be set (Rule D-37, D-88)** | **PARTIAL — one team produces no pipeline** |
| **LM-15** | **Institutional independence counts** | The four annual tests: absence, attribution, dissent, successor | Test records with counts | Audit → Council | **Any zero count is a warning sign** | **PARTIAL — T1 and T3 need a period; T2 and T4 are observable** |

## IX.5 Identity and communication measurements — CI-1 … CI-15 **[S-E: Part 73]**

| ID | What it measures | Why it matters | Method | Records → verifies | Failure | Pilot-testable? |
|---|---|---|---|---|---|---|
| **CI-1** | **Misclassification rate** | Eleven categories, four rated Severe | Independent respondents mapped to MC-1…MC-11 | City (aggregate) | Concentration in MC-1/2/3/11 | **PARTIAL — one locality, one impression** |
| **CI-2** | **First-contact comprehension** | The current architecture fails 4 of 5 | Ten seconds with one artefact; the eight questions | City (aggregate) | Below the floor | **YES** |
| **CI-3** | **Perceived political association** | MC-1 Severe; N9 makes a false association a correction duty | Independent respondents, aggregate | National (aggregate) | Any non-zero is investigated | **NO — needs ≥3 localities, ≥30 respondents** |
| **CI-4** | **Perceived religious or caste association** | MC-2 Severe | As CI-3 | National (aggregate) | Any non-zero triggers a pattern review | **NO** |
| **CI-5** | **Perceived security or vigilante character** | MC-3 Severe | As CI-3 | National + Safety | Any non-zero triggers a visual and vocabulary audit | **NO** |
| **CI-6** | **Language match** | Language is a hard exclusion, not a friction | First-contact language vs material language | Team | Any mismatch in the mandatory set | **YES** |
| **CI-7** | **Terminology consistency** | Divergent meanings make the security boundary unenforceable | Sample artefacts against the register | National Comms | Below 100% | **PARTIAL — one language at pilot** |
| **CI-8** | **Public-claim traceability rate** | Every claim must be traceable to an inspectable record | Claim register audit | Audit | **Must be 100%** | **YES** |
| **CI-9** | **Correction performance** | The correction log is the load-bearing trust instrument | Count and discovery-to-publication interval; **and whether the log was empty** | Audit + Comms | **Zero across a period is published as an anomaly** | **YES** |
| **CI-10** | **Refusal-log operation** | Publishing refusals beats declaring neutrality | Count approaches received and declined | National + Legal | **Zero where approaches occur is a warning sign** | **NO — needs an election cycle or a full year** |
| **CI-11** | **Verification-channel use** | The anti-impersonation defence | Query count, response rate and interval | City | — | **YES** |
| **CI-12** | **Publication completeness** | The whole trust architecture is these publications | TS and PLR items present, current, dated | Audit | Below 100% of the stage-required subset | **YES** |
| **CI-13** | **Spokesperson distribution** | One voice is one point of failure | Distinct authorised spokespersons who actually spoke | National Comms | **A count of one is a finding** | **NO — one locality has one voice** |
| **CI-14** | **Attribution and consent compliance** | Saviour grammar enters through syntax | Subject-of-sentence check; consent completeness | Editor + Audit | **Must be 100%** | **YES** |
| **CI-15** | **Unaffiliated repeat use** | The measurement of participation without membership | Distinct people using a public channel more than once without joining | Team + City | **Non-zero is the primary evidence the central proposition works** | **YES** |

## IX.6 Testability summary across all 60

| Category | Count | Items |
|---|---|---|
| **Fully testable by one team on paper** | **47** | P-01…P-11, P-13, P-14; HM-1…HM-15; LM-1, LM-2, LM-3, LM-6, LM-7, LM-9, LM-11, LM-12; CI-2, CI-6, CI-8, CI-9, CI-11, CI-12, CI-14, CI-15 |
| **Partially testable** | **8** | P-12, P-15; LM-4, LM-5, LM-13, LM-14, LM-15; CI-1, CI-7 |
| **`NOT TESTABLE AT PILOT SCALE`** | **7** | **LM-8, LM-10, CI-3, CI-4, CI-5, CI-10, CI-13** |

**[P] Rule F-19 (Thirteen Not Seven).** **[S-D]** recorded two not-testable items and **[S-E]** recorded five; **P-12 and P-15 additionally require a City layer to exist**, and **[S-D: L-06]** cohort normalisation is not a measurement but is structurally untestable. **The honest count of items the pilot cannot validly produce is therefore seven measurements plus one structural instrument, and the partial set of eight must be reported with its limitation attached rather than as a result.**

---

# PART X — PILOT VS POST-PILOT

## X.1 The five categories

**[P]** A strict separation, because the most likely post-pilot failure is that a narrow success is reported as a general one — **[S-D: Rule D-132]** and **[S-E: Rule E-223]** both exist to prevent exactly that.

### X.2 MUST BE PROVEN IN PILOT

| # | Item | Measurement | Why it cannot wait |
|---|---|---|---|
| 1 | **Priority-1 worker compensation was paid, on time, in every period** | P-13 | Non-suspendable **[S-D: INV-2]**; the whole economic premise |
| 2 | **`H_gov` is measurable and has an observed value** | P-01, LM-12 | `σ_max` cannot be set without it |
| 3 | **Service outcomes were verified and followed up** | P-09, HM-8 | Without follow-up there is no impact claim |
| 4 | **A person participated without joining, and returned** | HM-4, HM-5, HM-9, CI-15 | The architecture's central proposition |
| 5 | **Dignity was reported acceptable by beneficiaries, independently** | HM-13 | A veto gate **[S-C: HV-2]** |
| 6 | **Promises made were kept, or the failure was reported** | HM-14 | The trust ladder |
| 7 | **A correction was issued and published, without approval** | CI-9 | **[S-E: ES.5]** — the whole reputation architecture |
| 8 | **A refusal was logged using the script in the local language** | CI-10 (partial) | Neutrality is published, not declared |
| 9 | **Every published claim was traceable to a record** | CI-8 | The differentiation |
| 10 | **A first win satisfied FW-1…FW-6 including the scripted "nothing further is expected"** | PS-E4 | Otherwise the first win is a funnel stage |
| 11 | **The public local record existed, was ungated, and was kept current** | PS-E1, CI-12 | **[S-C: H-03]** — the missing artefact |
| 12 | **A complaint reached outside the locality** | LM-9 | **MVLS-9**; the only alternative to exit |
| 13 | **A decision was recorded with its reason** | LM-3 | M1; appealability |
| 14 | **Every covered role had a recorded SS state** | LM-1 | L-08 |
| 15 | **A playbook was exercised by a non-holder** | LM-2 (CT-B) | Otherwise the playbook is a document |
| 16 | **The human accessibility route completed a process for a non-reader** | AX-T1 | A hard exclusion, not a friction |
| 17 | **The language of first contact matched the language of the material** | CI-6 | Rule E-66 mandatory set |
| 18 | **No beneficiary image, name or circumstance was published** | CI-14 | Irreversible if breached |
| 19 | **Nobody was recruited at a moment of vulnerability** | PF-E3 | The foundational prohibition |
| 20 | **Communication hours were recorded and did not exceed service and verification hours** | P-01 with communication lines | **[S-E: Rule E-169]** |

### X.3 SHOULD BE TESTED IN PILOT

| # | Item | Measurement | Note |
|---|---|---|---|
| 1 | Venture category contribution margin | P-03 | Depends on a customer existing |
| 2 | Acquisition cost in hours | P-04 | Depends on opportunities arising |
| 3 | Collection terms and ageing | P-05 | Depends on credit being extended |
| 4 | Volunteer true cost | P-08 | Depends on onboarding occurring |
| 5 | Shock events and their cost | P-11 | Event-driven; a period with none is not a pass |
| 6 | Escalation latency | P-12 | Requires a City; yields a single-point observation |
| 7 | `C_city` actual | **P-15 (restored per PD-1)** | Requires a City; **must not be omitted from the plan** |
| 8 | Belonging — can they name two people | HM-3 | Depends on cohort size |
| 9 | Development taken up voluntarily | HM-10 | Depends on development being offered |
| 10 | Understanding that leaving is allowed | HM-12 | Requires someone actually to leave, or to be asked |
| 11 | Load and dependency bands | LM-6, LM-7 | Requires enough roles to distribute |
| 12 | Honest-reporting latency | LM-11 | Requires a failure to occur |
| 13 | Misclassification rate | CI-1 | One locality yields one impression |
| 14 | Terminology consistency | CI-7 | One language at pilot |
| 15 | Verification-channel use | CI-11 | Requires the channel to be known |
| 16 | Whether the category sentence works | CI-2, N-E-21 | **Adoption should follow measurement, not precede it** |
| 17 | Anti-gaming controls under real incentive pressure | L-18 | Requires real incentives |
| 18 | Mission balance | **[S-ST: §17.3; M14]** | Requires both service and commercial activity |

### X.4 CANNOT BE VALIDLY PROVEN AT PILOT SCALE

| # | Item | Source of the limit | Minimum condition |
|---|---|---|---|
| 1 | **Cohort normalisation** | **[S-D: L-06; Part 41 §41.2]** — a cohort of one is not a cohort | Multiple comparable units |
| 2 | **Out-of-team assessment independence** | **[S-D: ES.5]** — at Stage 0–1 there is no outside | **A second team, or a City with an assessor from another team** |
| 3 | **Succession exercised** | **[S-D: L-08, LM-1]** — a state can be recorded; a transition cannot occur without a vacancy and a successor | A real transition |
| 4 | **Promotion without hollowing out the winning team** | **[S-D: L-09, LM-14]** | A real promotion |
| 5 | **Appeal outcome rate** | **LM-10 `NOT TESTABLE`** | Appeal volume |
| 6 | **Opportunity-allocation fairness** | **LM-8 `NOT TESTABLE`** | Multiple cohorts |
| 7 | **Perceived political, religious, caste and security association** | **CI-3, CI-4, CI-5 `NOT TESTABLE`** | ≥3 localities, ≥30 respondents, suppression-safe |
| 8 | **Spokesperson distribution** | **CI-13 `NOT TESTABLE`** — one locality has one voice | ≥3 localities or a City layer |
| 9 | **Refusal-log annual count** | **CI-10 `NOT TESTABLE`** | An election cycle or a full year |
| 10 | **Economic sustainability** | **[S-B]** — `m_lead`, `σ_max`, `K_min`, `c` and the divisor all need a range | Multiple units across a range of `K` |
| 11 | **Governance burden at scale** | **[S-D: Part 40 §40.5]** — the pilot runs with no technology, so automation's effect on burden is unobservable | Technology plus scale |
| 12 | **Contribution portability** | **[S-E: E-41 Stage 3; PO-4]** | ≥2 localities, plus third-party acceptance |
| 13 | **The four annual institutional tests** | **[S-A: A-16]**; **LM-15** | A full year, and a real absence event |
| 14 | **Leadership cost ratio** | **LM-13** — uncomputable while `m_lead` is unresolved | `m_lead` decided plus a cost base |

### X.5 MUST WAIT FOR MULTI-CITY EVIDENCE

| # | Item | Source |
|---|---|---|
| 1 | The City divisor `H_gov_per_team(K)` shape | **LDR-U14**; **[S-D: Rule D-91]**; **P-15** |
| 2 | `K_min` — the viability threshold for a City layer | **LDR-U15**; **[S-B: B-21]** |
| 3 | City shared services in operation | **[S-B: B-21]**; **[S-D: Rule D-103]** |
| 4 | Replication — a model reproduced by people who were not its authors | **[S-E: GATE E4, RT-1…RT-5]** |
| 5 | Cross-locality verification of a contribution record | **[S-E: PO-4]** |
| 6 | Multi-locality claim class CL-3 | **[S-E: Part 31]**; **[S-ST: §30.3 item 10]** — three materially different contexts |
| 7 | Independent verification of an impact claim by an external party | **[S-ST: §14.3 item 8]** |
| 8 | Per-environment-type divisor measurement | **[S-E: Rule E-138]** |

### X.6 MUST WAIT FOR NATIONAL-SCALE EVIDENCE

| # | Item | Source |
|---|---|---|
| 1 | National identity at NI-4 and above | **[S-E: Part 59]** |
| 2 | Language equity across a state | **[S-ST: §30.3 item 13]** |
| 3 | Mass adoption at any level above MA-3 | **[S-E: Part 60]** |
| 4 | Reputation at RC-2 aligned across localities | **[S-E: Part 21]** |
| 5 | Political, religious and caste neutrality under real external pressure | **[S-E: AD-03, AD-04, AD-06; NRT-01…NRT-03]** |
| 6 | Business-network scaling | **[S-B: B-14]**; venture portfolio across markets |
| 7 | Governance scalability — whether obligation grows sub-linearly | **[S-B: §26]**; **[S-D: MAT-series]** |
| 8 | Communication burden at CL-3 and above | **[S-E: §42.5, Rule E-169]** |
| 9 | Social inclusion across structural variance | **[S-E: Part 34]** — eleven environment types |
| 10 | All ten **[S-ST: §14.3]** and all fifteen **[S-ST: §30.3]** national-trust and expansion pre-conditions | **[S-E: GATE E7]** |
| 11 | Brand and IP ownership at national scale | **A-N12, A-N13**; **[S-E: Rule E-60]** |

## X.7 The asymmetry

**[A]** The separation produces one finding worth stating plainly: **the pilot can prove almost everything about honesty and almost nothing about scale.** Of the twenty MUST-PROVE items, eighteen concern whether the organisation did what it said and recorded what it did. Of the fourteen CANNOT-PROVE items, thirteen concern whether it works somewhere else, for more people, under pressure.

**[P] Rule F-20 (The Pilot Is An Honesty Test, Not A Scale Test).** The pilot's evidential product is **that the architecture can be operated honestly by real people in one place.** It is not evidence that the architecture scales, that India wants it, that the economics close, or that the leadership system selects well. **Any report that presents pilot results as evidence of the latter four is a claim above its evidence class and is withdrawn under [S-E: Rule E-182].**

---

# PART XI — REALITY IMPLEMENTATION REGISTER

## XI.1 Method

**[P]** Every required capability is translated: **ARCHITECTURAL RULE → OPERATIONAL MECHANISM → HUMAN OWNER → TECHNOLOGY SUPPORT → RECORD / EVIDENCE → AUDIT METHOD.** **[A]** No implementation is claimed to exist unless the corpus establishes it. **The Technology column is almost entirely "none required" — which is the finding, not an omission.**

## XI.2 The register

| Capability | Architectural rule | **Operational mechanism** | **Human owner (role)** | Technology | Record / evidence | Audit method |
|---|---|---|---|---|---|---|
| **HR verification** | **[S: Ch.12]** gates for responsibility-bearing roles; immutable item 4 | A documented check sequence performed by a person, with a written outcome | HR & Verification | None required — paper checklist | Verification record with date, checker and outcome | Sample re-performance against source documents |
| **Membership records** | **[S: Ch.12]** HR record; **[S-A: A-17]** C3 classification | A register with one row per member and classified fields | HR & Verification | None required | Member register; classification per field | Field-level classification audit; **A-N32 prohibited-collection list** |
| **Vacancy handling** | **[S: Ch.10/11]** 13-step lifecycle, six statuses | A vacancy sheet per role with status, dates and reapplication | Team Leader with HR | None required | Vacancy record; **LM-4** time-to-fill | Lifecycle-step completeness check |
| **Financial records** | **[S: Ch.18]** waterfall, four segregated hands | Four separate functions held by four people; a ledger; a payment sheet with its formula version | Finance (four hands) | None required | Ledger; payment sheet; reconciliation | Segregation test; random reconciliation **[S: App. A §18.3]** |
| **Venture accounting** | **[S: Ch.17]**; **B-14, B-25** | Per-venture record with price, variable cost, contribution, QA outcome | AI/Business Manager with Finance | None required | Venture record; **P-03** | Contribution recomputation; QA record cross-check |
| **Safety incident reporting** | **A-09**; **[S-A: A-06 V42–V43]** | An incident sheet with mandatory fields **including whether any member wore organisational identification** | Safety Lead | None required | Incident record; **LM-11** latency | Field completeness; **V42–V43 visibility fields present** |
| **Leadership assessment** | **[S-D: L-01]** Gate E / Gate R | A published criteria sheet; an evidence portfolio assembled by the candidate; an assessor | Appointing authority; **assessor must be out of team — absent at Stage 0–1** | None required | Assessment record with reasons; appealable | **Recorded reason reviewed by Audit; the out-of-team condition is currently unsatisfiable and must be recorded as a gap** |
| **Correction log** | **[S-E: TS-6, Rule E-88, Rule E-186]** | An append-only sheet; **any role-holder may enter; no approval required** | Anyone; Audit reviews | None required | Correction log with discovery and publication dates; **CI-9** | **Emptiness test: a period with zero entries is published as an anomaly and referred to Audit** |
| **Public communication** | **[S: Ch.24]**; **[S-E: E-39]** | A publication matrix by artefact class; a claim register; a terminology register | Communications with the Editor function | None required | Published artefacts; claim register entries; **CI-8** | Sample audit of every artefact against its claim class and label |
| **Audit** | **[S: Ch.27]**; **[S: Ch.23]** "review only; not operational commander" | A schedule; a sampling method; a findings register with a consequence route | Auditor | None required | Audit findings; **whether each produced a change** | Independence test: the Auditor holds no operational role |
| **Appeals** | **[S-D: L-23]** | A route outside the decision line, with a recorded outcome | An appeal recipient outside the line | None required | Appeal record; **LM-9, LM-10** | **Pattern review: a 0% success rate across many appeals is a finding** |
| **Contribution records** | **[S-C: H-09]** | A narrative, non-ordinal record per contribution, held by the person | The contributor, countersigned by the verifier | None required | Contribution record; **HM-5, HM-6** | Ordinal-element test: any score, rank or band is a breach |
| **Role permissions** | **[S: Ch.23]** RBAC; **[S-D: L-17]** | A permission sheet per role with delegation start and end dates | Technology admin **on paper: the Team Leader with HR** | None required at pilot | Permission record; delegation expiry | Expiry test: any delegation past its end date is a finding |
| **Training** | **[S: Ch.12]** ten categories | A curriculum per category; an attendance and comprehension record | Training Lead | None required | Training record; comprehension check | **Internal training is not legally sufficient where the domain is regulated [V]** |
| **Probation** | **[S: Ch.11/12]** | A dated probation with a stated end and a recorded decision | Team Leader with HR | None required | Probation record | Decision-with-reason check |
| **Performance review** | **[S: Ch.24/25]**; **[S-D: L-13 RV-1…RV-4]** | Four review types, never merged, on the existing cadences | Reviewer independent of the reviewee's line | None required | Review record | **Merger test: any single review serving two purposes is a finding** |
| **Complaint intake** | **[S-D: MVLS-9]**; **[S-ST: M10]** | A route published locally that reaches outside the locality | Team intake plus an out-of-locality recipient | None required | Complaint log; **LM-9** | **Outward-reach test: does the route bypass the local line?** |
| **Refusal log** | **[S-A: A-04]**; **[S-E: TS-8]** | A register of approaches received and declined, with a published annual count | National Legal with the local role-holder | None required | Approach register; **CI-10** | **Zero-count test in a period where approaches occur** |
| **Decision record** | **[S-A: A-15 M1]**; **[S-D: LM-3]** | One line per decision: what, why, who, when, what would change it | The decider | None required | Decision register; **LM-3** | Sampling for reason completeness |
| **Standards versioning** | **[S-A: A-15 M2, M3]** | A versioned library plus an open change-request route any member may use | National Operations | None required | Version history; change requests with reasons | **Whether any change request from a non-leader was accepted** |
| **Playbook** | **[S-D: L-16 PB-1…PB-10]** | A per-role document **tested by a non-holder** | The role-holder writes; the successor tests | None required | Playbook; **CT-B exercise record** | **Exercise test: an unexercised playbook counts as absent (Rule D-122)** |
| **Public local record** | **[S-E: PLR-1…PL-7]**; **[S-C: H-03]** | One posted sheet per locality with seven elements and nothing else | The team | None required — **the paper sheet is a complete implementation** | The posted sheet, dated; **CI-12, CI-15** | Presence, currency, and the unadorned test |
| **Consent** | **[S-E: E-34]**; **A-19** | Three separate consents — to receive help, to be recorded, to be published — each separately refus­able | The person taking the record | None required | Consent records | **Specificity test: a general consent covering publication is invalid** |
| **Breach response** | **A-17 P5**; **[X]** DPDP timelines | A rehearsed runbook with named roles and clocks | Privacy officer with Legal | None required at pilot | **A rehearsal record** | Rehearsal date within the interval; **statutory clocks [V]** |

## XI.3 The finding

**[A]** Twenty-four capabilities, and **twenty-four require no technology.** Every one is a sheet, a register, a named role and an audit method. **[S-B: §40]**'s no-technology pilot is therefore not a constraint imposed on the architecture; **it is a description of what the architecture actually requires at Stage 0–1.**

**[P] Rule F-21 (No Capability In This Register May Be Deferred To A Software Build.** Where a capability is listed as requiring no technology, a proposal to satisfy it with software is a proposal to defer it. **[S-B: §26.3]**'s automate-or-retire discipline applies in the reverse direction at Stage 0–1: **automate only what has been proven manually, and retire what has not been used.**

---

# PART XII — HUMAN WORKLOAD AUDIT

## XII.1 The rule about numbers

**[P]** The brief is explicit: estimate only where source data supports estimation; otherwise write **`WORKLOAD NOT YET QUANTIFIABLE`**. **No hours are invented in this Part.**

**[A]** The corpus supports exactly one numeric range, and it is a range for observation rather than a target: **[S-B: §25]** records `H_gov` at **8–40 hours per team per month**, which v1.3-B presents as the window within which the pilot measures. **Everything else is `NOT YET QUANTIFIABLE`.**

## XII.2 The recurring processes

| Process | Human actions per cycle | Approval steps | Verification steps | Documentation burden | Audit burden | Communication burden | Leadership burden | Financial admin | Safety reporting | Training | **Quantifiable?** |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **Intake and triage of a need** | Receive, record 3 fields, acknowledge with reference, assess against six need criteria, decide, respond or refer | 1 (decline above a threshold) | Outcome verification later | Intake record; decision record | Sample | The response itself | Only on escalation | None | Only if the need is safety-related | None | **NO — volume unknown** |
| **Verification of a member** | Identity, conduct, references, training prerequisite, role assignment | 1 | The verification *is* the verification step | Verification record | Sample re-performance | None | None | None | None | Category-specific | **NO** |
| **A project cycle** | Scope, assign, execute, QA, evidence, outcome, follow-up | Per authority tier | Verifier other than performer | Project record; evidence pack; follow-up record | Sample | PLR-3 entry | Only on failure | Cost and contribution records | Incident if any | None | **PARTIAL — P-02 measures `h_proj`, `h_qa`, `h_rev`** |
| **Payment cycle** | Verify work, compute, approve, pay, record, publish formula version | **Segregation requires 4 distinct hands [S: Ch.18]** | Work verification | Payment sheet; ledger; reconciliation | Random reconciliation **[S: App. A §18.3]** | None | None | **The dominant financial-admin burden** | None | None | **NO — depends on headcount** |
| **Governance and reporting** | Daily, weekly, monthly, quarterly, annual per **[S: Ch.24]** | Per cadence | — | Five cadence artefacts | Audit schedule | Public subset (TS, PLR) | Review participation | Included | Included | — | **PARTIAL — P-01 measures `H_gov` by role and line** |
| **Safety and incident** | Recognise, stop work if required, respond within boundary, record with **V42–V43 fields**, escalate, review | Safety + Legal for sensitive statements | Incident review | Incident record | Findings register | **CC-1 or CC-7 if material** | Direct | None | **Direct** | Emergency/first-aid category | **NO — event-driven** |
| **Leadership and succession** | Record SS state, maintain playbook, exercise delegation, assess readiness, review | Per **[S: App. E]** | Out-of-team assessment — **absent at Stage 0–1** | SS register; playbook; assessment record | **LM-1, LM-2, LM-3** | None | **The dominant leadership burden** | None | None | Development delivery | **PARTIAL — LM-12, LM-13** |
| **Communication and publication** | Refresh PLR monthly; publish quarterly boring-things; publish annual accountability; answer queries; issue corrections; maintain claim and terminology registers | **Corrections require none (Rule E-186)**; everything else per the matrix | Editor accuracy check | PLR; TS items; claim register; correction log; refusal log | **CI-8, CI-9, CI-12** | **The whole process** | Spokesperson duty | None | None | Communication category | **NO — and not costed in any prior instrument ([S-E: §42.5 EA-E1])** |
| **Complaint, appeal and improvement** | Receive, route outside the line, investigate, decide, record, respond, review pattern | Panel for serious matters | Independent of the line | Complaint and appeal records | **LM-9, LM-10**; pattern review | The response | Only on escalation | None | None | None | **NO** |
| **Training delivery** | Prepare, deliver, record attendance, check comprehension, certify where a standard exists | Training Lead | Trainer qualification | Curriculum; attendance; comprehension records | Sample | None | None | **Trainer time is paid work ([S-D: Rule D-47])** | Certified where regulated | **The process itself** | **NO — trainer supply is the binding constraint ([S-ST: Scenario B])** |
| **Partnership** | Identify, due-diligence, scope, approve, operate, exit | Approval by amount, risk, data and **brand impact** | — | Agreement with seven field sets | Brand-usage audit | Co-branded artefacts | Only on escalation | Financial terms | Safeguarding duties | None | **NO** |
| **Measurement itself** | **60 measurements, 47 fully testable, each requiring a recorder and a verifier** | — | Independent verification of a subset | **60 recording forms** | Audit of the records | — | — | — | — | — | **PARTIAL — and this is a workload the corpus does not cost anywhere** |

## XII.3 The processes most likely to exceed volunteer capacity

**[A]** Five, ranked by the strength of the corpus evidence:

| Rank | Process | Mechanism | Evidence | Control |
|---|---|---|---|---|
| **1** | **Governance and reporting** | `H_gov` is bounded only by an unmeasured `σ_max`; five cadences each produce artefacts; the source range is **8–40 h/team/month** — a **five-fold spread** | **[S-B: §25]**; **[S-D: LM-12]** | **MVC-1…MVC-11** minimum viable control set; automate-or-retire; **[S-D: Rule D-52]** |
| **2** | **Measurement** | **60 measurements is a workload in its own right and appears in no cost model.** Recording 47 by hand, monthly or per event, alongside delivery, is the single most underestimated burden in the corpus | **This Part; Part IX** | **[P] Rule F-22 below** |
| **3** | **Communication and publication** | PLR refresh, quarterly publication, annual accountability, query response, corrections, claim register, terminology register — **none costed anywhere** | **[S-E: §42.5 EA-E1, Rule E-168, E-169]** | **Rule E-169**: if communication hours exceed service and verification hours, retire instruments |
| **4** | **Payment and financial administration** | Four segregated hands for every cycle; reconciliation; published formula version | **[S: Ch.18]**; **[S-B: B-05, B-13]** | Risk-proportionate integrity controls **B-25** |
| **5** | **Safety and incident** | Event-driven, unbounded, and the one process that cannot be deferred or sampled | **A-09**; **[S-B: §23.2]** Safety must be ● early | Activation Gate; do-not-attend list; **V12–V17 public-space conduct limits reduce exposure directly** |

**[P] Rule F-22 (The Measurement Set Must Be Thinned Before The Pilot, Not During).** Sixty measurements across four instruments were designed by four documents that did not share a workload budget. **[A]** The pilot team must be given, before commencement, **an explicit statement of which of the 60 are recorded continuously, which per event, which per period, and which are deferred** — and the deferral of any MUST-PROVE item (Part X §X.2) requires a recorded reason under **[S-D: Rule D-110]**. **A pilot that attempts all 60 continuously will either fail to deliver service or fail to record honestly, and the second is worse.**

**[P] Rule F-23 (Unpaid Work Is A Recorded Deficit, Not A Solution).** Where a required process exceeds the team's paid capacity, the excess is **recorded as an organisational deficit** — **[S-D: Rule D-126]** for leadership work, **[S-B: B-08]** for volunteer true cost, **[S-E: §42.5]** for communication. **It may not be absorbed silently**, because a burden that is absorbed silently is a burden that will be reported as affordable.

---

# PART XIII — TECHNOLOGY DEPENDENCY AUDIT

## XIII.1 The four classes

**[P]** Brief §XIII. **The governing rule: software development may not become a substitute for an unresolved institutional decision.**

| Class | Definition | Items |
|---|---|---|
| **REQUIRED** | The pilot cannot be authorised without it | **None.** **[S-B: §40]** runs the pilot with no technology, and Part XI shows all 24 capabilities are paper-executable |
| **HELPFUL** | Improves accuracy, speed or reach without being necessary | A spreadsheet for the ledger; a phone line for the intake and verification channels; a messaging group for coordination **(but no decision may be made in it — [S-E: Rule E-154])**; a camera for dated result evidence **(subject to A-06 V24–V27 and A-19)**; a simple public page on an owned domain **(but the paper sheet remains the primary form — [S-E: Rule E-79])** |
| **OPTIONAL** | Valuable at scale, premature now | The 14-module platform; dashboards; the leaderboard; contribution-record portability infrastructure; automated RBAC and delegation expiry; AI translation as a drafting aid **(never publishing — [S-E: Rule E-68])** |
| **NOT REQUIRED** | Never required for the architecture to function | Any AI feature that decides anything **[S: Const. Art.12]**; a mobile app as a condition of any process **[S-E: AX-D]**; a national domain or account portfolio below CL-7 **[S-E: Rule E-60]**; any biometric or identity-verification system **[S-A: A-18]**; any sentiment-analysis or profiling capability **[S-A: A-18; S-E: Rule E-133]** |

## XIII.2 The seven attributes per dependency

**[P]** For the OPTIONAL class — the items most likely to be built prematurely:

| Dependency | Why needed | Minimum viable capability | Data involved | Access control | **Human fallback** | Failure mode | Auditability |
|---|---|---|---|---|---|---|---|
| **The 14-module platform** | Scale, not function | **None at pilot.** Build only what has been proven manually (Rule F-21) | All classes C1–C4 | **[S: Ch.23]** RBAC | **Complete — the pilot is the fallback** | Building it before the decisions are made encodes the unresolved ones | **[S: Ch.22]** audit events |
| **Dashboards** | Visibility at scale | Aggregate views of records that already exist | C2 aggregate; **no individual score [S-C: §23.2]** | RBAC | Paper reports at the five cadences | A dashboard becomes the target rather than the view (**[S-D: L-18 Goodhart]**) | Whether each panel maps to a record |
| **The leaderboard** | Comparative visibility | **None — LDR-U11 is unresolved** | Team and cohort performance | RBAC | The six recognition instruments **[S-C: H-08]** | A public comparative artefact that cannot be withdrawn from memory | **[S: App. E]** leaderboard finalisation authority |
| **Automated RBAC and delegation expiry** | Prevents stale authority | A date field and a review | `delegated_authority`, `delegation_start/end_date` **[S: Ch.22]** | Technology admin | **A paper permission sheet with dates and a manual expiry check** | Auto-expiry fires during a crisis and removes a needed authority | Expiry log |
| **Contribution portability infrastructure** | Cross-locality legibility | A record schema and a verification lookup | C3 with person-controlled disclosure | Person-initiated only | A signed paper record plus a telephone verification | A portable record becomes a score (**[S-E: Rule E-199, E-200]**) | Disclosure log |
| **AI translation** | Language scale | Drafting aid only | Text, not personal data | Comms | **A named human reviewer, mandatory for LA-1/LA-3-legal/LA-5 ([S-E: Rule E-68])** | A meaning, legal or safety error published without review | Version and reviewer record |
| **AI-assisted leadership or reputation functions** | Analysis at scale | **None below CL-3** | **Prohibited inputs: identity, belief, protected characteristics, historical bias as prediction labels ([S-D: Rule D-107, LV-16])** | AI & Data with Audit | **A human decision, always ([S: Const. Art.12])** | Rubber-stamping **[S-ST: F-29]** | **A-22 field set — cannot be retro-fitted ([S-A: A-I8])** |

## XIII.3 The finding

**[A]** The technology audit produces an unusual and important result: **there is no technology dependency on the critical path.** Every item on the master critical path (Part VII §VII.2) is a decision, a validation, a document, a person or a payment. **The pilot's technology requirement is nil, and the post-pilot technology requirement is entirely a function of what the pilot proves.**

**[P] Rule F-24 (Software Follows Evidence, Never Precedes It).** No software may be specified, procured or built for a process that has not been performed manually and recorded. **[A]** The reason is not cost. It is that **software encodes decisions** — a field implies a collection, a workflow implies an authority, a dashboard implies a target — and encoding an unresolved decision makes it invisible and expensive to reverse. **[S-A: A-I8]** makes the same point about AI audit fields: "fields cannot be retro-fitted onto past logs."

---

# PART XIV — FINANCIAL READINESS

## XIV.1 The rule about money

**[P]** No new percentage is created. No new rupee value is created. **Economic viability is not declared because the waterfall exists.** **[S: App. A §1.1]** records that the economic blueprint was never attached; **[S: Ch.18]** supplies the priority order and it is APPROVED architecture; **every magnitude is a variable, a formula, a `[SC]` branch or a structural statement.**

**[A]** The governing finding, restated from **[S-B]** and unchanged: **there is no revenue line for service, for governance, for training, or — as v1.3-E established — for communication.** The waterfall's priority order is therefore not a distribution of surplus; **it is a rationing rule for a shortfall.**

## XIV.2 The sixteen financial-readiness requirements

| # | Requirement | Source | Variable / status | Pre-pilot? |
|---|---|---|---|---|
| **1** | **Worker compensation** — priority 1, non-suspendable | **[S: Ch.18]**; **[S-D: INV-2]** | `C_wc`; **classification `UNRESOLVED` (LDR-U09)** | **YES — and unpayable until BLK-A-01…03** |
| **2** | **Statutory obligations** — priority 2 | **[S: Ch.18]** | `C_stat`; depends on classification and entity form | **YES** |
| **3** | **Direct business costs** — priority 3 | **[S: Ch.18]** | `C_var` | **YES** |
| **4** | **Founder compensation rules** — priority 4 | **[S: Ch.18]** | **`UNRESOLVED` (LDR-U16)**; the founder is the beneficiary, so **[S-D: Rule D-92]** recusal applies | **YES — decide whether it is nil for the pilot, and record it** |
| **5** | **Organisation service fee** — priority 5 | **[S: Ch.18]** | Rate not stated anywhere | **YES — as a recorded decision, not an invented number** |
| **6** | **Reserves** — priority 6 | **[S: Ch.18]**; **[S-B: B-03, B-15]** | Seeding order proposed; **custody `UNRESOLVED` (A-N15)** | **YES for the seeding order; custody before reserves become material** |
| **7** | **Wage-protection buffer** | **[S-B: §13]** | `M_to_buffer`, derived from `S̄_5` — **"very large when average surplus is small, and grows super-linearly"**; `S̄_5` unmeasured | **YES — and unsizable until measured** |
| **8** | **Social-impact contribution** — priority 7 | **[S: Ch.18, Ch.20]** | Formula `NOT FINAL`; **may not support political or religious activity**; **LDR-U18 37.5/17/12 are illustrative** | **NO — priority 7 is reached only if 1–6 are satisfied** |
| **9** | **Marketing / acquisition** | **[S-E: Rule E-25 emotion is never a budget line; Rule E-175 no growth campaign]** | **Zero by prohibition.** No paid media, no celebrity, no campaign, no referral incentive | **YES — as a prohibition, which costs nothing** |
| **10** | **Shared services** | **[S-B: B-21; §26.4]** | `C_city` — **P-15 measures it, and P-15 was dropped by PD-1** | **NO — requires a City** |
| **11** | **Volunteer true cost** | **[S-B: B-08]** | `C_vol_total` per onboarded member, by component | **YES — P-08** |
| **12** | **Governance burden** | **[S-B: §25]** | `H_gov` 8–40 h/team/month as an **observation window**; `σ_max` `UNKNOWN` | **YES — P-01** |
| **13** | **Runway** | **[S-B: §8.3, §10.2]** | Solvency line per period; four break-evens; **no survival period is asserted anywhere** | **YES — P-10** |
| **14** | **Float** | **[S-B: B-04]** | `M_to_buffer`; first-season float | **YES — BLK-D-04** |
| **15** | **Minimum viable control** | **[S-B: B-20 MVC-1…MVC-11]** | The control set that may not be deferred, and its cost | **YES** |
| **16** | **Anchored contracted revenue and local venture economics** | **[S-B: B-14, B-13]** | Two-track strategy; collection terms; `CAC` mostly in hours | **YES — P-03, P-04, P-05** |

**Plus three the corpus adds late and no cost model contains:**

| # | Requirement | Source | Note |
|---|---|---|---|
| **17** | **Communication** | **[S-E: §42.5 EA-E1, Rule E-168]** | **Not costed in v1.3-B.** Translation, publication, moderation, verification-channel response, crisis standby, media relations |
| **18** | **Leadership cost** | **[S-B: §24]**; **[S-D: L-37]** | `C_lead = C_wc_base × m_lead`, **`m_lead` `NOT FINAL`**; plus assessment, development and **paid trainer time ([S-D: Rule D-47])** and **paid mentorship ([S-D: L-12])** |
| **19** | **Professional fees for the eleven pre-pilot validations** | Part III; Part V BLK-B | **The most commonly omitted pre-pilot cost in the corpus** |

## XIV.3 The three findings

**[A]** Stated without softening:

**Finding 1 — The pilot cannot be funded from the architecture, because the architecture has no funding source.** **[S-B]**'s model is a *cost and viability* model, not a revenue model; the venture pillar is the only revenue line and it requires a customer, a margin and a collection cycle that do not exist at CL-0. **The pilot's funding is therefore an external act — capital, contribution, reserve or grant — and the corpus deliberately does not say which.** **`[V]` and `UNRESOLVED`: the hybrid funding map (B-26) is the instrument, and its content is not determined.**

**Finding 2 — Priority 1 is a legal obligation the organisation cannot currently discharge.** The waterfall puts worker compensation first and **[S-D: INV-2]** makes it non-suspendable. **But LDR-U08 (entity), LDR-U09 (classification) and A-N16 (bank mandate) are all unresolved, and A-B1 and A-B9 are BLOCKERS.** Until they close, **the architecture's first and most absolute financial obligation is one the organisation cannot lawfully perform.** This is the single hardest fact in this register.

**Finding 3 — Every number the pilot needs is a number the pilot must produce.** `m_lead`, `σ_max`, `K_min`, `c`, the City divisor, `S̄_5`, `P_max`, `C_L1`, `C_city`, `CAC`, the break-evens — **all are variables with formulas and no values.** **[S-A: A-L1]** states the principle: "the source deliberately does not invent numbers; pilot evidence should set them." **The correct reading is not that the economics are incomplete; it is that the economics are an instrument with no reading yet.** Declaring viability now would be declaring the reading before the measurement.

**[P] Rule F-25 (No Viability Claim Before P-10 And P-13 Have Values).** The organisation may not state or imply that it is economically viable, sustainable, self-funding or break-even until **P-10 (solvency position)** and **P-13 (payment continuity)** have produced values across a full period, and those values are published. **[S-E: CL-1]** permits only "we are testing this."

---

# PART XV — MASTER FAILURE REGISTER

## XV.1 Method and the five classes

**[P]** Failure conditions merged from A–E and classified. **The classification determines the response, and the response determines whether the pilot pauses or terminates.**

| Class | Meaning | Pilot must pause? | Pilot must terminate? | Expansion blocked? |
|---|---|---|---|---|
| **CATASTROPHIC** | Irreversible harm to a person, or destruction of the property that makes every other claim believable | **YES, immediately** | **YES if the mechanism is not closed** | **YES, until closed and re-evidenced** |
| **PILOT-BLOCKING** | The pilot cannot validly produce evidence while it persists | **YES** | Only if uncorrectable within the pilot | **YES** |
| **SERIOUS** | Material harm, detectable and correctable | Case-by-case, recorded | No | **YES until corrected** |
| **RECOVERABLE** | A failure that the architecture is designed to absorb | No | No | No |
| **INFORMATIONAL** | A signal that requires attention but no cessation | No | No | No |

## XV.2 The register

| ID | Failure | Source IDs | Class | Trigger | Early warning | Detection | Immediate response | Authority | Documentation | Escalation | Pause? | Terminate? | Expansion blocked? |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **MF-01** | **A minor is harmed, imaged or identified** | **A-B6; [S-C: SA-1…SA-7; S-E: Rule E-148]** | **CATASTROPHIC** | Any activity with a minor outside certified safeguarding | Any adult alone with a minor; any image draft containing a minor | CI-14; Editor rejection; safeguarding audit | Stop the activity; notify per protocol **[V]**; seal the record C4 | Safety + Legal + privacy officer | Incident record; sealed case | Immediate to National and to authorities where lawful | **YES** | **YES if certification was absent** | **YES** |
| **MF-02** | **An uninsured injury to a member or third party** | **A-B2; A-N10** | **CATASTROPHIC** | Any protection or first-response activity without written liability answers | Protection activity occurring while A-N10 is open | Activation Gate check | Stop; treat; record; notify | Safety + Legal | Incident record with V42–V43 fields | Immediate | **YES** | **YES** | **YES** |
| **MF-03** | **Priority-1 compensation unpaid in any period** | **P-13; [S-D: INV-2]; [S: Ch.18]** | **CATASTROPHIC** | Float exhausted; mandate failure; classification dispute | P-10 solvency position approaching the line | Payment sheets against periods | Pay from reserve or float per the seeding order; publish the failure | Finance + CEO | Ledger; published correction | Immediate to Council | **YES — service may continue, payment may not stop** | **YES if repeated** | **YES** |
| **MF-04** | **A fabricated impact, revenue, volunteer or beneficiary record** | **[S-E: Rule E-132; S: Ch.25 anti-gaming; S-D: GF-series]** | **CATASTROPHIC** | Any incentive to appear successful | A claim with no record; a total with no locality | CI-8 traceability audit; audit sampling | Withdraw the claim publicly; treat as serious misconduct **[S: SOP-18]** | Audit + Governance panel | Correction log; panel record | Immediate | **YES** | **YES** | **YES** |
| **MF-05** | **A data breach exposing C3 or C4** | **A-B7; A-N29; [X] DPDP** | **CATASTROPHIC** | Any exfiltration, loss or unauthorised access | Access-log anomaly; a missing device | Runbook trigger | Contain, notify the Board **without delay**, detailed report within **72 hours**, notify affected principals, **no materiality threshold**; CERT-In 6-hour reporting separately **[X][V]** | Privacy officer + Legal | Breach record; notification record | Immediate to National and regulator | **YES for the affected category** | Case-by-case | **YES** |
| **MF-06** | **A vigilante or unlawful intervention** | **A-06 V12–V23, V31–V41; A-08; [S-D: VG-series]** | **CATASTROPHIC** | Any patrol, pursuit, detention, command to a member of the public, or crowd entry | Any group movement in public; any assertion of authority | Incident record; V42–V43 visibility fields | Stop; refer to authorities; review; publish if material | Safety + Legal + National | Incident record; VG-5-class review | Immediate | **YES for protection activity** | **YES if the DO-NOT list was breached** | **YES** |
| **MF-07** | **Political, religious or caste capture** | **A-01 N1…N9; A-05; [S-D: PC-series; S-E: AD-03…AD-06]** | **CATASTROPHIC** | A faction placing members, controlling routing, or attaching resources | Approach register entries; routing, calendar or venue pattern; **CI-3/4/5** | Pattern review; refusal log; aggregate disparity testing | Recuse; refuse; log; correct publicly; **repair rather than message ([S-E: Rule E-35])** | CEO + Council + National Legal | Approach register; correction log | Immediate | Case-by-case | **YES if institutional** | **YES** |
| **MF-08** | **A public claim above its evidence class, not withdrawn on discovery** | **[S-E: Rule E-4, E-128, E-182]** | **PILOT-BLOCKING** | Attention, funding pressure or enthusiasm | CI-8 audit finding | Claim-ladder audit each period | Withdraw; publish the withdrawal; enter in the correction log | Communications + Audit | Correction log | To National | No | No | **YES until withdrawn** |
| **MF-09** | **The correction log is empty across a reporting period** | **[S-E: Rule E-88, ES.5, MAF-04]** | **PILOT-BLOCKING** | Errors known and not entered | Two consecutive empty periods | TS-6 emptiness test | Publish the anomaly; refer to Audit | Audit | Anomaly record; referral | To Council | No | No | **YES — CL-3 requires a published correction** |
| **MF-10** | **A person recruited at a moment of vulnerability** | **[S-C: H-03, H-22; S-E: Rule E-13, PF-E3]** | **CATASTROPHIC** | Any conversion approach to a beneficiary | Any membership language at a help interaction | HM-12; complaint route; observation | Stop; withdraw; retrain; publish if material | Team Leader + HR | Incident record | Immediate | **YES for the pathway** | **YES if systemic** | **YES** |
| **MF-11** | **`H_gov` exceeds `σ_max` sustained** | **P-01; [S-B: §25, §26]** | **PILOT-BLOCKING** | Controls added without retirement | Rising governance hours with flat delivery | P-01 by role and line; LM-12 | Retire instruments — one retirement per addition **[S-D: Rule D-128]**; route functions upward | City + Finance | `H_gov` ledger | To National | **YES for expansion** | No | **YES** |
| **MF-12** | **No out-of-team assessor exists and a promotion proceeds** | **[S-D: Rule D-45, ES.5]** | **PILOT-BLOCKING** | A vacancy and an available candidate | A Gate R assessment by an in-team person | Assessment record reviewer identity | **Do not promote.** Record the gap; use TL instruments with expiry | Appointing authority + HR | Recorded gap | To City | No | No | **YES** |
| **MF-13** | **Communication hours exceed service and verification hours** | **[S-E: Rule E-169]** | **SERIOUS** | Publication, moderation and query load | Ledger composition shifting | P-01 with communication lines | Retire instruments; reduce cadence | National Comms + City | Ledger | To National | No | No | **YES until corrected** |
| **MF-14** | **A partnership implies general endorsement** | **[S: Ch.5 §4.4; S-E: BR-4, Rule E-112]** | **SERIOUS** | A co-branded artefact | Any artefact carrying two marks | Brand-usage audit | Withdraw; correct; terminate if the agreement is breached | Communications + Legal | Correction log | To National | No | No | No |
| **MF-15** | **A language mismatch in the mandatory set** | **[S-E: Rule E-66; S-C: FR-11]** | **SERIOUS** | Publication in one language first | CI-6 mismatch | Language-match rate | Publish in the missing language; register the failure | Communications | Register entry | To National | No | No | **YES — GATE E1** |
| **MF-16** | **A beneficiary exposed in a published artefact** | **A-19; [S-E: Rule E-148, CI-14]** | **CATASTROPHIC** | Any image, name, locality detail or testimony | A draft containing a personal element without specific consent | CI-14; Editor rejection | Withdraw immediately; notify if required; correct | Editor + privacy officer | Correction log | Immediate | **YES for publication** | Case-by-case | **YES** |
| **MF-17** | **Whistleblowing misfiled as criticism or disloyalty** | **[S-E: Rule E-108 C-WHB, E-178; S-ST: M10]** | **CATASTROPHIC** | A report handled by the line it concerns | Any adverse change to a reporter | Classification record audit (Rule E-179) | Route to the Integrity Line; reverse the burden; protect | Audit + Integrity Line | Classification record | Immediate to Council | **YES for the affected unit** | Case-by-case | **YES** |
| **MF-18** | **Retaliation against a complainant, appellant or dissenter** | **[S-D: §18.2 non-retaliation with reversed burden]** | **CATASTROPHIC** | Any adverse change during or after a report | Any task, allocation or standing change | LM-9 pattern; HR review | Reverse; restore; treat as serious misconduct | HR + Governance panel | Panel record | Immediate | **YES** | **YES if by a leader** | **YES** |
| **MF-19** | **A reserved matter decided by an interim or local authority** | **[S-A: A-14 §13.3; S-D: L-10, Rule D-113]** | **CATASTROPHIC** | An apex vacancy plus an urgent decision | Any TL instrument touching mission, name, brand, assets, reserves, dissolution, permanent CEO appointment, the DO-NOT list or the waterfall order | Decision register review | Void the decision; restore the position; record | Council or the interim procedure | Decision record | Immediate | **YES** | **YES** | **YES** |
| **MF-20** | **Nominal compliance — artefacts exist, are approved, and change nothing** | **[S-D: LF-17; S-E: MAF-28, NRT-20]** | **CATASTROPHIC** | Approval without operation | **None available from inside.** Only downward experience, the Integrity Line, and asking people | Unknown | Unknown | — | — | — | — | — | **YES — undetectable, therefore unblockable** |
| **MF-21** | **Viral demand exceeding capacity** | **[S-E: SIM-01, Rule E-170]** | **SERIOUS** | Attention | Inbound rising faster than triage | HM-1 against capacity | Publish the limit, queue, criteria, window, alternatives; suspend celebration | City → National | Published limit | To National | No | No | No |
| **MF-22** | **A unit collapses with open commitments unaddressed** | **[S-B: B-24; S-E: SIM-20]** | **SERIOUS** | Loss of a team | SS-0 on mandatory roles; LDI at DEP-L | LM-1, LM-7 | Complete, transfer or honestly close every commitment with an alternative; publish the closure | City | Closure record | To State | No | No | **YES for that locality** |
| **MF-23** | **A shock event with no recorded cost** | **P-11; [S-B: B-04, B-11]** | **RECOVERABLE** | Any HC-* event | An event with no ledger entry | P-11 | Record the cost in hours and rupees; adjust the float | Team + Finance | Event record | To City | No | No | No |
| **MF-24** | **A decline or closure goes unpublished** | **[S-E: Rule E-176, TS-13]** | **SERIOUS** | Contraction | Openings published, endings absent | Compare openings to closures | Publish retroactively on the same terms | National | Publication record | To Council | No | No | No |
| **MF-25** | **A false association is not corrected within the window** | **[S-A: A-01 N9; S-E: Rule E-32]** | **SERIOUS** | A circulating false claim | The claim known and uncorrected | Media and platform scan | Correct calmly with the record; log it | Communications + Legal | Correction log | To National | No | No | No |
| **MF-26** | **A trust signal is published that identifies a person or small cell** | **A-17; [S-E: Rule E-99, E-100; S-D: Rule D-108]** | **SERIOUS** | Small populations | Any aggregate below the suppression threshold | Publication review | Suppress or aggregate; report the suppression | Privacy officer | Publication record | To National | No | No | No |
| **MF-27** | **A measurement is recorded without a verifier, or verified by the performer** | **Part IX; [S: Ch.18 segregation]** | **PILOT-BLOCKING** | Workload pressure | Any record with the same name as recorder and verifier | Audit sampling | Re-verify; if impossible, mark the measurement unavailable | Audit | Audit finding | To City | No | No | **YES — the evidence is not evidence** |
| **MF-28** | **An invented threshold, target or number appears in any artefact** | Rule F-17; **[S-A: A-L1]** | **PILOT-BLOCKING** | The pressure to have an answer | Any numeric target not traceable to source | Artefact audit | Withdraw; replace with `THRESHOLD REQUIRES FINAL APPROVAL` | Communications + Audit | Correction log | To National | No | No | No |

## XV.3 The register's finding

**[A]** Of 28 merged failure conditions: **11 CATASTROPHIC, 6 PILOT-BLOCKING, 8 SERIOUS, 1 RECOVERABLE, 0 INFORMATIONAL** (informational signals are the early-warning column, not separate failures), and **2 recorded as undetectable from inside (MF-20) or unblockable (MF-20)**.

**[P] Rule F-26 (Every Catastrophic Failure Has A Stop, Not A Review).** For MF-01…MF-07, MF-10, MF-16…MF-19 the immediate response is cessation of the affected activity, not the commissioning of a review. **[S-D: Rule D-33]** establishes stop-work capability as non-deferrable; **this register extends the same posture to publication, conversion and data activity.**

---

# PART XVI — ANTI-GAMING AND ANTI-CAPTURE REGISTER

## XVI.1 Method

**[P]** Eighteen capture and gaming vectors, each with **PREVENT → DETECT → RESPOND → AUDIT**. Controls are consolidated from **[S: Ch.25]** eight anti-gaming controls, **[S-A: A-01…A-06, A-16]**, **[S-C: MLM-1…MLM-7, H-19, H-21]**, **[S-D: GF-1…GF-30, CU-1…CU-10, VG-1…VG-6, PC-1…PC-8, L-18, L-34, L-35]** and **[S-E: AD-01…AD-14, AC-1…AC-9, ML-1…ML-8, E-35]**.

## XVI.2 The register

| Vector | **PREVENT** | **DETECT** | **RESPOND** | **AUDIT** |
|---|---|---|---|---|
| **Political capture** | A-01 N1…N9; tier restrictions A-02; election protocol A-03; refusal workflow A-04; **[S-D: PC-1…PC-8]**; **[S-E: PN-1…PN-4]** | Approach register; refusal log; **CI-3**; aggregate disparity testing | Recuse; refuse; log; publish the count; **repair not message** | Annual refusal count published; register sampling |
| **Religious capture** | A-05 eight clauses and four guards; activity-scoped, separately-branded, **never exclusive** faith partnerships; no religious ritual; **[S-E: RN-1…RN-7]** | Calendar, venue and routing pattern review; **CI-4** | Terminate the exclusivity; re-schedule; publish the correction | Pattern review per period |
| **Caste-based capture** | **[S-E: CN-1…CN-6]**; publish criteria before results; **no caste data collected (Rule E-48)** | Behavioural aggregates — routing, venue, timing, recognition, function distribution | Re-route; change venue or timing; publish the criteria | **[S-D: Rule D-79]** aggregate distribution with suppression |
| **Personality cult** | **[S-A: A-16 §15.4]**; **[S-D: CU-1…CU-10]**; **[S-E: AC-1…AC-9]**; no portrait, no eponymous artefact, no founder date | **The four annual tests — absence, attribution, dissent, successor; a zero count is a warning sign**; **CI-13** spokesperson count | Withdraw the artefact; distribute spokespersons; publish the test counts | Annual test publication |
| **Founder worship** | **[S-D: Rule D-92 Founder Recusal Register; Rule D-93 the founder may not assess]** | Attribution test T2; recusal register completeness | Record the preference as a declared interest, not a decision | Register sampling by Audit |
| **MLM / recruitment economics** | **[S-C: H-21; MLM-1…MLM-7]**; **[S-D: Rule D-118]**; **[S-E: Rules E-24, E-135, E-159, E-162]** | **Formula audit for any participation-linked term; vocabulary register; the growth-source test** | Void the formula; withdraw the artefact; publish the correction | Formula audit per period — **provable from documents alone** |
| **Leaderboard gaming** | **[S: Ch.25]** eight anti-gaming controls; **[S-D: GF-1…GF-30; Goodhart Prohibition List; two-independent-signal rule]** | Any metric becoming a target; task splitting; activity spikes | Void the score; retire the measurement (**one retirement per addition**) | Anti-gaming register review |
| **Fake service records** | **[S: App. F]** evidence standards; verifier other than performer; follow-up mandatory | **CI-8 traceability; P-09 outcome verification; audit sampling** | Treat as serious misconduct **[S: SOP-18]**; withdraw the claim | Re-performance against source records |
| **Fake revenue** | **[S: Ch.18]** segregation; **[S-B: B-05, B-13, B-25]** | Reconciliation; ageing; contribution recomputation | Void; refer; correct publicly | Random reconciliation **[S: App. A §18.3]** |
| **Fake volunteers** | **[S-B: B-08]** true-cost accounting; verification gates | **P-06 `N_ver` vs `N_act`; P-08 cost per onboard** | Remove from the record; correct any published count | Headcount reconciliation |
| **Popularity replacing competence** | **[S-D: L-01 Gate E/R separation; L-03 nine prohibited evidence types; Rule D-45 out-of-team]** | Assessment record evidence classes; **LM-8 opportunity allocation** | Void the assessment; re-assess out of team | Reviewer-identity check |
| **Retaliation against dissent** | **[S-D: §18.2 non-retaliation with reversed burden; S-E: E-190…E-195]** | **LM-9 appeal pattern; the dissent count; any adverse change to a reporter** | Reverse; restore; treat as serious misconduct | Pattern review across periods |
| **Selective disclosure** | **[S-E: TS-13 closures published on opening terms; Rule E-176; Rule E-218 pauses published]** | Compare openings to closures published; expansions to pauses | Publish the omitted item retroactively | Publication completeness **CI-12** |
| **Reputation manipulation** | **[S-E: Rule E-90 no trust claim; E-91 reputation never a target; E-111 no endorsement; E-123 no paid praise]** | Any trust adjective; any celebrity or creator adjacency; any paid placement undisclosed | Withdraw; disclose; correct | Artefact audit |
| **Financial manipulation** | **[S: Ch.18]** four hands; **[S-B: B-25]** risk-proportionate controls | Reconciliation anomalies; reserve release without authority | Void; refer; correct | Audit & Ethics **[S: Ch.27]** |
| **Nepotism** | **[S-D: L-34 declaration before participation; recusal on the matter; Rule D-79]**; **[S-D: L-09 prohibited tie-breaks]** | Declaration register; relationship fields on assessment; **LM-8** | Recuse; void the decision; re-decide | Declaration completeness |
| **Role concentration** | **[S: Ch.18]** segregation; **[S-D: L-28 held-versus-routed; L-34]**; **A-14 §13.4** dual custody | **LDI dependency exposure (LM-7); LLI load (LM-6)** | Route the function upward; appoint a deputy; record | Dependency register review |
| **Data misuse** | **A-17…A-20**; **[S-A: A-01 N7 — political use of data is serious misconduct]**; **[S-C: CR-1…CR-4]**; **[S-E: Rule E-199]** | Access logs with reason codes; the two-person rule on C4; export logging | Revoke; refer; notify if required | Access-log audit; **A-20 sealed-category review** |

## XVI.3 The finding

**[A]** Sixteen of the eighteen vectors are **detectable from records alone** — which is what **[S-A: A-01 N2]** means by "the strongest and most testable rule; audit can verify it from records alone." **Two are not: caste-based capture (because the proving data may not be collected) and personality cult (because affection is not a record).** Both are managed behaviourally rather than detected, and both carry a permanent residual recorded in Part XV and in **[S-E: AD-06, NRT-04]**.

**[P] Rule F-27 (A Control That Cannot Be Audited From Records Is A Statement Of Intent).** Every PREVENT entry above is paired with a DETECT entry that reads from a record. Where no record exists, the control is marked and the residual is carried — **not presented as a control.**

---

# PART XVII — UNRESOLVED CONTRADICTION REGISTER

## XVII.1 Method

**[P]** Forty contradictions recorded across the corpus — **C-D-01…C-D-20 [S-D: Part 47]** and **E-C-01…E-C-20 [S-E: Part 64]**. **None is silently reconciled.** For each: the competing requirements, why both cannot be satisfied, whether the architecture explicitly refused resolution, whether external authority is required, whether the pilot can proceed, and **what remains prohibited from being claimed**.

**[P] Rule F-28 (A Contradiction Is Not Closed By This Register).** Where a source instrument refused resolution, the refusal is preserved. Where a source instrument resolved a contradiction by reading, the reading is recorded as a reading and not as a fact.

## XVII.2 v1.3-D contradictions — C-D-01 … C-D-20

| ID | Competing requirements | Why both cannot be satisfied | Refused? | External authority? | **Pilot may proceed?** | **Prohibited from being claimed** |
|---|---|---|---|---|---|---|
| **C-D-01** | **"Best Mohalla Team can become City Head Team" [S: Const. Art.15, APPROVED]** vs a team is composed of people who have lives, families and locality — moving the team moves the people | Promoting a *team* either relocates people against their lives, or transfers a label to different people, in which case the team that earned it did not get it | **YES — [S-D] records it as a true contradiction and refuses** | **YES — a constitutional interpretation by the approving authority** | **YES — no promotion occurs in the pilot** | That Art.15 has been interpreted, or that any promotion route under it is settled |
| **C-D-02** | **"Serve without expecting reward" [S: Const. Art.2, APPROVED]** vs the leader is paid in the same framework with a higher allocation **[S: App. A §15.3]** | Resolved by reading: the article addresses *motive*, §15.3 addresses *compensation for work*. Both hold if payment is for verified work rather than for status | No — resolvable by reading | No | **YES** | That leadership is unpaid, or that service is uncompensated |
| **C-D-03** | **"Volunteer count … cannot determine leadership" [S: Ch.25]** vs "volunteer reliability" is a specified metric **[S: App. A §18.3]** | Resolved by reading: a *count* is prohibited; *reliability* is a rate against commitment, not a headcount | No — resolvable by reading | No | **YES** | That a headcount informed any decision |
| **C-D-04** | **"Performance is monthly" [S: Const. Art.14, APPROVED]** vs service outcomes, sustainability and correction mature over quarters and years | Both hold only if scoring is two-speed — **[S-D: L-05]** proposes four windows, which *extends* Art.14 rather than contradicting it | No — resolved by L-05, `PROPOSED` | No | **YES** | That a monthly score reflects outcome or sustainability |
| **C-D-05** | **"One role has one primary holder" [S: Ch.22]** vs State A permits role combination, and small size never removes duties **[S: Ch.10]** | Resolved by reading: one *primary holder per role*; one *person may hold several roles*, each with its own record. **`c` and `⌈9/c⌉` remain `UNRESOLVED` (LDR-U13)** | No — but the combination factor is unresolved | No | **YES — with `c` recorded as observed, not chosen** | Any span-of-control number |
| **C-D-06** | **Four distinct finance hands [S: Ch.18, APPROVED]** vs a State A team may have fewer than four holders **[S-B: §3.3]** | A genuine operational contradiction: segregation is APPROVED and non-negotiable, and a small team may not have four people | **Partly — [S-B] routes functions rather than waiving them** | No | **YES only if the four functions are held or routed, never merged (Rule D-33)** | That segregation was waived for size |
| **C-D-07** | **"Leadership is earned through performance" [S: Const. Art.4, APPROVED]** vs "opportunity is not an automatic personal entitlement" **[S: Ch.26]** | Resolved by reading: performance earns *consideration*; entitlement would remove the gate | No | No | **YES** | That a score entitles anyone to a role |
| **C-D-08** | **CEO holds executive authority [S: Ch.4, Ch.5]** vs a National Council is contemplated **[S: Ch.5; S-A: A-N19 PROPOSED]** | Two apex authorities with no determined relationship; every reserved matter needs one of them | **YES — [S-D] and [S-E] both refuse; LDR-U01 and A-N19 remain `AUTHORITY UNRESOLVED`** | **YES — corporate governance counsel (A-V9) and the founder** | **YES — the interim reserved-matter procedure [S-D: Rule D-113] suffices for a one-team pilot** | That any body has authority over the CEO, or that the CEO has authority over the Council |
| **C-D-09** | **"Leadership transfer: CEO / governance process" [S: App. E]** vs "leadership transition rules: NOT FINAL" **[S: Ch.33]** | An authority is assigned for a process that is not final | No — but LDR-U04 is `NOT FINAL` | Yes — governance | **YES — no transfer occurs in the pilot** | That the transition process is settled |
| **C-D-10** | **"A person is never scored" [S-C: §23.2]** vs `succession_status` stores "ready/acting/nominated status" **about a person** **[S: Ch.22]** | A state about a person is not a score of a person — resolvable by reading, and **[S-D: Rule D-63]** adopts bands not scores | No | No | **YES** | That any person has a score, grade, rank or percentile |
| **C-D-11** | A Team Leader **"cannot … punish people" [S: Ch.9]** vs leadership failure leads to "replacement / dynamic succession" **[S: Ch.14]** | Resolved by reading: replacement is a governance act by a panel, not a punishment by a line manager **[S: App. E; S-D: RM-1…RM-10]** | No | Yes — employment counsel | **YES** | That a Team Leader removed anyone |
| **C-D-12** | **AI "cannot autonomously make consequential … leadership decisions" [S: Const. Art.12, APPROVED]** vs an eligibility engine and a scoring pipeline determine who is considered | Determining *who is considered* is a consequential act even though a human decides the outcome | **Partly — [S-D: L-26, AI-1…AI-8] constrains it; Rule D-107 remains `UNVALIDATED`** | Yes — technology and equality | **YES — no AI in the pilot** | That any AI influenced who was considered |
| **C-D-13** | **Worker compensation is priority 1 [S: Ch.18, APPROVED — THE CONTROL]** vs a leader allocation is drawn from the worker-compensation base **[S-B: §24]** | If `C_lead = C_wc_base × m_lead`, leadership pay is inside priority 1 — which either protects it or inflates it | **YES — `m_lead` is `NOT FINAL` (LDR-U02)** | Yes — labour, tax, accounting | **YES — with the deficit recorded if leadership is unpaid (Rule D-126)** | Any leader multiplier; that leadership work is free |
| **C-D-14** | **"No ordinal numbering" in any public medium [S-C: SR-2]** vs a leaderboard ranks teams **[S: Ch.25; App. E]** | Teams may be ranked while persons may not — but a team rank is read as a rank of its members | **YES — LDR-U11 leaves leaderboard publicity open; [S-ST: R5] leaves it open** | No | **YES — no leaderboard need exist in the pilot** | That any comparative artefact is public |
| **C-D-15** | A non-selected member **"may apply again" [S: Ch.11 step 9]** vs no interval, limit or feedback obligation is stated | An unlimited right with no feedback obligation produces repeated rejection without information | **Partly — [S-D: L-27] adds a mandatory specific-feedback obligation** | No | **YES** | That reapplication has a defined interval |
| **C-D-16** | **Autonomy is "earned freedom inside central standards" [S: App. A §16.1]** vs safety, HR verification, finance integrity and evidence duties are never removed **[S: Ch.10 State A]** | Resolved by reading: autonomy applies to *how*, never to *whether* the four duties exist | No | No | **YES** | That autonomy waives any of the four |
| **C-D-17** | **Appointment of a permanent CEO is a reserved matter [S-A: A-14 §13.3]** vs "leadership transfer: CEO / governance process" **[S: App. E]** | The CEO cannot appoint the CEO; and no interim authority may | **YES — depends on LDR-U01 and LDR-U19** | **YES — corporate counsel (A-V1, A-V9)** | **YES — not triggered by a pilot** | That any interim authority appointed a permanent CEO |
| **C-D-18** | **The Auditor is "review only; not operational commander" [S: Ch.23]** vs leaderboard finalisation is "Performance / Audit" **[S: App. E]** | Finalising a ranking is an operational act with consequences for people | **Partly — [S-D: INV-15] preserves review-only; LDR-U11 leaves the leaderboard open** | No | **YES — no leaderboard** | That Audit finalised anything with operational consequence |
| **C-D-19** | **"Serve without expecting reward" [S: Const. Art.2]** vs mentoring, training, verifying and assessing are paid work (**[S-D: Rule D-47]**) | Resolved by reading: reward for *work performed* is compensation; reward for *service rendered to a beneficiary* is prohibited | No | Yes — labour | **YES** | That service is paid, or that development work is free |
| **C-D-20** | **Elder/Mentor is "excluded from RBAC command and from scoring" [S-C: §6.10]** vs an Elder may be a source of LE-4 trust evidence | Excluded from *command and scoring*, not from *testimony* — resolvable by reading, but the Elder's word about a person carries weight without accountability | **Partly — [S-D: Part 13 §13.6] requires that a mentor not assess their own mentee** | No | **YES** | That an Elder's testimony alone determined readiness |

## XVII.3 v1.3-E contradictions — E-C-01 … E-C-20

| ID | Competing requirements | Why both cannot be satisfied | Refused? | External authority? | **Pilot may proceed?** | **Prohibited from being claimed** |
|---|---|---|---|---|---|---|
| **E-C-01** | National identity vs political neutrality (A-01 N4, N5) | A national identity expressed through any prohibited symbol, colour or favourable content is political; expressed through none, it is thin | No — **managed by Rule E-6 and Rule E-57**; the tension is permanent | Yes — per-state political review | **YES** | That the organisation represents India or any Indian identity |
| **E-C-02** | National identity vs religious neutrality (A-05 clauses 2, 6) | Apparent only: a shared *service* identity requires no theological content | No | No | **YES** | Any theological position, favourable or unfavourable |
| **E-C-03** | National identity must be shown caste-neutral vs **no caste data may be collected** (A-18; A-N5) | The proving instrument is the prohibited instrument | **YES — refused; Rule E-48** | **Yes — privacy and equality law** | **YES — behaviourally, not demographically** | Any caste composition figure, in any direction, for any purpose |
| **E-C-04** | National consistency vs local autonomy | Apparent: consistency of *standards* versus consistency of *expression* | No — Rule E-50 | No | **YES** | That local expression is deviation |
| **E-C-05** | Brand visibility vs vigilante perception (A-06 V1…V3, V8) | **TRUE.** A brand only on documents and banners is far less visible than one on shirts | **YES — resolved against visibility; Rule E-65** | No | **YES** | That the organisation is visually recognisable in public |
| **E-C-06** | Recognition vs personality cult | Apparent: credit a person for *work* versus describe a person's *quality* | No — Rule E-152 | No | **YES** | Any description of a person's character, sacrifice or destiny |
| **E-C-07** | Growth vs anti-MLM | Growth needs people to tell people; anti-MLM forbids rewarding them for it | No — **Rules E-135, E-162** | No | **YES** | That anyone gained anything from introducing anyone |
| **E-C-08** | National membership vs voluntary participation | **TRUE if membership is a target.** A target creates pressure | **YES — resolved against the target; Rules E-86, E-183** | No | **YES** | Any membership, join-rate or conversion figure as an objective |
| **E-C-09** | Transparency vs privacy (A-17…A-20) | **TRUE and permanent.** The most persuasive records are the most identifying | **YES — resolved toward suppression; Rule E-99** | Yes — data protection | **YES** | That transparency is complete |
| **E-C-10** | National communication volume vs evidence discipline | Communication is bounded by evidence volume | No — Rule E-107 | No | **YES** | Anything not already in a published record |
| **E-C-11** | National expansion vs economic viability (`σ_max`; no revenue line for governance or communication) | **TRUE at the margin.** Each locality adds cost with no revenue line for it | **YES — Rules E-166, E-168; GATE E6** | Yes — accounting | **YES at one locality** | That expansion is affordable |
| **E-C-12** | National expansion vs leadership capacity | **TRUE.** Expansion multiplies units faster than leaders and assessors | **YES — not resolved; carried** | No | **YES at one locality** | That leadership supply supports growth |
| **E-C-13** | National expansion vs human-system validation | **TRUE in sequence.** National communication describes a human system never observed | **YES — the claim ladder resolves it** | No | **YES at CL-0/CL-1** | Anything above CL-1 |
| **E-C-14** | National claims vs pilot evidence | **TRUE.** The pilot cannot validate seven of the leadership claims and none of the national ones | **YES — Rules E-129, TS-14** | No | **YES** | That pilot results generalise |
| **E-C-15** | National brand vs founder identity (**[S: Ch.4]** brand is owned personally; **A-16 §15.4** requires the public face to be many people) | **TRUE and structural.** The brand is owned by a person while the identity must not be a person | **YES — carried; A-N12 unresolved** | **Yes — IP counsel (A-V8)** | **YES locally under BR-9** | That the brand is institutionally owned |
| **E-C-16** | AI-assisted communication vs Art.12 | Apparent: a translated consent text or safety instruction *is* a consequential decision | No — **Rule E-68** | Yes — legal per language | **YES** | That any machine-translated LA-1/LA-5 text was published unreviewed |
| **E-C-17** | Digital scale vs physical community | Digital reach is cheap; digital belonging is not a thing | No — **Rules E-196, E-198** | No | **YES — no technology** | That an online community exists |
| **E-C-18** | National consistency vs local culture | Apparent: meaning registered, wording local | No | No | **YES** | That a local wording changed a meaning |
| **E-C-19** | National reputation vs truthful failure disclosure | **TRUE in incentive terms.** The deciders are the damaged parties | **YES — minimum correction only (Rule E-88); [S-E: ES.5]** | **No external authority can supply the willingness** | **YES — and the pilot is the first test of whether it will be honoured** | **That the organisation publishes its failures, until it has** |
| **E-C-20** | National growth vs governance burden | **TRUE if the divisor is not sub-linear** | **YES — carried; LDR-U14** | No | **YES at one locality** | That governance scales sub-linearly |

## XVII.4 Summary

| Class | Count | Items |
|---|---|---|
| **TRUE CONTRADICTION — refused, resolved against growth / visibility / reputation** | 5 | C-D-01, E-C-05, E-C-08, E-C-11, E-C-13 |
| **TRUE CONTRADICTION — NOT RESOLVED, carried** | 8 | **C-D-08, C-D-13, C-D-14, C-D-17, E-C-03, E-C-12, E-C-15, E-C-19, E-C-20** |
| **TRUE IN INCENTIVE TERMS — minimum correction only** | 1 | **E-C-19** (counted above) |
| **PARTLY REFUSED / constrained but open** | 6 | C-D-06, C-D-09, C-D-12, C-D-15, C-D-18, C-D-20 |
| **TENSION — both preserved with a control** | 6 | E-C-01, E-C-07, E-C-09, E-C-10, E-C-14, E-C-20 |
| **APPARENT CONFLICT — resolvable by reading** | 14 | C-D-02, C-D-03, C-D-04, C-D-05, C-D-07, C-D-10, C-D-11, C-D-16, C-D-19, E-C-02, E-C-04, E-C-06, E-C-16, E-C-17, E-C-18 |

**[A]** **The pilot may proceed without resolving any of the forty.** That is the most important finding in this Part, and it is not reassuring: **it means the pilot will generate evidence inside an architecture whose apex authority (C-D-08), whose leadership pay (C-D-13), whose comparative artefacts (C-D-14), whose CEO succession (C-D-17), whose brand ownership (E-C-15) and whose failure-disclosure incentive (E-C-19) are all unresolved.** Every one of those is a decision about *what the pilot's evidence will eventually be used for*, and none is a decision about *whether the pilot can run*.

**[P] Rule F-29 (Unresolved Contradictions Bound The Claim, Not The Activity).** Each row's final column states what may not be claimed while the contradiction stands. **The pilot may operate; the claim may not exceed the contradiction.**

---

# PART XVIII — NO-FALSE-READINESS AUDIT

## XVIII.1 The question

**[P]** Brief §XVIII: **things that look complete but are not proof of readiness.** For each artefact: what its existence proves, what it does not prove, and what would prove it.

**[A]** The governing principle, from **[S-D: MAT-series]** and **[S-E: NI/MA]**: **a level is determined by what a unit actually operates, not by what it documents.**

## XVIII.2 The audit

| Artefact | **What its existence proves** | **What it does NOT prove** | **What would prove readiness** | State |
|---|---|---|---|---|
| **Written policy** | That a decision was articulated | That anyone performs it, that it survives contact with a real case, or that its absence would be noticed | **A record produced by performing it, and an audit finding that changed something** | 1 |
| **Organisational chart** | That roles were conceived | That any role is filled, that authority is exercised, or that a vacancy is survivable | **A named holder per role, an SS state per covered role, and a completed transition** | 1 |
| **Role definitions** | That boundaries were thought about | That a role-holder knows them, or refuses an instruction that crosses them | **An observed refusal, recorded, with no adverse consequence** | 1 |
| **Badges / ID cards** | That a design was approved | **Nothing about identity, authority or safety.** A card proves only that a card exists — and **[S-A: A-06 V4]** requires it to be *carried, not worn*, so its correct use is invisible | **A role claim verified through the public channel, and a card that conferred nothing** | 1 |
| **App / platform** | That software was written | That any process needs it, that it encodes the right decisions, or that it improves anything | **A process proven manually first (Rule F-24), then automated, then measured** | **1 — and premature (BLK-F-01)** |
| **Leaderboard** | That ranking is technically possible | That ranking selects well. **[S-D: L-18 GF-series]** and **[S-ST: F-19]** show it selects for what is measured | **Two independent signals agreeing, out-of-team assessment operating, and no ordinal artefact about a person** | **1 — and unresolved (LDR-U11)** |
| **Brand identity** | That a mark was designed | That the institution deserves it. **A national logo can exist in one day; a national institution cannot (brief §234)** | **CL-n evidence matching the claim class; A-N12 and A-N13 resolved** | **1 — and blocked (N-E-02)** |
| **Social media** | That accounts exist | That anyone is served, or that reach is trust. **Rule E-106: followers are communication signals at most** | **CI-15 unaffiliated repeat use; CI-8 claim traceability on everything posted** | 1 |
| **Training material** | That content was written | That competence was produced. **[X]** training alone did not improve retention in one large volunteer sample, because training raises expectations the role must then meet | **A comprehension check, an observed task, and an assessed delegation** | 1 |
| **Financial waterfall** | That a priority order was decided — **and it is APPROVED architecture, so this is real** | That priority 1 can lawfully be paid. **LDR-U08, LDR-U09 and A-N16 are unresolved; A-B1 and A-B9 are BLOCKERS** | **P-13: payment continuity across periods, from a real account, under a real mandate** | **1 → 2 only when BLK-A-01…03 close** |
| **AI architecture** | That boundaries were specified — **Art.12 is APPROVED, so this is real** | That any AI operates, or that review caps hold under volume. **[S-ST: F-29]** rubber-stamping | **A-22 field set populated by real use, with review caps observed** | **1 — and absent from the pilot entirely** |
| **Membership system** | That a lifecycle was designed | That anyone has joined, been verified, been assigned a role, or left with dignity | **HM-4, HM-5, HM-12 with real people** | 1 |
| **Public claims** | That a sentence was written | That it is true, checkable, or at the right class. **Rule E-8: a statement that cannot be traced to a record may not be published however true it is** | **CI-8 at 100%; the claim register audited** | 1 |
| **A pilot plan** | That measurements were specified | That anything was measured. **This document is a pilot plan** | **Completed recording forms with named recorders and verifiers** | 1 |
| **A readiness register** | That blockers were identified | That any blocker is closed. **This document is a readiness register, and its own verdict is C** | **GATE P0 passing on evidence** | 1 |
| **Six comprehensive instruments** | That the architecture was thought through more thoroughly than most national institutions have managed | **That it works.** Five instruments independently returned **D — NOT YET PROVEN** | **State 3 evidence from the pilot** | 1 |

## XVIII.3 The three substitutions to refuse

**[P] Rule F-30 (Three Prohibited Substitutions).**

| Substitution | Why it is tempting | Why it is false |
|---|---|---|
| **Documentation → operation** | A complete document feels like a complete system | **A document is a description of an intention. An operation is a record of an act. Only the second is evidence** |
| **Approval → implementation** | Approving 164 amendments feels like adopting them | **Approval is the *start* of implementation. Every amendment in Part II has `In arch. = NO — proposed`** |
| **Design → validation** | A well-designed control feels like a working control | **[S-D: Rule D-122]: an unexercised control counts as absent. [S-E: Rule E-88]: an empty log is an anomaly, not a clean bill** |

**[A]** The closing observation of this Part, offered without softening: **this register is itself an artefact of the kind it audits.** It is a State 1 document about State 1 documents. **Its value is entirely conditional on it being used to close 259 decisions and 11 validations — and if it is instead filed, it becomes the seventeenth item in the table above.**

---

# PART XIX — PILOT AUTHORISATION PACKAGE

## XIX.1 Method

**[P]** Ten packages. **Each lists the required artefact, its source, its status, its owner (by role), its dependency and its evidence of completion.** An artefact whose status is `UNRESOLVED` cannot have evidence of completion, and the package cannot be signed.

## XIX.2 PAK-01 Governance Package

| Artefact | Source | Status | Owner | Dependency | Evidence of completion |
|---|---|---|---|---|---|
| Certificate of registration and objects clause permitting all four pillars | **A-B1**; **[S: Ch.33]** | **`UNRESOLVED` — LDR-U08** | Founder/CEO + corporate counsel | — | The certificate |
| Reserved-matters list (seven items) | **A-N18**; **[S-A: A-14 §13.3]** | `PROPOSED` | CEO + Council | LDR-U01 (interim procedure suffices) | The adopted list |
| Interim reserved-matter procedure | **[S-D: Rule D-113]** | `PROPOSED` | CEO | — | The procedure, and one tabletop use |
| Decision register operating (M1) | **A-N23**; **[S-A: A-15 M1]** | `PROPOSED` | National Operations | — | **≥1 decision record with reason, decider, date** |
| Amendment adoption sequencing | **A-N38** — "Immediately" | `PROPOSED` | CEO + Council | — | The adopted sequence |
| `n_min` for the pilot team | **LDR-U06**; **[S-D: L-28]** | **`UNRESOLVED`** | National + CEO | LDR-U13 `c` | The recorded decision |
| MVLS-1…MVLS-12 adopted | **[S-D: L-21; LDR-19]** | `PROPOSED` | CEO | — | The adoption record |
| Key-person dependency register started | **A-N20**; **A-I5** | `PROPOSED` | National HR + Operations | — | The register, however short |

## XIX.3 PAK-02 Legal Package

| Artefact | Source | Status | Owner | Dependency | Evidence of completion |
|---|---|---|---|---|---|
| Entity-structure decision paper and counsel opinion | **A-B1**; **V-01** | **`UNRESOLVED` — the single next artifact** | Founder/CEO + corporate counsel | — | **A written opinion held as governance evidence** |
| Tax position opinion — 12A / 80G / FCRA | **V-04**; **[X]** | Required | Tax counsel + CA | Entity structure | Written opinion |
| Worker-classification opinion | **V-05**; **LDR-U09** | **`UNRESOLVED`** | Labour counsel | Entity structure | Written opinion |
| **Written answers to A-10 §9.1 L1–L15** | **A-B2**; **A-N10** | **`UNRESOLVED` — questions posed, not answered** | National Legal + Finance + CEO | Insurance broker | **The written answers, held as governance evidence** |
| Intervention-boundary and reporting-duty opinion | **A-B3**; **V-09**; **[X]** BNSS 2023 | Required | Criminal/regulatory counsel | — | Written opinion |
| Certified safeguarding standards and protocols | **A-B6**; **V-08** | Required | Safeguarding specialist + Safety | — | Certificates; the protocol |
| Political Neutrality Code adopted + counsel review | **A-B4**; **A-N1** | `PROPOSED` | CEO + Council | — | Adoption record; opinion |
| Public Protection Statement approved and published in the operating language | **A-B5**; **A-N7** | `PROPOSED` draft | CEO + Communications + Legal | **V-16 communications counsel** | The published statement |
| DO-NOT list entrenched as Tier-1 | **A-B5**; **A-N8** | `PROPOSED` | CEO + Council | A-N21 mission lock (deferrable) | The entrenchment instrument |
| Protection Visibility Protocol V1…V43 adopted | **A-N6** | `PROPOSED` | National Safety + Legal + Communications | — | Adoption record; terminology review per language |
| Protection Activation Gate adopted | **A-B8**; **A-N11** | `PROPOSED` | CEO + National Safety + Legal | A-N10 | The gate document |
| Non-police ID card design approved | **[S: Ch.31] blocker**; **A-N31** | **`PROPOSED` — blocker undelivered** | Communications + Legal | **V-11 IP; per-state review** | **The approved mock-up** |
| Comms policy approved | **[S: Ch.31] blocker** | **`PROPOSED` — blocker undelivered** | Communications + Legal | — | **The policy** |

## XIX.4 PAK-03 Finance Package

| Artefact | Source | Status | Owner | Dependency | Evidence of completion |
|---|---|---|---|---|---|
| Bank account with ≥2 signatories and a continuity rule | **A-B9**; **A-N16** | **`UNRESOLVED`** | Finance + CEO | Entity structure | **The mandate document** |
| Dual custody of every credential and channel | **[S-A: A-14 §13.4]** | `PROPOSED` | Finance + Technology/Operations | — | The custody register |
| Four segregated finance functions held or routed | **[S: Ch.18]**; **C-D-06** | APPROVED architecture | Finance | `n_min` | The routing record |
| Accrued compensation ledger | **[S-B: B-05]** | `PROPOSED` | Finance | Classification | The ledger |
| Payment sheet with its formula version | **[S: Ch.19 step 13]** | APPROVED architecture | Finance | Classification | **One completed sheet** |
| Float and wage-protection buffer funded | **[S-B: B-04; §13]** | **`UNKNOWN — unsizable until `S̄_5` measured`** | Finance + CEO | Funding source | The funding statement |
| Reserve seeding order adopted | **[S-B: B-03]** | `PROPOSED` | Finance + CEO | **A-N15 custody `UNRESOLVED`** | The adopted order |
| Collection terms standard | **[S-B: B-13]** | `PROPOSED` | Finance | Entity structure | The terms |
| Minimum viable control set MVC-1…MVC-11 | **[S-B: B-20]** | `PROPOSED` | Finance + Audit | `σ_max` | The adopted set |
| Founder-compensation position for the pilot recorded | **LDR-U16** | **`UNRESOLVED`** | **`AUTHORITY UNRESOLVED`** — the founder is the beneficiary | Rule D-92 recusal | **A recorded position, even if it is nil** |

## XIX.5 PAK-04 HR Package

| Artefact | Source | Status | Owner | Dependency | Evidence of completion |
|---|---|---|---|---|---|
| Member lifecycle and HR record implemented on paper | **[S: Ch.12]** | APPROVED architecture | HR & Verification | Classification | The register |
| Verification procedure with a written outcome | **[S: Ch.12]** immutable item 4 | APPROVED architecture | HR & Verification | — | **One completed verification** |
| Vacancy lifecycle and six statuses | **[S: Ch.10/11]** | APPROVED architecture | Team Leader + HR | `n_min` | The vacancy sheet |
| Ten training categories with material | **[S: Ch.12]** | `PROPOSED` | Training Lead | Certified where regulated **[V]** | Curriculum; comprehension records |
| Probation procedure | **[S: Ch.11/12]** | `NOT FINAL` — **LDR-U07 serious-misconduct procedure unresolved** | Team Leader + HR | — | A dated probation record |
| Permission sheet with delegation start and end dates | **[S: Ch.22]** | APPROVED architecture | Team Leader + HR | — | The sheet, with expiry |
| Refusal script and exit route published in the operating language | **[S-E: Rule E-165]**; **[S-C: H-17]** | `PROPOSED` | HR + Communications | Language review | **The published script** |
| Guardian-consent form for any minor activity | **[S-C: SA-series; HV-2]** | Required | Safeguarding + HR | **A-B6** | The form, legally reviewed |

## XIX.6 PAK-05 Safety Package

| Artefact | Source | Status | Owner | Dependency | Evidence of completion |
|---|---|---|---|---|---|
| Incident protocol matrix, triggers and do-not-attend list | **A-N9**; **A-09** | `PROPOSED` | National Safety + Legal | **A-B3** | The matrix |
| Incident record template **including A-06 V42–V43 visibility fields** | **A-09**; **PD-8** | **`PROPOSED` — the V42–V43 fields are absent from [S-D] and [S-E] templates** | Safety | — | **The template, with the fields** |
| Stop-work capability present at all times | **[S-D: Rule D-33]** | `PROPOSED` | Team Leader | `n_min` | The named holder |
| Emergency / first-aid training within scope | **[S: Ch.12]**; **A-B3** | Required | Training + Safety | Certified where regulated **[V]** | Certificates |
| **LA-5 emergency text pre-positioned in the operating language, including voice form** | **[S-E: Rule E-66, §14.5]** | `PROPOSED` | Communications + Safety | Language review | **The pre-positioned text** |
| Breach runbook rehearsed | **A-N29**; **A-17 P5** | `PROPOSED` | Privacy officer + Legal | **A-B7** | **A rehearsal record** |
| Public boundary statement | **[S-E: Rule E-116]** | `PROPOSED` | Communications + Safety | A-07 | The published statement |

## XIX.7 PAK-06 Leadership Package

| Artefact | Source | Status | Owner | Dependency | Evidence of completion |
|---|---|---|---|---|---|
| SS state recorded for every covered role | **[S-D: L-08]** | `PROPOSED` | Team Leader + HR | — | **The SS register** |
| Gate E criteria published | **[S-D: L-01]** | `PROPOSED` | HR | — | The published criteria |
| **Gate R recorded as a known gap — no out-of-team assessor exists** | **[S-D: Rule D-45, ES.5]** | **`GAP — recorded, not closable at one team`** | Appointing authority | A second team | **The recorded gap** |
| Temporary-leadership instruments with automatic expiry | **[S-D: L-10]** | `PROPOSED` | HR | — | The templates |
| Playbook for every covered role, **exercised by a non-holder** | **[S-D: L-16, CT-B]** | `PROPOSED` | The role-holder | — | **An exercise record** |
| Complaint, appeal, improvement and removal routes | **[S-D: L-23]** | `PROPOSED` | HR + Audit | **LDR-U07** | The routes, published |
| **No promotion planned during the pilot** | **[S-D: Part 52]** | **Required as a recorded scope decision** | CEO | Gate R gap | **The scope decision** |

## XIX.8 PAK-07 Technology / Data Package

| Artefact | Source | Status | Owner | Dependency | Evidence of completion |
|---|---|---|---|---|---|
| C1–C4 classification with a field register | **A-N25**; **A-17 P1** | `PROPOSED` | AI & Data + privacy officer | — | The register |
| Prohibited-collection list | **A-N32**; **A-18** | `PROPOSED` | CEO + privacy officer | — | The list |
| **Retention and erasure schedule with counsel-set periods** | **A-N26**; **A-17 P2** | **`UNRESOLVED` — periods deliberately not invented** | Legal + privacy officer | **V-07, V-17 records/archival** | **The schedule** |
| Privacy notice in the operating language | **A-N27**; **A-17 P3** | `PROPOSED` | Legal + Communications | Retention schedule | **The published notice** |
| Named privacy officer and data fiduciary | **A-N14** | **`UNRESOLVED`** | CEO + Legal + AI & Data | Entity structure | **The appointment** |
| Sealed-case model, break-glass procedure, subject rights | **A-N35**; **A-20** | `PROPOSED` | Legal + privacy officer + Safety | — | The procedure |
| Processor and vendor standard | **A-N30**; **A-17 P6** | `PROPOSED` | Legal + AI & Data | — | The contract terms |
| DPIA trigger list | **A-N28**; **A-17 P4** | `PROPOSED` — **deferrable (A-I10)** | Privacy officer | — | The list |
| **No technology procured** | **[S-B: §40]**; **BLK-F-01** | **Required as a recorded scope decision** | CEO | — | **The scope decision** |

## XIX.9 PAK-08 Communication Package

| Artefact | Source | Status | Owner | Dependency | Evidence of completion |
|---|---|---|---|---|---|
| **PLR-1…PL-7 posted for the locality, on paper** | **[S-C: H-03]**; **[S-E: E-16]** | **`PROPOSED` — does not exist in v1.2** | The team | Language review | **The posted sheet, dated** |
| Two ungated actions operating — report a need, help once | **[S-E: NP-1, NP-4]** | `PROPOSED` | The team | PLR | **One use of each** |
| Outward-reaching complaint route published | **[S-D: MVLS-9]**; **[S-ST: M10]** | `PROPOSED` | Team + out-of-locality recipient | — | **The published route** |
| **Correction log and refusal log, published, approval-free** | **[S-E: TS-6, TS-8, Rule E-186]** | `PROPOSED` | Anyone; Audit reviews | — | **The two logs** |
| Claim ladder, claim classes and evidence labels adopted | **[S-E: E-29, E-46]** | `PROPOSED` | Communications + Audit | — | The adopted ladder |
| Claim register | **[S-E: Rule E-26]** | `PROPOSED` | Communications | — | The register |
| Category sentence registered — **or explicitly not adopted, with the draft's status recorded** | **N-E-21**; **[S-ST: §20.2]** | **`NOT ADOPTED — draft only`** | Communications | **CI-2 measured first** | **The register entry, either way** |
| "What we are not" list approved | **[S-ST: §18.3 item 2]** | `PROPOSED` | Communications + Legal | — | The approved list |
| Terminology register for the operating language | **[S-C: H-25]**; **[S-E: Rule E-31]** | `PROPOSED` | Communications | Language review | The register |
| Mandatory translation set complete | **[S-E: Rule E-66]** | `PROPOSED` | Communications + Legal | **BLK-B-11** | **The four items in the operating language** |
| Public verification channel operating | **[S-ST: §14.2 Layer 2]**; **PLR-6** | `PROPOSED` | City | — | **One answered query** |

## XIX.10 PAK-09 Measurement Package

| Artefact | Source | Status | Owner | Dependency | Evidence of completion |
|---|---|---|---|---|---|
| All 60 measurements with a named recorder and verifier | Part IX | Required | City owner | — | **The measurement plan, signed** |
| Recording forms executable on paper | Part IX | Required | City owner | — | **The forms** |
| **The 7 `NOT TESTABLE` items recorded with minimum populations** | **[S-D: LM-8, LM-10]**; **[S-E: CI-3/4/5/10/13]** | Required | City owner | — | **The not-testable schedule** |
| **Every threshold from source or marked `THRESHOLD REQUIRES FINAL APPROVAL`** | Rule F-17 | Required | Audit | — | **The threshold schedule** |
| **The measurement-thinning statement (Rule F-22)** | This Part | **Required — and absent from all five prior instruments** | CEO + City owner | `H_gov` declaration | **Which of the 60 are continuous, per event, per period, or deferred, with reasons** |
| Success and failure conditions adopted | **[S-B: §40]**; **[S-C: §57]**; **[S-D: Part 41 PS/PF]**; **[S-E: PS-E/PF-E]** | `PROPOSED` | CEO | — | The adopted conditions |
| Pilot scope statement — the seven limits | **[S-D: Rule D-132]**; **[S-E: Rule E-223]** | `PROPOSED` | CEO | — | **The published scope statement** |

## XIX.11 PAK-10 Emergency / Failure Package

| Artefact | Source | Status | Owner | Dependency | Evidence of completion |
|---|---|---|---|---|---|
| Interim Authority Order at apex and local level | **[S-A: A-14]**; **[S-B: B-19]** | `PROPOSED` | CEO | A-N17, A-N18 | The orders |
| Crisis communication protocol CC-1…CC-8 | **[S-E: E-22]** | `PROPOSED` | Communications + Safety + Legal | Comms policy | The protocol |
| Seven-step public error response | **[S-E: Part 23 §23.3]** | `PROPOSED` | Communications | Correction log | The procedure |
| Authorised spokespersons designated **by domain and region** | **[S: Ch.24]**; **[S-A: A-16 §15.4]** | `PROPOSED` | National Communications | — | **The designations — more than one** |
| Failure register MF-01…MF-28 with pause and terminate triggers | Part XV | Required | CEO + Audit | — | The adopted register |
| Service continuity instrument for open commitments | **[S-B: B-24]** | `PROPOSED` | Team + City | — | The instrument |
| **PAUSE publication rule adopted** | **[S-E: Rule E-218]** | `PROPOSED` | CEO | — | The rule |
| Insurance in force, or protection activity withdrawn from scope | **A-N10**; **MF-02** | **`UNRESOLVED`** | Finance + Legal | **A-B2** | **The policy, or the recorded scope withdrawal** |

## XIX.12 Package status summary

| Package | Artefacts | **Signed now?** | Blocking items |
|---|---|---|---|
| **PAK-01 Governance** | 8 | **NO** | Entity structure; `n_min` |
| **PAK-02 Legal** | 13 | **NO** | Entity, tax, classification, insurance answers, safeguarding, ID card, comms policy |
| **PAK-03 Finance** | 10 | **NO** | Bank mandate; float; founder-compensation position |
| **PAK-04 HR** | 8 | **NO** | Classification; misconduct procedure; guardian consent |
| **PAK-05 Safety** | 7 | **NO** | Insurance answers; intervention boundary; V42–V43 template fields |
| **PAK-06 Leadership** | 7 | **NO** | Gate R gap must be *recorded*, not closed; no-promotion scope decision |
| **PAK-07 Technology / Data** | 9 | **NO** | Retention schedule; named fiduciary |
| **PAK-08 Communication** | 11 | **NO** | PLR; complaint route; two logs; mandatory translation set |
| **PAK-09 Measurement** | 7 | **NO** | Measurement-thinning statement; threshold schedule |
| **PAK-10 Emergency** | 8 | **NO** | Insurance; spokesperson designations |
| **TOTAL** | **88 artefacts** | **NO — zero of ten packages signable** | **13 `UNRESOLVED` items and 2 undelivered [S: Ch.31] blockers** |

---

# PART XX — PILOT EXIT GATE

## XX.1 The question the exit gate asks

**[P]** Not "did the pilot run?" but **"did the pilot produce credible evidence about people, service, money, leadership, safety, trust, governance, workload, communication and failure handling?"**

**[P] Rule F-31 (A Completed Pilot With No Evidence Is A Failed Pilot).** A pilot that ran for its full period and produced no measurements, or measurements with no verifiers, or claims with no records, **fails the exit gate.** Duration is not evidence.

## XX.2 The eleven exit conditions

| # | Domain | **PASS condition** | **Evidence** | FAIL if |
|---|---|---|---|---|
| **X-1** | **People** | Real people participated, returned, and could leave without adverse consequence | **HM-4, HM-5, HM-9, HM-12**; **CI-15** non-zero | Nobody returned; or nobody knew they could leave |
| **X-2** | **Service** | Outcomes were verified and followed up, **including unchanged and worsened** | **P-09, HM-8**; TS-2-format record | All outcomes reported as resolved; no follow-up |
| **X-3** | **Money** | Priority 1 was paid in every period; `H_gov` has an observed value; the cost of existing is known | **P-13, P-01, P-07, P-10** | Any period unpaid; `H_gov` unrecorded |
| **X-4** | **Leadership** | Every covered role had an SS state; decisions were recorded with reasons; a playbook was exercised by a non-holder | **LM-1, LM-2, LM-3** | Any mandatory role at SS-0; reason-free decisions |
| **X-5** | **Safety** | No unresolved serious incident; **or** every incident was recorded, reviewed and reported with the V42–V43 fields | Incident records; **LM-11** | An unrecorded incident; a missing visibility field |
| **X-6** | **Trust** | **At least one correction was published, and at least one refusal was logged** | **CI-9 non-zero; CI-10**; TS-6, TS-8 | **Both logs empty — which is not a pass, it is an anomaly referred to Audit** |
| **X-7** | **Governance** | The decision register operated; the complaint route reached outside the locality and was used or demonstrably available | **LM-3, LM-9** | A complaint route that never left the team |
| **X-8** | **Workload** | `H_gov` including communication hours was declared per role and stayed inside the observed window; unpaid work was recorded as a deficit | **P-01**; **[S-D: Rule D-126]**; **[S-E: Rule E-168]** | Communication hours exceeding service and verification hours with no retirement |
| **X-9** | **Communication** | PLR existed and was current; every published claim carried a class and a label and was traceable; nobody was recruited at a moment of need | **CI-8 at 100%, CI-12, CI-14, CI-6**; **PF-E1…PF-E8 all clear** | Any claim above its class; any unlabelled figure; any conversion approach |
| **X-10** | **Failure handling** | At least one failure occurred, was recorded, produced a learning entry with a "did it work" column, and changed a standard — **or** the absence of any failure is itself examined as improbable | **[S-A: A-15 M5, M3]**; **LM-11** | A failure hidden; a learning entry with no standard change |
| **X-11** | **Business sustainability** | Where a venture operated, its contribution margin is known; where none operated, **that is recorded rather than presented as a pass** | **P-03, P-04, P-05**; **P-15 if a City existed** | A venture whose margin was never computed |

## XX.3 The three exit outcomes

**[P]** Adopted from **[S-E: Rule E-219]**, with **IMPROVE as the default**:

| Outcome | Meaning | Consequence |
|---|---|---|
| **EXPAND** | All eleven conditions PASS **and** the four capability conditions hold | Authorise the next locality under XG-1…XG-8 **and** GATE E0…E4, recorded as a cost |
| **IMPROVE** | Conditions substantially met with identified corrections | **No expansion.** Correct, re-measure, re-evaluate. **This is the default where evidence is incomplete, ambiguous or of low confidence** |
| **PAUSE** | Any CATASTROPHIC or PILOT-BLOCKING failure unresolved; or priority-1 payment failed; or any PF-class condition breached | **Stop growth activity; publish the pause on expansion terms ([S-E: Rule E-218]); continue existing commitments** |

**[P] Rule F-32 (The Exit Report Publishes Its Own Limits).** The exit report must contain the seven **[S-D: Rule D-132]** limits and the seven **[S-E: Rule E-223]** limits, and must state which of the 60 measurements were not produced and why. **A report that omits its limits is a claim above its evidence class.**

---

# PART XXI — EXPANSION GATE

## XXI.1 The four transitions

**[P]** Success at one level does not prove the next. **Three gate sets are conjunctive at every transition ([S-E: Rule E-214]): [S-D: XG-1…XG-8] · [S-E: GATE E0…E7] · [S-B] economic conditions.**

| Transition | **[S-D] leadership conditions** | **[S-E] identity conditions** | **[S-B] economic conditions** | **Scaling-specific unknowns** |
|---|---|---|---|---|
| **LOCAL PILOT → ADDITIONAL MOHALLA** | XG-1…XG-8 all pass, **including XG-2 (a named SS-4 successor for the sponsor) and XG-8 (no existing unit falls below continuity cover)** | GATE E0, E1, E2 held; **GATE E4 — the communication set reproduced by people who were not its authors** | `H_gov` inside `σ_max` for both units; float intact; priority 1 paid in both | Whether the playbook transfers; whether verification is available for the second unit; **whether the first unit's leaders were the locally popular (Gate R gap)** |
| **MOHALLA → CITY** | Out-of-team assessment capability exists — **[S-D: §52.3 step 5, the pivot that moves the grade]**; City roles have SS states | GATE E5 — multi-locality evidence in materially different contexts; **≥1 independently verified impact claim; ≥1 published correction** | **B-21 City Shared Services Contract; P-15 `C_city` measured; P-12 escalation latency measured** | **The City divisor is a single-point observation until several teams exist**; whether shared services are cheaper than held functions |
| **CITY → STATE** | State assessment independence; cross-city succession exercised | GATE E6 — **communication capacity costed and funded**; language equity demonstrated | **`H_gov_per_team(K)` measured across a range of `K` and sub-linear or mitigated — LDR-U14**; **per environment type (Rule E-138)** | **Whether the divisor is sub-linear at all — the arithmetic condition for a State layer's existence**; whether a State layer is coordination or a hierarchy **[S-ST: §2.3]** |
| **STATE → NATIONAL** | National leadership proven; **[S-D] at B or above** | **GATE E7 — all ten [S-ST: §14.3] and all fifteen [S-ST: §30.3] pre-conditions; A-N12 and A-N13 resolved; mission lock executed; insurance in force; privacy programme live** | Reserves; multi-state economics viable; **the economic blueprint attached (LDR-U17)** | **Whether national identity is epistemic or affective in practice (N-E-01)**; whether political, religious and caste neutrality hold under real external pressure; whether communication burden forms a second organisation |

## XXI.2 What never justifies a transition

**[P]** Consolidated from **[S-D: Rule D-213-equivalent]**, **[S-E: Rule E-213]** and **[S-B: B-07]**:

Increased membership · increased followers · increased funding · increased media attention · increased inbound demand · a political or commercial invitation · a partner's offer · a leader's ambition · a locality's enthusiasm · **a successful pilot alone** · a completed document · an approved amendment · a favourable audit of paperwork.

## XXI.3 The weakest-capacity rule at every transition

**[P] Rule F-33 (The Constraining Capacity Is Named).** At every transition the authorisation record names the **smallest** of CAP-1…CAP-8 **[S-E: Part 42]** and states its observed value. **An authorisation that does not name its constraint is invalid.** This is **[S-E: Rule E-166]** applied to all four transitions, and it is the operational form of the bottleneck principle the brief requires.

---

# PART XXII — SINGLE MASTER REGISTER

## XXII.1 Status vocabulary

**[P]** Thirteen statuses, exactly as the brief specifies. **No vague status is used; "in progress" appears nowhere because no source instrument uses it.**

| Status | Meaning |
|---|---|
| **DECISION REQUIRED** | An `UNRESOLVED` question; no answer exists |
| **VALIDATION REQUIRED** | A `[V]` item awaiting a qualified professional |
| **BUILD REQUIRED** | A mechanism must be constructed |
| **IMPLEMENTATION REQUIRED** | An approved mechanism must be put into operation |
| **MEASUREMENT REQUIRED** | A value must be observed |
| **PILOT TEST REQUIRED** | The item's validity depends on pilot evidence |
| **EVIDENCE REVIEW REQUIRED** | Evidence exists and must be assessed |
| **COMPLETE — NOT YET PROVEN** | **State 1: written, approved or proposed, with no operational evidence. The status of all 164 amendments and of most of v1.2** |
| **PASS** | A gate condition satisfied on evidence. **No item in this register is at PASS** |
| **MODIFY** | Evidence review found the item requires change |
| **BLOCK** | The item cannot proceed; a dependency is unmet |
| **DEFERRED** | Deliberately postponed, with the reason and the review point recorded |
| **EXPLICITLY UNRESOLVED** | The corpus refuses to answer, and the refusal is the correct position |

## XXII.2 The canonical register

| ID | Source | Requirement | Category | Status | Dependency | Evidence required | Owner | Gate | Blocking level | Next action |
|---|---|---|---|---|---|---|---|---|---|---|
| **SR-01** | LDR-U08; **[S: Ch.33]**; A-B1 | Legal entity structure under Krytos | Governance | **DECISION REQUIRED** | — | A written decision plus counsel opinion | Founder/CEO | **P0-A, P0-B** | **BLOCKER A / Tier 0** | **Produce the entity-structure decision paper for counsel** |
| **SR-02** | LDR-U09; A-B1 | Worker classification | Legal | **DECISION REQUIRED** | SR-01 | Counsel opinion | CEO + Legal | P0-B | BLOCKER A / Tier 0 | Commission with SR-01 |
| **SR-03** | A-N16; A-B9 | Bank mandate, ≥2 signatories, continuity rule | Finance | **DECISION REQUIRED** | SR-01 | The mandate document | Finance + CEO | **P0-C** | BLOCKER A / Tier 0 | Establish on registration |
| **SR-04** | A-N10; A-B2 | Written answers to A-10 §9.1 L1–L15 | Insurance | **DECISION REQUIRED** | SR-01 | **Written answers held as governance evidence** | National Legal + Finance + CEO | P0-F | BLOCKER A / Tier 0 | Commission broker and counsel |
| **SR-05** | A-N14; A-B7 | Data fiduciary identity and named privacy officer | Data | **DECISION REQUIRED** | SR-01 | The appointment | CEO + Legal + AI & Data | P0-H | BLOCKER A / Tier 0 | Appoint |
| **SR-06** | A-N26; LDR-U10 | Retention and erasure schedule with actual periods | Data | **DECISION REQUIRED** | SR-05 | **A schedule with counsel-set periods** | Legal + privacy officer | P0-H | BLOCKER A / Tier 0 | Commission — **periods deliberately not invented** |
| **SR-07** | LDR-U06; **[S-D: L-28]** | `n_min` for the pilot team | Governance | **DECISION REQUIRED** | LDR-U13 `c` | A recorded decision | National + CEO | **P0-A** | BLOCKER A / Tier 0 | Decide from the five-condition set |
| **SR-08** | LDR-U01; C-D-08 | CEO versus National Council authority | Governance | **EXPLICITLY UNRESOLVED — `AUTHORITY UNRESOLVED`** | — | — | **`AUTHORITY UNRESOLVED`** | P0-A (interim procedure suffices) | **Tier 1 for the interim procedure; Tier 3 for the substance** | Adopt **[S-D: Rule D-113]** interim procedure now; refer the substance to A-V9 |
| **SR-09** | A-N19 | Apex dispute-resolution mechanism | Governance | **EXPLICITLY UNRESOLVED — `AUTHORITY UNRESOLVED`** | SR-08 | — | **`AUTHORITY UNRESOLVED`** | — | Tier 3 | Adopt the ladder as a proposal; do not constitute the Council before it |
| **SR-10** | LDR-U19; A-N17 | Successor to the founder / apex succession mechanism | Governance | **EXPLICITLY UNRESOLVED** | SR-08, SR-09 | — | Founder/CEO + Council | — | **Tier 1 — [S-A: A-N17] "preferably before the first hire"** | Adopt A-14 scenarios and the Interim Authority Order; **no instrument names a successor** |
| **SR-11** | A-N18 | Reserved-matters list (seven items) | Governance | **VALIDATION REQUIRED** | SR-08 | Adoption record | CEO + Council | P0-A | Tier 1 | Adopt as proposed |
| **SR-12** | A-N12 | Brand ownership and licensing terms | Brand / IP | **EXPLICITLY UNRESOLVED** | SR-01 | A licence instrument | Founder/CEO + IP counsel | **GATE E7** | **Tier 3 for the pilot; Tier 0 for any national use (Rule E-60)** | Decide **before the first public artefact bearing the name** (Rule F-13) |
| **SR-13** | A-N13 | IP ownership of architecture, SOPs, curricula, software, data models | Brand / IP | **EXPLICITLY UNRESOLVED** | SR-01 | An ownership or licence instrument | Founder/CEO + IP counsel | GATE E7 | Tier 3 | Commission with SR-12 |
| **SR-14** | LDR-U20; **[S: Ch.33]** | Name availability and registration | Brand / IP | **VALIDATION REQUIRED** | SR-01 | Search and registration evidence | CEO + IP counsel | — | Tier 1 | Search now — cheap, and irreversible if lost |
| **SR-15** | LDR-U02 | Leader multiplier `m_lead` | Economic | **EXPLICITLY UNRESOLVED — pilot measures it** | SR-02 | **LM-13 observation** | CEO + Finance | — | **Tier 2 — do not decide before measurement** | Record the deficit if leadership is unpaid (Rule D-126) |
| **SR-16** | LDR-U03 | Leaderboard weights 20/15/15/15/10/10/10/5 | Performance | **EXPLICITLY UNRESOLVED — `PROPOSED` in source** | SR-08 | — | **`AUTHORITY UNRESOLVED`** | — | Tier 2 | **Adopt windows and cohorts without altering the PROPOSED weights ([S-D: Part 52 step 4])** |
| **SR-17** | LDR-U11; **[S-ST: R5]** | Whether the leaderboard is public | Performance | **EXPLICITLY UNRESOLVED** | SR-08 | — | **`AUTHORITY UNRESOLVED`** | — | Tier 3 | No comparative artefact until decided |
| **SR-18** | A-N5 | Whether composition monitoring is undertaken at all | Data / equality | **EXPLICITLY UNRESOLVED — deliberately** | SR-05 | — | CEO + Council + privacy officer | — | **Tier 4 — decide before any collection, and collect none in the pilot** | Leave undecided; **Rule E-48 prohibits caste data for any purpose** |
| **SR-19** | A-N15 | Custody of reserves and the social-impact fund | Finance | **EXPLICITLY UNRESOLVED** | SR-01, SR-03 | A custody instrument | CEO + Finance + Council | — | Tier 3 — before reserves become material | Decide with SR-03 |
| **SR-20** | LDR-U16 | Founder compensation | Finance | **EXPLICITLY UNRESOLVED — `AUTHORITY UNRESOLVED` (beneficiary recusal)** | SR-01 | **A recorded position, even if nil** | **`AUTHORITY UNRESOLVED`** | P0-C | **Tier 0 for recording the position; Tier 3 for setting a figure** | Record the pilot position |
| **SR-21** | LDR-U17 | The economic blueprint | Economic | **EXPLICITLY UNRESOLVED — never attached** | SR-15, P-01…P-15 | **The pilot's own measurements** | CEO + Finance | — | **Tier 2 — the pilot produces it** | Do not attempt before measurement |
| **SR-22** | LDR-U18 | The 37.5 / 17 / 12 percentages | Economic | **EXPLICITLY UNRESOLVED — illustrative only** | SR-21 | **P-07, P-10** | CEO + Finance | — | Tier 2 | Never publish as policy |
| **SR-23** | LDR-U13, U14, U15 | Role combination factor `c`; City divisor shape; `K_min` | Economic | **MEASUREMENT REQUIRED** | A City | **P-01, P-15, LM-12** | National + Finance | GATE E5, E6 | **Tier 2 / Tier 4** | Measure; **no span number exists anywhere and none may be invented** |
| **SR-24** | LDR-U04, U05, U07 | Transition rules; team readiness threshold; serious-misconduct procedure | Leadership | **DECISION REQUIRED** | SR-08 | Adopted procedures | CEO + HR + Legal | P0-E, P06 | **Tier 0 for U07 (misconduct may occur at any time); Tier 2 for U04, U05** | Adopt the misconduct procedure first |
| **SR-25** | A-N1; A-B4 | Political Neutrality Code adopted | Neutrality | **IMPLEMENTATION REQUIRED** | V-01, V-04 counsel review | Adoption record | CEO + Council | **P0-B** | BLOCKER A / Tier 0 | Adopt with counsel review |
| **SR-26** | A-N7; A-B5 | Public Protection Statement published in the operating language | Communication | **BUILD REQUIRED** | V-16 counsel | **The published statement** | CEO + Communications + Legal | P0-B | BLOCKER A / Tier 0 | Draft, validate, publish |
| **SR-27** | A-N8 | DO-NOT list entrenched as Tier-1 | Safety | **IMPLEMENTATION REQUIRED** | SR-11 | The entrenchment instrument | CEO + Council | P0-B | BLOCKER A / Tier 0 | Entrench |
| **SR-28** | A-N6; **PD-8** | Protection Visibility Protocol **V1…V43** adopted | Safety | **IMPLEMENTATION REQUIRED** | Terminology review per language | Adoption record | National Safety + Legal + Communications | P0-F | BLOCKER A / Tier 0 | **Adopt all 43, not 8. Add the V42–V43 incident-record fields** |
| **SR-29** | A-N9 | Incident protocol matrix, triggers, do-not-attend list | Safety | **BUILD REQUIRED** | SR-04 | The matrix | National Safety + Legal | P0-F | BLOCKER A / Tier 0 | Build |
| **SR-30** | A-N11; A-B8 | Protection Activation Gate adopted | Safety | **BUILD REQUIRED** | SR-04 | The gate document | CEO + National Safety + Legal | P0-F | BLOCKER A / Tier 0 | Build |
| **SR-31** | A-B6 | Certified safeguarding — two-adult rule, image and consent absolutes, reporting protocol | Safeguarding | **VALIDATION REQUIRED** | V-08 | Certificates and the protocol | Safety + safeguarding specialist | **P0-F** | BLOCKER A / Tier 0 | Certify before any minor or vulnerable-adult activity |
| **SR-32** | A-B3 | Intervention boundary and reporting-duty counsel opinion | Legal | **VALIDATION REQUIRED** | V-09 | Written opinion | National Legal | P0-B | BLOCKER A / Tier 0 | Commission |
| **SR-33** | A-B7; A-N25, N27, N29 | Privacy minimum — classification, notice, breach runbook | Data | **BUILD REQUIRED** | SR-05, SR-06 | Register, published notice, **rehearsal record** | Privacy officer + Legal | **P0-H** | BLOCKER A / Tier 0 | Build and rehearse |
| **SR-34** | A-N32, N35 | Prohibited-collection list; sealed-case model and subject rights | Data | **IMPLEMENTATION REQUIRED** | SR-33 | The list; the procedure | CEO + privacy officer + Safety | P0-H | BLOCKER A / Tier 0 | Adopt |
| **SR-35** | **[S: Ch.31]** | **Comms policy** | Communication | **BUILD REQUIRED** | V-16 | **The policy** | Communications + Legal | **P0-G** | **BLOCKER A / Tier 0 — a v1.2 launch blocker** | Write and approve |
| **SR-36** | **[S: Ch.31]**; A-N31 | **Non-police ID card design** | Brand | **BUILD REQUIRED** | SR-12, V-11 | **The approved mock-up** | Communications + Legal | **P0-G** | **BLOCKER A / Tier 0 — a v1.2 launch blocker** | Design within **[S-E: E-12]** constraints and **A-06 V3, V4** |
| **SR-37** | **[S-C: H-03]**; **[S-E: E-16]** | Public local record PLR-1…PL-7, on paper | Communication | **BUILD REQUIRED** | SR-35, language review | **The posted sheet, dated** | The team | **P0-D, P0-G** | **BLOCKER C / Tier 0** | Build — **"not in the current architecture"** |
| **SR-38** | **[S-D: MVLS-9]**; **[S-ST: M10]** | Outward-reaching complaint route | Governance | **BUILD REQUIRED** | SR-35 | **The published route** | Team + out-of-locality recipient | P0-D | **BLOCKER C / Tier 0** | Build |
| **SR-39** | **[S-E: TS-6, Rule E-88, E-186]** | Correction log, published, approval-free | Reputation | **BUILD REQUIRED** | SR-35 | **A non-empty log across a period** | Anyone; Audit reviews | P0-G | **BLOCKER C / Tier 0** | Build — **and honour it (ES.5)** |
| **SR-40** | **[S-A: A-04]**; **[S-E: TS-8]** | Refusal log with a published annual count | Neutrality | **BUILD REQUIRED** | SR-25 | **A non-zero count where approaches occur** | National Legal | P0-G | BLOCKER C / Tier 0 | Build |
| **SR-41** | **[S-A: A-15 M1]**; LM-3 | Decision register operating | Governance | **BUILD REQUIRED** | SR-01 | **≥1 record with reason, decider, date** | National Operations | P0-A | BLOCKER C / Tier 0 | Build |
| **SR-42** | **[S-D: L-21; LDR-19]** | MVLS-1…MVLS-12 adopted | Leadership | **IMPLEMENTATION REQUIRED** | SR-07 | Adoption record | CEO | **P0-A, P0-E** | BLOCKER A / Tier 0 | Adopt |
| **SR-43** | **[S-D: L-08]**; LM-1 | SS state recorded for every covered role | Leadership | **BUILD REQUIRED** | SR-42 | **The SS register** | Team Leader + HR | P0-E | BLOCKER C / Tier 0 | Build |
| **SR-44** | **[S-D: L-16, CT-B]**; LM-2 | Playbook per covered role, exercised by a non-holder | Leadership | **BUILD REQUIRED** | SR-43 | **An exercise record** | The role-holder | P0-E | Tier 1 | Write and exercise |
| **SR-45** | **[S-D: L-01]** | Gate E criteria published | Leadership | **BUILD REQUIRED** | SR-42 | The published criteria | HR | P0-E | Tier 1 | Publish |
| **SR-46** | **[S-D: Rule D-45, ES.5]** | **Gate R out-of-team assessment capability** | Leadership | **BLOCK — not closable at one team** | A second team or a City assessor | **The recorded gap** | Appointing authority | P0-E | **Tier 4 — the [S-D] pivot** | **Record the gap; plan no promotion during the pilot** |
| **SR-47** | **[S-D: L-10]**; LM-5 | Temporary-leadership instruments with automatic expiry | Leadership | **BUILD REQUIRED** | SR-42 | The templates | HR | P0-E | Tier 1 | Build |
| **SR-48** | **[S-D: L-23]**; LM-9 | Complaint, appeal, improvement and removal routes | Leadership | **BUILD REQUIRED** | SR-24, SR-38 | The routes, published | HR + Audit | P0-E | Tier 1 | Build |
| **SR-49** | **[S-E: E-29, E-46]** | Claim ladder, claim classes and evidence labels adopted | Communication | **IMPLEMENTATION REQUIRED** | SR-35 | The adopted ladder; the claim register | Communications + Audit | P0-G | Tier 0 | Adopt |
| **SR-50** | **N-E-21**; **[S-ST: §20.2]** | Category sentence | Communication | **EXPLICITLY UNRESOLVED — `NOT ADOPTED, draft only`** | **CI-2 measured first** | Comprehension evidence | Communications | P0-G | **Tier 2 — measure before adopting** | Test, then decide |
| **SR-51** | **[S-ST: §18.3]** | "What we are not" list approved | Communication | **BUILD REQUIRED** | SR-35 | The approved list | Communications + Legal | P0-G | Tier 0 | Approve |
| **SR-52** | **[S-C: H-25]**; **[S-E: Rule E-66]** | Terminology register and the mandatory translation set | Language | **BUILD REQUIRED** | V-16, legal review per language | **The four mandatory items in the operating language** | Communications + Legal | **P0-D** | BLOCKER C / Tier 0 | Build |
| **SR-53** | **[S-E: §14.5]** | LA-5 emergency text pre-positioned, including voice form | Language | **BUILD REQUIRED** | SR-52 | **The pre-positioned text** | Communications + Safety | P0-D | **BLOCKER C / Tier 0 — no time to translate during an emergency** | Pre-position |
| **SR-54** | **[S-E: E-14]**; AX-T1 | Human accessibility route for every process | Accessibility | **BUILD REQUIRED** | SR-37 | **AX-T1 passes** | Team + Communications | P0-D | Tier 0 | Build |
| **SR-55** | **[S-E: E-34]**; CI-14 | Beneficiary dignity and consent rules operating | Safeguarding | **IMPLEMENTATION REQUIRED** | SR-31, SR-33 | **Zero beneficiary images; consent complete** | Editor + privacy officer | P0-D | Tier 0 | Implement |
| **SR-56** | **[S-C: H-06]**; PS-E4 | Paired first task with the scripted "nothing further is expected" | Human | **BUILD REQUIRED** | SR-37 | **HM-5, HM-7, HM-9** | The team | P0-D | Tier 1 | Build |
| **SR-57** | **[S-C: H-17]**; **[S-E: Rule E-165]** | Refusal scripts and exit route published in the operating language | Human | **BUILD REQUIRED** | SR-52 | **The published script** | HR + Communications | P0-D | Tier 0 | Publish |
| **SR-58** | **[S-B: B-20]** | Minimum viable control set MVC-1…MVC-11 | Economic | **IMPLEMENTATION REQUIRED** | SR-01 | The adopted set | Finance + Audit | P0-C | Tier 0 | Adopt |
| **SR-59** | **[S-B: B-04, B-05, B-13]** | Float, accrued-compensation ledger, collection terms | Economic | **BUILD REQUIRED** | SR-03 | Ledger; terms | Finance | P0-C | BLOCKER D / Tier 0 | Build and fund |
| **SR-60** | **[S-B: B-08]** | Volunteer true-cost accounting | Economic | **MEASUREMENT REQUIRED** | SR-41 | **P-08** | Finance + HR | — | Tier 2 | Measure |
| **SR-61** | **[S-B: B-26]** | Hybrid funding map | Economic | **DECISION REQUIRED** | SR-01, V-04 | The map | CEO + Finance | P0-J | **Tier 0 — the pilot's funding source must be stated** | Decide and record |
| **SR-62** | **[S-B: §40]**; **PD-1** | **All 60 measurements with recorder, verifier, form and threshold status** | Measurement | **BUILD REQUIRED** | All of the above | **The signed measurement plan, including P-15** | City owner + Audit | **P0-I** | **BLOCKER C / Tier 0** | Build — **and thin it (Rule F-22)** |
| **SR-63** | Rule F-22 | **Measurement-thinning statement** | Measurement | **BUILD REQUIRED — absent from all five prior instruments** | SR-62, `H_gov` declaration | **Which of the 60 are continuous, per event, per period or deferred, with reasons** | CEO + City owner | P0-I, P0-J | **Tier 0** | Produce |
| **SR-64** | **[S-E: Rule E-168]** | Communication hours costed into `H_gov` | Economic | **MEASUREMENT REQUIRED — a gap in v1.3-B** | SR-62 | **P-01 with communication lines** | Finance + Communications | P0-J | **Tier 0** | Measure from day one |
| **SR-65** | **[S-A: A-16]**; LM-15 | The four annual institutional tests | Governance | **DEFERRED — requires a year** | SR-41 | Published counts | Audit → Council | — | Tier 3 | Start recording now; report annually |
| **SR-66** | **[S-A: A-13, A-14]**; A-N21, A-N22 | Mission lock and Tier-1 amendment process | Governance | **DEFERRED — important before scaling** | SR-08 | The instrument | Founder/CEO + Council | — | Tier 3 | Draft now; execute before scaling |
| **SR-67** | **[S-A: A-15 M2…M7]** | Memory instruments, standards library, change-request route | Governance | **BUILD REQUIRED** | SR-41 | Versioned library; change requests | National Operations + Editor | — | Tier 1 | Build M1–M5; defer M6–M7 |
| **SR-68** | **[S-A: A-21, A-22]**; A-N36, A-N37 | AI risk tiers, review caps, auditability field set | Technology | **DEFERRED — no AI in the pilot** | — | — | AI & Data + Audit | — | **Tier 4 — but [S-A: A-I8]: fields cannot be retro-fitted** | Specify the field set now; deploy nothing |
| **SR-69** | **[S-D: L-18]** | Anti-gaming register and Goodhart Prohibition List | Performance | **IMPLEMENTATION REQUIRED** | SR-62 | The adopted list | Audit | — | Tier 1 | Adopt |
| **SR-70** | **[S-D: L-19]**; **[S-C: H-19]**; **[S-E: E-35]** | Anti-cult controls in leadership and communication | Governance | **IMPLEMENTATION REQUIRED** | SR-35 | Artefact audit | Communications + Audit | P0-G | Tier 0 | Implement |
| **SR-71** | **[S-C: H-21]**; **[S-D: Rule D-118]**; **[S-E: Rule E-135]** | Anti-MLM compensation firewall and referral prohibition | Economic | **IMPLEMENTATION REQUIRED** | SR-02 | **Formula audit showing no participation-linked term** | Finance + Audit | — | Tier 0 | Audit every formula before the first payment |
| **SR-72** | **[S-C: H-22]**; **[S-E: Rule E-13]** | Beneficiary/recruitment separation — no pathway exists | Human | **IMPLEMENTATION REQUIRED** | SR-37 | **PF-E3 clear** | Team + HR | P0-D | **Tier 0 — a fatal condition if breached** | Implement and train |
| **SR-73** | **[S-E: E-19]**; TS-1…TS-14 | Public trust signals | Reputation | **DEFERRED by stage** | SR-39, SR-01 | Stage-required subset only | Finance + Audit + Communications | P0-G | **Tier 1 for TS-1, TS-2, TS-6, TS-11; Tier 3 for the full set** | Publish the four now |
| **SR-74** | **[S-E: E-22]**; CC-1…CC-8 | Crisis communication protocol | Communication | **BUILD REQUIRED** | SR-35 | The protocol; a rehearsal | Communications + Safety + Legal | P0-G | Tier 1 | Build and rehearse CC-1, CC-3, CC-8 |
| **SR-75** | **[S: Ch.24]**; **[S-A: A-16 §15.4]** | **Authorised spokespersons designated by domain and region — more than one** | Communication | **BUILD REQUIRED** | SR-35 | **CI-13 — a count of one is a finding** | National Communications | P0-G | Tier 1 | Designate |
| **SR-76** | **[S-A: A-14 §13.4]**; **[S-E: Rule E-188]** | Dual custody of every credential, channel, domain and gateway | Technology | **BUILD REQUIRED** | SR-03 | The custody register | Operations + Finance | P0-H | Tier 1 | Build — **no personal account is an official channel** |
| **SR-77** | BLK-F-01; **[S-B: §40]** | **No technology procured for the pilot** | Technology | **IMPLEMENTATION REQUIRED — as a scope decision** | — | **The recorded scope decision** | CEO | — | **Tier 0 — as a prohibition** | Record it, so a platform proposal is refused on evidence |
| **SR-78** | **[S-E: Rule E-60]**; N-E-15 | No national branding below CL-7 with A-N12/A-N13 unresolved | Brand | **BLOCK** | SR-12, SR-13 | — | CEO | GATE E7 | **Tier 4 — as a standing prohibition** | Record the prohibition |
| **SR-79** | **[S-D: L-22]**; XG-1…XG-8 | Expansion gate adopted | Governance | **IMPLEMENTATION REQUIRED** | SR-42 | The adopted gate | CEO + National | — | Tier 1 | Adopt |
| **SR-80** | **[S-E: GATE E0…E7]** | Identity expansion gates adopted | Communication | **IMPLEMENTATION REQUIRED** | SR-49 | The adopted gates | CEO + Communications | — | Tier 1 | Adopt |
| **SR-81** | **[S-E: Rule E-218]** | PAUSE publication rule adopted | Governance | **IMPLEMENTATION REQUIRED** | SR-39 | The rule | CEO | — | Tier 1 | Adopt |
| **SR-82** | **[S-B: B-24]** | Service continuity instrument for open commitments | Service | **BUILD REQUIRED** | SR-37 | The instrument | Team + City | — | Tier 1 | Build |
| **SR-83** | **[S-B: B-09]**; HM-11 | Paid/voluntary boundary published | Economic | **BUILD REQUIRED** | SR-02, SR-52 | **The published boundary** | Communications + Finance | P0-D | Tier 0 | Publish |
| **SR-84** | **[S-E: Rule E-120]**; MC-6 | No earnings claim without a local funded reality | Communication | **IMPLEMENTATION REQUIRED** | SR-83 | Artefact audit | Communications | P0-G | Tier 0 | Implement |
| **SR-85** | **[S-E: Rule E-148]**; A-19 | No beneficiary image, name or circumstance published | Communication | **IMPLEMENTATION REQUIRED** | SR-55 | **CI-14 at 100%** | Editor | P0-G | **Tier 0 — irreversible if breached** | Implement |
| **SR-86** | **[S-A: A-05]**; **[S-E: E-07]** | Religious neutrality in expression | Neutrality | **IMPLEMENTATION REQUIRED** | SR-35 | Artefact audit | Communications | P0-B | Tier 0 | Implement |
| **SR-87** | **[S-E: E-08]**; CN-1…CN-6 | Caste neutrality — behavioural pattern review only | Neutrality | **IMPLEMENTATION REQUIRED** | SR-18 | Pattern reviews | City + Audit | — | Tier 2 | Implement behaviourally; **collect no identity data** |
| **SR-88** | **[S-E: E-42]**; Rule E-203 | Hero-language prohibition and vocabulary register | Communication | **IMPLEMENTATION REQUIRED** | SR-52 | Vocabulary audit | Communications | P0-G | Tier 0 | Implement |
| **SR-89** | **[S-E: Rule E-144]** | No national day, no eponymous artefact, no ceremony set | Culture | **IMPLEMENTATION REQUIRED — as refusals** | — | The recorded refusals | CEO | — | **Tier 0 — refusals cost nothing** | Record |
| **SR-90** | **[S-E: Rule E-61]** | Colour reservation — the nine information colours may not be identity colours | Brand | **IMPLEMENTATION REQUIRED — as a refusal** | — | The recorded rule | Communications | — | **Tier 0 — adoptable now without resolving A-N12** | Record |
| **SR-91** | Part IX; Rule F-17 | Threshold schedule — every threshold from source or marked | Measurement | **BUILD REQUIRED** | SR-62 | **The schedule** | Audit | P0-I | Tier 0 | Build — **invent nothing** |
| **SR-92** | **[S-D: Rule D-132]**; **[S-E: Rule E-223]** | Pilot scope statement — the seven limits | Measurement | **BUILD REQUIRED** | SR-62 | **The published statement** | CEO | P0-I | Tier 0 | Publish before the pilot starts |
| **SR-93** | Part XX | Exit-gate conditions X-1…X-11 adopted | Governance | **IMPLEMENTATION REQUIRED** | SR-62 | The adopted conditions | CEO + Audit | — | Tier 0 | Adopt before commencement |
| **SR-94** | Part XXI; Rule F-33 | Transition gates and the named-constraint rule adopted | Governance | **IMPLEMENTATION REQUIRED** | SR-79, SR-80 | The adopted gates | CEO | — | Tier 1 | Adopt |
| **SR-95** | **A-N38** | Amendment adoption sequencing | Governance | **DECISION REQUIRED — "Immediately"** | — | The adopted sequence | CEO + Council | — | **Tier 0 — do this first** | Adopt the three-stage sequence |
| **SR-96** | Part II | **164 amendment approvals** | Governance | **COMPLETE — NOT YET PROVEN** (all are `PROPOSED`) | SR-95 | Approval records | CEO + Council per item | — | **Tier 0–4 per Annexure J waves W1–W4 and [S-E: §63.4]** | Approve W1 first |
| **SR-97** | Part XVII | **40 contradictions — none closed** | Governance | **EXPLICITLY UNRESOLVED** | SR-08 | — | Per item | — | **Tier 3 — but they bound the claim now (Rule F-29)** | Record the claim limits |
| **SR-98** | Part III | **11 pre-pilot validations across 8 professional categories** | Legal | **VALIDATION REQUIRED** | SR-01 | **Written opinions held as governance evidence** | Per category | **P0-B** | **BLOCKER B / Tier 0** | Commission as one engagement where possible |
| **SR-99** | Part XV | Failure register MF-01…MF-28 with pause and terminate triggers | Governance | **IMPLEMENTATION REQUIRED** | SR-35 | The adopted register | CEO + Audit | — | Tier 0 | Adopt |
| **SR-100** | Part XVIII; Rule F-30 | **No-false-readiness discipline — documentation is not operation** | Governance | **IMPLEMENTATION REQUIRED — permanently** | All | **GATE P0 passing on evidence, not on documents** | CEO + Audit | **P0** | **Tier 0 — and it never expires** | Apply at every gate |

## XXII.3 Register statistics

| Status | Count |
|---|---|
| **DECISION REQUIRED** | 12 |
| **EXPLICITLY UNRESOLVED** | 16 |
| **VALIDATION REQUIRED** | 5 (representing **11 pre-pilot validations** at SR-98) |
| **BUILD REQUIRED** | 27 |
| **IMPLEMENTATION REQUIRED** | 22 |
| **MEASUREMENT REQUIRED** | 5 |
| **DEFERRED** | 4 |
| **BLOCK** | 2 |
| **COMPLETE — NOT YET PROVEN** | 1 (SR-96, representing all 164 amendments) |
| **PASS** | **0** |
| **MODIFY** | 0 |
| **EVIDENCE REVIEW REQUIRED** | 0 |
| **TOTAL** | **100 canonical items, representing 164 amendments, 77 validations, 30 unresolved decisions, 60 measurements and 40 contradictions** |

**[A] The zero in the PASS row is the verdict of this register in one cell.**

---

# PART XXIII — PRIORITY TIERS

## XXIII.1 TIER 0 — MUST RESOLVE BEFORE ANY PILOT

**[P]** Twenty-two items. **The reasoning for each is stated, as the brief requires.**

| # | Item | SR | **Reasoning** |
|---|---|---|---|
| 1 | **Legal entity structure** | SR-01 | **Root of eleven of the twenty-eight dependency chains.** Without a legal person there is no payer, no employer, no contracting party, no data fiduciary, no insured and no bank account. Everything economic and legal is downstream |
| 2 | **Worker classification** | SR-02 | Priority 1 is worker compensation and **[S-D: INV-2]** makes it non-suspendable. **An obligation the organisation cannot lawfully discharge is not a policy, it is an exposure** |
| 3 | **Bank mandate and two signatories** | SR-03 | **A-B9.** Independent of scale, and the only control that lets priority 1 survive an apex vacancy |
| 4 | **Written insurance and liability answers (A-10 L1–L15)** | SR-04 | **A-B2.** An uninsured injury is irreversible harm; **[S-A: §23.1]**'s BLOCKER test is precisely "failure causes harm that cannot be reversed" |
| 5 | **Data fiduciary and named privacy officer** | SR-05 | **A-B7.** Duties attach with no accountable person; **[X]** DPDP notification windows cannot be met by nobody |
| 6 | **Retention and erasure schedule** | SR-06 | **A-N26.** Collection without a retention rule is over-retention from day one, and the corpus deliberately did not invent periods |
| 7 | **`n_min` for the pilot team** | SR-07 | A unit cannot be authorised without knowing the minimum people needed for the four capabilities **[S-D: Rule D-33]** will not permit to be routed |
| 8 | **Political Neutrality Code adopted** | SR-25 | **A-B4**, required "before the first public activity". MC-1 is rated **Severe** and tax-exempt standing may depend on it **[X][V]** |
| 9 | **Public Protection Statement published** | SR-26 | **A-B5.** The word "protection" imports the most dangerous category; **[S-ST: §20.2]** removes it from first contact, which makes the published boundary the only place it is stated |
| 10 | **DO-NOT list entrenched** | SR-27 | **A-B5.** Local interpretation authority over the list is the mechanism by which a service organisation becomes an enforcement one |
| 11 | **Protection Visibility Protocol V1…V43 adopted** | SR-28 | **A-N6.** A single image creates the perception. **PD-8: all 43, including V10's crowd-event banner prohibition and the V42–V43 incident fields** |
| 12 | **Incident protocol matrix and Activation Gate** | SR-29, SR-30 | **A-N9, A-B8.** Otherwise capability activates as a side-effect of filling a vacancy |
| 13 | **Certified safeguarding** | SR-31 | **A-B6.** Harm to a child is the least recoverable failure available |
| 14 | **Intervention-boundary counsel opinion** | SR-32 | **A-B3.** Members will face real incidents; the boundary must be known before, not constructed after |
| 15 | **Privacy minimum built and rehearsed** | SR-33, SR-34 | **A-B7.** A breach runbook rehearsed after the breach is not a runbook |
| 16 | **Comms policy** | SR-35 | **[S: Ch.31] launch blocker.** The source itself makes this a condition of launch |
| 17 | **Non-police ID card design approved** | SR-36 | **[S: Ch.31] launch blocker.** "Non-police" is a legal constraint, not an aesthetic one |
| 18 | **Public local record PLR-1…PL-7 built** | SR-37 | **[S-C: H-03]**; **[S-ST: §20.3]** — the artefact whose absence makes the first available action "apply for membership" |
| 19 | **Outward-reaching complaint route** | SR-38 | **[S-D: MVLS-9]**. Without it the only response to a local failure is exit |
| 20 | **Correction log and refusal log** | SR-39, SR-40 | **[S-E: ES.5]** and **[S-A: A-04]**. **These two logs are the entire evidence base for the organisation's central claim** |
| 21 | **Decision register operating; MVLS adopted; SS states recorded** | SR-41, SR-42, SR-43 | A decision with no reason cannot be appealed or learned from; a role with no succession state is a single point of failure |
| 22 | **Measurement plan signed, thinned, with the threshold schedule and the pilot scope statement** | SR-62, SR-63, SR-91, SR-92 | **60 measurements is an uncosted workload (Rule F-22), and a pilot that attempts all of them continuously will either fail to deliver service or fail to record honestly** |

**Plus four prohibitions that cost nothing and are Tier 0 because they are refusals:** **SR-77** no technology procured · **SR-78** no national branding · **SR-89** no national day, eponymous artefact or ceremony · **SR-90** colour reservation. **And SR-95, the amendment sequencing decision, which [S-A: A-N38] marks "Immediately" and which must precede SR-96's 164 approvals.**

## XXIII.2 TIER 1 — MUST COMPLETE BEFORE PILOT

| Item | SR | Reasoning |
|---|---|---|
| Interim reserved-matter procedure | SR-08 | Permits the pilot to operate while **LDR-U01** stays unresolved |
| Apex succession instruments and Interim Authority Order | SR-10 | **[S-A: A-N17]**: "preferably before the first hire" |
| Reserved-matters list | SR-11 | Defines what no interim authority may do |
| Name availability search | SR-14 | Cheap now, irreversible if lost |
| Serious-misconduct procedure | SR-24 | An allegation may arrive at any time and the response itself becomes the liability |
| Founder-compensation position recorded | SR-20 | The published accounts must state it, even if it is nil |
| Hybrid funding map | SR-61 | The pilot's funding source must be stated before money is spent |
| Playbooks written and exercised | SR-44 | **An unexercised playbook counts as absent ([S-D: Rule D-122])** |
| Gate E criteria; temporary instruments; complaint and appeal routes | SR-45, SR-47, SR-48 | MVLS dependencies |
| Claim ladder, claim classes, evidence labels, "what we are not" list | SR-49, SR-51 | Rule E-8: an untraceable claim may not be published however true |
| Terminology register and mandatory translation set | SR-52 | Language is a hard exclusion, not a friction |
| LA-5 emergency text pre-positioned | SR-53 | There is no time to translate during an emergency |
| Human accessibility route | SR-54 | Rule E-72: every process needs a human route |
| Beneficiary dignity and consent rules | SR-55, SR-85 | Irreversible if breached |
| Paired first task | SR-56 | The first win is the only growth mechanism that is not capacity-limited |
| Refusal scripts and exit route published | SR-57 | A right that cannot be exercised politely is not a right |
| Minimum viable control set | SR-58 | The controls that may not be deferred |
| Float, ledger, collection terms | SR-59 | **BLK-D — the pilot cannot run unfunded** |
| Communication hours costed into `H_gov` | SR-64 | **The gap in v1.3-B; Rule E-169's test needs the data from day one** |
| Memory instruments M1–M5 | SR-67 | Decision reasons must be captured while the deciders are present |
| Anti-gaming register; anti-cult controls; anti-MLM formula audit | SR-69, SR-70, SR-71 | **Audit every formula before the first payment** |
| Beneficiary/recruitment separation | SR-72 | **A fatal pilot condition if breached** |
| Crisis protocol; spokesperson designations; dual custody | SR-74, SR-75, SR-76 | A crisis is when procedure is most needed and most likely to be abandoned |
| Paid/voluntary boundary published; no earnings claims | SR-83, SR-84 | MC-6 is rated **High** and causes material harm |
| Religious neutrality in expression; hero-language prohibition | SR-86, SR-88 | Artefact-level controls, cheap and irreversible if absent |
| Exit conditions and failure register adopted | SR-93, SR-99 | Adopted before commencement, or they are negotiated after failure |
| **W1 amendments approved** | SR-96 | **[S-E: §63.4]**: E-01…E-04, E-14…E-18, E-23, E-34, E-35, E-42, E-46 |

## XXIII.3 TIER 2 — MUST TEST DURING PILOT

**SR-15 `m_lead` · SR-21 economic blueprint · SR-22 percentages · SR-23 `c`, divisor, `K_min` · SR-50 category sentence · SR-60 volunteer true cost · SR-87 caste pattern review** — plus **BLK-E-01…BLK-E-18** in full: every numeric value, every cohort instrument, the whole human journey, first contact, claim traceability, correction performance, language match, attribution compliance, unaffiliated repeat use, venture economics, mission balance, and **whether the organisation will actually publish a correction**.

**Reasoning:** each is a value or a behaviour that can only be observed, and designing it now would be guesswork — **[S-A: §23.5 A-L1]**: "the source deliberately does not invent numbers; pilot evidence should set them."

## XXIII.4 TIER 3 — MUST REVIEW AFTER PILOT

**SR-09 apex dispute resolution · SR-12 brand ownership · SR-13 IP ownership · SR-17 leaderboard publicity · SR-19 reserve custody · SR-24 transition rules and readiness threshold · SR-65 four annual tests · SR-66 mission lock · SR-73 full TS set · SR-97 the forty contradictions** — plus **[S-A: A-I1…I11]** and the **W2/W3 amendment waves**.

**Reasoning:** each either requires scale to be meaningful, or requires the pilot's evidence to be designed correctly, or is important-before-scaling in **[S-A]**'s own taxonomy. **Exception recorded: SR-12 brand ownership is Tier 3 for national use and Tier 1 for the first public artefact bearing the name (Rule F-13).**

## XXIII.5 TIER 4 — FUTURE SCALE REQUIREMENT

**SR-18 composition monitoring · SR-46 out-of-team assessment capability · SR-68 AI tiers and field set · SR-78 national branding** — plus **BLK-F-01…BLK-F-16**: the platform, dashboards, leaderboard, mark and palette, badges and ceremonies, the State layer, contribution portability, the full-scope continuity test, oral history, the public archive, external independent reviews, the DPIA programme.

**Reasoning:** **[S-A: §23.1]** is explicit that software completeness, badges, ceremonies, the state layer, the leaderboard, national branding and the full 14-module platform are **not** blockers. **SR-46 is Tier 4 and is also the most important item in Tier 4: it is [S-D: §52.3 step 5], the single event that moves the leadership grade from D to B.**

---

# PART XXIV — DECISION OWNERSHIP AUDIT

## XXIV.1 Where authority is defined

| Decision class | **Defined authority** | Source |
|---|---|---|
| Role promotion | **Team Leader + HR**, co-review by the City/State owner | **[S: App. E]** |
| Suspension | **HR / Safety / Leader** | **[S: App. E]** |
| Serious-misconduct removal | **Governance / HR panel** | **[S: App. E]** |
| Leaderboard finalisation | **Performance / Audit** | **[S: App. E]** |
| Leadership transfer | **CEO / governance process** | **[S: App. E]** |
| Platform permission change | **Technology admin** | **[S: App. E]** |
| Approval level generally | **Risk, money, data sensitivity, safety and public impact determine the level** | **[S: App. E]** |
| Partnership approval | **By amount / risk / data / brand impact** — signatory authority `Not final` | **[S: App. E; S: Ch.33]** |
| Audit | **Review only; not operational commander** | **[S: Ch.23; S-D: INV-15]** |
| Public statements | **Authorised spokespersons only; national or relevant approval for sensitive matters** | **[S: Ch.24]** |
| Sensitive incident statements | **Safety + Legal + Communications approval** | **[S: Ch.24]** |
| Content rejection | **Editor function** | **[S: App. A §8.x]** |
| Corrections | **Anyone who finds the error; ratification afterwards** | **[S-E: Rule E-186]** |
| Reserved matters | **Not delegable to any interim or acting authority** | **[S-A: A-14 §13.3]** |
| Ownership | **Krytos under the founder/CEO — property, brand, strategy, ultimate control** | **[S: Ch.4; Const. Art.3]** |

## XXIV.2 Where authority is ambiguous

| Ambiguity | Competing readings | Consequence |
|---|---|---|
| **CEO versus National Council** | **[S: Ch.4, Ch.5]** give the CEO executive authority and ownership; **[S: Ch.5]** contemplates a Council; **[S-A: A-N19]** is `PROPOSED`; **[S-D: LDR-U12]** leaves the charter `PROPOSED` | **Every reserved matter, every appeal, every national claim approval and every expansion authorisation has two possible deciders** |
| **Who approves a national claim** | Communications owns "public narrative" **[S: Ch.5]**; the claim register requires national approval **[S-E: E-29]**; but "national" authority is the unresolved question | A CL-n claim could be approved by a body with no determined standing |
| **Who appoints a permanent CEO** | A reserved matter **[S-A: A-14 §13.3]** — so not the CEO, and not an interim authority | **C-D-17: the CEO cannot appoint the CEO, and nobody else is determined** |
| **Who decides brand use locally** | **A-N12 `UNRESOLVED`** — teams hold no documented right to the name | **[S-E: BR-9]** interim recorded permission is the only available mechanism, and its grantor is undetermined |
| **Who sets thresholds and weights** | Source marks them `PROPOSED` / `NOT FINAL` without naming an approver beyond "founder/CEO with the relevant national function" | A scored decision could rest on weights nobody authorised |
| **Who decides founder compensation** | The founder is the beneficiary; **[S-D: Rule D-92]** requires recusal; **LDR-U16** is `UNRESOLVED` | **A decision with no disinterested decider** |
| **Who authorises expansion** | XG-1…XG-8 and GATE E0…E7 specify conditions but the authorising body is the unresolved apex | Expansion could be authorised by whoever proposes it |

## XXIV.3 Where authority conflicts

| Conflict | Source A | Source B | Resolution status |
|---|---|---|---|
| **C-D-17** Permanent-CEO appointment | Reserved matter **[S-A: A-14 §13.3]** | "Leadership transfer: CEO / governance process" **[S: App. E]** | **UNRESOLVED — refused by [S-D]** |
| **C-D-18** Leaderboard finalisation | Auditor is "review only; not operational commander" **[S: Ch.23]** | Leaderboard finalisation is "Performance / Audit" **[S: App. E]** | **Partly resolved by [S-D: INV-15]; LDR-U11 leaves the leaderboard open** |
| **C-D-11** Removal authority | A Team Leader "cannot … punish people" **[S: Ch.9]** | Leadership failure leads to "replacement / dynamic succession" **[S: Ch.14]** | **Resolved by reading: a panel acts, not a line manager [S-D: RM-1…RM-10]** |
| **C-D-06** Four finance hands | Segregation is APPROVED **[S: Ch.18]** | A State A team may have fewer than four holders **[S-B: §3.3]** | **Resolved by routing, never by merging (Rule D-33)** |
| **E-C-15** Brand ownership versus anti-personality rules | **[S: Ch.4]** brand is owned personally | **[S-A: A-16 §15.4]** the public face must be many people | **UNRESOLVED — structural; carried** |

## XXIV.4 Where AI is incorrectly positioned as decision-maker

**[A]** **Nowhere.** The corpus is consistent and unusually firm:

| Instrument | Position |
|---|---|
| **[S: Const. Art.12, APPROVED]** | "AI recommends, humans decide; AI cannot autonomously make consequential HR, wage, legal, safeguarding, safety, major fund or leadership decisions" |
| **[S-A: A-21]** | Risk tiers and review caps; a language guard |
| **[S-A: A-22]** | Append-only field set — prompt, output, model, sources, user, **reviewer**, final decision |
| **[S-D: L-26, AI-1…AI-8]** | Permitted and prohibited function table; the stranger test for explainability; **historical bias never used as prediction labels (Rule D-107 `UNVALIDATED`)** |
| **[S-E: Rule E-68]** | Machine translation never publishes; named human review mandatory for LA-1, LA-3-legal and LA-5 |
| **[S-E: Rule E-133]** | AI may not manipulate citizens, target vulnerable groups for persuasion, impersonate people, fabricate testimonials, run political persuasion or make final reputation decisions |

**[P] Rule F-34 (The One Residual AI Risk Is Not Positioning, It Is Volume).** **[S-A: A-21]**'s own concern — recorded at **A-N36** — is that "review fatigue voids the human-decides doctrine." **AI is correctly positioned as advisory throughout; the failure mode is that a human reviewer approving at volume stops reviewing.** Detection is the published approval rate; control is the review cap. **Neither exists yet, and neither is needed until AI is deployed — which the pilot does not do.**

## XXIV.5 Where human authority is required and cannot be delegated

| Decision | Why it cannot be delegated |
|---|---|
| **Any consequential HR, wage, legal, safeguarding, safety, major-fund or leadership decision** | **[S: Const. Art.12]** — APPROVED architecture |
| **Publication of an LA-1, LA-3-legal or LA-5 text** | **[S-E: Rule E-68]** — a translated rights or safety text *is* a consequential decision |
| **A claim above CL-1** | **[S-E: E-29]** — requires national approval and a claim-register entry |
| **A reserved matter** | **[S-A: A-14 §13.3]** — not delegable to any interim authority |
| **Stop-work** | **[S-D: Rule D-33]** — a named human, present, at all times |
| **Removal for cause** | **[S: App. E]** — a Governance/HR panel; **[S-D: Rule D-60]** no score or public pressure removes anyone |
| **Whether to publish a correction** | **Nobody may decide *not* to. [S-E: Rule E-186] makes correction approval-free, and Rule E-88 makes an empty log an anomaly. This is the only decision in the corpus where the correct answer is that no decision is required** |

---

# PART XXV — FINAL READINESS VERDICT

## XXV.1 The verdict

> # **C — PILOT NOT READY, BUT THE PATH IS FINITE**

| Grade | Meaning | Applies? |
|---|---|---|
| **A — PILOT READY** | GATE P0 passes on evidence; all ten packages signable | **NO — zero of ten packages are signable; 88 artefacts required, 13 resting on `UNRESOLVED` decisions** |
| **B — PILOT READY WITH MATERIAL CONDITIONS** | The only gaps are conditions attachable to an authorisation — scope limits, recorded waivers, staged obligations | **NO. A condition can limit *scope*; it cannot supply a legal person, a bank mandate, an insurance answer or a certified safeguarding capability. Four of the nine [S-A] BLOCKERS are of that kind** |
| **C — PILOT NOT READY BUT PATH IS FINITE** | Readiness is blocked by an enumerable, owned, sequenced set of decisions, validations and builds, none requiring new theory | **YES** |
| **D — PILOT NOT YET DEFINABLE** | The pilot itself is undefined | **NO — and this is why C rather than D. The pilot is precisely defined: [S-B: §40] one mohalla team, no technology; 60 measurements with methods, recorders and verifiers; success and failure conditions from four instruments; a scope statement with fourteen limits. What is undefined is the organisation's legal ability to run it** |

## XXV.2 Why

**[A]** Five reasons, each traceable:

1. **The organisation has no legal person.** LDR-U08 is `UNRESOLVED`; **A-B1** is a BLOCKER on **[S-A]**'s own test — "the capability either cannot lawfully or ethically operate." Eleven of twenty-eight dependency chains root here.
2. **Its first and most absolute financial obligation cannot lawfully be discharged.** Priority 1 is worker compensation, **[S-D: INV-2]** makes it non-suspendable, and it requires an entity (SR-01), a classification (SR-02) and a bank mandate (SR-03) — all three unresolved or unbuilt.
3. **Two of v1.2's own launch blockers are undelivered.** **[S: Ch.31]** requires a comms policy and an approved non-police ID card design. Neither exists. **This is not a v1.3 finding; the source architecture already classed both as `Blocker`.**
4. **Nine professional validations across eight categories have not been commissioned.** Insurance answers (**A-N10**) are recorded in the source as "questions posed, not answered." Certified safeguarding (**A-B6**) is a precondition of any activity with a minor.
5. **Nothing is at State 2.** All 164 amendments are `PROPOSED`; no mechanism has a named owner performing it and producing a record under an audit method. **Part XVIII's finding: this register is itself a State 1 artefact about State 1 artefacts.**

## XXV.3 What prevents a higher verdict

| To reach **B** | What must change |
|---|---|
| The four law-dependent BLOCKERS must close | **A-B1** entity, classification and tax; **A-B2** insurance answers; **A-B3** intervention boundary; **A-B6** certified safeguarding. **These are not conditions; they are preconditions, because each concerns lawfulness or irreversible harm** |
| The two v1.2 blockers must be delivered | Comms policy; approved non-police ID card design |
| The privacy minimum must exist | Classification, **retention schedule with counsel-set periods**, notice, rehearsed breach runbook, named officer |
| Funding must be identified | **B-26** hybrid funding map — the corpus does not say where the pilot's money comes from, and this register does not invent it |

**[A]** If those four groups closed tomorrow, the verdict would be **B — PILOT READY WITH MATERIAL CONDITIONS**, with the conditions being: no promotion during the pilot (SR-46 Gate R gap); no protection activity unless insured; no technology; no national claim above CL-1; no comparative artefact; no composition data; and the measurement set thinned per Rule F-22.

## XXV.4 The smallest number of critical actions that would improve the verdict

**[P]** **Five actions move C → B.** They are ordered, and each is a single act by a single owner:

| # | Action | Owner | Unblocks |
|---|---|---|---|
| **1** | **Produce the entity-structure decision paper and commission corporate, tax and labour counsel as one engagement** | Founder/CEO | **SR-01, SR-02, SR-03, SR-05, SR-06** — and therefore A-B1, A-B9, priority-1 payment, the fiduciary appointment, the retention schedule |
| **2** | **Commission the insurance broker for written answers to A-10 §9.1 L1–L15, and criminal/regulatory counsel on the intervention boundary** | National Legal + Finance + CEO | **SR-04, SR-32** — A-B2, A-B3, and the whole protection pillar |
| **3** | **Commission certified safeguarding** | Safety | **SR-31** — A-B6, and every activity involving a minor or vulnerable adult |
| **4** | **Write and approve the comms policy and the non-police ID card design** | Communications + Legal | **SR-35, SR-36** — the two **[S: Ch.31]** launch blockers, and P0-G |
| **5** | **Adopt A-N38 amendment sequencing, then approve the W1 amendment set and the Tier 0 prohibitions** | CEO + Council | **SR-95, SR-96, SR-77, SR-78, SR-89, SR-90** — and the whole build list becomes sequenced rather than simultaneous |

**[A]** Actions 1–3 are commissions and cost money. Actions 4–5 are authorship and approval and cost time. **Not one of the five requires new architecture, new theory, software, a brand, a second team or a national ambition.** That is what "the path is finite" means, and it is the entire basis of the C rather than D verdict.

## XXV.5 What remains genuinely unresolvable without authorised human decisions

| Item | Why no document can resolve it |
|---|---|
| **LDR-U01 CEO versus National Council** | **`AUTHORITY UNRESOLVED`** — the body that would decide is the subject of the decision. Only the owner under **[S: Ch.4]** can settle it, and settling it may reduce the owner's own authority |
| **LDR-U19 successor to the founder** | No instrument may name a successor; and the naming authority is itself unresolved |
| **A-N19 apex dispute resolution** | Depends on LDR-U01 |
| **A-N12 / A-N13 brand and IP ownership** | A property question about the founder's own assets |
| **LDR-U16 founder compensation** | The decider is the beneficiary; **[S-D: Rule D-92]** recusal applies and there is no disinterested decider |
| **A-N5 composition monitoring** | `UNRESOLVED — deliberately`, because both answers carry a real cost |
| **LDR-U02 `m_lead`, LDR-U03 weights** | Marked `NOT FINAL` in the source; **and the weights are `PROPOSED`, so adopting them is a decision, not a measurement** |
| **C-D-01 does Art.15 move the people or the label?** | A constitutional interpretation reserved to the approving authority |
| **E-C-19 will the correction log be kept when keeping it is costly?** | **A property of persons, not of architecture. No document can supply the willingness** |

## XXV.6 What can be tested instead of debated

| Item | Test |
|---|---|
| Whether the category sentence works | **CI-2** — measure comprehension, then decide (SR-50) |
| Whether `H_gov` is affordable | **P-01, LM-12** |
| Whether `m_lead` is sustainable | **LM-13**, with the deficit recorded if unpaid |
| Whether people return | **HM-9** |
| Whether participation without membership is real | **CI-15** |
| Whether dignity survives contact | **HM-13** |
| Whether a first win works | **PS-E4, HM-5, HM-7** |
| Whether a playbook transfers | **CT-B** |
| Whether the accessibility route works | **AX-T1** |
| Whether the organisation publishes a correction | **CI-9** — **the most important test in the corpus** |
| Whether the City divisor is sub-linear | **P-15, P-12** — at a City, not before |
| Whether out-of-team assessment selects differently | **LM-1 with an out-of-team assessor** — at a second team |

## XXV.7 What cannot be tested safely and requires prior decision or validation

| Item | Why it cannot be tested |
|---|---|
| **Any protection or first-response activity** | **A-B2 insurance answers and A-B3 boundary opinion are preconditions. An injury during a test is not a test result** |
| **Any activity involving a minor or vulnerable adult** | **A-B6 certified safeguarding. Harm to a child is irreversible** |
| **Any payment to a worker** | **A-B1 entity and classification. An unlawful payment creates liability, not data** |
| **Any systematic personal-data collection** | **A-B7 privacy minimum, including a retention schedule. Over-retention is a breach from day one** |
| **Any public political-adjacent activity** | **A-B4 neutrality code. A misreading cannot be un-read** |
| **Any published claim** | **SR-49 claim ladder. A withdrawn claim does not restore the position** |
| **Any AI deployment** | **A-N36, A-N37 — and [S-A: A-I8]: audit fields cannot be retro-fitted onto past logs** |
| **Any national brand use** | **SR-12, SR-13, Rule E-60. A mark used without documented right may not be defensible** |

## XXV.8 The closing statement

**[A]** Six instruments, 3.8 million bytes, 164 amendments, roughly 400 numbered rules and instruments, 60 defined measurements, 77 validation items, 40 recorded contradictions and 30 unresolved decisions — **and not one of them has been performed by a person.**

**That is not a criticism of the corpus.** The corpus did what a corpus can do: it identified the failure modes before they occurred, refused to invent the numbers it could not know, preserved the questions it was not authorised to answer, and returned the same honest verdict five times. **Its completeness is genuine and its verdicts are correct.**

**The criticism belongs to what happens next.** A body of work this thorough creates a specific and unusual hazard: **it makes the organisation feel ready.** Six comprehensive documents, an approved constitution, a costed model, a human system, a leadership architecture and a national identity strategy are, to any reasonable reader, evidence of seriousness — and seriousness is routinely mistaken for readiness. **Part XVIII exists because that mistake is the most likely way this work is wasted.**

**The precise position is this:** the pilot is fully defined and could be described in a page. It cannot be *authorised*, because the organisation has no legal person, cannot lawfully pay the worker whose compensation is priority one, has no insurance answer, no certified safeguarding, no privacy notice, no comms policy, no ID card design, no public record, no complaint route, no correction log and no refusal log. **Thirteen of those are decisions or validations that one person can commission this month. Two are documents a competent person can write this month. The rest are sheets of paper.**

**And the finding that should be carried into every one of those acts:**

> **[A]** The architecture's central promise is that it can be checked. **Everything required to make that promise true is inexpensive, is made of paper, and is within one team's power.** Everything required to make it *believed* is one act — publishing what went wrong — which no document in six instruments can compel, which the incentive structure quietly discourages, and which **[S-E: ES.5]** correctly identifies as the largest unresolved weakness in the entire body of work.
>
> **If the pilot produces one published correction, the architecture is real. If it produces a year of clean reports, the architecture is paperwork.** GATE P0 can authorise the first outcome. It cannot guarantee it.

**Verdict: `C — PILOT NOT READY, BUT THE PATH IS FINITE`.**
**Next artifact: the entity-structure decision paper.**
**Nothing else should be built until it exists.**

---

# COMPLETENESS AUDIT

| Check | Result |
|---|---|
| **Every A amendment accounted for** | **YES — A-01…A-23, all 23, Part II §II.2** |
| **Every B amendment accounted for** | **YES — B-01…B-27, all 27, Part II §II.3** |
| **Every H amendment accounted for** | **YES — H-01…H-28, all 28, Part II §II.4** |
| **Every L amendment accounted for** | **YES — L-01…L-40, all 40, Part II §II.5** |
| **Every E amendment accounted for** | **YES — E-01…E-46, all 46, Part II §II.6. Total 164** |
| **Every validation requirement accounted for** | **YES — A-V1…A-V12 (12), HV-1…HV-10 (10), LV-1…LV-25 (25), LV-E-1…LV-E-30 (30) = 77 items, consolidated into 17 categories, Part III** |
| **Every unresolved decision accounted for** | **YES — A-N1…A-N38 (38: 9 `UNRESOLVED`, 29 `PROPOSED`), LDR-U01…U20 (20), LDR-01…20 (20 proposed), N-E-01…N-E-27 (27), de-duplicated to **30 `UNRESOLVED` + 65 `PROPOSED`**, Part IV** |
| **Every contradiction accounted for** | **YES — C-D-01…C-D-20 and E-C-01…E-C-20 = 40, Part XVII** |
| **Every pilot measurement accounted for** | **YES — P-01…P-15 (15, **PD-1 correction applied**), HM-1…HM-15 (15), LM-1…LM-15 (15), CI-1…CI-15 (15) = **60**, Part IX. Testability: 47 full, 8 partial, 7 not testable** |
| **Every known blocker accounted for** | **YES — A-B1…A-B9 (9 source BLOCKERS), A-H1…A-H13, A-I1…A-I11, A-L1…A-L7, the two **[S: Ch.31]** launch blockers, and BLK-A-01…13 / BLK-B-01…11 / BLK-C-01…11 / BLK-D-01…14 / BLK-E-01…18 / BLK-F-01…16, Part V** |
| **Every major dependency mapped** | **YES — 28 chains, exceeding the 25 the brief named, Part VI** |
| **No silent resolution of unresolved governance** | **VERIFIED — LDR-U01, A-N19, LDR-U19, LDR-U16 and C-D-08, C-D-17 are all recorded with `AUTHORITY UNRESOLVED` where the source leaves authority open. No authority is invented** |
| **No invented numbers** | **VERIFIED — the only numeric range reproduced is **[S-B: §25]**'s `H_gov` 8–40 h/team/month, presented as an observation window. No threshold, target, ratio, interval, span, density, multiplier or percentage is supplied** |
| **No invented legal conclusions** | **VERIFIED — every legal proposition is `[V]`, or `[X]` with its external source named (DPDP Act 2023 timelines and penalties; 12A / 80G / FCRA conditions; BNSS 2023 ss.31, 40, 43) and marked as requiring validation** |
| **No invented ownership** | **VERIFIED — A-N12 and A-N13 remain `UNRESOLVED`; BR-9 interim recorded permission is cited as **[S-E]**'s, not adopted as a resolution** |
| **No invented thresholds** | **VERIFIED — Rule F-17; SR-91 threshold schedule; every absent threshold reads `THRESHOLD REQUIRES FINAL APPROVAL`** |
| **No invented pilot success rates** | **VERIFIED — no conversion rate, adoption percentage, retention figure, participation rate or growth projection appears anywhere** |
| **No invented budgets** | **VERIFIED — no rupee value, salary, media spend, event cost, insurance premium, professional fee or funding amount is stated. Part V BLK-D and Part XIV list requirements and variables only** |
| **No invented membership targets** | **VERIFIED — **[S-E: Rule E-86]** and **[S-D: Rules D-37, D-88]** are carried; no target of any kind is set** |
| **No invented staffing requirements** | **VERIFIED — `n_min` (LDR-U06), `c` (LDR-U13), `K_min` (LDR-U15) and the City divisor (LDR-U14) all remain unresolved or measurement-required; no span-of-control number exists in the corpus and none is supplied** |
| **No new architecture proposed** | **VERIFIED — this instrument proposes no amendment, no rule, no body, no measurement and no gate beyond consolidating and sequencing what the corpus contains. The `F-` series labels this document's own operating rules only** |
| **No source ID replaced** | **VERIFIED — Rule F-4. All 164 amendment IDs, 77 validation IDs, 40 contradiction IDs, 60 measurement IDs and every decision ID retain their source form. Three citation conventions (PD-1, PD-2) are recorded rather than substituted** |

---

## END OF INSTRUMENT

**v1.3-F — Consolidated Cross-Instrument Adoption, Validation & Implementation Register.**

**100 canonical register items (SR-01…SR-100) · 164 amendments accounted for (A-01…A-23, B-01…B-27, H-01…H-28, L-01…L-40, E-01…E-46) · 77 validation items in 17 categories · 30 `UNRESOLVED` and 65 `PROPOSED` decisions · 40 contradictions, none silently reconciled · 60 pilot measurements (47 fully testable, 8 partial, 7 not testable) · 28 dependency chains · 8 critical paths plus a 13-step master path · GATE P0 with 10 sub-gates · 88 authorisation artefacts across 10 packages · 28 merged failure conditions · 18 anti-gaming and anti-capture vectors · 9 provenance defects recorded (PD-1…PD-9) · 34 operating rules (F-1…F-34).**

**Status: `CONSOLIDATION REGISTER — PROPOSED`.**
**Verdict: `C — PILOT NOT READY, BUT THE PATH IS FINITE`.**
**Next artifact: the entity-structure decision paper.**

**Nothing in this document is an approval, a decision, a validation or a finding of readiness. No unresolved question is resolved. No number, threshold, budget, target, rate, legal conclusion or ownership arrangement is invented. No successor is named. No recommendation is converted into a decision. No assumption is converted into a fact. No architectural rule is treated as evidence of real-world effectiveness.**

**WRITTEN ARCHITECTURE IS NOT OPERATIONAL READINESS. OPERATIONAL READINESS IS NOT PILOT EVIDENCE. PILOT EVIDENCE IS NOT INSTITUTIONAL PROOF.**

**DO NOT LET THE BRAND OUTRUN THE INSTITUTION. DO NOT LET SOFTWARE OUTRUN GOVERNANCE. DO NOT LET REVENUE CLAIMS OUTRUN ECONOMICS. DO NOT LET LEADERSHIP TITLES OUTRUN DEMONSTRATED COMPETENCE. DO NOT LET MEMBERSHIP NUMBERS OUTRUN TRUST. DO NOT LET PROTECTION LANGUAGE OUTRUN SAFETY AND LEGAL CONTROLS. DO NOT LET NATIONAL AMBITION OUTRUN LOCAL PROOF.**

**Prepared 5 October 2026.**
