# KRYTOS / SEWAK SATHI SANSTHA — Architecture Brief (my working understanding)

**Source read:** `KRYTOS_SEWAK_SATHI_SANSTHA_VISUAL_MASTER_ARCHITECTURE_CONSTITUTION_LAUNCH_SPECIFICATION_v1_2.pdf`
179 pages · Version 1.2 "Visual Transformation Edition" · dated 1 October 2026
**Structure:** pp. 1–6 front matter + legend · pp. 7–41 = 36 visual chapters · pp. 42–179 = Appendix A, the complete extracted text of the **v1.1 source (81 pages)**, preserved page-by-page.
**Upstream lineage:** v1.0 Krytos Master Architecture → v1.1 Sub-Role & Vacancy System Amendment → v1.2 visual edition. Prepared for Krytos / Founder-CEO **Vasu**.

---

## 1. What the organisation is

A Krytos-owned, founder-led, **India-wide distributed operating network** — not a charity, not a WhatsApp volunteer group, not a private security force. Public/operating name **Sewak Sathi Sanstha** (PROPOSED — legal/name validation required); **Krytos** remains the parent/ownership context.

**Four pillars:** Social Service · Community Network · Protection / First Response · AI Business Network.

**Operating formula:** Central mission + local autonomy + verified membership + AI-enabled business + transparent compensation + measurable performance + earned leadership.

**Core doctrine:** Help without discrimination · Protect without retaliation · Serve without expecting reward · Stand against injustice without becoming unjust · Use strength with discipline · Greater responsibility only to those who have earned greater trust.

**Non-negotiables stated in the doc:** not charity-only · not vigilantism · not AI-controlled · not micromanaged · not status-based.

---

## 2. Hierarchy & governance

`KRYTOS / Founder-CEO → National Council (PROPOSED governance layer) → National Team → State Teams → City Teams → Mohalla Teams → Verified Members`

- Ownership + executive authority sit with Krytos/CEO; the **Council is standards/ethics/audit/dispute review, NOT an owner above the CEO** unless a legal charter says so (explicitly flagged UNRESOLVED).
- Authority matrix separates: Ownership · Executive · Governance · Management · Operations · Audit · Safety · Finance — each with a stated boundary.
- National departments: Operations, HR & Verification, Finance, Legal & Compliance, Safety/Protection, AI & Data, Business, Communications, Audit & Ethics.
- **State ≠ National duplication:** city coaching, cross-district coordination, specialist pool, multi-city projects, escalation filter, performance review. States may not alter constitutional principles, final compensation percentages, protection boundaries, data policy or legal structure.
- **City:** Mohalla formation/support, cross-Mohalla projects, customer pipeline + venture proposals, inventory allocation, weekly/monthly data review, mid-level incident support. Six-lane escalation map (project / HR-conduct / money / safety / business / need-more-team).
- **Mohalla 10-step operating loop:** observe-request → log → safety check → verify → prioritise → create project → assign roles/resources → execute → evidence + outcome → report + performance.

---

## 3. Roles, sub-roles, vacancies (the v1.1 amendment)

**Universal ladder:** Primary Role → Sub-Role/Deputy → Coordinators → Supporting Members.
A sub-role is **delegated operational support, not an automatic transfer of primary authority** — delegation must be explicit, recorded, RBAC-limited, dated and reviewed.

**11 primary role families:** Team Leader · HR & Verification · Ground-Level/Operations · Volunteer · Planner · Social Media · Editor · Funds · Warehouse/Logistics · AI & Business · Safety/Protection. Each has a defined "cannot do" boundary (e.g. Funds cannot self-approve, release reserves, change formula or audit own final work; Safety cannot authorise retaliation, weapons, unlawful detention/search or police impersonation).

**Three staffing states:** A – Starter Team (roles may combine; safety/HR/finance/evidence duties never skipped) · B – Growing Team (need-based sub-role vacancies) · C – Full/Autonomous Team (Manager → Sub-Manager → Coordinators → Supporting Members).

**Vacancy lifecycle (13 steps):** create → define eligibility → open → apply → HR screening → verification → interview/assessment → training verification → select or alternate path → probation → appoint → activate permissions (RBAC/finance/data) → performance monitoring.
**Vacancy statuses:** Open · Filled · Reserved · Temporarily inactive · Suspended · Closed.
**Eligibility engine dimensions:** membership status, training, experience, conduct, availability, legal/age, conflicts, safety & data handling — plus the rule **AI may match/shortlist but may never appoint, reject or remove**.
**Software rule:** one role = one primary holder; one designated deputy where applicable; multiple coordinators only under defined workstreams (prevents duplicate heads / "deputy authority creep").

Full role + vacancy catalogues are repeated per level (National pp. 15–16, State pp. 16–17, City/Mohalla pp. 17, 20–22) with purpose, authority limits, training, reporting line and succession path for every role.

---

## 4. People: membership, HR, training

**Member lifecycle (12 stages):** application → screening → identity verification → interview/suitability → beginner training → probation → Verified Member (optional QR card, privacy-minimised) → role assignment → Active Member → review → advancement/transfer → demotion/suspension/removal/resignation.
**Conduct rule:** first violation = warning; repeat of the same violation = removal; separate serious-misconduct procedure (PROPOSED, needs legal/safeguarding review).
**HR record classes** with privacy tiers: identity, contact/emergency, skills & training, team/role/status, conduct (highly restricted), vacancy/appointment records.
**10 training categories:** organisation fundamentals, code of conduct, safeguarding, communication, emergency response/first aid, financial integrity, data privacy/cybersecurity, AI usage, business operations, leadership/de-escalation/role-specific.
**Explicit caveat:** internal training is *not* automatically legally sufficient for first aid, security, labour, child safeguarding, medical, counselling, legal or regulated activities.

---

## 5. Team growth, autonomy, failure

- **Autonomy is earned, gated** on 8 evidence areas: membership, operations (full project cycle), finance (reconciled, no material gaps), safety (trained lead, no unresolved serious breach), HR records accuracy, business (approved work priced/delivered/recorded), community trust, audit pass.
- Framing contrast preserved: **central standards ≠ central control** (micromanagement creates fear, dependency and obedience-measuring).
- **Failure recovery is support-first (9 steps):** detect → identify bottleneck → assign support team → discuss → root-cause → training/resources → improvement period → reassess → continue/support/restructure/replace. Six failure types mapped with signals, first response and escalation (operational, financial, leadership, HR, safety, business).

---

## 6. Service, protection, business

**Social Service Engine:** 12-step need-to-impact loop ending in *outcome verification* and *real impact measurement*. Seven categories (education, food, health-support, cleaning/plantation, clothing/donations, infrastructure/emergency, animal/environment) each with special controls.
Anti-fake-impact rules: no counting plans as impact, no double-counting beneficiaries/items/sessions, measure outcomes not activity, privacy-protective evidence, random audits + beneficiary/partner confirmation + inventory reconciliation, separate reach from verified benefit, report failures and partial outcomes.

**Protection / First Response:** 9-step official sequence — incident → assess risk (Low/Medium/High/Emergency) → protect → de-escalate → contact authorities → first aid if trained → physical intervention only if reasonably necessary and lawful → document → review.
**Six DO-NOTs:** weapons · retaliation/punishment squads · mob justice/public shaming · unlawful detention/search/seizure/forced confession · police or government impersonation · intimidation using organisational identity.
Risk-tier decision matrix defines who decides and what action is mandatory at each tier; at High/Emergency the rule is *do not investigate or punish* — protect, call authorities, preserve evidence.

**AI Business Network:** 14-step venture lifecycle (idea → validation → approval tier → setup → customer → assignment → production → QA → delivery → acceptance → revenue → waterfall → performance → scale/improve/close). Seven candidate categories with controls (software/apps, AI automation, digital services/analytics, design/editing, education/training, local business technology, physical products/services). Zero-capital local venture model preserved.

---

## 7. Money

**Waterfall (the priority order is the control; percentages are only a planning tool):**
customer revenue → venture revenue account → 1. worker compensation → 2. statutory dues → 3. direct business/delivery costs → 4. founder compensation (approved cap) → 5. organisation service fee → 6. reserves / wage-protection buffer → 7. social-impact contribution (only if surplus conditions met) → 8. residual surplus / founder upside.
**Illustrative-only figures in source:** 37.5% worker compensation, 17% direct delivery costs, 12% organisation service fee — explicitly **NOT final policy**.
**Bad-month rule:** deferrable organisational fees and social contributions fall *before* verified worker compensation is sacrificed (subject to law/final structure).
**Controls:** segregation of duties (no one person receives + approves + records + audits), Funds Manager and Sub-Funds limits, reserves held by National Funds Manager with an approval matrix, social-impact fund is a restricted mission fund — not salaries, venture bailouts, political/religious activity or a discretionary pool.
**Weekly payment system (13 steps):** Mon–Sun verified work → work verification → revenue reconciliation → expense verification → statutory check → distributable amount → member payment → leader payment (multiplier NOT FINAL) → organisation allocation → reserve → social-impact → weekly report → audit trail (payment sheet + formula version + approvals + evidence).

---

## 8. AI, data, platform, permissions

**Doctrine: AI MAY RECOMMEND. HUMANS DECIDE.**
8-layer AI stack: human governance → AI governance policy → agent/assistant layer → orchestration (context, prompt/model versioning, confidence, sources) → tools/data under RBAC → named human review → execution → append-only audit (prompt, output, model, sources, user, reviewer, decision).
**AI may not:** terminate workers, deny applications, set wages, adjudicate safeguarding, make legal conclusions, authorise serious safety actions, move significant funds, manipulate leaderboards.
**Data flow:** Mohalla → City → State → National, upward only when needed (HR, finance, safeguarding, investigation, statutory duty, audit, approved analytics); access is least-privilege by role, geography, case assignment, sensitivity and audit purpose.
**14 platform modules:** Identity/HR/Verification · Team hierarchy/Roles/Vacancies · Training/Volunteers/Tasks · Projects · Business ventures/Customers · Revenue/Expenses/Payroll · Reserves/Social-impact funds · Inventory/Warehouses · Safety incidents · Reports/Performance/Leaderboards · AI assistant · Audit logs · Notifications · Permissions/Dashboards.
**Role/sub-role/vacancy DB fields** specified (role_id, parent_role_id, team_id, organisational_level, vacancy_status, assigned_member_id, designated_sub_role_id, delegated_authority, permission_profile, financial_permission_profile, data_access_profile, training/eligibility requirements, performance/succession status, appointment/review dates, delegation start/end).
**RBAC matrix** legend: N / V / C / U / A / R / X across Operational, HR, Finance, Safety, Data-AI, Approval — for Verified Member, Team Leader, Sub-Leader, HR Manager, Sub-HR, Funds Manager, Sub-Funds, Safety Lead, Sub-Safety, Auditor (review-only, not an operational commander).

---

## 9. Reporting, performance, leadership

**Dashboards** per persona: Member, Team Leader, City, State, National, Auditor.
**Cadence:** daily (operational memory) · weekly (money/work/accountability) · monthly (performance/leadership) · quarterly (strategic) · annual (full accountability).
**Communications rules:** internal clarity without off-record orders; public = verified facts only, plans distinguished from completed work, privacy protected; incident comms fast/factual with safety-legal-comms approval; authorised spokespersons only; misinformation corrected calmly with correction logs.

**Performance system:** evidence → metrics → monthly evaluation → team score → leaderboard (post anomaly-review, corrections, appeals) → leadership/support/development.
**Proposed weights (require approval):** mission impact 20 · execution 15 · business 15 · financial discipline 15 · member development 10 · community trust 10 · safety/compliance 10 · innovation 5.
Raw revenue, followers, views, volunteer counts, application counts or activity counts **cannot** determine leadership. Eight gaming vectors each have a named control.

**Dynamic leadership:** best Mohalla Team → City Head Team → State Head Team → National Team opportunity, with eligibility gates, evidence review, tie-breaks, correction window, appeals and handover; high score is void on fraud/safety breach/manipulation; opportunity is not automatic personal entitlement.

**Audit pathway (7 steps)** across six domains: financial, HR, safety, business, AI, operational. Append-only records throughout.

---

## 10. Risk, partnerships, launch

**Risk register (18 risks)** with detection/early warning, prevention, response and escalation owner — including leader abuse, financial fraud, fake members/projects/revenue, AI hallucination/misuse, data breach, unsafe protection, mission drift, business failure, team collapse, toxic leadership, leaderboard gaming, centralisation/bureaucracy, uncontrolled expansion, reputational/safeguarding failure, conflict of interest, and deputy authority creep/fake vacancies.

**Partnerships (8 steps):** identify → due diligence → tiered approval → MOU/contract documentation → responsibilities → financial terms → safeguarding → termination.

**Launch roadmap (Phases 0–5):** 0 Legal/Governance validation → 1 National Core → 2 Pilot Mohalla → 3 Pilot City → 4 State Expansion → 5 National Scale, each with objective, prerequisites, exit gate and blockers.
**Launch control board:** 9 areas all currently marked **Blocker** (technology = blocker before scale): governance, legal/tax/employment, safeguarding/safety, finance, business, technology/cybersecurity, training/HR, communication/branding, audit/risk/insurance.

---

## 11. Constitution (19 articles) & open decisions

Articles: 1 Mission · 2 Values · 3 Ownership · 4 Leadership · 5 Membership · 6 Rights · 7 Responsibilities · 8 Conduct · 9 Safety · 10 Finance · 11 Business · 12 AI · 13 Data · 14 Performance · 15 Succession · 16 Audit · 17 Dispute resolution · 18 Amendments · 19 Dissolution/restructuring.
Each article is tagged APPROVED ARCHITECTURE, PROPOSED POLICY, or REQUIRES PROFESSIONAL VALIDATION.

**Status labelling system used throughout:** LOCKED/APPROVED · PROPOSED—REQUIRES FINAL APPROVAL · REQUIRES PROFESSIONAL VALIDATION · UNRESOLVED · FUTURE IMPLEMENTATION. Colour = information system (blue organisation, teal people/HR, green service, orange business, emerald finance, red safety, purple AI/data, slate governance/audit, amber warning/unresolved). No mandatory rule is ever communicated by icon alone.

**Decision register — still open (needs founder/CEO + professional validation):**
legal structure under Krytos (UNRESOLVED) · public name validation · CEO vs Council authority (UNRESOLVED) · weekly revenue percentages (NOT FINAL) · leader multiplier (NOT FINAL) · worker classification (UNRESOLVED) · team readiness thresholds · leaderboard weights · leadership transition rules · serious misconduct procedure · protection curriculum · QR ID card privacy/legal · social-impact formula · reserve release rules · venture categories · sub-role policy · vacancy taxonomy · minimum staffing numbers · delegation expiry/RBAC profiles · data retention / AI model policy / insurance / partnerships.

---

## 12. Implementation layer preserved in the appendix (v1.1 source)

Appendix A retains, in searchable text: operating templates (project record, incident record minimum fields), **Appendix B** software functional-spec user stories, **Appendix C** data dictionary + audit events, **Appendix D** SOP index (SOP-01 … SOP-22: application, verification, interview, probation, request intake, project execution, donations, expense approval, weekly payment, reserve release, venture proposal, customer delivery, safety incident, public communication, inventory issue, transfer, ordinary violation, serious misconduct, monthly performance, team recovery, AI recommendation review, data breach response), **Appendix E** approval & delegation matrix, **Appendix F** evidence standards (required vs not acceptable vs privacy/retention, per record type), **Appendix G** self-audit before delivery, plus five worked scenarios (resident request, child education activity, local business customer, weekly revenue, protection incident).

---

## 13. My read on the document's character

- It is deliberately **self-aware**: every soft spot is labelled rather than papered over, and the doc refuses to invent numbers (percentages, staffing thresholds, multipliers) that would look like policy.
- The centre of gravity is **control design** — verification before trust, evidence before score, priority order before percentages, human decision before AI output, support before replacement.
- The largest real-world dependencies are all **outside** the document: legal entity/tax/employment structure, safeguarding and protection legality, insurance, data-protection compliance, and a buildable platform. Phase 0 exists precisely because none of that is validated yet.
