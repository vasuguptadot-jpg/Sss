# SEWAK SATHI SANSTHA v1.3-C
# HUMAN SYSTEM, PARTICIPATION & MASS ADOPTION ARCHITECTURE

| | |
|---|---|
| **Instrument** | v1.3-C — third major v1.3 instrument, following v1.3-A (Institutional Survival & Legitimacy) and v1.3-B (Costed Mohalla Unit Economics) |
| **Question answered** | **DO PEOPLE ACTUALLY WANT TO BE PART OF IT?** — why a normal person would participate, why they would return, and why they would eventually want to help build it |
| **Source hierarchy** | (1) `…v1_2.pdf` 179 pp. incl. Appendix A preservation of v1.1; (2) `Sewak_Sathi_Strategic_Stress_Test.md`; (3) `…v1_3_A_Institutional_Survival_and_Legitimacy_Amendment.md`; (4) `…v1_3_B_Costed_Mohalla_Unit_Economics_and_Economic_Survival_Model.md` |
| **Relationship to prior instruments** | v1.2 = control system. v1.3-A = can it be trusted. v1.3-B = can it survive economically. **v1.3-C = does anyone want to be in it.** Each is additive; none rewrites another |
| **Scope** | Human proposition, participation architecture, journey design, belonging, recognition, credentials, retention, exit, anti-coercion and anti-MLM safeguards, identity and language, culture, metrics, human pilot, and the amendment pack that carries all of it |
| **Explicitly out of scope** | Any change to hierarchy, roles, the waterfall, performance weights, the constitution, protection doctrine or the launch roadmap. No element of v1.2, v1.3-A or v1.3-B is removed, renumbered or silently rewritten |
| **Document status** | **HUMAN-SYSTEM DESIGN — PROPOSED.** Nothing here is a slogan, a brand, a policy or a promise until approved. Every psychological claim is a **hypothesis to be tested**, not a finding |
| **Prepared** | 4 October 2026 |

---

## HOW TO READ THIS INSTRUMENT

### Classification tags

| Tag | Class | Meaning |
|---|---|---|
| **[S]** | **SOURCE-DERIVED** | Stated in v1.2 or the preserved v1.1 source, cited by chapter, article, SOP or appendix |
| **[S-ST]** | **SOURCE-DERIVED from the Strategic Stress Test** | The stress test is part of the declared source hierarchy; cited by section |
| **[S-A] / [S-B]** | Source-derived from **v1.3-A / v1.3-B** | Cited by amendment ID or section |
| **[A]** | **ANALYSIS** | Reasoning applied to source facts |
| **[I]** | **INFERENCE** | Probable consequence derived from analysis and general human behaviour — **not evidence** |
| **[P]** | **PROPOSAL** | Recommended here. Not architecture. Requires approval before it binds anyone |
| **[V]** | **REQUIRES VALIDATION** | Legal, safeguarding, privacy, employment, tax or regulatory advice required |
| **[X]** | **EXTERNAL FACT** | Published source outside your documents |
| **[X-inherited]** | External fact **already cited inside the stress test** | Recorded for honesty; **not re-asserted as independent evidence here** |
| **[H]** | **HYPOTHESIS — REQUIRES PILOT TESTING** | A claim about human behaviour that this document deliberately refuses to treat as true |

### Three rules that govern every page

**RULE 1 — No invented behavioural numbers.** Your brief forbids inventing adoption percentages and psychological statistics. **This document contains none.** Every quantity is a variable, a formula, or a threshold marked `PROPOSED — REQUIRES PILOT VALIDATION`. Where the stress test used external retention research, that is marked **[X-inherited]** and is **not** re-asserted here as evidence for a new claim. Per your instruction, **no new outside research has been used.**

**RULE 2 — No untested emotional claim.** Nothing in this document asserts that a message, symbol, ritual or story *will* work. Every such item is marked **[H]** and routed to the human pilot (§57–§58). The core proposition in §3 is treated as a **hypothesis**, not a slogan, and is explicitly **not** declared final.

**RULE 3 — Preserve the unresolved.** Every UNRESOLVED / NOT FINAL / PROPOSED item in v1.2, v1.3-A and v1.3-B that touches the human system is carried forward into §59 **unchanged**, and nothing is closed here.

### Two separations maintained throughout

1. **PARTICIPATION SCOPE vs. HUMAN WORTH.** The nine levels of §6 describe *what a person is permitted to touch*, never *what a person is worth*. §7 makes this a security boundary and §8 makes it a status rule. Any instrument in this document that could be read as ranking people is flagged and corrected at the point of use.
2. **BELONGING vs. LOYALTY TO A PERSON.** §19 builds belonging; §20 prohibits the forms belonging takes when it becomes captivity. The distinction is not stylistic — it is the difference between an institution and a following.

### Naming conventions used

| Prefix | Meaning |
|---|---|
| **H-01 … H-nn** | v1.3-C amendments (§60). Distinct from v1.3-A's `A-nn` and v1.3-B's `B-nn` |
| **HD-01 … HD-nn** | Human Decision Register items (§59); `⟨carried⟩` = brought forward unchanged |
| **N-01 … N-18** | The eighteen human needs examined in §2 |
| **L0 … L8** | Participation levels (§6); **E** = Elder/Mentor standing (§6.10) |
| **D1 … D4** | The four doors (§5) |
| **F-01 … F-36** | Failure modes from the stress test — cited, never renumbered |
| **HF-1 … HF-20** | Human failure simulations (§56) |
| **HM-1 … HM-15** | The fifteen human measurements (§58) |
| **P-01 … P-15** | v1.3-B's economic pilot measurements — referenced where the human pilot must not duplicate them |

---

# 1. EXECUTIVE SUMMARY

## 1.1 The finding in one paragraph

**[A]** v1.2 built a machine that can *verify* a person, *assign* a person, *measure* a person and *pay* a person — and never once asks what a person wants. v1.3-A made that machine trustworthy. v1.3-B made it affordable. **Neither added a single reason for a stranger to walk in.** Across 179 pages the only door is the Verified Member application **[S: Ch.12]**, whose own description is "application starts a verification process; **not entitlement to join**" **[S-ST: §1.1 of App. A]** — an integrity-first design that the stress test correctly called conversion-fatal **[S-ST: §20.3]**. The human system is therefore not *weak*; it is **structurally absent below the point of commitment**, and everything above that point assumes commitment already happened.

## 1.2 Has the gap been closed? — tested, not assumed

Your brief requires that the stress test's verdict be **tested** rather than repeated. §2 does that across eighteen human needs. The result:

| Need | Position after v1.2 + v1.3-A + v1.3-B |
|---|---|
| **Closed or nearly closed (4)** | dignity, trust, contribution *evidence*, autonomy within standards |
| **Materially improved but incomplete (5)** | purpose, usefulness, livelihood, skill development, recognition *controls* |
| **Still open (6)** | **belonging, relationships, identity, achievement, hope, fun/enjoyment** |
| **Deliberately out of scope (3)** | family life, romantic friendship, therapy/grief care — the organisation must *not* try to supply these (§2.3) |

> **[A] Verdict on the stress test's claim: it remains true, and it has narrowed.** v1.3-A closed the *trust* half of the human problem (can I believe this institution?) and v1.3-B closed the *fairness* half (will I be paid honestly?). **Nobody has closed the *belonging* half (will I know anyone here?) or the *identity* half (what does being here say about me?).** Those two are the ones that decide whether a person returns in month four — and the stress test already found that belonging has **"no belonging design anywhere in 179 pages"** **[S-ST: §6.2 row 3]**.

## 1.3 What this instrument builds

**[P]** Twenty-eight amendments (H-01…H-28, §60) organised into six clusters:

| Cluster | Amendments | What it creates |
|---|---|---|
| **1. Access** | H-01 four doors; H-02 nine-level participation spectrum; H-03 public local page; H-04 first-ten-seconds standard; H-05 first-five-minutes experience; H-06 Paired First Task | A way in that does not require joining |
| **2. Worth** | H-07 no-forced-progression rule and six legitimate endpoints; H-08 recognition taxonomy (six separate instruments); H-09 contribution record with anti-social-credit limits; H-10 portable credentials; H-11 specialist and Elder/Mentor paths | Status that does not depend on rank |
| **3. Belonging** | H-12 friendship infrastructure; H-13 rituals under six tests; H-14 story framework; H-15 attribution and follow-up loop; H-16 community-experience charter | Relationships as a designed product |
| **4. Freedom** | H-17 exit with dignity; H-18 paused/alumni status; H-19 anti-cult safeguards; H-20 psychological-safety instruments; H-21 anti-MLM compensation firewall; H-22 beneficiary/recruitment separation | The right to leave, disagree and refuse |
| **5. Reach** | H-23 flexible participation modes; H-24 remote participation; H-25 language architecture; H-26 layered identity; H-27 youth and elder participation rules | A door for every kind of citizen |
| **6. Proof** | H-28 human-system metrics, the fifteen measurements, and the human pilot | Evidence instead of assumption |

## 1.4 The verdict

> ## **D — HUMAN SYSTEM NOT YET PROVEN**
> ### with a defined path to **B — HUMAN SYSTEM VIABLE WITH TESTING**

**[A]** D is not a criticism of the design; it is a statement about evidence. Your own rule forbids claiming that an emotional message will work without testing it, and **nothing in the human system has been tested against a single real person.** Every mechanism here is a hypothesis with an instrument attached. The classification becomes **B** when the twenty-eight amendments are adopted *and* §57's pilot is designed; it becomes **A** only after §58's fifteen measurements return values that meet approved thresholds. **A is not available to a document, only to an experiment.**

## 1.5 The one-sentence answer to your core question

**[A]** *An ordinary Indian would join Sewak Sathi for one of four different reasons (purpose, proof, livelihood, building), would return because a specific person expected them and a specific outcome was visible, would trust it because it kept a small promise publicly and showed the record, and would eventually want to build it only if staying had already converted into something they could carry — a skill, a credential, a livelihood, a reputation, or a set of friendships — rather than into a debt they owed the organisation.*

§63 answers that question separately for twelve kinds of person and then proves the differentiated value against eleven existing alternatives.

## 1.6 What this instrument refuses to do

1. **It does not declare a slogan.** §3 tests *"My help reached someone real — and I was not alone in it"* as a hypothesis with nine failure modes identified, and leaves adoption to approval.
2. **It does not invent conversion rates.** §36 builds the adoption funnel as **variables the pilot must measure**, with no percentages anywhere.
3. **It does not make leadership the goal.** §8 establishes six legitimate endpoints, and §7 forbids any instrument that implies leadership is morally superior to service.
4. **It does not recruit beneficiaries.** §16 makes assistance and recruitment separate by *role* and by *time*, and never permits an invitation at the moment of need.
5. **It does not build a social credit score.** §24 states the four things the contribution record may never determine.
6. **It does not assume everyone must progress.** §6 gives every level an **exit path and a lateral path**, not only an advancement path.
7. **It does not claim universal coverage.** §35 tests whether every *type* of citizen can find one legitimate way to benefit, contribute or interact — and §53's "would they miss us" test is applied before any promise of scale.

---

# 2. THE HUMAN-SYSTEM GAP

## 2.1 The claim, tested

> **[S-ST: §1.1]** "The architecture is **unusually strong as a control system and unusually weak as a human system.**"

**[A]** Repeating that sentence would be worthless. Testing it requires asking *which* human needs the architecture serves, and whether two subsequent instruments changed the answer. §2.2 does that need by need.

**Method:** for each need — (i) what v1.2 already provides, cited; (ii) its strength; (iii) what is still missing after v1.3-A and v1.3-B; (iv) what this instrument proposes; (v) what validation is required. Strengths are rated **● strong / ◐ partial / ○ absent**, and the rating refers to *design presence*, never to *proven effect* — nothing here has met a real person.

## 2.2 The eighteen-need matrix

| # | Human need | Existing architecture | Strength | Current gap after v1.2 + A + B | Proposed addition | Validation needed |
|---|---|---|---|---|---|---|
| **N-01** | **Purpose** — "my life does something" | Mission and principles **[S: Ch.1–2]**; four pillars; "serve without expecting reward" **[S: Ch.2]**; mission impact carries the **highest** performance weight, 20% **[S: Ch.25]**; v1.3-A A-13 Tier-1 mission lock | **●** | Purpose is stated to *members*. It is never stated to a **stranger in ten seconds** in language they would use **[S-ST: §20.1]** | **H-04** first-ten-seconds standard; **H-14** story framework; §3 proposition | **[H]** — test comprehension, not agreement |
| **N-02** | **Belonging** — "these are my people" | Implied only: Volunteer Manager family incl. **Member Engagement Coordinator** and **Volunteer Support Coordinator** **[S: Ch.9]**; team structure; Head Team concept **[S: Ch.34]** | **○** | **The largest single gap.** Stress test: "no belonging design anywhere in 179 pages" **[S-ST: §6.2 row 3]**. v1.3-A protected the institution; v1.3-B protected the payroll; neither created a friendship | **H-12** friendship infrastructure; **H-13** rituals; **H-16** community-experience charter; **H-06** Paired First Task (two existing members, by design) | **[H]** + **[V]** where gatherings involve minors or public space |
| **N-03** | **Usefulness** — "I was needed today" | 12-step service loop **[S: Ch.15]**; 10-step Mohalla loop **[S: Ch.8]**; task assignment **[S: Ch.9 Planner family]** | **◐** | Usefulness exists but is **not returned to the person**. Outcome verification happens **[S: Ch.15 step 10]** and is never shown to the contributor **[S-ST: §7.3 item 9]** | **H-15** attribution and follow-up loop | **[V]** privacy (v1.3-A A-19) |
| **N-04** | **Dignity** — of the person helped *and* the person helping | "Dignity" in food service; no exposure of minors; avoid unnecessary beneficiary documents **[S: Ch.15, App. F]**; **v1.3-A A-19** Beneficiary Privacy & Dignity Code; **v1.3-B §34** Economic Dignity Test | **●** | Closed for beneficiaries (A-19) and for workers (v1.3-B §34). **Open for low-level participants**: nothing prevents Levels 0–4 being treated as a lower caste of member | **H-07** no-status-hierarchy rule; **H-02** level naming discipline; §7 | **[V]** equality/anti-discrimination |
| **N-05** | **Recognition** — "someone noticed" | Leaderboard with anomaly review, corrections and appeals **[S: Ch.25]**; "achievements" on the Member dashboard **[S: Ch.24]**; recognition must celebrate contribution, not loyalty **[S-ST constraint]** | **◐** | Recognition exists as **one instrument (ranking)** where six are needed; and the weights are PROPOSED/NOT FINAL **[S: Ch.33]** | **H-08** recognition taxonomy; §44 status-addiction controls | **[H]** + approval of weights **[S: Ch.33]** |
| **N-06** | **Relationships** — friends, mentors, peers | Conduct & Welfare Coordinator **[S: Ch.9]**; team proximity; nothing else | **○** | No mentorship design, no stable-team rule, no family-inclusive provision. Stress test: friendship infrastructure "cheap, unglamorous, decisive" and absent **[S-ST: §7.3 item 7]** | **H-12**; **H-11** Elder/Mentor standing; §48–§49 | **[V]** safeguarding where minors or vulnerable adults are involved |
| **N-07** | **Personal growth** — "I am not the same person" | 11 training categories **[S: Ch.12]**; probation; member development 10% **[S: Ch.25]**; per-role succession columns **[S: Ch.9]** | **◐** | Training exists as **eligibility for tasks**, not as a **ladder a person can climb**. No credential issuance; no horizontal progression | **H-10** portable credentials; **H-11** specialist path; §26 | **[V]** recognition of credentials by employers/institutions |
| **N-08** | **Skill development** | Training categories **[S: Ch.12]**; professional-validation boundary **[S]**; State specialist pool **[S: Ch.6]** | **◐** | Skills are *consumed* by the organisation and never *certified outward*. Stress test: "the most under-exploited asset in the entire architecture" **[S-ST: §6.2 row 6]** | **H-10**; **H-11** | **[V]** — certification legality, sector recognition |
| **N-09** | **Livelihood** — "honest work, honest accounting" | Worker-first waterfall **[S: Ch.18]**; weekly payment with published formula and audit trail **[S: Ch.19]**; AI Business Network **[S: Ch.17]**; **v1.3-B** B-05/B-06/B-09/B-13 | **◐→●** | **Substantially closed by v1.3-B** on *fairness*. Still open on **expectation management**: nothing stops recruitment language implying income the waterfall cannot deliver **[S-ST: F-02, M16]** | **H-01** Door 3 with earnings-reality disclosure; §46 livelihood door | **[V]** employment/labour (v1.3-B E-C2) |
| **N-10** | **Identity** — "what does being here say about me?" | Name *Sewak Sathi* (PROPOSED public name **[S: Ch.33]**); ID card / QR CONCEPT APPROVED **[S: Ch.33]**; **v1.3-A A-06** visibility protocol (no uniform, no insignia) | **○** | **A deliberate vacuum.** v1.3-A removed the *dangerous* identity signals (uniform, insignia, force imagery) and correctly so — but nothing supplies a *positive* one. A person cannot say "I am a …" | **H-26** layered identity; §53 symbolism under the "service not force" rule; §32 shared vocabulary | **[V]** + **[H]**; **must not** contradict A-06 V1–V3 |
| **N-11** | **Trust** — "will they be honest with me?" | Evidence and outcome verification **[S: Ch.15]**; waterfall transparency **[S: Ch.18–19]**; audit **[S: Ch.27]**; **v1.3-A** A-07 public statement, A-15 memory, A-16 four institutional tests, A-19 dignity | **●** | Closed *institutionally*. Open *interpersonally*: a stranger's trust is produced by one named person keeping one small promise, which is §40's sequence, not a policy | **H-15**; §39 social proof; §40 trust-before-brand | **[H]** |
| **N-12** | **Autonomy** — "I choose how much" | Local autonomy doctrine **[S: Ch.13; App. A §16]**; earned freedom inside central standards | **◐** | Autonomy is designed for **teams**, not for **individuals**. Nothing lets a person choose cadence, mode, duration or the right to refuse | **H-23** eleven participation modes; **H-17** right to refuse; §21 exit | **[V]** where refusal touches a safety or legal duty |
| **N-13** | **Contribution** — "I gave something" | Verified work; contribution recorded in payment sheets and evidence **[S: Ch.19, App. F]** | **●** | Contribution is recorded **for control**, never **for the contributor**. The record exists and is never given back | **H-09** contribution record; **H-10** portability | **[V]** privacy, data-subject rights (v1.3-A A-17/A-20) |
| **N-14** | **Achievement** — "I finished something" | Project completion; customer acceptance **[S: Ch.17 step 10]**; execution 15% **[S: Ch.25]** | **◐** | Achievement is measured at **team** level. An individual's completed thing has no artifact, no moment and no witness | **H-08** (project-completion and milestone instruments); **H-14** | **[H]** |
| **N-15** | **Community** — "my neighbourhood is better" | Mohalla architecture **[S: Ch.8]**; local observation and resident request **[S]**; community trust 10% **[S: Ch.25]** | **●** | **The strongest existing asset.** Gap is one of *legibility*: the improvement is real but not attributed to the people who made it | **H-14** story framework; **H-16** community charter; §38 first community loop | **[H]** |
| **N-16** | **Hope** — "it can get better" | Implied by mission; nothing designed | **○** | Hope is the one need the organisation **must not manufacture**. It arises from evidence or it is a lie. §33 places hope in the *permitted* emotional set and §20 prohibits the fear/guilt substitutes | **H-15** follow-up loop (hope produced by *shown* outcomes); §40 small-promise sequence | **[H]**; **no instrument may promise an outcome** |
| **N-17** | **Fun / enjoyment** | Nothing. No source provision anywhere | **○** | Absent, and **partly correctly**: an organisation that becomes entertainment loses its seriousness. But a volunteer programme with no enjoyment has no social fuel | **H-13** rituals under six tests (voluntary, inclusive, non-political, non-religious, no personality cult, reasonable cost); shared meals after projects **[S-ST: §7.3 item 7]** | **[V]** where food, minors or public space are involved |
| **N-18** | **Flexibility** — "life comes first" | Nothing. Vacancy statuses include `Temporarily inactive` **[S: Ch.11]** but there is no participant-level pause | **○** | The architecture treats absence as a **vacancy problem**, not a **life event**. Stress test: paused/alumni status missing (F-04); relocation and busyness are leading exit reasons **[X-inherited: S-ST §6.2/§7.3]** | **H-18** paused/alumni status; **H-23** modes; **H-17** exit with dignity | **[V]** records retention while paused (v1.3-A A-17 P2) |

## 2.3 Which needs do NOT belong inside the organisation

**[A]** Your brief requires that not every human need be assumed to belong here. Five are explicitly **out of scope**, and naming them is a safeguard rather than a limitation:

| Need | Why it must stay outside | What the organisation does instead |
|---|---|---|
| **Family life and intimate relationships** | An organisation that supplies a person's whole social world becomes the thing §20 prohibits — isolation from family, "organisation above family" | **Family-inclusive** events are permitted (H-13); family *replacement* is prohibited (§20.2 item 7) |
| **Therapy, counselling, grief care** | Requires licensed competence; **[S: Ch.12]** already states internal training is not legally sufficient for counselling or medical roles | **Referral only**, to qualified partners **[S: Ch.15 health-support "qualified partner support"]**; the Elder/Mentor role (§6.10) explicitly excludes counselling |
| **Romantic or matchmaking functions** | Creates safeguarding, coercion and exclusion risk, and imports caste/community clustering **[S-ST: §6.2 row 12]** | Nothing. Any such activity by members is private and must not use organisational channels or records |
| **Religious fulfilment** | Seva may be *personally* motivated by faith; the organisation may never *invoke* faith **[S-A: A-05]** — "accepted individually, never invoked institutionally" **[S-ST: §6.2 row 13]** | Religious neutrality per **v1.3-A A-05**; no religious framing, symbols, calendar or language in organisational voice |
| **Political identity and collective bargaining** | v1.3-A A-01/A-02 already settle this: members keep their personal civic rights, and the organisation takes no position | **v1.3-A A-02** T0–T5 rules apply unchanged |

**[A]** A sixth need deserves a qualified exclusion: **status**. Status is real, universal and useful — and §44 shows it becomes destructive the moment it is the *only* thing on offer. The organisation may **recognise contribution**; it may not **rank human worth** (§7.3, §8.2).

## 2.4 What the matrix proves

**[C]** Three derived conclusions:

1. **The architecture's human strength is concentrated in *evidence* needs** (contribution, community, trust, dignity) and its weakness in *social* needs (belonging, relationships, identity, fun). **That is not a coincidence.** Evidence is what a control system produces; belonging is what a community produces. v1.2 is the former and was never asked to be the latter.
2. **v1.3-A and v1.3-B closed exactly the needs they were designed to close** — trust (A-07/A-16/A-19), dignity (A-19), livelihood fairness (B-05/B-06/B-09), autonomy *of teams* (A-13/A-14). **Neither was addressed to belonging, identity, relationships or flexibility, and neither pretended to be.** The gap is not a failure of the previous instruments; it is the reason this one exists.
3. **Six needs remain open and all six are cheap.** Belonging, relationships, identity, achievement, hope, flexibility and fun require **no new authority, no new money and no new technology** — they require stable teams, named pairings, one page in a local language, a record given back, a pause button and a meal. **That is the most encouraging finding in this document: the missing half of the human system is the inexpensive half.**

---

# 3. THE CORE HUMAN PROPOSITION

## 3.1 The proposition, as a hypothesis

> **[S-ST: §10.2]** *"My help reached someone real — and I was not alone in it."*
> Formally: **Trust × Contribution × Belonging, standing on a floor of Dignity, expressed in the cultural vocabulary of Seva.**

**Status: [H] HYPOTHESIS — NOT APPROVED, NOT ADOPTED, NOT A SLOGAN.** The stress test proposed it; this instrument tests it. Adoption requires approval under **[S: Const. Art.18]** and testing under §57.

## 3.2 What it means, decomposed

| Clause | What it asserts | What it obliges the organisation to do |
|---|---|---|
| **"My help"** | Agency belongs to the participant, not to the institution. The subject of the sentence is *I* | Attribution must name the contributor, not only the organisation (§17) |
| **"reached"** | Delivery, not intention. Something arrived | Outcome verification **[S: Ch.15 step 10]** and the follow-up loop (§18) |
| **"someone real"** | A specific person or place, not a statistic | Anti-inflation rules already exist: "Do not count planned activities as completed impact" **[S: Ch.15]** — **and privacy forbids naming them (v1.3-A A-19), so "real" must be shown without exposure** |
| **"and I was not alone in it"** | Belonging. The contribution happened *with* people | H-06 Paired First Task; H-12 friendship infrastructure |

**[A]** The proposition is well-formed because each clause is **already an architectural commitment**. It does not promise a feeling the organisation cannot produce; it describes a sequence the architecture already performs and never narrates.

## 3.3 Why it could resonate

**[I]** Four reasons, each a hypothesis to test rather than a finding:

1. **It is verifiable in an environment saturated with unverifiable giving.** The stress test's core differentiation claim: most organisations can only *assert* impact; this one is built to *evidence* it **[S-ST: §10.2, §19.2]**.
2. **It supplies the two things separately missing from the alternatives:** the neighbourhood group has belonging but no evidence; the NGO has evidence but no neighbourhood **[S-ST: §19.3]**.
3. **It is compatible with seva vocabulary without invoking religion** — *Sewak* already means one who serves **[S-ST: §10.2]**, so the cultural frame is in the name and needs no doctrinal claim.
4. **It does not ask the participant to be exceptional.** "My help reached someone" is available to a person who gave ninety minutes once.

## 3.4 Where it could fail — nine failure modes

**[A]** Your brief requires the failure analysis, not the pitch.

| # | Failure mode | Mechanism | Detector | Guard |
|---|---|---|---|---|
| **PM-1** | **Saviourism** | "I helped *them*" positions the participant as superior and the recipient as an object. The clause "my help reached someone" is one word away from it | Language audit of stories and internal speech; beneficiary feedback (§58 HM-13) | **§17.4 attribution rules**: the beneficiary is the subject of the outcome sentence, the contributor is the subject of the *action* sentence; **never** "we gave them"; v1.3-A A-19 dignity rules apply |
| **PM-2** | **Dependency in the recipient** | Repeated help with no follow-up creates reliance rather than capability | Follow-up loop (§18) asks "did the problem improve?" — a *no* that repeats is the signal | **§18.4**: referral to competent authorities and partners is a success, not a failure; the organisation's aim is a problem that stops recurring **[S: Ch.15 "survival/follow-up tracking"]** |
| **PM-3** | **Emotional manipulation** | The proposition becomes a guilt instrument: "you *could* have reached someone" | Any communication that implies obligation; §20.1 prohibited-mechanism list | **§34.3**: guilt, shame and indebtedness are prohibited emotions; **seva is descriptive, never prescriptive** — "a true sewak would…" is banned phrasing **[S-ST: §10.2]** |
| **PM-4** | **It does not communicate the business side** | A person who hears only service will be confused or betrayed when asked to deliver paid client work | Comprehension testing of the service/business distinction (§58 HM-11) | **§46**: the livelihood door is stated separately and truthfully; **v1.3-B B-09** requires the paid/voluntary boundary to be published |
| **PM-5** | **It does not communicate belonging** | "I was not alone" is the weaker clause in practice — belonging is produced by people, not by a sentence | HM-3 belonging measurement; whether participants can name two people | **H-06/H-12**: belonging is *engineered* through pairing and stable teams, never asserted through copy |
| **PM-6** | **It does not communicate personal growth** | Nothing in the sentence promises a skill, a credential or a livelihood — and for students and job-seekers that is the actual reason | Door-2 comprehension (§58 HM-11); whether participants know a record exists | **H-10**: the credential is stated as a *separate* proposition to Door 2, not folded into the emotional one |
| **PM-7** | **It over-claims reach** | "Reached someone real" fails the first time help does not arrive — and in a resource-constrained team that will happen | Decline rate; unmet-request register; HM-14 | **§40 small-promise sequence**: promise only what the team can deliver; **a well-delivered decline is itself a trust event [S-ST: §20.3]** |
| **PM-8** | **It is untranslatable** | The clause structure is English; direct translation may produce something flat or devotional in other languages | Terminology review per language (v1.3-A A-06 V11 pattern; H-25) | **§30.4**: meaning is fixed, wording is local, and no translation is published without review |
| **PM-9** | **It becomes a brand before it becomes true** | The organisation advertises the proposition before it can evidence it | §40's sequence inverted; promise size vs delivery record | **§40 trust-before-brand** as a hard rule; **v1.3-A A-07** under-claiming posture |

## 3.5 Who it may resonate with, and who it may not

**[H]** All entries are hypotheses. Segments are drawn from the stress test's citizen-value map **[S-ST: §8]**, which is not reproduced here.

| Likely to resonate | Why **[H]** | Likely **not** to resonate | Why **[H]** |
|---|---|---|---|
| Retirees and elders with time and standing | Purpose, respect, use of accumulated judgement | People in acute financial need | The proposition offers meaning, not money — and offering it *to them* is close to insulting |
| Students seeking verifiable experience | "Reached someone real" is a *record*, which is what they need | Gig workers comparing hourly rates | v1.3-B §34 and stress-test F-34: the open market usually pays better; the proposition must not compete on price |
| Homemakers and parents seeking bounded, near-home contribution | Local, time-bounded, socially safe | People who distrust organisations on principle | No proposition survives prior distrust; only §40's small-promise sequence does |
| Migrants and new residents with no local network | "I was not alone" is precisely their deficit | Ideologically motivated joiners seeking a vehicle | They will be disappointed — and §20 exists so their disappointment does not become the organisation's character |
| Professionals wanting pro-bono scope with evidence | Proof plus competence use | People seeking entertainment or social media content | §2.3 excludes fun-as-product; the proposition is quiet by design |
| People who were themselves helped, later | The loop of §16 — **but only after the separation window** | People in the moment of vulnerability | **§16.2 hard rule: never recruit at the moment of need** |
| Faith-motivated individuals, personally | Seva vocabulary is already theirs | Faith-based *groups* as institutions | v1.3-A A-05: accepted individually, never invoked institutionally |

## 3.6 The three tests the proposition must pass before adoption

**[P]**

| Test | Question | Method | Pass condition |
|---|---|---|---|
| **T1 Comprehension** | Does a person who hears it once understand what the organisation does? | Ten-second test with non-members in the pilot locality, in their own language | They can restate it correctly **without** using the words "NGO", "party", "security" or "scheme" |
| **T2 Non-coercion** | Can it be heard as an obligation or a guilt claim? | Adversarial review against §20.1's prohibited mechanisms and §34.3's prohibited emotions | No formulation of it produces guilt, shame, fear or indebtedness |
| **T3 Deliverability** | Can the organisation keep the promise in its weakest month? | Cross-check against v1.3-B §9 (zero-revenue model) and §33.3 (what stops at ₹0) | The proposition remains **true at ₹0 revenue** — i.e. it must describe *service*, which continues, and never *payment*, which may not |

**[A] T3 is the decisive one and it passes:** at zero revenue the time-costed service categories continue (v1.3-B B-02), so "my help reached someone real" can still be honestly said. **A proposition that fails at ₹0 would be a fair-weather promise**, and that is exactly what §40 forbids.

## 3.7 What must never be the reason

**[S-ST: §6.4]** carried forward unchanged, and now attached to an enforcement instrument:

No recruitment, communication, ceremony or internal appeal may invoke —
(i) an earnings figure not approved in writing; (ii) protection from any group of people; (iii) religious or caste merit; (iv) political change; (v) personal loyalty to any leader; (vi) fear of missing a benefit.

**[P] H-21 and §22 make (i) and (vi) computable**: compensation may never be primarily recruitment-derived, and no benefit may be conditional on joining. **§20 makes (ii) and (v) veto-gated.** **v1.3-A A-01 and A-05 already make (iii) and (iv) prohibited at constitutional level.**

**[A] Each of these six works in the short term. That is precisely why they must be prohibited by rule rather than left to judgement** — the same reasoning v1.3-A applied to the protection DO-NOT list.

---

# 4. THE HUMAN JOURNEY

## 4.1 The ten stages

Your brief's sequence is adopted exactly. For each stage: what the person sees, what they do, what friction exists, what value they receive, what the organisation must provide, what causes abandonment, what evidence indicates success. **Level references are §6; door references are §5.**

### STAGE 1 — SEE

| | |
|---|---|
| **What they see** | A **result**, not an organisation: a cleaned lane with a small dated board; a neighbour's remark; a stall with photographs of local work; one page in their language **[S-ST: §20.3]** |
| **What they do** | Nothing. Looking is the whole activity |
| **Friction** | Not knowing what it is; assuming it is political, religious, a security group, a scheme or a business (**the misclassification map, [S-ST: §18.2]**); no local-language material; nothing visible in their own lane |
| **Value received** | Curiosity; a sense that something local is happening |
| **Organisation must provide** | Visible, dated, local evidence in public space; **H-03** public local page; **H-04** ten-second standard; the v1.3-A A-07 "what we do NOT do" statement |
| **Abandonment cause** | Nothing to see. **An organisation with no visible local output has no Stage 1 at all** |
| **Evidence of success** | Unsolicited local questions; inbound requests via the public page; **HM-1** first-contact count |

### STAGE 2 — UNDERSTAND

| | |
|---|---|
| **What they see** | One page, in their language: the core sentence, the "what we are not" list, three things this team actually did nearby **with dates**, and two buttons — **"Report a need"** and **"Help once"** **[S-ST: §20.3]** |
| **What they do** | Reads. Asks someone. Possibly taps a button |
| **Friction** | Jargon; role titles; process diagrams; the 12-stage member lifecycle; the constitution; language; **the word "AI" and the word "protection" both import the wrong category and belong in the second conversation** **[S-ST: §20.2]** |
| **Value received** | Clarity: what it is, what it is not, what they could do, what they need not do |
| **Organisation must provide** | **H-04/H-05**; a public local page (**not in the current architecture** — [S-ST: §20.3]); plain-language discipline; multilingual publication (H-25) |
| **Abandonment cause** | Being asked to understand the organisation before being offered a way to help |
| **Evidence of success** | **HM-2** comprehension: they can restate the purpose correctly and name at least one thing they could do |

### STAGE 3 — PARTICIPATE

| | |
|---|---|
| **What they see** | Two options only: submit a need in about a minute (three fields: what, where, contact optional), or pick a listed one-off task with time, place, duration and what to bring **[S-ST: §20.3]** |
| **What they do** | Chooses one. Acts once. **Level 1–2** |
| **Friction** | Any form longer than a minute; any identity document request; any membership language; any implication of commitment; transport; timing that clashes with work or family; technology (a phone number should be enough) |
| **Value received** | **Immediate**: their need is acknowledged with a reference number and an expected response time, **or** they do something useful for ninety minutes |
| **Organisation must provide** | **H-02** Levels 1–2 with no verification burden; **H-06** Paired First Task; a real named person responding inside the promised window; §13 friction controls |
| **Abandonment cause** | Silence after the request; being routed into a recruitment conversation; being asked for documents; nobody turning up |
| **Evidence of success** | **HM-4** first-participation completion; response window met |

### STAGE 4 — CONTRIBUTE

| | |
|---|---|
| **What they see** | A real task, alongside two existing members, with a visible beginning and end |
| **What they do** | Works. **Level 2–3** |
| **Friction** | Role ambiguity ("what exactly am I doing?"); fear of failure; fear of judgement; skill mismatch; physical access; language on site |
| **Value received** | Usefulness; company; a small competence |
| **Organisation must provide** | Task-specific training only for the task at hand **[S: Ch.9 "cannot assign untrained people to restricted tasks"]**; a named responsible Verified Member for any Level 1–4 task **[S-ST: §9.3]**; §13 confidence-friction controls |
| **Abandonment cause** | Being left alone; being given a task they were not prepared for; being corrected publicly |
| **Evidence of success** | **HM-5** contribution completion; **HM-6** the participant can say what they did |

### STAGE 5 — EXPERIENCE IMPACT

| | |
|---|---|
| **What they see** | A before/after; an outcome confirmation; the specific thing that changed — **shown without exposing anyone (v1.3-A A-19)** |
| **What they do** | Receives the result. Often says nothing. Sometimes tells someone |
| **Friction** | **The result is never returned to them** — the architecture verifies outcomes **[S: Ch.15 step 10]** and does not narrate them back **[S-ST: §7.3 item 9]** |
| **Value received** | The core emotional payoff of §3: *my help reached someone real* |
| **Organisation must provide** | **H-15** attribution and follow-up loop; §17 ethical attribution methods; §18 follow-up |
| **Abandonment cause** | Never hearing what happened. **This is the single most common quiet exit** **[I]** |
| **Evidence of success** | **HM-7** attribution received; **HM-8** follow-up outcome known and shared |

### STAGE 6 — RETURN

| | |
|---|---|
| **What they see** | An invitation that is specific, optional and low-pressure: a named task, a named date, a named person who remembers them |
| **What they do** | Comes back — or does not, and is not made to feel that this is a failure |
| **Friction** | Life (relocation, exams, work, family); no reminder; the belief that they are expected to commit more than they can; social discomfort if they declined last time |
| **Value received** | Continuity; a relationship that survived an absence |
| **Organisation must provide** | **H-12** friendship infrastructure; **H-18** paused/alumni status so absence is a comma; **H-17** the right to reduce participation without explanation |
| **Abandonment cause** | Being treated as a defector for having a life. Stress test F-04 and **[X-inherited: relocation and busyness are leading exit reasons]** |
| **Evidence of success** | **HM-9** voluntary return within a defined window — **the stress test's chosen metric: second contribution within 30 days, not member conversion [S-ST: §21.3]** |

### STAGE 7 — DEVELOP

| | |
|---|---|
| **What they see** | A training module they want, a slightly harder task, a credential they can keep, a specialist route that does not require managing people |
| **What they do** | Learns; takes on scope. **Level 3–4**, possibly 5 |
| **Friction** | Training treated as a gate rather than a gift — **[S-ST: §21.2]**: attending a training module is the *worst* first win because it is slow, invisible and produces no result; cost and time; certification barriers in regulated domains **[V]** |
| **Value received** | Capability; a portable record; increased scope without increased rank |
| **Organisation must provide** | **H-10** portable credentials; **H-11** specialist path; **H-23** modes; training as a *reward for contribution* rather than a *precondition of participation* |
| **Abandonment cause** | Being told they must complete the full lifecycle to do anything more **[S: Ch.12]** — i.e. the single-door problem again |
| **Evidence of success** | **HM-10** skills/credentials issued and used; scope growth without role growth |

### STAGE 8 — BELONG

| | |
|---|---|
| **What they see** | People who know their name, a team that stays the same, rituals that are theirs, a local identity that is not a national abstraction |
| **What they do** | Shows up when nobody asked; brings someone; defends the team's reputation |
| **Friction** | Team reshuffling; cliques and exclusion (a documented exit driver **[X-inherited: S-ST §6.2 row 3 / §7.3 item 7]**); a culture that feels owned by its founders; social homogeneity |
| **Value received** | The second clause of §3: *I was not alone in it* |
| **Organisation must provide** | **H-12** stable teams and pairing; **H-13** rituals under six tests; **H-16** community charter; §19 belonging instruments; §20 anti-cult limits so belonging never becomes captivity |
| **Abandonment cause** | Feeling like an outsider inside the group; discovering that belonging is conditional on agreement |
| **Evidence of success** | **HM-3** belonging: can they name two people here? **HM-13** dignity and respect reported by participants *and* beneficiaries |

### STAGE 9 — LEAD

| | |
|---|---|
| **What they see** | A role with real scope, real accountability, a named predecessor, and a stated hour expectation |
| **What they do** | Takes responsibility. **Level 6–7** |
| **Friction** | The tournament bottleneck — leadership is the scarcest reward and attracts the highest proportion of the wrong people per unit of appeal **[S-ST: §6.2 row 10, F-24]**; no bench; fear of the compliance load (v1.3-B §25) |
| **Value received** | Authority, scope, recognition, and (where approved) compensation |
| **Organisation must provide** | Successor-before-transition (**v1.3-B B-18**); bounded delegation **[S: Ch.10]**; the full verification lifecycle **[S: Ch.12]**; leadership and finance-integrity training; §44 recognition that is not rank-addictive |
| **Abandonment cause** | Promotion into an unsupported, overloaded, socially-frictioned control role (v1.3-B §25.5, HC-18) |
| **Evidence of success** | **HM-10** leadership pipeline: a named successor exists per role; a transition completed without collapse |

### STAGE 10 — BUILD

| | |
|---|---|
| **What they see** | A chance to start something — a team, a venture, a workstream, a standard change — inside rules they can read |
| **What they do** | Creates. Sponsors others. **Level 8** |
| **Friction** | Approval latency; capital (v1.3-B §9.6); governance load; the founder-concentration problem (**v1.3-A A-12/A-16**) |
| **Value received** | Ownership within limits; the deepest form of the proposition — *we* reached someone |
| **Organisation must provide** | Venture lifecycle **[S: Ch.17]**; autonomy readiness gates **[S: Ch.13]**; **v1.3-A A-13** mission lock so building cannot become capture; **v1.3-B B-07/B-23** economic gates; a standard-change request route (**[S-ST: M23, F-13]**) |
| **Abandonment cause** | Discovering that "build" means "implement someone else's design" |
| **Evidence of success** | New teams formed by people who were not appointed; standards amended through the request route; **HM-15** replication evidence (v1.3-B §30 Stage 6) |

## 4.2 The three rules that make this a journey rather than a funnel

**[P]**

1. **Nobody is required to progress.** §8 establishes six legitimate endpoints. Stage 5 (experience impact) is a **complete and successful journey** for most people who ever touch the organisation — and §35 shows that is by design, not by failure.
2. **Every stage has a legitimate exit.** §21: reduce, pause, leave, return, change role, change team, refuse. An exit at Stage 4 is recorded neutrally, never as a failure or a defection.
3. **The organisation measures *stage completion*, never *stage conversion*.** **[S-ST: §21.3]** makes the point exactly: measuring conversion directly "causes the organisation to sell membership during the first win, which destroys the win." §36 therefore defines funnel **variables** and explicitly refuses conversion **targets**.

## 4.3 Where the journey actually breaks

**[A]** Ranked by how early and how silently the break occurs:

| Rank | Break point | Why | Instrument |
|---|---|---|---|
| **1** | **Stage 1→2: nothing to see** | No visible local output means no curiosity. An organisation that has not yet done anything in a locality has no Stage 1 | §38 first community loop; §40 small-promise sequence |
| **2** | **Stage 2→3: the first available action is an application** | **[S: Ch.12]** "application starts a verification process; not entitlement to join" is integrity-first and conversion-fatal **[S-ST: §20.3]** | **H-02/H-05**: value before vetting; verification only when responsibility is requested |
| **3** | **Stage 5→6: the outcome is never returned** | The most silent break. The person helped; nobody told them what happened; they concluded it did not matter | **H-15** attribution loop; §18 follow-up |
| **4** | **Stage 6→7: development is a gate, not a gift** | Training is front-loaded as a precondition **[S-ST: §21.2]** | **H-10**; train *for the task at hand*, certify *for the path chosen* |
| **5** | **Stage 8→9: the tournament bottleneck** | Leadership is the only visible progression, and it is scarce | **H-11** specialist path; §8 lateral endpoints |
| **6** | **Stage 3→4: being left alone** | Belonging is produced by a person, not a programme **[S-ST: §7.3 item 1]** | **H-06** Paired First Task with **two** existing members |

---

# 5. FOUR DOORS

## 5.1 The doors

**[S-ST: §6.3]** proposed four doors. **[A]** This instrument tests whether they genuinely cover different motivations, and develops each.

| | **DOOR 1 — PURPOSE** | **DOOR 2 — PROOF** | **DOOR 3 — LIVELIHOOD** | **DOOR 4 — BUILDING** |
|---|---|---|---|---|
| **The sentence** | "I want to help." | "I have skills, experience or contribution to offer." | "I want meaningful work or economic opportunity." | "I want to build the organisation itself." |
| **Core motivation** | Meaning, contribution, belonging, seva | Competence, credential, recognition, evidence of capability | Income, stability, dignity of paid work, a reference | Ownership, scope, legacy, ambition |
| **Who arrives here [H]** | Retirees, students, homemakers, faith-motivated individuals, people after a personal loss, new residents | Students, job-seekers, professionals, specialists, returning homemakers, creators | Unemployed and underemployed youth, gig and informal workers, skilled tradespeople, part-time seekers | Entrepreneurs, shopkeepers, SME owners, ambitious members, retired officials, technologists |
| **Entry activity** | One supervised community activity; reporting a need | One scope-bounded contribution with a verified record | One paid task under the approved formula | One proposal: a venture, a workstream, a team, a standard change |
| **Possible participation** | Observe; learn; attend; contribute occasionally; support a cause | Specialist contribution; skill verification; project contribution; service record; credentials | AI business; paid work; project work; training; skill development; customer delivery | Coordination; planning; leadership; operations; technology; training; business development; community building |
| **Typical levels (§6)** | L0–L3, sometimes L4 | L2–L4, often remote; L5 if they take a role | L5 (compensation attaches to verified work **[S: Ch.18]**); L3–L4 **not permitted for commercial work** **[S-ST: §9.3]** | L5–L8 |
| **What they receive** | Meaning, company, visible local result | **A record they can carry** — the most under-exploited asset **[S-ST: §6.2 row 6]** | Pay under a worker-first waterfall with a published formula and audit trail **[S: Ch.18–19]** | Scope, ownership, upside inside rules **[S: Ch.17; App. A §16.1]** |
| **What must be true** | No recruitment pressure; time-bounded; family-compatible | The credential must actually be usable outside (**H-10**, §25) | **Earnings reality disclosed in writing before joining** (**[S-ST: M16]**; v1.3-B §12.6 rule 2) | Approval tiers, economic gates (v1.3-B B-07), mission lock (v1.3-A A-13) |
| **Principal risk** | Being treated as a recruitment funnel; guilt appeals (§3.4 PM-3) | Free labour with an unrecognised certificate | **F-02**: income promise not kept → "scheme" accusation | **F-17** mission drift; capture of the builder class |
| **Guard** | §16 separation from beneficiary recruitment; §34 prohibited emotions | **H-10** portability test; §23's proof/credential separation | **H-21** anti-MLM firewall; v1.3-B B-05/B-06/B-13 | §20 anti-cult; §44 recognition limits; v1.3-A A-12/A-16 |

## 5.2 Do the four doors genuinely cover different motivations?

**[A]** Tested against the stress test's 18-motivation inventory **[S-ST: §6.2]**:

| Motivation | Door | Note |
|---|---|---|
| Purpose / meaning | D1 | |
| Contribution efficacy | D1 (and D2 when evidenced) | **The proposition of §3 lives here** |
| Belonging / friendship | **D1 primarily — but it is not a door, it is an outcome** | **[A] Important correction:** belonging is not a reason people *arrive*; it is a reason they *stay*. No door should advertise it, because "come make friends" attracts the socially lonely into a service organisation, which is a safeguarding risk (§20, §48–49) |
| Local identity / pride in place | D1 | Free and strong in India **[S-ST: §6.2 row 4]** |
| Learning and skills | D2 | |
| Verifiable credential / proof of work | **D2** | The distinct and largest reachable population **[S-ST: §6.3]** |
| Earning / livelihood | D3 | **Double-edged: must be truthful and never the headline** **[S-ST: §6.2 row 7]** |
| Entrepreneurship / building | D4 | Also the engine of mission drift |
| Recognition / status | **Cross-cutting — not a door** | **[A]** Status is a *retention* mechanism (§23), not an *acquisition* one. Advertising status attracts the wrong people **[S-ST: §6.2 row 9]** |
| Leadership / authority | D4 | Scarcest reward; highest wrong-person ratio |
| **Protector identity** | **NO DOOR — PROHIBITED** | **[S-ST: §6.2 row 11]** rated ⚠️❌: "the most emotionally powerful appeal available and the most dangerous… must never be used in recruitment." Reinforced by **v1.3-A A-07/A-08** |
| Network access / business contacts | D4 (secondary) | Chamber-of-commerce drift risk |
| Religious merit / seva | **Individually accepted, never institutionally invoked** | **v1.3-A A-05**; **[S-ST: §6.2 row 13]** |
| Grief / loss transformation | **D1 — with care, never recruitment** | **[S-ST: §6.2 row 14]**: "one of the most committed volunteer populations… also one of the most fragile. Requires care, not recruitment" |
| Family / intergenerational duty | **D1 — as a design property, not an appeal** | §19.3 family-legibility; §48–49 |
| **Fear / protection membership** | **PROHIBITED** | **[S-ST: §6.2 row 16]** ❌ |
| **Belief in the founder personally** | **PROHIBITED** | **[S-ST: §6.2 row 17]** ❌; **v1.3-A A-16** |
| **Anger / opposition to an enemy** | **PROHIBITED** | **[S-ST: §6.2 row 18]** ❌; §52 no-enemy rule |

**[C] Verdict: the four doors are sufficient for *acquisition* and correctly exclude the three corrosive motivations.** Two refinements are required:

1. **Belonging and recognition are not doors.** They are **retention mechanisms** and must be moved out of acquisition messaging (§26, §23). Advertising them at the door attracts dependency rather than contribution.
2. **Three motivations have no door and must have none**: protector identity, fear-based membership, founder belief. **§20 makes their absence a prohibition rather than an omission.**

## 5.3 The design insight the doors depend on

> **[S-ST: §6.3]** "**All four doors lead into the same verification spine.** Multiple entry motivations, one integrity standard. Today the architecture has one door (Verified Member) with four rooms behind it. **Inverting this — four doors, one spine — is the highest-leverage adoption change available and requires no weakening of any control.**"

**[A]** This instrument adopts that inversion as **H-01/H-02**, with the three rules that make it safe **[S-ST: §9.2]** preserved verbatim: responsibility begins at Level 5 and nowhere below; restricted tasks require role-specific training regardless of level **[S: Ch.9]**; data collected matches responsibility.

**[A] And the economic consequence, which v1.3-B supplies:** the four-door model is not only an adoption instrument, it is the **only** way a Mohalla team reaches the delivery capacity its break-even requires. v1.3-B §17.2 showed `P_max` capped by available trained people; §6 showed that verification, service and governance hours come from the same pool. **Doors 2 and 4 are how that pool is filled without lowering the integrity standard.** The human system and the economic system are the same problem seen from two sides.

---

# 6. PARTICIPATION SPECTRUM

**Basis:** **[S-ST: §9.1]** proposed the nine levels. This instrument develops each against the twelve attributes your brief specifies, and adds the Elder/Mentor standing. **Status: `PROPOSED — REQUIRES FINAL APPROVAL`, with [V] as noted.** The levels are a **clarification of latent design**, not a change: the vacancy record already distinguishes "volunteer, paid, mixed, stipend/contract/employee" **[S: Ch.19 template as cited in S-ST §9.2]** and eligibility already contemplates "membership status appropriate to task" **[S-ST: §9.2]**.

**Naming discipline (H-02, [S-ST: §9.3]):** the word **"Member" is reserved for Level 5 and above.** Levels 0–4 are *observer, participant, contributor, volunteer, specialist*. Enforced in all communications per **[S: Ch.24]**. Levels 0–4 are **never ranked publicly** — no badges, no leaderboards, no ordinal titles.

## 6.1 LEVEL 0 — OBSERVER / WELL-WISHER

| Attribute | Content |
|---|---|
| **Purpose** | To exist as a legitimate relationship for people who support the mission without participating — including the majority of any locality |
| **Permissions** | None in any system. May receive public information |
| **Responsibilities** | None |
| **Access** | Public channels only: the local page (H-03), published reports **[S: Ch.24]**, public complaints route |
| **Verification** | **None.** No record required to be an observer |
| **Data access** | None |
| **Financial access** | None. May give a donation, which is handled under **[S: SOP-07]** with donor, restriction, receipt, storage, allocation and report |
| **Organisational authority** | None |
| **Expected behaviour** | None. Nobody owes the organisation anything at Level 0 |
| **Exit path** | Nothing to exit — unsubscribe from communications on request |
| **Advancement path** | Optional, explicit, separate application to L1/L2 with its own consent (**no automatic progression**, [S-ST: §9.3]) |
| **Lateral path** | May become an institutional partner, a customer of the venture pillar, or a sceptic deliberately served **[S-ST: §8 last rows]** — none of which requires membership |

## 6.2 LEVEL 1 — COMMUNITY PARTICIPANT

| Attribute | Content |
|---|---|
| **Purpose** | To let a person take part in one supervised open activity, raise a need, or receive help — **without joining anything** |
| **Permissions** | Participate in a listed open activity; submit a need; receive an acknowledgement with a reference number and expected response time |
| **Responsibilities** | Follow the safety instruction given on site; nothing else |
| **Access** | Own participation record only, if any record exists |
| **Verification** | **Minimal: name + contact + consent. No identity documents** **[S-ST: §9.1]** — collecting ID from a person who came once to plant trees is a privacy failure *and* an adoption killer **[S-ST: §9.2 rule 3]** |
| **Data access** | None. Their own data is held under v1.3-A A-17 classification and A-18 minimisation, and is **deletable on request at this level** **[S-ST: §9.3]** |
| **Financial access** | None |
| **Organisational authority** | None |
| **Expected behaviour** | Ordinary courtesy. The organisation's conduct rules apply to *its* people, not to a person who attended once |
| **Exit path** | Walk away. No process, no record of "leaving", no follow-up pressure |
| **Advancement path** | To L2 by choosing a defined contribution; to L3 by opting into recurring, trained volunteering |
| **Lateral path** | May remain L1 indefinitely and be a **beneficiary** — §16 governs the beneficiary↔participant relationship and forbids recruitment at the moment of need |

## 6.3 LEVEL 2 — CONTRIBUTOR (single act)

| Attribute | Content |
|---|---|
| **Purpose** | To let a person give **one defined thing** — one hour, one skill, one item, one introduction, one idea, one session |
| **Permissions** | Own contribution record; may be named in a *narrative* acknowledgement ("these forty people cleaned the lane"), never in an ordinal ranking |
| **Responsibilities** | Complete the single act they accepted; follow the task briefing |
| **Access** | Own contribution record |
| **Verification** | Identity **for the record only where the contribution must be attributed**; otherwise self-declared **[S-ST: §9.1]** |
| **Data access** | None beyond their own record |
| **Financial access** | None. May receive reimbursement of an approved, receipted expense under **[S: SOP-08]** |
| **Organisational authority** | None |
| **Expected behaviour** | Honesty about what they did. **Over-claiming is corrected, not punished** (§43 psychological safety) |
| **Exit path** | The act is complete; nothing to exit |
| **Advancement path** | To L3 by choosing recurrence; to L4 if the contribution was professional |
| **Lateral path** | May remain a one-time contributor for life. **This is a complete and successful participation** (§8.2) |

## 6.4 LEVEL 3 — VOLUNTEER (recurring)

| Attribute | Content |
|---|---|
| **Purpose** | Repeated, scheduled, supervised contribution — the workhorse of the service mission |
| **Permissions** | Own tasks, own schedule, own record; may be paired with newcomers (**H-06** requires L3+ to accompany L1–L2) |
| **Responsibilities** | Attend as agreed or give notice; complete task-specific training for the tasks they actually do; follow safety doctrine **[S: Ch.16]** and the DO-NOT list (**v1.3-A A-08**, which binds every level) |
| **Access** | Own tasks, schedule and record; team-level public information |
| **Verification** | **Identity verification + task-specific training + safeguarding where relevant** **[S-ST: §9.1]** — note this is *task*-specific, not the full L5 lifecycle |
| **Data access** | None beyond own records. **May not access beneficiary records** (v1.3-A A-18/A-19 access separation) |
| **Financial access** | None. Expense reimbursement only **[S: SOP-08]** |
| **Organisational authority** | None. **May not verify others, approve anything, publish anything, or hold money** (§7) |
| **Expected behaviour** | Reliability within the stated time contract; the time contract must be explicit (**H-23**, **[S-ST: §7.3 item 3]**) |
| **Exit path** | Reduce, pause (**H-18**), or leave — with an exit conversation offered, never compelled (§21) |
| **Advancement path** | To L4 (specialist) or L5 (Verified Member) — **each an explicit, separate, opt-in application with its own consent** **[S-ST: §9.3]** |
| **Lateral path** | Change team, change activity type, change cadence, change mode (local/remote, §50) |
| **Hard limit** | **Levels 1–4 may not be assigned to commercial venture work. Ever.** Commercial work requires L5+ with the compensation framework applied **[S-ST: §9.3]** — reinforced by **v1.3-B B-09 rule 3** |

## 6.5 LEVEL 4 — SPECIALIST (professional)

| Attribute | Content |
|---|---|
| **Purpose** | To let a professional contribute licensed or expert capability under a bounded, time-limited engagement — **including entirely remotely** (§50) |
| **Permissions** | Scope-limited; **may advise; may not command** **[S-ST: §9.1]** |
| **Responsibilities** | Deliver within the agreed scope; declare conflicts; respect the professional-validation boundary — **internal training is not legally sufficient for first aid, emergency response, security, labour, child safeguarding, medical, counselling, legal or regulated activities [S: Ch.12]** |
| **Access** | Scope-limited, case-scoped where sensitive (v1.3-A A-20 §19.2 model) |
| **Verification** | **Professional credential verification + conflict declaration + scope agreement** **[S-ST: §9.1]** |
| **Data access** | Only what the scope requires, at the classification the scope permits (**v1.3-A A-17 C1–C4**), with reason codes and expiry |
| **Financial access** | None custodial. May be paid as an approved direct cost under **[S: Ch.18 priority 3; App. A §14.3 "subcontracted approved services"]** — **which makes this the one pre-L5 level that can lawfully be paid, and it is paid as a supplier, not as a member** |
| **Organisational authority** | **Advisory only; never custodial** **[S-ST: §9.1]** |
| **Expected behaviour** | Stay inside scope. A specialist who begins directing operations has become a role-holder and must go through L5 |
| **Exit path** | The engagement ends. Record of the contribution persists (H-09) |
| **Advancement path** | To L5 if they want a role; **not required** |
| **Lateral path** | Multiple concurrent scopes; different teams; different cities; State specialist pool **[S: Ch.6]** |
| **Guard** | A **cap on specialist-held coordinator positions per team** to prevent professional capture of priorities **[S-ST: §9.3]** |

## 6.6 LEVEL 5 — VERIFIED MEMBER

| Attribute | Content |
|---|---|
| **Purpose** | **The architecture's existing spine** — and the entry point to responsibility |
| **Permissions** | Role-based RBAC per **[S: Ch.23]** |
| **Responsibilities** | The full set attaching to their role; conduct rules **[S: SOP-17, SOP-18]** |
| **Access** | Per role and per classification |
| **Verification** | **Full lifecycle: application → screening → identity verification → interview → training → probation → role [S: Ch.12; SOP-01…SOP-04]** |
| **Data access** | Per RBAC and v1.3-A A-17 classification; **sealed categories remain case-scoped (A-20)** |
| **Financial access** | **Begins here.** Compensation for verified work **[S: Ch.18 priority 1; Ch.19 step 7]**; expense approval per role; **segregation of duties applies — no single person receives money + approves expense + records + audits [S: Ch.18]** |
| **Organisational authority** | Per role, within recorded limits **[S: Ch.9]** |
| **Expected behaviour** | Full conduct, safety, privacy and evidence duties |
| **Exit path** | §21: reduce, pause, leave, return; credentials and records per §21.4 |
| **Advancement path** | To L6 (Coordinator) by workstream ownership; to L7 (Leader) by the vacancy lifecycle **[S: Ch.11]** |
| **Lateral path** | **Specialist track (H-11) — increasing responsibility without becoming a general manager**; change team; change role family; Elder/Mentor standing (§6.10) |
| **Note** | **Nothing in v1.2 changes here.** L5 is the existing Verified Member, unmodified |

## 6.7 LEVEL 6 — COORDINATOR

| Attribute | Content |
|---|---|
| **Purpose** | Own a workstream under a primary or sub-role — "recruitment, schedule, issue, platform, QA or documentation" **[S: Ch.10]** |
| **Permissions** | Workstream-scoped, RBAC-limited |
| **Responsibilities** | The workstream's output and records |
| **Access / data / financial** | Workstream-scoped; financial access only as the role permits, never self-approval **[S: Ch.18]** |
| **Verification** | Full L5 lifecycle **+ role training** **[S-ST: §9.1]** |
| **Organisational authority** | **Delegated and bounded**; delegation recorded with start/end/reviewer **[S: Ch.10, Ch.22]** and expiring automatically **[S: Ch.33 delegation expiry PROPOSED]** |
| **Expected behaviour** | Own the workstream; escalate what exceeds it **[S: Ch.7 escalation map]** |
| **Exit path** | Step down from the workstream **without leaving the organisation** — §8.3's decline-a-role right |
| **Advancement path** | To L7 via the vacancy lifecycle and eligibility engine **[S: Ch.11]** |
| **Lateral path** | Different workstream; different team; specialist track |

## 6.8 LEVEL 7 — LEADER (primary or sub-role)

| Attribute | Content |
|---|---|
| **Purpose** | Accountable owner of a function or team — "one role → one primary holder" **[S: Ch.10]** |
| **Permissions** | Full role authority within stated limits **[S: Ch.9 authority-limits column]** |
| **Responsibilities** | Function outcomes, people, money integrity, safety, evidence, reporting |
| **Access / data / financial** | Per role and classification; **Funds Manager may record, prepare, request receipts and flag anomalies; cannot self-approve, release reserves, change formula or audit own final work [S: Ch.18]** |
| **Verification** | Full lifecycle **+ leadership, safety and finance-integrity training + conduct clearance** **[S-ST: §9.1]** |
| **Organisational authority** | Role authority; **not** constitutional authority — reserved matters per **v1.3-A A-13/A-14** |
| **Expected behaviour** | Model the culture; **create belonging, not dependency** (§57 pilot question 12) |
| **Exit path** | §21 plus **v1.3-B B-18/B-19**: successor-before-transition, overlap, bounded mentorship, local interim authority order |
| **Advancement path** | Head Team / City / State / National opportunity **[S: Ch.26; App. A §1.1]** — **with the promotion tax mitigated per v1.3-B B-18** |
| **Lateral path** | **Elder/Mentor standing (§6.10); specialist track; a different leadership family** |
| **Guard** | Leader differential must be "transparent, capped or bounded… justified by verified leadership work rather than status alone" **[S: App. A §15.3]**; multiplier **NOT FINAL [S: Ch.33]** |

## 6.9 LEVEL 8 — ORGANISATIONAL BUILDER

| Attribute | Content |
|---|---|
| **Purpose** | Create new teams, ventures, systems and partnerships; sponsor others |
| **Permissions** | Cross-team, **with charter limits** |
| **Responsibilities** | The viability and integrity of what they build; sponsorship obligations toward the teams they seed |
| **Access / data / financial** | Enhanced, with **enhanced oversight** **[S-ST: §9.1]** |
| **Verification** | Full lifecycle **+ track record + audit clearance + Council/CEO process** **[S-ST: §9.1]** — and the Council's authority is itself **UNRESOLVED [S: Ch.33; v1.3-A N19]** |
| **Organisational authority** | Delegated creation authority; **never constitutional amendment authority** (v1.3-A A-13 reserved matters) |
| **Expected behaviour** | Build replicably — v1.3-B §30 Stage 6 requires proof in a *different* neighbourhood |
| **Exit path** | §21 with an enhanced handover per **v1.3-A A-14** master handover checklist |
| **Advancement path** | None required. **L8 is an endpoint, not a rung** |
| **Lateral path** | Different build; different state; Council-adjacent advisory |
| **Guard** | **The builder class is the highest capture risk in the model.** §20 and v1.3-A A-12/A-16 apply with full force |

## 6.10 ELDER / MENTOR STANDING (proposed, non-command)

**[S-ST: §9.1, §7.3 item 12]** — carried forward and developed.

| Attribute | Content |
|---|---|
| **Purpose** | To keep long-serving members useful **without** giving them command — and to let knowledge survive turnover |
| **Who** | Long-serving members, at any level from L3 upward, recognised by the team and recorded |
| **Functions** | Teaches; verifies by witness; mediates; holds local memory; blesses new teams; sits with newcomers; contributes to oral history (**v1.3-A A-15 M7**) |
| **Explicit exclusions** | **Excluded from RBAC command permissions and from scoring** **[S-ST: §9.1]**; may not approve money, appoint, discipline, publish or override a role-holder |
| **Why it matters** | It is the **lateral endpoint** that makes §8 credible: a sixty-year-old with no ambition to manage can hold real standing. It also solves the elder-participation problem (§49) and the institutional-memory problem (**v1.3-A A-15**) with one instrument |
| **Guard** | Standing is **recognised, not ranked** — it confers no ordinal position and appears on no leaderboard (§23, §44) |
| **Status** | `PROPOSED — REQUIRES FINAL APPROVAL`; **[V]** where mediation touches conduct or grievance process |

## 6.11 Spectrum-wide rules

**[P]** Six rules that apply across all levels:

1. **No automatic progression.** Upgrading is always an explicit, separate, opt-in application with its own consent **[S-ST: §9.3]**.
2. **Data collected matches responsibility** — L1 needs name/contact/consent; L5 needs the full HR record. Purpose limitation and re-consent on upgrade; deletion on request at low levels; retention per schedule at L5+ (**v1.3-A A-17 P2, A-18**).
3. **Levels 0–4 are not ranked publicly** — no badges, no leaderboards, no ordinal titles. Recognition at these levels is **narrative**, never ordinal.
4. **One word, one meaning** — "Member" = L5+. Enforced in all communications **[S: Ch.24]**.
5. **Task responsibility always sits with a Verified Member.** Any L1–L4 task is assigned *through* an L5+ person who is recorded as responsible **[S-ST: §9.3]** — which prevents a shadow unverified workforce.
6. **The spectrum adds nothing to the permission surface below L5.** Money, HR records, safety decisions, verification of others, publications and appointments all remain behind the existing full lifecycle **[S-ST: §9.2 rule 1]**.

---

# 7. CRITICAL SECURITY BOUNDARY

## 7.1 The boundary, preserved

**[S-ST: §9.2]** — carried forward unchanged:

> **Responsibility begins at Level 5 and nowhere below.** Money, HR records, safety decisions, verification of others, publications, appointments — all remain behind the existing full lifecycle.

Levels 0–4 receive **no** organisational command authority, **no** sensitive data access, **no** financial authority and **no** operational control — **unless another existing architecture explicitly requires otherwise.**

## 7.2 Where existing architecture does require otherwise

**[A]** Your brief's exception clause must be honoured rather than ignored. Four cases exist:

| Case | Source | Effect on the boundary |
|---|---|---|
| **A specialist is paid as an approved direct cost** | **[S: Ch.18 priority 3; App. A §14.3 "subcontracted approved services"]** | L4 may receive money **as a supplier**, never hold or approve it. Custodial authority remains L5+ |
| **A trained volunteer gives first aid** | **[S: Ch.16 "physical intervention only when reasonably necessary… first aid if trained"]** | Task-specific, training-gated, **not** command authority. v1.3-A A-09 §8.2 preserves it |
| **Any person calls the emergency authorities** | **[S: Ch.16]**; **v1.3-A §10.5 citizen-conduct preservation** | Preserved at every level including L0. **This is a duty of citizenship, not an organisational permission** |
| **A contributor's expense is reimbursed** | **[S: SOP-08]** | Approved by an L5+ Funds role; the contributor holds nothing |

**[A]** In all four, the exception is **task-scoped, training-gated and non-custodial.** The boundary is intact.

## 7.3 "DO NOT TURN LEVEL 0–4 INTO LESSER PEOPLE"

**[A]** Your brief states this as an absolute rule. It is the hardest design constraint in this instrument, because a permission hierarchy *looks* like a status hierarchy and will be *felt* as one unless the difference is engineered into every instrument. **[P] Seven rules:**

| # | Rule | Instrument |
|---|---|---|
| **SR-1** | **The levels describe what a person may touch, never what a person is worth.** This sentence is published wherever the levels are published | H-02; §6 preamble |
| **SR-2** | **No ordinal language in public.** Levels are never displayed as a ladder, a rank, a tier number or a badge. Externally there are only *participant, volunteer, specialist, member* | H-02 naming discipline **[S-ST: §9.3]** |
| **SR-3** | **Recognition at L0–L4 is narrative, never ordinal.** "These forty people cleaned the lane" — never "contributor #4,231" | H-08; §23 |
| **SR-4** | **A one-time contribution is a complete participation, not a failed membership.** §8.2 lists it as a legitimate endpoint | H-07 |
| **SR-5** | **No benefit of the commons is conditional on level.** A person at L0 who reports a need receives the same verification, the same priority assessment and the same dignity as a member's relative. Priority is set by **[S: Ch.8 step 5]** criteria — urgency, vulnerability, resources, expected impact, safety risk, feasibility — **none of which is level** | §38; §16 |
| **SR-6** | **No language of "just".** "Just a volunteer", "only a participant", "not yet a member" are prohibited internal phrasings, on the same basis as v1.3-A A-19's dignity rules | H-07; §34.3 (shame prohibited) |
| **SR-7** | **The verification burden falls on the organisation, not the person.** Levels 1–2 must not be made to prove anything; the *organisation* must prove its own case when it asks for more data | H-02; **v1.3-A A-18** minimisation |

## 7.4 Why the boundary is a *human* instrument and not only a security one

**[A]** Three effects, in order of importance:

1. **It makes the low levels safe to enter.** A person who knows that joining a clean-up will not give anyone access to their documents, will not put them on a list, and will not obligate them to anything, will come. **The boundary is the adoption mechanism.**
2. **It makes the high levels meaningful.** Responsibility that anyone can obtain is responsibility nobody values. Keeping custody behind verification is what makes L5+ a *trust* rather than a *formality* — consistent with **[S: Ch.2 "responsibility follows earned trust"]**.
3. **It prevents the two worst abuses at once:** a shadow unverified workforce doing restricted tasks, and a data estate built from people who only came once (**v1.3-A A-17/A-18**).

---

# 8. NO FORCED PROGRESSION

## 8.1 The principle

> **[P] A person can contribute meaningfully without becoming a leader.**
>
> **[A] And more strongly: most people who ever touch this organisation should never become members, and that is a design success rather than a conversion failure.** The stress test's library analogy is exact — "most people who benefit from a library are not librarians, and the library does not want them to be" **[S-ST: §8]**.

## 8.2 The six legitimate endpoints

| Endpoint | Who it is for | What a complete life at this endpoint looks like | Evidence it is legitimate, not residual |
|---|---|---|---|
| **COMMUNITY CONTRIBUTOR** (L1–L2) | Anyone who gave one hour, one item, one introduction, one idea | Reports a need once; joins one clean-up; donates one bag of clothes; introduces one shopkeeper. Never returns. **Complete** | §35: the last row of the citizen map — "People who will never join" — is *the strategic row* **[S-ST: §8 conclusion 1]** |
| **VOLUNTEER** (L3) | People who want recurring service without organisational responsibility | One activity a month for years; known by name; no role, no records duty, no score | H-23 cadence modes; §26 healthy retention |
| **SPECIALIST** (L4) | Professionals contributing bounded expertise, often remotely | Three scopes a year; paid as a supplier where applicable; advises, never commands | H-11 specialist path; §50 remote participation |
| **VERIFIED MEMBER** (L5, no role) | People who want full standing without management responsibility | Holds membership, takes tasks, is paid for venture work, votes nothing, manages nobody | §6.6 lateral path; **[S: Ch.10]** Supporting Members already exist as a category |
| **LEADER** (L6–L7) | People who want accountability | Owns a function; carries the compliance load; is succeeded properly | v1.3-B B-18/B-19 |
| **BUILDER** (L8) | People who want to create | Seeds teams and ventures; sponsors others; is audited | v1.3-B §30 Stage 6 |
| *(plus)* **ELDER / MENTOR** | Long-serving people at any level | Teaches, witnesses, mediates, holds memory; **no command, no score** | §6.10 |

**[A] Note what is missing from that list: there is no "top".** L8 is an endpoint, not a summit, and the Elder standing is available from L3 — which means **the most socially respected position in the design can be reached without ever managing anyone.** That is deliberate, and it is the structural answer to §44's status-addiction problem.

## 8.3 The rights that make endpoints real

**[P]** An endpoint is only legitimate if a person can *choose* it without cost. **H-17 — Right of Refusal**, seven components:

| Right | What it means | Limit |
|---|---|---|
| **Refuse a task** | Any person may decline any specific task, with or without a reason | A refusal inside an accepted, paid engagement is handled as a scope conversation **[S: Ch.17 step 4]**, not as misconduct |
| **Refuse a project** | May decline to be assigned | — |
| **Refuse paid work** | May decline venture work without affecting their standing as a volunteer | v1.3-B B-09 rule 2: service is never a condition of paid work, **and paid work is never a condition of standing** |
| **Refuse promotion** | **May decline a role and keep everything else** | §24 succession must then find another successor (v1.3-B B-18) |
| **Refuse leadership** | May decline permanently, and be recorded as "not available for leadership" so they are not asked repeatedly | — |
| **Refuse data collection** | May decline any data field not required for the task at hand | Statutory and safeguarding minima excepted **[V]** (v1.3-A A-18) |
| **Refuse publicity** | May decline to be named, photographed or mentioned in any story | **Absolute for beneficiaries** (v1.3-A A-19); for contributors, an absolute yes/no at the point of record |

**[A] The critical design point:** refusal must be **cheap, silent and non-recorded as a negative.** A refusal that requires an explanation, or that appears on a dashboard as a decline rate, is not a right — it is a friction with extra steps (§13).

## 8.4 No status hierarchy implying moral superiority

**[P]** Four prohibitions, all enforceable through communications discipline **[S: Ch.24]**:

1. **No instrument may describe leadership as a higher form of service.** Leadership is a **different** form of contribution with **more** accountability and **more** compliance load (v1.3-B §25.5) — not a better one.
2. **No ceremony, story, award or publication may rank endpoints against each other.** A twenty-year volunteer and a two-year team leader are both complete.
3. **The performance system may not be applied to endpoints.** **[S: Ch.25]** scores **teams**, not people, and its own rule forbids raw counts determining leadership. §44 keeps it that way.
4. **Recruitment language may not imply that joining is better than not joining.** The correct statement is the library one: **the organisation exists to be useful to people who never join.**

**[A] And one positive requirement:** the annual report **[S: Ch.24 annual cadence]** should publish **the count of people who helped once and never came back, presented as a success metric.** This is counter-intuitive and it is the cheapest possible proof that the organisation means what §8.1 says.

---

# 9. FIRST TEN SECONDS

> **Question: if someone encounters Sewak Sathi for ten seconds, what should they understand?** The answer must not require reading the constitution.

## 9.1 What they must understand — five things

**[P]** Derived from the stress test's misclassification map **[S-ST: §18.2]**, which identified what people will wrongly assume. The ten seconds must **pre-empt the wrong classification**, not merely state the right one.

| # | Must be understood | Because otherwise they assume | Source of the risk |
|---|---|---|---|
| **1** | **This is local** — people near me, doing something near me | A distant NGO or a national brand with no presence | **[S-ST: §19.1]** — NGOs are "absent from most neighbourhoods" |
| **2** | **This is practical** — a problem gets fixed | A talk-shop, a movement, a religious gathering | **[S-ST: §18.2]** |
| **3** | **This is open** — I could take part without joining anything | A closed membership body with vetting | **[S: Ch.12]** "not entitlement to join" |
| **4** | **This is not political and not religious** | A party cadre, a communal body | **v1.3-A A-01, A-05**; **[S-ST: F-08, F-36]** |
| **5** | **This is not a security force** | A vigilante group, a private guard, a political muscle | **v1.3-A A-06, A-07, A-08**; **[S-ST: F-09]** |

## 9.2 The one-sentence explanation

**[S-ST: §20.2]** — the drafted core sentence, carried forward **as a draft for approval, not adopted language**:

> **"Neighbourhood teams that fix local problems — verified, recorded, and paid fairly when the work earns."**

**[A]** Three properties make it work in ten seconds: it names the **unit** (neighbourhood teams), the **activity** (fix local problems) and the **integrity claim** (verified, recorded, paid fairly). It contains no abstract noun. **Design constraints preserved from the stress test:** the word **"AI" must not appear** in the ten-second version (it imports the wrong category) and the word **"protection" must not appear** (it imports the most dangerous category). **Both belong in the second conversation — this is sequencing of truth-telling, not concealment: the full description must be one tap away and must be complete.**

## 9.3 The "what we are not" line

**[S-ST: §20.2]** — printed smaller underneath, and now coupled to **v1.3-A A-07**, which requires limits to be stated **more loudly** than capabilities:

> *Not a political organisation. Not a religious organisation. Not a security agency. Not a job portal. Not a replacement for government.*

**[A]** Note the fifth item, which the stress test added and which is the most important for trust: **an organisation that does not claim to replace the state is an organisation an official can tolerate.** That is a legitimacy asset, and it costs nothing.

## 9.4 The participation invitation

**[P]** In ten seconds there is room for exactly one call to action, and it must satisfy three conditions: **no account, no document, no commitment.**

> **"Tell us a problem in your lane."** — or — **"Help once this week."**

**[A]** These are the two buttons the stress test specified **[S-ST: §20.3]**, and their order matters: **"report a need" first**, because it offers value *to* the person rather than asking value *of* them. An organisation whose first ask is "help us" has inverted the sequence.

## 9.5 The trust signal

**[P]** In ten seconds, trust is produced by **one specific, dated, nearby, verifiable fact** — never by an adjective.

| Trust signal | Works? | Why |
|---|---|---|
| A dated board at the site of completed work | **Best** | Physical, local, unfakeable, and it is *already* the evidence the architecture requires **[S: Ch.15; App. F]** |
| Three things this team did nearby, with dates, on one page | **Strong** | Verifiable and local **[S-ST: §20.3]** |
| A named person who answers | **Strong** | Trust is interpersonal before it is institutional (§40) |
| "Audited accounts published" | Medium — for officials, donors, partners | Not legible to a resident in ten seconds |
| Logos, awards, follower counts, celebrity endorsement | **Prohibited as primary signals** | **[S: Ch.25]**: follower counts and views cannot determine leadership; §39 forbids manufactured social proof |
| Adjectives: trusted, leading, biggest, most impactful | **Prohibited** | Unfalsifiable; and **v1.3-A A-07** requires under-claiming |
| Uniforms, insignia, ranks, formations | **Prohibited** | **v1.3-A A-06 V1–V3**: no uniform, no insignia; §53 "symbols must signal service, not force" |

## 9.6 Visual identity in ten seconds

**[A]** Constraints already fixed by prior instruments, and one gap:

| Element | Position | Source |
|---|---|---|
| **Name** | "Sewak Sathi Sanstha" is a **PROPOSED** public name; validation pending | **[S: Ch.33]** |
| **Clothing** | **No uniform, no insignia.** Identification is *carried, not worn*, task-scoped and removable | **v1.3-A A-06 V1–V7** |
| **ID card / QR** | **CONCEPT APPROVED** — minimal data, revocable token, **non-police visual design**; use restricted to five rules | **[S: Ch.33]**; **v1.3-A A-17 §16.4** |
| **Symbols** | Must signal service, not force. §53 develops the criteria | §53 |
| **Photography** | **No filming or photographing of incidents, victims, minors or beneficiaries**; no publication of incident material | **v1.3-A A-06 V24–V30, A-19** |
| **Colour, typography, logo** | **NOT DECIDED.** Nothing in the source specifies a visual system, and this document will not invent one | §53 |

**[A] The gap, stated honestly:** v1.3-A removed every *dangerous* visual signal and correctly so. **Nothing yet supplies a positive one.** A person cannot see the organisation and know what it is. §53 proposes the criteria and explicitly declines to design the artefacts, because a visual system chosen in a document rather than in a locality will be wrong in most localities (§31 localisation).

## 9.7 The ten-second test itself

**[P]** A repeatable test, to be run in the pilot (§57) rather than assumed:

1. Show a person in the target locality the artefact (board, page, stall, one sentence) for ten seconds.
2. Ask, in their language: *what is this? could you take part? is it political? is it religious? is it a security group? does it cost money?*
3. **Pass condition:** all six answered correctly, **without** the words "NGO", "party", "scheme", "security" or "company" appearing in their answer.
4. Record the wrong answers. **They are the design specification**, not a failure of the respondent.

**[H]** No claim is made that the current draft passes. It has never been shown to anyone.

---

# 10. FIRST FIVE MINUTES

## 10.1 The design principle

**[S-ST: §20.3]** — carried forward verbatim:

> **Value before vetting; contribution before commitment; a person before a process.** Nothing in these five minutes requires understanding the architecture.

## 10.2 The eight things a new person must understand

Your brief lists eight. Each is mapped to a moment and to an instrument:

| # | Must understand | Where in the five minutes | Instrument |
|---|---|---|---|
| **1** | What Sewak Sathi is | Minute 1–2 | One page, their language: the core sentence (§9.2) |
| **2** | What it does | Minute 1–2 | Three nearby things actually done, **with dates** |
| **3** | What they can do | Minute 2–3 | Two buttons: report a need / help once |
| **4** | **What they do not have to do** | Minute 2–3 | **An explicit absence-of-obligation statement** — "you are on the record for this; nothing further is expected" **[S-ST: §21.3]** |
| **5** | Whether participation costs money | Minute 1–2 | **A stated "no"** — participation is free; §38 lists what must always be free |
| **6** | Whether they must become a member | Minute 1–2 | **A stated "no"** — the "what we are not" line includes *not a membership scheme*; §6.1 L0 exists |
| **7** | How they can help | Minute 2–3 | A listed one-off task with time, place, duration and what to bring |
| **8** | What happens next | Minute 3–4 | A named person, a promised window, and an honest statement of limits |

**[A]** Items 4, 5 and 6 are the ones organisations omit, and they are the ones that decide whether the first five minutes feel like an opportunity or a trap. **All three are statements of what the organisation will *not* do** — which is why v1.3-A A-07's under-claiming posture is an adoption instrument, not only a safety one.

## 10.3 The five-minute sequence

**[S-ST: §20.3]**, carried forward and extended with the level and friction references this instrument adds:

| Minute | Stage | What happens | What must NOT happen | Level | Friction addressed (§13) |
|---|---|---|---|---|---|
| **0–1** | **Discovery** | They encounter a *result*: a cleaned lane with a dated board; a neighbour's remark; a stall with a photograph wall; a QR opening one page in their language | No form. No app download. No membership language. **No request for identity documents. No explanation of the hierarchy. No description of four pillars** | L0 | Discovery, technology, language |
| **1–2** | **Understanding** | One page in their language: core sentence, "what we are not", three nearby dated results, two buttons | No jargon. No role titles. No process diagram. **No 12-stage lifecycle, no constitution, no RBAC** | L0 | Role ambiguity, confidence |
| **2–3** | **First participation** | (a) submit a need in ~60 seconds — three fields: what, where, contact optional — and receive an acknowledgement with a reference number and expected response time; **or** (b) choose a listed one-off task happening this week | No verification. No commitment. **No account beyond a phone number.** No implication they must join. **No identity data collected** | L1 | Registration, identity, verification, financial |
| **3–4** | **Trust** | A **real named person** calls or messages within the promised window, explains what will happen, and says what the team *cannot* do ("we don't handle that — here's the municipal number") | No overpromising. No form. No silence. No broadcast message | L1 | Social, confidence |
| **4–5** | **Meaningful action** | Either they see their reported problem verified and scheduled **and are told the date**; or they spend ~90 minutes on a real task **alongside two existing members**, are thanked **by name**, are shown the before/after, and are told *"you're on the record for this — no obligation to do it again"* | No recruitment pitch. No membership form. **No group photo posted without consent** (v1.3-A A-19) | L2 | Time, family, social |

## 10.4 The single most important design decision

**[S-ST: §20.3]** — preserved, because everything else in this section depends on it:

> *The first action available must be either "tell us a problem" or "help once", and neither may require joining.* The current architecture's first available action is "application — begins verification; not entitlement to join" **[S: Ch.12]**. That is an **integrity-first design and a conversion-fatal one.** Both can be satisfied by the spectrum: **value first, verification only at the moment responsibility is requested.**

**[A]** This is not a weakening of **[S: Ch.12]**. The full lifecycle is preserved intact and remains the *only* route to L5+ responsibility (§7.1). What changes is that **the lifecycle is no longer the front door of the organisation.**

## 10.5 Five things the first five minutes must avoid

Your brief lists five; each is given an enforcement mechanism:

| Avoid | Why it kills participation | Enforcement |
|---|---|---|
| **Long forms** | Every field is a decision to continue; three is the maximum at L1 | H-02 rule: data collected matches responsibility; **v1.3-A A-18** minimisation test applied to the intake form |
| **Unnecessary verification** | Verification is a *cost to the person* — documents, time, exposure | §7.1 boundary; verification only at L3+ and only task-specific **[S-ST: §9.1]** |
| **Immediate recruitment pressure** | Converts an offer into a solicitation | §16.2; H-17; **[S-ST: §21.3]** "nothing further is expected" |
| **Forced commitment** | A commitment extracted in minute five is broken in week five | H-23 modes; the time contract stated as a *range* with an explicit pause right |
| **Ideological testing** | Belief screening is absolutely prohibited | **v1.3-A A-01 N8** — no question, test, inference or record about what a member *believes*, ever |

---

# 11. FIRST REAL WIN

## 11.1 Definition

> **FIRST REAL WIN — the earliest moment at which a participant can genuinely say "I did something useful."**

**[S-ST: §21.1]** criteria, carried forward and adopted: the first win must be **fast** (≤48 hours), **small** (≤2 hours), **visible** (a before/after exists), **safe** (no restricted task, no minors, no money, no conflict), **legal** (no permission needed, or permission already held), **social** (done *with* two existing members, not for them), and **recorded** (the person can see their name attached to a real outcome).

**[A]** Your brief's six adjectives map onto those seven criteria exactly: **real** = visible + recorded; **measurable** = recorded; **safe** = safe + legal; **voluntary** = no obligation statement; **achievable** = small + fast; **meaningful** = social + visible. **No new criterion is needed.**

## 11.2 Candidate first wins — proposals, not assumptions

**[S-ST: §21.2]** evaluated against the existing architecture, carried forward:

| Candidate | Verdict | Note |
|---|---|---|
| Neighbourhood clean-up of one defined stretch | **Best universal first win** | Already Scenario A in the source **[S: Ch.35]**; may need municipal permission **[V]** |
| Delivering a verified request (medicine pickup, grocery for an elderly neighbour, escort to a clinic) | **Best emotional first win** — highest trust produced per hour | Requires care with privacy and safeguarding (v1.3-A A-19, A-20) |
| One digital-literacy or homework-help session | **Best for students and professionals** | Two-adult rule where minors are involved **[V]** |
| Contributing one professional skill pro-bono (accounts, design, a legal opinion, a repair) | **Best for Specialists** — "the single most under-used resource in the model" | Needs scope discipline (L4 scope agreement) |
| Verifying one need (a site visit with a photo and a note) | **Best for people who want responsibility early** | **Observational only at L3** — verification of others is an L5 responsibility (§7.1) |
| Donating one item or one introduction | **Best zero-time entry** | Handled under **[S: SOP-07]** |
| Attending a training module | **Worst first win** — slow, invisible, no result | **This is what the architecture currently front-loads** **[S-ST: F-01]** |
| Applying for membership | **Worst possible first action** | Slow, extractive, no value delivered |

## 11.3 The recommended model

**[S-ST: §21.3]** — **H-06, the Paired First Task**, carried forward:

> A newcomer is matched within 48 hours to **one** small, safe, visible task, performed **alongside two existing members**, ending with a **before/after record** the newcomer can see and keep, and an explicit statement that **nothing further is expected.**

**Why paired:** belonging is produced by a person, not a programme — **the two existing members are the actual product being delivered; the task is the pretext.** **Why two:** it satisfies the two-adult rule where relevant, prevents isolation, and gives the newcomer two relationships instead of one. **Why "nothing further is expected":** it removes the pressure that makes first experiences feel like recruitment — and paradoxically that is what makes people return **[I; H]**.

## 11.4 The metric that matters

**[S-ST: §21.3]** — adopted as **HM-9**:

> **Percentage of first-time participants who complete a second contribution within 30 days.** *Not member conversions.*

**[A]** The reasoning is preserved because it is the discipline that keeps the whole human system honest: **"conversion is a lagging indicator of a good first win; measuring it directly causes the organisation to sell membership during the first win, which destroys the win."** §36 therefore forbids conversion targets at the entry stages.

**[P] Status:** the 30-day window is `PROPOSED — REQUIRES PILOT VALIDATION`. The window length must be tested against local rhythms — v1.3-B HC-15 notes festival and agricultural cycles, and a window that spans a harvest or an exam period will measure the calendar rather than the person.

---

# 12. FIRST THIRTY DAYS

**Rule from your brief, adopted:** timing is a **hypothesis**, not a schedule. Every interval below is `[H] / PROPOSED — REQUIRES PILOT VALIDATION`, and none may be published as a commitment.

## 12.1 The map

| | **DAY 0 — Discovery** | **DAY 1 — First participation** | **WEEK 1 — First contribution** | **WEEK 2 — Recognition / feedback** | **WEEK 3 — Skill / community development** | **WEEK 4 — Choice of next path** |
|---|---|---|---|---|---|---|
| **What happens** | They see a result in their lane, or hear a neighbour, or open one page | They submit a need **or** attend one listed activity | The Paired First Task (H-06): ~90 minutes, two existing members, a visible before/after | They are told what happened. **By name. By a person.** And they see their own record | They are offered — never assigned — one thing: a training module *for a task they want to do*, an introduction to two more people, or a slightly larger task | They are shown **four options, all equal**: do nothing more; come occasionally (L3); contribute a skill (L4); apply for membership (L5). **Plus the explicit right to decline all four** |
| **Level** | L0 | L1 | L2 | L2 | L2–L3 | L2 → any |
| **What the organisation must provide** | A visible dated local result; the public page (H-03); the ten-second standard (H-04) | A listed task with time, place, duration, what to bring; a named contact; ≤3-field intake | Two existing members who were told this is their job; task-specific briefing; a record the newcomer can see | **H-15 attribution**: the outcome, returned to the person who produced it, inside a stated window | One optional offer; no queue, no prerequisite, no form | A plain-language choice screen; the H-17 right of refusal stated aloud |
| **What must NOT happen** | A membership pitch; a form; an app requirement | Verification requests; identity documents; ideology questions | Being left alone; a restricted task; a task they were not briefed for | Silence. **This is the single most common quiet exit (§4.3 rank 3)** | Training presented as a gate; a mandatory module; a cost | Pressure; a default option; a deadline; a suggestion that not choosing is failing |
| **Value they receive** | Curiosity; a sense something local exists | Their need acknowledged with a reference number and a window, **or** immediate usefulness | Usefulness + two relationships | **The proposition of §3 becomes true for them personally** | Capability or connection, on their terms | Autonomy. The first experience of *choosing* rather than being processed |
| **Friction peak (§13)** | Discovery, language | Registration, identity, technology | Time, transport, confidence, role ambiguity | **Attribution silence** | Cost, scheduling, fear of commitment | Social pressure, fear of judgement |
| **Abandonment cause** | Nothing to see | A form, a document request, silence | Being alone; a task they were unprepared for; public correction | Never hearing the outcome | Being told they must complete the lifecycle to continue | Being recruited |
| **Success evidence** | HM-1 inbound contacts | HM-4 first participation completed | HM-5 contribution completed | **HM-7 attribution received within window** | HM-10 development activity taken up *voluntarily* | **HM-9 second contribution within 30 days**; HM-2 comprehension |

## 12.2 The three design rules of the first month

**[P]**

1. **The organisation gives something before it asks for anything.** Days 0–1 are pure delivery: their need is acknowledged, or a result is visible. The first *ask* is at Day 1 and it is optional and ninety minutes long.
2. **The outcome must be returned before the next invitation.** Week 2 precedes Week 3 and Week 4 by design. **Inviting someone before telling them what their last contribution achieved converts a relationship into a sales cycle** (§4.3 rank 3).
3. **Week 4 offers four equal options and an explicit right to decline all of them.** If the choice screen has a highlighted option, it is a recruitment funnel and H-07 has been violated.

## 12.3 What is deliberately absent from the first thirty days

**[A]** Five things, each a decision rather than an omission:

| Absent | Why |
|---|---|
| **Any payment conversation** | Money belongs to Door 3 and arrives on its own timetable. Introducing it in month one frames the relationship transactionally, and **culture formed under monetary framing resists re-framing** **[S-ST: §5 Scenario A]** |
| **Any verification beyond name and contact** | §7.1 boundary; **v1.3-A A-18** minimisation |
| **Any performance measurement** | **[S: Ch.25]** scores teams, not people; L0–L4 are never ranked (§7.3 SR-3) |
| **Any role title** | §7.3 SR-2: no ordinal language in public |
| **Any obligation** | The "nothing further is expected" statement is the product **[S-ST: §21.3]** |

---

# 13. PARTICIPATION FRICTION

## 13.1 The friction map

Your brief names fifteen frictions. Each is given a mechanism, a detector and a control. **Nothing here asserts a magnitude** — §58 measures them.

| # | Friction | What it actually feels like | Detector | Control | Instrument |
|---|---|---|---|---|---|
| **FR-01** | **Discovery** | "I have never heard of them" | HM-1 inbound contacts; unsolicited questions | Visible dated local results; §38 first community loop before any recruitment | H-03, H-04 |
| **FR-02** | **Registration** | "Why do they need all this?" | Intake abandonment; field count | **Maximum three fields at L1**; no account | H-02; §10.5 |
| **FR-03** | **Identity** | "Why do they want my documents?" | Document requests at L0–L2 (should be zero) | **No identity documents below L3** and only task-specific there | §7.1; **v1.3-A A-18** |
| **FR-04** | **Verification** | "How long will this take? Who sees it?" | Time from application to first task | Full lifecycle only at L5; L3 verification is task-specific | §6; **v1.3-A A-17 P3** plain-language notice |
| **FR-05** | **Transport** | "It is too far and too expensive" | Delivery distance of tasks; attendance by locality | Tasks within walking distance where possible; **no member funds operations personally** | **v1.3-B §12.6 rule 1, HC-03, B-15(2)** |
| **FR-06** | **Time** | "I do not have a whole day" | Task duration distribution | ≤2-hour first win; **stated hour ranges, never open-ended** | H-06; H-23 |
| **FR-07** | **Financial** | "Will this cost me?" | Any fee, purchase or expected expense at L0–L4 | **Participation is free; membership fees prohibited (§39.3); no mandatory purchase (H-21)** | §38; §22 |
| **FR-08** | **Social** | "I will not know anyone" | Whether a newcomer can name two people after week 2 (HM-3) | Paired First Task; stable teams | H-06, H-12 |
| **FR-09** | **Family** | "My family will object / I have care duties" | Participation by time-of-day and gender; drop-off after family events | Morning and weekend slots; near-home tasks; **family-inclusive events**; never "organisation above family" | H-23; §20.2 item 7; §48 |
| **FR-10** | **Technology** | "I do not have a smartphone / the app will not load" | Share of participation completed offline | **Paper-first and voice-capable routes; a phone number is sufficient; no app requirement at L0–L3** | H-24; §29.3 |
| **FR-11** | **Language** | "This is not in my language" | Language of first contact vs language of material | Three-layer language architecture; **meaning fixed, wording local; no publication without terminology review** | H-25; §30 |
| **FR-12** | **Confidence** | "I am not qualified / I will do it wrong" | First-task completion rate; self-reported confidence (HM-6) | Tasks matched to stated capability; **briefing before task, correction in private** | H-06; §43 |
| **FR-13** | **Role ambiguity** | "What exactly am I supposed to do?" | Questions asked on site; incomplete tasks | Every task has a one-line description: what, where, when, how long, what to bring, who to ask | H-06; §12.1 |
| **FR-14** | **Fear of failure** | "If I do it badly everyone will know" | Public correction incidents (should be zero); repeat participation after a mistake | **Mistakes are reviewed, not punished**; §43 psychological safety; **[S: Ch.14 step 5 "avoid fear of reporting problems"]** | H-20 |
| **FR-15** | **Fear of judgement** | "They will think I am poor / political / religious / too old" | Participation across social categories; complaint records | Non-discrimination is already constitutional **[S: Ch.2; v1.3-A A-05]**; **§7.3 SR-6 bans "just/only" language**; §34.3 prohibits shame | H-07 |

## 13.2 At what point does a willing person simply stop?

**[A]** Willingness is not the scarce resource; **the cost of acting on willingness is.** A willing person stops at the first point where the *immediate* cost exceeds the *immediate* value — and the calculation is not rational, it is emotional and social. **[I]** The five most common stopping points, in order:

| Rank | Stopping point | The calculation the person makes |
|---|---|---|
| **1** | **A form or a document request at first contact** | "This is more than I offered to give." — and the offer they made was *attention* |
| **2** | **Silence after they asked for help** | "They did not care about my problem, so why should I care about theirs." **This is the most damaging, because it converts a prospective contributor into an active critic** |
| **3** | **Being recruited during the first win** | "This was a trick." — and the loss is not only that person but everyone they tell |
| **4** | **Arriving and knowing nobody** | "I will stand at the edge." — social cost exceeds contribution value in ninety minutes |
| **5** | **Being told they must complete training/membership to continue** | "I came to help, not to enrol." |

**[P] The friction ceiling rule (H-05 extension):** *at no point may the process require more from a person than they have already voluntarily given.* Each step may ask for exactly one increment — a phone number after they report a need; an hour after they attend; a name on a record after they contribute. **Any step that asks for two increments at once is a stopping point.**

---

# 14. CITIZEN SEGMENTATION

**Rule from your brief, adopted:** do not target "Indian citizens" as one homogeneous population; **do not claim empirical certainty without research.** Every entry below is a **participation hypothesis [H]**, to be tested in the pilot (§57), and the segment map is *not* a duplication of the stress test's citizen-value map **[S-ST: §8]** — that map gives what each segment **needs** and can **give**; this one gives the seven participation attributes your brief specifies.

**Legend:** Door **D1** purpose · **D2** proof · **D3** livelihood · **D4** building. Levels **L0–L8** per §6.

| # | Segment | Likely motivation **[H]** | Likely contribution **[H]** | Likely friction **[H]** | Door | Level | Retention hypothesis **[H]** | Potential harm / exclusion |
|---|---|---|---|---|---|---|---|---|
| **1** | **School students** | Structured activity, certificates, adult mentors, family approval | Energy, numbers, digital fluency, reach into families | Guardian consent; safeguarding; exam cycles; transport; child-labour perception | D1, D2 | L1→L3 **with guardian consent** | School-calendar rhythm; a certificate they can show | **Safeguarding failure is institutional death.** Prohibited responsibilities per §48; **[V]** on age and child-labour law |
| **2** | **College students** | Verifiable experience, references, skills, belonging, some income | Time, skills, energy, campus networks | Academic calendar; the belief that it is unpaid labour; credential recognition | **D2**, D1, D3 | L2→L5→L6 | **A record they can put on a résumé** — H-10 is decisive | Being treated as free labour; a certificate no employer recognises |
| **3** | **Young professionals** | Purpose, competent use of skill, network, leadership experience | Pro-bono specialist hours, credibility, remote capability | Meetings instead of work; bureaucracy; time scarcity | **D2**, D4 | L4, remote-capable | **Scope without administration** — three hours of real deliverable, no committee | Being asked to attend rather than to do; scope creep |
| **4** | **Workers (salaried/industrial)** | Bounded contribution near home, dignity, occasional income | Weekend and evening hours, trade skills, local knowledge | Shift patterns; fatigue; family time; transport | D1, D3 | L2→L3, L5 for paid | **Predictable, bounded, respected time** (H-23) | Being poached into a worse deal than the open market **[S-ST: F-34]** |
| **5** | **Skilled tradespeople** | Steady work, local reputation, reliable payment | Electrical, plumbing, carpentry, masonry, repair — the highest-value local delivery capacity | Irregular demand; payment delay; being asked to work free "for the cause" | **D3**, D2 | L4→L5 | **Payment continuity** (v1.3-B B-05/B-06) and a local reputation effect | Unpaid "cause" work; liability for work performed by untrained volunteers **[S-ST: §8 engineers row]** |
| **6** | **Entrepreneurs** | Building something, ownership, network, capability | Ventures, capital, mentorship, employment, market access | Approval latency; mission-conflict rules; governance load | **D4** | L5→L8 | **Scope inside rules they can read** (v1.3-B B-14) | Mission drift **[S-ST: F-17]**; capture of the builder class (§20) |
| **7** | **Shopkeepers** | Footfall, a trustworthy local partner, help in crisis, goodwill | Space, material, in-kind support, local information, sponsorship | Being treated as a donor ATM; political contamination of their shop | D1, D4 | L1→L2, partner | **Visible local goodwill returned to them**, not extracted | v1.3-A A-01: no partisan adjacency near their business; §39.3 sponsorship conditions |
| **8** | **Homemakers** | Safe, time-bounded, near-home participation; recognition; some income | Organisation, teaching, care, networks, meticulous records | Timing; safety; transport; male-dominated leadership; family objection | **D1**, D3 | L1→L3→L6 | **Morning slots within walking distance, with other women** | Freezing them out of leadership; assuming availability without asking |
| **9** | **Parents** | Their children's environment and safety; a good example for the family | Time, advocacy, school linkage, vigilance | School calendar; child-care during activity; fear for children's safety | D1 | L1→L3 | **Family-legible participation** — children at appropriate tiers with consent | Safeguarding; using children as evidence or imagery (**v1.3-A A-19 absolute**) |
| **10** | **Elderly people** | Purpose, company, respect, use of accumulated judgement | Time, patience, verification by witness, local memory, mediation | Physical demand; app-first design; being marginalised by youth | **D1**, D2 | L3→L4→**Elder/Mentor** | **Standing without command** (§6.10) — the only instrument that fits | Exclusion by a digital-only design; being asked to do physical work |
| **11** | **Retirees (professional)** | Continued relevance, mentorship, structured giving-back | Expertise, governance capacity, credibility, time | Irrelevance of ceremony; impatience with bureaucracy; health | **D2**, D4 | L4→L6, Elder | **Real scope with real authority, and no tokenism** | Being used as decoration; unpaid professional labour expectation |
| **12** | **Farmers / rural households** | Water, school, animal health, labour pooling, emergency help, information | Land, labour, local authority, produce, seasonal capacity | Literacy and device constraints; distance; agricultural calendar; urban-designed process | **D1**, D3 | L1→L3 | **Voice-first and paper-first processes; cycles matched to the agricultural year, not the week** | A weekly payment cycle that does not match income rhythm **[S-ST: §12 rural row]**; producing-aggregation regulation **[V]** |
| **13** | **Teachers** | Student engagement, resources, recognition, safe volunteering | Teaching, curriculum, discipline, credibility with parents | Safeguarding exposure; unpaid-labour expectation; school permission | **D2** | L4→L6 | **A channel that makes their existing work more effective** | Safeguarding liability; being assumed available because it is their job |
| **14** | **Doctors / nurses / allied health** | A safe lawful channel to give care; medico-legal protection | Clinical expertise, camps, referrals, training | **Unlicensed practice and medico-legal liability** — internal training is not legally sufficient **[S: Ch.12]** | **D2** | **L4 only, strictly bounded** | **A scope that protects them legally** | **[V]** — the highest-liability segment; referral, awareness and licensed camps only **[S: Ch.15 "no diagnosis/treatment unless licensed"]** |
| **15** | **Lawyers / CAs / compliance professionals** | Pro-bono channel, reputation, institutional client | Legal, tax, audit, governance expertise | Their advice being represented as an organisational position | **D2** | L4, Council-adjacent adviser | **Scope-limited, conflict-declared, documented engagements** | **v1.3-A A-10**: the legal-support protocol defines *process*, never entitlement |
| **16** | **Engineers / technical professionals** | Meaningful application of skill; visible local impact | Design, water and sanitation, safety, digital, energy expertise | Liability for designs executed by untrained volunteers | **D2**, D4 | L4→project owner | **A problem worth solving, with the execution capability to match** | **[V]** liability; scope must exclude supervision they cannot perform |
| **17** | **Designers** | Portfolio, purpose, creative freedom, occasional income | Visual, content, product design — the fastest route to a first rupee for a team (v1.3-B §7.1 category 4) | Revision loops; IP and consent rules **[S: Ch.17]**; low price points | **D2**, D3 | L4→L5 | **Credit and portfolio rights respected**; scope discipline | IP ownership disputes; work used without attribution |
| **18** | **Creators / artists / journalists** | Stories worth telling, access, platform, integrity | Content, documentation, credibility, reach | Being asked to produce promotional content that breaches accuracy rules **[S: Ch.24]** | **D2** | L4, communications contributor | **Editorial integrity protected by the architecture, not by goodwill** | **v1.3-A A-19**: no beneficiary story without separate consent; §33 story framework |
| **19** | **Technology professionals** | Meaningful application, remote participation, building something real | Software, AI operations, data, platform work — **remotely** | The AI-governance load (v1.3-A A-21/A-22); remote-only people missing local belonging | **D2**, D4 | L4→L8, remote | **Real technical scope, and "AI may recommend, humans decide" honoured [S: Ch.21]** | Remote isolation; being treated as a free development shop |
| **20** | **Unemployed / underemployed people** | Income, skill, dignity, a reference | Labour, local knowledge, availability | **The income promise** — the most dangerous expectation to create | **D3** | L5 (earnings track) | **Truthful, bounded earnings reality disclosed in writing before joining** ([S-ST: M16]; v1.3-B §34.2 D-2) | **[S-ST: F-02]**: promise not kept → "scheme" accusation, and a hostile ex-member |
| **21** | **People seeking skills** | Training, certification, a path to work | Time, attention, eventual delivery capacity | Training treated as a gate rather than a gift **[S-ST: §21.2]** | **D2**, D3 | L2→L4 | **A credential they can carry away** (H-10) | Training with no path; certification nobody recognises **[V]** |
| **22** | **People seeking work** | A job, any job | Availability, willingness | Being told the answer is "volunteer first" | **D3** | L5 | **Honest sequencing**: what paid work exists, when, and what it pays | **v1.3-B §34.1 question 1**: payment predictability is currently NO |
| **23** | **People seeking occasional volunteering** | One-off contribution, no commitment, no identity exposure | One hour, one item, one skill, one introduction | Any form, any document, any expectation of recurrence | **D1** | **L1–L2, permanently** | **Nothing is asked of them again unless they ask** | Being funnelled; being recorded without consent; being made to feel a failure for not returning |
| **24** | **People who cannot volunteer physically** | Contribution without presence; not being excluded | Remote skills: translation, design, research, documentation, planning, AI operations, telephone follow-up, funding | Physical-access assumptions in every process; digital exclusion; being overlooked | **D2**, D1 | **L4 remote**, L2 remote | **A contribution designed to their access needs from the start, not adapted later** | **Exclusion by inaccessibility is a visible moral failure [S-ST: §8]**; §50 makes remoteness a first-class mode |
| **25** | **People outside India wanting to contribute** | Connection to a home locality; trustworthy giving; skilled remote contribution | Money, skills, networks, technology — **remotely** | Trust (can they verify where it went?); **FCRA and foreign-contribution law**; time zones | D1, **D2** | L0 donor, L4 remote specialist | **Transparent, evidenced, small, locality-specific projects** — their own village, their own lane | **[V] FCRA is decisive**: foreign contribution without cover is unlawful **[S-ST: §8 diaspora row]**; v1.3-A A-17/A-18 for data |

## 14.1 Three conclusions from the segmentation

**[A]**

1. **Nineteen of twenty-five segments require no earnings and no command role.** Only segments 4, 5, 20, 21, 22 (and partly 6) are livelihood-driven, and only 6, 11, 19 plausibly reach L8. **Yet v1.2 offers essentially one participation format — Verified Member.** That is the adoption gap, quantified without a single invented percentage.
2. **Segment 24 is a design test, not a special case.** If remote and non-physical participation is a first-class mode (§50), twenty-five segments become reachable. If it is an afterthought, roughly a third of them are excluded — including most of the professional segments whose skills the venture pillar needs.
3. **Segment 23 is the one the architecture has no language for at all.** A person who wants to give one hour and never be asked again is currently either "not a member" or an applicant. **L2 exists precisely for them, and §8.2 makes their participation a complete success.**

## 14.2 What must not be done with this table

**[P]** Four prohibitions:

1. **No segment may be targeted with a different *truth*.** Door framing may differ; facts may not. The earnings-reality rule applies to segment 20 and 22 identically **[S-ST: M16]**.
2. **No segment may be recruited through a vulnerability.** Segment 20 (unemployed) must not be recruited with income claims; segment 10 (elderly, lonely) must not be recruited with belonging claims; segment 25 must not be recruited with guilt about leaving India. **§34.3 prohibits the emotions; §3.7 prohibits the appeals.**
3. **No segment may be excluded by inference.** Not collecting caste, religion or ethnicity data is absolute (**v1.3-A A-18 §17.4**), so **no segmentation may be operationalised on those axes** — including "helpfully".
4. **No segment claim may be published as a finding.** Every cell above is `[H]`. Publishing "students join for certificates" as fact before measuring it would be exactly the invented psychological statistic your brief forbids.

---

# 15. FLEXIBLE PARTICIPATION

**Rule:** the organisation must not assume everyone can commit the same amount of time. **No binding policy is created here; everything is `PROPOSED`.**

## 15.1 The eleven participation modes

| Mode | Definition | Fits | Level | What the organisation must provide | What it must not do |
|---|---|---|---|---|---|
| **M-1 One-time** | A single act, no expectation of recurrence | Segments 23, 7, 10 | L1–L2 | A record they can see; **no follow-up pressure** | Ask them to come back |
| **M-2 Occasional** | Irregular, self-selected, no schedule | Most of D1 | L2–L3 | A standing list of available tasks | Treat irregularity as unreliability |
| **M-3 Weekly / regular** | A stated cadence with a stated hour range | D1 committed; D3 | L3–L5 | **An explicit time contract**: "this needs about N hours a month; you can pause" **[S-ST: §7.3 item 3]** | Leave hours open-ended — unclear time expectations are a documented exit driver **[X-inherited: S-ST §7.3]** |
| **M-4 Project-based** | Bounded by a deliverable, not a calendar | D2, D4 | L3–L5 | Scope, timeline, acceptance criteria **[S: Ch.17 step 4]** | Extend the project without renegotiating |
| **M-5 Skill-based** | Contribution defined by capability, not time | Segment 3, 13–19 | **L4** | Scope agreement, conflict declaration, credential verification | Command authority; open-ended availability |
| **M-6 Remote** | No physical presence required | Segments 19, 24, 25, 3 | L2–L4, L8 | §50 remote architecture; **belonging by design, since proximity is absent** | Assume remote people need no relationships |
| **M-7 Local** | Within walking distance | Segments 8, 10, 12 | L1–L5 | FR-05 transport control | Require travel beyond the normal area unfunded (**v1.3-B HC-14**) |
| **M-8 Emergency** | On-call, episodic, unpredictable | Protection, disaster, crisis | **L5+ trained only** | v1.3-A A-09/A-11 doctrine and gates; certification current | Use L1–L4 for emergencies — §7.1 forbids it |
| **M-9 Seasonal** | Tied to a calendar: festivals, harvest, exams, monsoon | Segments 1, 2, 12 | L1–L5 | **Cadence matched to the local calendar, not the financial week** (v1.3-B HC-15) | Measure a seasonal participant against a monthly standard |
| **M-10 Professional** | Bounded paid or pro-bono engagement with a contract | Segments 14–19 | L4 | Written scope; **[S: Ch.18 priority 3]** if paid | Blur into employment without classification **[V]** (v1.3-B E-C2) |
| **M-11 Full-time equivalent** | Sustained, high-hour, role-bearing | L6–L8 | **L5+** | v1.3-B governance-load ceiling (`σ_max`); compensation formula approved | Treat as available by default — **v1.3-B §25.5 shows the heaviest loads fall on the least supported people** |

## 15.2 Mode-switching rules

**[P]**

1. **A person may change mode at any time, without a reason and without a record of the reason.** Mode is an attribute of the *engagement*, not of the *person*.
2. **Mode determines obligation, not standing.** A one-time contributor and a full-time leader have identical dignity (§7.3, §8.4).
3. **Mode determines data collection.** A remote L4 specialist needs a scope and a credential; a one-time L2 contributor needs nothing. **v1.3-A A-18** tier-linked collection applies.
4. **Mode must be visible to the person, in their language, before they choose.** The failure mode is a person who believed they had signed up for M-2 and discovers they were rostered for M-3.
5. **No mode may be the default.** An unselected mode is a design failure, not an assumption.

## 15.3 The pause instrument

**[P] H-18 — Paused and Alumni Status.** Two additions to the existing vacancy statuses **[S: Ch.11 six statuses]**, applied to *people* rather than to *posts*:

| Status | Meaning | Data | Return |
|---|---|---|---|
| **Paused** | Life intervened: exams, illness, childbirth, relocation, work, family. **Expected, normal, and not a resignation** | Retained per schedule (v1.3-A A-17 P2); no active tasks; no score | **One message, no re-verification, no re-application.** Their record and relationships persist |
| **Alumni** | They have left and do not intend to return | Minimal retention; credentials and contribution record **preserved and portable (H-10)** | Welcome at any time, at the level they held, subject only to currency of any certification |

**[A]** The stress test's formulation is preserved: **"Life events should be a comma, not a full stop"** **[S-ST: §7.3 item 4]**. **[I]** The mechanism by which this retains people is simple: **a person who must re-apply to return will not return, and a person who was made to feel like a defector will tell others.** Paused status costs nothing and removes the single most common administrative cause of permanent exit.

**[V]** Retention periods for paused and alumni records require counsel, per **v1.3-A A-17 P2** and the source's own UNRESOLVED retention decision **[S: Ch.33]**.

---

# 16. BENEFICIARY TO PARTICIPANT

## 16.1 The loop, and why it matters

**[S-ST: §22]** — the national growth loop begins with a person who was helped. **[A]** It is the only growth channel that produces *trust-transferable* participants: someone who was helped well has evidence, not advertisement.

```
SERVICE → TRUST → PARTICIPATION → SERVICE
```

**[A]** The loop is real and it is also the most dangerous mechanism in the entire human system, because it operates precisely at the moment a person is vulnerable. Every safeguard below exists because the loop's efficiency and the loop's ethics pull in opposite directions.

## 16.2 The absolute safeguards

**[P] H-22 — Beneficiary/Recruitment Separation.** Six absolute rules. **These are proposed as Tier-1 candidates under v1.3-A A-13**, because they protect people who cannot protect themselves in the moment.

| # | Rule | Basis |
|---|---|---|
| **BS-1** | **No person may be invited to participate within a defined window of receiving help** — and **never by the person who delivered it.** Assistance and recruitment are separated **by role and by time** | **[S-ST: §9.3]** hard rule; window length `PROPOSED — REQUIRES APPROVAL` **[M]** |
| **BS-2** | **Assistance is never conditional on anything** — not on joining, not on attending, not on a testimonial, not on consent to be photographed, not on future availability | **v1.3-A A-19** consent rules; §38.1 |
| **BS-3** | **No volunteer or member may be rewarded, scored, credited or paid for converting a beneficiary.** Not in the performance system, not in the contribution record, not in compensation | **v1.3-B §22.4**; §22 anti-MLM; **[S: Ch.25]** mission impact is measured by *outcomes*, never by conversions |
| **BS-4** | **A beneficiary may not be asked for a testimonial, a photograph, a quote, a name or a story at the point of service — or ever, as a condition of anything.** Consent, where sought, follows **v1.3-A A-19**: separate, specific, informed, reversible, at least a day later, by a different person, never from someone in crisis or dependency | **v1.3-A A-19** consent architecture |
| **BS-5** | **A beneficiary may refuse all future contact, and the refusal is recorded and honoured absolutely** — no follow-up, no outreach, no re-approach, no "we were just checking" | §56 HF-8; **v1.3-A A-20 §19.7** subject rights |
| **BS-6** | **No unnecessary personal information may be sought from a person receiving help.** The minimisation test applies at its strictest here: *if we did not collect this, could we still help?* | **v1.3-A A-18** four-branch necessity test; **[S: Ch.8 step "Privacy check — minimum-data checklist"]** |

## 16.3 Why the loop must be slow

**[A]** Three reasons, none of them merely ethical:

1. **A conversion at the moment of vulnerability is not a conversion.** It is compliance, and compliance ends when the need ends. **[I]** The participant acquired this way has the highest exit rate and the worst story to tell.
2. **It poisons the service.** The moment a helper is also a recruiter, every act of help carries an implicit question, and the recipient can feel it. **This is the mechanism by which a service organisation becomes a membership organisation** — and the stress test's misclassification map **[S-ST: §18.2]** shows how fast that reputation travels.
3. **It is measurable evidence of the thing §39 prohibits.** Monetising or instrumentalising access to help is NM-1 on the never-monetised list. **Converting a beneficiary is the recruitment-shaped version of the same error.**

## 16.4 The permitted path

**[P]** A person who was helped may become a participant **only** through the ordinary public door, on their own initiative, after the separation window, approached by nobody:

```
Helped well, once, with dignity and no publicity
   ↓  (time passes; the separation window elapses)
They see a public invitation like anyone else — the local page, a board, a neighbour
   ↓
They choose to report a need, or help once  (L1–L2, §6)
   ↓
The Paired First Task, with two members who are NOT the people who helped them
```

**[A] The last condition matters:** if the person who helped them is the person who pairs with them, the relationship of debt is preserved rather than dissolved. **The newcomer must meet the organisation, not their creditor.**

---

# 17. ATTRIBUTION

## 17.1 The principle

> **[S-ST: §7.3 item 9]** "The person should be able to understand that their contribution mattered." **Visible consequence of one's own work** — the person you helped, the lane that stayed clean, the shop that survived. "Closed feedback loops are the emotional fuel; **the architecture verifies outcomes but never *returns* them to the person who did the work.**"

**[A]** This is the cheapest and most consequential gap in the architecture. **[S: Ch.15 step 10]** already requires outcome verification — "Did the project solve or reduce the problem?" **The verification exists. The narration does not.**

## 17.2 Ethical attribution methods

| Method | What it is | When | Privacy constraint |
|---|---|---|---|
| **Completion confirmation** | "The task you did on <date> is recorded as complete." | Immediately | None — no third-party data |
| **Impact notification** | "The drain you helped clear has not flooded in the two monsoons since." | After follow-up (§18) | **Aggregate and place-based, never person-based** |
| **Anonymised outcome** | "A family in your lane received the materials. They asked us to say thank you." | Where a personal outcome exists | **v1.3-A A-19**: no identity, no image, no detail that could identify in a small locality |
| **Project result** | Before/after photograph of a *place*, with the contributor list | At project close | Photographs of places are permitted; **of people receiving help they are not** (v1.3-A A-06 V24–V30, A-19) |
| **Team acknowledgement** | "Forty people did this. Here are their names — if they consented." | At project close | **Name-by-name consent**; narrative, never ordinal (§7.3 SR-3) |
| **Personal record entry** | Their own contribution record updates (H-09) and they can see it | Continuously | Their own data only |
| **A thank-you from a named person** | One human sentence, not a broadcast | Within a stated window | None |

## 17.3 What attribution must avoid

Your brief names four; each is given an enforcement point:

| Avoid | Why | Enforcement |
|---|---|---|
| **Exploiting vulnerable people for stories** | The person becomes raw material for someone else's feeling | **v1.3-A A-19**: consent architecture; storytelling channel has **no read access** to the service channel |
| **Publicising private information** | Irreversible harm in a small locality | **v1.3-A A-17 C3/C4** classification; **A-20** sealed records |
| **Emotional manipulation** | Guilt, pity and obligation are prohibited emotions | §34.3; **[S-ST: §10.3]** |
| **"Look what WE did" saviour messaging** | It transfers agency from the contributor and the recipient to the institution | §33 story framework: **"Look what ordinary people were able to accomplish together"** |

## 17.4 The subject rule — the anti-saviour grammar

**[P]** A single grammatical discipline that prevents PM-1 (§3.4) without any new process:

> **The person helped is the subject of the OUTCOME sentence. The person who helped is the subject of the ACTION sentence. The organisation is the subject of neither.**

| Prohibited | Permitted |
|---|---|
| "We gave them a roof." | "The roof is fixed. Ramesh and eleven neighbours carried the sheets." |
| "Sewak Sathi helped 400 families." | "Four hundred households in eleven lanes reported the problem was resolved." |
| "Look what our volunteers did for the poor." | "This lane was flooding every monsoon. It did not flood this year." |
| "We are changing India." | "Twelve teams fixed nineteen drains last quarter. Here is the list." |

**[A]** The rule also protects the organisation: **a claim about a person requires that person's consent; a claim about a place requires only evidence.** Most attribution can therefore be honest, useful and privacy-safe simultaneously — which is why §33's story framework is built on places and problems rather than on faces.

## 17.5 Attribution failure

**[A]** Two failure modes, and both are silent:

1. **Over-attribution:** naming and photographing contributors so enthusiastically that participation becomes performance. Detector: contributors begin recruiting an audience. Guard: consent per item; no ordinal ranking (§7.3); §44 status controls.
2. **Under-attribution:** the default today. The person helped, nobody told them what happened, and they concluded it did not matter. Detector: **HM-7** — attribution received within window. Guard: **H-15** makes attribution a *required step*, not a courtesy, with a stated window and a reported completion rate.

---

# 18. FOLLOW-UP

## 18.1 The loop

```
SERVICE → FOLLOW-UP → OUTCOME
```

**[S]** The architecture already contains the follow-up obligation, thinly: **"survival/follow-up tracking"** for cleaning and plantation **[S: Ch.15]**; **outcome verification** — "Did the project solve or reduce the problem?" **[S: Ch.15 step 10]**; **follow-up** as a Planner-family coordinator role **[S: Ch.9 Follow-up Coordinator]**; and **impact measurement** — "Real outcomes, not inflated counts" **[S: Ch.15 step 12]**.

**[A]** So follow-up is **not a new obligation**. It is an existing obligation that has no cadence, no owner at team level, no record and no return path to the contributor. **H-15 supplies all four.**

## 18.2 The six questions your brief asks

| Question | How it is answered | Record | Who sees it |
|---|---|---|---|
| **Did the problem actually improve?** | Outcome verification **[S: Ch.15 step 10]** at a stated interval after completion | Outcome field: resolved / reduced / unchanged / worsened / unknown | Team, City **[S: Ch.7 review]**, contributor (anonymised, §17.2) |
| **What happened after assistance?** | One follow-up contact at a stated interval, by a person other than the deliverer where the case is sensitive | Follow-up note | Team + City; **sealed where safeguarding is involved (v1.3-A A-20)** |
| **What was learned?** | **v1.3-A A-15 M5** lessons register, with its "did the change work?" column | Lessons entry | Any member (**v1.3-A A-15 rule: inspectable by any member**) |
| **Should the process change?** | Standard-change request route (**[S-ST: M23, F-13]**) | Change request | City → State → National per §20.2 of v1.3-B |
| **Did the beneficiary remain safe?** | Safeguarding follow-up where the case involved a minor, a vulnerable adult, or an incident | Safeguarding field, **C4 sealed** | Restricted per v1.3-A A-20; escalation mandatory per A-09 |
| **Was the service effective?** | Aggregate outcome rates by category and locality — **the mission-balance data v1.3-B B-01 and [S-ST: M14] require** | Category outcome summary | City, State, National; published in aggregate |

## 18.3 Follow-up must not become a burden

**[A]** Your brief's warning is the operative constraint. Follow-up competes for the same hours as service and delivery (v1.3-B §17.2) and adds governance load (v1.3-B §25 GC-09). **[P] Four bounding rules:**

1. **One follow-up per project, at one stated interval.** Not a monitoring programme. Recurrence is a *service* decision (does this need a standing intervention?), not a *follow-up* decision.
2. **Sampling for repeated categories.** Where a team does fifty identical activities, follow-up is sampled, not universal — the same logic as **v1.3-A A-21**'s Low-tier post-hoc sampling and the stress test's sampling-assurance conclusion **[S-ST: §23]**.
3. **Follow-up is City-shareable.** **[S: Ch.7]** already gives the City the review function; a Follow-up Coordinator exists in the Planner family **[S: Ch.9]**. The v1.3-B B-21 shared-services contract should include it.
4. **A follow-up that cannot be done is recorded as "unknown", not skipped silently.** An honest *unknown* rate is a governance asset; a silently missing one is the inflation the source prohibits **[S: Ch.15 "Do not count planned activities as completed impact"]**.

## 18.4 Follow-up outcomes that are uncomfortable — and correct

**[P]** Three results must be recorded as **successes**, because otherwise the loop will be gamed:

| Outcome | Why it is a success |
|---|---|
| **"Referred to the municipal authority / PHC / school, and they acted."** | The organisation is **not a replacement for government** (§9.3). A correct referral that resolves the problem is the best possible result — and **[S-ST: §20.3]** already treats a well-delivered decline as *the trust moment* |
| **"The problem returned and required a standing intervention."** | Honest detection of a structural need, which is the input to City and State planning **[S: Ch.6, Ch.7]** |
| **"Unchanged."** | An honest null result. **A team that reports 100% resolution is not effective; it is not measuring** (§39, §56 HF-14) |

**[A]** The reason this matters: if only "resolved" counts as success, follow-up will not be performed. **The measurement must reward honesty about failure, or it will produce confident fiction.**

---

# 19. BELONGING

## 19.1 What actually creates belonging

**[A]** Twelve candidate mechanisms from your brief, each tested for whether it produces *belonging* or merely *attendance*, and each given the instrument that would build it.

| Mechanism | Produces belonging? | How | Instrument | Cost |
|---|---|---|---|---|
| **Shared mission** | **Necessary, insufficient** | Gives a reason to be here, not a reason to know anyone | §3 proposition; H-04 | Nil |
| **Local relationships** | **YES — the primary mechanism** | Belonging is produced by a *person*, not a programme **[S-ST: §7.3 item 1]** | **H-06** Paired First Task; **H-12** stable teams | Nil |
| **Teamwork** | **YES** | Shared effort with a visible result creates the strongest ordinary bond | H-06 (two existing members, by design) | Nil |
| **Recognition** | Partially | Recognition from *people you know* matters; from an institution it does not | **H-08** taxonomy; §44 | Nil |
| **Rituals** | **YES, if voluntary** | Repeated shared acts create a "we" faster than any statement | **H-13**, under six tests | Low |
| **Stories** | **YES** | A shared narrative about *people like us doing things like this* | **H-14**; §33 | Nil |
| **Shared achievements** | **YES** | "We fixed the lane" is a belonging sentence; "I fixed the lane" is not | §38 first community loop; §33 | Nil |
| **Learning** | Partially | Learning *together* creates belonging; being trained does not | H-10; cohort-based training rather than individual modules | Low |
| **Community events** | **YES, with caution** | Events include families and neighbours, which extends belonging outward — and can also become the organisation's social calendar, which §20 forbids | H-13; family-inclusive provision | Low |
| **Mentorship** | **YES — and asymmetric** | Being *known* by someone more experienced is the strongest retention mechanism available | **H-11** Elder/Mentor; §49 | Nil |
| **Identity** | **YES, dangerous** | A shared identity binds powerfully — and binds against outsiders. §52's "service not force" rule and §20's exclusivity guards are the containment | H-26 layered identity | Nil |
| **Contribution history** | **YES, quietly** | "I was here when the drain was fixed" is a form of ownership | **H-09** contribution record; **v1.3-A A-15** institutional memory | Nil |

**[A] The pattern: nine of twelve mechanisms cost nothing.** Belonging is not a budget line. It is a set of design decisions — pair the newcomer, keep the team stable, return the outcome, name the contribution, eat together occasionally, let an elder be useful.

## 19.2 BELONGING versus LOYALTY TO A PERSON

**[A]** Your brief calls this distinction essential. It is, and the difference is structural rather than emotional:

| | **Belonging** | **Loyalty to a person** |
|---|---|---|
| **Attached to** | A place, a team, a purpose, a set of relationships | An individual |
| **Survives** | The departure of any one person | Only that person's presence and favour |
| **Test** | *"Would you still come if the leader changed?"* | *"Would you still come if the leader asked you not to?"* |
| **Cost of leaving** | Sadness | Betrayal |
| **Effect on dissent** | Dissent is normal | Dissent is disloyalty |
| **Effect on outsiders** | Curiosity | Suspicion |
| **Institutional result** | An organisation | A following |
| **Detector** | **v1.3-A A-16 test 2 (attribution)**: are decisions and achievements attributed to roles and teams, or to a person? | **v1.3-A A-16 test 3 (dissent)**: a zero-dissent count is a warning, not a success |
| **Source position** | **[S: Ch.2]** "serve without expecting reward"; "responsibility follows earned trust" | **[S-ST: §6.2 row 17]** belief in the founder personally rated ❌ — "fastest growth, worst durability"; **v1.3-A A-16** founder-vs-institution |

**[P] H-12 rule:** *belonging must be engineered at team level and never at leader level.* Concretely: a newcomer is paired with **two** members, not with the leader; recognition is given by the team, not by one person; rituals belong to the team, not to a personality; and **when a leader moves, the team's relationships must survive intact** (v1.3-B B-18).

## 19.3 Family-legibility

**[S-ST: §7.3 item 13]** — "Indian institutions survive generations only when they are family-legible." And **[S-ST: §6.2 row 15]** rates family/intergenerational duty ✅ compatible and notes the architecture "treats membership as purely individual."

**[P] H-12 extension — three provisions:**

1. **Family-inclusive events** are permitted and encouraged (H-13), where safeguarding and consent rules apply with full force.
2. **Intergenerational participation** is designed for, not tolerated: a parent at L3 and a child at L1 with guardian consent, or an elder at Elder/Mentor standing and a grandchild at L2, are both normal (§48, §49).
3. **The family is never a recruitment target.** No household may be approached as a unit, no family pressure may be invoked, and **"organisation above family" is a prohibited framing** (§20.2 item 7). **Family-legibility means the family can see and approve what a person does here — not that the family is enrolled.**

**[A]** The tension is real and must be stated: family-legibility improves retention, and family *pressure* destroys consent. **The line is whether a person can stop without a family consequence the organisation created or encouraged.**

## 19.4 What belonging must never become

**[P]** Four prohibitions, each traceable:

1. **Belonging must not become the reason a person cannot leave.** "Staying because one's social world would vanish" is the unhealthy column of the stress test's retention table **[S-ST: §7.4]**. §21's exit-with-dignity and §26's healthy/coercive distinction are the guards.
2. **Belonging must not become exclusivity.** A team that is warm inward and cold outward is a clique, and cliques are a documented exit driver **[X-inherited: S-ST §6.2 row 3]**. §56 HF-9 tests it.
3. **Belonging must not become identity fusion.** "We" that requires a "they" is §52's prohibited enemy narrative.
4. **Belonging must not be conditional on agreement.** §43 psychological safety: a person who can only belong while agreeing does not belong, they comply.

---

# 20. ANTI-CULT SAFEGUARDS

**Basis:** **[S-ST: §16]** established prohibited mechanisms and institutional checks; **v1.3-A A-16** established founder-vs-institution tests; **v1.3-A A-01 N8** prohibited belief screening. **This section converts them into a single enforceable instrument, H-19, and adds the detection layer.**

## 20.1 The prohibited mechanisms

**[P]** Eleven prohibitions. **Each is proposed as a Tier-1 item under v1.3-A A-13** — i.e. harder to amend than ordinary policy — because a prohibition that can be relaxed by the person it constrains is not a prohibition.

| # | Prohibited | How it appears in practice | Detector | Existing basis |
|---|---|---|---|---|
| **AC-1** | **Founder worship** | Portraits, founder's-birthday observance, decisions announced in a personal name, "the founder's vision" as an unarguable premise | **v1.3-A A-16 test 2 (attribution)**; A-16 §15.4 rule: no portrait display, decisions in the institution's name | **[S-ST: §11.1]**; **v1.3-A A-16** |
| **AC-2** | **Unquestionable leadership** | A decision that may not be challenged; a leader whose reasoning is not recorded | **v1.3-A A-15 M1**: no decision without a recorded reason; §43 dissent route | **[S: Const. Art.17]** |
| **AC-3** | **Personality cult** | Rank or access derived from proximity to a person rather than from role | Attribution audit; the four annual institutional tests | **v1.3-A A-16** |
| **AC-4** | **Forced loyalty** | Loyalty tests, oaths, declarations of belief, public affirmations | **v1.3-A A-01 N8**: no belief screening ever — no question, test, inference or record about what a person believes | **[S-ST: §16.1]** |
| **AC-5** | **Isolation** | Members discouraged from family, friends, other organisations, or information | Exit interviews; complaint patterns; §43 | **[S-ST: §16.1]**; §19.3 |
| **AC-6** | **Ideological conformity** | One correct interpretation of the mission; deviation framed as betrayal | Standard-change requests actually used (**[S-ST: F-13, M23]**); dissent counts | **[S-ST: §16.1]** |
| **AC-7** | **Suppression of criticism** | Criticism treated as disloyalty; critics reassigned, cooled out or removed | **v1.3-A A-16 test 3**: a **zero-dissent count is a warning, not a success**; Integrity Line usage | **[S-ST: M10]**; **v1.3-A A-16** |
| **AC-8** | **"Organisation above family"** | Schedules that consume family time; guilt for family obligations; framing family as an obstacle | FR-09 family friction; time-contract breaches; exit reasons | **[S-ST: §16.1]**; §19.3 |
| **AC-9** | **Emotional coercion** | Guilt, shame, fear, indebtedness, manufactured urgency, "after everything we did for you" | §34.3 prohibited emotions; communications review | **[S-ST: §10.3]**; **v1.3-A** manipulation prohibitions |
| **AC-10** | **Fear-based retention** | Implying consequences for leaving; social coldness toward leavers; "you will regret it" | Exit interviews; alumni treatment (§21.5) | **[S-ST: §7.4]** |
| **AC-11** | **Social punishment for leaving** | Ostracism of alumni; public naming of leavers; pressure on their families | Alumni participation rates; complaint records | §21; **[S-ST: §7.4]** |

## 20.2 The institutional checks that make the prohibitions real

**[A]** A prohibition without a check is a sentence in a document. **[P] Seven checks, each with an owner:**

| # | Check | Owner | Frequency |
|---|---|---|---|
| **CK-1** | **Independent route for concerns that does not pass through the person complained about** — the Integrity Line / ombuds | National, independent of operations (**[S: Ch.23 Auditor "review only; not operational commander"]**) | Continuous |
| **CK-2** | **Every decision has a recorded reason, inspectable by any member** | v1.3-A A-15 M1/M4 | Continuous |
| **CK-3** | **The four annual institutional tests** — absence, attribution, dissent, successor | v1.3-A A-16 §15.3 | Annual |
| **CK-4** | **Exit interviews, offered never compelled, with themes reported upward** | HR + independent reviewer | On every exit |
| **CK-5** | **Standard-change request route actually used** — a route nobody uses is a route nobody trusts | City → State → National | Continuous |
| **CK-6** | **Alumni welcome test** — a person who left may return without penalty, and this is stated publicly | §21.5 | Continuous |
| **CK-7** | **Published "what we are not" and published corrections** — the organisation is describable from outside, and corrects itself in public | v1.3-A A-07; **[S: Ch.24 correction logs]** | Continuous |

## 20.3 PARTICIPATION WITHOUT WORSHIP

**[P]** The operational test, applied to any ceremony, communication, ritual, story or rule:

> **Could a person who disagrees with the leadership participate fully, safely and with their standing intact?**

If the answer is no, the instrument has crossed from belonging into loyalty. **§43 makes this testable** by requiring that six specific sentences be sayable without consequence.

**[A]** One further structural point: **the strongest anti-cult instrument in this design is not a prohibition — it is §8's six legitimate endpoints and §21's free exit.** A person who can leave cheaply, keep their credential, keep their friendships and come back later cannot be held. **Coercion requires a captive asset, and this architecture deliberately creates none** (§26.3, **[S-ST: §7.4]**: "no member may be owed money, records, or credentials as a condition of continued membership").

---

# 21. EXIT WITH DIGNITY

## 21.1 The ten exit rights

**[P] H-17**, extended. A person may, at any time, without giving a reason and without a record of the reason being used against them:

| # | Right | Process | Time to effect |
|---|---|---|---|
| **1** | **Reduce participation** | Change mode (§15) | Immediate |
| **2** | **Take a break** | Paused status (H-18) | Immediate |
| **3** | **Leave** | Alumni status (H-18); one exit conversation **offered, never compelled** | Immediate |
| **4** | **Return later** | One message. **No re-application, no re-verification**, subject only to certification currency | Immediate |
| **5** | **Change role** | Vacancy lifecycle **[S: Ch.11]** | Per lifecycle |
| **6** | **Change team** | Local transfer; **relationships and record follow them** (§25) | Immediate where capacity allows |
| **7** | **Refuse promotion** | Recorded as "not available for leadership" so they are not asked repeatedly | Immediate |
| **8** | **Refuse a project** | Decline; no reason recorded | Immediate |
| **9** | **Refuse paid work** | Decline; standing as a volunteer unaffected (v1.3-B B-09 rule 2) | Immediate |
| **10** | **Refuse leadership** | Permanently, if they choose | Immediate |

## 21.2 What happens to each asset on exit

| Asset | On **pause** | On **leave (alumni)** | On **removal for misconduct** |
|---|---|---|---|
| **Credentials / contribution record** | Preserved in full, visible to them | **Preserved and portable (H-10) — they take it with them** | Preserved as to *facts*; a conduct finding is recorded under **[S: SOP-18]** and v1.3-A A-20 sealed rules |
| **Access (system, RBAC)** | Suspended; delegation expires automatically **[S: Ch.22; Ch.33]** | Revoked; **a stated window for handover of anything they hold** | Revoked immediately |
| **Records held about them** | Retained per schedule (**v1.3-A A-17 P2**) | **Retention per schedule; erasure on request where lawful [V]**; the contribution record they *hold* is theirs | Retained per legal-hold and safeguarding rules **[V]** |
| **Compensation** | Accrued and unpaid amounts remain owed (**v1.3-B B-05**) | **Paid in full, at priority 1, on the ordinary cycle. Leaving does not forfeit earned money** | Paid for verified work; conduct outcomes follow **[S: SOP-18]**, never a wage deduction **[V]** |
| **Pending work** | Reassigned; customer informed where contractual **[S: Ch.17]** | Handed over; **customers are treated fairly per [S: App. A §13.5]** | Handed over under supervision |
| **Responsibilities** | Delegated per **[S: Ch.10]** with recorded end dates | Successor named (v1.3-B B-18/B-19) | Successor named; interim authority order applies |
| **Organisational property** | Retained by them for the pause | Returned within a stated window; **not withheld as leverage** | Returned; access revoked first |
| **Standing** | Unchanged | **Alumni — welcome to return, and entitled to be spoken of neutrally** | Per conduct outcome; **never publicly named** (§21.5) |

## 21.3 No retaliation

**[P]** Four absolute rules:

1. **No person may suffer any detriment for reducing participation, pausing, leaving, refusing a role, or raising a concern.** Detriment includes compensation, reference, credential, task allocation and social standing.
2. **The basis exists already:** anti-retaliation for performance is a source provision **[S-ST: §7.2 citing App. A §18.4]**; **[S: Ch.14 step 5]** requires avoiding fear of reporting problems; v1.3-A A-16 requires a concern route that bypasses the person complained about.
3. **Retaliation is serious misconduct** under **[S: SOP-18]**, regardless of outcome — the same entrenchment logic v1.3-A A-08 applied to the DO-NOT list.
4. **A leaver's criticism is not a breach.** §21.5 governs the organisation's response; it does not constrain the leaver's speech.

## 21.4 The exit conversation

**[P]** Offered, never required. Four questions, in this order:

1. **What made you decide?** (recorded as a theme, never as a personal file entry)
2. **Was there a moment when we could have done something different?**
3. **What would have to change for you to come back?**
4. **Is there anything you need from us before you go?** — money owed, a record, a reference, a handover

**[A]** Question 4 is the one that determines whether the exit is dignified. **An organisation that settles what it owes before asking for feedback is believed; one that asks for feedback first is not.**

**[V]** Exit-interview data is personal data: classification, retention and access per **v1.3-A A-17/A-18/A-20**.

## 21.5 How the organisation speaks about people who left

**[P]** Three rules, because this is where dignity is actually tested:

1. **Neutrally and by role, never by name, in public.** No published list of leavers, no characterization of why someone left.
2. **Alumni are welcome.** The public statement is that a person may leave and return, and §20 CK-6 tests whether that is true.
3. **A leaver who criticises publicly is answered with facts and corrections, never with characterisation** — the source's own misinformation rule: "Correct calmly with verifiable facts and correction logs" **[S: Ch.24]**.

**[A] This is also the most powerful recruitment instrument available.** A person who left well tells their neighbours that it is safe to join. **A person who left badly tells them it is a trap** — and they are believed, because they have nothing to gain.

---

# 22. ANTI-MLM / RECRUITMENT SAFEGUARD

## 22.1 The adversarial test

> **Could someone make money primarily by recruiting people rather than creating real value?**

**[A]** Applied honestly to the architecture. **The risk is real**, because Sewak Sathi combines all six of the features your brief lists: teams, progression, business, compensation, recruitment and leadership.

| Feature | Present? | MLM-shaped risk |
|---|---|---|
| **Teams** | Yes — Mohalla/City/State/National **[S: Ch.4–8]** | Hierarchical structure resembles a downline |
| **Progression** | Yes — L0→L8, and the Head Team ladder **[S: Ch.26]** | Recruitment can appear to be the way up |
| **Business** | Yes — AI Business Network, 14-step venture lifecycle **[S: Ch.17]** | Revenue exists to be redistributed |
| **Compensation** | Yes — priority-1 worker compensation, leader multiplier **[S: Ch.18–19]** | A multiplier on "your team's" revenue is the classic mechanism |
| **Recruitment** | Yes — HR family, Recruitment Coordinator, vacancy engine **[S: Ch.9, Ch.11]** | Headcount is visible and easily counted |
| **Leadership** | Yes — earned leadership, dynamic succession **[S: Ch.26]** | Leadership can be sold as the reward for recruiting |

## 22.2 The structural answer already in the source

**[A]** Four existing provisions make a recruitment-based income **architecturally impossible**, provided they are not weakened:

1. **Compensation attaches to *verified work*, not to people.** "Worker compensation — payment to workers/members for **verified work**" **[S: App. A §14.3]**; weekly payment step 1: "**Only approved tasks/projects/venture work are eligible**" **[S: Ch.19]**. **There is no head, no downline and no team-size term anywhere in the payment chain.**
2. **The leader differential is bounded and work-justified.** "Any leader differential must be transparent, capped or bounded… **justified by verified leadership work rather than status alone**" **[S: App. A §15.3]**. A multiplier on subordinate *revenue* would violate this; a bounded differential for leadership *work* does not.
3. **The performance system already forbids counting people.** "**Volunteer counts** → verified members/approved participants only, attendance cross-checked"; "**Member retention** → healthy active retention, not inactive names"; and "**Raw revenue, follower count, social-media views, volunteer count, application count or raw activity count cannot determine leadership**" **[S: Ch.25]**.
4. **Membership has no fee.** Application starts verification and is "not entitlement to join" **[S: Ch.12]**; there is no membership fee anywhere in the architecture. **§39.3 proposes prohibiting one permanently.**

> **[C] Verdict on the adversarial test: NO — under the architecture as written, a person cannot earn primarily by recruiting, because nothing in the payment chain counts people.** The vulnerability is therefore **not structural but interpretive**: it opens the moment anyone defines the leader multiplier as a function of team revenue or headcount, or the moment a "growth incentive" is introduced.

## 22.3 The compensation firewall

**[P] H-21 — Anti-MLM Compensation Firewall.** Seven rules, proposed as **Tier-1 candidates under v1.3-A A-13**:

| # | Rule |
|---|---|
| **MLM-1** | **No compensation, bonus, incentive, allocation or benefit may be calculated from any count of people** — recruited, active, paused, in a team, in a downline, or in any grouping |
| **MLM-2** | **No compensation may be derived from another person's contribution** except through an approved, capped, transparent leader differential justified by verified leadership **work** **[S: App. A §15.3]** — and the differential may not be a percentage of the team's revenue |
| **MLM-3** | **No membership fee, joining fee, kit purchase, training purchase, materials purchase or mandatory subscription** may be required at any level. **Free to join, free to participate, free to leave** (§38, §39.3) |
| **MLM-4** | **No recruitment commission, referral fee or bounty** of any kind, in cash or in kind, at any level |
| **MLM-5** | **No mandatory purchase of any product or service** as a condition of participation, advancement, role or recognition |
| **MLM-6** | **No referral chain.** A person who introduces another receives no benefit, preferential treatment or record advantage. **Attribution of an introduction may be recorded for thanks, never for value** |
| **MLM-7** | **Economic value must come from real service + real work + real products + real customer value.** Concretely: every rupee distributed must trace to a **collected customer receipt** through the waterfall **[S: Ch.18]**, or to an approved and published funding source under **v1.3-B B-26**. **Any distribution not traceable to one of those is prohibited** |

## 22.4 The four detection tests

**[P]** Because a prohibition needs a detector:

| Test | Question | Data |
|---|---|---|
| **T1** | Is any person's income correlated with the number of people they brought in? | Compensation records vs recruitment attribution — **correlation should be zero** |
| **T2** | Does any team's growth in headcount outrun its growth in *customer* revenue and *outcome-verified* service? | §55 metrics; **[S: Ch.25]** anti-gaming controls already flag this |
| **T3** | Does any communication describe earning in terms of building a team rather than doing work? | Communications review; §3.7 prohibited appeals |
| **T4** | Does anyone pay anything to participate? | Zero-tolerance audit; any receipt of money from a participant for participation is a veto-gate breach (§28.2 pattern from v1.3-B) |

**[A]** T1 is the decisive one and it is computable from records the architecture already keeps **[S: Ch.19 payment sheet; Ch.12 HR records]**. **A single correlation report, run annually, is the entire anti-MLM assurance programme.**

## 22.5 The adjacent risk: growth as the metric

**[A]** An organisation can be free of MLM mechanics and still behave like one, if **growth becomes the primary measure of success.** Your brief's final question is the antidote:

> The test is not *"how many members can we recruit?"* but *"how many people voluntarily return because their participation made their life, their community, or someone else's life genuinely better?"*

**[P]** Therefore §55's metric set places **HM-9 voluntary return** and **HM-8 outcome known** above any count, and §8.4 requires the annual report to publish **the number of people who helped once and never returned, as a success metric.** An organisation that reports that number proudly cannot become an MLM, because its growth incentive has been removed at the level of its own reporting.

---

# 23. RECOGNITION SYSTEM

## 23.1 The six instruments, separated

**[P] H-08.** Your brief's distinction is adopted exactly, and the separation is the whole design:

| Instrument | Sentence | What it certifies | Who gives it | Recorded where | May it be ranked? |
|---|---|---|---|---|---|
| **1. APPRECIATION** | "Thank you." | That someone noticed | **A person, to a person** | Nowhere — it is speech, not a record | **Never** |
| **2. PROOF** | "Here is evidence of what you contributed." | That a contribution happened and had an outcome | The organisation, from records | **H-09 contribution record** | Never |
| **3. CREDENTIAL** | "You demonstrated this skill." | Verified capability | The organisation, against a stated standard | **H-10 portable credential** | Never — credentials are **absolute**, not comparative |
| **4. RESPONSIBILITY** | "You are trusted with this role." | That trust has been earned and delegated | Role appointment through the vacancy lifecycle **[S: Ch.11]** | Delegation record with dates **[S: Ch.10, Ch.22]** | No — responsibility is scoped, not ranked |
| **5. COMPENSATION** | "You were paid for this work." | That verified work was remunerated | Finance, at priority 1 **[S: Ch.18]** | Payment sheet with formula version **[S: Ch.19 step 13]** | **Never** — pay is not a score |
| **6. PROMOTION** | "You are entrusted with greater responsibility." | That scope has increased | Vacancy lifecycle + eligibility engine **[S: Ch.11]** | Appointment record | No |

> **[A] The critical rule: never collapse all six into one leaderboard.** A single ranking conflates gratitude with evidence, evidence with capability, capability with trust, trust with pay, and pay with status. **Once conflated, the only way to be thanked is to outrank someone** — which is §44's status addiction and §56 HF-13/HF-14.

## 23.2 Where the existing performance system belongs

**[S: Ch.25]** — team score, proposed weights 20/15/15/15/10/10/10/5, leaderboard published after anomaly review, corrections and appeals; weights **PROPOSED / NOT FINAL [S: Ch.33]**; reconsideration item R5 asks whether the leaderboard should be public at all **[S-ST: §25.3 R5]**.

**[P] H-08 position — the performance system is retained unchanged and *scoped*:**

| Applies to | Does not apply to |
|---|---|
| **Teams**, for learning, support allocation and earned leadership **[S: Ch.25, Ch.26]** | **Individuals at any level** — a person is never scored |
| Comparison **within cohorts** (normalisation per **[S-ST: M8]**) | Comparison of a Level-2 contributor with a Level-7 leader |
| Instruments 4 and 6 (responsibility, promotion) | Instruments 1, 2, 3, 5 (appreciation, proof, credential, compensation) |
| Published after anomaly review, correction and appeal **[S: Ch.25]** | Published for L0–L4, who are never ranked (§7.3 SR-3) |

**[A]** This preserves the source exactly — **nothing is removed, no weight is changed, and R5 remains open** — while removing the mechanism by which a ranking could be read as a judgement of a person.

## 23.3 Recognition design rules

**[P]** Seven, drawn from the constraint that recognition must "celebrate contribution, not loyalty":

1. **Recognition is evidence-linked or it is not given.** Every instrument 2/3/6 cites a record.
2. **Recognition is mostly local.** A thank-you from two people who were there outweighs a national mention **[S-ST: §6.2 row 9]**.
3. **Recognition is narrative below L5, never ordinal** (§7.3 SR-3).
4. **Recognition celebrates the *act*, not the *person*** — §45's community-hero rule: recognised for *what they did*, never for *who they are*.
5. **Recognition is not scarce by design.** Instruments 1, 2 and 3 have unlimited supply. Only 4 and 6 are scarce, because responsibility and scope genuinely are.
6. **Recognition may not be conditional on continuing.** A person who contributed once and left keeps their proof and their credential (§21.2).
7. **Recognition may never be a recruitment message.** Publishing "look how honoured our volunteers are" to attract people converts appreciation into advertising (§39).

---

# 24. CONTRIBUTION RECORD

## 24.1 What it is

**[P] H-09 — Verified Contribution Record.** A person's own, portable, dated record of what they did. Fields:

| Field | Source basis | Classification |
|---|---|---|
| **Service** — activities, dates, places, outcomes | **[S: Ch.15 evidence and outcome verification; App. F]** | C2 internal; C1 for what the person consents to share |
| **Skills** — demonstrated, verified, and by whom | **[S: Ch.12 training; Ch.17 step 6 verified skills]** | C2 |
| **Training** — completed, dates, certifications and expiry | **[S: Ch.12]** | C2 |
| **Projects** — role, scope, outcome | **[S: Ch.17 steps 4–10]** | C2 |
| **Responsibilities** — roles and delegations held, with dates | **[S: Ch.10, Ch.11, Ch.22]** | C2 |
| **Leadership** — functions owned, transitions completed | **[S: Ch.9, Ch.26]** | C2 |
| **Verified achievements** — outcomes attributed to their work | §17 attribution | C2 |
| **Customer work** — delivered, accepted, paid | **[S: Ch.17 steps 10–11; Ch.19 step 7]** | C2; **customer identity restricted** (v1.3-A A-17) |
| **Community contribution** — narrative, non-ordinal | §23.3 rule 3 | C1 where consented |

**[A]** Every field is **derived from a record the architecture already requires.** The contribution record is therefore not a new data estate; it is **a view of the existing estate, turned to face the person.** That is why it is cheap, and why the stress test called it "the most valuable and least developed asset in the architecture" **[S-ST: §19.2 claim 3]**.

## 24.2 What it must NEVER become: a social credit score

**[P]** Four absolute limits, proposed as **Tier-1 candidates under v1.3-A A-13**:

| # | The record may never determine… | Why |
|---|---|---|
| **CR-1** | **A person's basic dignity, or how they are treated** | Priority assessment of a *need* uses urgency, vulnerability, resources, expected impact, safety risk and feasibility **[S: Ch.8 step 5]** — **never** the requester's record. §7.3 SR-5 makes this explicit |
| **CR-2** | **Access to ordinary community life** | The commons is not a reward. A person with no record receives the same help (§38) |
| **CR-3** | **Their worth as a person, in any internal or public statement** | §7.3 SR-1; §8.4 |
| **CR-4** | **Eligibility for anything outside the organisation** — no sale, no sharing, no inference, no profiling for third parties | **v1.3-B §39 NM-4, NM-11**; **v1.3-A A-20 §19.5** prohibited uses including commercial |

**[A] And four positive properties that keep it on the right side of the line:**

1. **It is theirs.** They can see all of it, correct it (**[S: Const. Art.17]**; **v1.3-A A-20 §19.7** subject rights), export it (§25), and have it erased where lawful **[V]**.
2. **It is factual, not evaluative.** It records *what happened*, not *how good a person they are*. No character field, no attitude field, no "potential" score.
3. **It is not aggregated into a single number.** §23.1's separation applies: the record contains proofs and credentials, never a composite.
4. **It survives exit.** §21.2: leaving does not forfeit it. **A record that is worthless outside is a captivity mechanism** **[S-ST: §7.4]**; one that is portable is a gift.

## 24.3 Privacy architecture for the record

**[A]** The record is personal data at scale, and v1.3-A already governs it:

| Requirement | Instrument |
|---|---|
| Classification per field | **v1.3-A A-17 C1–C4**, field-level |
| Minimisation — only what the purpose requires | **v1.3-A A-18** four-branch necessity test |
| Plain-language notice, in English or any Eighth Schedule language | **v1.3-A A-17 P3** **[X-inherited: DPDP notice requirements]** |
| Access separation — a contributor's record is not a beneficiary's record | **v1.3-A A-19** eight-function access matrix |
| Sealed categories — conduct, safeguarding, incident | **v1.3-A A-20** C4, case-scoped, two-person rule |
| Retention and erasure | **v1.3-A A-17 P2**; source retention decision remains **UNRESOLVED [S: Ch.33]** |
| Breach response | **v1.3-A A-17 P5**; **[S: SOP-22]** |
| Subject rights | **v1.3-A A-20 §19.7**; **[S: Const. Art.6]** |

**[V]** All of the above requires professional validation, and the underlying retention decision is unresolved in the source and carried to §59.

---

# 25. PORTABLE CREDENTIALS

## 25.1 The question

> **Should skills and verified achievements be portable across Mohalla, City, State, National, business projects and specialist roles?**
>
> **[A] Answer: yes — and a person should not have to restart their credibility every time they change teams.**

**[S-ST: §7.3 item 6]** identified this as the strongest retention instrument available: "People stay where their time is *converting into something they can carry*. This is also the strongest protection against F-24, because it makes staying rational even for those who will never be promoted." And **[S-ST: §6.2 row 6]**: the architecture "already holds verified service records **[S: Ch.12, App. F]** — it simply never issues them outward. **This is the most under-exploited asset in the entire architecture.**"

## 25.2 The portability matrix

| Portable across | Mechanism | Constraint |
|---|---|---|
| **Mohalla → Mohalla** | The contribution record (H-09) is held at City level or above, not locally; a transfer moves the person, not a copy | **v1.3-A A-20**: sealed categories do not travel with a transfer — they remain case-scoped |
| **Mohalla → City → State → National** | Same record; scope of visibility narrows by RBAC **[S: Ch.23]** | Data moves upward only where needed **[S: Ch.6 upward-minimisation rule]** |
| **Team → business project** | Verified skills field **[S: Ch.17 step 6]** is drawn from the record rather than re-established | Customer confidentiality: customer identity is not portable (v1.3-A A-17) |
| **Team → specialist role** | Credential verification (L4) reads the record rather than restarting it | Professional credential verification remains independent **[V]** |
| **Organisation → employer / institution** | **A reference and a certified record, issued on request, with the person's consent** | **What it may contain, and its legal character, is [V]** |
| **Organisation → another organisation** | Export in a standard format | Erasure and portability rights **[V]** (v1.3-A A-20 §19.7) |
| **Exit → return** | The record persists through alumni status (§21.2) | Certification currency must be re-checked where regulated **[S: Ch.12 boundary]** |

## 25.3 What makes a credential real

**[A]** A credential that nobody outside recognises is a souvenir. **[P] Five conditions:**

| Condition | Requirement | Status |
|---|---|---|
| **1. Standard-based** | Issued against a **published** standard, so a third party can see what was required | **[P]** — standards must be written |
| **2. Evidence-based** | Backed by the record: dates, tasks, outcomes, verifier | **[S]** — the records exist |
| **3. Externally checkable** | A third party can verify it without the person's private data being exposed — the same revocable-token logic as the QR concept **[S: Ch.33 "Minimal data, revocable token"]** | **[P]** + **[V]** privacy |
| **4. Honestly scoped** | States exactly what was demonstrated and **what was not** — "assisted in two digital-literacy sessions" is worth more than "digital literacy" | **[P]**; v1.3-A A-07 under-claiming posture |
| **5. Legitimately issued** | The organisation must be entitled to certify the domain | **[V]** — decisive for regulated domains **[S: Ch.12 boundary]** |

**[V] The hard limit:** the source already states that **"internal training is not automatically legally sufficient for first aid, emergency response, security, labour, child safeguarding, medical, counselling, legal or regulated activities"** **[S: Ch.12]**. **No internal credential may imply legal sufficiency in any of those domains.** A credential that overstates is worse than none, because it exposes the holder.

## 25.4 Why this is an adoption instrument and not a benefit

**[A]** Three effects, each traceable:

1. **It opens Door 2.** For students and job-seekers — "probably the largest single reachable population in India" **[S-ST: §6.3]** — a portable record *is* the value proposition. Without it, Door 2 has nothing behind it.
2. **It removes captivity.** **[S-ST: §7.4]**: staying because the record is worthless outside is the unhealthy column. **Portability converts retention from dependence to preference** — which is the §26.3 test.
3. **It makes the specialist path real.** §47's horizontal progression requires that scope growth be *visible*; a credential is how invisible growth becomes legible, to the person and to others.

**[A] And the honest risk:** issuing credentials creates an expectation the organisation may not be able to honour. **A credential that employers ignore is a betrayal dressed as a gift.** Condition 3 (externally checkable) and **[V]** review are therefore prerequisites, not enhancements — and §59 records external recognition as an unresolved decision.

---

# 26. RETENTION

## 26.1 The right question

> Not *"how do we retain members?"* but **"why would a person voluntarily return?"**

**[A]** The difference is not semantic. "Retention" is something an organisation does *to* people; "return" is something people do. **Every instrument in this section is designed to make returning attractive rather than leaving costly** — because the second is §26.3's coercive column and the stress test already prohibits it: **"no member may be owed money, records, or credentials as a condition of continued membership"** **[S-ST: §7.4]**.

## 26.2 Twelve return hypotheses

**[H]** All are hypotheses. None is asserted as true. Each has an instrument and a measurement.

| # | Hypothesis | Instrument | Measurement |
|---|---|---|---|
| **R-1** | They return because the **contribution was meaningful** | H-15 attribution; §18 follow-up | HM-7 attribution received; HM-8 outcome known |
| **R-2** | They return because of **friendships** | H-06 pairing; H-12 stable teams | HM-3 can they name two people |
| **R-3** | They return because they **trust** the team | §40 small-promise sequence | HM-14 promises kept / made |
| **R-4** | They return because they **learned something** | H-10 credentials; training as reward not gate | HM-10 development taken up voluntarily |
| **R-5** | They return because they were **recognised by people, not by a system** | H-08 instrument 1 (appreciation) | HM-6 can they say what they did; qualitative |
| **R-6** | They return because they had **autonomy** over how much | H-23 modes; H-17 refusal rights | Mode changes without exit |
| **R-7** | They return because participation **fits their life** | H-23; H-18 paused status | Pause-then-return rate |
| **R-8** | They return because there is **livelihood** | Door 3; v1.3-B B-05/B-06 | Payment continuity (v1.3-B P-13) |
| **R-9** | They return because there is **scope without rank** | H-11 specialist path; Elder/Mentor | Lateral moves; scope growth |
| **R-10** | They return because of **local identity** | H-26 layered identity; §31 | Locality-specific participation |
| **R-11** | They return because they **finished something** | §38 community loop; H-08 instrument 2 | HM-5 completion |
| **R-12** | They return because they **saw the impact** | H-15; §18 | HM-7, HM-8 |

## 26.3 HEALTHY retention versus COERCIVE retention

**[S-ST: §7.4]** — the table is carried forward **unchanged**, because it is already the correct instrument:

| **Healthy (build this)** | **Unhealthy (prohibit this)** |
|---|---|
| Staying because the work matters | Staying because leaving would be seen as betrayal |
| Staying because of friendships | Staying because one's social world would vanish |
| Staying because the record has value outside | Staying because the record is worthless outside (**captivity**) |
| Staying because income is fair and predictable | Staying because an advance or debt binds you (**v1.3-B HC-03/F-06**) |
| Staying because you can leave and come back | Staying because a break would erase your standing |
| Staying because you can criticise and be heard | Staying because criticism is disloyalty |
| Staying because the institution outlives its leaders | Staying because the institution *is* a leader |

**[P] The operational test (H-12 extension):**

> **For every person who stays, ask whether they could leave cheaply.** If leaving would cost them money owed, a record, a credential, a reference, their friendships or their reputation — **the retention is coercive however warm it feels.**

**[A]** Three specific coercive patterns to detect, each with a guard:

| Pattern | Mechanism | Guard |
|---|---|---|
| **Debt binding** | A float, advance or personal loan ties a member to the team | **v1.3-B §12.6 rule 1**: a member is never expected to fund operations personally; **v1.3-B B-05** accruals are organisational debts *to* the member, never *from* them |
| **Record captivity** | Their contribution record exists only inside the organisation | **H-09/H-10**: portable, exportable, survives exit |
| **Social captivity** | Their entire social world is the team | §19.4 prohibition 1; §20 AC-5 isolation prohibition; family-legibility §19.3 |

## 26.4 What retention is NOT

**[A]** Four clarifications:

1. **Retention is not the absence of exit.** A healthy organisation has exits, and §21 makes them dignified. **A zero-exit rate is a warning, exactly as v1.3-A treats a zero-dissent count.**
2. **Retention is not headcount.** **[S: Ch.25]**: "healthy active retention, not inactive names." §55 measures `r_act` and voluntary return, never roll size.
3. **Retention is not the goal of the first win.** **[S-ST: §21.3]**: measuring conversion directly destroys the win. HM-9 measures *second contribution*, not membership.
4. **Retention is not uniform.** Different segments return for different reasons (§14). A single retention strategy applied to all twenty-five segments will fail most of them.

---

# 27. RETURN LOOP

## 27.1 The loop

```
SEE A NEED → FIND A WAY TO HELP → CONTRIBUTE → SEE REAL OUTCOME
     ↑                                                    ↓
HELP AGAIN ← RETURN ← LEARN / GROW ← MEET OTHER CONTRIBUTORS ← FEEL USEFUL
```

**[S-ST: §22.1]** tested this loop and found it sound in structure. **[A]** This instrument's contribution is to locate the **break points**, because a loop that breaks silently is worse than no loop.

## 27.2 Where the loop breaks

| Arrow | Break | Frequency **[A]** | Why it breaks | Instrument |
|---|---|---|---|---|
| **See a need → find a way to help** | **No visible route** | **Most common** | A person sees a problem and does not know that a route exists, or the route requires joining | **H-03** public local page; **H-05** two buttons |
| **Find a way → contribute** | **Friction at entry** | Very common | A form, a document, a meeting, a wait (§13 FR-02/03/04) | **H-02**; §10.5; §13 friction ceiling |
| **Contribute → see real outcome** | **Attribution silence** | **The most damaging** | The outcome is verified **[S: Ch.15 step 10]** and never returned **[S-ST: §7.3 item 9]** | **H-15**; §17; §18 |
| **See outcome → feel useful** | **Outcome is aggregate and bloodless** | Common | "400 households served" produces nothing; "the lane did not flood" produces something | §17.4 subject rule; §33 story framework |
| **Feel useful → meet other contributors** | **They were alone** | Common | Unpaired participation; a reshuffled team | **H-06** two existing members; **H-12** stable teams |
| **Meet others → learn/grow** | **Development is a gate** | Common | Training presented as a precondition **[S-ST: §21.2]** | **H-10**; training as reward |
| **Learn/grow → return** | **No invitation, or too much invitation** | Common | Either silence or pressure; both fail | §12.1 week 4: four equal options and a right to decline |
| **Return → help again** | **Life intervened and the door closed** | **Very common** | No paused status; re-application required | **H-18**; §21.1 right 4 |
| **Whole loop** | **The need was never real** | Occasional | A reported problem is not verified, or is not lawfully fixable, and the person is never told | **§40**: a well-delivered decline **is** the trust moment **[S-ST: §20.3]** |
| **Whole loop** | **The loop runs but nobody is thanked** | Silent | Appreciation (H-08 instrument 1) is the one instrument with no system, no owner and no record — and it is the one that matters most at low levels | **H-08**; §23.3 rule 2 (mostly local) |

## 27.3 The loop's minimum viable form

**[P]** For a Stage-0 team (v1.3-B §30) the whole loop reduces to **five acts**, and nothing more is required:

1. **One visible need** in the lane, published.
2. **One way in** that requires no account: a phone number, a person, or a listed task.
3. **One paired contribution** of about ninety minutes.
4. **One returned outcome**, in a sentence, from a named person, within a stated window.
5. **One invitation** that can be declined without consequence.

**[A]** That is the entire human system at minimum viable scale. It requires **no software, no budget, no badge, no ceremony and no approval** — only that someone does the fifth step, which is the one organisations skip.

---

# 28. COMMUNITY EXPERIENCE

## 28.1 What a Mohalla Team could be in its locality

**[P] H-16 — Community Experience Charter.** Nine functions, each mapped to what already exists:

| A person in the mohalla can… | Existing basis | What must be added |
|---|---|---|
| **Ask for help** | **[S: Ch.8 step 1–2]** local observation, resident request, partner referral, logged with location, urgency, risk, privacy | **A public front door** (H-03, H-05) — the intake exists internally and is invisible externally |
| **Offer help** | **[S: Ch.15 step 7]** verified and trained members scheduled | **Levels 1–2 entry** with no verification burden (§6) |
| **Find local opportunities** | **[S: Ch.17]** venture work; **[S: Ch.7]** City identifies customer needs | A **public list of open tasks**, which does not exist |
| **Find skilled people** | **[S: Ch.6]** State specialist pool; **[S: Ch.9]** role families | A **local skills directory** — with consent, and with §39.3's prohibition on brokerage of personal data |
| **Join projects** | **[S: Ch.15]** project creation with roles and resources | Project listing with the §12.1 one-line description |
| **Learn** | **[S: Ch.12]** training categories; **[S: Ch.6]** trainers | Training as **reward and offer**, not gate (§12.1 week 3) |
| **Contribute** | **[S: Ch.8]** the whole loop | Nothing — contribution is the architecture's strongest existing feature |
| **Discover community activities** | **[S: Ch.15]** categories; **[S: Ch.24]** public communication | A **local calendar** in the local language (H-25) |
| **Build relationships** | **Nothing** | **H-12 friendship infrastructure** — the one function with no existing basis at all |

**[A]** Eight of nine functions are already latent in v1.2. **Only belonging has no basis whatsoever**, which is precisely the §2.2 finding expressed locally.

## 28.2 The rule that protects the community from the organisation

**[P]** Your brief's constraint — **do not turn every community interaction into a recruitment funnel** — is operationalised as four rules:

1. **The public front door is for needs, not for membership.** "Report a need" is the first button (§9.4), and the response to a need contains **no** participation invitation.
2. **No activity may be conditioned on attending a recruitment moment.** No "information session" attached to a clean-up; no membership talk after a tutoring session.
3. **The ratio is published and defended:** for every participation invitation issued, the team must be able to show N services delivered to people who were never invited. **The count of people helped who never joined is a success metric** (§8.4).
4. **A person who says no is never asked twice within a stated window** — and the window is recorded, so the rule is auditable rather than aspirational.

## 28.3 The team as a place, not a process

**[A]** Three properties distinguish a place from a process, and all three are cheap:

| Property | What it looks like | Instrument |
|---|---|---|
| **Predictability** | The same people, the same slot, the same lane | H-12 stable teams; H-23 stated cadence |
| **Legibility** | A resident can say what the team is for without having read anything | §9 ten-second standard; H-03 one page |
| **Availability of a person** | Someone's name and number are known locally | §10.3 minute 3–4: a real named person responds |

**[A]** None requires an office, a building or a budget. **All three are destroyed by the same thing: being replaced by an app that has no name on it.** §29.4 makes that a design rule.

---

# 29. DIGITAL EXPERIENCE

## 29.1 The digital journey

```
DISCOVERY → UNDERSTANDING → PARTICIPATION → CONTRIBUTION → IMPACT → RECOGNITION → NEXT OPPORTUNITY
```

**[A]** Mapped to the existing platform architecture **[S: Ch.22 fourteen modules]** and to the level structure:

| Stage | Digital | Human | Offline | Level |
|---|---|---|---|---|
| **Discovery** | One public local page, in the local language, no login | A neighbour, a board at the site, a stall | **Primary** — most discovery is physical | L0 |
| **Understanding** | The core sentence; "what we are not"; three dated local results | A named person answering a question | A printed one-pager | L0 |
| **Participation** | Two buttons: report a need / help once. **Three fields. No account** | A phone call is sufficient and must remain sufficient | A person, a register at a stall | L1 |
| **Contribution** | Task list with time, place, duration, what to bring | **Two existing members on site** (H-06) | Paper task sheet | L2 |
| **Impact** | Their own record updates; an outcome notification | **A named person tells them** | A before/after board at the site | L2 |
| **Recognition** | Appreciation and proof (H-08 instruments 1–2). **No ranking below L5** | Thanked by name, in person | A wall of names where consented | L2–L4 |
| **Next opportunity** | Four equal options and a right to decline | A conversation, never a prompt | — | Any |

## 29.2 What belongs where

**[P]** The allocation rule: **a thing belongs in the app if it is repetitive, factual and private; it belongs to a human if it is a decision, an emotion or an exception; it belongs offline if the person is not online.**

| Belongs in **app / platform** | Belongs with the **local team** | Belongs in **human interaction** | Belongs **offline always** |
|---|---|---|---|
| Own record and contribution history | Task listing and rostering | **Every decline** | Discovery for non-digital residents |
| Own schedule and reminders | Site verification | **Every outcome notification of consequence** | The physical result — a fixed drain, a clean lane |
| Evidence capture at the point of activity **[S: App. F]** | Local relationships | **Every invitation** | Paper intake where required |
| Reconciliation views **[S: Ch.19]** | Materials and stock **[S: Ch.7]** | **Every conflict** (§42) | Community events |
| Access requests and reason codes (v1.3-A A-20) | Escalation | **Every exit conversation** (§21.4) | The board at the site |
| Audit logs (v1.3-A A-22) | Incident response **[S: Ch.16]** | **Every refusal** (§8.3) | Voice/telephone routes for low-literacy users |

## 29.3 Technology must not be mandatory where it excludes

**[P]** Five rules, derived from the source's own upward-minimisation and privacy discipline and from v1.3-B's cost findings:

1. **A phone number is sufficient at L1–L2.** No app, no account, no email.
2. **Every digital route has a paper or voice equivalent** at L1–L3, because literacy, device ownership and connectivity are uneven **[S-ST: §12 rural row notes literacy and device constraints and prescribes voice/IVR and paper-first processes]**.
3. **No participation may be impossible without a smartphone.** §14 segment 24 makes this an equality requirement, not a convenience.
4. **Data collected digitally is subject to the same minimisation test** (**v1.3-A A-18**) — a form field is not free because it is digital.
5. **The manual control stack has an expiry, not a permanence.** **[S-ST: M12, F-30]**: manual processes are acceptable early and must be retired at a hard trigger; the platform minimum is a Stage-2 item. **v1.3-B §40.2 confirms: no software is required for the pilot.**

## 29.4 The rule about names

**[P]** *No digital surface may be the only way to reach the organisation.* Every screen that offers a function must also offer a person. **An organisation whose front door is a form will be experienced as an institution; one whose front door is a name will be experienced as a neighbour** — and §28.3 shows that "availability of a person" is one of the three properties of a place.

---

# 30. LANGUAGE ARCHITECTURE

## 30.1 The problem

**[S-ST: §13.1]** — India cannot be treated as a single-language community. **[A]** Three consequences for the human system specifically:

1. **A person who cannot read the invitation cannot accept it.** Language is FR-11 in §13, and it is a *hard* exclusion rather than a friction.
2. **A translated slogan is not the same slogan.** §3.4 PM-8: the proposition's clause structure is English, and direct translation may produce something flat or devotional.
3. **Terminology drift creates governance failure, not just confusion.** If "member", "verified", "volunteer" and "specialist" mean different things in different languages, §6's security boundary becomes unenforceable.

## 30.2 The three-layer architecture

**[S-ST: §13.2]** — carried forward as **H-25**:

| Layer | Content | Rule |
|---|---|---|
| **L1 — Constitutional and legal** | The constitution, DO-NOT list, protection doctrine, privacy notice, compensation formula, consent text, exit rights, grievance route | **One authoritative text per language; every version legally reviewed; no publication without review.** **v1.3-A H10** already requires this for legally significant documents |
| **L2 — Operational** | SOPs, task descriptions, training material, forms, dashboards | Local language first; terminology register maintained per language |
| **L3 — Cultural and expressive** | Stories, invitations, recognition wording, event language, local naming | **Fully local.** The organisation sets meaning, never phrasing |

## 30.3 Hindi and English: the trap

**[S-ST: §13.3]** — carried forward unchanged, marked **[P, V]**: a Hindi-first or English-first national voice imports a political position. **[A]** The human-system consequence is specific: **a language hierarchy inside the organisation becomes a status hierarchy among members**, which violates §7.3 SR-1 and **v1.3-A A-05**'s language-equality requirement.

**[P] Three rules:**
1. **No language is senior.** No internal document, ceremony or announcement is "original" in one language with the others as translations of lesser standing.
2. **The public voice of a locality is in that locality's language.** National communication is multilingual or is not published.
3. **Terminology is registered, not improvised.** One meaning per term per language, reviewed — the same discipline **v1.3-A A-06 V11** applies to protection terminology.

## 30.4 Preserving the meaning of SEVA

**[A]** Your brief requires that the system preserve the meaning of *seva* without requiring everyone to speak the same language. **[P] The method:**

1. **Fix the meaning, not the word.** The meaning is: *service given without an expectation of reward, and without superiority toward the person served.* That definition — not the word — is what is registered in each language.
2. **Let each language supply its own word.** Seva, khidmat, thozhil, seva/thond, upakar — the local term carries cultural legitimacy that an imported one does not, and **v1.3-A A-05** requires that legitimate cultural diversity not be erased.
3. **Never use it prescriptively.** **[S-ST: §10.2]**: "Used descriptively it is powerful; used prescriptively ('a true sewak would…') it becomes the guilt mechanism that burns out good people." **§34.3 makes guilt a prohibited emotion, which makes prescriptive seva phrasing a communications violation.**
4. **Do not invoke it religiously.** **v1.3-A A-05**: accepted individually, never invoked institutionally.

**[V]** Terminology review per language is required before any L1 publication, and the source's public-name decision remains **UNRESOLVED [S: Ch.33]**.

## 30.5 What language costs

**[S-ST: §13.4]** notes the cost is real. **[A]** For the human system specifically: **v1.3-B HC-19** already records translation as a hidden cost, and **v1.3-A A-06/A-07** require per-language review of protection and public-statement wording. **[P]** The economising rule: **translate L1 fully and once; translate L2 by need; leave L3 to the locality, which does it for free and better.**

---

# 31. NATIONAL AND LOCAL IDENTITY

## 31.1 The layering

```
INDIA → STATE → CITY → MOHALLA
```

**[A]** Your brief requires that a participant feel *"this is my local community"* **and** *"I am part of something larger"* — without forced uniformity, regional superiority, cultural erasure, nationalism as coercion, or political symbolism.

**[P] H-26 — Layered Identity, five rules:**

| # | Rule | Basis |
|---|---|---|
| **ID-1** | **The local layer is primary and the national layer is derived.** A person belongs to their mohalla team first; "India" is the sum of those, not a container for them | **[S: Ch.8]** Mohalla is the direct-execution layer; **v1.3-B §2.4** the City is the economic unit |
| **ID-2** | **Nothing local may be replaced by a national standard.** Language, calendar, courtesy, food, dress and naming stay local | **[S-ST: §12.1 localisation contract]**; **v1.3-A A-05** cultural-respect guard |
| **ID-3** | **The national layer supplies capability, not identity.** What flows down is a specialist, a trainer, a warehouse, a reviewer, a float and an escalation route — not a flag, a slogan or a uniform | **[S: Ch.6, Ch.7]**; **v1.3-B B-21** |
| **ID-4** | **No layer may claim superiority over another.** Not state over state, not city over city, not urban over rural, not "founding" teams over new ones | §30.3 rule 1; §52 no-enemy rule |
| **ID-5** | **National symbolism is service symbolism or it is nothing.** §53's rule: symbols must signal service, not force | **v1.3-A A-06/A-07/A-08** |

## 31.2 How "something larger" is felt without abstraction

**[A]** A person does not feel part of a national network because of a logo. They feel it when **the network does something for them that their locality could not.** **[S-ST: §12.3]** identified the mechanism: *"Local achievement published nationally, national capability deployed locally."*

**[P] Two-way flow, four instruments:**

| Direction | Instrument | Example |
|---|---|---|
| **Up** | A local result is published nationally, with the locality named and the contributor credited (with consent) | "This lane in <place> did not flood this year" |
| **Up** | A local lesson enters the institutional memory and changes a standard elsewhere | **v1.3-A A-15 M5** lessons register with its "did the change work?" column |
| **Down** | A specialist, trainer or reviewer arrives from the State pool when the locality cannot solve it alone | **[S: Ch.6]** |
| **Down** | Materials, stock, escalation or a float arrive when the locality cannot resource it | **[S: Ch.7]**; **v1.3-B B-15(2), B-24** |

**[A]** That is the entire content of "I am part of something larger." **It is a set of observable events, not a feeling to be induced** — which is why it survives contact with scepticism and why §39 ranks it as a trust signal.

## 31.3 What must be avoided

| Avoid | Mechanism | Guard |
|---|---|---|
| **Forced uniformity** | One template, one script, one visual system imposed nationally | §30.2 L3 fully local; §31.1 ID-2 |
| **Regional superiority** | Ranking states or cities; "best region" awards | §23.1: only *teams* are scored **[S: Ch.25]**, never regions; §7.3 SR-3 no ordinal language |
| **Cultural erasure** | National vocabulary replacing local terms | §30.4: each language supplies its own word |
| **Nationalism as coercion** | Loyalty to the nation used to demand loyalty to the organisation | §34.3 prohibited emotions; **v1.3-A A-01** (no political positioning); §3.7 prohibited appeals |
| **Political symbolism** | Colours, gestures, dates, imagery associated with any party or movement | **v1.3-A A-01 N-series; A-03 election protocol; A-06 V8–V11** |

**[A]** The last two are the same risk wearing different clothes, and **v1.3-A already closed them at constitutional level.** This instrument's contribution is narrower and practical: **identity design must never give a future leader a symbol to weaponise.**

---

# 32. SHARED CULTURE

## 32.1 Whether the organisation should develop shared culture at all

**[A]** Yes — but **thin, local and voluntary.** The reasoning:

- **A shared vocabulary reduces friction.** If "verified", "member", "specialist", "paused" mean the same thing everywhere, §6's boundary is enforceable (§30.3 rule 3).
- **A shared tradition produces continuity.** Institutional memory (**v1.3-A A-15**) is a cultural instrument before it is an archival one.
- **But a thick culture excludes.** Every ritual, symbol and in-joke raises the cost of entry for the next person. **[I]** The thicker the culture, the narrower the population that can belong — which contradicts §35's universal-usefulness test.

**[P] The rule: culture is *earned locally* and *registered nationally*, never *designed nationally and imposed locally*.**

## 32.2 The six-test gate for any ritual

**[P] H-13.** Every proposed ritual, ceremony, event, symbol, story format or tradition must pass **all six** of your brief's tests:

| # | Test | Question | Fails if |
|---|---|---|---|
| **1** | **Voluntary participation** | Can a person decline without explanation, record or consequence? | Any attendance expectation, roll call, or score attaches to it |
| **2** | **Inclusivity** | Can every segment in §14 take part — including elders, people with disabilities, women with care duties, non-digital residents, and people of every faith, caste, language and region? | It requires physical ability, literacy, a device, money, a diet, a gender role, or a calendar that excludes some |
| **3** | **Non-political character** | Does it avoid every party, movement, election, leader, date and symbol with political association? | Any adjacency — **v1.3-A A-01, A-03, A-06 V8–V11** apply |
| **4** | **Non-religious coercion** | Is it free of religious content, calendar, dress, food restriction and language — while permitting individuals to observe their own faith privately? | Any invocation, blessing, fasting, festival alignment or devotional phrasing in the organisational voice (**v1.3-A A-05**) |
| **5** | **No personality cult** | Does it celebrate acts and teams rather than persons, and does it survive the departure of its originator? | Any portrait, naming, birthday observance, founder reference, or "our leader's vision" (**v1.3-A A-16**; §20 AC-1/AC-3) |
| **6** | **Reasonable cost** | Can a Stage-0 team with no revenue hold it? | Any cost that competes with service materials, transport or payment (**v1.3-B §4.4 L1; §9.3**) |

**[A]** Test 6 is the one that will eliminate most proposed ceremonies, and correctly: **v1.3-B §9.3 shows that at ₹0 revenue only time-costed activity continues.** A ritual that requires money is a ritual a poor team cannot hold — and a culture that only rich teams can perform is a culture that erases the places the mission exists for.

## 32.3 What survives the six tests

**[P]** Candidates, all time-costed, all voluntary, all local:

| Candidate | Passes? | Note |
|---|---|---|
| A shared meal after a project, where food is already being prepared for the activity | ✅ | **[S-ST: §7.3 item 7]**; **[V]** food safety **[S: Ch.15]**; must not require purchase |
| Naming the lane, the school room or the tree by what was done and when | ✅ | Place-based, not person-based (§17.4); no portrait, no plaque naming a leader |
| Reading the outcome aloud at the end of an activity | ✅ | §17 attribution; costs nothing; produces the proposition of §3 |
| An annual local "what we did" list, published | ✅ | **[S: Ch.24 annual cadence]** already requires it |
| A moment of quiet before work | ⚠️ | Voluntary and non-religious only; **risky** — easily becomes devotional. Better omitted |
| A national service day | ⚠️ | Passes tests 1, 2, 5, 6; **test 3 (non-political) and test 4 (non-religious) require care with any date choice.** Date selection is **[V]** and politically sensitive — §31.3 |
| A flag, anthem-like song, salute, uniform or badge | ❌ | **v1.3-A A-06 V1–V3, V8–V11**: no uniform, no insignia; §53 |
| A founder's-day observance | ❌ | §20 AC-1; v1.3-A A-16 §15.4 no portrait display |
| An oath, pledge or affirmation | ❌ | §20 AC-4 forced loyalty; **v1.3-A A-01 N8** no belief declarations |
| Awards ranked across teams or regions | ❌ | §31.3; §7.3 SR-3; **[S: Ch.25]** scores teams only |

## 32.4 How culture is actually transmitted

**[S-ST: §15.4]** — the honest answer is that culture travels by **what people see rewarded and punished**, not by what documents say. **[A]** Three transmission channels this instrument relies on:

1. **The Paired First Task** — two existing members *are* the culture, for ninety minutes (H-06).
2. **What gets recognised** — §23's six instruments, applied mostly locally.
3. **What gets refused** — a visible refusal of a political approach (v1.3-A A-04), a beneficiary photograph (A-19), an unsafe task (A-08) or a recruitment commission (H-21) teaches more than any handbook.

**[A]** Therefore **the pilot must observe refusals, not only activities** (§57). A team that never refuses anything has not understood the culture; it has understood the paperwork.

---

# 33. STORIES

## 33.1 The primary story

> **NOT:** *"Look how powerful Sewak Sathi is."*
> **INSTEAD:** *"Look what ordinary people were able to accomplish together."*

**[P] H-14 — Story Framework.** Six priorities, in order:

| Priority | Subject | Why first | Constraint |
|---|---|---|---|
| **1** | **The place and the problem** | A place can be named without anyone's consent, and a resolved problem is verifiable | Must be true and dated **[S: Ch.24 verified facts only]** |
| **2** | **The contributors, if they consent** | Agency belongs to the people who acted (§17.4) | Name-by-name consent; no ordinal ranking |
| **3** | **The team** | "Together" is the second clause of §3 | Team, never a leader |
| **4** | **The learning** | Including what did not work | **[S: Ch.15 "include failures in reports"]**; v1.3-A A-15 M5 |
| **5** | **Quiet service** | The unphotogenic majority | No image required; text is enough |
| **6** | **The beneficiary — only with separate, specific, informed, reversible consent, sought at least a day later by a different person** | Their story is theirs | **v1.3-A A-19** in full: never in crisis or dependency; guardian consent plus the minor's own assent; absolute withdrawal; the right to remain invisible |

## 33.2 Prohibited story forms

| Prohibited | Why | Basis |
|---|---|---|
| **"Look what WE did"** | Transfers agency to the institution | §17.4 subject rule |
| **Before/after images of a person** | Dignity harm, irreversible | **v1.3-A A-19**; **[S: App. F no exposure of minors]** |
| **A named beneficiary in hardship** | Exposure in a small locality is identification | **v1.3-A A-17 C3/C4, A-20** |
| **A conversion story** ("they were helped and now they serve") | It is the recruitment loop of §16 dressed as narrative, and it pressures the person | §16.2 BS-3, BS-4 |
| **A poverty narrative** | Shame is a prohibited emotion | §34.3; **[S-ST: §10.3]** |
| **An enemy narrative** — a corrupt official, a negligent agency, a hostile group | Unity built against someone is §52's prohibition | §52; **v1.3-A A-01, A-05** |
| **A founder narrative** | Personality cult | §20 AC-1; **v1.3-A A-16** |
| **An exaggerated impact claim** | Truth veto | **[S: Ch.15 "Do not count planned activities as completed impact"]**; §39 |
| **A story published without correction capability** | Errors are permanent if uncorrected | **[S: Ch.24 correction logs]**; v1.3-A A-15 M4 |

## 33.3 The story discipline

**[P]** Four rules:

1. **Every published claim traces to a record.** The evidence chain already exists **[S: Ch.15 steps 9–10; App. F]**; a story without it is not published.
2. **Correction is faster than publication.** **[S: Ch.24]**: correct calmly with verifiable facts and correction logs.
3. **Consent is per item, per use, revocable** — and revocation removes the story, not merely the name (**v1.3-A A-19**).
4. **The story channel has no read access to the service channel** (**v1.3-A A-19** access-separation matrix). **A communicator cannot browse case records looking for material** — which is the structural reason the prohibited forms above cannot be produced by accident.

---

# 34. EMOTIONAL DESIGN

## 34.1 Method

**[A]** Emotional design here means: **deciding in advance which feelings the organisation will try to produce, which it will accept, and which it will prohibit** — and then auditing its instruments against that decision. Not copywriting.

## 34.2 The permitted emotions

| Emotion | How it is legitimately produced | Instrument | Test that it is not manufactured |
|---|---|---|---|
| **Usefulness** | A real task with a visible result | H-06; §38 | The result exists and is verifiable |
| **Dignity** | Being asked, not processed; being told the truth; being able to refuse | §10; §8.3; §21 | The person could have said no without cost |
| **Belonging** | Two people who expected them | H-06; H-12 | They can name two people |
| **Hope** | **A shown outcome, never a promised one** | H-15; §18 | The claim is about what happened, not what will |
| **Pride in contribution** | Their name on a real act, with consent | §17; H-08 instrument 2 | The act is recorded and attributable |
| **Gratitude** | Given and received between people | H-08 instrument 1 | It is not owed, and not scored |
| **Trust** | A small promise kept visibly | §40 | The promise was small and the delivery was on time |
| **Curiosity** | A visible local result | §9; §38 | Nothing is hidden to create it |
| **Responsibility** | Real delegated scope with real limits | §6; **[S: Ch.10]** | The authority is genuine and revocable |
| **Companionship** | Shared effort, repeated | H-12 | The team is stable |
| **Achievement** | Completion, witnessed | H-08 instrument 2 | Completion is verified, not claimed |

## 34.3 The prohibited emotions

**[S-ST: §10.3]** — carried forward **unchanged**, now with detectors:

| Prohibited | How it would be produced | Detector | Guard |
|---|---|---|---|
| **Guilt** — for not giving enough time or money | "Others gave more"; absence framed as failure | Communications review; exit-interview themes | No obligation framing; §12.1 "nothing further is expected" |
| **Fear** — of a group, of the organisation's displeasure, of losing standing | Protection appeals; implied consequences for leaving | §20 AC-10; complaint records | **v1.3-A A-01/A-08**; §3.7 prohibited appeals |
| **Shame** — of poverty, of receiving help, of low rank, of leaving, of family circumstances | Public correction; ordinal ranking; "just a volunteer" | §7.3 SR-6 language ban; HM-13 dignity measurement | **v1.3-A A-19**; §8.4 |
| **Indebtedness** — to a leader, a family, a community, the founder | Personal advances; favours; "after everything we did" | **v1.3-B §12.6 rule 1**: no personal funding; §20 AC-9 | Debt binding is coercive retention (§26.3) |
| **Superiority** — over non-members, other organisations, other neighbourhoods, faiths, castes, regions, languages | "We are more trustworthy than…"; ranking regions | §31.3; §33.2 | **[S-ST: §19.2]**: the claim is "we are verifiable", never "we are better" |
| **Outrage** as mobilising fuel | An enemy narrative; manufactured injustice | §33.2; §52 | **v1.3-A A-01**; §34.4 |
| **Dependency** | Being the only route to help, work or belonging | §26.3 coercive-retention test | **"A floor people stand on, not a wall they lean against" [S-ST: §10.3]** |

## 34.4 The audit question

**[P]** Applied to every communication, ceremony, story, ritual, recruitment message and internal announcement:

> **What does this make a person feel, and could they act otherwise without cost?**

If the intended feeling depends on the person *not* being able to decline, the instrument is coercive regardless of its tone. **This is the same test as §20.3, applied to communications rather than to structure** — and it is deliberately simple, because a complex ethics test is not used at eleven at night when a message is being written.

---

# 35. THE "EVERY CITIZEN" TEST

## 35.1 The question, correctly framed

**[A]** Your brief's reframing is adopted exactly:

> **NOT:** every citizen must become a member.
> **BUT:** can every *type* of citizen find at least one legitimate way to **benefit from**, **contribute to**, or **interact with** Sewak Sathi?

**[S-ST: §8 premise]** supplies the standard: **"the goal is not universal membership. It is *universal usefulness*"** — and the library analogy: most people who benefit from a library are not librarians, and the library does not want them to be.

## 35.2 The participation matrix

Three relationships are sufficient: **BENEFIT** (receive), **CONTRIBUTE** (give), **INTERACT** (neither — use, refer, verify, buy, criticise). Levels per §6; doors per §5.

| Citizen type | Possible need | Possible contribution | Door | Level | Principal friction | Proposed solution |
|---|---|---|---|---|---|---|
| **A resident with a local problem** | A drain, a lane, a school, a safety concern | Local knowledge; later, participation | D1 | **L1** | No visible route | H-03 public page; H-05 two buttons |
| **A resident who wants nothing to do with it** | A cleaner lane, a working drain, help in crisis | **Nothing — and that is fine** | — | **L0** | Being recruited at the moment of need | §16.2 BS-1/BS-2; §28.2 |
| **A person with one free hour** | To do something useful once | One hour | D1 | **L2** | Any form, any document | §6.3; §13 friction ceiling |
| **A student** | Verifiable experience | Time, skill, energy | **D2** | L2→L5 | Being treated as free labour | H-10 credential; §23 separation |
| **A professional** | Meaningful use of skill | Bounded expertise, often remote | **D2** | **L4** | Meetings instead of work | §15 M-5; §50 remote |
| **A person seeking income** | Work | Delivery capacity | **D3** | L5 | The income promise | **[S-ST: M16]** earnings-reality disclosure; v1.3-B §34 |
| **A tradesperson** | Steady local work | Repair, construction, maintenance | D3, D2 | L4→L5 | Payment delay; unpaid "cause" work | v1.3-B B-05/B-13 |
| **A homemaker** | Safe, bounded, near-home participation | Organisation, teaching, care, records | D1, D3 | L1→L6 | Timing, safety, family | H-23 modes; §19.3 |
| **An elder** | Purpose, company, respect | Judgement, memory, mediation, witness | D1, D2 | L3→**Elder** | Physical demand; app-first design | §6.10; §49 |
| **A farmer / rural household** | Water, school, animal health, emergency help | Land, labour, local authority, seasonal capacity | D1, D3 | L1→L3 | Literacy, device, distance, calendar | §30 voice/paper-first; H-23 M-9 seasonal |
| **A shopkeeper** | Footfall, a trustworthy partner, help in crisis | Space, material, information, sponsorship | D1, D4 | L1→L2, partner | Donor-ATM treatment; political contamination | §39.3 sponsorship conditions; v1.3-A A-01 |
| **A business owner / SME** | Reliable delivery capacity; CSR channel | Contracts, paid work, mentorship, equipment | **D4** | partner + L5 | Being asked for free work | §38.2 commercial separation (v1.3-B B-27) |
| **A local authority** | A reliable, non-political, documented partner | Permissions, referrals, information | — | **Institutional partner** | Being used as a parallel authority | v1.3-A A-06/A-07/A-09 |
| **A donor (individual or diaspora)** | A trustworthy channel to a specific locality | Money, skills, networks | D1, D2 | **L0 donor**, L4 remote | Verifying where it went; FCRA **[V]** | §39 evidence; v1.3-B B-26 funding map |
| **A customer of the venture pillar** | Work delivered reliably | Revenue — the only funded input (§8.4 of v1.3-B) | D3 relationship | **Customer, not member** | Quality, price, delay | v1.3-B B-13; **[S: Ch.17]** |
| **A journalist, sceptic or critic** | Truth, access, accountability | **Scrutiny — which is a service to the institution** | — | **Non-participant, deliberately served** | Unanswered questions | **[S-ST: §8]**; §39.4; v1.3-A A-07/A-15 |
| **A person with a disability** | Accessible participation and dignified help | Skills, perspective, meticulous work | D1, D2 | **Any**, with access provision | Physical and digital inaccessibility | §29.3 rule 3; §50 |
| **A person unable to participate physically** | To contribute anyway | Remote skill, funding, telephone follow-up | **D2** | **L4 remote**, L2 | Every process assumes presence | §50 remote architecture |
| **A child (with guardian consent)** | Safe structured activity | Energy, digital fluency, family reach | D1 | **L1→L3 with consent** | Safeguarding | §48 **[V]** |
| **A member of a faith-based service group** | Collaboration without absorption | Volunteers, kitchens, space, distribution | — | **Project partner, activity-scoped** | Being classified as a religious body | **v1.3-A A-05**; §32.2 test 4 |
| **A person who will never join** | A better neighbourhood | Nothing | — | **L0** | Being made to feel a failure for not joining | **§8.4: publish the count of one-time helpers as a success metric** |

## 35.3 Does every type have a legitimate way in?

**[C]** Counting the matrix: **twenty-one citizen types, and every one has at least one legitimate relationship** — including the two that require *nothing* of the organisation (the resident who wants no involvement, and the person who will never join) and the one that is hostile (the critic).

**[A] Three qualifications, stated honestly rather than as a pass:**

1. **Coverage is a design claim, not a demonstrated fact.** §35.2 shows a *route exists* for every type. It does not show the route *works* — that is §57's pilot.
2. **Six routes depend on instruments that do not yet exist:** H-03 (public page), H-10 (credential), H-23 (modes), §50 (remote), §6.10 (Elder), H-16 (community charter). **Until those are adopted, the matrix is aspirational for those rows.**
3. **No promise of universal coverage before the pilot proves the system.** §41.3 of v1.3-B and §57 here both refuse to treat a favourable pilot as a national claim — and v1.3-B AD-10 established that a uniformly poor city may have no viable route at all. **A route existing on paper is not a route existing in a locality.**

---

# 36. MASS ADOPTION FUNNEL

## 36.1 The funnel

Your brief's ten stages, mapped to levels and to the variables the pilot must measure. **No conversion rate is assigned anywhere.**

| Stage | Level | What marks entry | Variable the pilot must measure |
|---|---|---|---|
| **1 AWARE** | L0 | Has encountered the organisation in any form | `N_aware` — *and note: awareness is not measurable by the organisation except through inbound contact* |
| **2 CURIOUS** | L0 | Has sought information: opened the page, asked a question, attended a stall | `N_curious` = inbound contacts, page requests, questions |
| **3 PARTICIPATES** | L1 | Has reported a need **or** attended one activity | `N_participate` |
| **4 CONTRIBUTES** | L2 | Has completed one defined contribution | `N_contribute` |
| **5 RETURNS** | L2–L3 | **A second contribution within the defined window** | **HM-9** — the metric the stress test chose over conversion **[S-ST: §21.3]** |
| **6 DEVELOPS** | L3–L4 | Has taken training, a credential, a larger scope, or a specialist engagement **voluntarily** | `N_develop`, `N_credential` |
| **7 VERIFIES** | **L5** | Has chosen to apply and completed the full lifecycle **[S: Ch.12]** | `N_member` |
| **8 COORDINATES** | L6 | Holds a workstream | `N_coordinator` |
| **9 LEADS** | L7 | Holds a primary or sub-role | `N_leader` |
| **10 BUILDS** | L8 | Creates teams, ventures or standards | `N_builder` |

## 36.2 Why no conversion rates are assigned

**[A]** Four reasons, each sufficient:

1. **Your brief forbids inventing adoption percentages.** There are none in the source, and **[S: Ch.33]** establishes the discipline of not inventing numbers.
2. **A rate would be a target, and a target at stages 3–5 destroys the win.** **[S-ST: §21.3]**: measuring conversion directly "causes the organisation to sell membership during the first win, which destroys the win."
3. **The funnel is not a funnel.** Stages 3–4 are **open to everyone permanently** (§8.2: a one-time contribution is a complete participation). A shape that implies narrowing implies failure, and most people in the shape are *succeeding*.
4. **Denominators are unknowable.** `N_aware` cannot be measured by the organisation. Any rate computed against it is fiction.

## 36.3 What is measured instead

**[P]** Six quantities, all countable from records the architecture already requires:

| Measure | Formula | Why this one |
|---|---|---|
| **Inbound contacts** | `N_curious` per period, per locality | The only honest awareness proxy — people who came to *us* |
| **First-participation completion** | `N_contribute / N_participate` | Tests §10 and §13, not marketing |
| **Voluntary return** | **HM-9**: second contribution within window | **The stress test's chosen metric; the closest thing to a truth-teller in the set** |
| **Active ratio** | `r_act = N_act / N_ver` | **[S: Ch.25]** already requires attendance cross-check and "healthy active retention, not inactive names"; **v1.3-B §14.3** shows `N_ver` is the wrong planning variable |
| **Helped-not-joined count** | People served who never participated | **§8.4**: published as a success metric |
| **Level distribution** | Count at each level | Detects a funnel that is actually a cliff — e.g. many L2, no L3, which is a design finding not a failure |

## 36.4 The two structural findings the funnel reveals

**[A]**

1. **The step from 4 to 5 (contribute → return) is the whole business.** Everything before it is an offer; everything after it is a relationship. **If HM-9 is low, no amount of awareness spending matters** — and if HM-9 is high, awareness spending is largely unnecessary, because §39's referral channel is working.
2. **The step from 6 to 7 (develop → verify) should be *small*, and that is correct.** Applying for membership is a decision to accept responsibility, verification and conduct duties **[S: Ch.12]**. A design in which most developers become members has either lowered the standard or is pressuring people. **§7.1's boundary requires this step to be a real threshold.**

---

# 37. ACQUISITION WITHOUT MANIPULATION

## 37.1 The nine channels, assessed

| Channel | Permissible? | Conditions | Prohibited use |
|---|---|---|---|
| **Community referrals** | **YES — the primary channel** | Referral is thanked, never rewarded (§22.3 MLM-4/MLM-6) | Paying for referrals; tracking who referred whom for benefit |
| **Local events** | YES | Six-test gate (H-13); no recruitment moment attached to a service (§28.2 rule 2) | Using a service event as a captive audience |
| **Schools / colleges where appropriate** | **YES with heavy conditions** | Guardian consent; safeguarding; education priority; institutional permission; no compulsory participation | Presenting participation as an academic requirement; recruiting minors into anything beyond L1–L3 (§48) **[V]** |
| **Professional networks** | YES | L4 scope agreement; conflict declaration | Implying employment or endorsement |
| **Local businesses** | YES | Activity-scoped partnership; **v1.3-A A-01** neutrality; §39.3 sponsorship conditions | Political adjacency; treating a shop as a donor ATM (§14 segment 7) |
| **Digital content** | YES with limits | Verified facts only; distinguish completed work from plans; protect privacy **[S: Ch.24]**; authorised spokespersons | Follower-count vanity; exaggeration; **§18.4 of v1.3-B: social media is not a customer channel** |
| **Service demonstrations** | **YES — the strongest channel** | The demonstration *is* the service: a fixed drain, not a stall about fixing drains | Staging a service for an audience; photographing recipients (§33.2) |
| **Partnerships** | **NOT ASSUMED APPROVED** | **[S: Ch.29]** partnership flow and due diligence apply; **UNRESOLVED in [S: Ch.33]** | Any partnership presented as endorsement before approval |
| **Word of mouth** | YES — and it is the only channel that cannot be manufactured | It is produced by §40's small-promise sequence, not by a campaign | Solicited testimonials from beneficiaries (§16.2 BS-4) |

## 37.2 The two absolute prohibitions

**[P]**

1. **Vulnerable beneficiaries are never acquisition tools.** Not their stories, not their images, not their presence, not their gratitude, not their names. **v1.3-A A-19** and §16.2 BS-4 make this absolute, and §33.2 lists it as a prohibited story form.
2. **No acquisition message may contain any of the six prohibited appeals** **[S-ST: §6.4]**: unapproved earnings figures; protection from a group; religious or caste merit; political change; personal loyalty to a leader; fear of missing a benefit.

## 37.3 The acquisition test

**[P]** One question, applied to any channel, message or event:

> **Would this approach still be acceptable if the person said no — and would they find it easy to say no?**

If saying no is awkward, costly, public or recorded, the approach is manipulative whatever its content. **This is §34.4's test applied to acquisition.**

---

# 38. THE FIRST REAL COMMUNITY LOOP

## 38.1 The smallest repeatable loop

```
PROBLEM → CONTRIBUTOR → ACTION → RESULT → FEEDBACK → RECOGNITION → NEXT CONTRIBUTION
```

**[A]** Mapped to existing architecture — **every step already exists**, which is why this loop can run at Stage 0 with no new instrument except the feedback and recognition steps:

| Step | Existing basis | What is missing |
|---|---|---|
| **PROBLEM** | **[S: Ch.8 steps 1–2]** local observation, resident request, logged with location, urgency, risk, privacy | A **public** intake (H-03, H-05) |
| **CONTRIBUTOR** | **[S: Ch.15 step 7]** verified and trained members scheduled | **Levels 1–2 entry** (§6) and pairing (H-06) |
| **ACTION** | **[S: Ch.8 steps 6–8; Ch.15 step 8]** project created, resources assigned, executed within safety, finance, HR and privacy boundaries | Nothing |
| **RESULT** | **[S: Ch.15 steps 9–10]** evidence, outcome verification: "Did the project solve or reduce the problem?" | Nothing — **this is the architecture's strongest existing feature** |
| **FEEDBACK** | **[S: Ch.9 Follow-up Coordinator]** exists as a role | **The return path to the contributor and to the reporter does not exist** → **H-15** |
| **RECOGNITION** | **[S: Ch.24 "achievements"; Ch.25]** | **Separated instruments (H-08), narrative not ordinal below L5 (§7.3)** |
| **NEXT CONTRIBUTION** | **[S: Ch.8 step 1]** the loop restarts | **An invitation that can be declined without cost (§12.1 week 4; H-17)** |

## 38.2 What would prove the loop works

**[P]** Seven pieces of evidence, each collectable in the pilot without new technology:

| # | Evidence | Source of truth |
|---|---|---|
| **E-1** | A problem reported by a **resident** (not identified by the team) was verified and acted on | Request log **[S: Ch.8 step 2]** |
| **E-2** | A person at **L1 or L2** took part in the action | Task record; pairing record (H-06) |
| **E-3** | The outcome was **verified**, not asserted | Outcome field **[S: Ch.15 step 10]** |
| **E-4** | The **reporter** was told what happened, within a stated window | H-15 record; HM-7 |
| **E-5** | The **contributor** was told what happened, within a stated window | H-15 record; HM-7 |
| **E-6** | The contributor was **recognised in a non-ordinal way** | H-08 instruments 1–2 |
| **E-7** | **Somebody came back** — and somebody else did not, and neither was penalised | HM-9; §21 records |

**[A] E-7's second half is as important as the first.** A loop in which everyone returns is suspicious, and a loop in which nobody is made to feel bad for not returning is the one that produces §39's word of mouth. **The proof that the loop is healthy is that exit is easy and unremarkable.**

## 38.3 Why this loop is the pilot's unit of observation

**[A]** Because it is the smallest thing that exercises **every** part of the human system at once: discovery, entry, low-level participation, delivery, verification, attribution, recognition, invitation and exit. **§57's pilot is designed around completing this loop N times and recording E-1…E-7 each time** — not around counting members.

---

# 39. SOCIAL PROOF

## 39.1 How trust actually spreads

**[A]** Trust in a locality travels through **people who are known**, not through channels. **[S-ST: §22.2]** examined the "I know someone who helped me" effect and found it real but slow, and dependent on the help having been *verifiable*.

| Signal | Strength | Why | Constraint |
|---|---|---|---|
| **Verified outcomes, shown locally** | **Strongest** | Unfakeable, nearby, and already required **[S: Ch.15 step 10]** | Must be shown without exposing anyone (§17.4) |
| **A named person who answers** | **Very strong** | Interpersonal trust precedes institutional trust (§40) | Requires the person to actually answer — silence destroys it (§27.2) |
| **Transparent records and published accounts** | Strong for officials, donors, partners; **weak for residents in ten seconds** | Verifiable | **[S: Ch.24 annual cadence]**; v1.3-B B-26 |
| **Local reputation over time** | Strong, slow, and **durable** | Accumulated small promises (§40) | Cannot be accelerated; can be destroyed instantly |
| **Visible service** — the thing itself, in public | Strong | A fixed drain is its own advertisement | Must be real, not staged (§37.1) |
| **Member experiences, told by members** | Strong | Peer testimony | Must be unsolicited; **never manufactured** |
| **Customer results** | Strong within the commercial segment | Repeat and referral are the cheap revenue (v1.3-B §18.5) | Customer confidentiality (v1.3-A A-17) |
| **Independent validation** — audit, professional review | Medium; decisive for institutions | External | **[V]**; only where it exists |
| **Professional partnerships** | Medium | Association | **[S: Ch.29]** due diligence; **UNRESOLVED [S: Ch.33]** |
| **Follower counts, views, celebrity endorsement** | **Negative** | Performative; and the source forbids using them to determine leadership **[S: Ch.25]** | Prohibited as primary signals (§9.5) |
| **Awards and superlatives** | **Negative** | Unfalsifiable; and v1.3-A A-07 requires under-claiming | Prohibited |

## 39.2 What must never be done

**[P]** Five prohibitions:

1. **No manufactured testimonials.** A testimonial that was requested, scripted, incentivised or selected for effect is an advertisement wearing a witness's clothes.
2. **No purchased social proof.** No paid promotion presented as organic, no bought followers, no planted reviews. **[S: Ch.25]** already requires detection of "mass fake reviews and pressure" for community ratings — the rule applies to the organisation's own conduct as well.
3. **No exaggerated impact.** "Do not count planned activities as completed impact" **[S: Ch.15]**; "Real outcomes, not inflated counts" **[S: Ch.15 step 12]**.
4. **No beneficiary used as proof.** §37.2 prohibition 1.
5. **No comparative superiority claim.** **[S-ST: §19.2]**: existing faith, caste and neighbourhood bodies hold far more trust than a new entity; claiming superiority is false, insulting, and manufactures enemies. **The defensible claim is "we are verifiable" — a different axis, on which winning requires nobody to lose.**

## 39.3 The one legitimate amplifier

**[A]** There is exactly one way to accelerate social proof without manufacturing it: **make the evidence easier to see.** A dated board at the site of completed work; a published local list of what was done and when; a resident able to check what happened to their own reported need. **All three are already obligations of the architecture** **[S: Ch.15; Ch.24]** — none is marketing.

**[P]** Rule: *the organisation may make its evidence more visible. It may not make its claims more impressive.* The first is transparency; the second is advertising, and §40 shows why advertising before delivery is fatal.

## 39.4 Serving the sceptic

**[S-ST: §8]** lists "Sceptics / critics / journalists" as a segment whose need is **"truth, access, accountability"** and whose contribution is **"scrutiny — which is a service to the institution."**

**[P]** Three provisions:
1. **An answered question is a trust event.** A published response to a hard question does more than a hundred testimonials.
2. **A correction published quickly is an asset.** **[S: Ch.24]** correction logs; **v1.3-A A-15 M4** corrections are permanent.
3. **The public complaint route is external and named** (**v1.3-A A-07** requires published complaint routes; CK-1 requires independence). **A complaint route that goes to the person complained about is not a route.**

---

# 40. TRUST BEFORE BRAND

## 40.1 The two sequences

**[P]** The permitted sequence, and the prohibited one:

```
PERMITTED:   SMALL PROMISE → DELIVER → SHOW EVIDENCE → BUILD REPUTATION → LARGER PROMISE
PROHIBITED:  HUGE PROMISE → BRAND CAMPAIGN → HOPE THAT DELIVERY FOLLOWS
```

**[A]** The prohibited sequence is not merely risky; it is **structurally unavailable to this organisation**, because:
- **v1.3-A A-07** requires a public statement that states limits *more loudly* than capabilities, and forbids exaggerated authority.
- **v1.3-A A-11 G-N** gates any public protection claim behind evidence.
- **v1.3-B §46.1** shows the first team has no capacity to deliver a large promise in months 1–6.
- **[S: Ch.24]** permits only verified facts and requires completed work to be distinguished from plans.
- **[S-ST: §23]** institutionalisation table: national brand is **deliberately late** — "brand follows evidence, never precedes it."

## 40.2 The promise ladder

**[P]** Each rung may be claimed only after the rung below has been delivered and evidenced:

| Rung | The promise | Evidence required before claiming it |
|---|---|---|
| **1** | "We will come and look at the problem you reported." | Nothing — this is claimable on day one, and it is the only claim a new team should make |
| **2** | "We will tell you what we found." | Rung 1 delivered; H-15 attribution functioning |
| **3** | "We will try to fix it, with you." | Capability exists; permissions held; resources identified |
| **4** | "We fixed it — here is the evidence." | Outcome verified **[S: Ch.15 step 10]**; follow-up performed (§18) |
| **5** | "We do this regularly in this locality." | `n` completed loops with E-1…E-7 (§38.2) |
| **6** | "You can rely on us for this kind of problem." | Rung 5 sustained across a seasonal cycle (v1.3-B HC-15) |
| **7** | "We can do this in your locality too." | A second locality, evidenced — **v1.3-B §30 Stage 6 replication test** |
| **8** | "We are a national organisation." | **Never claimed by the organisation.** It is claimed by others, or not at all |

**[A] Rung 8 is the important one.** An organisation that describes itself as national before it is, has spent the credibility it needed for rungs 1–7. **The stress test's institutionalisation table places national brand at Stage 4–5 and explicitly marks it "deliberately late"** **[S-ST: §23]**.

## 40.3 The mechanism

**[A]** Why the ladder works, stated as a mechanism rather than a slogan:

1. **A small promise is easy to keep**, so early reliability is achievable even by a Stage-0 team with no revenue (v1.3-B §9.2: intake, verification and time-costed service all continue at ₹0).
2. **A kept promise is evidence**, and evidence is the only trust signal that cannot be bought (§39.1).
3. **Evidence travels through people**, and people travel at the speed of conversation — which is why §36 assigns no conversion rate: the rate is set by the locality, not by the organisation.
4. **A broken large promise destroys the small ones retroactively.** Trust is not compartmentalised: an organisation that over-claimed once is re-read entirely.

**[P] Rule (H-04 extension):** *no communication may claim a rung that has not been delivered in the locality where the communication appears.* A national claim in a locality where rung 2 has not been achieved is a lie told locally, and it will be discovered locally.

---

# 41. HUMAN FAILURE

## 41.1 The ten assumptions

**[A]** Your brief requires the architecture to assume all ten. **Each is normal, frequent, and not a moral failing.** The design consequence is that the system must absorb them without converting them into records of blame.

| Assumption | What the architecture currently does | What it must do | Instrument |
|---|---|---|---|
| **People get tired** | Nothing — absence becomes a vacancy problem **[S: Ch.11]** | Treat fatigue as expected; bounded hour contracts; pause without penalty | H-23 time contract; H-18 |
| **People disagree** | Conduct process **[S: SOP-17]** — which frames disagreement as a conduct matter | Separate *disagreement* from *misconduct* absolutely | §42; §43 |
| **People make mistakes** | Evidence and audit will find them | **Mistakes reviewed, not punished**; correction in private | §43; **[S: Ch.14 step 5 "avoid fear of reporting problems"]** |
| **People leave** | Six vacancy statuses **[S: Ch.11]** — posts, not people | Paused and alumni status for people | **H-18**; §21 |
| **People lose motivation** | Performance system measures teams **[S: Ch.25]** | Motivation is not measurable and must not be scored; **the return loop is the instrument** | §27; §26 |
| **People have family obligations** | Nothing | Family-legibility; never "organisation above family" | §19.3; §20 AC-8 |
| **People change jobs** | Nothing | Mode switching without re-application | H-23; §15.2 |
| **People relocate** | Nothing — and relocation is a leading exit reason **[X-inherited: S-ST §6.2/§7.3]** | **Portability is the answer**: their record and credential travel (§25); a team in the new locality can be found | **H-10**; §25.2 |
| **People fail** | Failure recovery is support-first for **teams** **[S: Ch.14]** | Extend support-first to **individuals**: no task assigned beyond capability; failure produces training, not record | §43; **[S: Ch.9 "cannot assign untrained people to restricted tasks"]** |
| **People misunderstand instructions** | Nothing | One-line task descriptions; briefing before task; **the misunderstanding is a design defect, not a person defect** | §13 FR-13; H-06 |

## 41.2 The rule about absence

**[P]** *Absence is information, not disloyalty.*

**[A]** Three consequences:
1. **No absence is recorded as a negative attribute of a person.** It is recorded as a fact about a period, and it triggers a welfare check (**[S: Ch.9 Conduct & Welfare Coordinator]**), not a review.
2. **The first response to absence is a question, not a warning.** "Is everything alright?" precedes anything else, and the conduct process **[S: SOP-17]** is not invoked for absence alone.
3. **A pattern of absence may indicate a design failure** — a task that is too far, too long, badly timed, or socially uncomfortable. **§13's friction map is the diagnostic**, and the fix is usually the schedule, not the person.

## 41.3 Humane recovery mechanisms

**[P] H-20 extension — five mechanisms:**

| Mechanism | What it is | Basis |
|---|---|---|
| **The pause** | Leave without losing anything, return without re-applying | H-18 |
| **The reduction** | Change mode or cadence without explanation | §15.2; H-17 |
| **The re-pairing** | A person who had a bad experience is paired with different people, not the same ones | H-06/H-12 |
| **The re-brief** | A person who failed a task is re-briefed and re-offered, with the failure treated as a briefing defect | §41.1 last row |
| **The return** | Alumni may come back at the level they held, subject only to certification currency | §21.1 right 4 |

**[A]** What is deliberately absent: **no rehabilitation record, no probation-after-failure, no "second chance" framing.** All three imply that the person was ever in jeopardy, and jeopardy is what §43 exists to remove. **The only recorded outcomes of a mistake are the correction and the lesson (v1.3-A A-15 M5).**

---

# 42. CONFLICT BETWEEN PEOPLE

## 42.1 The eight ordinary conflicts

**[A]** Each is ordinary, frequent, and — if unhandled — becomes either a silent exit or a formal grievance. **The design principle: most conflict should be resolved by a conversation before it becomes a process.**

| Conflict | First response | If unresolved | Escalation | Existing basis |
|---|---|---|---|---|
| **Two volunteers disagree** | The pairing member or Coordinator listens to both, separately, then together | Team Leader mediates | City HR **[S: Ch.7 lane 2]** | **[S: Ch.9 Conduct & Welfare Coordinator]**; **[S: SOP-17]** |
| **Leader and member disagree** | **The member may go around the leader** — a route that does not pass through the person complained about | City HR | State HR **[S: Ch.7 "City HR → State HR if unresolved"]** | **v1.3-A A-16 §15.2 item 5**; **[S-ST: M10]** Integrity Line |
| **Customer and worker disagree** | Scope and acceptance criteria re-read **[S: Ch.17 steps 4, 10]** | Business Manager | City AI & Business → State Business/Legal **[S: Ch.7 lane 5]** | **[S: Ch.14 business failure row]**; **v1.3-B B-13** |
| **Specialist and manager disagree** | Scope agreement re-read; **the specialist advises, never commands** | Team Leader + City | State specialist pool lead **[S: Ch.6]** | §6.5; **[S-ST: §9.3]** |
| **Local and city team disagree** | City review of the evidence | State escalation filter | National **[S: Ch.6 "prevents national overload"]** | **[S: Ch.7 escalation map]** |
| **Member criticises leadership** | **Received as information, recorded, and answered** | Standard-change request route | Independent route (CK-1) | **[S-ST: F-13, M23]**; **v1.3-A A-15 M1** |
| **Member wants to leave** | §21.4 exit conversation, offered not compelled | Alumni status; **no persuasion process** | None — the decision is theirs | §21 |
| **Team disputes recognition** | The record is checked — recognition is evidence-linked (§23.3 rule 1) | City review | Corrections and appeals process | **[S: Ch.25 "anomaly review, corrections and appeals"]** |

## 42.2 The six mechanisms your brief names

| Mechanism | Design | Limit |
|---|---|---|
| **Listening** | Separate conversations first; the listener does not decide | Listening is not mediation; it must lead somewhere within a stated window |
| **Mediation** | A person with no stake and no authority over either party; **Elder/Mentor standing is well suited** (§6.10: mediates, no command) | A mediator cannot decide; if a decision is needed it goes to the role that owns it |
| **Evidence** | Records already kept: task, delegation, payment, incident, conduct **[S: Ch.19, Ch.22, App. F]** | Evidence about *conduct* is sealed (**v1.3-A A-20**) and access is case-scoped |
| **Appeal** | **[S: Const. Art.17]** grievance and appeal; **[S: Ch.25]** corrections and appeals | An appeal needs a body that is not the original decider — which requires the CEO/Council question to be answered (**UNRESOLVED [S: Ch.33; v1.3-A N19]**) |
| **Escalation** | **[S: Ch.7]** six lanes, already defined | Escalation must have a clock (§20.3 of v1.3-B); an escalation without a time limit is a dismissal |
| **Separation where necessary** | Different pairing, different team, different workstream — **without either party losing standing** | Separation must never be a punishment in disguise; §21.1 right 6 makes team change a right, so it cannot be a sanction |

## 42.3 What is deliberately NOT built

**[A]** Your brief says: preserve v1.2 governance; do not invent a court-like system unnecessarily. **Three refusals:**

1. **No tribunal, no hearing, no formal pleadings** for ordinary interpersonal conflict. The existing conduct **[S: SOP-17]** and serious-misconduct **[S: SOP-18]** processes remain, and they are sufficient for what they cover.
2. **No new adjudicative body.** Appeals use **[S: Const. Art.17]** and the escalation lanes **[S: Ch.7]**. Creating a court would require resolving the CEO/Council question, which is **UNRESOLVED** and which v1.3-A declined to resolve.
3. **No conflict-resolution metric.** Counting conflicts produces under-reporting (§36.2 logic; §43). **What is measured is the *route's usage*, not the conflict rate** — and, as with dissent, **a zero count is a warning.**

**[V]** Employment-discipline, natural-justice and safeguarding requirements apply to any conduct process and require professional review; the underlying worker-classification decision remains **UNRESOLVED [S: Ch.33; v1.3-B E-C2]**.

---

# 43. PSYCHOLOGICAL SAFETY

## 43.1 The seven sentences that must be sayable

**[P] H-20.** A human system is safe if a person at *any* level can say each of these, in their own language, without a consequence they would want to avoid:

| # | Sentence | Why it is the test | What must be true |
|---|---|---|---|
| **1** | **"I disagree."** | Without it, decisions are unchallenged and errors compound | A recorded reason exists for every decision (**v1.3-A A-15 M1**), so disagreement has something to attach to; a standard-change route exists (**[S-ST: M23]**) |
| **2** | **"I made a mistake."** | Without it, mistakes are hidden until they are catastrophic | §41.3: correction and lesson recorded, never a rehabilitation file; **[S: Ch.14 step 5]** |
| **3** | **"This policy is not working."** | Without it, the architecture ossifies | Standard-change request route reaches City → State → National; **the requester is answered** |
| **4** | **"I need help."** | Without it, overload becomes failure | §23 support-first applies to individuals, not only teams; welfare coordination exists **[S: Ch.9]** |
| **5** | **"I cannot do this."** | Without it, people are assigned beyond capability and QA collapses | H-17 right of refusal; **[S: Ch.9]** untrained people are not assigned to restricted tasks |
| **6** | **"I want to leave."** | Without it, retention is coercive | §21 in full; **§26.3's test: could they leave cheaply?** |
| **7** | **"I think the leader is wrong."** | Without it, leadership is unaccountable and §20 AC-2 is already true | A route that **does not pass through the person complained about** (**v1.3-A A-16 §15.2; CK-1**); anti-retaliation **[S-ST: App. A §18.4]** |

## 43.2 How safety is produced rather than declared

**[A]** Five mechanisms, none of which is a policy statement:

1. **Recorded reasons.** A decision with a written reason can be argued with. A decision without one can only be obeyed (**v1.3-A A-15 M1**).
2. **An independent route.** CK-1: concerns reach someone who does not report to the person concerned. **This is the single necessary condition** — without it, sentences 1 and 7 are unsayable.
3. **Visible fair outcomes.** **[S-ST: §7.3 item 10]**: "one visibly fair grievance outcome per year in a city does more for retention than any policy document."
4. **Leaders who disclose their own mistakes.** §32.4: culture travels by what people see rewarded. A leader who says "I got that wrong" authorises everyone else.
5. **No measurement of safety itself.** Counting reported problems produces under-reporting. **What is measured is whether the route was *used* and whether the person was *answered*.**

## 43.3 The zero-count warning

**[P]** Applied to three quantities, on the same logic v1.3-A A-16 applies to dissent:

| Quantity | A zero count means |
|---|---|
| Concerns raised | **The route is not trusted** — not that nothing is wrong |
| Mistakes reported | **Mistakes are being hidden** — not that none are made |
| Standard-change requests | **People believe change is impossible** — not that the standards are perfect |

**[A]** This is counter-intuitive and it must be stated in the pilot design (§57), because a pilot team that reports "no problems, no complaints, no mistakes" will otherwise be scored as a success. **It is the most likely failure the human pilot will produce, and it will look like a pass.**

---

# 44. RECOGNITION WITHOUT STATUS ADDICTION

## 44.1 The question

> **Does recognition motivate contribution, or create obsession with ranking?**

**[A]** Both, depending on design — and the architecture already knows it. **[S: Ch.25]** contains eight anti-gaming controls and states plainly that "Raw revenue, follower count, social-media views, **volunteer count, application count or raw activity count cannot determine leadership**." **[S-ST: §6.2 row 9]** rates recognition ⚠️ double-edged: "Cheap, immediate, addictive. Drives performance *and* gaming."

## 44.2 The seven diagnostics of status addiction

**[P]** Each is observable from records the architecture already keeps:

| # | Diagnostic | Detector |
|---|---|---|
| **SA-1** | Contribution falls when nobody is watching | Compare activity in measured vs unmeasured periods |
| **SA-2** | Work migrates toward whatever is scored | Category drift: easy projects over difficult needs (**v1.3-B I-02**) |
| **SA-3** | Counting replaces doing | Activity counts rise while outcome-verification rates fall **[S: Ch.15 step 10]** |
| **SA-4** | Friendships become competitive | §56 HF-13; team-transfer requests; refusal to pair with strong performers |
| **SA-5** | Recognition is sought rather than received | Requests for awards exceed occurrences of recognition |
| **SA-6** | A person's standing depends on rank rather than on acts | Ordinal language appearing at L0–L4 (§7.3 SR-3) |
| **SA-7** | Leaving is experienced as demotion | §26.3 coercive-retention test; exit-interview themes |

## 44.3 Alternatives and supplements

**[P]** Seven instruments that motivate **without** ranking, each already traceable to source:

| Instrument | What it produces | Basis |
|---|---|---|
| **Contribution milestones** | "You have done this ten times" — **absolute, never comparative** | H-08 instrument 2 |
| **Skill credentials** | Portable, standard-based, externally checkable | **H-10**; §25.3 |
| **Team achievements** | "We fixed the lane" — the belonging sentence | §19.1; §38 |
| **Service stories** | A place, a problem, a date — never a ranking | **H-14**; §33 |
| **Peer appreciation** | Person to person, unrecorded, unscored | H-08 instrument 1; §23.3 rule 2 |
| **Project completion** | The satisfaction of a finished thing, witnessed | §27.1 |
| **Reliability recognition** | "You came when you said you would" — **the most underrated virtue in a volunteer system** | §15; §41.1 |

**[A]** Note that **six of seven are absolute rather than comparative.** Ranking is the only mechanism with a fixed supply; every other form of recognition can be given to everyone who earned it. **That is the whole answer to status addiction: increase the supply of the things that are not scarce.**

## 44.4 Where the existing performance system belongs

**[P]** **Nothing is removed.** **[S: Ch.25]** is preserved verbatim, including its PROPOSED weights, and its scope is stated:

| The performance system is for | It is not for |
|---|---|
| Comparing **teams**, to allocate support, learning and earned leadership **[S: Ch.25, Ch.26]** | Comparing **people** |
| Detecting **gaming** through its eight controls **[S]** | Producing individual recognition |
| Triggering **support-first recovery** **[S: Ch.14]** | Triggering shame |
| Being reviewed, corrected and appealed **[S]** | Being published for L0–L4 (§7.3 SR-3) |

**[A]** And **R5 remains open**: whether the leaderboard should be public at all **[S-ST: §25.3 R5]**. **This instrument does not resolve it**, and carries it forward to §59 unchanged.

---

# 45. LOCAL HERO WITHOUT PERSONALITY CULT

## 45.1 The concept, retained and bounded

**[A]** The architecture's dynamic-leadership ladder **[S: Ch.26]** and Head Team concept **[S: Ch.34]** already produce locally prominent people. The question is not whether to recognise them but **what the recognition is about.**

> **Recognised for WHAT THEY DID — never for WHO THEY ARE.**

## 45.2 The two messages

| Recognition that says | Effect |
|---|---|
| **"Anyone can contribute."** | Invitation. The recognised person is *evidence* that ordinary participation works | 
| **"Only exceptional people matter."** | Exclusion. The recognised person becomes a *standard* that discourages the next person |

**[P] Five rules that keep recognition on the first line:**

1. **Recognise the act, in the act's own terms.** "Cleared the blockage in lane 4 on 12 August, with nine others" — not "our outstanding volunteer".
2. **Recognise the ordinary, repeatedly.** Reliability (§44.3) and quiet service (§33 priority 5) are recognised as often as dramatic acts. **If only dramatic acts are recognised, the message is that ordinary participation is invisible.**
3. **Recognise groups first.** The belonging clause of §3 is "I was not alone in it"; a story about one person contradicts it (§17.4, §33).
4. **No imagery of the person as a symbol.** No portrait campaigns, no "face of Sewak Sathi", no poster recognition — **v1.3-A A-16 §15.4** already prohibits portrait display and requires decisions in the institution's name.
5. **The recognised person is asked, not chosen.** Consent per item (§33.3 rule 3). A person who does not want to be named is not named, and this is not recorded as a deficiency.

## 45.3 The specific danger: the charismatic local leader

**[A]** A local hero is an asset until they become a **necessary condition**, at which point the team is one resignation from collapse (**v1.3-B §29 Scenario 4, HC-02**) and the culture is one grievance from a following (§20).

**[P] Four guards:**

| Guard | Mechanism |
|---|---|
| **Successor exists before prominence is consolidated** | **v1.3-B B-18(1)** successor-before-transition; §6.8 |
| **Attribution is to roles and teams** | **v1.3-A A-16 test 2**; §17.4 subject rule |
| **The person can be disagreed with safely** | §43 sentence 7; CK-1 independent route |
| **Promotion does not destroy the team** | **v1.3-B B-18** in full: overlap, bounded mentorship, promotion-cohort reporting, horizontal recognition as an alternative |

**[A]** Note that **the Elder/Mentor standing (§6.10) is the release valve**: it lets a locally prominent person hold real respect indefinitely **without** holding command, and therefore without becoming a bottleneck or a cult centre.

---

# 46. LIVELIHOOD DOOR

## 46.1 The two directions

> **Can someone enter for service and discover livelihood?**
> **Can someone enter for livelihood and discover service?**

**[A]** Both, and both are already latent:

| Direction | Mechanism | Existing basis | Risk |
|---|---|---|---|
| **Service → livelihood** | A volunteer's demonstrated skill is verified **[S: Ch.17 step 6 "verified skills"]**, and they become eligible for paid venture work at L5 | **[S: Ch.12 training; Ch.18 priority 1; Ch.19 step 7]** | **The discovery must be an offer, never an implication.** A volunteer who begins to hope for payment and is not offered it has been worse treated than one who never hoped (§34.3, §3.7) |
| **Livelihood → service** | A paid contributor participates in a time-costed service activity, meeting people and a purpose they did not come for | **[S: Ch.15]**; **v1.3-B B-09 rule 2** — service is voluntary and never a condition | **Service must not become an obligation of employment.** v1.3-B B-09 rule 2 already forbids the reverse; both directions must be forbidden |

## 46.2 The connection to v1.3-B

**[A]** The human system and the economic model meet at exactly one point, and it is worth stating precisely:

- **v1.3-B §34.1 question 1** found that workers are **not** currently paid predictably.
- **v1.3-B §34.2 D-1/D-2** required a written formula and honest disclosure before recruitment.
- **v1.3-B §12.7** concluded that worker-first is a rule about dividing a surplus, and a new team has no surplus.

**[C] Therefore the Livelihood Door has a precondition that is economic, not communicational:** *the door may only be opened where the waterfall can actually reach the person walking through it.* Concretely:

| Condition | Requirement |
|---|---|
| The compensation formula exists in writing and is approved | **v1.3-B E-02**; **[S: Ch.33 NOT FINAL]** |
| The earnings reality is disclosed in the weak month, not the good month | **v1.3-B §34.2 D-2**; **[S-ST: M16]** |
| The venture is approved and its category selected under §19's framework | **[S: Ch.17 step 3]**; **v1.3-B B-14** |
| The team is at or approaching `B_healthy` | **v1.3-B §11.2** |
| Accrual and scarcity rules exist, so a bad month is fair rather than arbitrary | **v1.3-B B-05, B-06** |

**[A] If those five are not met, Door 3 must not be advertised** — and the correct action is to open Doors 1 and 2 only, honestly. **A door that opens onto nothing is worse than a closed door**, because it produces the "scheme" accusation (**[S-ST: F-02]**) and an ex-member with a grievance.

## 46.3 Preventing economic dependency from becoming ideological dependency

**[P]** Five rules:

1. **A person may accept work, refuse work, leave, return and pursue other opportunities — without coercion.** All five are H-17 rights and are stated in the engagement, not merely permitted in policy.
2. **No exclusivity.** Nothing prevents a member from working elsewhere, competing lawfully, or serving another organisation. **An exclusivity clause would be both coercive and, in most cases, unenforceable [V].**
3. **No advance or debt that binds.** **v1.3-B §12.6 rule 1**: a member is never expected to fund operations personally, and **v1.3-B §26.3** identifies debt binding as coercive retention. **Where a float exists (B-04), it is owed by the organisation's structure, never by the individual** **[V]**.
4. **Compensation is never conditioned on belief, loyalty, attendance at events, or participation in service.** v1.3-B B-09 rule 2 in both directions.
5. **The exit is as easy as the entry.** §21.2: accrued compensation is paid on leaving, at priority 1. **A person who is owed money they cannot collect without staying is not free** (**[S-ST: §7.4]**).

**[A]** The test is the same as §26.3's, applied to money: **could this person leave tomorrow, in good standing, with everything they are owed?** If not, the livelihood door has become a cage.

---

# 47. SPECIALIST PATH

## 47.1 The problem

**[A]** The architecture has one visible progression: the role ladder **[S: Ch.9, Ch.10, Ch.26]**. Its apex is management. **[S-ST: F-24]** found the consequence: leadership is a **tournament** with a scarce prize, so most capable people hit a ceiling — and the organisation loses them, or keeps them discontented.

**[A]** And there is a second, economic consequence: **v1.3-B §17.4** ranks trained delivery people as bottleneck #2 and §24.5 identifies leader supply as a *stock* problem. **A specialist path multiplies the useful population without multiplying the management population** — which is the only way to raise `P_max` without raising `H_gov`.

## 47.2 The horizontal ladder

**[P] H-11.** Increasing responsibility **without** becoming a general manager:

| Stage | What grows | What does **not** grow | Existing basis |
|---|---|---|---|
| **S1 Demonstrated** | A skill is verified against a published standard | Nothing else | **[S: Ch.12; Ch.17 step 6]** |
| **S2 Trusted scope** | Larger or harder scopes within the same skill | Command over people | **[S: Ch.10]** delegation, recorded and bounded |
| **S3 Verifier** | May verify others' work in that skill | No general authority | **[S: Ch.12]** training/verification roles; **L4→L5 boundary respected (§7.1)** |
| **S4 Advisor** | Advises teams and the City; contributes to standards | **Advises, never commands** **[S-ST: §9.1]** | **[S: Ch.6]** State specialist pool |
| **S5 Mentor / Elder** | Teaches, witnesses, holds memory, mediates | **Excluded from RBAC command and from scoring** | §6.10; **[S-ST: §7.3 item 12]** |
| **S6 Standard-setter** | Owns a standard or curriculum through the change-request route | No line authority | **[S-ST: F-13, M23]**; **v1.3-A A-15** |

## 47.3 The domains

Your brief lists twelve; each is mapped to the source's own controls, because **specialist authority is bounded by the professional-validation rule**:

| Domain | Basis | Hard limit |
|---|---|---|
| **Technology** | **[S: Ch.22 platform; Ch.9 AI & Business family]** | AI may recommend, humans decide **[S: Ch.21]** |
| **Finance** | **[S: Ch.9 Funds family; Ch.18 segregation]** | **Cannot combine receive + approve + record + audit** |
| **Legal** | **[S: Ch.5 Legal & Compliance]** | **Internal training is not legally sufficient [S: Ch.12]**; advice is not an organisational position **[V]** |
| **Design** | **[S: Ch.9 Editor family; Ch.17 category controls]** | IP, consent, fact-check, content rights **[S]** |
| **Medicine / health** | **[S: Ch.15 health-support]** | **"No diagnosis/treatment unless licensed" [S]**; referral and awareness only **[V]** |
| **Education** | **[S: Ch.15 education; Ch.17 education/training]** | Trainer competence; **safeguarding for minors [S][V]** |
| **Logistics** | **[S: Ch.9 Warehouse family; Ch.7]** | Restricted goods and write-offs require approval **[S]** |
| **Media** | **[S: Ch.9 Social Media and Editor families; Ch.24]** | Verified facts only; authorised spokespersons **[S]** |
| **AI** | **[S: Ch.21; Ch.9 AI Ops Coordinator]** | Prohibited-decision list preserved verbatim; **v1.3-A A-21/A-22** |
| **Business** | **[S: Ch.17; Ch.9 Business family]** | Category approval required **[S: Ch.33 POTENTIAL]** |
| **Field service** | **[S: Ch.9 Ground-Level Manager family; Ch.8]** | Safety doctrine and DO-NOT list bind at every level (**v1.3-A A-08**) |
| **Other verified skills** | **[S: Ch.11 eligibility engine]** | Standard published before the skill is recognised (§25.3 condition 1) |

## 47.4 What makes the specialist path credible

**[A]** Four conditions, without which it is a consolation prize and everyone will know it:

1. **It carries real scope.** S2–S4 must involve decisions that matter, not titles that do not.
2. **It is recognised outwardly.** H-10 credentials make horizontal growth legible to employers and institutions (§25).
3. **It is recognised inwardly without ranking.** §44.3: absolute instruments, never comparative.
4. **It can be paid.** Where a specialist performs venture work, priority 1 applies **[S: Ch.18]**; where they are engaged as a supplier, priority 3 applies **[S: App. A §14.3]**. **A path with no economic expression is a hobby.**

---

# 48. YOUTH PARTICIPATION

**[A]** This section is written conservatively, because the downside is not organisational but human, and because **[S: Ch.12]** already establishes that internal training is not legally sufficient for child safeguarding.

## 48.1 The governing rules

| # | Rule | Basis |
|---|---|---|
| **Y-1** | **No legal age rule is invented here.** Minimum ages, permissible hours, prohibited work and consent requirements are **[V]** and must come from counsel and from applicable law | Your brief; **[S: Ch.12 professional-validation boundary]** |
| **Y-2** | **Guardian consent is required** wherever the participant is a minor, for every activity, in writing, in the guardian's language, and revocable | **[P]**; **[V]** |
| **Y-3** | **The two-adult rule applies to every activity involving minors** — no minor is ever alone with one adult | **v1.3-A B6 / A-11 category 11**; **[S-ST: §8 school-students row]** |
| **Y-4** | **Education comes first.** No activity may conflict with schooling or examinations; participation is paused, not penalised, during exam periods | **[P]**; §14 segment 1 |
| **Y-5** | **Prohibited responsibilities for minors:** money handling, reserve or expense approval, verification of others, incident response, protection activity, publication, conduct processes, and any restricted task | **§7.1 boundary** applied *more* strictly; **[S: Ch.9 "cannot assign untrained people to restricted tasks"]**; **v1.3-A A-08/A-09/A-11** |
| **Y-6** | **No image, name or story of a minor is ever published** — with or without consent | **v1.3-A A-19** (guardian consent **plus the minor's own assent**); **[S: Ch.15 "no exposure of minors"; App. F]** |
| **Y-7** | **Online safety:** no unsupervised digital communication between an adult member and a minor; no minor in a remote-only engagement without a guardian-known local anchor | **[P]**; **[V]**; §50 |
| **Y-8** | **Safeguarding concerns escalate immediately and are never handled locally** | **v1.3-A A-09** mandatory escalation; **A-20** sealed handling |
| **Y-9** | **No minor may be recruited, or approached about joining, through a school or activity in a way that makes participation feel required** | §37.1 conditions; §34.4 test |
| **Y-10** | **Certified safeguarding training is a precondition for any adult working with minors** | **[S: Ch.12]**; **[V]** |

## 48.2 What youth participation is *for*

**[A]** Not recruitment, and not labour. **[P]** Three legitimate purposes:

1. **Safe structured activity with adult mentors** — a real community need (§14 segment 1).
2. **Skill and character development** — with a credential that is honest about scope (§25.3 condition 4).
3. **Family-legible participation** — a parent and child contributing together (§19.3).

**[A]** A fourth purpose is explicitly rejected: **numbers.** Youth participation inflates headcount cheaply, and **[S: Ch.25]** already forbids letting volunteer counts determine anything. **A team that recruits minors to look larger has failed §44 and §22 simultaneously.**

## 48.3 Age-appropriate roles (proposed, subject to Y-1)

| Band | Appropriate | Never |
|---|---|---|
| **Child (with guardian, present)** | Family-inclusive activity; observation | Any task; any record about them beyond consent |
| **Young teen** | Supervised group activity in public space; digital-literacy helper **alongside** an adult; documentation assistance | Anything involving money, minors younger than themselves, private homes, night, transport, or a vulnerable adult |
| **Older teen** | L2–L3 contributions with guardian consent; training; a credential | L4 specialist scope; L5 responsibility; any Y-5 item |

**[V]** Every band boundary, hour limit and activity type requires legal review before use. **Nothing above is a legal position.**

---

# 49. ELDER PARTICIPATION

## 49.1 The design principle

**[A]** Elders are the most under-designed segment in the architecture and the most valuable for the human system, because they supply exactly what §2.2 found missing: **continuity, memory, mediation, witness and standing without command.**

> **Physical volunteering is not necessary.** §50's remote modes and §6.10's Elder standing both make contribution possible without physical work.

## 49.2 Seven participation areas

| Area | What it is | Level | Basis |
|---|---|---|---|
| **Mentoring** | Sitting with newcomers; teaching by presence | **Elder / L4** | §6.10; **[S-ST: §7.3 item 12]** |
| **Knowledge** | Local craft, practice, history, seasonal knowledge | L2–L4 | §32.4 culture transmission |
| **Community history** | Oral history; the memory of what the locality was | Elder | **v1.3-A A-15 M7** oral history |
| **Education** | Teaching, tutoring, reading with children **under the two-adult rule and safeguarding certification** | L3–L4 | **[S: Ch.15 education]**; §48 Y-3/Y-10 |
| **Coordination** | Scheduling, telephone follow-up, register-keeping — low-physical, high-reliability work | L3–L6 | **[S: Ch.9]** Coordinator families |
| **Advisory contribution** | Judgement on local disputes, priorities, and what will not work | **Elder** — advises, never commands | §6.10; **[S-ST: §9.1]** |
| **Local relationship networks** | Knowing who is who, who is trusted, who is at risk — **the single most valuable intelligence a neighbourhood team can have** | L1–Elder | §39.1 local reputation |

## 49.3 What elder participation requires

**[P]** Five provisions, all of which are also accessibility provisions (§14 segment 24):

1. **Paper and voice routes, always** (§29.3 rule 2). An app-first design excludes elders systematically.
2. **Daytime, near-home, seated-capable activities** as the default offer.
3. **No physical requirement anywhere in the record.** The contribution record (§24) records what was done, never how.
4. **Standing without command** (§6.10) — the mechanism that makes an elder's exclusion from RBAC a *design feature* rather than a demotion.
5. **Intergenerational pairing in both directions.** A young member teaches a device; an elder teaches a locality. **Both are recorded as contributions.**

**[A]** The strategic reason to design for elders deliberately: **they are the segment with the highest tenure and the lowest churn.** In a model where `C_vol_per_hour` falls with tenure (**v1.3-B §15.3**), elders are the most economically efficient volunteers the organisation can have — and they are the ones a youth-oriented design excludes first.

---

# 50. REMOTE PARTICIPATION

## 50.1 The question

> **Can someone contribute without living near a team?**

**[A] Yes — and for a substantial part of the work.** The architecture already assumes physical presence at every point (site visits, verification, service delivery), which excludes §14 segments 3, 19, 24 and 25 unnecessarily.

## 50.2 What can remain remote

| Contribution | Remote-capable? | Basis | Constraint |
|---|---|---|---|
| **Software / platform** | **Fully** | **[S: Ch.22]**; §14 segment 19 | Access controls, RBAC, AI logs **[S: Ch.21; v1.3-A A-21/A-22]** |
| **Design / editing / content** | **Fully** | **[S: Ch.9 Editor family; Ch.17 category 4]** | IP, consent, fact-check **[S: Ch.17]** |
| **Translation and terminology** | **Fully** | §30; **v1.3-A A-06 V11** review pattern | **L1 texts require legal review [V]** |
| **Research and analysis** | **Fully** | **[S: Ch.17 category 3]** | Customer data legality **[S]**; **v1.3-A A-17** |
| **Documentation and record-keeping** | **Fully** | **v1.3-A A-15** memory instruments | Privacy classification |
| **Planning and scheduling** | **Fully** | **[S: Ch.9 Planner family]** | Local knowledge is partial — pair with a local |
| **AI operations** | **Fully** | **[S: Ch.21; Ch.9 AI Ops Coordinator]** | Prohibited-decision list preserved; review capacity (**v1.3-A A-21**) |
| **Business development and pipeline** | **Mostly** | **[S: Ch.7]** City pipeline is already non-local | Closing usually needs a local |
| **Telephone follow-up (§18)** | **Fully** | **[S: Ch.9 Follow-up Coordinator]** | **Never for safeguarding cases**; consent and privacy apply |
| **Training delivery** | **Partly** | **[S: Ch.6]** State trainer pool is already non-local | **Certified and practical domains cannot be remote [S: Ch.12][V]** |
| **Mentoring** | **Partly** | §6.10 | Weaker without presence; **minors: §48 Y-7** |
| **Funding and donor relations** | **Fully** | §35 donor row | **FCRA [V]**; **v1.3-B B-26** |

## 50.3 What requires physical presence — absolutely

| Requires presence | Why |
|---|---|
| **Site verification** | "Site visit, phone/partner confirmation, photos where appropriate or multiple witnesses" **[S: Ch.8 step 4]** — a phone confirmation is permitted *in addition*, never *instead*, for a first verification |
| **Service delivery** | The product is presence |
| **Protection and emergency response** | **v1.3-A A-09/A-11**; certification required |
| **Safeguarding-sensitive activity** | Two-adult rule; certified supervision **[V]** |
| **Materials handling and stock** | **[S: Ch.9 Warehouse family; SOP-15, SOP-16]** |
| **Belonging formation for a newcomer** | **H-06 requires two existing members physically alongside** — remote pairing produces a contact, not a relationship |

## 50.4 The remote-participation problem nobody designs for

**[A]** Remote contributors do the work and miss the belonging. **§19.1 shows belonging is produced by proximity, repeated effort and shared result** — none of which a remote contributor gets. **[I]** The predictable outcome: remote contributors are the most productive and the most likely to leave silently, because nothing holds them except the task.

**[P] Four provisions:**

1. **Every remote contributor is paired with a named local person** — not a manager, a *person* — who tells them what their work became on the ground. **This is H-15 attribution applied deliberately to remote contributors**, and it is the substitute for presence.
2. **Remote contributors appear in the outcome, not only in the invoice.** "This page was built by X in <city>; it is used by the team in <locality>" — with consent.
3. **A remote contributor may visit, and the visit is funded as a capability cost, not a perk.** Once a year, if they wish. **Cost: `C_travel`, a v1.3-B OC line [M].**
4. **Remote participation has its own mode (M-6) with its own time contract** (§15), because remote work expands to fill silence and produces its own burnout.

---

# 51. NATIONAL EMOTIONAL CONNECTION

## 51.1 Why one advertisement cannot work

**[A]** Your brief's instruction is correct and the reason is structural: **India is not one emotional market.** **[S-ST: §12.2]** documented how differently the proposition lands across urban metros, small towns, rural areas and tribal regions. A single national message either says nothing specific or offends someone specific.

## 51.2 The layered identity

```
PERSON → FAMILY → LOCAL COMMUNITY → CITY → STATE → INDIA
```

**[P] H-26 extension.** The requirement: **the proposition of §3 must be compatible at every layer** — meaning a person can say the same true sentence about themselves at each scale.

| Layer | The sentence at this layer | What makes it true |
|---|---|---|
| **Person** | "I did something useful." | H-15 attribution; §17 |
| **Family** | "My family knows what I do here, and approves." | §19.3 family-legibility |
| **Local community** | "My lane is better and I was part of it." | §38 community loop; §33 story priority 1 |
| **City** | "Teams across this city do this, and we help each other." | **[S: Ch.7]**; **v1.3-B B-21** |
| **State** | "Specialists and trainers come to us from across the state." | **[S: Ch.6]** |
| **India** | "This happens in neighbourhoods across the country, and no single story is the story." | §31.2 two-way flow; §40 rung 8 |

**[A] The critical property: each layer is verified by an *event*, not by a claim.** A person feels the national layer when a specialist arrives from another city — not when a hoarding says "national organisation." **This is why §40 forbids claiming rung 8: the organisation cannot produce the event that would make it true for a stranger.**

## 51.3 What the layers must never do to each other

| Prohibited | Guard |
|---|---|
| The national layer overriding the local | §31.1 ID-1/ID-2 |
| The local layer contradicting the national standards | **[S: Ch.13]** autonomy is inside central standards; **v1.3-A A-08** no local reinterpretation |
| Any layer claiming superiority over another | §31.3; §30.3 rule 1 |
| Family pressure being invoked by any layer | §19.3; §20 AC-8 |
| The person being subordinated to any layer | §7.3 SR-1; §8.4 |

---

# 52. THE NATIONAL STORY

## 52.1 The narrative

> **ORDINARY PEOPLE HELPING ORDINARY PEOPLE.**

**[A]** Three properties make this the only viable national narrative for this architecture:

1. **It is falsifiable in the right direction.** Every clause can be evidenced: ordinary (no credential required to take part — L1 needs nothing), people (not an institution), helping (a verifiable act), ordinary people (a neighbour, not a category).
2. **It is already the architecture's own claim.** "Neighbourhood teams that fix local problems" **[S-ST: §20.2]**; the Mohalla is the direct-execution layer **[S: Ch.8]**; mission impact is the highest-weighted dimension **[S: Ch.25]**.
3. **It requires no enemy.** §34.3 prohibits outrage; **[S-ST: §6.2 row 18]** rates anger/opposition ❌.

## 52.2 The five prohibited narratives

| Prohibited | Why | Guard |
|---|---|---|
| **Political** | Any party, movement, ideology or election association destroys half the locality's trust permanently | **v1.3-A A-01…A-04** in full |
| **Religious** | Institutional invocation of faith classifies the organisation by faith | **v1.3-A A-05**; §30.4 |
| **Caste** | Caste framing imports exclusion and, in a service context, hierarchy | **v1.3-A A-05**; **v1.3-A A-18 §17.4** prohibits collecting caste data absolutely |
| **Enemy** | "They" narratives mobilise fast and poison permanently | §33.2; §34.3; **[S-ST: §6.2 row 18]** |
| **Superiority** | Claiming to be better than existing community bodies is false and insulting | **[S-ST: §19.2]**: the claim is *verifiable*, never *better* |
| **Founder-centred** | Personality dependence is the fastest growth and the worst durability | **v1.3-A A-16**; §20 AC-1/AC-3 |

> **[A] The organisation should not need an enemy to create unity.** The alternative to an enemy is a **shared, verifiable, local accomplishment** — which is §38's loop and §33's story priority 1. It is slower and it is the only one that lasts.

## 52.3 Why "Why India?" is not a rallying cry

**[S-ST: §29]** produced a factual, non-manipulative narrative about scale and unmet need. **[A]** This instrument's caution: **a national-scale argument is a reason for the *founder* to persist, not a reason for a *resident* to participate.** Nobody in a lane cares about a national statistic. **The national story is for internal endurance and external legitimacy; the local story is for participation.** Confusing the two produces hoardings and no volunteers.

---

# 53. NATIONAL SYMBOLISM

## 53.1 The governing rule

> **SYMBOLS MUST SIGNAL SERVICE, NOT FORCE.**

**[A]** This is not a stylistic preference. **v1.3-A** established that the organisation's most dangerous perception risk is being read as a private security force or a vigilante body (F-09), and that perception is formed **by one image, in ten seconds, by people who will never read the doctrine.** Symbolism is therefore a *safety* system.

## 53.2 The eight elements, assessed

| Element | Existing position | Constraint |
|---|---|---|
| **Logo** | **NOT DECIDED.** Nothing in the source specifies one; the name is PROPOSED **[S: Ch.33]** | Must pass §9's ten-second test: local, practical, open, not political, not religious, not security. **[H]** — must be tested, not chosen |
| **Colours** | **NOT DECIDED** | **Must avoid every colour associated with any political party or movement in any operating state [V]** — a colour that is neutral in one state is partisan in another. **v1.3-A A-06 V8–V11** prohibits communal and partisan symbols |
| **Typography** | **NOT DECIDED** | Must render correctly in every operating language (§30); legibility at low literacy and on a hand-painted board |
| **Symbols** | **NOT DECIDED** | Service imagery only. **Prohibited: weapons, shields, fists, flames, eagles, marching figures, uniformed silhouettes, any religious mark, any map outline used as an identity claim** |
| **Clothing** | **PROHIBITED as uniform or insignia** | **v1.3-A A-06 V1–V3**: no uniform, no insignia; identification is carried, not worn; task-scoped identification is removable and audited |
| **Identification** | **CONCEPT APPROVED** — minimal data, revocable token, **non-police visual design** | **[S: Ch.33]**; **v1.3-A A-17 §16.4** five use rules |
| **Digital identity** | Not specified | Privacy-first: minimal data, revocable, no profiling (**v1.3-A A-17/A-18**); no biometric collection without **[V]** |
| **Physical spaces** | **No facility requirement exists in the source (v1.3-B OC-05)** | If a space is used, it must not resemble an office, a station, a shrine or a party premises. **A shared community space is preferable to a branded one** |

## 53.3 What this document deliberately does not design

**[A]** No logo, colour, typeface or symbol is proposed here, for three reasons:

1. **Nothing in the source authorises one**, and inventing a visual system would convert a proposal into a decision.
2. **A visual system chosen in a document will be wrong in most localities.** §31.1 ID-2 requires local expression; a national template contradicts it.
3. **It must be tested, not argued.** §9.7's ten-second test is the correct method, and it requires real people in a real locality.

**[P] What is proposed instead:** a **symbol brief** — the constraints above, plus the six-test gate (H-13) and the ten-second test (§9.7) — to be given to local designers in the pilot city, with the winning artefact selected by the test rather than by preference. **The organisation supplies the constraint; the locality supplies the form.**

---

# 54. "WOULD PEOPLE MISS US?"

## 54.1 The test

> **If Sewak Sathi disappeared tomorrow, what would each group actually lose?**

**[A]** This is the strictest test in the document, because it cannot be answered with intentions. **If the only loss is "the organisation", the human value proposition is weak.**

## 54.2 The test applied

| Group | What they would lose **today**, on the architecture as written | What they would lose **if this instrument is adopted** | Verdict |
|---|---|---|---|
| **Beneficiaries** | A route to have a local problem verified and acted on; a number to call | The same, **plus** follow-up, plus the knowledge that help is not conditional on anything (§16.2) | **Real loss — conditional on the team actually having delivered.** A beneficiary of an organisation that has not yet acted loses nothing |
| **Volunteers** | A place to be useful; a record of what they did | The same, **plus** friendships, a portable credential, a pause button, and the outcome returned to them (§17, §25, §21) | **Currently weak, potentially strong.** Today: they would lose an activity. Adopted: they would lose relationships and a credential |
| **Specialists** | A scope in which to apply skill pro bono or paid | The same, plus a horizontal path and remote capability (§47, §50) | **Moderate.** Specialists have alternatives; the differentiator is *evidence of impact*, which the architecture uniquely has |
| **Workers (paid)** | Income under a worker-first waterfall with a published formula and audit trail | The same, plus accrual protection and a fair scarcity rule (**v1.3-B B-05/B-06**) | **Real loss — but only if the revenue exists** (v1.3-B §32.3) |
| **Businesses (customers)** | Verified local delivery with QA, acceptance and clear accounting | The same, plus collection terms and a referral route (§38.2, v1.3-B B-13) | **Moderate.** They would find another provider; they would not easily find *accountability* |
| **Local communities** | A cleaner lane, a fixed drain, a working process for raising a problem | The same, plus a public page, a calendar, a place to find skilled people (§28.1) | **The strongest loss — and the one that matters most**, because it is the loss that produces ambient legitimacy **[S-ST: §8 conclusion 1]** |
| **Leaders** | A role, scope, a team, standing | The same, plus a successor, a bounded differential, and protection from the promotion tax (v1.3-B B-18) | **Real, but leaders are the most replaceable group in the analysis** — and a system whose leaders would miss it more than its beneficiaries has its priorities inverted |

## 54.3 The honest reading

**[A]** Three findings:

1. **The community is the group that would lose most, and that is correct.** An organisation whose disappearance would be felt most by *people who never joined* has built the right thing. **§8.4's proposal — publish the count of one-time helpers as a success metric — is the reporting expression of this finding.**
2. **Volunteers would currently lose least**, because the architecture gives them an activity and takes a record. **H-06, H-09, H-10, H-12, H-15 and H-18 exist to change exactly that** — to make the loss include friendships, a credential and a returned outcome.
3. **Nobody would lose anything at all until the first loop completes.** §38 is therefore not a design exercise; it is the precondition for the organisation having any human value whatsoever. **A team that has completed zero loops is missed by no one, however good its architecture.**

## 54.4 The test as a recurring instrument

**[P]** Ask it annually, per locality, in the annual report cycle **[S: Ch.24]**:

> *Which specific person, in which specific place, would be worse off if this team stopped?*

**If the answer cannot be named, the team has not created human value yet** — and §40's ladder tells it which rung to return to. **This is a harsher test than any metric in §55, and it is the only one that cannot be gamed.**

---

# 55. HUMAN-SYSTEM METRICS

**Rule from your brief, adopted:** do not reduce humanity to a single score. **Every numeric target is `PROPOSED — REQUIRES PILOT VALIDATION`.** No target value appears anywhere in this section.

## 55.1 Why no composite human score

**[A]** The reasoning parallels **v1.3-B §28.3**, and it is stronger here:

1. **The dimensions are incommensurable.** Dignity and completion rate cannot be traded at any exchange rate without implying that enough activity compensates for humiliation.
2. **A human score would be gamed the same way a financial one would** — and the gaming would be worse, because the quantities are softer and the detectors weaker.
3. **[S: Ch.25]** already scores **teams**, not people, and already forbids raw counts determining leadership. **Extending a score to individuals would contradict it.**
4. **§44 shows recognition must be absolute, not comparative.** A human score is comparative by construction.

**[P] H-28 therefore specifies six metric *categories*, each reported in its own unit, with four veto-style gates.**

## 55.2 The six categories

### PARTICIPATION

| Measure | Definition | Unit | Instrument |
|---|---|---|---|
| **First contribution** | People completing one contribution in the period | count | HM-5 |
| **Repeat participation** | **Second contribution within the defined window** | rate | **HM-9** — the primary measure |
| **Active participation** | `r_act = N_act / N_ver` | ratio | **[S: Ch.25]** attendance cross-check; **v1.3-B §14.3** |
| **Voluntary return** | Returns after a pause or alumni period, uninvited | count | H-18; HM-9 |
| **Helped-not-joined** | People served who never participated | count | **§8.4 — reported as a success metric** |

### EXPERIENCE

| Measure | Definition | Unit |
|---|---|---|
| **Clarity** | Can they restate what the organisation is and does? | HM-2 |
| **Belonging** | Can they name two people here? | HM-3 |
| **Usefulness** | Can they say what they did and what it achieved? | HM-6, HM-7 |
| **Dignity** | Do participants *and* beneficiaries report being treated with respect? | HM-13 |
| **Trust** | Promises made vs promises kept | HM-14 |
| **Friction** | Where in §13 did they stop? | HM-15 |

### CONTRIBUTION

| Measure | Definition | Constraint |
|---|---|---|
| **Completed activities** | Verified complete, with outcome | **"Do not count planned activities as completed impact" [S: Ch.15]** |
| **Verified skills** | Credentials issued against a published standard | §25.3 |
| **Service impact** | Outcome-verified: resolved / reduced / unchanged / worsened / unknown | **§18.4: an honest "unchanged" or "unknown" is a success of measurement** |

### RETENTION

| Measure | Definition | Constraint |
|---|---|---|
| **Voluntary return** | As above | The primary measure |
| **Role continuity** | Roles held continuously; successor named per role | **v1.3-B B-18(1)** |
| **Healthy exits** | Exits that were dignified, settled and non-adversarial | **§21; a zero exit count is a warning (§43.3 logic)** |

### DEVELOPMENT

| Measure | Definition | Constraint |
|---|---|---|
| **Skills** | New verified skills per period | Voluntary uptake only (§12.1 week 3) |
| **Training** | Completed, and certification currency | **[S: Ch.12]** |
| **Responsibility** | Scope growth, **including horizontal scope** | §47; scope without rank is the point |

### COMMUNITY

| Measure | Definition | Constraint |
|---|---|---|
| **Relationships** | Pairings formed; teams stable across periods | H-12 |
| **Local trust** | Inbound requests from residents; repeat reporters | §39.1 |
| **Repeat collaboration** | Same contributors working together again | The belonging signal that is not self-reported |

## 55.3 The four human veto gates

**[P]** Mirroring **v1.3-B §28.2**: any breach means the human system is **not** healthy, regardless of every other reading.

| Gate | Breach condition | Basis |
|---|---|---|
| **HV-1 Coercion** | Any person participated, stayed, paid, gave consent, or was recorded under pressure; any recruitment appeal breached §3.7 | §34.3; §37.2; **v1.3-A A-01 N8** |
| **HV-2 Dignity** | Any beneficiary exposed, photographed without consent, recruited at the moment of need, or shamed | **v1.3-A A-19**; §16.2 |
| **HV-3 Cult** | Any §20 AC-1…AC-11 mechanism detected | §20; **v1.3-A A-16** |
| **HV-4 Extraction** | Any person paid to participate, any fee charged, any recruitment commission, any compensation correlated with headcount | §22.3 MLM-1…MLM-7; §39.3 |

## 55.4 Metric discipline

**[P]** Five rules, because a human metric can damage the thing it measures:

1. **No metric may be an individual target.** All are team- or locality-level, consistent with **[S: Ch.25]**.
2. **No metric may be ranked below L5.** §7.3 SR-3.
3. **Every metric has a stated interpretation risk** (§58 column 7) — what a good number can conceal.
4. **A metric that requires new data collection is not adopted at Stage 0–2** unless it is one of the fifteen (§58). **v1.3-B §26.3's control-budget rule applies to human metrics too.**
5. **The zero-count warning applies to every "problems reported" measure** (§43.3).

---

# 56. HUMAN FAILURE SIMULATIONS

**Method:** each of your twenty scenarios is run against the design. **Trigger / consequence / early signal / safeguard / recovery / unresolved question.**

| # | Scenario | Trigger | Likely consequence | Early signal | Safeguard | Recovery | Unresolved question |
|---|---|---|---|---|---|---|---|
| **HF-1** | **Person joins but never contributes** | Signed up at an event; no task followed | Roll inflates; `r_act` falls; the person feels mildly dishonest | Registration without a paired task within 48h | **H-06** pairing is triggered by *registration*, not by request; §12.1 day 1 | One low-friction offer, once. Then nothing. **Never a nudge campaign** | Is an inactive registration a *record* they can see? (§24 — their own record shows nothing, which is honest) |
| **HF-2** | **Person contributes once and disappears** | Life; a bad first experience; no outcome returned | Normal, and **should be counted as success** (§8.4) | No second contribution inside the window | §21.1 right 3; §12.1 week 4 four equal options | Their record and credential persist; return needs one message | **Do we ever ask why?** §21.4 offers, never compels — and asking a one-time helper for an interview is itself friction |
| **HF-3** | **Volunteer burns out** | Unclear hours; consecutive heavy tasks; no pause taken | Exit of a reliable person — the most expensive exit (**v1.3-B HC-01**) | Attendance falling; tasks declined; irritability; the *most* reliable person going quiet | **H-23** explicit time contract; §41.1 fatigue is expected; §43 sentence 5 "I cannot do this" | Pause (H-18), re-pairing (§41.3), reduced mode — **with no record of deficiency** | How is burnout distinguished from disengagement without asking? |
| **HF-4** | **High performer becomes arrogant** | Recognition concentrated on one person; ordinal ranking creeps in | Team fracture; others withdraw; the performer becomes a bottleneck | Recognition mentions clustering; others' contributions falling; "ask them" becoming the answer | §44.3 absolute-not-comparative recognition; §45.2 five rules; §23.3 rule 2 mostly local | Elder/Mentor redirection (§6.10): standing without command; scope change; **v1.3-B B-18** if promotion is involved | Can a person be told they are behaving arrogantly without a conduct process? §42 mediation, not SOP-17 |
| **HF-5** | **Leader becomes controlling** | Power without a successor; dissent route unused | §20 AC-2/AC-7; dependency; silent exits | Zero dissent recorded (§43.3); decisions with no recorded reason; others deferring | **v1.3-A A-15 M1** reasons; **A-16** four annual tests; CK-1 independent route; §43 sentence 7 | Mediation (§42); City HR escalation **[S: Ch.7 lane 2]**; **[S: Ch.14 leadership failure row]** coaching then replacement | Who reviews a leader when the Council's authority is **UNRESOLVED [S: Ch.33; v1.3-A N19]**? |
| **HF-6** | **Member disagrees publicly** | A real grievance; a real error | **Healthy if handled well; fatal if suppressed** | A public post, a raised voice at a meeting, a written objection | §43 sentence 1; standard-change route; **[S: Ch.24]** correct calmly with facts and correction logs | Answer with facts; correct if wrong; **thank them in the same channel**; log the reason (**v1.3-A A-15 M1**) | Is a public disagreement "misconduct"? **No — and this must be written down, or it will be treated as such** |
| **HF-7** | **Member leaves and criticises the organisation** | A bad exit; a real failure; a personality conflict | Reputation damage locally; **and a legitimate voice** | Exit interview themes; a growing audience for the criticism | §21.3 no retaliation; §21.5 speak neutrally, never by name; §43 | Answer facts publicly; correct errors; **do not characterise the person**; offer the alumni route | Should the organisation ever engage a critic in dialogue? **[P] Yes on facts, never on character** |
| **HF-8** | **Beneficiary refuses future contact** | Dignity; fear; a bad experience; simple preference | The correct outcome — **and a loss of follow-up data** | A refusal recorded at any point | **§16.2 BS-5**: refusal recorded and honoured absolutely; **v1.3-A A-20 §19.7** subject rights | Stop all contact; record the outcome as "unknown, contact declined" | Does a declined follow-up count as a failed outcome? **[P] No — it counts as an honoured refusal** |
| **HF-9** | **Team becomes socially exclusive** | Homogeneous recruitment; cliques; informal criteria | A caste/class/faith pattern emerges without anyone deciding it | Participation composition narrowing; newcomers not returning; "we know each other" as a reason | **v1.3-A A-05** composition monitored but never engineered; **A-18 §17.4** no caste/religion data; §19.4 prohibition 2; H-06 pairs across the existing group | City review; re-pairing; open-task publication (§28.1); **a deliberate invitation to a different locality** | **How is exclusivity detected without collecting identity data?** — the hardest unresolved question in this document (§59) |
| **HF-10** | **Local team becomes personality-centred** | A charismatic leader; attribution drift | §20 AC-1/AC-3 at local scale | Stories naming one person; decisions attributed to a person; the team's identity is a name | §17.4 subject rule; **v1.3-A A-16 test 2**; §45.2; §33 story framework | Attribution correction; **v1.3-B B-18** successor-before-transition; Elder redirection | Can attribution be corrected retroactively in published stories? (§33.3 rule 2 — corrections are permanent records) |
| **HF-11** | **Business members ignore service** | Revenue pressure; `H_svc` consumed | **v1.3-B §29 Scenario 9**: economically survivable, mission-fatal | `H_svc` below budget while revenue rises | **v1.3-B B-01** service hour budget; §55 mission dimension; **[S: Ch.25]** mission impact 20% | Enforce the budget; City review of mission balance | Is a mission-balance breach a *veto* or a *variance*? **[P] Variance at first, veto if sustained** |
| **HF-12** | **Service members distrust business members** | The paid/unpaid boundary is unclear | Two castes inside one team | Separate social groups; "they only came for money" | **v1.3-B B-09** boundary rules published; §23.1 recognition separated from pay; §44 no ranking | A shared task — **the only thing that actually works**; §32.4 culture transmission | Should business and service members be paired deliberately? **[P] Yes, in H-06 pairing logic** |
| **HF-13** | **Leaderboard creates unhealthy competition** | Comparative scoring without cohort normalisation | §44.2 SA-4: friendships become competitive | Team-transfer requests; refusal to share method; score-focused conversations | **[S: Ch.25]** anomaly review, corrections, appeals; **[S-ST: M8]** cohort normalisation; §44.4 scope | Suspend comparison for the cohort; publish the correction | **R5 — whether the leaderboard should be public at all — remains UNRESOLVED [S-ST: §25.3]** |
| **HF-14** | **Recognition becomes popularity-based** | Appreciation given for visibility rather than contribution | The quiet majority withdraw | Recognition clustering on the articulate; outcome-verification decoupled from recognition | §23.3 rule 1 evidence-linked; §44.3 reliability recognition; §45.2 rule 2 recognise the ordinary | Re-weight toward outcome-verified acts; **audit who is *never* recognised** | Can recognition be audited without becoming a score? |
| **HF-15** | **Recruitment becomes the primary growth metric** | Headcount targets; expansion pressure | §22.5 growth-as-metric; MLM-adjacent dynamics | Application counts reported upward as achievement | **[S: Ch.25]** application count cannot determine leadership; §22.3 MLM-1; §36.2 no conversion targets; **§8.4 publish helped-not-joined as success** | Replace the reported metric with HM-9 and outcome counts | **Who sets the growth target, and can it be refused?** §43 sentence 3 |
| **HF-16** | **A charismatic leader begins demanding loyalty** | Personal following; grievance route unused | §20 AC-4/AC-5/AC-9 — the cult pathway | Loyalty language; "after everything"; isolation of dissenters; gifts and favours | **§20 all eleven prohibitions as Tier-1 candidates**; CK-1; **v1.3-A A-16** four tests; §22.3 MLM-6 no referral value | **Immediate**: independent review; role suspension; the person is protected, not punished, until findings exist | **How fast can this be stopped when the Council's authority is UNRESOLVED?** — §59 carries it |
| **HF-17** | **Members treat the organisation as more important than family** | Over-scheduling; belonging as the only social world; guilt framing | §20 AC-8; family opposition; a local reputation for breaking homes | Hours rising for a few people; family members complaining; activities at family times | §19.3 family-legibility; **H-23** bounded contracts; §34.3 guilt prohibited; §20 CK-4 exit interviews | Reduce the schedule **from the organisation's side**, not by telling the person to | Can the organisation intervene in a member's private priorities at all? **[P] Only by reducing its own demands — never by advising them** |
| **HF-18** | **National identity becomes political** | A date, a colour, a slogan, a map, an association | **v1.3-A F-08 at national scale** — permanent misclassification | Political adjacency in imagery; a leader's public political activity; a partnership with a partisan body | **v1.3-A A-01…A-04** in full; §53.2 colour and symbol constraints; §31.3; §52.2 | Withdraw the imagery; publish the refusal; **A-04 refusal register** | **Who decides a colour is political in a given state?** [V] and local |
| **HF-19** | **Local identity becomes exclusionary** | "Our area, our people"; territoriality between teams | Inter-team hostility; exclusion of outsiders; a communal reading | Refusal to collaborate; language about "them"; boundary disputes over needs | **v1.3-A A-05**; §31.3 no superiority; §7.3 SR-5 need-based priority regardless of who reports | City coordination **[S: Ch.7]**; joint activity; **the priority-assessment criteria [S: Ch.8 step 5] contain no locality-preference term and must not acquire one** | Can a team refuse a request from outside its area? **[P] Yes on capacity, never on identity** |
| **HF-20** | **Organisation becomes famous before it becomes effective** | Media attention; a viral story; a political endorsement; a large donation | Promises outrun delivery; §40's prohibited sequence; scrutiny exceeds capability | Inbound contacts rising faster than completed loops; journalists asking questions the records cannot answer | **§40 rung discipline**: no claim above the delivered rung; **v1.3-A A-07** under-claiming; **[S: Ch.24]** authorised spokespersons only | **Slow down publicly.** Publish what has actually been done and what has not; decline interviews that exceed the rung | **Can attention be refused?** [P] Yes — and declining a national story to protect a local promise is the correct trade, and must be pre-authorised so a spokesperson can do it |

## 56.1 What the twenty simulations show

**[A]** Four conclusions:

1. **Fifteen of twenty have a safeguard that already exists** in v1.2, v1.3-A or v1.3-B — the design is not starting from nothing. **Five require new instruments**: HF-9 (exclusivity detection without identity data), HF-13 (R5), HF-16 (speed of intervention), HF-17 (intervention limits), HF-20 (pre-authorised refusal of attention). **All five are routed to §59 as unresolved.**
2. **The most dangerous scenarios are the ones that look like success:** HF-11 (high revenue, no service), HF-14 (recognition flowing), HF-15 (recruitment growing), HF-20 (fame arriving). **Every one of them improves a visible number while degrading the system.** That is why §55 refuses a composite score.
3. **The most common scenarios are the quiet ones:** HF-1, HF-2, HF-3. They produce no incident, no complaint and no record — only absence. **§55's `r_act`, HM-9 and HM-3 exist because nothing else detects them.**
4. **HF-9 is the hardest problem in this document.** Detecting social exclusivity without collecting caste, religion or ethnicity data — which **v1.3-A A-18 §17.4 prohibits absolutely** — has no clean solution. §59 records it honestly rather than proposing a mechanism that would violate the privacy rule it is meant to serve.

---

# 57. HUMAN-SYSTEM PILOT

## 57.1 The distinction from the v1.3-B pilot

**[A]** **v1.3-B §40** designed a pilot to answer *can the unit survive economically?* Its fifteen measurements (P-01…P-15) are governance hours, contribution margins, collection rates, retention and City cost. **This pilot answers a different question and must not duplicate that one.**

> **v1.3-B asks: does the arithmetic work?**
> **v1.3-C asks: do the people work?**
>
> **[P] They are the same pilot, run on the same team, with two measurement sets.** Running two separate pilots would double the burden on a Stage-0 team and violate **v1.3-B §26.3**'s control-budget rule.

## 57.2 The twelve questions your brief specifies

**[P]** Each is given a method, because a question without a method produces an opinion:

| # | Question | Method | Why the method fits |
|---|---|---|---|
| **1** | **Did they understand the purpose?** | §9.7 ten-second test, run with non-members in the locality; plus HM-2 with participants | Comprehension is testable; agreement is not the point |
| **2** | **Did they participate without pressure?** | HV-1 gate check; §37.3's test applied retrospectively to every invitation issued; a **decline-rate** observation | **A high decline rate with no adverse consequence is evidence of freedom**, not of failure |
| **3** | **Did they contribute?** | HM-5; §38.2 E-2 | Countable from existing task records |
| **4** | **Did they return?** | **HM-9** — second contribution within the window | The stress test's chosen metric **[S-ST: §21.3]** |
| **5** | **Did they feel useful?** | HM-6, HM-7 — asked in their language, by someone outside the team | Self-report is the only source; independence reduces courtesy bias |
| **6** | **Did they feel respected?** | **HM-13**, asked of participants **and** of beneficiaries, separately | Dignity is a veto gate (§55.3 HV-2) and cannot be inferred from activity |
| **7** | **Did they understand their options?** | Ask them to state the four options of §12.1 week 4, **including the right to decline all four** | If they cannot state the refusal, they did not have it |
| **8** | **Did they feel safe disagreeing?** | §43.1's seven sentences, tested by **observation of whether each was ever actually said** — not by asking whether people feel safe | **Asking produces compliance. Observation produces evidence** |
| **9** | **Did they understand the difference between service and business?** | Ask a participant to explain which of their activities were paid and which were voluntary (**v1.3-B B-09 rule 7**) | If they cannot, the boundary has failed whatever the ledger says |
| **10** | **Did they understand that leaving is allowed?** | Ask; and check whether any person actually paused, reduced or left **without adverse consequence** | **A right nobody has exercised is unproven** |
| **11** | **Did beneficiaries feel respected?** | HM-13 with beneficiaries, by an independent person, **at least a day after help, never by the person who delivered it** (**v1.3-A A-19 consent architecture applied to research**) | The most easily corrupted measurement in the set; independence is non-negotiable |
| **12** | **Did leaders create belonging or dependency?** | **§26.3's test: for every person who stayed, could they have left cheaply?** Plus **v1.3-A A-16**'s four institutional tests applied locally | Dependency is structural, not attitudinal — it is measured by the cost of exit |

## 57.3 Pilot design rules

**[P]** Six:

1. **One team, one locality, ordinary.** The same team as **v1.3-B §40.5 rule 2** — chosen for measurability, not impressiveness.
2. **Two measurement sets, one burden.** §58's fifteen measurements and v1.3-B's fifteen, sharing every record.
3. **The measurement period spans one full local cycle** — a season, an exam period, a festival — so that HM-9 is not measuring a calendar (v1.3-B HC-15).
4. **Independent collection for HM-13 and question 8.** The team cannot measure its own dignity or its own safety. City or an external reviewer collects **[S: Ch.7; Ch.23 auditor separation]**.
5. **Publish the failure conditions before starting** — §42 of v1.3-B's discipline applied here: what would make this pilot *unsuccessful* is stated in advance.
6. **No target values.** Every threshold is `PROPOSED — REQUIRES PILOT VALIDATION`. **A pilot run against a target produces a result; a pilot run against a question produces knowledge.**

## 57.4 What would make the human pilot unsuccessful

**[P]** Six failure conditions, parallel to **v1.3-B §42**:

| ID | Condition | Detector | What is learned |
|---|---|---|---|
| **HPF-1** | **Coercion detected** — any HV-1 breach | §55.3 | The proposition or the recruitment practice is manipulative; redesign before scaling |
| **HPF-2** | **Dignity breach** — any HV-2 breach | §55.3 | The service model humiliates; **v1.3-A A-19** implementation failed |
| **HPF-3** | **Nobody returns** — HM-9 near zero across the window | HM-9 | The first win did not work; §11 and §27 break points are the diagnostic |
| **HPF-4** | **Nobody can say what they did** — HM-6/HM-7 near zero | HM-6, HM-7 | **Attribution is broken**, which is §4.3's most damaging break |
| **HPF-5** | **The seven sentences were never said** — no dissent, no mistake, no refusal, no request for help recorded in the whole period | §43; §56 HF-16 pattern | **Psychological safety is absent** — and the pilot's own reporting is unreliable |
| **HPF-6** | **Beneficiaries report feeling used** | HM-13 | The beneficiary/recruitment separation (§16.2) failed |

**[A] Note HPF-5's second clause:** if nobody ever disagreed, made a mistake, refused a task or asked for help during the entire pilot, **the pilot's data cannot be trusted**, because it was produced under compliance. **That is the most likely way for this pilot to fail while appearing to succeed.**

## 57.5 What the human pilot must NOT measure

**[P]** Four refusals:

1. **Member conversions.** **[S-ST: §21.3]**: measuring conversion directly destroys the first win.
2. **Headcount growth.** **[S: Ch.25]**; §22.5.
3. **Individual satisfaction scores.** §55.4 rule 1: no metric may be an individual target.
4. **Anything requiring new personal data beyond §58's privacy column.** **v1.3-A A-18** applies to research too — a study is not a licence to collect.

---

# 58. THE FIFTEEN HUMAN MEASUREMENTS

**Rule:** no target values are invented. Each measurement specifies what, why, how, who sees it, privacy implications, frequency and **interpretation risk** — the last being what a good number can conceal.

| # | What is measured | Why it matters | How collected | Who sees it | Privacy implication | Frequency | Interpretation risk |
|---|---|---|---|---|---|---|---|
| **HM-1** | **Inbound contacts** — needs reported, questions asked, people who approached us | The only honest awareness proxy (§36.3) | Count from the public intake record **[S: Ch.8 step 2]** | Team, City | Minimal: a contact is not an identity | Monthly | A high count can mean curiosity **or** unmet need in the locality — the two require opposite responses |
| **HM-2** | **Comprehension** — can a person restate what this is and what they could do? | Stage 2 of the journey (§4.1); §9.7 test | Short structured conversation by someone **outside** the team, in the person's language | City, National (aggregate) | No personal data retained; **aggregate only** | At pilot; then per cohort | People may answer correctly to please the asker — **use a non-team asker** |
| **HM-3** | **Belonging** — can they name two people here? | The second clause of §3; §19.1's primary mechanism | One question, asked conversationally | Team, City (aggregate) | **Names of others must not be recorded** — only the count | Per cohort; then quarterly | Naming two people who are both leaders indicates dependency, not belonging |
| **HM-4** | **First-participation completion** — of those who started, how many finished the first activity? | Tests §10 and §13 | From task records | Team, City | Own record only | Monthly | Completion under pressure is not participation — cross-check with HV-1 |
| **HM-5** | **Contribution completion** — one defined contribution done | Stage 4 of the journey | Task record with outcome | Team, City | Own record | Monthly | Counts can be inflated by splitting tasks — **[S: Ch.25]** "no artificial splitting" |
| **HM-6** | **Can they say what they did?** | Usefulness (§55.2); the subjective half of attribution | One question, in their language | City (aggregate) | Aggregate only | Per cohort | A confident answer can mask a trivial task — pair with HM-5 |
| **HM-7** | **Attribution received** — was the outcome returned to them, inside the stated window? | **The most damaging break in the loop** (§27.2); H-15 | From the H-15 record | Team, City | Outcome data is **place-based, never person-based** (§17.4) | Per contribution | Attribution delivered late is counted as delivered — **measure the window, not the fact** |
| **HM-8** | **Follow-up outcome known** — resolved / reduced / unchanged / worsened / unknown | §18; the mission-balance data **v1.3-B B-01** and **[S-ST: M14]** require | Follow-up record **[S: Ch.15 step 10]** | Team, City, State (aggregate) | **Aggregate by category and locality; never by beneficiary** | Per project; quarterly roll-up | A 100% "resolved" rate means follow-up is not happening (§18.4) |
| **HM-9** | **Voluntary return** — second contribution within the defined window | **The primary measure.** Chosen over conversion by the stress test **[S-ST: §21.3]** | Two dated contribution records | Team, City | Own record | Rolling; window `PROPOSED — REQUIRES PILOT VALIDATION` | A short window flatters; a long window hides. **The window must be tested against local rhythms (§11.4)** |
| **HM-10** | **Development taken up voluntarily** — training, credential, scope, specialist engagement | Stage 7; §47; the anti-gate test | From training and delegation records **[S: Ch.12, Ch.22]** | Team, City | Own record | Quarterly | **Compulsory training inflates this and proves nothing** — record only voluntary uptake (§12.1 week 3) |
| **HM-11** | **Understanding of the service/business distinction** | PM-4; **v1.3-B B-09 rule 7** | Ask them to classify their own activities | City (aggregate) | Aggregate only | Per cohort | Correct answers given after being told the answer measure nothing — **ask before explaining** |
| **HM-12** | **Understanding that leaving is allowed** | §21; HV-1 | Ask; **and observe whether anyone actually paused, reduced or left without adverse consequence** | City, National (aggregate) | Aggregate; exit themes only (§21.4) | Per cohort; quarterly | **A right nobody exercised is unproven** — the observation half is the measurement |
| **HM-13** | **Dignity and respect** — reported by participants **and** beneficiaries, separately | **HV-2 veto gate**; §55.2 | Independent collection: **at least a day after help, by someone other than the person who delivered it** (**v1.3-A A-19** architecture applied to research) | **Restricted**; aggregate upward; **never to the team member concerned** | **Highest sensitivity in the set**: C3/C4 classification (**v1.3-A A-17**), case-scoped access (**A-20**) | Per cohort; quarterly | Courtesy bias is severe; **and a beneficiary who depends on future help will not report honestly** — hence independence and delay |
| **HM-14** | **Promises made vs promises kept** | §40 trust ladder; §55.2 trust | From the intake record: what was promised, what was done, when | Team, City | Aggregate | Monthly | Small promises kept easily inflates this — **measure the promise size alongside** |
| **HM-15** | **Where friction stopped them** — the last stage reached, per §13 | The diagnostic that tells you *what to fix* | From the journey record: stage reached, stage abandoned | Team, City | Aggregate; no reason recorded about a person (§41.2) | Monthly | **Abandonment is invisible unless the stage is recorded** — which requires the journey to be instrumented, not the person to be surveyed |

## 58.1 Rules for the fifteen

**[P]** Five, because measurement of human experience is itself a risk:

1. **Nothing is measured about a person that is not already recorded for an operational purpose**, except HM-2/3/6/11/12/13, which are **asked, aggregate-only, and consented**. **v1.3-A A-18**'s necessity test applies to research.
2. **No individual result is reported to anyone.** All six subjective measures are aggregate. **A person's answer about their own dignity must never reach the person whose conduct it describes** except through §42's process.
3. **HM-13 is the only measurement requiring restricted handling**, and it inherits **v1.3-A A-17/A-20** in full.
4. **Zero counts are warnings** for HM-12 and for any "problems reported" measure (§43.3, §57.4 HPF-5).
5. **The fifteen are the maximum.** Adding a sixteenth requires retiring one — **v1.3-B §26.3**'s control-budget rule applied to human measurement.

---

# 59. HUMAN DECISION REGISTER

**Columns exactly as your brief specifies.** Items already UNRESOLVED / NOT FINAL / PROPOSED in v1.2, v1.3-A or v1.3-B are **carried forward unchanged** and marked ⟨carried⟩; items newly identified are ⟨new⟩. **Nothing is closed here.** Triggers are events, not dates.

## 59.1 Carried forward, unchanged

| ID | Question | Current state | Evidence | Proposal | Owner | Validation | Pilot test |
|---|---|---|---|---|---|---|---|
| **HD-C1** ⟨carried⟩ | **Public name: Sewak Sathi Sanstha** | **PROPOSED [S: Ch.33]** | "Use as public operating name while preserving Krytos parent context"; legal/name validation required | Test comprehension in the pilot locality before adoption (§9.7) | CEO | **Yes — legal, name, language [V]** | HM-2 |
| **HD-C2** ⟨carried⟩ | **Legal structure under Krytos** | **UNRESOLVED [S: Ch.33; v1.3-A N12; v1.3-B E-C1]** | Determines whether volunteers, members and workers have any legal standing, and what duties attach | Resolve in Phase 0 **[S: Ch.30]** | CEO | **Yes — corporate, tax, regulatory** | — |
| **HD-C3** ⟨carried⟩ | **Worker classification** | **UNRESOLVED [S: Ch.33; v1.3-B E-C2]** | Determines whether L3–L5 participation is volunteering, employment or contracting — **and therefore whether §6 is lawful as designed** | Classify per level and per mode (§15) | CEO + HR | **Yes — employment, tax [V]** | — |
| **HD-C4** ⟨carried⟩ | **CEO vs National Council authority** | **UNRESOLVED [S: Ch.33; v1.3-A N19; v1.3-B E-C11]** | Determines who decides every appeal, every Tier-1 amendment and every HF-5/HF-16 intervention | v1.3-A A-13/A-14 reserved-matters approach | CEO + governance | **Yes** | — |
| **HD-C5** ⟨carried⟩ | **Leaderboard weights** | **PROPOSED 20/15/15/15/10/10/10/5; NOT FINAL [S: Ch.25; Ch.33]** | Used for teams only (§44.4); weights unchanged here | Pilot, adjust after testing **[S]** | CEO + Operations | Yes | HF-13 |
| **HD-C6** ⟨carried⟩ | **R5 — whether the leaderboard should be public at all** | **RECONSIDER [S-ST: §25.3 R5]** | §44.2 SA-4; HF-13 | Decide after cohort normalisation is tested | CEO + Council | Yes | HF-13 |
| **HD-C7** ⟨carried⟩ | **Minimum staffing thresholds** | **NOT FINAL — "no final numbers invented" [S: Ch.33; v1.3-B E-C8]** | §14.2 of v1.3-B derives `N_min` | Derive from pilot P-01/P-03 | CEO + HR | Yes | — |
| **HD-C8** ⟨carried⟩ | **Data retention / AI model policy** | **UNRESOLVED / PROPOSED [S: Ch.33; v1.3-A N26, N37]** | Determines how long paused, alumni and contributor records are kept | v1.3-A A-17 P2 | AI & Data + Legal | **Yes** | HM-13 handling |
| **HD-C9** ⟨carried⟩ | **Insurance** | **UNRESOLVED [S: Ch.33; v1.3-A A-10 L1–L15; v1.3-B E-C10]** | Determines whether volunteers and members are covered at all — **a human question as much as a financial one** | Obtain written answers before any activity | Legal + Finance | **Yes — broker, counsel** | — |
| **HD-C10** ⟨carried⟩ | **Partnerships** | **UNRESOLVED / PROPOSED [S: Ch.29; Ch.33; v1.3-A N25]** | §37.1 requires due diligence before any partnership is presented as endorsement | Per **[S: Ch.29]** flow | CEO + Legal | **Yes** | — |
| **HD-C11** ⟨carried⟩ | **N5 — whether composition data may exist at all** | **DELIBERATELY UNRESOLVED [v1.3-A A-05]** | HF-9: exclusivity cannot be detected without it, and it is prohibited | **Keep unresolved.** §59.2 HD-14 proposes a non-identity method instead | CEO + Council | **Yes if ever contemplated** | HF-9 |
| **HD-C12** ⟨carried⟩ | **QR ID card** | **CONCEPT APPROVED — minimal data, revocable token, non-police visual design [S: Ch.33]**; use restricted by **v1.3-A A-17 §16.4** | §53.2 identification row | Preserve; **never required at L0–L2** | CEO + Privacy | **Yes — privacy, legal** | — |
| **HD-C13** ⟨carried⟩ | **R1 — whether Protection/First Response is a publicly named pillar in the first years** | **RECONSIDER [S-ST: §25.3 R1]** | §9.2: the word "protection" must not appear in the ten-second version | Decide before any public statement (**v1.3-A A-07**) | CEO + Council | **Yes** | HM-2 |

## 59.2 Newly identified by v1.3-C

| ID | Question | Current state | Evidence | Proposal | Owner | Validation | Pilot test |
|---|---|---|---|---|---|---|---|
| **HD-01** ⟨new⟩ | **Adopt the nine-level participation spectrum?** | PROPOSED **[S-ST: §9; M1]** | §6; §35 coverage | Adopt with the three safety rules preserved | CEO + HR + Legal | **Yes — volunteer/worker boundary per level; privacy per level; safeguarding for L1–L3 [V]** | HM-4, HM-5, HM-9 |
| **HD-02** ⟨new⟩ | **Adopt the four-door model?** | PROPOSED **[S-ST: §6.3]** | §5 | Adopt; **Door 3 gated on v1.3-B §46.2's five conditions** | CEO | Yes | HM-11 |
| **HD-03** ⟨new⟩ | **The core proposition — adopt, revise or reject?** | **HYPOTHESIS [S-ST: §10.2; H]** | §3.4 nine failure modes; §3.6 three tests | **Do not adopt until T1/T2/T3 pass** | CEO + Communications | **Yes — T2 non-coercion review; PM-8 translation review** | HM-2, HM-13 |
| **HD-04** ⟨new⟩ | **Separation window between receiving help and being invited to participate** | **PROPOSED — value not set [M]** | §16.2 BS-1 | Set a window; **never approached by the person who delivered the help** | CEO + Safeguarding | **Yes [V]** | HM-13 |
| **HD-05** ⟨new⟩ | **Return window for HM-9 (second contribution)** | **PROPOSED — 30 days suggested by [S-ST: §21.3]** | §11.4: must be tested against local rhythms | Test 30 / 60 / seasonal variants | Operations | No | HM-9 |
| **HD-06** ⟨new⟩ | **Credential standard and external recognition** | **PROPOSED [S-ST: §7.3 item 6; M9]** | §25.3 five conditions; **a credential nobody recognises is a betrayal** | Publish standards; seek external recognition before issuing | CEO + HR | **Yes — sector recognition, legal characterisation [V]** | HM-10 |
| **HD-07** ⟨new⟩ | **Elder/Mentor standing — adopt?** | PROPOSED **[S-ST: §7.3 item 12; §9.1]** | §6.10; §45.3; §49 | Adopt, with command and scoring exclusions explicit | CEO + HR | **Yes — where mediation touches conduct or grievance [V]** | HM-3, HF-4 |
| **HD-08** ⟨new⟩ | **Paused and alumni statuses** | PROPOSED **[S-ST: F-04; M23]** | §15.3; §21 | Add to **[S: Ch.11]** status set by appendment | CEO + HR | **Yes — retention while paused [V]** | HM-9, HM-12 |
| **HD-09** ⟨new⟩ | **Membership fees — permanent prohibition?** | PROPOSED §39.3 | §22.3 MLM-3 | Prohibit permanently as a Tier-1 item | CEO + Council | **Yes — enforceability (v1.3-A A-13)** | HV-4 |
| **HD-10** ⟨new⟩ | **Public local page — build it?** | PROPOSED **[S-ST: §20.3: "not in the current architecture"]** | §10; §28.1; §29.2 | Build as a single page per team, in the local language, **before** the pilot | Communications + AI & Data | **Yes — privacy notice, accessibility [V]** | HM-1, HM-2 |
| **HD-11** ⟨new⟩ | **Language rollout order** | PROPOSED **[S-ST: §13.2; M17]** | §30.2 three layers | L1 fully, L2 by need, L3 local; **no language senior to another** | CEO + Communications | **Yes — L1 legal review per language [V]** | HM-2 |
| **HD-12** ⟨new⟩ | **Rituals and ceremonies — which pass the six tests?** | PROPOSED §32.3 | §32.2 six-test gate | Adopt only the ✅ candidates; **national service day deferred pending date review** | CEO + Council | **Yes — date and symbol political/religious review [V]** | HF-18 |
| **HD-13** ⟨new⟩ | **Symbol brief and local design** | PROPOSED §53.3 | §53.2 constraints; §9.7 test | Issue the brief; let the pilot locality design; select by test | CEO + Communications | **Yes — colour/symbol political association per state [V]** | HM-2, §9.7 |
| **HD-14** ⟨new⟩ | **How is social exclusivity detected without identity data?** | **UNRESOLVED — no clean solution** | §56 HF-9; **v1.3-A A-18 §17.4** prohibits collecting religion, caste or ethnicity absolutely | **Do not collect identity data.** Use non-identity proxies: participation composition by *locality and activity type*, newcomer return rates, and complaint patterns — all aggregate | CEO + Council + Privacy | **Yes — whether any proxy is lawful and non-discriminatory [V]** | HF-9, HM-9 |
| **HD-15** ⟨new⟩ | **How fast can a HF-16 (loyalty-demanding leader) intervention occur?** | **UNRESOLVED — depends on HD-C4** | §56 HF-16; **v1.3-A A-14** covers the apex only | Define an interim authority to suspend a role pending review, using **v1.3-B B-19**'s local pattern at City level | CEO + Council | **Yes** | HF-16 |
| **HD-16** ⟨new⟩ | **May a team refuse a request from outside its area?** | PROPOSED §56 HF-19 | **[S: Ch.8 step 5]** criteria contain no locality term | **Yes on capacity, never on identity**; City coordinates **[S: Ch.7]** | Operations | No | HF-19 |
| **HD-17** ⟨new⟩ | **Can media attention be pre-authorised for refusal?** | PROPOSED §56 HF-20 | §40 rung 8; **v1.3-A A-07**; **[S: Ch.24]** authorised spokespersons | **Yes — pre-authorise a spokesperson to decline a story that exceeds the delivered rung** | CEO + Communications | **Yes [V]** | HF-20 |
| **HD-18** ⟨new⟩ | **Is a public disagreement misconduct?** | PROPOSED §56 HF-6 | §43 sentence 1; **[S: SOP-17]** | **No — and this must be written into the conduct SOP by appendment**, or it will be treated as such | CEO + HR | **Yes — conduct process review [V]** | HF-6 |
| **HD-19** ⟨new⟩ | **Youth participation: ages, hours, consent, prohibited work** | **UNRESOLVED — no legal position taken** | §48 Y-1 to Y-10 | Obtain written legal advice **before** any minor participates | CEO + Safeguarding + Legal | **Yes — mandatory [V]** | §48 |
| **HD-20** ⟨new⟩ | **Remote participation: what may be done without physical presence?** | PROPOSED §50.2–§50.3 | §50; §14 segment 24 | Adopt the two lists; **belonging formation stays physical (H-06)** | Operations + AI & Data | **Yes — safeguarding, data, employment [V]** | HM-7 for remote contributors |
| **HD-21** ⟨new⟩ | **Mission-balance breach: variance or veto?** | PROPOSED §56 HF-11 | **v1.3-B B-01**; **[S: Ch.25]** mission 20% | **Variance first, veto if sustained across `n` periods [M]** | CEO + Operations | No | HF-11 |
| **HD-22** ⟨new⟩ | **Do the twenty-eight amendments impose anything on Levels 0–4?** | **ANSWERED — no new task** | §60.30 burden check | Adopt the check as a standing rule for future amendments | CEO | No | — |
| **HD-23** ⟨new⟩ | **Which of H-01…H-28 are Tier-1 candidates under v1.3-A A-13?** | PROPOSED | §16.2, §20.1, §22.3, §24.2, §39.3 | **BS-1…BS-6, AC-1…AC-11, MLM-1…MLM-7, CR-1…CR-4, and the free-to-join rule** | CEO + Council | **Yes — enforceability [V]** | — |

---

# 60. v1.3-C AMENDMENT PACK

**Merge instruction [P]:** 28 amendments, **H-01 … H-28**, each additive. **Nothing in v1.2, v1.3-A or v1.3-B is deleted, renumbered or reworded.** Where an amendment extends an existing instrument (the vacancy statuses, the conduct SOPs, the dashboards, the approval matrix, the launch checklist, the decision register), it is *appended* and the original preserved. Twelve fields per your brief, in order.

## H-01 · Four-Door Participation Model

| Field | Content |
|---|---|
| **1. Amendment ID** | H-01 |
| **2. Source reference** | **[S: Ch.2 mission; Ch.12 membership lifecycle; Ch.17 AI Business Network; Ch.9 role families]**; **[S-ST: §6.3, M1]** |
| **3. Problem** | The architecture has one door — the Verified Member application — with four rooms behind it. Eight of the citizen segments in §14 need neither earnings nor command, and have no way in |
| **4. Human mechanism** | Four distinct entry propositions (purpose, proof, livelihood, building), each with its own first activity, its own value and its own language — **all four leading into the same verification spine** |
| **5. Operational effect** | Intake splits by door rather than by application; Door 3 is gated on **v1.3-B §46.2**'s five conditions before it may be advertised |
| **6. Financial effect** | Raises the delivery-capacity pool (`N_paid`, `P_max`) without lowering the integrity standard — the human half of **v1.3-B §17.4** bottleneck 2 |
| **7. Governance effect** | Verification is unchanged and remains the single spine; the doors change *what is asked first*, never *what is required for responsibility* |
| **8. Technology effect** | A door attribute on the intake record; no new system |
| **9. New risk** |Door 3 creates an income expectation the waterfall may not meet (**[S-ST: F-02]**); doors become a marketing segmentation that produces different truths — **Mitigations:** §37.1 prohibitions; **§14.2 rule 1** — no segment may be targeted with a different truth; earnings-reality disclosure **[S-ST: M16]**|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Validation required** | **[V]** volunteer/worker boundary per door (HD-C3) |
| **12. Merge target** | New Chapter 12B; cross-reference from Ch.12 and Ch.31 checklist |

## H-02 · Nine-Level Participation Spectrum

| Field | Content |
|---|---|
| **1. Amendment ID** | H-02 |
| **2. Source reference** | **[S: Ch.10 Supporting Members "helpers, volunteers, trainees and project workers"; Ch.11 eligibility "membership status appropriate to task"; Ch.12 lifecycle; Ch.23 RBAC; Ch.9 "cannot assign untrained people to restricted tasks"]**, **[S-ST: §9, M1]** |
| **3. Problem** | Between "member of the public" and "Verified Member" there is nothing. A person who wants to give one hour has no legitimate status, so either they are processed as an applicant or they are invisible |
| **4. Human mechanism** | Nine levels (L0 observer → L8 builder) plus Elder/Mentor standing, each with purpose, permissions, responsibilities, access, verification, data access, financial access, authority, expected behaviour, exit path, advancement path and lateral path (§6) |
| **5. Operational effect** | Tasks are assigned by level; **every L1–L4 task is assigned through an L5+ person recorded as responsible** |
| **6. Financial effect** | Reduces per-participant processing cost — L1 requires no verification at all (**v1.3-B §15.2** `C_vol_total` falls sharply at low levels) |
| **7. Governance effect** | **Reduces the permission surface at the bottom while widening participation** — the security boundary of §7.1 is preserved verbatim |
| **8. Technology effect** | A level attribute driving RBAC; **no system write access below L5** |
| **9. New risk** |A shadow unverified workforce; a second status hierarchy with its own politics; level inflation; data creep; low tiers becoming a recruitment trap — **Mitigations [S-ST: §9.3]:** hard RBAC floor; **no public ranking below L5**; "Member" reserved for L5+; purpose limitation and re-consent on upgrade; **no automatic progression**; deletion on request at low levels|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Validation required** | **[V]** legal review of the volunteer/worker boundary at each level; privacy assessment of what is collected at each level; safeguarding review of L1–L3 where minors or vulnerable adults participate |
| **12. Merge target** | New Chapter 12C; Ch.23 RBAC extended by appendment, original matrix preserved; Ch.11 statuses appended (H-18) |

## H-03 · Public Local Page

| Field | Content |
|---|---|
| **1. Amendment ID** | H-03 |
| **2. Source reference** | **[S: Ch.24 public communication; Ch.8 request intake]**; **[S-ST: §20.3 — "Requires a public local page — not in the current architecture"]** |
| **3. Problem** | The request-intake loop exists internally and is invisible externally. A resident with a problem has no route, so Stage 1 of the journey does not exist |
| **4. Human mechanism** | One page per team, in the local language: the core sentence, the "what we are not" list, three nearby dated results, and two buttons — **report a need** / **help once** |
| **5. Operational effect** | Public intake feeds **[S: Ch.8 step 2]** directly; a reference number and expected response time are issued automatically |
| **6. Financial effect** | Negligible; one page, no app, no account |
| **7. Governance effect** | Creates a public record of unmet need, which is itself governance evidence |
| **8. Technology effect** | One static-or-simple page per locality; **must work on a basic phone and have a paper/voice equivalent (§29.3)** |
| **9. New risk** |The page becomes a complaint channel the team cannot answer, producing silence — the most damaging failure (§27.2) — **Mitigation:** the response window is published only if it can be met; **v1.3-B B-15(1)** latency discipline applies; §40 rung 1 is the only claim made|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Validation required** | **[V]** privacy notice (v1.3-A A-17 P3), accessibility |
| **12. Merge target** | New Chapter 24B; Ch.31 communications checklist row appended |

## H-04 · First-Ten-Seconds Standard

| Field | Content |
|---|---|
| **1. Amendment ID** | H-04 |
| **2. Source reference** | **[S: Ch.24; Ch.31 branding row]**, **v1.3-A A-07**, **[S-ST: §20.1–20.2]** |
| **3. Problem** | Nothing states what a person must understand in ten seconds, and the misclassification risks (political, religious, security, scheme) are live **[S-ST: §18.2]** |
| **4. Human mechanism** | Five things must be understood (local, practical, open, not political/religious, not a security force); one sentence; a "what we are not" line; one call to action; one trust signal that is a dated local fact |
| **5. Operational effect** | Every artefact — board, page, stall, script — is tested against §9.7 before use |
| **6. Financial effect** | Nil |
| **7. Governance effect** | Communications discipline becomes testable rather than a matter of taste |
| **8. Technology effect** | None |
| **9. New risk** |Over-simplification that omits something material — the "AI" and "protection" exclusions in particular could read as concealment — **Mitigation [S-ST: §20.2]:** this is *sequencing of truth-telling, not concealment* — the full description must be one tap away and must be complete|
| **10. Approval required** | `PROPOSED — draft language requiring approval`; **not adopted wording** |
| **11. Validation required** | **[V]** per-language terminology review (**v1.3-A A-06 V11** pattern); representations review (**v1.3-A A-07**) |
| **12. Merge target** | Chapter 24B; **v1.3-A A-07** cross-reference |

## H-05 · First-Five-Minutes Experience

| Field | Content |
|---|---|
| **1. Amendment ID** | H-05 |
| **2. Source reference** | **[S: Ch.8 intake and triage; Ch.15 steps 1–7; Ch.24]**, **[S-ST: §20.3]** |
| **3. Problem** | The first available action in the architecture is an application, which delivers no value and extracts data |
| **4. Human mechanism** | A five-minute sequence: encounter a result → read one page → act once (report a need or help once) → be answered by a named person → do something real and be told nothing further is expected. Plus the §13.2 friction-ceiling rule: *no step may ask for more than the person has already voluntarily given* |
| **5. Operational effect** | Intake requires ≤3 fields; no account; no documents; no verification |
| **6. Financial effect** | Nil; reduces `C_vol_total` per entrant (**v1.3-B §15.2**) |
| **7. Governance effect** | Verification is deferred to the moment responsibility is requested — **which strengthens rather than weakens it (§7.1)** |
| **8. Technology effect** | A minimal public form; a phone route must remain |
| **9. New risk** |Unverified people enter the system and expectations form about them — **Mitigation:** L1–L2 have **no system write access and no responsibility** (§7.1); every task is assigned through a recorded L5+ responsible person|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Validation required** | **[V]** data minimisation for the public intake |
| **12. Merge target** | Chapter 8A; SOP-05 appended (public front door) |

## H-06 · Paired First Task

| Field | Content |
|---|---|
| **1. Amendment ID** | H-06 |
| **2. Source reference** | **[S: Ch.15 step 7 "verified and trained members scheduled"; Ch.9 Volunteer Support Coordinator]**, **[S-ST: §21.3, §7.3 item 1]** |
| **3. Problem** | Belonging is produced by a person, not a programme — and the architecture has no mechanism that guarantees a newcomer meets anyone |
| **4. Human mechanism** | Within a stated window, a newcomer is matched to **one** small, safe, visible task performed **alongside two existing members**, ending with a before/after record they can see and keep, and an explicit statement that nothing further is expected |
| **5. Operational effect** | Two existing members are rostered per newcomer; this is real work for them and must be scheduled as such |
| **6. Financial effect** | Consumes delivery hours — **and it is the highest-return use of them** (§27.2 arrow 5) |
| **7. Governance effect** | Satisfies the two-adult rule where relevant; prevents isolation; gives the newcomer two relationships |
| **8. Technology effect** | A pairing field on the task record |
| **9. New risk** |The two members become recruiters, destroying the win — **Mitigation:** the statement "nothing further is expected" is mandatory and scripted; §37.3's test applies; **HM-9 measures second contribution, never conversion [S-ST: §21.3]**|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL`; window and duration `PROPOSED — REQUIRES PILOT VALIDATION` |
| **11. Validation required** | **[V]** safeguarding where minors or vulnerable adults are present (§48 Y-3) |
| **12. Merge target** | New Chapter 12D; SOP-05/SOP-06 appended |

## H-07 · No-Forced-Progression Rule and Six Endpoints

| Field | Content |
|---|---|
| **1. Amendment ID** | H-07 |
| **2. Source reference** | **[S: Ch.10 Supporting Members; Ch.25 "raw counts cannot determine leadership"; Ch.2 principle 1 non-discrimination]**, **v1.3-A A-05**, §8 |
| **3. Problem** | A level system will be read as a hierarchy of worth unless the alternative is stated as architecture |
| **4. Human mechanism** | Six legitimate endpoints (community contributor, volunteer, specialist, verified member without role, leader, builder) plus Elder/Mentor; seven status rules (SR-1…SR-7); seven rights of refusal; and four prohibitions on implying that leadership is morally superior to service |
| **5. Operational effect** | No process may treat non-progression as failure; a declined promotion is recorded as "not available for leadership" so the person is not asked repeatedly |
| **6. Financial effect** | Reduces pressure on the scarce leadership tournament (**[S-ST: F-24]**) |
| **7. Governance effect** | Prevents the level system from becoming a second status hierarchy with its own politics |
| **8. Technology effect** | Endpoint and refusal attributes; **no ordinal display below L5** |
| **9. New risk** |Ambition is suppressed; capable people are not invited to lead — **Mitigation:** invitation remains — **§12.1 week 4 offers all four options equally**; refusal is the right, not the default|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL`; **SR-1…SR-7 proposed as Tier-1 candidates (HD-23)** |
| **11. Validation required** | **[V]** equality and non-discrimination |
| **12. Merge target** | Constitution cross-reference (**v1.3-A A-05** Article 21 family); new Chapter 12E |

## H-08 · Recognition Taxonomy

| Field | Content |
|---|---|
| **1. Amendment ID** | H-08 |
| **2. Source reference** | **[S: Ch.25 performance system and anti-gaming controls; Ch.24 Member dashboard "achievements"]**, **[S-ST: §6.2 row 9, M18]** |
| **3. Problem** | Recognition exists as one instrument — ranking — where six are needed, and a single ranking conflates gratitude, evidence, capability, trust, pay and status |
| **4. Human mechanism** | Six separated instruments (appreciation, proof, credential, responsibility, compensation, promotion), each with its own giver, record and rules; **the existing performance system is retained unchanged and scoped to teams**; seven recognition design rules |
| **5. Operational effect** | Appreciation is person-to-person and unrecorded; proof and credential are record-derived; responsibility and promotion follow **[S: Ch.11]** |
| **6. Financial effect** | Nil; increases the supply of non-scarce recognition (§44.3) |
| **7. Governance effect** | Removes the mechanism by which a ranking could be read as a judgement of a person |
| **8. Technology effect** | Achievement and credential fields already implied by **[S: Ch.24]**; **no ordinal display below L5** |
| **9. New risk** |Six instruments become six bureaucracies — **Mitigation:** only 2, 3, 4, 6 are recorded; appreciation is deliberately unrecorded; **v1.3-B §26.3** control-budget rule applies|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL`; **weights remain PROPOSED [S: Ch.25; Ch.33] and are unchanged** |
| **11. Validation required** | Not required; **R5 (public leaderboard) remains open** |
| **12. Merge target** | New Chapter 25B; Ch.24 Member dashboard appended |

## H-09 · Verified Contribution Record

| Field | Content |
|---|---|
| **1. Amendment ID** | H-09 |
| **2. Source reference** | **[S: Ch.12 HR records; Ch.15 evidence; Ch.17 steps 4–11; Ch.19 step 13; Ch.10 delegations; App. F]**, **v1.3-A A-17/A-20**, **[S-ST: §19.2 claim 3]** |
| **3. Problem** | The organisation holds verified records of what people did and never shows them to the people who did it |
| **4. Human mechanism** | A person-facing view of the existing estate: service, skills, training, projects, responsibilities, leadership, verified achievements, customer work, community contribution — **with four absolute limits so it can never become a social credit score** |
| **5. Operational effect** | No new data collection: **a view, not an estate** |
| **6. Financial effect** | Enables Door 2 and §25 portability — the strongest retention instrument available (**[S-ST: §7.3 item 6]**) |
| **7. Governance effect** | Gives the person a correction right over their own record (**[S: Const. Art.17]**) |
| **8. Technology effect** | A read-only personal view with export |
| **9. New risk** |**It becomes a social credit score** — determining dignity, access to community life, worth, or eligibility for anything external — **Mitigations CR-1…CR-4:** may never determine basic dignity or treatment; may never gate access to the commons; may never be aggregated into a single number; may never be sold, shared or used for third-party inference (**v1.3-B §39 NM-4, NM-11**)|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL`; **CR-1…CR-4 proposed as Tier-1 candidates** |
| **11. Validation required** | **[V]** data-subject rights, retention, portability, erasure |
| **12. Merge target** | New Chapter 22D; **v1.3-A A-17** estate map extended by appendment |

## H-10 · Portable Credentials

| Field | Content |
|---|---|
| **1. Amendment ID** | H-10 |
| **2. Source reference** | **[S: Ch.12 training; Ch.17 step 6 verified skills; Ch.33 QR "minimal data, revocable token"]**, **[S-ST: §6.2 row 6, §7.3 item 6, M9]** |
| **3. Problem** | A person's verified capability is locked inside the organisation and must be re-established on every team change — and a record worthless outside is a captivity mechanism **[S-ST: §7.4]** |
| **4. Human mechanism** | Credentials issued against published standards, backed by evidence, externally checkable without exposing private data, honestly scoped, and legitimately issued — portable across Mohalla, City, State, National, projects, specialist roles, employers and exit |
| **5. Operational effect** | Verification reads the record rather than restarting it |
| **6. Financial effect** | Opens Door 2 for the largest reachable population (**[S-ST: §6.3]**) |
| **7. Governance effect** | Makes horizontal progression legible (§47) |
| **8. Technology effect** | Revocable verification token, same design logic as the QR concept **[S: Ch.33]** |
| **9. New risk** |A credential nobody outside recognises is a betrayal dressed as a gift; and an overstated credential exposes the holder — **Mitigations:** §25.3 five conditions; **absolute limit — no internal credential may imply legal sufficiency in a regulated domain [S: Ch.12 boundary]**|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Validation required** | **[V]** sector recognition, legal characterisation of certification, privacy of external checks |
| **12. Merge target** | New Chapter 12F; Ch.12 appended |

## H-11 · Specialist and Elder/Mentor Paths

| Field | Content |
|---|---|
| **1. Amendment ID** | H-11 |
| **2. Source reference** | **[S: Ch.6 State specialist pool; Ch.9 per-role succession columns; Ch.10 delegation; Ch.12 professional-validation boundary]**, **[S-ST: §9.1 Elder/Mentor, §7.3 item 12, F-24, M9]** |
| **3. Problem** | The only visible progression is the management ladder, whose prize is scarce; most capable people hit a ceiling and the organisation loses them or keeps them discontented |
| **4. Human mechanism** | A six-stage horizontal ladder (demonstrated → trusted scope → verifier → advisor → mentor/elder → standard-setter) across twelve domains, each bounded by the source's own professional-validation rule; plus Elder/Mentor standing with **command and scoring explicitly excluded** |
| **5. Operational effect** | Scope grows without headcount authority growing |
| **6. Financial effect** | Raises `P_max` without raising `H_gov` (**v1.3-B §17.4, §24.5**) |
| **7. Governance effect** | Specialists **advise, never command**; a cap on specialist-held coordinator positions prevents professional capture **[S-ST: §9.3]** |
| **8. Technology effect** | A scope-and-standard attribute on the delegation record |
| **9. New risk** |The horizontal path is experienced as a consolation prize — **Mitigation §47.4:** real scope, outward recognition (H-10), inward recognition without ranking (H-08), and pay where venture work is performed|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Validation required** | **[V]** per regulated domain |
| **12. Merge target** | New Chapter 9A; Ch.6 specialist pool cross-referenced |

## H-12 · Friendship Infrastructure

| Field | Content |
|---|---|
| **1. Amendment ID** | H-12 |
| **2. Source reference** | **[S: Ch.9 Volunteer Manager family incl. Member Engagement and Volunteer Support Coordinators; Ch.10 team structure]**, **[S-ST: §7.3 items 1, 7]** |
| **3. Problem** | **Belonging has no basis anywhere in 179 pages** (§2.2 N-02) — and it is the retention variable that matters most |
| **4. Human mechanism** | Stable teams (not reshuffled); every newcomer paired with two members; team rituals under the six-test gate; family-inclusive events; **belonging engineered at team level and never at leader level** |
| **5. Operational effect** | Team composition is a managed variable with a stability rule |
| **6. Financial effect** | Nil. **Nine of twelve belonging mechanisms cost nothing (§19.1)** |
| **7. Governance effect** | Reduces single-leader dependency (**v1.3-B HC-02, §24**) |
| **8. Technology effect** | A team-stability attribute; **no relationship data collected beyond assignment** |
| **9. New risk** |Stable teams become cliques (§56 HF-9); belonging becomes captivity (§19.4) — **Mitigations:** H-06 pairs *across* the existing group; §26.3's leave-cheaply test; §21 exit rights; HD-14's non-identity exclusivity proxies|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Validation required** | **[V]** where gatherings involve minors, food or public space |
| **12. Merge target** | New Chapter 12G; Ch.9 Volunteer Manager family appended |

## H-13 · Rituals Under Six Tests

| Field | Content |
|---|---|
| **1. Amendment ID** | H-13 |
| **2. Source reference** | **[S: Ch.15 categories; Ch.24 communications; Ch.2 principle 1]**, **v1.3-A A-01, A-05, A-06, A-16**, **[S-ST: §15, M18]** |
| **3. Problem** | Shared culture produces belonging, and unexamined culture produces exclusion, political adjacency, religious coercion or personality cult |
| **4. Human mechanism** | Any ritual, ceremony, event, symbol, story format or tradition must pass all six tests: voluntary, inclusive, non-political, non-religiously coercive, no personality cult, reasonable cost. **Culture is earned locally and registered nationally, never designed nationally and imposed locally** |
| **5. Operational effect** | A local team may create its own traditions inside the six tests |
| **6. Financial effect** | **Test 6 eliminates any ritual a Stage-0 team at ₹0 could not hold** (v1.3-B §9.3) |
| **7. Governance effect** | Prevents §56 HF-18 (political identity) and HF-10 (personality centre) at the cultural layer |
| **8. Technology effect** | A ritual register with the six tests recorded |
| **9. New risk** |The tests eliminate everything and the culture stays thin — **Mitigation:** §32.3 lists candidates that pass; **thin, local and voluntary is the intended result**|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL`; individual rituals approved locally within the tests |
| **11. Validation required** | **[V]** for any date, symbol or gathering with political, religious or public-order dimensions |
| **12. Merge target** | New Chapter 24C; **v1.3-A A-05** cross-reference |

## H-14 · Story Framework

| Field | Content |
|---|---|
| **1. Amendment ID** | H-14 |
| **2. Source reference** | **[S: Ch.24 verified facts only, distinguish completed work from plans, protect privacy, correction logs; Ch.15 include failures; App. F]**, **v1.3-A A-19**, **[S-ST: §18.3]** |
| **3. Problem** | The default institutional story is "look what we did", which transfers agency from the contributor and the recipient to the organisation and produces saviourism (§3.4 PM-1) |
| **4. Human mechanism** | Six story priorities (place and problem → contributors if consenting → team → learning → quiet service → beneficiary only under A-19 consent); nine prohibited story forms; four discipline rules including **the story channel has no read access to the service channel** |
| **5. Operational effect** | Stories are assembled from place-and-outcome records, not from case files |
| **6. Financial effect** | Supports **v1.3-B B-12** trust-to-demand path at the referral step |
| **7. Governance effect** | Enforces **v1.3-A A-19** access separation in the communications function |
| **8. Technology effect** | A story record referencing outcome records, never case records |
| **9. New risk** |Stories become scarce because consent is hard to get — **Mitigation:** §17.4's subject rule — **a claim about a place requires only evidence, a claim about a person requires consent** — so most stories need no consent at all|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Validation required** | **[V]** where publication creates representations |
| **12. Merge target** | Chapter 24C; SOP-14 appended; **v1.3-A A-19** cross-reference |

---

## H-15 · Attribution and Follow-Up Loop

| Field | Content |
|---|---|
| **1. Amendment ID** | H-15 |
| **2. Source reference** | **[S: Ch.15 steps 9–12 evidence, outcome verification, report, impact measurement; Ch.9 Follow-up Coordinator; Ch.15 "survival/follow-up tracking"]**, **[S-ST: §7.3 item 9]** |
| **3. Problem** | **The architecture verifies outcomes and never returns them to the person who produced them** — the most damaging silent break in the return loop (§27.2) |
| **4. Human mechanism** | Two obligations with stated windows: the **reporter** is told what happened to their reported need, and the **contributor** is told what their work achieved. Seven ethical attribution methods; the subject rule (person helped = subject of the outcome sentence; contributor = subject of the action sentence; organisation = subject of neither) |
| **5. Operational effect** | One follow-up per project at one stated interval; sampling for repeated categories; City-shareable |
| **6. Financial effect** | Adds `g_plan`-class hours (**v1.3-B §25.1 GC-09**) — bounded by the four rules in §18.3 |
| **7. Governance effect** | Outcome data becomes the mission-balance evidence **v1.3-B B-01** and **[S-ST: M14]** require |
| **8. Technology effect** | An outcome-notification field derived from records that already exist |
| **9. New risk** |Follow-up becomes a monitoring programme and a burden; or attribution exposes a beneficiary — **Mitigations:** §18.3 four bounding rules; §17.4 subject rule; **v1.3-A A-19** consent architecture|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL`; windows `PROPOSED — REQUIRES PILOT VALIDATION` |
| **11. Validation required** | **[V]** privacy of outcome notification; safeguarding cases excluded from ordinary follow-up |
| **12. Merge target** | New Chapter 15D; SOP-06 appended |

## H-16 · Community Experience Charter

| Field | Content |
|---|---|
| **1. Amendment ID** | H-16 |
| **2. Source reference** | **[S: Ch.8 Mohalla operating loop; Ch.7 City responsibilities; Ch.15 categories; Ch.24]**, **[S-ST: §8, §22]** |
| **3. Problem** | Eight of the nine things a locality could use a team for are already latent in v1.2 and none is publicly offered |
| **4. Human mechanism** | Nine functions published per locality (ask for help, offer help, find opportunities, find skilled people, join projects, learn, contribute, discover activities, build relationships) — plus four rules preventing the community experience from becoming a recruitment funnel |
| **5. Operational effect** | A local calendar and an open-task list become public artefacts |
| **6. Financial effect** | Nil; uses records already produced |
| **7. Governance effect** | Makes the team legible as a **place** rather than a process (§28.3) |
| **8. Technology effect** | The public local page (H-03) carries it; paper equivalent required |
| **9. New risk** |A published skills directory becomes a brokerage of personal data — **Mitigation:** consent per entry; **v1.3-B §39 NM-4/NM-11** prohibit data-derived commercial inference; no contact details published|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Validation required** | **[V]** privacy of any directory |
| **12. Merge target** | New Chapter 8B; Ch.7 cross-reference |

## H-17 · Rights of Refusal and Exit with Dignity

| Field | Content |
|---|---|
| **1. Amendment ID** | H-17 |
| **2. Source reference** | **[S: Ch.11 vacancy statuses; Const. Art.17 grievance and appeal; Ch.14 step 5; SOP-17, SOP-18]**, **v1.3-A A-16**, **[S-ST: §7.4]** |
| **3. Problem** | There is no stated right to decline, reduce, pause, refuse promotion or leave — so refusal is experienced as a negotiation, and exit as a defection |
| **4. Human mechanism** | Ten exit rights; seven rights of refusal; an asset-disposition table for pause, leave and removal; four anti-retaliation rules; an offered-never-compelled exit conversation with four questions; three rules on how the organisation speaks about people who left |
| **5. Operational effect** | Refusal is cheap, silent and not recorded as negative |
| **6. Financial effect** | **Accrued compensation is paid on leaving at priority 1** (**v1.3-B B-05**) — exit is not a forfeiture event |
| **7. Governance effect** | Removes every captive asset, which is the structural anti-coercion instrument (§20.3) |
| **8. Technology effect** | Status changes; delegation expiry already exists **[S: Ch.22]** |
| **9. New risk** |Permissive exit destabilises teams mid-project — **Mitigation:** §21.2 requires a handover window for anything held; **customers are treated fairly [S: App. A §13.5]**|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Validation required** | **[V]** employment notice, final settlement, record retention |
| **12. Merge target** | New Chapter 11A; SOP-17 appended; Ch.11 statuses appended (H-18) |

## H-18 · Paused and Alumni Status

| Field | Content |
|---|---|
| **1. Amendment ID** | H-18 |
| **2. Source reference** | **[S: Ch.11 six vacancy statuses incl. `Temporarily inactive`]**, **[S-ST: F-04, §7.3 item 4, M23]** |
| **3. Problem** | The architecture tracks the status of *posts*, not of *people*. A life event produces a resignation because no other category exists |
| **4. Human mechanism** | Two person-level statuses: **Paused** (life intervened; expected and normal; return with one message, no re-verification) and **Alumni** (left; record and credential preserved and portable; welcome to return at the level held, subject to certification currency) |
| **5. Operational effect** | Absence stops being a vacancy event |
| **6. Financial effect** | Reduces `C_replace` (**v1.3-B HC-01**) — the cheapest retention instrument available |
| **7. Governance effect** | Retention data becomes honest: a pause is not an exit |
| **8. Technology effect** | Two statuses appended to **[S: Ch.11]**; delegation expiry already handles access **[S: Ch.22]** |
| **9. New risk** |Paused status becomes permanent and the roll fills with inactives — **Mitigation:** **[S: Ch.25]** already requires "healthy active retention, not inactive names"; `r_act` is the reported measure, never roll size|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Validation required** | **[V]** retention periods while paused (HD-C8; **v1.3-A A-17 P2**) |
| **12. Merge target** | Ch.11 status set appended; new Chapter 12H |

## H-19 · Anti-Cult Safeguard Instrument

| Field | Content |
|---|---|
| **1. Amendment ID** | H-19 |
| **2. Source reference** | **[S: Ch.2 principles; Const. Art.17; Ch.14 step 5; Ch.24]**, **v1.3-A A-15 M1, A-16 four tests, A-01 N8**, **[S-ST: §16.1–16.2, §11.1, M10]** |
| **3. Problem** | Prohibitions against personality cult, forced loyalty, isolation and fear-based retention exist as analysis but not as one enforceable instrument with detectors |
| **4. Human mechanism** | Eleven prohibitions (AC-1…AC-11) each with a detector and an existing basis; seven institutional checks (CK-1…CK-7); and the operational test — *could a person who disagrees participate fully, safely and with standing intact?* |
| **5. Operational effect** | Attribution, dissent, exit and concern-route usage become observed quantities |
| **6. Financial effect** | Nil |
| **7. Governance effect** | **Proposed as Tier-1 candidates under v1.3-A A-13**, because a prohibition relaxable by the person it constrains is not a prohibition |
| **8. Technology effect** | Uses **v1.3-A A-15 M1** reasons and **A-16** tests; no new system |
| **9. New risk** |The instrument is used to label ordinary enthusiasm as cult behaviour, or to discipline a popular leader — **Mitigation:** detectors are structural (attribution patterns, dissent counts, exit themes), **never attitudinal**; findings require independent review (CK-1); **v1.3-A A-16** requires written reasons and appeal|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL`; Tier-1 status requires the **v1.3-A A-13** process |
| **11. Validation required** | **[V]** enforceability; employment consequences |
| **12. Merge target** | Constitution Tier-1 candidate list (**v1.3-A A-13 T1.x**); new Chapter 2A extension |

## H-20 · Psychological Safety Instruments

| Field | Content |
|---|---|
| **1. Amendment ID** | H-20 |
| **2. Source reference** | **[S: Ch.14 step 5 "avoid fear of reporting problems"; Const. Art.17; Ch.24]**, **v1.3-A A-15 M1, A-16 §15.2**, **[S-ST: F-13, F-21, M10, M23, App. A §18.4 anti-retaliation]** |
| **3. Problem** | Without safety, mistakes are hidden, dissent is silent, and the architecture's evidence culture produces confident fiction |
| **4. Human mechanism** | Seven sentences that must be sayable at any level without adverse consequence; five production mechanisms (recorded reasons, independent route, visible fair outcomes, leaders disclosing their own mistakes, no measurement of safety itself); the zero-count warning; five humane recovery mechanisms; and the rule that **absence is information, not disloyalty** |
| **5. Operational effect** | Disagreement is separated from misconduct absolutely (HD-18) |
| **6. Financial effect** | Nil |
| **7. Governance effect** | Requires CK-1's independent route — which depends on the **UNRESOLVED** CEO/Council question (HD-C4) |
| **8. Technology effect** | A concern route that does not pass through the person concerned; a standard-change request register |
| **9. New risk** |Safety is declared rather than produced, and the pilot reports "no problems" (HPF-5) — **Mitigation:** §57.4 HPF-5 makes a zero-dissent pilot **unsuccessful**, not successful|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Validation required** | **[V]** where a concern engages conduct or employment process |
| **12. Merge target** | New Chapter 27B; **v1.3-A A-15** cross-reference; SOP-17 appended |

## H-21 · Anti-MLM Compensation Firewall

| Field | Content |
|---|---|
| **1. Amendment ID** | H-21 |
| **2. Source reference** | **[S: Ch.18 priority 1 and definitions; Ch.19 step 1 eligibility; Ch.25 anti-gaming controls; App. A §14.3, §15.3]**, **v1.3-B §12, §22**, **[S-ST: F-02]** |
| **3. Problem** | The architecture combines teams, progression, business, compensation, recruitment and leadership — the six ingredients of MLM dynamics. Nothing currently prohibits a growth-based incentive |
| **4. Human mechanism** | Seven firewall rules (MLM-1…MLM-7): no compensation from any count of people; no compensation derived from another's contribution except a capped, work-justified leader differential; no fees or mandatory purchases; no recruitment commission; no referral chain; **every rupee distributed must trace to a collected customer receipt or a published funding source** |
| **5. Operational effect** | Growth incentives are structurally unavailable |
| **6. Financial effect** | **None — it confirms what the waterfall already does.** §22.2 shows a recruitment-based income is architecturally impossible as written; H-21 makes it permanently so |
| **7. Governance effect** | Four detection tests, of which **T1 (correlation between a person's income and the people they brought in) is computable from existing records and should be zero** |
| **8. Technology effect** | One annual correlation report from **[S: Ch.19]** payment sheets and **[S: Ch.12]** recruitment attribution |
| **9. New risk** |Legitimate team-building is chilled; a leader is afraid to invite anyone — **Mitigation:** invitations remain encouraged — **only value attaching to the invitation is prohibited** (MLM-4, MLM-6); attribution of an introduction may be recorded *for thanks*|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL`; **MLM-1…MLM-7 proposed as Tier-1 candidates** |
| **11. Validation required** | **[V]** employment, tax, and any direct-selling or pyramid-scheme regulation applicable to the entity form |
| **12. Merge target** | Constitution Tier-1 candidate list; new Chapter 18B; **v1.3-B §39 NM list** cross-reference |

## H-22 · Beneficiary/Recruitment Separation

| Field | Content |
|---|---|
| **1. Amendment ID** | H-22 |
| **2. Source reference** | **[S: Ch.8 privacy check and minimum-data checklist; Ch.15 dignity and no exposure of minors; App. F]**, **v1.3-A A-18 minimisation, A-19 consent architecture, A-20 subject rights**, **[S-ST: §9.3, §22.2]** |
| **3. Problem** | The service→trust→participation loop operates precisely at the moment a person is vulnerable, and its efficiency and its ethics pull in opposite directions |
| **4. Human mechanism** | Six absolute rules (BS-1…BS-6): a separation window with a role bar; assistance never conditional on anything; no reward for converting a beneficiary; no testimonial or image sought at the point of service; refusal of future contact honoured absolutely; no unnecessary personal information sought |
| **5. Operational effect** | Assistance and recruitment are separated **by role and by time** |
| **6. Financial effect** | Removes the cheapest apparent growth channel — deliberately |
| **7. Governance effect** | **Proposed as Tier-1 candidates**; breaches are serious misconduct (**[S: SOP-18]**) regardless of outcome |
| **8. Technology effect** | A separation-window flag on the intake record; a refusal flag honoured across all channels |
| **9. New risk** |Genuine organic participation by someone helped is obstructed — **Mitigation §16.4:** the permitted path exists — the ordinary public door, on their own initiative, after the window, approached by nobody, **paired with members who were not the people who helped them**|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL`; window length **[M]** |
| **11. Validation required** | **[V]** consent validity, vulnerability, safeguarding |
| **12. Merge target** | Constitution Tier-1 candidate list; **v1.3-A A-19** Chapter 15A appended; SOP-05 appended |

## H-23 · Flexible Participation Modes

| Field | Content |
|---|---|
| **1. Amendment ID** | H-23 |
| **2. Source reference** | **[S: Ch.11 statuses; Ch.10 delegation; Ch.9 Volunteer Manager family]**, **v1.3-B §15.3, HC-15**, **[S-ST: §7.3 item 3]** |
| **3. Problem** | The architecture assumes one cadence and one commitment shape. Life does not |
| **4. Human mechanism** | Eleven modes (one-time, occasional, weekly, project, skill, remote, local, emergency, seasonal, professional, full-time-equivalent) with five switching rules; **an explicit time contract stating the hour range and the right to pause** |
| **5. Operational effect** | Rostering becomes mode-aware; seasonal and exam calendars are respected |
| **6. Financial effect** | Aligns participation with **v1.3-B HC-15** seasonality and reduces `C_replace` |
| **7. Governance effect** | Mode determines obligation, data collection and standing — never worth (§7.3) |
| **8. Technology effect** | A mode attribute; no new system |
| **9. New risk** |Mode proliferation makes scheduling unmanageable — **Mitigation:** modes are attributes of an *engagement*, not categories of person; a team may limit which modes a given task supports|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Validation required** | **[V]** where a mode approaches employment (M-10, M-11) |
| **12. Merge target** | New Chapter 12I; Ch.9 Volunteer Manager family appended |

## H-24 · Remote Participation Architecture

| Field | Content |
|---|---|
| **1. Amendment ID** | H-24 |
| **2. Source reference** | **[S: Ch.6 State specialist pool; Ch.9 Editor, AI & Business, Planner families; Ch.17 categories 1–3; Ch.22 platform]**, §50 |
| **3. Problem** | Every process assumes physical presence, excluding professionals, people with disabilities, and the diaspora — three segments whose skills the venture pillar needs |
| **4. Human mechanism** | Two lists: what may be fully or partly remote, and what requires presence absolutely; plus four provisions so remote contributors receive belonging rather than only tasks — **a named local person who tells them what their work became**, appearance in the outcome, a funded annual visit, and their own time contract |
| **5. Operational effect** | L4 specialist engagements become location-independent |
| **6. Financial effect** | Accesses skill the locality does not contain — **v1.3-B §17.4** bottleneck 2 relief |
| **7. Governance effect** | Verification of presence-dependent tasks remains local and absolute (§50.3) |
| **8. Technology effect** | Access controls, AI logs and delegation expiry apply unchanged **[S: Ch.22; v1.3-A A-21/A-22]** |
| **9. New risk** |Remote contributors are the most productive and the most likely to leave silently — **Mitigation:** the four provisions above; **HM-7 measured specifically for remote contributors**|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Validation required** | **[V]** cross-border data, employment characterisation, safeguarding for remote minors' activity (§48 Y-7) |
| **12. Merge target** | New Chapter 6A; Ch.6 specialist pool appended |

## H-25 · Language Architecture

| Field | Content |
|---|---|
| **1. Amendment ID** | H-25 |
| **2. Source reference** | **[S: Ch.24 communications]**, **v1.3-A A-05 language equality, A-06 V11 terminology review, A-17 P3 notice in English or any Eighth Schedule language**, **[S-ST: §13, M17]** |
| **3. Problem** | Language is a hard exclusion, not a friction: a person who cannot read the invitation cannot accept it. And terminology drift makes §6's security boundary unenforceable |
| **4. Human mechanism** | Three layers — **L1 constitutional and legal** (one authoritative text per language, legally reviewed, no publication without review); **L2 operational** (local language first, terminology register per language); **L3 cultural and expressive** (fully local). Plus three rules: no language is senior; a locality's public voice is in its own language; terminology is registered, not improvised. And the seva method: **fix the meaning, let each language supply its own word, never use it prescriptively, never invoke it religiously** |
| **5. Operational effect** | Every public artefact has a language owner |
| **6. Financial effect** | **v1.3-B HC-19** translation cost; economised by translating L1 once, L2 by need, L3 never |
| **7. Governance effect** | Extends **v1.3-A A-06 V11** and **H10** from protection terminology to all terminology |
| **8. Technology effect** | A terminology register; language attribute on every public artefact |
| **9. New risk** |Translation debt — material exists in one language and is silently unavailable in others — **Mitigation:** the register records coverage; **v1.3-A H10** already requires the rule for legally significant documents|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL`; rollout order **HD-11** |
| **11. Validation required** | **[V]** every L1 text per language |
| **12. Merge target** | New Chapter 24D; **v1.3-A A-05/A-17 P3** cross-reference |

## H-26 · Layered Identity

| Field | Content |
|---|---|
| **1. Amendment ID** | H-26 |
| **2. Source reference** | **[S: Ch.4–8 hierarchy; Ch.6 State functions; Ch.7 City functions]**, **v1.3-A A-01, A-05, A-06**, **[S-ST: §11, §12, §29]** |
| **3. Problem** | "Local community" and "something larger" must both be felt, without uniformity, regional superiority, cultural erasure, nationalism as coercion or political symbolism |
| **4. Human mechanism** | Five rules (local primary and national derived; nothing local replaced by a national standard; the national layer supplies **capability, not identity**; no layer claims superiority; national symbolism is service symbolism or nothing) plus the six-layer sentence test (person → family → locality → city → state → India) and the two-way flow (local achievement published nationally; national capability deployed locally) |
| **5. Operational effect** | Identity is produced by **observable events** — a specialist arriving, a local result published — not by claims |
| **6. Financial effect** | Nil |
| **7. Governance effect** | Prevents §56 HF-18 and HF-19 |
| **8. Technology effect** | Locality attribution on published outcomes |
| **9. New risk** |"National capability deployed locally" becomes central control wearing a helpful costume — **Mitigation:** **[S: App. A §16.2]** central-standards doctrine; **v1.3-B §20.3** response times and refusal-with-alternative|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL` |
| **11. Validation required** | **[V]** for any symbol, date or colour with political association per state |
| **12. Merge target** | New Chapter 4C; **v1.3-A A-05** Chapter 2A appended |

## H-27 · Youth and Elder Participation Rules

| Field | Content |
|---|---|
| **1. Amendment ID** | H-27 |
| **2. Source reference** | **[S: Ch.12 professional-validation boundary; Ch.15 no exposure of minors, safeguarding; Ch.9 Conduct & Welfare Coordinator]**, **v1.3-A A-19 (guardian consent plus the minor's own assent), A-11 category 11, B6**, **[S-ST: §8]** |
| **3. Problem** | Two segments — the youngest and the oldest — are excluded by default: minors because safeguarding is unresolved, elders because every process assumes physical, digital presence |
| **4. Human mechanism** | **Youth:** ten governing rules (Y-1…Y-10) — no legal age invented; guardian consent for every activity; the two-adult rule; education first; five prohibited responsibility categories; no image or story of a minor ever; online safety; immediate escalation of safeguarding concerns; no school-based recruitment that feels required; certified safeguarding training as a precondition. **Elder:** seven participation areas, five accessibility provisions, and standing without command |
| **5. Operational effect** | Age-appropriate role bands; paper and voice routes always available |
| **6. Financial effect** | Certification cost is externally set and cannot be reduced (**v1.3-B §4.2 OC-10**) |
| **7. Governance effect** | Minors are held **more** strictly than the §7.1 boundary, never less |
| **8. Technology effect** | Guardian-consent field; age-band task filter |
| **9. New risk** |Youth participation inflates headcount cheaply — **Mitigation §48.2:** a fourth purpose — numbers — is explicitly rejected; **[S: Ch.25]** forbids counts determining anything|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL`; **HD-19 must be answered before any minor participates** |
| **11. Validation required** | **[V] mandatory** — age, hours, prohibited work, consent, safeguarding, online safety |
| **12. Merge target** | New Chapter 12J; SOP-01/SOP-04 appended; **v1.3-A A-19** cross-reference |

## H-28 · Human-System Measurement and Pilot

| Field | Content |
|---|---|
| **1. Amendment ID** | H-28 |
| **2. Source reference** | **[S: Ch.24 dashboards and cadences; Ch.25 metrics and anti-gaming; Ch.27 audit; Ch.30 Phase 2 exit gate; App. F]**, **v1.3-B §40–§42, §26.3 control-budget rule**, **[S-ST: §21.3, §22.4]** |
| **3. Problem** | Nothing measures the human system, so its failure is invisible until people have already left |
| **4. Human mechanism** | Six metric categories with no composite score; four human veto gates (coercion, dignity, cult, extraction); fifteen measurements (HM-1…HM-15) each with what/why/how/who-sees/privacy/frequency/**interpretation risk**; a human pilot sharing the v1.3-B team and burden; twelve pilot questions; six failure conditions including **HPF-5 (a pilot in which nobody ever disagreed, erred, refused or asked for help is unsuccessful)** |
| **5. Operational effect** | The journey is instrumented, not the person surveyed (§58 HM-15) |
| **6. Financial effect** | Bounded by the control-budget rule: the fifteen are the maximum, and a sixteenth requires retiring one |
| **7. Governance effect** | Six subjective measures are **aggregate-only**; HM-13 inherits **v1.3-A A-17/A-20** handling |
| **8. Technology effect** | Derived from records that already exist; no new collection except six consented aggregate questions |
| **9. New risk** |Measurement becomes performance management of individuals — **Mitigation §55.4:** no metric may be an individual target; no ranking below L5; zero counts are warnings|
| **10. Approval required** | `PROPOSED — REQUIRES FINAL APPROVAL`; **all thresholds `PROPOSED — REQUIRES PILOT VALIDATION`** |
| **11. Validation required** | **[V]** research consent, privacy of subjective data, safeguarding in beneficiary interviews |
| **12. Merge target** | New Chapter 25C; Ch.24 dashboards appended; **v1.3-B §40** pilot specification appended |

## 60.29 Adoption sequencing

**[A]** Twenty-eight amendments will not be adopted at once — the fatigue problem **v1.3-A §24.10** and **v1.3-B §44.28** both addressed. **[P]** Three stages, keyed to the same triggers:

| Stage | Amendments | Trigger |
|---|---|---|
| **Stage 1 — before the first public contact** | **H-04** ten seconds, **H-05** five minutes, **H-03** public page, **H-02** levels (with §7.1 boundary), **H-01** doors 1 and 2 only, **H-22** beneficiary separation, **H-17** refusal and exit rights, **H-21** anti-MLM firewall, **H-19** anti-cult prohibitions, **H-27** youth rules (**HD-19 answered first**) | Immediately — these are the conditions of contacting a single member of the public |
| **Stage 2 — with the first team and the first cohort** | **H-06** paired first task, **H-15** attribution and follow-up, **H-08** recognition taxonomy, **H-09** contribution record, **H-12** friendship infrastructure, **H-13** rituals, **H-14** stories, **H-18** paused/alumni, **H-20** psychological safety, **H-23** modes, **H-28** measurement and pilot | On forming the pilot team (with **v1.3-B §44.28** Stage 1) |
| **Stage 3 — before the second team, city or scale** | **H-01** door 3 (**only when v1.3-B §46.2's five conditions are met**), **H-07** endpoints and status rules, **H-10** portable credentials, **H-11** specialist and Elder paths, **H-16** community charter, **H-24** remote, **H-25** language, **H-26** layered identity | On the decision to form a second team or open a second city |

**[A] Note the deliberate placement of Door 3 in Stage 3.** The livelihood door is the most attractive and the most dangerous, and **v1.3-B §46.2** shows it may only be opened where the waterfall can actually reach the person walking through it. Opening it in Stage 1 would produce **[S-ST: F-02]** in the first month.

## 60.30 Burden check — the rule from v1.3-A §25.3 applied again

**[C]** Every prior instrument tested whether it imposed anything on ordinary participants. This one must pass the same test, and it is the most important test in the document — because an adoption architecture that burdens the people it is trying to attract is self-defeating.

| Layer | Amendments imposing a **new task** | Amendments imposing only a **restraint or a right** | Amendments imposing **nothing** |
|---|---|---|---|
| **Level 0 Observer** | **0** | 0 | **28** |
| **Level 1 Community Participant** | **0** | 1 (follow the safety instruction given on site) | 27 |
| **Level 2 Contributor** | **0** | 2 (complete the act accepted; honesty about what was done) | 26 |
| **Level 3 Volunteer** | **1** (attend as agreed or give notice — which is the definition of the commitment they chose) | 4 | 23 |
| **Level 4 Specialist** | 2 (scope delivery; conflict declaration) | 3 | 23 |
| **Level 5 Verified Member** | 3 | 5 | 20 |
| **Coordinator / Sub-Role (L6)** | 7 | 4 | 17 |
| **Leader (L7)** | 12 | 4 | 12 |
| **Builder (L8)** | 15 | 3 | 10 |
| **City / State / National** | 22 | 3 | 3 |

> **[A] Result: Levels 0–2 carry zero new tasks. Level 3 carries one — the commitment they themselves chose. Every instrument in this pack that creates work creates it at L5 and above, and the heaviest concentration is at City level** (H-03 page, H-15 attribution routing, H-25 translation, H-28 measurement, H-10 credential issuance) — **which is exactly where v1.3-B §26.4 showed fixed cost can be absorbed.**
>
> **And the rights run the other way:** H-07's seven refusals, H-17's ten exit rights, H-18's pause, H-19's eleven prohibitions and H-21's seven firewall rules are all **protections of the participant against the organisation.** A participant at Level 1 receives more rights than duties, and that asymmetry is the design.

---

# 61. FINAL ADVERSARIAL AUDIT

**Method:** written **against** this document. Each of your eighteen attacks is run at full force. Where the design survives, the reason is stated; where it does not, the failure is recorded as a finding. **No attack is deflected by reference to good intentions.**

## 61.1 The eighteen attacks

### AD-01 · "What if nobody cares?"
**Attack lands: YES — completely.**
Nothing in this document creates caring. §27.3's minimum viable loop assumes at least one person in the locality has a problem they want fixed. If they do not, there is no organisation.
**What survives:** §40's ladder starts with a promise so small it cannot fail — "we will come and look" — and §39.1 identifies visible service as the strongest trust signal. Caring is *produced* by a fixed drain, not by an argument.
**What fails:** **there is no instrument for a locality that is indifferent.** §56 HF-20 covers attention without effectiveness; nothing covers effectiveness without attention.
**Finding AD-01:** *unanswerable by design.* Routed to §59: the pilot locality must be chosen where a need is already articulated (§57.3 rule 1). **A team formed in an indifferent locality is not a pilot; it is a donation.**

### AD-02 · "What if people join only for money?"
**Attack lands: PARTIALLY — and the design anticipates it.**
**[S-ST: §5 Scenario A]**: at 100 members with no venture revenue this is fatal within a quarter; with one anchored revenue source it is survivable "but produces a transactional culture that is very hard to convert later. Culture formed under monetary framing resists re-framing."
**What survives:** §60.29 places **Door 3 in Stage 3**, behind v1.3-B §46.2's five conditions; §12.3 keeps any payment conversation out of the first thirty days; **[S-ST: §6.4]** prohibits unapproved earnings figures; §37.2 repeats it as an acquisition prohibition.
**What fails:** if the *only* people who come are the ones who came for money, no amount of sequencing produces purpose-motivated members. **The composition of the first cohort determines the culture, and composition is not designed anywhere in this document.**
**Finding AD-02:** *mitigated by sequencing; unmitigated by selection.* **[P] Addition:** the first cohort should be recruited through Doors 1 and 2 **only**, with Door 3 opened after the culture exists — which is what §60.29 already implies and §46.2 makes explicit.

### AD-03 · "What if people join only for status?"
**Attack lands: PARTIALLY.**
§44 exists for this. But status-seeking is rational where status is scarce, and the architecture has one scarce status: leadership.
**What survives:** §44.3 increases the supply of non-scarce recognition; §47 creates a horizontal ladder; §6.10 creates standing without command; §45.2 rule 4 prohibits imagery of a person as a symbol; §7.3 SR-3 prohibits ordinal ranking below L5.
**What fails:** **the leaderboard remains, R5 remains unresolved, and a public ranking of teams is a public ranking of the people in them however carefully scoped.**
**Finding AD-03:** *structurally mitigated, not eliminated.* **R5 (HD-C6) is the residual decision, and it should be answered before the second team exists.**

### AD-04 · "What if people join because of the founder?"
**Attack lands: YES — and this is the fastest-growing, worst-durability channel.**
**[S-ST: §6.2 row 17]** rates belief in the founder personally ❌: "Fastest growth, worst durability. Produces personality dependence (F-11) and collapses at the first founder controversy."
**What survives:** **v1.3-A A-16** — the four annual institutional tests (absence, attribution, dissent, successor), no portrait display, decisions announced in the institution's name; §20 AC-1/AC-3; §33 story framework prohibits founder narratives; §45.2 rule 4; §3.7 prohibits appeals to personal loyalty; §52.2 prohibits a founder-centred national story.
**What fails:** **the founder is, as a matter of source fact, the owner and CEO [S: Const. Art.3; Ch.4].** Nothing in this document can prevent a charismatic founder from being the reason people come. It can only prevent the *organisation* from saying so, rewarding it, or depending on it.
**Finding AD-04:** *the design cannot stop it; it can only make it visible and expensive.* **v1.3-A A-16 test 1 (the absence test) is the real control, and it must be run genuinely, not ceremonially.**

### AD-05 · "What if people join because their friends joined?"
**Attack lands: NO — and this is the one attack the design *wants*.**
§19.1 identifies local relationships as the primary belonging mechanism; §39.1 identifies referrals as near-zero-cost acquisition; §18.5 of v1.3-B identifies `r_referral` as one of the two most important business metrics.
**But the guard matters:** §22.3 MLM-4/MLM-6 prohibit **any** value attaching to an introduction. **Friend-driven growth is the goal; friend-driven *income* is the pathology.**
**Finding AD-05:** *desired, and firewalled.* The firewall is H-21, and its test T1 (correlation between income and introductions) should be zero.

### AD-06 · "What if service is boring?"
**Attack lands: YES — and no instrument fixes it.**
Cleaning a lane, sorting donated clothes, sitting with a homework circle: these are repetitive, physically uncomfortable and unglamorous. §34.2 lists *achievement* and *usefulness* as permitted emotions, but neither makes repetition pleasant.
**What survives:** §19.1 shows the mechanism that makes boring work bearable is **company** — H-06 pairing and H-12 stable teams. §32.3's shared meal after a project is the only "fun" instrument that passes all six tests. §27.1's loop returns an outcome, which converts repetition into accumulation.
**What fails:** **an organisation cannot make service entertaining, and should not try.** §2.3 excludes fun-as-product; §32.2 test 6 excludes costly entertainment.
**Finding AD-06:** *accepted, not solved.* **The honest position: service is boring, company makes it bearable, and outcome makes it meaningful.** Any design that promises otherwise will disappoint.

### AD-07 · "What if business work is more attractive than service?"
**Attack lands: YES.**
Business work is paid, skilled, time-bounded and has a customer who says thank you. Service work is unpaid, repetitive and has a beneficiary who may say nothing.
**What survives:** mission impact carries the **highest** performance weight, 20% vs business 15% **[S: Ch.25]**; **v1.3-B B-01** makes the service-hour budget a defended allocation; §55.3 HV-gates; §28.1 of v1.3-B reports mission as a dimension; §56 HF-11 detects it.
**What fails:** **weights do not pay rent.** If business work earns and service work does not, the attraction is economic, and no ethical instrument changes it.
**Finding AD-07:** *detected, not prevented.* **The only durable answer is v1.3-B's: service must be funded from somewhere (§33, B-24), because unfunded work will always lose to funded work.**

### AD-08 · "What if service is more emotionally attractive but economically unsustainable?"
**Attack lands: YES — this is §56 HF-10 and v1.3-B §29 Scenario 10.**
A team of deeply committed people delivering real service with no revenue: mission metrics excellent, cash position below `B_bare`.
**What survives:** v1.3-B §32.4 answers honestly — **such a team should be subsidised deliberately, not accidentally**; §22.4 Layer 1 provides non-cash transfer; B-24 provides a materials instrument; §46.2 gates Door 3 so nobody is recruited into an unfunded promise.
**What fails:** **the subsidy has no source.** v1.3-B E-03 (who funds the centre) is unresolved, and §33.4's B-24 creates a *place* for money rather than money.
**Finding AD-08:** *the human system's most attractive failure mode, and the economic system's most unsolved one.* **They are the same problem.** A person who joins for purpose and stays unpaid for two years is not a retention success; they are a deferred grievance.

### AD-09 · "What if people want flexible participation?"
**Attack lands: NO — the design is built for it.**
§15's eleven modes, §6's lateral paths, H-18's pause, §8.3's refusals, §13's friction ceiling.
**Finding AD-09:** *handled.* The residual risk is the opposite: **flexibility without any commitment produces no reliability**, and a team where nobody is reliably present cannot deliver. §15.1 M-3's explicit time contract is the counterweight — **flexible, but stated.**

### AD-10 · "What if people do not want leadership?"
**Attack lands: NO — anticipated and designed for.**
**[S-ST: §5 Scenario A]**: "Likely, because leadership here means accountability without pay certainty, social friction (F-03), compliance labour (F-05), and a lottery-sized upside (F-24)." §8's six endpoints, §47's horizontal ladder, §6.10's Elder standing, §8.3's right to refuse promotion permanently.
**What fails:** somebody must still hold the nine State A functions and the four segregated finance hands (**v1.3-B §3.3**). **A society of people who all refuse leadership is not a viable team.**
**Finding AD-10:** *handled for individuals; unresolved for the team.* **[S-ST: §5 Scenario A]** proposes a rotating facilitator for one quarter, explicitly not a rank, with the City holding accountability — **this is carried to §59 as an unresolved option, because it would need approval and it is not in the architecture.**

### AD-11 · "What if people want leadership but lack competence?"
**Attack lands: PARTIALLY.**
§44.3 and §47 create alternatives; **[S: Ch.11]**'s eligibility engine and **[S: Ch.13]**'s readiness gates filter; **v1.3-B B-18(1)** requires a successor to be trained before transition.
**What fails:** **desire is not filtered by the architecture, only appointment is.** A person who wants a role and does not get it is a retention risk, and §8.3's right to *refuse* has no mirror image — a right to be *told honestly* why they were not appointed.
**Finding AD-11:** *mitigated.* **[P] Addition:** appointment decisions should carry a reason the candidate may see, consistent with **v1.3-A A-15 M1** (no decision without a recorded reason) and **[S: Const. Art.17]** (appeal). **This is cheap, and its absence is a silent exit generator.**

### AD-12 · "What if the organisation becomes socially exclusive?"
**Attack lands: YES — and it is the hardest problem in the document.**
§56 HF-9. Detection normally requires composition data; **v1.3-A A-18 §17.4 prohibits collecting religion, caste or ethnicity absolutely**, and **v1.3-A A-05** requires that composition be monitored but never engineered — while **N5 (whether composition data may exist at all) is deliberately UNRESOLVED**.
**What survives:** HD-14's non-identity proxies (participation composition by locality and activity type, newcomer return rates, complaint patterns); H-06 pairing *across* the existing group; §28.1's published open-task list; §7.3 SR-5's need-based priority regardless of who reports.
**What fails:** **a homogeneous team that is warm inward and cold outward will not be detected by any of these until a newcomer fails to return** — and by then the pattern is established.
**Finding AD-12:** *genuinely unresolved.* Recorded honestly at HD-14 rather than solved with a mechanism that would violate the privacy rule it exists to serve. **The trade-off is real: privacy protection and exclusivity detection are in tension, and this document chooses privacy.**

### AD-13 · "What if the organisation becomes politically associated?"
**Attack lands: NO at the level of design, YES at the level of reality.**
**v1.3-A A-01…A-04** is a complete neutrality code: nine organisational prohibitions, a civic/partisan boundary with a newspaper-headline test, an election-period protocol with fourteen rules, and a refusal workflow with a register. §31.3, §52.2, §53.2 and §56 HF-18 extend it to identity, story, colour and symbol.
**What fails:** **association can be imposed from outside.** A photograph, a rumour, a relative of a member, a landlord who is a party worker, a single event near an election. No internal control prevents an external classification.
**Finding AD-13:** *internally closed, externally open.* **v1.3-A A-04's register and published refusal counts are the only defence — they make the organisation's own record contradistinct from the rumour.** That is the best available, and it is not a guarantee.

### AD-14 · "What if people fear leaving?"
**Attack lands: NO — if H-17 and H-18 are adopted, and YES if they are not.**
§21's ten rights; §21.2's asset table (credentials preserved, compensation paid at priority 1, record portable); §26.3's test — *could they leave cheaply?*; §20 AC-10/AC-11; §21.5's neutral speech about leavers; **[S-ST: §7.4]**'s rule that no member may be owed money, records or credentials as a condition of continued membership.
**Finding AD-14:** *handled — and it is the single strongest anti-cult instrument in the design, stronger than any prohibition.* **Coercion requires a captive asset. §25 and §21 ensure there are none.**

### AD-15 · "What if recognition becomes addictive?"
**Attack lands: PARTIALLY.**
§44.2's seven diagnostics; §44.3's six non-scarce instruments; §23.1's separation of six things; §45.2's five rules.
**What fails:** **addiction is a property of a person, not a system.** A system can refuse to supply ranking, and some people will manufacture their own.
**Finding AD-15:** *supply-side controlled, demand-side uncontrolled.* The residual guard is §44.2's detectors, particularly SA-4 (friendships becoming competitive), which is observable before it is damaging.

### AD-16 · "What if the leaderboard damages friendships?"
**Attack lands: YES.**
§56 HF-13; §44.2 SA-4; **[S-ST: M8]** cohort normalisation (comparing a team in a wealthy locality with one in a poor one is not comparison, it is a lottery).
**What survives:** **[S: Ch.25]**'s anomaly review, corrections and appeals; §44.4's scoping to teams; §23.3 rule 2 (recognition mostly local).
**What fails:** **the leaderboard is PROPOSED and R5 is unresolved**, and cohort normalisation is not yet adopted.
**Finding AD-16:** *two known fixes, neither adopted.* **HD-C5, HD-C6 and [S-ST: M8] should all be resolved before a second team exists to be compared with.**

### AD-17 · "What if local identity conflicts with national identity?"
**Attack lands: PARTIALLY.**
§31's five rules and six-layer sentence test; §30.3's no-senior-language rule; §52.3's caution that the national argument is for internal endurance, not for local participation; §31.3's five prohibitions.
**What fails:** **a real conflict — a state-level political mood against a national symbol, a language dispute, a regional grievance — cannot be resolved by architecture.** §31.1 ID-1 (local primary) is the tie-breaker, and it will sometimes cost the organisation a national opportunity.
**Finding AD-17:** *the tie-breaker exists and is correct; the cost is real and should be accepted in advance.* **[P] The rule to adopt now: when local and national conflict, the local layer wins, and the national layer says nothing publicly.**

### AD-18 · "What if the organisation becomes famous before it becomes effective?"
**Attack lands: YES — and this is the most likely failure of a well-designed organisation.**
§40's rung ladder with rung 8 never self-claimed; §56 HF-20; §36.2's refusal to set conversion targets; **[S-ST: §23]**'s "national brand is deliberately late — brand follows evidence, never precedes it."
**What survives:** §9.7's ten-second test is run *locally*, so a national reputation cannot be tested and will not be trusted internally; HD-17 pre-authorises a spokesperson to decline a story that exceeds the delivered rung.
**What fails:** **attention is not optional.** Once offered, refusing it is itself a decision with a cost, and the person refusing it will be under enormous pressure from people who see an opportunity.
**Finding AD-18:** *the instrument exists (HD-17) and it must be pre-authorised, because it will not survive being decided in the moment.* **This is the same logic v1.3-A applied to protection doctrine: restraint must be pre-decided, because in the moment it will be contested by someone with a strong reason to proceed.**

## 61.2 Six attacks this document ran on itself

| ID | Attack | Result |
|---|---|---|
| **AD-19** | **What if this document is itself the bureaucracy it warns against?** | **Partially lands.** 28 amendments, 15 measurements, 20 simulations, 23 register items. **Mitigation:** §60.30 shows L0–L2 carry zero new tasks; §60.29 stages adoption so Stage 1 is ten amendments; §55.4 rule 4 and §58.1 rule 5 apply the control-budget rule to human instruments. **Residual: a document this size will be skimmed, and a skimmed safeguard is not a safeguard.** §1.6's refusal list exists to be read first |
| **AD-20** | **What if every hypothesis here is wrong?** | **Lands, and is the point.** Every psychological claim is marked **[H]**, §57 exists to test them, and §62's verdict is **D — not yet proven** precisely because they are untested. **A document that claimed to know would be the failure your brief describes** |
| **AD-21** | **What if the design is right and the people are wrong?** | **Lands.** §41 assumes ten forms of human failure and §56 simulates twenty. But no design survives a team that does not want to be honest. **§32.4's answer is the only one available: culture travels by what people see rewarded and refused — so the pilot must observe refusals, not only activities** |
| **AD-22** | **What if the four doors are really one door with four signs?** | **Partially lands.** All four lead into the same verification spine **[S-ST: §6.3]**, which is the design's strength — and its risk: if the spine is slow, all four doors are slow. **Mitigation:** §7.1 keeps the spine only where responsibility begins; L1–L4 never touch it |
| **AD-23** | **What if "dignity" is used to justify never asking anything of anyone?** | **Lands.** §7.3 SR-1 and §8 could be read as prohibiting all expectation. **Mitigation:** §15.1 M-3's explicit time contract, §6.4's reliability expectation for L3, and §44.3's reliability recognition all *require* a stated commitment. **Dignity means the commitment is chosen and bounded — not that there is none** |
| **AD-24** | **What if the pilot measures compliance instead of experience?** | **Lands, and it is the most likely pilot failure.** §57.4 HPF-5 makes a pilot in which nobody disagreed, erred, refused or asked for help **unsuccessful**. §58.1 rule 2 forbids individual reporting. §57.2 question 8 measures safety by **observation of whether the sentences were said**, not by asking whether people feel safe |

## 61.3 Audit summary

| Attack | Landed? | Status |
|---|---|---|
| AD-01 nobody cares | **YES** | Unanswerable by design; locality selection is the only control |
| AD-02 only for money | Partial | Sequencing mitigates; **cohort selection does not** |
| AD-03 only for status | Partial | Mitigated; **R5 unresolved** |
| AD-04 because of the founder | **YES** | Cannot be stopped; can be made visible and expensive |
| AD-05 because friends joined | No | **Desired and firewalled (H-21)** |
| AD-06 service is boring | **YES** | Accepted, not solved: company and outcome, not entertainment |
| AD-07 business more attractive | **YES** | Detected, not prevented; **funding is the only durable answer** |
| AD-08 service attractive, unsustainable | **YES** | Same problem as v1.3-B E-03; **unresolved** |
| AD-09 want flexibility | No | Handled (H-23); counterweight is the stated time contract |
| AD-10 do not want leadership | No | Handled for individuals; **unresolved for the team** |
| AD-11 want leadership, lack competence | Partial | **[P] addition: appointment reasons visible to the candidate** |
| AD-12 socially exclusive | **YES** | **Genuinely unresolved — privacy chosen over detection (HD-14)** |
| AD-13 politically associated | No internally, **YES externally** | v1.3-A is the defence; association can be imposed |
| AD-14 fear leaving | No | **Handled — the strongest anti-coercion instrument in the design** |
| AD-15 recognition addictive | Partial | Supply-side controlled |
| AD-16 leaderboard damages friendships | **YES** | Two known fixes, neither adopted |
| AD-17 local vs national identity | Partial | Tie-breaker exists (local wins); cost must be accepted |
| AD-18 famous before effective | **YES** | Instrument exists (HD-17) and must be pre-authorised |

**[A] Score: 8 land fully, 4 partially, 6 are handled.** Every landed attack traces to one of three causes: **(i) an unfunded obligation** (AD-07, AD-08 — shared with v1.3-B); **(ii) a fact about human beings that no design changes** (AD-01, AD-04, AD-06, AD-14's inverse); or **(iii) a decision deliberately left unresolved to protect something else** (AD-12 privacy over detection, AD-03/AD-16 R5, AD-10 the Council question).

**Not one landed attack traces to a defect in the architecture's values.** The values are the strongest part of the design and they survive every test in this section. **What is missing is instruments, funding and evidence — in that order of difficulty.**

---

# 62. FINAL HUMAN-SYSTEM VERDICT

## 62.1 The classification

> # **D — HUMAN SYSTEM NOT YET PROVEN**
> ### with a defined path to **B — HUMAN SYSTEM VIABLE WITH TESTING**

**[A]** Your brief permits D and warns against choosing A because the architecture is attractive. **It is attractive.** That is precisely why the classification must not be B.

## 62.2 Why D and not C

**C would require major redesign.** The evidence does not support it:

| Test | Result |
|---|---|
| Does the architecture contain a human system that must be torn out? | **No.** §2.2: four needs are already ● and five are ◐. **[S: Ch.15]**'s outcome verification, **[S: Ch.19]**'s published payment formula, **[S: Ch.25]**'s anti-gaming controls and **[S: Ch.2]**'s principles are genuinely strong |
| Are the missing pieces structurally incompatible with what exists? | **No.** §28.1: eight of nine community functions are already latent. §6: the spectrum is "a clarification of latent design, not a silent change" **[S-ST: §9.2]** |
| Do the missing pieces require new authority, money or technology? | **No.** §2.4 finding 3: the missing half of the human system is the inexpensive half |
| Is any core mechanism unbuildable? | **No.** §27.3: the whole loop reduces to five acts requiring no software, budget, badge or ceremony |

**[A] The architecture does not need redesign. It needs instruments, and it needs evidence.** That is D, not C.

## 62.3 Why D and not B

**B would require that the instruments exist and only testing remains.** They do not exist:

| Requirement for B | Status |
|---|---|
| A way in that does not require joining | ❌ **H-01, H-02, H-03, H-05 not adopted.** Today the first available action is an application **[S: Ch.12]** |
| Belonging produced by design | ❌ **H-06, H-12 not adopted.** §2.2 N-02: **○ absent** |
| The outcome returned to the person who produced it | ❌ **H-15 not adopted.** §4.3 rank 3: the most damaging break |
| A record the person can carry | ❌ **H-09, H-10 not adopted.** "The most under-exploited asset in the architecture" **[S-ST: §6.2 row 6]** |
| A right to leave, pause and refuse | ❌ **H-17, H-18 not adopted.** No person-level status exists **[S: Ch.11]** tracks posts |
| Recognition separated from ranking | ❌ **H-08 not adopted**; **R5 unresolved** |
| A language a non-English speaker can read | ❌ **H-25 not adopted**; **HD-11 unresolved** |
| Any of it tested against one real person | ❌ **Nothing has been** |

**[A] Eight requirements, zero satisfied.** B is not available to a document.

## 62.4 The path to B, and from B to A

| Stage | What must happen | Classification reached |
|---|---|---|
| **1** | Adopt **§60.29 Stage 1** — the ten amendments that must exist before a single member of the public is contacted (H-01 doors 1–2, H-02, H-03, H-04, H-05, H-17, H-19, H-21, H-22, H-27) | **D+** — safe to make contact |
| **2** | Answer **HD-19** (youth legal position) and **HD-C3** (worker classification), because both determine whether §6 is lawful as designed | **D+** |
| **3** | Adopt **§60.29 Stage 2** — H-06, H-08, H-09, H-12, H-13, H-14, H-15, H-18, H-20, H-23, H-28 | **C+** — the instruments exist |
| **4** | **Design the human pilot (§57) jointly with v1.3-B §40**, on one team, in one ordinary locality, over one full local cycle, with the fifteen measurements funded and owned | **B — VIABLE WITH TESTING** |
| **5** | Run it, and let HM-1…HM-15 replace every **[H]** in this document with a measured value or a rejected hypothesis | **B** confirmed or corrected |
| **6** | Adopt **§60.29 Stage 3** — H-07, H-10, H-11, H-16, H-24, H-25, H-26 — and open Door 3 only when **v1.3-B §46.2**'s five conditions are met | **B+** |
| **7** | Repeat in a **second, low-demand locality** (v1.3-B E-24) to test whether the human system works where the economics do not | **A is only reachable here** — after two localities, two cycles, and one honest negative result |

**[A] Note step 7.** A human system proven in one favourable locality is not proven. **v1.3-B AD-10 established that the neediest localities have the least capacity; §61 AD-01 established that an indifferent locality has no loop at all.** A verdict of A requires the system to have worked somewhere it should not have.

## 62.5 What D means operationally

**[P]** Three permissions and three prohibitions that follow from the verdict:

**Permitted now:**
1. **Complete one §27.3 loop** — five acts, no software, no budget, no approval beyond what exists.
2. **Adopt Stage 1 of §60.29** — the ten instruments that make public contact safe.
3. **Design the joint pilot (§57 + v1.3-B §40)** and publish its failure conditions before starting.

**Prohibited while the verdict is D:**
1. **No national communication, brand campaign or expansion announcement.** §40 rung 8; §56 HF-20; HD-17.
2. **No recruitment at scale.** §36.2: a funnel with untested stages multiplied is a failure multiplied.
3. **No adoption of the core proposition as a slogan.** §3.6's three tests have not been run; **HD-03 remains open.**

## 62.6 The honest closing statement

**[A]** This instrument was asked to find out whether people would want to be part of Sewak Sathi. **It cannot answer that, and no document can.** What it can do — and has done — is identify the eighteen human needs, show that six are unmet, show that the six are cheap to meet, propose twenty-eight instruments to meet them, refuse to claim that any of them will work, and specify the fifteen measurements that would find out.

> **The organisation does not have a human-system problem. It has a human-system absence — and an absence is easier to fix than a problem, because nothing has to be undone.**
>
> **What cannot be fixed by absence-filling is the one thing §61 could not design: whether anyone in a particular lane wants a particular problem fixed enough to spend ninety minutes on it with two strangers. That is not an architecture question. It is the question the pilot exists to ask.**

---

# 63. THE ONE-PAGE ANSWER

> ## **"Why would an ordinary Indian join Sewak Sathi, what would make them return, what would make them trust it, and what would make them eventually want to build it?"**
>
> **[A] Every cell below is a hypothesis [H] until §58 measures it. Nothing here is a promise.**

| # | Person | **Why they would join** | **What would make them return** | **What would make them trust it** | **What would make them build it** |
|---|---|---|---|---|---|
| **1** | **Student** | A verified record of real work near home that they can show an employer — **Door 2, which the architecture does not currently open** | The record grows; a credential is issued; the people they worked with are still there | The record is **externally checkable** and honestly scoped (§25.3); nobody exaggerated what they did | A project of their own with their name on the outcome; a horizontal path that does not require managing people |
| **2** | **Worker (wage/industrial)** | Bounded contribution near home that does not collide with shifts; occasional paid work with a published formula | Hours that stay bounded; **payment that arrives when it was said to**; a pause when life intervenes | **A payment sheet showing the formula and the calculation** **[S: Ch.19 step 13]**; nobody was paid less arbitrarily | A skill credential that raises their rate; a say in the schedule |
| **3** | **Professional** | Three hours of real pro-bono scope where the skill is actually used, remotely if needed | Scope, not meetings; the outcome of their work reported back to them | **The organisation knows its own limits** — "we don't handle that, here's the municipal number"; advice never presented as an organisational position | A standard or curriculum they can own through the change-request route; advisory standing without line authority |
| **4** | **Entrepreneur** | A venture inside rules they can read, with an approval tier and a real customer pipeline at City level | Contribution-gated growth; a second track into higher-margin work; the centre actually delivering shared services | **The waterfall is published and the priority order is the control** **[S: Ch.18]**; a float with a cap and a term, not a favour | Ownership of a team or venture they seeded — **and replication proven in a different neighbourhood, not the same one** |
| **5** | **Homemaker** | A morning slot within walking distance, with other women, that ends when it says it ends | Her time contract is honoured; the team is stable; **family-inclusive rather than family-competing** | She was never asked for documents she did not want to give; her child was safe under the two-adult rule | Coordination of a workstream she can hold from home; recognition that is not a rank |
| **6** | **Elderly person** | Purpose, company and **the use of accumulated judgement** — verification by witness, mediation, local memory | Standing **without command**: Elder/Mentor, no RBAC, no score | They were not required to use an app; a paper and voice route always existed | Holding the locality's memory; blessing a new team; oral history recorded as institutional memory |
| **7** | **Farmer** | Help with a real problem — water, school, animal health — on the agricultural calendar, not the financial week | Cycles matched to the season; voice-first and paper-first processes; nobody assumed a smartphone | The team did not arrive with a city process that could not be used; a decline was delivered honestly | Labour pooling and a venture that uses what the locality already produces |
| **8** | **Shopkeeper** | A trustworthy local partner; help in a crisis; visible goodwill that returns footfall | They were never treated as a donor ATM; no political adjacency near their shop | **The organisation refused something** in front of them — a partisan request, a sponsorship with strings | Space and material become part of a named local result; sponsorship acknowledged without endorsement |
| **9** | **Specialist** | Scope-limited, conflict-declared, credential-verified engagement where they advise and are not conscripted | Their scope grew without their authority over people growing | **The professional-validation boundary was honoured** — internal training never claimed to be legal sufficiency **[S: Ch.12]** | Setting the standard for their domain across the network |
| **10** | **Person seeking livelihood** | **Honest work with honest accounting — and an earnings reality disclosed in writing before joining, describing the weak month, not the good one** | Payment continuity; an accrual recorded when a customer did not pay; a fair pro-rata rule in a bad month | **They can see how their payment was calculated, and challenge it** **[S: Ch.19; Const. Art.17]** | A move from delivery to venture ownership once contribution is demonstrated |
| **11** | **Occasional volunteer** | **One hour, once, with no form, no documents, no account and no expectation of anything further** | Nothing — **and that is the point.** They may return in a year and be welcomed without re-application | They were told "nothing further is expected" and it was true | They will not build it, and the organisation should not want them to. **§8.4: their one hour is published as a success** |
| **12** | **Person unable to participate physically** | Remote contribution designed **from the start**, not adapted later: translation, design, research, documentation, planning, AI operations, telephone follow-up, funding | A named local person telling them what their work became on the ground; appearance in the outcome | They were not told their contribution counted less because it was remote | Full L4→L8 progression without ever being physically present |

## 63.1 What Sewak Sathi offers that nothing else already offers

> **Do not assume the answer is "everything in one place." Prove the differentiated value.**

**[A]** Tested against the eleven alternatives in **[S-ST: §19.1]** — the mohalla WhatsApp group, the RWA, faith-based service committees, ideological service networks, caste and community associations, professional NGOs, NSS/NCC, gig platforms, local service providers, government schemes, and social networks.

**Four claims are defensible, because the architecture genuinely produces them and no single alternative does:**

| Claim | Why nothing else offers it | Basis |
|---|---|---|
| **1. Verified help that actually arrives, with evidence** | The WhatsApp group has no accountability; the NGO has evidence but is not in your mohalla; the social campaign has neither. **Only this architecture combines locality with an evidence chain**: verification → priority assessment → execution → evidence → **outcome verification: "Did the project solve or reduce the problem?"** | **[S: Ch.8, Ch.15, App. F]** |
| **2. You can see where the money went** | Faith and caste bodies are trusted but opaque; NGOs are accountable upward to funders, not to the neighbourhood. **A priority waterfall with receipts, reconciliation, a published formula version and an audit trail is close to unique in Indian giving** — *and it is only a differentiator if actually published* | **[S: Ch.18–19, Ch.27]** |
| **3. Your contribution is recorded and portable** | NSS gives a certificate bounded to student years; a gig platform gives a rating bounded to the platform; an employer gives a reference bounded to the job. **Nothing in the informal civic space gives a 19-year-old or a returning homemaker a dated, verified, externally checkable record of real work** — and the organisation already holds the underlying data | **[S: Ch.12, App. F]**; §25; **[S-ST: §19.2 claim 3]** |
| **4. Neighbourhood-scale, national-capability** | A WhatsApp group is local and powerless; a national NGO is powerful and absent. **A local team that can pull a specialist, a warehouse, a city reviewer, a safety escalation and a float from a national network can do both ends** | **[S: Ch.6, Ch.7]**; v1.3-B B-21 |

**Three claims that are NOT defensible and must never be made:**

| Do not claim | Why |
|---|---|
| ~~"Cheaper or faster than a professional agency"~~ | Not true — the organisation carries a governance cost they do not (**v1.3-B §25; [S-ST: F-05]**) |
| ~~"We pay better than the open market"~~ | Almost certainly not true (**[S-ST: F-34]**); claiming it produces the "scheme" accusation (**F-02**) |
| ~~"More trustworthy than existing community organisations"~~ | False and insulting. Existing faith, caste and neighbourhood bodies hold **far** more trust than a new entity. **The correct claim is "we are verifiable" — a different axis, on which winning requires nobody to lose** |

**[A] The one-sentence competitive answer, carried forward [S-ST: §19.3]:**

> *"Your mohalla group means well and cannot keep records. An NGO keeps records and is not in your mohalla. A platform pays and does not care. **We are the thing that is in your mohalla, keeps records, and pays fairly — and we can prove all three.**"*

**And the strategic posture, which is not competition at all [S-ST: §19.3]:** **complement and escalate.** Work *with* the RWA, the school, the PHC, the faith-based kitchen and the shopkeepers' association — activity-scoped, evidence-shared, credit-shared. **A new organisation that arrives as a rival to existing local institutions will be destroyed by them; one that arrives as capacity will be adopted by them.**

## 63.2 The final test, restated

> **Not:** how many members can we recruit?
> **But:** how many people voluntarily return because their participation made their life, their community, or someone else's life genuinely better?

**[A]** That question is answerable, and §58 HM-9 and HM-8 are the two measurements that answer it: **voluntary return** and **outcome known.** Everything else in this document exists to make those two numbers worth measuring.

**And §54.4's question is harsher still, and cannot be gamed:**

> *Which specific person, in which specific place, would be worse off if this team stopped?*

**Until that person can be named, the human system is not proven — and the verdict remains D.**

---

# ANNEXURE A — CONSISTENCY VERIFICATION

| Check | Result |
|---|---|
| Any v1.2 chapter, article, SOP, table or rule deleted, renumbered or reworded? | **No.** All 28 amendments are additive or appendment-based |
| Any v1.3-A amendment rewritten or contradicted? | **No.** v1.3-A is extended and relied upon: A-05 (language and cultural equality), A-06 (visibility), A-07 (under-claiming), A-08 (DO-NOTs bind every level), A-15 (memory, M1/M5/M7), A-16 (four institutional tests), A-17/A-18/A-19/A-20 (privacy, minimisation, dignity, sealed data), A-21/A-22 (AI governance), A-13 (Tier-1 candidates) |
| Any v1.3-B amendment rewritten or contradicted? | **No.** v1.3-B is extended: B-01 (service hour budget), B-05/B-06 (accrual and scarcity), B-09 (paid/volunteer boundary), B-13 (collection terms), B-18/B-19 (succession and interim authority), B-21 (shared services), §34 (economic dignity), §39 (never monetised), §40–42 (pilot) |
| Any UNRESOLVED / NOT FINAL / PROPOSED item closed? | **No.** Thirteen carried forward unchanged in §59.1 (HD-C1…HD-C13), including the public name, legal structure, worker classification, CEO/Council authority, leaderboard weights, R5, minimum staffing, retention, insurance, partnerships, N5, QR card and R1 |
| Any proposal converted into a final rule? | **No.** Every amendment is `PROPOSED — REQUIRES FINAL APPROVAL`; the core proposition is explicitly **not adopted** (§3.1, HD-03) |
| Any adoption percentage invented? | **No.** §36 assigns none; §36.2 gives four reasons why none may be assigned |
| Any psychological statistic invented? | **No.** Every behavioural claim is **[H]**, **[I]** or **[A]**, and routed to §58 |
| Any emotional message claimed to work without testing? | **No.** §3 treats the proposition as a hypothesis with nine failure modes and three tests; §57 requires testing |
| Any new outside research used? | **No.** Per your instruction. External facts already inside the stress test are marked **[X-inherited]** and are **not re-asserted as independent evidence** |
| Source terminology preserved? | **Yes** — Verified Member, Supporting Member, Coordinator, Sub-Role, Primary Role, Team Leader, Volunteer Manager, HR & Verification Manager, Ground-Level Manager, Planner, Editor, Social Media Manager, Funds Manager, Warehouse Manager, AI & Business Manager, Safety/Protection Lead, Mohalla / City / State / National Team, Head Team, Starter / Growing / Full Team, vacancy statuses, RBAC, autonomy readiness gate, service loop, waterfall priority order, social-impact fund, status labels |
| Leadership treated as morally superior to service? | **No — prohibited.** §8.2 six endpoints; §8.4 four prohibitions; §45.2 five rules; §6.10 Elder standing reachable from L3 |
| Levels 0–4 turned into "lesser people"? | **No — prohibited.** §7.3 SR-1…SR-7; §60.30 burden check shows **zero new tasks at L0–L2** |
| Any beneficiary recruited at the moment of need? | **No — prohibited absolutely.** §16.2 BS-1…BS-6, proposed as Tier-1 candidates |
| Any compensation derivable from recruitment? | **No — prohibited absolutely.** §22.3 MLM-1…MLM-7; §22.4 test T1 requires the correlation to be zero |
| Any contribution record able to become a social credit score? | **No — prohibited absolutely.** §24.2 CR-1…CR-4, proposed as Tier-1 candidates |
| Any cult mechanism permitted? | **No.** §20.1 AC-1…AC-11 with detectors and §20.2 CK-1…CK-7 checks |
| Any legal conclusion asserted? | **No.** Youth age rules, consent, safeguarding, employment characterisation, credential recognition and privacy all marked **[V]**; §48 Y-1 invents no age rule |
| Any uniform, insignia or force signal introduced? | **No.** §53.2 preserves **v1.3-A A-06 V1–V3, V8–V11** and prohibits the symbol list |
| Is the verdict derived from the model rather than from attractiveness? | **Yes.** §62.3 scores eight requirements for B: **zero satisfied** |

---

# ANNEXURE B — PROPOSAL INDEX

Every **[P]** instrument in this document, so nothing is buried.

| ID | Name | Section | Stage (§60.29) | Depends on |
|---|---|---|---|---|
| **H-01** | Four-Door Participation Model | §5, §60 | 1 (doors 1–2), **3 (door 3)** | **v1.3-B §46.2** for Door 3 |
| **H-02** | Nine-Level Participation Spectrum | §6, §7 | 1 | HD-C3 worker classification **[V]** |
| **H-03** | Public Local Page | §10, §28 | 1 | v1.3-A A-17 P3 notice **[V]** |
| **H-04** | First-Ten-Seconds Standard | §9 | 1 | v1.3-A A-07; HD-C1 name |
| **H-05** | First-Five-Minutes Experience | §10 | 1 | H-02, H-03 |
| **H-06** | Paired First Task | §11, §27 | 2 | §48 Y-3 where minors present **[V]** |
| **H-07** | No-Forced-Progression Rule; six endpoints; SR-1…SR-7; seven refusals | §8 | 3 | v1.3-A A-05, A-13 |
| **H-08** | Recognition Taxonomy (six instruments) | §23, §44 | 2 | R5 unresolved (HD-C6) |
| **H-09** | Verified Contribution Record; CR-1…CR-4 | §24 | 2 | v1.3-A A-17/A-18/A-20 |
| **H-10** | Portable Credentials | §25, §47 | 3 | HD-06 external recognition **[V]** |
| **H-11** | Specialist and Elder/Mentor Paths | §6.10, §47, §49 | 3 | **[S: Ch.12]** boundary **[V]** |
| **H-12** | Friendship Infrastructure | §19, §12 | 2 | — |
| **H-13** | Rituals Under Six Tests | §32 | 2 | v1.3-A A-01, A-05, A-06, A-16 **[V]** |
| **H-14** | Story Framework | §33 | 2 | v1.3-A A-19 |
| **H-15** | Attribution and Follow-Up Loop | §17, §18 | 2 | v1.3-A A-19 privacy of outcomes |
| **H-16** | Community Experience Charter | §28 | 3 | H-03 |
| **H-17** | Rights of Refusal; Exit with Dignity | §8.3, §21 | 1 | v1.3-B B-05; **[S: Const. Art.17]** |
| **H-18** | Paused and Alumni Status | §15.3, §21 | 2 | HD-C8 retention **[V]** |
| **H-19** | Anti-Cult Safeguard Instrument; AC-1…AC-11; CK-1…CK-7 | §20 | 1 | v1.3-A A-13 Tier-1; A-16 |
| **H-20** | Psychological Safety Instruments; seven sentences | §43 | 2 | HD-C4 for CK-1 independence |
| **H-21** | Anti-MLM Compensation Firewall; MLM-1…MLM-7 | §22 | 1 | **[S: Ch.18, Ch.19]** unchanged; HD-C3 **[V]** |
| **H-22** | Beneficiary/Recruitment Separation; BS-1…BS-6 | §16 | 1 | v1.3-A A-19, A-20 **[V]** |
| **H-23** | Flexible Participation Modes (eleven) | §15 | 2 | v1.3-B HC-15 |
| **H-24** | Remote Participation Architecture | §50 | 3 | **[V]** cross-border data, employment |
| **H-25** | Language Architecture (three layers) | §30 | 3 | v1.3-A A-05, A-06 V11, A-17 P3 **[V]** |
| **H-26** | Layered Identity; ID-1…ID-5 | §31, §51 | 3 | v1.3-A A-01, A-05 |
| **H-27** | Youth and Elder Participation Rules; Y-1…Y-10 | §48, §49 | 1 | **HD-19 [V] mandatory before any minor participates** |
| **H-28** | Human-System Measurement and Pilot; HV-1…HV-4; HM-1…HM-15 | §55, §57, §58 | 2 | **v1.3-B §40** joint pilot; v1.3-A A-17/A-20 for HM-13 |

**Additional [P] instruments not numbered as amendments:** §9.5 trust-signal rules · §9.7 ten-second test · §13.2 friction ceiling rule · §17.4 subject rule (anti-saviour grammar) · §18.4 uncomfortable-outcome rules · §28.2 four community rules · §29.4 the rule about names · §32.4 three transmission channels · §38.2 seven loop proofs · §39.3 the one legitimate amplifier · §40.2 the promise ladder · §41.2 absence-is-information · §44.2 seven status-addiction diagnostics · §46.3 five anti-dependency rules · §54.4 the annual named-person test · §61.1 AD-11 addition (appointment reasons visible) · §61.1 AD-17 tie-breaker (local wins) · §62.5 three permissions and three prohibitions under verdict D.

---

# ANNEXURE C — CONSOLIDATED [V] REGISTER (human system)

| # | Professional | Questions | Items |
|---|---|---|---|
| **HV-1** | **Employment / labour counsel** | Whether each participation level and mode is volunteering, employment or contracting; whether L4 specialist payment is supplier or wage; whether refusal rights and exit rights are enforceable; notice and final settlement | HD-C3, H-02, H-15, H-17, H-23 |
| **HV-2** | **Child safeguarding specialist** | Minimum ages, permissible hours, prohibited work, guardian consent form and revocability, the two-adult rule, certified supervision, online safety, reporting duties | **HD-19**, §48 Y-1…Y-10, H-06, H-27 |
| **HV-3** | **Privacy counsel / DPO** | What may be collected at each level; deletion at L1–L2; re-consent on upgrade; retention while paused or alumni; portability and erasure; HM-13 handling; any directory publication | H-02, H-09, H-10, H-18, H-28, HD-C8 |
| **HV-4** | **Vulnerable-adult / social-care specialist** | Participation by and service to vulnerable adults; capacity to consent; undue-influence risk in the beneficiary loop | H-22, §16.2, HM-13 |
| **HV-5** | **Regulated-profession bodies** | Whether any internal credential may be issued in medicine, law, engineering, teaching, counselling, first aid or security; what external recognition is available | H-10, H-11, HD-06, §47.3 |
| **HV-6** | **Corporate / entity counsel** | Whether an unincorporated network may issue credentials, hold records, publish a directory, or accept guardian consent | HD-C2, H-09, H-10, H-16 |
| **HV-7** | **Consumer / advertising counsel** | Whether any statement in §9, §33, §39 or §63.1 creates a representation; comparative-claim risk | H-04, H-14, §39.2 |
| **HV-8** | **Political / electoral counsel** | Colours, dates, symbols and events with political association per state; national service day | H-13, H-26, §53.2, HD-12, HD-13 |
| **HV-9** | **Tax / donations counsel** | Donor intent, restricted gifts, sponsorship conditions, FCRA for diaspora participation, 12A/80G interaction with any commercial activity | §39.3, §14 segment 25, v1.3-B B-24/B-26 |
| **HV-10** | **Accessibility specialist** | Physical and digital accessibility of the public page, tasks, events and records | H-03, H-16, H-24, §14 segment 24, §29.3 |

---

# ANNEXURE D — WHAT THIS INSTRUMENT DID NOT ADDRESS

**[A]** Stated explicitly, following the discipline v1.3-A Annexure D established: a document that lists what it did not do is more trustworthy than one that implies completeness.

| Not addressed | Where it lives | Why deferred |
|---|---|---|
| **The economic viability of the unit** | **v1.3-B** in full | Deliberately not repeated; §46.2 imports its conditions rather than restating them |
| **Institutional legitimacy, neutrality, protection doctrine, privacy programme** | **v1.3-A** in full | Imported as constraints throughout; not re-derived |
| **Scaling structure beyond national** — federation, public-interest governance | Stress-test §5 Scenarios D–F; **v1.3-B §31.4** | A later-stage structural question |
| **Platform and module design** | **[S: Ch.22]**; stress-test F-30, M12 | §29 allocates functions to channels but designs no system; **v1.3-B §40.2 confirms no software is needed for the pilot** |
| **Cohort normalisation of the performance system** | **[S-ST: M8, F-19]**; HD-C5, HD-C6 | Referenced at §44.4 and §56 HF-13; the mechanism is not designed here |
| **Integrity Line / ombuds design** | **[S-ST: M10, F-21]**; **v1.3-A A-16 §15.2** | Depended upon as CK-1; **full design still outstanding and should be adopted with Stage 1** |
| **Funding doctrine and donor policy** | **[S-ST: M19, F-32]**; **v1.3-B E-03, B-24, B-26** | The centre's pre-revenue funding source remains the single largest unresolved economic question |
| **Costed unit model** | **v1.3-B** | Complete |
| **A visual identity** | §53.3 | **Deliberately declined** — a symbol brief is proposed instead, because a visual system chosen in a document will be wrong in most localities |
| **The core proposition's adoption** | §3.6, HD-03 | **Deliberately declined** until tests T1, T2 and T3 are run |
| **Whether the Protection pillar is publicly named** | **[S-ST: §25.3 R1]**; HD-C13 | Carried forward unresolved; §9.2 excludes the word from the ten-second version either way |
| **Human-resource planning at scale** | **[S-ST: §23]**; **v1.3-B §31.3 NL-2** | Trainer and leader supply is a stock problem outside unit design |
| **Empirical validation of every [H] in this document** | **§57–§58** | **The whole purpose of the pilot. Nothing here is proven.** |

---

*End of v1.3-C. Human system, participation and mass adoption architecture. No element of v1.2, v1.3-A or v1.3-B was removed, renumbered or silently altered. No adoption percentage, psychological statistic or conversion rate was invented. No emotional message is claimed to work. Every proposal is marked `PROPOSED` and requires approval by the Founder/CEO under **[S: Const. Art.18]**, professional validation wherever marked **[V]**, and pilot testing wherever marked **[H]**.*
